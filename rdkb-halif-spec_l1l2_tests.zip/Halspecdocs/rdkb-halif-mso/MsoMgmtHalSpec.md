# MSO Management HAL Specification

## Scope and evidence

The executable public surface in [mso_mgmt_hal.h](../../include/mso_mgmt_hal.h) consists of password-of-the-day (PoD) validation and seed get/set. MSO means Multiple System Operator; HAL means Hardware Abstraction Layer.

The header's introductory prose mentions broader provisioning, data-model access, and events, but no corresponding entry points are declared. This specification does not promise those capabilities, general device management, firmware upgrades, encryption services, context handles, or callbacks.

## Architecture

~~~mermaid
flowchart TD
    C["Authorized management caller"] --> H["mso_mgmt_hal.h"]
    H --> V["Vendor PoD implementation"]
    V --> S["Seed source and daily-password logic"]
    V --> T["Time source used by validation"]
~~~

Seed storage and time integration are vendor-specific; the diagram is a conceptual boundary, not a mandated implementation.

## Complete API inventory

| Exact declaration | Header contract |
| --- | --- |
| `mso_pwd_ret_status mso_validatepwd(char *pwd);` | Caller-provided password input, validated against current MSO password of the day. Returns the enum, not generic `0/-1` success. |
| `INT mso_set_pod_seed(char *pSeed);` | Input buffer at least 64 bytes. Returns `RETURN_OK` or `RETURN_ERR`; newer broadband devices must decrypt the seed on demand when called. |
| `INT mso_get_pod_seed(char *pSeed);` | Output buffer at least 64 bytes, retrieved/decrypted from configuration or `rdkbEncryptedClientSeed` SNMP OID. Returns `RETURN_OK` or `RETURN_ERR`. Header requires manually overwriting the buffer after use. |

## Complete type and constant inventory

| Item | Definition |
| --- | --- |
| `mso_pwd_ret_status` | Implicit enum values: `Invalid_PWD=0`, `Good_PWD=1`, `Unique_PWD=2`, `Expired_PWD=3`, `TimeError=4`. |
| Scalar macro aliases | `CHAR=char`, `UCHAR=unsigned char`, `BOOLEAN=unsigned char`, `INT=int`, `UINT=unsigned int`, `ULONG=unsigned long`, each conditionally defined. |
| Typedefs | `uint16=unsigned short`, `uint32=unsigned long`, `boolean=int`. `uint32` is not guaranteed to be 32 bits on all ABIs. |
| Boolean/status constants | `TRUE=1`, `FALSE=0`, `ENABLE=1`, `RETURN_OK=0`, `RETURN_ERR=-1`, `ERROR=-1`. |
| Other constants | `SEC_PER_YEAR=31536000`; `SIZE_arrisCmDevHttpClientSeed=8L`. The latter is guarded by differently spelled `SIZE_arrisCmDevHttpClientSee`. |

No public structs, object handles, callback typedefs, or public variables are declared. `Unique_PWD` exists in the enum but is omitted from the validation function's listed return cases and questioned by a header TODO.

## Lifecycle and representative sequence

No initializer or deinitializer is declared. Seed provisioning and validation are distinct operations; reading or resetting the seed is not required before every password check.

~~~mermaid
sequenceDiagram
    participant C as Authorized caller
    participant H as Vendor HAL
    C->>H: mso_validatepwd(pwd)
    H-->>C: mso_pwd_ret_status
    opt Authorized seed retrieval
        C->>H: mso_get_pod_seed(pSeed)
        H-->>C: INT status; seed on success
        Note over C: Securely overwrite seed storage after use
    end
~~~

An invalid password has numeric value zero, so treating zero as universal success is incorrect.

## Ownership, security, errors, and concurrency

Caller owns password and seed buffers. No allocation-return or release function exists. The ABI takes mutable pointers even for documented inputs, with no explicit length arguments or input-retention rule.

Keep passwords and seeds out of logs, diagnostics, and crash artifacts. Apply the header's overwrite requirement to retrieved seeds and use a secure erasure mechanism appropriate to the integration. Authorization, rate limiting, trust boundaries, seed encoding, and cryptographic algorithms are not specified by these declarations.

Seed calls use generic `0/-1`; validation distinguishes invalid, good, expired, and time error, with unresolved `Unique_PWD` behavior. Failure does not guarantee output initialization.

No async callback, power-control API, or object lifecycle exists. Thread safety, process locking, blocking limits, and persistent seed-storage semantics are not fully declared. Integration policy is to serialize operations, coordinate concurrent processes, and avoid unbounded calls on critical event loops.

## Integration and delivery policy

Retain Linux/Yocto support, Apache License 2.0 implementation, and delivery as `libhal_msomgmt.so`. Consumers include the linked header and link this library. Semantic versioning is interface-governance policy, not a runtime negotiation API.

Vendors clean up internal resources and provide multi-process protection; callers manage their own buffers. Numeric memory, CPU, and deadline targets remain unresolved. Syslog-backed diagnostics go to `mso_vendor_hal.log` under `/var/tmp/` or `/rdklogs/logs/`, with timestamps and severity but no credentials or seeds. FATAL/TRACE are project labels, not native syslog priorities. Static analysis, dependency/license review, and leak analysis remain recommended.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| MSO-GAP-01 | Resolve `Unique_PWD` enum versus function documentation and header TODO. |
| MSO-GAP-02 | Reconcile seed constant `8L` with documented minimum 64-byte buffers and mismatched macro guard spelling. |
| MSO-GAP-03 | No lengths: specify password maximum, seed encoding/length, termination, and short-buffer behavior. |
| MSO-GAP-04 | Define daily rollover, timezone, clock validity, expiry, and `TimeError` conditions. |
| MSO-GAP-05 | Clarify seed retention, persistence, atomic updates, and synchronization across processes. |
| MSO-GAP-06 | Specify timing bounds, failure-output validity, and security controls outside this narrow ABI. |
