# DHCPv4 Client HAL Specification

## Scope and evidence

The public surfaces are [dhcp4cApi.h](../../include/dhcp4cApi.h) and [dhcpv4c_api.h](../../include/dhcpv4c_api.h). They declare parallel `dhcp4c_` and `dhcpv4c_` getter families for E-Router (ERT), embedded cable modem (ECM), and conditionally embedded multimedia terminal adapter (eMTA).

DHCP means Dynamic Host Configuration Protocol; HAL means Hardware Abstraction Layer. Neither header declares DHCP server operations, start/stop, renew/release commands, configuration setters, callbacks, initialization, or object handles. Similar names do not establish aliasing, wrapper dispatch, or shared implementation between the two surfaces.

## Architecture

~~~mermaid
flowchart TD
    C["RDK-B caller"] --> A["dhcp4cApi.h: dhcp4c getters"]
    C --> B["dhcpv4c_api.h: dhcpv4c getters"]
    A --> V["Vendor information provider"]
    B --> V
    V --> S["Existing ERT, ECM and optional eMTA client state"]
~~~

The shared vendor box is conceptual; no runtime dispatch or particular DHCP daemon is mandated.

## Complete API inventory

Each cell contains the declared function name and parameter list. Every legacy function returns `int`; every newer function returns `INT` (conditionally defined as `int`). All pointer parameters below are outputs.

### E-Router: twelve functions per header

| Purpose | `dhcp4cApi.h` | `dhcpv4c_api.h` |
| --- | --- | --- |
| Offered lease | `dhcp4c_get_ert_lease_time(unsigned int *pValue)` | `dhcpv4c_get_ert_lease_time(UINT *pValue)` |
| Lease remaining | `dhcp4c_get_ert_remain_lease_time(unsigned int *pValue)` | `dhcpv4c_get_ert_remain_lease_time(UINT *pValue)` |
| Renewal remaining | `dhcp4c_get_ert_remain_renew_time(unsigned int *pValue)` | `dhcpv4c_get_ert_remain_renew_time(UINT *pValue)` |
| Rebind remaining | `dhcp4c_get_ert_remain_rebind_time(unsigned int *pValue)` | `dhcpv4c_get_ert_remain_rebind_time(UINT *pValue)` |
| Attempts | `dhcp4c_get_ert_config_attempts(int *pValue)` | `dhcpv4c_get_ert_config_attempts(INT *pValue)` |
| Interface name | `dhcp4c_get_ert_ifname(char *pName)` | `dhcpv4c_get_ert_ifname(CHAR *pName)` |
| Client state | `dhcp4c_get_ert_fsm_state(int *pValue)` | `dhcpv4c_get_ert_fsm_state(INT *pValue)` |
| IPv4 address | `dhcp4c_get_ert_ip_addr(unsigned int *pValue)` | `dhcpv4c_get_ert_ip_addr(UINT *pValue)` |
| Subnet mask | `dhcp4c_get_ert_mask(unsigned int *pValue)` | `dhcpv4c_get_ert_mask(UINT *pValue)` |
| Gateway | `dhcp4c_get_ert_gw(unsigned int *pValue)` | `dhcpv4c_get_ert_gw(UINT *pValue)` |
| DNS list | `dhcp4c_get_ert_dns_svrs(ipv4AddrList_t *pList)` | `dhcpv4c_get_ert_dns_svrs(dhcpv4c_ip_list_t *pList)` |
| DHCP server | `dhcp4c_get_ert_dhcp_svr(unsigned int *pValue)` | `dhcpv4c_get_ert_dhcp_svr(UINT *pValue)` |

### ECM: twelve functions per header

| Purpose | `dhcp4cApi.h` | `dhcpv4c_api.h` |
| --- | --- | --- |
| Offered lease | `dhcp4c_get_ecm_lease_time(unsigned int *pValue)` | `dhcpv4c_get_ecm_lease_time(UINT *pValue)` |
| Lease remaining | `dhcp4c_get_ecm_remain_lease_time(unsigned int *pValue)` | `dhcpv4c_get_ecm_remain_lease_time(UINT *pValue)` |
| Renewal remaining | `dhcp4c_get_ecm_remain_renew_time(unsigned int *pValue)` | `dhcpv4c_get_ecm_remain_renew_time(UINT *pValue)` |
| Rebind remaining | `dhcp4c_get_ecm_remain_rebind_time(unsigned int *pValue)` | `dhcpv4c_get_ecm_remain_rebind_time(UINT *pValue)` |
| Attempts | `dhcp4c_get_ecm_config_attempts(int *pValue)` | `dhcpv4c_get_ecm_config_attempts(INT *pValue)` |
| Interface name | `dhcp4c_get_ecm_ifname(char *pName)` | `dhcpv4c_get_ecm_ifname(CHAR *pName)` |
| Client state | `dhcp4c_get_ecm_fsm_state(int *pValue)` | `dhcpv4c_get_ecm_fsm_state(INT *pValue)` |
| IPv4 address | `dhcp4c_get_ecm_ip_addr(unsigned int *pValue)` | `dhcpv4c_get_ecm_ip_addr(UINT *pValue)` |
| Subnet mask | `dhcp4c_get_ecm_mask(unsigned int *pValue)` | `dhcpv4c_get_ecm_mask(UINT *pValue)` |
| Gateway | `dhcp4c_get_ecm_gw(unsigned int *pValue)` | `dhcpv4c_get_ecm_gw(UINT *pValue)` |
| DNS list | `dhcp4c_get_ecm_dns_svrs(ipv4AddrList_t *pList)` | `dhcpv4c_get_ecm_dns_svrs(dhcpv4c_ip_list_t *pList)` |
| DHCP server | `dhcp4c_get_ecm_dhcp_svr(unsigned int *pValue)` | `dhcpv4c_get_ecm_dhcp_svr(UINT *pValue)` |

### Conditional eMTA: three functions per header

Only declared when `NO_MTA_FEATURE_SUPPORT` is not defined.

| Purpose | `dhcp4cApi.h` | `dhcpv4c_api.h` |
| --- | --- | --- |
| Lease remaining | `dhcp4c_get_emta_remain_lease_time(unsigned int *pValue)` | `dhcpv4c_get_emta_remain_lease_time(UINT *pValue)` |
| Renewal remaining | `dhcp4c_get_emta_remain_renew_time(unsigned int *pValue)` | `dhcpv4c_get_emta_remain_renew_time(UINT *pValue)` |
| Rebind remaining | `dhcp4c_get_emta_remain_rebind_time(unsigned int *pValue)` | `dhcpv4c_get_emta_remain_rebind_time(UINT *pValue)` |

Thus each header has 24 unconditional and three conditional functions; both headers together contain 54 declarations when eMTA support is enabled. There is no eMTA full-getter family.

## Complete type and constant inventory

| Header | Item | Definition |
| --- | --- | --- |
| Legacy | `enum DHCPC_CMD` | Sequential `DHCPC_CMD_LEASE_TIME=0`, `DHCPC_CMD_LEASE_TIME_REMAIN=1`, `DHCPC_CMD_RENEW_TIME_REMAIN=2`, `DHCPC_CMD_REBIND_TIME_REMAIN=3`, `DHCPC_CMD_CONFIG_ATTEMPTS=4`, `DHCPC_CMD_GET_IFNAME=5`, `DHCPC_CMD_FSM_STATE=6`, `DHCPC_CMD_IP_ADDR=7`, `DHCPC_CMD_IP_MASK=8`, `DHCPC_CMD_ROUTERS=9`, `DHCPC_CMD_DNS_SVRS=10`, `DHCPC_CMD_DHCP_SVR=11`, `DHCPC_CMD_MAX=12`. No dispatcher accepting this enum is declared. |
| Legacy | `enum DHCPC_MODULE` | `DHCPC_ECM=0`, `DHCPC_EROUTER=1`, conditional `DHCPC_EMTA=2`. |
| Legacy | `MAX_IPV4_ADDR_LIST_NUMBER` | `4`. |
| Legacy | `ipv4AddrList_t` | `int number`; `unsigned int addrList[MAX_IPV4_ADDR_LIST_NUMBER]`. |
| Newer | `DHCPV4_MAX_IPV4_ADDRS` | `4`. |
| Newer | `dhcpv4c_ip_list_t` | `INT number`; `UINT addrs[DHCPV4_MAX_IPV4_ADDRS]`. This is a separate declared type, not a typedef alias of the legacy struct. |
| Newer | Scalar aliases | Conditional `ULONG=unsigned long`, `BOOL=unsigned char`, `CHAR=char`, `UCHAR=unsigned char`, `INT=int`, `UINT=unsigned int`. |
| Newer | Flags/status | Conditional `TRUE=1`, `FALSE=0`, `ENABLE=1`, `STATUS_SUCCESS=0`, `STATUS_FAILURE=-1`. |

No callbacks, handles, or public variables exist. The legacy comments reference `STATUS_SUCCESS/STATUS_FAILURE` without defining them in that header; the newer header defines them.

## Behavior, lifecycle, and sequence

Lease durations and remaining times are documented in seconds. The legacy ERT offered-lease comment gives maximum 604800; do not generalize it into an all-role/all-header bound. Interface-name output needs at least 64 bytes. IPv4 address outputs are integer representations, not string buffers; byte order requires agreement.

The legacy `dhcp4c_get_ert_fsm_state` comment documents `1=RELEASED or INIT_REBOOT`, `2=INIT_SELECTING`, `3=REQUESTING`, `4=REBINDING`, `5=BOUND`, and `6=RENEWING or RENEW_REQUESTED`. These are comment-defined values, not a public state enum. The legacy ECM getter instead references `enum DHCPC_CMD`, which is not declared in that header; do not silently apply the ERT mapping to ECM or the newer API family. No transition API or complete transition table is declared. State observation is not permission to infer client transitions or setter behavior. No strict ordering among getters is declared.

~~~mermaid
sequenceDiagram
    participant C as Caller
    participant H as Vendor HAL
    C->>H: dhcpv4c_get_ert_ifname(pName)
    H-->>C: INT status; name on success
    C->>H: dhcpv4c_get_ert_remain_lease_time(pValue)
    H-->>C: INT status; remaining seconds on success
    C->>H: dhcpv4c_get_ert_dns_svrs(pList)
    H-->>C: INT status; DNS list on success
~~~

This is a representative use of the newer surface, not required sequencing or evidence that separate outputs are atomic.

## Ownership, errors, timing, and concurrency

Caller owns scalar outputs, name buffers, and list structs. Bound list counts to four before indexing. There is no returned allocation or release function. Check status before consuming data; null handling, truncation, and partial outputs are not fully specified.

The newer surface uses `0/-1`; establish legacy numeric status definitions with the integration rather than relying on unrelated includes. No detailed error accessor or `errno` contract is declared.

No callback, initialization, shutdown, power-control, or persistence setter is exposed. Thread safety, reentrancy, process exclusion, maximum duration, cancellation, and cross-getter snapshot consistency are not declared. Integration policy requires caller serialization, vendor cross-process protection, and cleanup of private resources. A synchronous getter is not guaranteed nonblocking.

## Integration and delivery policy

Retain Linux/Yocto support, Apache License 2.0 implementation, and delivery guidance `libapi_dhcpv4c.so`. Select the matching public header and exported symbol family; this document does not prove runtime symbol availability or mapping between families. Controlled semantic versioning remains policy.

Route timestamped syslog diagnostics to `dhcp_vendor_hal.log` under `/var/tmp/` or `/rdklogs/logs/`. Map FATAL/TRACE project labels to real priorities and minimize network-identifier exposure. Numeric memory/CPU/response-time targets remain unassigned. Static analysis, license/dependency review, and memory analysis remain recommended, not execution performed here.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| DHCP4-GAP-01 | Two similar symbol families exist without an aliasing/dispatch contract; verify the deployed surface separately. |
| DHCP4-GAP-02 | Legacy status macros are referenced but undefined locally; identify numeric definitions. |
| DHCP4-GAP-03 | IPv4 integer byte order, lease-infinity encoding, and unavailable-value sentinels need definition. |
| DHCP4-GAP-04 | Formal state enum, transition semantics, and role/header state-value consistency are not declared. |
| DHCP4-GAP-05 | Lengthless names: define maximum, termination, truncation, and failed-call outputs. |
| DHCP4-GAP-06 | Define timing, atomicity across getters, thread safety, and process locking. |
| DHCP4-GAP-07 | Newer ECM gateway comment describes a mask while the declaration/brief identify gateway; resolve the inconsistency. |
| DHCP4-GAP-08 | `NO_MTA_FEATURE_SUPPORT` changes declarations and module enum membership; no runtime capability API is declared. |
