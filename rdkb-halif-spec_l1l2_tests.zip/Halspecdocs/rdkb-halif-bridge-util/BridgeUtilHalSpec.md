# Bridge Util HAL Specification

## Scope and evidence

[bridge_util_hal.h](../../include/bridge_util_hal.h) declares seven bridge-management functions; [network_interface.h](../../include/network_interface.h) supplies companion data types and no functions. This repository supplies interfaces, not a vendor implementation.

HAL means Hardware Abstraction Layer; RDK-B means Reference Design Kit for Broadband; OEM means Original Equipment Manufacturer; OVS means Open vSwitch; GRE means Generic Routing Encapsulation. Capabilities are limited to bridge mutations through one vendor entry point, pre/post hooks, interface existence/membership queries, a string-list edit, and vendor-interface enumeration. No forwarding counters, learned-MAC/FDB query, packet observation, generic link-status getter, callback, or power-control function is declared.

## Architecture

~~~mermaid
flowchart TD
    C["Upper-stack bridge caller"] --> H["bridge_util_hal.h"]
    T["network_interface.h companion types"] -. "No conversion API declared" .-> C
    H --> V["Vendor bridge implementation"]
    V --> N["Platform network interfaces and bridge operations"]
    H -. "External globals and shared logging buffers" .-> S["Integration-owned shared state"]
~~~

Linux bridge/netlink is a possible integration boundary, not a required implementation. A script-path constant does not prove a script is invoked.

## Complete API inventory

| Exact declaration | Behavior and return |
| --- | --- |
| `int updateBridgeInfo(bridgeDetails *bridgeInfo, char *ifNameToBeUpdated, int Opr, int type);` | Create/update/delete bridge configuration. Interface name applies during synchronization. `Opr` refers to missing `enum OVS_CMD`; resolve mapping before mutation. `type` uses `enum INTERFACE_TYPE` cast to `int`; synchronization deletion uses `IF_OTHER_BRIDGEUTIL`. Returns `0/-1` success/failure. |
| `int checkIfExists(char *iface_name);` | Vendor interface existence. `INTERFACE_EXIST=0`, `INTERFACE_NOT_EXIST=-1`; no distinct diagnostic reason. |
| `void removeIfaceFromList(char *str, const char *sub);` | Removes a name from caller-supplied list. Missing name is a no-op. `str` must be writable despite its input annotation. No error return. |
| `int checkIfExistsInBridge(char *iface_name, char *bridge_name);` | Interface membership query, not forwarding/link-state query. Returns `0/-1`. |
| `int HandlePreConfigVendor(bridgeDetails *bridgeInfo, int InstanceNumber);` | OEM/SoC hook before `updateBridgeInfo`; `InstanceNumber` uses `enum Config` cast to `int`. Returns `0/-1`. |
| `int HandlePostConfigVendor(bridgeDetails *bridgeInfo, int Config);` | OEM/SoC hook after `updateBridgeInfo`; `Config` uses `enum Config` cast to `int`. Returns `0/-1`. |
| `char *getVendorIfaces();` | Zero-terminated vendor-interface string; `NULL` means no interfaces, not necessarily error. Allocation/release/lifetime unresolved. Empty parameter list is not a zero-argument prototype in traditional C; do not invent parameters. |

There are five integer-status functions, one `void` function, and one pointer-returning function. Older spellings `checkIfExist` and `checkIfExistinBridge` are not declared.

## Complete type inventory

### `bridgeDetails` struct tag and typedef

| Field | Type/capacity |
| --- | --- |
| `bridgeName`, `vlan_name`, `VirtualParentIfname` | Each `char[BRIDGE_NAME_SIZE]`, capacity 64. |
| `vlanID` | `int`. |
| `ethIfList`, `MoCAIfList`, `GreIfList`, `WiFiIfList` | Each `char[IFLIST_SIZE]`, capacity 256. |

Names and VLAN IDs in comments are examples, not exhaustive ranges. Embedded arrays are not separately allocated pointers.

### `Gateway_Config_Non_Ovs_Bridge` struct tag and typedef

| Field | Type/capacity |
| --- | --- |
| `if_name`, `parent_ifname` | Each `char[MAX_IF_NAME_SIZE]`, capacity 16 including NUL. |
| `inet_addr`, `netmask`, `gre_remote_inet_addr`, `gre_local_inet_addr` | Each `char[MAX_IP_ADDR_SIZE]`, capacity 16 including NUL. |
| `parent_bridge` | `char[MAX_BRIDGE_NAME_SIZE]`, capacity 16 including NUL. |
| `mtu`, `vlan_id` | `int`; MTU documented in bytes, ranges unspecified. |
| `if_type` | `IF_TYPE`. |
| `if_cmd` | `BR_CMD`. |

No public function accepts this companion struct; conversion to `bridgeDetails` is not declared.

### All five enums

| Enum | Complete values |
| --- | --- |
| `enum Config` | `PRIVATE_LAN=1`, `HOME_SECURITY=2`, `HOTSPOT_2G=3`, `HOTSPOT_5G=4`, `LOST_N_FOUND=6`, `HOTSPOT_SECURE_2G=7`, `HOTSPOT_SECURE_5G=8`, `MOCA_ISOLATION=9`, `MESH_BACKHAUL=10`, `ETH_BACKHAUL=11`, `MESH=12`, `MESH_WIFI_BACKHAUL_2G=13`, `MESH_WIFI_BACKHAUL_5G=14`, `MESH_ONBOARD=18`, `MESH_WIFI_ONBOARD_2G=19`. Conditional `MANAGE_WIFI_BRIDGE=17` under `WIFI_MANAGE_SUPPORTED`; `AMENITY_BRIDGE_2G=20`, `AMENITY_BRIDGE_5G=21`, `AMENITY_BRIDGE_6G=22` under `AMENITIES_NETWORK_ENABLED` and not `_CBR2_PRODUCT_REQ_`. |
| `enum INTERFACE_TYPE` | `IF_BRIDGE_BRIDGEUTIL=1`, `IF_VLAN_BRIDGEUTIL=2`, `IF_GRE_BRIDGEUTIL=3`, `IF_MOCA_BRIDGEUTIL=4`, `IF_WIFI_BRIDGEUTIL=5`, `IF_ETH_BRIDGEUTIL=6`, `IF_OTHER_BRIDGEUTIL=7`. |
| `enum BridgeOpr` | `DELETE_BRIDGE=0`, `CREATE_BRIDGE=1`. This does not resolve the missing `OVS_CMD` mapping. |
| Companion tag/typedef `IF_TYPE` | `OTHER_IF_TYPE=0`, `BRIDGE_IF_TYPE=1`, `ETH_IF_TYPE=2`, `GRE_IF_TYPE=3`, `VLAN_IF_TYPE=4`. |
| Companion tag/typedef `BR_CMD` | `IF_UP_CMD=0`, `IF_DOWN_CMD=1`, `IF_DELETE_CMD=2`, `BR_REMOVE_CMD=3`. |

Different interface-type enums have different numeric assignments and are not interchangeable. No mapping between `BR_CMD`, `BridgeOpr`, and `Opr` is supplied. Compile-time enum membership is not proof of runtime hardware support.

## Complete constant and macro inventory

| Header | Symbols and values |
| --- | --- |
| HAL | `BRIDGE_UTIL_LOG_FNAME="/rdklogs/logs/bridgeUtils.log"`; `GRE_HANDLER_SCRIPT="/etc/utopia/service.d/service_multinet/handle_gre.sh"`. |
| HAL | `TOTAL_IFLIST_SIZE=1024`, `BRIDGE_NAME_SIZE=64`, `IFACE_NAME_SIZE=64`, `IFLIST_SIZE=256`, `MAX_LOG_BUFF_SIZE=1024`, `TIMESTAMP=64`. |
| HAL | `INTERFACE_EXIST=0`, `INTERFACE_NOT_EXIST=-1`. |
| Companion | `MAX_IF_NAME_SIZE=16`, `MAX_IP_ADDR_SIZE=16`, `MAX_BRIDGE_NAME_SIZE=16`; each includes the terminator. |
| HAL function-like macro | `bridge_util_log(fmt ...)`: formats shared buffers, adds UTC time, writes and flushes `logFp` when non-NULL. |

The logging macro formats once even if `logFp` is NULL, and formats its variadic arguments again when the stream is non-NULL. Arguments with side effects can therefore execute twice. Its comment promises stdout fallback, but the body has none. Shared buffers, time objects and `gmtime` use require synchronization; the macro has no severity/filter parameter or independent error result.

## Complete public global inventory

| Object | Declared type and meaning |
| --- | --- |
| `DeviceMode` | `int`; comment gives router mode 0, bridge mode 2. |
| `MocaIsolation_Val` | `int`; MoCA isolation value. |
| `need_wifi_gw_refresh`, `need_switch_gw_refresh` | `int`; gateway refresh flags. |
| `syncMembers` | `int`; synchronization variable. |
| `BridgeOprInPropgress` | `int`; operation-in-progress flag, preserving declared spelling. |
| `logFp` | `FILE *`; stream ownership/open/close unresolved. |
| `log_buff` | `char[MAX_LOG_BUFF_SIZE]`. |
| `log_msg_wtime` | `char[MAX_LOG_BUFF_SIZE+TIMESTAMP]`. |
| `primaryBridgeName` | `char[64]`. |
| `PORT2ENABLE`, `ethWanEnabled` | `int`; port/Ethernet-WAN status variables. |
| `ethWanIfaceName` | `char[64]`. |
| `timeinfo` | `struct tm *`. |
| `utc_time` | `time_t`. |

These fifteen external objects require definitions and initialization outside this interface-only contract; no independent per-instance state is promised.

## Lifecycle and representative sequence

There is no dedicated initialization/shutdown API. The pre/post hooks are per-operation configuration hooks, not one-time initialization. Resolve vendor operation encoding before attempting bridge mutation.

~~~mermaid
sequenceDiagram
    participant C as Upper-stack caller
    participant H as Vendor Bridge Util HAL
    Note over C,H: Opr encoding resolved externally; success path only
    C->>H: HandlePreConfigVendor(bridgeInfo, InstanceNumber)
    H-->>C: int status
    opt Pre-configuration succeeded
        C->>H: updateBridgeInfo(bridgeInfo, ifNameToBeUpdated, Opr, type)
        H-->>C: int status
        opt Mutation succeeded
            C->>H: HandlePostConfigVendor(bridgeInfo, Config)
            H-->>C: int status
        end
    end
    C->>H: checkIfExists(iface_name)
    H-->>C: 0 or -1
    C->>H: checkIfExistsInBridge(iface_name, bridge_name)
    H-->>C: 0 or -1
~~~

The diagram illustrates successful hook use, not mandated error-path suppression, rollback, transactionality, or a complete create/bind/unbind/delete mapping. Existence/membership do not prove packet forwarding.

## Ownership, errors, concurrency, and persistence

Caller owns `bridgeDetails`, strings and writable list storage. Non-const inputs do not establish immutability, retention, or ownership transfer. Validate termination and capacity without inventing kernel limits from array size. `getVendorIfaces` ownership, reuse, release and lifetime require vendor agreement; neither freeing nor indefinite retention is justified.

Integer status exposes no distinct invalid-input, not-found, resource or vendor-error category, and no `errno` contract exists. Check status before assuming a mutation occurred. The void removal and pointer getter have no separate diagnostic return.

Thread safety is not required by retained integration policy; callers serialize access and vendors coordinate internal threads and multi-process operations. Shared globals make locking an explicit integration concern. No cross-process locking implementation, timeout, cancellation, atomic snapshot, numeric memory/CPU budget, or callback-draining protocol is declared. Private resource cleanup remains a vendor responsibility despite the absent public shutdown function.

No power-management operation or asynchronous notification is declared. Bridge mutations have stateful effects; persistence across restart/power loss and recovery after partial mutations are unspecified. The lack of a persistence requirement is not a guarantee of transient behavior.

## Integration and delivery policy

Retain Linux/Yocto support, Apache License 2.0 implementation, semantic versioning, and private-resource cleanup. Existing build guidance names `libhalbridge_utils.so`, while older linker guidance names `libbridge_utils.so`; verify deployed library identity rather than resolving the conflict by assumption.

Logging guidance permits printf/syslog and recommends `bridgeUtils.log` under `/var/tmp/` or `/rdklogs/logs/`; the actual macro constant selects `/rdklogs/logs/bridgeUtils.log`. Severity labels FATAL/TRACE require mapping to real syslog priorities; they are not native priorities. Static analysis, license/dependency review and leak analysis remain recommendations; no compiler, tests, VTS or device operations were performed for this regeneration.

## Header-reverified gap register

Stable identifiers from the preceding specification are preserved.

| ID | Unresolved contract and integration consequence |
| --- | --- |
| BU-GAP-01 | Missing `enum OVS_CMD`/numeric `Opr` mapping; do not substitute `BridgeOpr` or `BR_CMD` before mutation. |
| BU-GAP-02 | Null/empty/invalid names, termination, rejection/truncation and accepted lengths unspecified; 64-byte and 16-byte storage capacities differ. |
| BU-GAP-03 | Duplicate operations, absent bridges, attached-port deletion, retries, partial changes, rollback and failed-hook ordering unspecified. |
| BU-GAP-04 | Vendor-interface string allocation/release/lifetime/mutability/delimiter/error policy unresolved; preserve `NULL` no-interfaces meaning and old-style C declaration. |
| BU-GAP-05 | List edit input annotation conflicts with mutation; capacity/token matching/repeated entries/whitespace unresolved; absent-entry no-op explicit. |
| BU-GAP-06 | External global definitions, setup and locking absent; resolve caller/vendor and cross-process ownership. |
| BU-GAP-07 | Library names conflict: `libhalbridge_utils.so` versus `libbridge_utils.so`. |
| BU-GAP-08 | No numeric deadline, readiness predicate, dedicated init/shutdown; integration deadlines are not header requirements. |
| BU-GAP-09 | Companion MTU/VLAN ranges, type conversion and command mappings unspecified. |
| BU-GAP-10 | No forwarding/statistics/link/FDB observable; existence/membership cannot establish traffic or MAC-learning acceptance. |
| BU-GAP-11 | Logging comment promises stdout fallback absent from body; document actual behavior. |
| BU-GAP-12 | Conditional config members lack runtime capability discovery. |
| BU-GAP-13 | Memory, CPU and completion guidance qualitative, not measurable thresholds. |
| BU-GAP-14 | Logging arguments can evaluate twice; define safe argument/locking/stream ownership policy and avoid side effects. |

## Source and canonical location

The linked headers establish declarations; integration policy is not evidence of vendor/device execution. `docs/pages/BridgeUtilHalSpec.md` remains canonical, with root `README.md` preserved as a Git mode `120000` symlink.
