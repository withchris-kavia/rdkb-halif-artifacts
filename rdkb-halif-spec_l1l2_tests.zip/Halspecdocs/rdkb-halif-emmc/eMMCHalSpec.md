# eMMC HAL Specification

## Scope and evidence

[ccsp_hal_emmc.h](../../include/ccsp_hal_emmc.h) declares two eMMC information getters. It also defines storage-manager types for multiple device classes, diagnostics, and events; those types do not imply enumeration, partition-control, event-registration, or storage-write APIs.

eMMC means embedded MultiMediaCard; HAL means Hardware Abstraction Layer. Header declarations are the contract evidence, not proof of a vendor driver's implementation.

## Architecture

~~~mermaid
flowchart TD
    C["RDK-B caller"] --> H["ccsp_hal_emmc.h"]
    H --> V["Vendor eMMC information implementation"]
    V --> D["Device and health data from platform storage stack"]
~~~

## Complete API inventory

| Exact declaration | Contract |
| --- | --- |
| `eSTMGRReturns CcspHalEmmcGetHealthInfo(eSTMGRHealthInfo* pHealthInfo);` | Populate caller-owned health information. |
| `eSTMGRReturns CcspHalEmmcGetDeviceInfo(eSTMGRDeviceInfo* pDeviceInfo);` | Populate caller-owned device information. |

There is no device-ID input, initializer, deinitializer, context handle, callback-registration function, or allocator/release function.

## Complete type inventory

Fields are summarized exhaustively by declared type; see the linked header for layout and declaration order.

| Type | Fields or enum values |
| --- | --- |
| `eSTMGRReturns` | `RDK_STMGR_RETURN_SUCCESS=0`, `RDK_STMGR_RETURN_GENERIC_FAILURE=-1`, `RDK_STMGR_RETURN_INIT_FAILURE=-2`, `RDK_STMGR_RETURN_INVALID_INPUT=-3`, `RDK_STMGR_RETURN_UNKNOWN_FAILURE=-4`. Not every code is promised for every getter. |
| `eSTMGRDeviceType` | `RDK_STMGR_DEVICE_TYPE_HDD=0`, `RDK_STMGR_DEVICE_TYPE_SDCARD=1`, `RDK_STMGR_DEVICE_TYPE_USB=2`, `RDK_STMGR_DEVICE_TYPE_FLASH=3`, `RDK_STMGR_DEVICE_TYPE_NVRAM=4`, `RDK_STMGR_DEVICE_TYPE_EMMCCARD=5`, `RDK_STMGR_DEVICE_TYPE_MAX=6`. |
| `eSTMGRDeviceStatus` | `RDK_STMGR_DEVICE_STATUS_OK=0`; bit values `RDK_STMGR_DEVICE_STATUS_READ_ONLY=1<<0`, `RDK_STMGR_DEVICE_STATUS_NOT_PRESENT=1<<1`, `RDK_STMGR_DEVICE_STATUS_NOT_QUALIFIED=1<<2`, `RDK_STMGR_DEVICE_STATUS_DISK_FULL=1<<3`, `RDK_STMGR_DEVICE_STATUS_READ_FAILURE=1<<4`, `RDK_STMGR_DEVICE_STATUS_WRITE_FAILURE=1<<5`, `RDK_STMGR_DEVICE_STATUS_UNKNOWN=1<<6`. |
| `eSTMGREvents` | `RDK_STMGR_EVENT_STATUS_CHANGED=100`, `RDK_STMGR_EVENT_HEALTH_WARNING=101`, `RDK_STMGR_EVENT_DEVICE_FAILURE=102`. No delivery API is declared. |
| `eSTMGRDeviceIDs` | `unsigned short m_numOfDevices`; `char m_deviceIDs[10][128]`. |
| `eSTMGRDeviceInfo` | `char m_deviceID[128]`; `eSTMGRDeviceType m_type`; `unsigned long long m_capacity`; `eSTMGRDeviceStatus m_status`; `char m_partitions[256]`; `char[128]` fields `m_manufacturer`, `m_model`, `m_serialNumber`, `m_firmwareVersion`, `m_hwVersion`, `m_ifATAstandard`; `bool m_hasSMARTSupport`. |
| `eSTMGRDeviceInfoList` | `unsigned short m_numOfDevices`; `eSTMGRDeviceInfo m_devices[10]`. |
| `eSTMGRPartitionInfo` | `char[128]` fields `m_partitionId`, `m_name`, `m_mountPath`, `m_format`; `eSTMGRDeviceStatus m_status`; `unsigned long long m_capacity`, `m_freeSpace`; `bool m_isTSBSupported`, `m_isDVRSupported`. |
| `eSTMGRDiagAttributes` | `char m_name[128]`, `m_value[128]`. |
| `eSTMGRDiagAttributesList` | `unsigned short m_numOfAttributes`; `eSTMGRDiagAttributes m_diagnostics[20]`. |
| `eSTMGRHealthInfo` | `char m_deviceID[128]`; `eSTMGRDeviceType m_deviceType`; `bool m_isOperational`, `m_isHealthy`; union `m_diagnostics` containing `eSTMGRDiagAttributesList m_list` or `char m_blob[2048]`; diagnostic lists `m_lifetimesList`, `m_firstExceededConfiguredLife`, `m_firstExceededMaxLife`, `m_healthStatesList`. |
| `eSTMGREventMessage` | `eSTMGREvents m_eventType`; `char m_deviceID[128]`; `eSTMGRDeviceType m_deviceType`; `eSTMGRDeviceStatus m_deviceStatus`; `char m_description[128]`, `m_diagnostics[256]`. |
| `eSTMGRCallBackData` | `bool isSDCard`; `char mountPath[200]`. Despite its name this is a data struct, not a callback typedef. |

### Complete capacity constants

`RDK_STMGR_MAX_DEVICES=10`; `RDK_STMGR_MAX_STRING_LENGTH=128`; `RDK_STMGR_PARTITION_LENGTH=256`; `RDK_STMGR_DIAGNOSTICS_LENGTH=256`; `RDK_STMGR_DIAGNOSTICS_BLOB_LENGTH=2048`; `RDK_STMGR_MAX_DIAGNOSTIC_ATTRIBUTES=20`. Boolean representation comes from `<stdbool.h>`.

## Lifecycle and representative sequence

No initialization dependency or object creation is declared. The existing integration policy invokes these getters at runtime, not during system boot; that is caller scheduling policy, not an ABI-enforced precondition.

~~~mermaid
sequenceDiagram
    participant C as Caller
    participant H as Vendor HAL
    C->>H: CcspHalEmmcGetDeviceInfo(pDeviceInfo)
    H-->>C: eSTMGRReturns; device output on success
    C->>H: CcspHalEmmcGetHealthInfo(pHealthInfo)
    H-->>C: eSTMGRReturns; health output on success
~~~

Either getter may be used independently. Their separate results are not guaranteed to form an atomic snapshot.

## Ownership, errors, and operational caveats

Caller owns the output structs and embedded arrays. No returned heap allocation or public release method exists. Check the enum result before consuming output, bound counts to capacity, and validate strings before using them as NUL-terminated text.

`m_diagnostics` is a union with no explicit discriminator. Do not read both members or guess which representation is active. Diagnostic keys, blob encoding, device selection on multi-device systems, field availability, and unavailable-data sentinels require agreement.

The header declares no notification registration, power-state changes, persistence setters, locking, deadline, cancellation, or thread-safety guarantee. Existing integration policy requires serialized caller access, multi-process coordination, and vendor internal-resource cleanup. Calls may depend on storage readiness; a synchronous getter is not a nonblocking or bounded-time guarantee.

## Integration and delivery policy

Retain Linux/Yocto support, Apache License 2.0 implementation, and existing linker name `libhal_emmc`. Earlier guidance calls `libhal_emmc.so` a “static library”; `.so` denotes a shared-library convention, so artifact linkage must be resolved rather than silently asserting both.

Use timestamped syslog diagnostics routed to `emmc_vendor_hal.log`; project deployments should configure the sink. Avoid unnecessary serial-number exposure. Efficient CPU/memory usage and quality review remain requirements, but no numeric budgets are assigned. Static analysis, dependency/license review, and leak analysis remain recommended. Interface evolution follows controlled semantic versioning, not an exposed version API.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| EMMC-GAP-01 | Health diagnostics union lacks a discriminator and encoding/lifetime semantics. |
| EMMC-GAP-02 | No device selector despite generic multi-device types: define which eMMC the getters describe. |
| EMMC-GAP-03 | Define field validity, string termination, diagnostic count bounds, and outputs on failure. |
| EMMC-GAP-04 | Event enums/data exist without registration; do not promise asynchronous notification. |
| EMMC-GAP-05 | Define timing bounds, readiness behavior, snapshot consistency, and concurrency. |
| EMMC-GAP-06 | Reconcile static-library prose with `libhal_emmc.so` delivery guidance. |
