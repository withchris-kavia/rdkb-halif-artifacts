# MTA HAL Specification

## Scope and evidence

[mta_hal.h](../../include/mta_hal.h) defines Media Terminal Adapter (MTA) database initialization, DHCP information, line/DECT/call diagnostics, logs, battery information, reset/provisioning control, status queries, and line-registration notification.

DECT means Digital Enhanced Cordless Telecommunications; HAL means Hardware Abstraction Layer. This document is limited to header declarations and comments, not vendor implementation behavior. There is no general voice-call origination API, opaque instance handle, shutdown function, or generic power controller.

## Architecture

~~~mermaid
flowchart TD
    C["RDK-B MTA management caller"] --> H["mta_hal.h"]
    H --> V["Vendor MTA implementation"]
    V --> T["Telephony, DECT and provisioning services"]
    V --> B["Battery and diagnostic information"]
    V -. "Line registration callback" .-> C
~~~

These vendor service boundaries are conceptual, not additional public APIs.

## Complete API inventory

The following declarations preserve function names, argument types and argument order.

~~~c
INT mta_hal_InitDB(void);
INT mta_hal_GetDHCPInfo(PMTAMGMT_MTA_DHCP_INFO pInfo);
INT mta_hal_GetDHCPV6Info(PMTAMGMT_MTA_DHCPv6_INFO pInfo);
ULONG mta_hal_LineTableGetNumberOfEntries(void);
INT mta_hal_LineTableGetEntry(ULONG Index, PMTAMGMT_MTA_LINETABLE_INFO pEntry);
INT mta_hal_TriggerDiagnostics(ULONG Index);
INT mta_hal_GetServiceFlow(ULONG* Count, PMTAMGMT_MTA_SERVICE_FLOW *ppCfg);
INT mta_hal_DectGetEnable(BOOLEAN *pBool);
INT mta_hal_DectSetEnable(BOOLEAN bBool);
INT mta_hal_DectGetRegistrationMode(BOOLEAN* pBool);
INT mta_hal_DectSetRegistrationMode(BOOLEAN bBool);
INT mta_hal_DectDeregisterDectHandset(ULONG uValue);
INT mta_hal_GetDect(PMTAMGMT_MTA_DECT pDect);
INT mta_hal_GetDectPIN(char* pPINString);
INT mta_hal_SetDectPIN(char* pPINString);
INT mta_hal_GetHandsets(ULONG* pulCount, PMTAMGMT_MTA_HANDSETS_INFO* ppHandsets);
INT mta_hal_GetCalls(ULONG InstanceNumber, ULONG *Count, PMTAMGMT_MTA_CALLS *ppCfg);
INT mta_hal_GetCALLP(ULONG LineNumber, PMTAMGMT_MTA_CALLP pCallp);
INT mta_hal_GetDSXLogs(ULONG *Count, PMTAMGMT_MTA_DSXLOG *ppDSXLog);
INT mta_hal_GetDSXLogEnable(BOOLEAN *pBool);
INT mta_hal_SetDSXLogEnable(BOOLEAN Bool);
INT mta_hal_ClearDSXLog(BOOLEAN Bool);
INT mta_hal_GetCallSignallingLogEnable(BOOLEAN *pBool);
INT mta_hal_SetCallSignallingLogEnable(BOOLEAN Bool);
INT mta_hal_ClearCallSignallingLog(BOOLEAN Bool);
INT mta_hal_GetMtaLog(ULONG *Count, PMTAMGMT_MTA_MTALOG_FULL *ppCfg);
INT mta_hal_BatteryGetInstalled(BOOLEAN* Val);
INT mta_hal_BatteryGetTotalCapacity(ULONG* Val);
INT mta_hal_BatteryGetActualCapacity(ULONG* Val);
INT mta_hal_BatteryGetRemainingCharge(ULONG* Val);
INT mta_hal_BatteryGetRemainingTime(ULONG* Val);
INT mta_hal_BatteryGetNumberofCycles(ULONG* Val);
INT mta_hal_BatteryGetPowerStatus(CHAR *Val, ULONG *len);
INT mta_hal_BatteryGetCondition(CHAR *Val, ULONG *len);
INT mta_hal_BatteryGetStatus(CHAR* Val, ULONG *len);
INT mta_hal_BatteryGetLife(CHAR* Val, ULONG *len);
INT mta_hal_BatteryGetInfo(PMTAMGMT_MTA_BATTERY_INFO pInfo);
INT mta_hal_BatteryGetPowerSavingModeStatus(ULONG *pValue);
INT mta_hal_Get_MTAResetCount(ULONG *resetcnt);
INT mta_hal_Get_LineResetCount(ULONG *resetcnt);
INT mta_hal_ClearCalls(ULONG InstanceNumber);
INT mta_hal_getDhcpStatus(MTAMGMT_MTA_STATUS *output_pIpv4status, MTAMGMT_MTA_STATUS *output_pIpv6status);
INT mta_hal_getConfigFileStatus(MTAMGMT_MTA_STATUS *poutput_status);
INT mta_hal_getLineRegisterStatus(MTAMGMT_MTA_STATUS *output_status_array, int array_size);
INT mta_hal_devResetNow(BOOLEAN bResetValue);
INT mta_hal_getMtaOperationalStatus(MTAMGMT_MTA_STATUS *operationalStatus);
INT mta_hal_getMtaProvisioningStatus(MTAMGMT_MTA_PROVISION_STATUS *provisionStatus);
INT mta_hal_start_provisioning(PMTAMGMT_MTA_PROVISIONING_PARAMS pParameters);
void mta_hal_LineRegisterStatus_callback_register(mta_hal_getLineRegisterStatus_callback callback_proc);
~~~

### Behavior and result interpretation

| Group | Contract/caveat |
| --- | --- |
| Initialization and DHCP | Initialize database, then retrieve IPv4/IPv6 configuration as needed. No deinitializer is declared. |
| Lines/diagnostics | Entry count is returned directly as `ULONG`; it is not a generic status. Query entries with `Index`, diagnostics with `Index`, calls with `InstanceNumber`, and CALLP with `LineNumber`; do not silently equate these identifiers. |
| Service flows and lists | Count/double-pointer interfaces return service flows, handsets, calls and logs. Count direction, allocation and release must be agreed per function. |
| DECT | Enable, registration mode, deregister a handset, retrieve DECT details, get/set PIN. PIN comments specify 128-byte buffers, while the struct's PIN field is 64 bytes. |
| Logs | Retrieve or clear DSX/call-signalling/MTA logs and enable/disable relevant logging. Clear operations are not getters and can destroy evidence. |
| Battery | Presence, total/actual capacity, remaining charge/time, cycles, strings, hardware info and power-saving status. Comments describe remaining time in minutes; capacity units use the ambiguous spelling “mAVHour”. Power-saving status uses `1=enabled`, `2=disabled`, not a Boolean convention. |
| Reset/provisioning | Read counters, reset device, start provisioning, and observe DHCP/config/registration/operational/provisioning status. An accepted provisioning request does not prove completion. |
| Callback | Registration returns `void`, not a status. Callback and polling both expose line-registration status. |

Most `INT` operation comments specify `RETURN_OK=0` and `RETURN_ERR=-1`. The direct count and `void` registration are exceptions. `LineTableGetNumberOfEntries` comments mix generic status wording with the count signature; consumers must resolve the contradiction, not cast a count to status.

## Complete enum and callback inventory

| Type | Values |
| --- | --- |
| `MTAMGMT_MTA_STATUS` | `MTA_INIT=0`, `MTA_START=1`, `MTA_COMPLETE=2`, `MTA_ERROR=3`, `MTA_REJECTED=4`. |
| `MTAMGMT_MTA_PROVISION_STATUS` | `MTA_PROVISIONED=0` (valid IP), `MTA_NON_PROVISIONED=1` (IP `0.0.0.0` in comments). |
| `MTAMGMT_MTA_PROV_IP_MODE` | `MTA_IPV4=0`, `MTA_IPV6=1`, `MTA_DUAL_STACK=2`. |
| `mta_hal_getLineRegisterStatus_callback` | `typedef INT (*mta_hal_getLineRegisterStatus_callback)(MTAMGMT_MTA_STATUS *output_status_array, int array_size);` |

These enums do not define a complete finite-state machine or mandatory callback transition order.

## Complete struct inventory

Every struct has a pointer alias. For the first eleven rows it is the struct name prefixed with `P`; the final row explicitly lists its differently named pointer alias.

| Type | Fields |
| --- | --- |
| `MTAMGMT_MTA_DECT` | `ULONG RegisterDectHandset`, `DeregisterDectHandset`; `char HardwareVersion[64]`, `RFPI[64]`, `SoftwareVersion[64]`, `PIN[64]`. |
| `MTAMGMT_MTA_HANDSETS_INFO` | `ULONG InstanceNumber`; `BOOLEAN Status`; `char LastActiveTime[64]`, `HandsetName[64]`, `HandsetFirmware[64]`, `OperatingTN[64]`, `SupportedTN[64]`. |
| `MTAMGMT_MTA_DHCP_INFO` | `ANSC_IPV4_ADDRESS IPAddress`, `SubnetMask`, `Gateway`, `PrimaryDNS`, `SecondaryDNS`, `PrimaryDHCPServer`, `SecondaryDHCPServer`; `CHAR BootFileName[256]`; `ULONG LeaseTimeRemaining`; `CHAR[64]` fields `FQDN`, `RebindTimeRemaining`, `RenewTimeRemaining`, `DHCPOption3`, `DHCPOption6`, `DHCPOption7`, `DHCPOption8`, `PCVersion`, `MACAddress`. |
| `MTAMGMT_MTA_DHCPv6_INFO` | `CHAR[INET6_ADDRSTRLEN]` fields `IPV6Address`, `Prefix`, `Gateway`, `PrimaryDNS`, `SecondaryDNS`, `PrimaryDHCPv6Server`, `SecondaryDHCPv6Server`; `CHAR BootFileName[256]`; `ULONG LeaseTimeRemaining`; `CHAR[64]` fields `FQDN`, `RebindTimeRemaining`, `RenewTimeRemaining`, `DHCPOption3`, `DHCPOption6`, `DHCPOption7`, `DHCPOption8`, `PCVersion`, `MACAddress`. |
| `MTAMGMT_MTA_SERVICE_FLOW` | `ULONG SFID`, `ScheduleType`, `NomGrantInterval`, `UnsolicitGrantSize`, `TolGrantJitter`, `NomPollInterval`, `MinReservedPkt`, `MaxTrafficRate`, `MinReservedRate`, `MaxTrafficBurst`, `NumberOfPackets`; `CHAR ServiceClassName[256]`, `Direction[16]`, `TrafficType[64]`; `BOOLEAN DefaultFlow`. |
| `MTAMGMT_MTA_CALLS` | Complete field inventory follows below. |
| `MTAMGMT_MTA_LINETABLE_INFO` | `ULONG InstanceNumber`, `LineNumber`, `Status`, `CAPort`, `MWD`, `CallsNumber`, `CallsUpdateTime`, `OverCurrentFault`; `CHAR HazardousPotential[128]`, `ForeignEMF[128]`, `ResistiveFaults[128]`, `ReceiverOffHook[128]`, `RingerEquivalency[64]`, `CAName[64]`; `PMTAMGMT_MTA_CALLS pCalls`. |
| `MTAMGMT_MTA_CALLP` | `CHAR LCState[64]`, `CallPState[64]`, `LoopCurrent[64]`. |
| `MTAMGMT_MTA_DSXLOG` | `CHAR Time[64]`, `Description[128]`; `ULONG ID`, `Level`. |
| `MTAMGMT_MTA_MTALOG_FULL` | `ULONG Index`, `EventID`; `CHAR EventLevel[64]`, `Time[64]`; `CHAR *pDescription`. |
| `MTAMGMT_MTA_BATTERY_INFO` | `CHAR ModelNumber[32]`, `SerialNumber[32]`, `PartNumber[32]`, `ChargerFirmwareRevision[32]`. |
| `MTAMGMT_PROVISIONING_PARAMS`, `PMTAMGMT_MTA_PROVISIONING_PARAMS` | `INT MtaIPMode`, `DhcpOption2171CccV6DssID1Len`, `DhcpOption2171CccV6DssID2Len`; `CHAR DhcpOption122Suboption1[5]`, `DhcpOption122Suboption2[5]`, `DhcpOption2171CccV6DssID1[33]`, `DhcpOption2171CccV6DssID2[33]`. |

### Complete `MTAMGMT_MTA_CALLS` field inventory

- `CHAR[64]`: `Codec`, `RemoteCodec`, `CallStartTime`, `CallEndTime`.
- `BOOLEAN`: `JitterBufferAdaptive`, `Originator`, `RemoteJitterBufferAdaptive`.
- `ANSC_IPV4_ADDRESS RemoteIPAddress`; `ULONG CallDuration`.
- Every remaining field is `CHAR[MTA_HAL_SHORT_VALUE_LEN]`: `CWErrorRate`, `PktLossConcealment`, `CWErrors`, `SNR`, `MicroReflections`, `DownstreamPower`, `UpstreamPower`, `EQIAverage`, `EQIMinimum`, `EQIMaximum`, `EQIInstantaneous`, `MOS_LQ`, `MOS_CQ`, `EchoReturnLoss`, `SignalLevel`, `NoiseLevel`, `LossRate`, `DiscardRate`, `BurstDensity`, `GapDensity`, `BurstDuration`, `GapDuration`, `RoundTripDelay`, `Gmin`, `RFactor`, `ExternalRFactor`, `JitterBufRate`, `JBNominalDelay`, `JBMaxDelay`, `JBAbsMaxDelay`, `TxPackets`, `TxOctets`, `RxPackets`, `RxOctets`, `PacketLoss`, `IntervalJitter`, `RemoteIntervalJitter`, `RemoteMOS_LQ`, `RemoteMOS_CQ`, `RemoteEchoReturnLoss`, `RemoteSignalLevel`, `RemoteNoiseLevel`, `RemoteLossRate`, `RemotePktLossConcealment`, `RemoteDiscardRate`, `RemoteBurstDensity`, `RemoteGapDensity`, `RemoteBurstDuration`, `RemoteGapDuration`, `RemoteRoundTripDelay`, `RemoteGmin`, `RemoteRFactor`, `RemoteExternalRFactor`, `RemoteJitterBufRate`, `RemoteJBNominalDelay`, `RemoteJBMaxDelay`, `RemoteJBAbsMaxDelay`.

These diagnostic strings must not be treated as native binary counters or assigned units from their names alone.

## Complete macro and scalar inventory

Conditional aliases: `ULONG=unsigned long`, `CHAR=char`, `UCHAR=unsigned char`, `BOOLEAN=UCHAR`, `INT=int`; `TRUE=1`, `FALSE=0`, `ENABLE=1`, `RETURN_OK=0`, `RETURN_ERR=-1`. `ULONG` width is platform-dependent.

`IPV4_ADDRESS_SIZE=4`; `MTA_HAL_SHORT_VALUE_LEN=16`; `MTA_HAL_LONG_VALUE_LEN=64`; `DECT_MAX_HANDSETS=5`; `MTA_LINENUMBER=8`; `MTA_DHCPOPTION122SUBOPTION1_MAX=4`; `MTA_DHCPOPTION122SUBOPTION2_MAX=4`; `MTA_DHCPOPTION122CCCV6DSSID1_MAX=32`; `MTA_DHCPOPTION122CCCV6DSSID2_MAX=32`.

`ANSC_IPV4_ADDRESS` is a macro expanding to a union of `unsigned char Dot[IPV4_ADDRESS_SIZE]` and `uint32_t Value`. General union byte order is not stated; provisioning comments explicitly describe option-122 suboption-1 address octets in network order. No public variables are declared.

## Lifecycle and representative sequence

Initialize, retrieve/count entries as needed, and explicitly request provisioning or destructive actions only under caller policy. The following shows observation, not a prescribed provisioning state machine.

~~~mermaid
sequenceDiagram
    participant C as MTA caller
    participant H as Vendor HAL
    C->>H: mta_hal_InitDB()
    H-->>C: INT status
    C->>H: mta_hal_LineRegisterStatus_callback_register(callback_proc)
    Note over C,H: Registration returns void
    C->>H: mta_hal_getLineRegisterStatus(output_status_array, array_size)
    H-->>C: INT status; array on success
    opt Line-registration notification
        H-->>C: callback_proc(output_status_array, array_size)
    end
    C->>H: mta_hal_getMtaProvisioningStatus(provisionStatus)
    H-->>C: INT status; provisioning state on success
~~~

There is no callback unregister/drain function. Do not unload callback code or destroy its state while notifications may still occur.

## Ownership, errors, timing, and concurrency

Caller owns ordinary output structs, status arrays, input provisioning data, and string buffers. Returned list pointers and nested pointers (`pCalls`, `pDescription`) lack a complete allocation/release/validity contract. No public free routine exists; do not assume that caller `free()`, static storage, or deep-copy retention is safe.

Battery string length parameters have inconsistent direction descriptions. Resolve capacity-in versus length-out, truncation and NUL termination before use. `GetHandsets` labels its count as input while other list functions use output-style counts; do not normalize them without agreement.

Registration callbacks take an array and size; pointer retention, ownership, dispatch thread, return handling, serialization, replacement, and shutdown quiescence are unspecified. Copy needed data only within an agreed valid lifetime and avoid reentering the HAL from callbacks unless supported.

No general thread-safety, cross-process exclusion, deadline, cancellation, or atomic snapshot guarantee is declared. Existing integration policy requires serialized calls, vendor multi-process protection and cleanup of internal resources. Blocking must be bounded by a separately agreed vendor policy, not invented milliseconds.

Battery and power-saving status are observable; no corresponding general power-mode setter exists here. DECT settings, log clearing, reset and provisioning can change device state, so persistence and reset effects cannot be summarized as universally absent.

## Integration and delivery policy

Retain Linux/Yocto support, shared library `libhal_mta.so`, Apache License 2.0 implementation, and controlled semantic versioning. Numeric CPU, memory and deadline budgets remain unspecified. Vendors own private memory/thread/descriptor cleanup.

Use timestamped syslog diagnostics routed to `mta_vendor_hal.log` under `/var/tmp/` or `/rdklogs/logs/`; map FATAL/TRACE labels to real priorities. Do not log DECT PINs or unnecessary telephone/subscriber identifiers. Static analysis, dependency/license review, and leak analysis remain recommended. No tests, compiler work, or MTA device operations were performed for this document.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| MTA-GAP-01 | Resolve count versus generic-status wording for `LineTableGetNumberOfEntries`. |
| MTA-GAP-02 | Specify list allocation/release, count direction, nested pointer ownership and validity. |
| MTA-GAP-03 | Reconcile 128-byte DECT PIN API comments with the 64-byte struct field and define secret handling. |
| MTA-GAP-04 | Define battery string `len` direction, truncation, capacity/charge units and unavailable sentinels. |
| MTA-GAP-05 | No unregister/drain: define callback threading, replacement, lifetime, return semantics and shutdown. |
| MTA-GAP-06 | Define line index/instance/number domains and count-query races. |
| MTA-GAP-07 | Enum vocabularies are not a complete provisioning transition/error model; clarify readiness and durable effects. |
| MTA-GAP-08 | Define timing, concurrency, failure-output validity, counter widths/rollover and byte order. |
