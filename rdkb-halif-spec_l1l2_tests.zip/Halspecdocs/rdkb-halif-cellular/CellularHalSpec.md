# Cellular HAL Specification

## Scope and evidence

[cellular_hal.h](../../include/cellular_hal.h) defines a global cellular modem interface: detection/opening, UICC slot selection and power, registration monitoring, profile management, network start/stop, radio and identity queries, statistics, and modem operating configuration/reset. HAL means Hardware Abstraction Layer; UICC means Universal Integrated Circuit Card; PDP means Packet Data Protocol; PLMN means Public Land Mobile Network.

This document describes the declarations and their comments, not a tested vendor implementation. It does not add a context handle, deinitializer, callback-unregister function, standalone PIN/PUK/SMS API, or eSIM profile-download operation. eSIM download belongs to a separate LPA contract.

## Architecture

~~~mermaid
flowchart TD
    C["Cellular management caller"] --> H["cellular_hal.h"]
    H --> V["Vendor modem implementation"]
    V --> M["Modem, UICC and packet-network services"]
    V -. "Declared status and IP callbacks" .-> C
~~~

The transport and vendor modules are conceptual. The header defines `QMI_SUPPORT` unless `CELLULAR_MGR_LITE` is defined; this is a compile-time selection, not runtime capability discovery.

## Complete API inventory

Declarations are listed with exact argument types and names. Except for the two predicate functions identified below, return type is `int`.

~~~c
unsigned int cellular_hal_IsModemDevicePresent(void);
int cellular_hal_init(CellularContextInitInputStruct *pstCtxInputStruct);
int cellular_hal_open_device(CellularDeviceContextCBStruct *pstDeviceCtxCB);
unsigned char cellular_hal_IsModemControlInterfaceOpened(void);
int cellular_hal_select_device_slot(cellular_device_slot_status_api_callback device_slot_status_cb);
int cellular_hal_sim_power_enable(unsigned int slot_id, unsigned char enable);
int cellular_hal_get_total_no_of_uicc_slots(unsigned int *total_count);
int cellular_hal_get_uicc_slot_info(unsigned int slot_index, CellularUICCSlotInfoStruct *pstSlotInfo);
int cellular_hal_get_active_card_status(CellularUICCStatus_t *card_status);
int cellular_hal_monitor_device_registration(cellular_device_registration_status_callback device_registration_status_cb);
int cellular_hal_profile_create(CellularProfileStruct *pstProfileInput, cellular_device_profile_status_api_callback device_profile_status_cb);
int cellular_hal_profile_delete(CellularProfileStruct *pstProfileInput, cellular_device_profile_status_api_callback device_profile_status_cb);
int cellular_hal_profile_modify(CellularProfileStruct *pstProfileInput, cellular_device_profile_status_api_callback device_profile_status_cb);
int cellular_hal_get_profile_list(CellularProfileStruct **ppstProfileOutput, int *profile_count);
int cellular_hal_start_network(CellularNetworkIPType_t ip_request_type, CellularProfileStruct *pstProfileInput, CellularNetworkCBStruct *pstCBStruct);
int cellular_hal_stop_network(CellularNetworkIPType_t ip_request_type);
int cellular_hal_get_signal_info(CellularSignalInfoStruct *signal_info);
int cellular_hal_get_cell_location_info(CellLocationInfoStruct *loc_info);
int cellular_hal_set_modem_operating_configuration(CellularModemOperatingConfiguration_t modem_operating_config);
int cellular_hal_get_device_imei(char *imei);
int cellular_hal_get_device_imei_sv(char *imei_sv);
int cellular_hal_get_modem_current_iccid(char *iccid);
int cellular_hal_get_modem_current_msisdn(char *msisdn);
int cellular_hal_get_packet_statistics(CellularPacketStatsStruct *network_packet_stats);
int cellular_hal_get_current_modem_interface_status(CellularInterfaceStatus_t *status);
int cellular_hal_set_modem_network_attach(void);
int cellular_hal_set_modem_network_detach(void);
int cellular_hal_get_modem_firmware_version(char *firmware_version);
int cellular_hal_get_current_plmn_information(CellularCurrentPlmnInfoStruct *plmn_info);
int cellular_hal_get_available_networks_information(CellularNetworkScanResultInfoStruct **network_info, unsigned int *total_network_count);
int cellular_hal_get_modem_preferred_radio_technology(char *preferred_rat);
int cellular_hal_set_modem_preferred_radio_technology(char *preferred_rat);
int cellular_hal_get_modem_current_radio_technology(char *current_rat);
int cellular_hal_get_modem_supported_radio_technology(char *supported_rat);
int cellular_hal_modem_factory_reset(void);
int cellular_hal_modem_reset(void);
~~~

### API behavior groups

| Group | Contract and limits |
| --- | --- |
| Presence/control predicates | Return presence/opened indications, not the generic operation-status convention. Check each documented predicate meaning. |
| Initialization/open | Supply initialization preferences and callback bundle. Opening status is reported through the declared callback; a successful request is not equivalent to device readiness. |
| UICC | Retrieve slot count before indexing slots, select a device slot through callback reporting, query active card status, or enable/disable SIM power for `slot_id`. Index base and hotplug stability require agreement. |
| Registration | Monitor NAS registration, roaming and registered service through callback. Attach/detach requests are distinct from observed registration. |
| Profiles | Create/modify/delete using `CellularProfileStruct` and profile callback; enumerate through double pointer and count. Do not infer transactional or persistent semantics. |
| Network | Start using requested IP family, profile and callbacks; stop by IP family. Packet-service and IP-ready notifications are distinct observations. |
| Telemetry | Signal, cell location, packet counters, interface status, current PLMN and available networks. Snapshot consistency across calls is not declared. |
| Identity/radio | IMEI, IMEI-SV, ICCID, MSISDN, firmware and radio-technology strings; setters accept preferred RAT text rather than the preference enum used in initialization. |
| Disruptive control | Operating configuration includes online/offline/low-power/reset/factory-reset; standalone reset/factory-reset are also declared. Do not automatically invoke destructive operations on errors. |

## Complete enum inventory

Values in each row proceed consecutively from the stated first value unless shown otherwise. Every member is listed; these are vocabularies, not a normative transition matrix.

| Type | Members in declaration order |
| --- | --- |
| `CellularInterfaceStatus_t` | `IF_UP=1`, `IF_DOWN`, `IF_UNKNOWN`, `IF_DORMANT`, `IF_NOTPRESENT`, `IF_LOWERLAYERDOWN`, `IF_ERROR`. |
| `CellularIpFamilyPref_t` | `IP_FAMILY_UNKNOWN=1`, `IP_FAMILY_IPV4`, `IP_FAMILY_IPV6`, `IP_FAMILY_IPV4_IPV6`. |
| `CellularPrefAccessTechnology_t` | `PREF_GPRS=1`, `PREF_EDGE`, `PREF_UMTS`, `PREF_UMTSHSPA`, `PREF_CDMA2000OneX`, `PREF_CDMA2000HRPD`, `PREF_LTE`, `PREF_NR`. |
| `CellularPDPType_t` | `CELLULAR_PDP_TYPE_IPV4=0`, `CELLULAR_PDP_TYPE_PPP`, `CELLULAR_PDP_TYPE_IPV6`, `CELLULAR_PDP_TYPE_IPV4_OR_IPV6`. |
| `CellularPDPAuthentication_t` | `CELLULAR_PDP_AUTHENTICATION_NONE=0`, `CELLULAR_PDP_AUTHENTICATION_PAP`, `CELLULAR_PDP_AUTHENTICATION_CHAP`. |
| `CellularProfileType_t` | `CELLULAR_PROFILE_TYPE_3GPP=0`, `CELLULAR_PROFILE_TYPE_3GPP2`. |
| `CellularPDPNetworkConfig_t` | `CELLULAR_PDP_NETWORK_CONFIG_NAS=1`, `CELLULAR_PDP_NETWORK_CONFIG_DHCP`. |
| `CellularModemOperatingConfiguration_t` | `CELLULAR_MODEM_SET_ONLINE=1`, `CELLULAR_MODEM_SET_OFFLINE`, `CELLULAR_MODEM_SET_LOW_POWER_MODE`, `CELLULAR_MODEM_SET_RESET`, `CELLULAR_MODEM_SET_FACTORY_RESET`. |
| `CellularModemRegisteredServiceType_t` | `CELLULAR_MODEM_REGISTERED_SERVICE_NONE=0`, `CELLULAR_MODEM_REGISTERED_SERVICE_PS`, `CELLULAR_MODEM_REGISTERED_SERVICE_CS`, `CELLULAR_MODEM_REGISTERED_SERVICE_CS_PS`. |
| `CellularRegistrationStatus_t` | `DEVICE_REGISTERED=1`, `DEVICE_NOT_REGISTERED`. |
| `CellularNetworkIPType_t` | `CELLULAR_NETWORK_IP_FAMILY_UNKNOWN=0`, `CELLULAR_NETWORK_IP_FAMILY_IPV4`, `CELLULAR_NETWORK_IP_FAMILY_IPV6`, `CELLULAR_NETWORK_IP_FAMILY_UNSPECIFIED`. Distinct from initialization IP-family enum. |
| `CellularUICCFormFactor_t` | `CELLULAR_UICC_FORM_FACTOR_1FF=0`, `CELLULAR_UICC_FORM_FACTOR_2FF`, `CELLULAR_UICC_FORM_FACTOR_3FF`, `CELLULAR_UICC_FORM_FACTOR_4FF`. |
| `CellularUICCStatus_t` | `CELLULAR_UICC_STATUS_VALID=0`, `CELLULAR_UICC_STATUS_BLOCKED`, `CELLULAR_UICC_STATUS_ERROR`, `CELLULAR_UICC_STATUS_EMPTY`. |
| `CellularUICCApplication_t` | `CELLULAR_UICC_APPLICATION_USIM=0`, `CELLULAR_UICC_APPLICATION_ISIM`, `CELLULAR_UICC_APPLICATION_ESIM`. |
| `CellularDeviceDetectionStatus_t` | `DEVICE_DETECTED=1`, `DEVICE_REMOVED`. |
| `CellularDeviceOpenStatus_t` | `DEVICE_OPEN_STATUS_NOT_READY=1`, `DEVICE_OPEN_STATUS_INPROGRESS`, `DEVICE_OPEN_STATUS_READY`. |
| `CellularDeviceSlotStatus_t` | `DEVICE_SLOT_STATUS_NOT_READY=1`, `DEVICE_SLOT_STATUS_SELECTING`, `DEVICE_SLOT_STATUS_READY`. |
| `CellularDeviceNASStatus_t` | `DEVICE_NAS_STATUS_NOT_REGISTERED=1`, `DEVICE_NAS_STATUS_REGISTERING`, `DEVICE_NAS_STATUS_REGISTERED`. |
| `CellularDeviceNASRoamingStatus_t` | `DEVICE_NAS_STATUS_ROAMING_OFF=1`, `DEVICE_NAS_STATUS_ROAMING_ON`. |
| `CellularContextProfileStatus_t` | `PROFILE_STATUS_INACTIVE=1`, `PROFILE_STATUS_ACTIVE`. |
| `CellularDeviceProfileSelectionStatus_t` | `DEVICE_PROFILE_STATUS_NOT_READY=1`, `DEVICE_PROFILE_STATUS_CONFIGURING`, `DEVICE_PROFILE_STATUS_READY`, `DEVICE_PROFILE_STATUS_DELETED`. |
| `CellularDeviceIPReadyStatus_t` | `DEVICE_NETWORK_IP_NOT_READY=1`, `DEVICE_NETWORK_IP_READY`. |
| `CellularNetworkPacketStatus_t` | `DEVICE_NETWORK_STATUS_DISCONNECTED=1`, `DEVICE_NETWORK_STATUS_CONNECTED`. |

## Complete struct inventory

| Type | Fields |
| --- | --- |
| `CellularProfileStruct` | `int ProfileID`, `PDPContextNumber`; enums `ProfileType`, `PDPType`, `PDPAuthentication`, `PDPNetworkConfig`; `char ProfileName[64]`, `APN[64]`, `Username[256]`, `Password[256]`, `Proxy[45]`; `unsigned int ProxyPort`; `unsigned char bIsNoRoaming`, `bIsAPNDisabled`, `bIsThisDefaultProfile`. |
| `CellularContextInitInputStruct` | `CellularIpFamilyPref_t enIPFamilyPreference`; `CellularProfileStruct stIfInput`; `CellularPrefAccessTechnology_t enPreferenceTechnology`. |
| `CellularIPStruct` | `char WANIFName[16]`, `IPAddress[128]`; `CellularNetworkIPType_t IPType`; `char SubnetMask[128]`, `DefaultGateWay[128]`, `DNSServer1[128]`, `DNSServer2[128]`, `Domains[256]`; `unsigned int MTUSize`. |
| `CellularPacketStatsStruct` | `unsigned long` fields `BytesSent`, `BytesReceived`, `PacketsSent`, `PacketsReceived`, `PacketsSentDrop`, `PacketsReceivedDrop`, `UpStreamMaxBitRate`, `DownStreamMaxBitRate`. Width is ABI-dependent. |
| `CellularUICCSlotInfoStruct` | `unsigned char SlotEnable`, `IsCardPresent`, `CardEnable`; enums `FormFactor`, `Application`, `Status`; `char MnoName[32]`, `iccid[20]`, `msisdn[20]`. |
| `CellularSignalInfoStruct` | `int RSSI`, `RSRQ`, `RSRP`, `SNR`, `TXPower`. Confirm units/scaling and unavailable sentinels before numerical comparisons. |
| `CellLocationInfoStruct` | `unsigned int globalCellId`, `bandInfo`, `servingCellId`. |
| `CellularCurrentPlmnInfoStruct` | `char plmn_name[32]`; `unsigned int MCC`, `MNC`; `CellularRegistrationStatus_t registration_status`; `CellularModemRegisteredServiceType_t registered_service`; `unsigned char roaming_enabled`; `unsigned int area_code`; `unsigned long cell_id`. |
| `CellularNetworkScanResultInfoStruct` | `char network_name[32]`; `unsigned int MCC`, `MNC`; `unsigned char network_allowed_flag`. |
| `CellularDeviceContextCBStruct` | `cellular_device_open_status_api_callback device_open_status_cb`; `cellular_device_removed_status_api_callback device_remove_status_cb`. |
| `CellularNetworkCBStruct` | `cellular_device_network_ip_ready_api_callback device_network_ip_ready_cb`; `cellular_network_packet_service_status_api_callback packet_service_status_cb`. |

### Complete callback inventory

~~~c
typedef int (*cellular_device_open_status_api_callback)(char *device_name, char *wan_ifname, CellularDeviceOpenStatus_t device_open_status, CellularModemOperatingConfiguration_t modem_operating_mode);
typedef int (*cellular_device_removed_status_api_callback)(char *device_name, CellularDeviceDetectionStatus_t device_detection_status);
typedef int (*cellular_device_slot_status_api_callback)(char *slot_name, char *slot_type, int slot_num, CellularDeviceSlotStatus_t device_slot_status);
typedef int (*cellular_device_registration_status_callback)(CellularDeviceNASStatus_t device_registration_status, CellularDeviceNASRoamingStatus_t roaming_status, CellularModemRegisteredServiceType_t registered_service);
typedef int (*cellular_device_profile_status_api_callback)(char *profile_id, CellularPDPType_t PDPType, CellularDeviceProfileSelectionStatus_t device_profile_status);
typedef int (*cellular_network_packet_service_status_api_callback)(char *device_name, CellularNetworkIPType_t ip_type, CellularNetworkPacketStatus_t packet_service_status);
typedef int (*cellular_device_network_ip_ready_api_callback)(CellularIPStruct *pstIPStruct, CellularDeviceIPReadyStatus_t ip_ready_status);
~~~

### Complete public constants

`RETURN_ERROR=-1`, `RETURN_OK=0`; conditional `TRUE=1`, `FALSE=0`; conditional `BUFLEN_8=8`, `BUFLEN_32=32`, `BUFLEN_64=64`, `BUFLEN_128=128`, `BUFLEN_256=256`. Unknown identifiers: `CELLULAR_PROFILE_ID_UNKNOWN=-1`, `CELLULAR_SLOT_ID_UNKNOWN=-1`, `CELLULAR_PDP_CONTEXT_UNKNOWN=-1`; `CELLULAR_PACKET_DATA_INVALID_HANDLE=0xFFFFFFFF`. The last constant does not create a handle-return API. No public variables are declared.

## Lifecycle and representative sequence

Use initialization input, then open the device with callbacks. Observe readiness rather than assuming request return equals completion. Slot, registration, profile and network operations depend on device state; the diagram is a representative integration path, not a complete mandated transition matrix.

~~~mermaid
sequenceDiagram
    participant C as Cellular caller
    participant H as Vendor HAL
    C->>H: cellular_hal_init(pstCtxInputStruct)
    H-->>C: int status
    C->>H: cellular_hal_open_device(pstDeviceCtxCB)
    H-->>C: int request status
    H-->>C: device_open_status_cb(device_name, wan_ifname, device_open_status, modem_operating_mode)
    Note over C: Continue only when readiness and call status allow
    C->>H: cellular_hal_select_device_slot(device_slot_status_cb)
    H-->>C: int request status
    H-->>C: device_slot_status_cb(slot_name, slot_type, slot_num, device_slot_status)
    C->>H: cellular_hal_monitor_device_registration(device_registration_status_cb)
    H-->>C: int request status
    H-->>C: device_registration_status_cb(device_registration_status, roaming_status, registered_service)
    opt Usable profile and registration available
        C->>H: cellular_hal_start_network(ip_request_type, pstProfileInput, pstCBStruct)
        H-->>C: int request status
        H-->>C: device_network_ip_ready_cb(pstIPStruct, ip_ready_status)
        C->>H: cellular_hal_stop_network(ip_request_type)
        H-->>C: int status
    end
~~~

Callbacks may occur during or after calls; the diagram does not guarantee dispatch order, thread identity, or one callback per request. Packet-service callbacks may also be delivered. No declared close/deinit entry point completes a global shutdown lifecycle.

## Ownership, errors, concurrency, and persistence

- Ordinary getter structs and input buffers are caller-owned. Callback bundles must remain valid for the vendor-agreed registration lifetime; neither stack retention nor copy-on-register should be assumed.
- Profile/network enumeration uses double pointers. Resolve documented allocation responsibilities, allocator compatibility, release procedure, and count bounds with the vendor; no public list-release function exists. Do not infer ownership solely from pointer depth.
- Callback strings and IP structs have no general retention guarantee. Copy needed data before the callback returns unless the vendor explicitly guarantees a longer lifetime. Do not free callback data.
- Lengthless identity and RAT getters require correctly sized writable buffers. Fixed array capacity is not automatically a maximum valid string length; in particular, 20-byte ICCID/MSISDN arrays need explicit termination handling.
- Most operations use `RETURN_OK/RETURN_ERROR`; the two presence/open predicates return indications instead. Status acceptance, callback completion, registered state, packet connection and IP readiness are separate concepts. Partial outputs and detailed error recovery are not uniformly specified.
- Thread safety, callback reentrancy/dispatch, registration replacement, cross-process ownership, and teardown draining are incomplete. Retained integration policy is caller serialization plus vendor protection across processes; never hold a caller lock across a call if an inline callback needs that lock.
- No universal deadline, cancellation, or retry policy exists. Modem low-power mode and SIM power are real declared capabilities, but not a general platform power manager.
- Profile and preferred-RAT changes may affect modem configuration. Durability, rollback, and reset/factory-reset scope require explicit vendor agreement rather than a blanket no-persistence assertion.

## Integration and delivery policy

Retain Linux/Yocto support, Apache License 2.0 implementation, existing delivery guidance `cellularmanager.so`, and controlled semantic versioning. Vendors clean up private resources; numeric CPU/memory/deadline budgets remain unresolved.

Use timestamped syslog diagnostics routed to `cellular_vendor_hal.log` under `/var/tmp/` or `/rdklogs/logs/`. Map FATAL/TRACE labels to actual priorities. Never log profile passwords or credentials; minimize IMEI, ICCID and MSISDN exposure. Static analysis, dependency/license review, and leak analysis remain recommended; no device or test execution was used for this regeneration.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| CELL-GAP-01 | No close/deinit/unregister API: define callback lifetime, replacement, removal and safe shutdown. |
| CELL-GAP-02 | Define callback dispatch, inline invocation, return handling, reentrancy, ordering and drain semantics. |
| CELL-GAP-03 | Double-pointer enumeration has no public release entry point: reconcile allocation/release/count policies per function. |
| CELL-GAP-04 | Define all lengthless getter bounds, termination and failed-call outputs; reconcile 20-byte card identifiers with string use. |
| CELL-GAP-05 | Define slot index base, hotplug races and stable profile identity across modifications/reset. |
| CELL-GAP-06 | Enum vocabularies do not give a complete legal-transition table or sequencing/error matrix. |
| CELL-GAP-07 | Specify telemetry units/sentinels, counter rollover and `unsigned long` ABI widths. |
| CELL-GAP-08 | Define deadlines, cancellation, concurrency, multi-process coordination and persistence. |
| CELL-GAP-09 | `QMI_SUPPORT`/`CELLULAR_MGR_LITE` selects compile-time configuration, not runtime modem capabilities. |
