# Firmware Management HAL Specification

## Scope and evidence

[fwupgrade_hal.h](../../include/fwupgrade_hal.h) declares configuration of download URL/filename/interface, download/install operations, status polling, reboot readiness, reboot, and update with factory reset. HAL means Hardware Abstraction Layer; CPE means Customer Premises Equipment.

The header describes image validation within download processing but exposes no standalone signature-verification, checksum, rollback, cancellation, or bank-selection API. No particular authentication algorithm, atomic upgrade guarantee, or automatic retry policy is declared.

## Architecture

~~~mermaid
flowchart TD
    C["Upgrade caller and authorization policy"] --> H["fwupgrade_hal.h"]
    H --> V["Vendor upgrade implementation"]
    V --> N["Download transport"]
    V --> F["OEM image validation and flashing"]
    V --> R["Boot-state, reboot and factory-reset services"]
~~~

The vendor subsystem labels are conceptual responsibilities, not additional callable interfaces.

## Complete API inventory

All functions return `INT`. Empty parameter lists below preserve the header spelling; in C these old-style declarations do not provide prototype-level argument checking.

| Exact declaration | Contract |
| --- | --- |
| `INT fwupgrade_hal_set_download_url(char* pUrl, char* pfilename);` | Set source URL and local filename; `RETURN_OK/RETURN_ERR`. |
| `INT fwupgrade_hal_get_download_url(char *pUrl, char* pfilename);` | Caller output buffers: at least 1024 bytes for URL and 256 bytes for filename; `RETURN_OK/RETURN_ERR`. |
| `INT fwupgrade_hal_set_download_interface(unsigned int interface);` | `0=wan0`, `1=erouter0`; `RETURN_OK/RETURN_ERR`. |
| `INT fwupgrade_hal_get_download_interface(unsigned int* pinterface);` | Retrieve the same interface identifier; `RETURN_OK/RETURN_ERR`. |
| `INT fwupgrade_hal_download();` | Header describes fetching, validating, installing, and setting boot state. `0` success, `-1` general failure, `400` invalid URL or hostname resolution failure. |
| `INT fwupgrade_hal_get_download_status();` | Returns progress/error directly; see complete code table below. |
| `INT fwupgrade_hal_reboot_ready(ULONG *pValue);` | Call status `0/-1`, separately writing `1=ready`, `2=not ready`. |
| `INT fwupgrade_hal_download_reboot_now();` | Immediate reboot to apply downloaded image; `0/-1`. |
| `INT fwupgrade_hal_update_and_factoryreset();` | Update and, upon success, factory reset; `0/-1`. Destructive. |
| `INT fwupgrade_hal_download_install(const char *url);` | Direct URL download and installation initiation; `0/-1`. |

### Download status values

| Value | Meaning |
| --- | --- |
| `0` | Not started, not a generic completed-success indication. |
| `1–99` | Download percentage. |
| `100` | Download complete, pending reboot. |
| `400` | Invalid HTTP server URL. |
| `401` | Cannot connect to HTTP server. |
| `402` | File not found. |
| `403` | Hardware type download protection failure. |
| `404` | Hardware mask download protection failure. |
| `405` | Download revision protection failure. |
| `406` | Download header protection failure. |
| `407` | Download CVC failure. |
| `500` | General download failure. |

These are HAL status values, not a declaration that all values are HTTP response codes. Download completion alone does not establish successful boot into the new image.

## Complete type and constant inventory

No structs, enums, callbacks, public variables, or context handles are declared. Conditional scalar aliases are `CHAR=char`, `UCHAR=unsigned char`, `BOOLEAN=unsigned char`, `USHORT=unsigned short`, `UINT8=unsigned char`, `INT=int`, `UINT=unsigned int`, `LONG=long`, and `ULONG=unsigned long`. Widths follow the target ABI. Constants: `TRUE=1`, `FALSE=0`, `ENABLE=1`, `RETURN_OK=0`, `RETURN_ERR=-1`. The header supplies C++ linkage guards; it does not declare version negotiation.

## Lifecycle and representative sequence

There is no initializer or finalizer. Configuration precedes the configured-download path. The following shows the standard path only; it does not mandate calling direct-install or factory-reset operations as well.

~~~mermaid
sequenceDiagram
    participant C as Upgrade caller
    participant H as Vendor HAL
    C->>H: fwupgrade_hal_set_download_url(pUrl, pfilename)
    H-->>C: INT status
    C->>H: fwupgrade_hal_set_download_interface(interface)
    H-->>C: INT status
    Note over C: Continue only after successful configuration
    C->>H: fwupgrade_hal_download()
    H-->>C: INT download result
    C->>H: fwupgrade_hal_get_download_status()
    H-->>C: INT progress or download error
    opt Download successful and reboot authorized
        C->>H: fwupgrade_hal_reboot_ready(pValue)
        H-->>C: INT status; readiness through pValue
        opt Status successful and readiness equals 1
            C->>H: fwupgrade_hal_download_reboot_now()
            H-->>C: INT status if execution returns
        end
    end
~~~

A not-ready result does not require redownloading. No automatic retries, exponential backoff, or state-transition graph is guaranteed by the header. Preserve failure information and let an authorized orchestrator decide recovery.

## Ownership, errors, persistence, and concurrency

Caller owns input strings and output buffers. No returned allocations or release API exist. Lengthless getters require the documented minimum capacities; termination, truncation, input retention, and failure-output rules remain unresolved.

Distinguish operation result, progress code, and output readiness. Do not treat every nonnegative result as success. Image operations, reboot, and factory reset may interrupt execution and connectivity; no cancellation, maximum duration, polling interval, or post-reboot observation API is declared.

No callback is declared. Serialization and cross-process exclusion are integration requirements, not proven implementation properties. Avoid concurrent configuration/download/reset operations and do not call potentially long-running work on a critical event-loop thread. Vendors own internal resource cleanup.

Configuration is described as retrieved from configuration files, and operations alter firmware/boot state. Thus a blanket “no persistence” claim would be misleading. Retention across process/device restart and power-loss recovery are not specified.

## Integration and delivery policy

Retain Linux/Yocto support, Apache License 2.0 implementation, and shared library `libfw_upgrade.so`. Interface evolution follows controlled semantic versioning. Multiple-process protection, leak-free cleanup, and efficient resource usage remain vendor obligations; numeric footprint and timing targets remain unassigned.

Use timestamped syslog diagnostics routed to `fwupgrade_vendor_hal.log` under `/var/tmp/` or `/rdklogs/logs/`. Redact credentials and tokens embedded in URLs. Map FATAL/TRACE project labels to actual logging priorities. Static analysis, dependency/license review, and memory analysis remain recommended; no build, test, device operation, or upgrade was performed to generate this document.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| FW-GAP-01 | `download` describes completed installation while status `100` says pending reboot: define completion and activation boundaries. |
| FW-GAP-02 | No deadline, cancellation, or polling cadence; clarify blocking behavior and progress visibility during `download`. |
| FW-GAP-03 | Lengthless URL/filename getters: define limits, termination, truncation, and failure outputs. |
| FW-GAP-04 | Shared configuration has no transaction/handle: define inter-process exclusion and configuration lifetime. |
| FW-GAP-05 | Validation internals unspecified: document trust anchors, image authenticity, compatibility, and power-loss recovery outside this ABI. |
| FW-GAP-06 | No rollback API, post-boot success observable, or idempotency contract; do not invent recovery guarantees. |
| FW-GAP-07 | Old-style empty parameter lists should be clarified by future interface governance, not silently changed in examples. |
