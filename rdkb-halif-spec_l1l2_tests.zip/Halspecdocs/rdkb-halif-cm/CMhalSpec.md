# Cable Modem HAL Specification

## Scope and evidence

[cm_hal.h](../../include/cm_hal.h) declares 51 functions, seventeen structs, and one diplexer callback type. It supplies initialization, DOCSIS status/channel observation, limited provisioning/channel controls, DHCP/CPE information, diagnostics, HTTP firmware-download/reboot operations, reset counters, SNMPv3 kickstart, energy detection and diplexer configuration observation.

HAL means Hardware Abstraction Layer; CM means Cable Modem; DOCSIS means Data Over Cable Service Interface Specification; CMTS means Cable Modem Termination System; DS/US mean Downstream/Upstream; OFDM/OFDMA mean Orthogonal Frequency Division Multiplexing/Multiple Access; CPE means Customer Premises Equipment; MDD means MAC Domain Descriptor; LLD means Low Latency DOCSIS; BPI means Baseline Privacy Interface; SNMP means Simple Network Management Protocol; DHCP means Dynamic Host Configuration Protocol.

The specification describes declarations/comments and retained integration policy, not tested vendor behavior. No deinitializer, model/firmware identity getter, IP-address setter, generic online/offline setter, or general status/channel-event subscription is declared. The only callback reports diplexer changes; asynchronous log clearing has no completion callback.

## Architecture

~~~mermaid
flowchart TD
    C["CM management caller, such as CcspCMAgent"] --> H["cm_hal.h"]
    H --> L["Vendor libcm_mgnt.so"]
    L --> D["DOCSIS PHY, MAC and registration services"]
    L --> I["DHCP, diagnostics, provisioning and download services"]
    L -. "Diplexer settings callback" .-> C
~~~

Vendor service boxes are conceptual; no internal transport or implementation layering is mandated.

## Complete API inventory

The following declarations retain exact names, parameter types, order and parameter names. Empty `()` declarations are retained rather than silently changed to `(void)`; in traditional C they do not specify a zero-argument prototype.

### Initialization, status, channels and diagnostics

~~~c
INT cm_hal_InitDB(void);
INT docsis_InitDS(void);
INT docsis_InitUS(void);
INT docsis_getCMStatus(CHAR *cm_status);
INT docsis_GetDSChannel(PCMMGMT_CM_DS_CHANNEL *ppinfo);
INT docsis_GetUsStatus(USHORT i, PCMMGMT_CM_US_CHANNEL pinfo);
INT docsis_GetUSChannel(PCMMGMT_CM_US_CHANNEL *ppinfo);
INT docsis_GetDOCSISInfo(PCMMGMT_CM_DOCSIS_INFO pinfo);
INT docsis_GetNumOfActiveTxChannels(ULONG *cnt);
INT docsis_GetNumOfActiveRxChannels(ULONG *cnt);
INT docsis_GetErrorCodewords(PCMMGMT_CM_ERROR_CODEWORDS *ppinfo);
INT docsis_GetMddIpModeOverride(CHAR *pValue);
INT docsis_SetMddIpModeOverride(CHAR *pValue);
UINT8 docsis_GetUSChannelId(void);
void docsis_SetUSChannelId(INT index);
ULONG docsis_GetDownFreq(void);
void docsis_SetStartFreq(ULONG value);
INT docsis_GetDocsisEventLogItems(CMMGMT_CM_EventLogEntry_t *entryArray, INT len);
INT docsis_ClearDocsisEventLog(void);
~~~

### Address information, market and firmware recovery

~~~c
INT cm_hal_GetDHCPInfo(PCMMGMT_CM_DHCP_INFO pInfo);
INT cm_hal_GetIPv6DHCPInfo(PCMMGMT_CM_IPV6DHCP_INFO pInfo);
INT cm_hal_GetCPEList(PCMMGMT_DML_CPE_LIST *ppCPEList, ULONG *InstanceNum, CHAR *LanMode);
INT cm_hal_GetMarket(CHAR *market);
INT cm_hal_Set_HTTP_Download_Url(char *pHttpUrl, char *pfilename);
INT cm_hal_Get_HTTP_Download_Url(char *pHttpUrl, char *pfilename);
INT cm_hal_Set_HTTP_Download_Interface(unsigned int interface);
INT cm_hal_Get_HTTP_Download_Interface(unsigned int *pinterface);
INT cm_hal_HTTP_Download();
INT cm_hal_Get_HTTP_Download_Status();
INT cm_hal_Reboot_Ready(ULONG *pValue);
INT cm_hal_HTTP_Download_Reboot_Now();
INT cm_hal_FWupdateAndFactoryReset(char *pUrl, char *pImagename);
INT cm_hal_ReinitMac();
INT docsis_GetProvIpType(CHAR *pValue);
INT docsis_GetCert(CHAR *pCert);
INT docsis_GetCertStatus(ULONG *pVal);
~~~

### Counters, DOCSIS 3.1, security, energy and diplexer

~~~c
INT cm_hal_Get_CableModemResetCount(ULONG *resetcnt);
INT cm_hal_Get_LocalResetCount(ULONG *resetcnt);
INT cm_hal_Get_DocsisResetCount(ULONG *resetcnt);
INT cm_hal_Get_ErouterResetCount(ULONG *resetcnt);
INT cm_hal_HTTP_LED_Flash(BOOLEAN LedFlash);
INT docsis_GetDsOfdmChanTable(PDOCSIF31_CM_DS_OFDM_CHAN *ppinfo, int *output_NumberOfEntries);
INT docsis_GetUsOfdmaChanTable(PDOCSIF31_CM_US_OFDMA_CHAN *ppinfo, int *output_NumberOfEntries);
INT docsis_GetStatusOfdmaUsTable(PDOCSIF31_CMSTATUSOFDMA_US *ppinfo, int *output_NumberOfEntries);
INT docsis_LLDgetEnableStatus();
INT cm_hal_snmpv3_kickstart_initialize(snmpv3_kickstart_table_t *pKickstart_Table);
INT docsis_IsEnergyDetected(BOOLEAN *pEnergyDetected);
INT cm_hal_set_ReinitMacThreshold(ULONG value);
INT cm_hal_get_ReinitMacThreshold(ULONG *pValue);
INT cm_hal_get_DiplexerSettings(CM_DIPLEXER_SETTINGS *pValue);
INT cm_hal_Register_DiplexerVariationCallback(cm_hal_DiplexerVariationCallback callback_proc);
~~~

### Per-family behavior and argument constraints

| Family | Header-backed behavior/limits |
| --- | --- |
| Initialization | Initialize DB/dependencies, then downstream PHY and upstream PHY/direct hardware access. Initialization may block for hardware readiness. No public shutdown exists. |
| Status | `docsis_getCMStatus` needs at least 40 bytes; `GetDOCSISInfo` fills caller-preallocated storage. Status strings are listed below without inferred transition edges. |
| Channels | DS/US channel getters return dynamic storage caller must release. `GetUsStatus` takes `USHORT i`, described only as 0..n without a concrete active-channel upper bound. Active TX/RX counts are separate observations. |
| Codewords | Comments require preallocated storage although declaration uses pointer-to-pointer; define capacity/layout before use. |
| MDD override | Getter needs 64 bytes. Setter accepts `ipv4Only`, `ipv6Only`, `honorMdd`; empty string clears override. Getter prose discourages `APM`/`DualStack`, while setter prose says they might be returned: inconsistent vocabulary, not permission to set them. |
| Channel control | US identifier getter range 0..255. Setter accepts `INT` without a complete validation rule. Downstream/start frequency is Hz. Both setters return `void`; readback is observation, not a transactional guarantee. |
| Event log | Caller supplies array and maximum `len`; return is number retrieved. Clear is explicitly asynchronous and must not block/use blocking system calls. Return is not proof of clearing completion. |
| DHCP/CPE | DHCP structs are caller-preallocated. CPE comments require preallocated list and mode string, return count through `InstanceNum`, and mark `LanMode` input (`router`/`bridge`, max 100 bytes). No list capacity parameter is declared. |
| Market/certificate | Market output at least 100 bytes, examples `US`, `EURO`. Certificate returns a filepath without a capacity; status output `0=disabled`, `1=enabled`, not certificate validation proof. |
| HTTP configuration | URL/filename setter inputs are non-const with a comment TODO to make const. Getter needs at least 200 bytes for each output; this is not an input minimum for the setter. Interface values `0=wan0`, `1=erouter0`. |
| HTTP initiation | Uses prior settings; returns request status, including error if already downloading. Poll status separately. |
| Reboot/reset | Reboot readiness outputs `1=ready`, `2=not ready`. Reboot performs pre-reboot work; update/factory-reset accepts URL and image filename and is destructive. Do not initiate either automatically on a read failure. |
| MAC recovery | Reinitializes MAC while preserving DS/US channels; completion/readiness and failure state require vendor agreement. Threshold setter/getter exist, but threshold units/range are not defined. |
| Provisioned IP type | Comment calls output a character variable but mentions strings `DHCP`/`STATIC` or numeric equivalents. Representation/capacity unresolved; no IP-address setter follows from it. |
| Reset counters | Four distinct getters; no counter-clear function declared. Width/rollover depend on `ULONG` and vendor behavior. |
| HTTP LED | Boolean enable/disable flashing; comment explicitly lists success but no detailed failure cases. |
| OFDM/OFDMA | Three dynamic arrays return entry count; caller deallocates. Declaration availability does not prove DOCSIS 3.1 hardware support or define an unsupported/empty distinction. |
| LLD | Returns `ENABLE=1`, `DISABLE=0` (also missing bootfile entry), or `RETURN_ERR=-1`. No actual `LLD_STATUS` enum is declared despite a future TODO. |
| SNMP kickstart | Input table has nested row and byte-buffer pointers; retention/deep-copy behavior unspecified. |
| Energy | Boolean energy detection is a physical observation, not proof of IP reachability or completed DOCSIS registration. |
| Diplexer | Getter/callback expose upper band edges in MHz. Registration may return error for unsupported/stub implementations. No unregister exists; comment explicitly says callback cannot be removed and should be supplied during initialization. |

### Return-shape accounting

Of 51 declarations, 44 have ordinary integer operation-status shape, one is the three-way LLD query, four directly return values/count/progress, and two return `void`. Most operation comments specify `RETURN_OK=0`/`RETURN_ERR=-1`; do not assign unlisted errors or `errno` behavior. Callback processing also returns operation status.

Direct-value exceptions are `docsis_GetUSChannelId`, `docsis_GetDownFreq`, `docsis_GetDocsisEventLogItems`, and `cm_hal_Get_HTTP_Download_Status`. The first two declare no failure sentinel. The log-count comment does not define a distinct error result; do not invent one.

HTTP download status: `0=not started`, `1..99=progress percentage`, `100=complete pending reboot`, `400=invalid URL`, `401=cannot connect`, `402=file not found`, `403..407=download protection failures` named HW_Type/HW Mask/DL Rev/DL Header/DL CVC, `500=general failure`. These are HAL-specific meanings, not standard HTTP response semantics. Status 100 is not proof of successful boot, rollback support, or post-reboot readiness.

## Complete type inventory

All seventeen structs and all their fields are listed. There are no public C enums or external global variables in this header.

### Channel, registration and error structs

| Type | Complete fields |
| --- | --- |
| `CMMGMT_CM_DS_CHANNEL` | `ULONG ChannelID`, `Octets`, `Correcteds`, `Uncorrectables`; `CHAR Frequency[64]`, `PowerLevel[64]`, `SNRLevel[64]`, `Modulation[64]`, `LockStatus[64]`. |
| `CMMGMT_CM_US_CHANNEL` | `ULONG ChannelID`; `CHAR Frequency[64]`, `PowerLevel[64]`, `ChannelType[64]`, `SymbolRate[64]`, `Modulation[64]`, `LockStatus[64]`. |
| `CMMGMT_CM_DOCSIS_INFO` | `CHAR[64]` fields `DOCSISVersion`, `DOCSISDownstreamScanning`, `DOCSISDownstreamRanging`, `DOCSISUpstreamScanning`, `DOCSISUpstreamRanging`, `DOCSISTftpStatus`, `DOCSISDataRegComplete`, `DOCSISConfigFileName`, `ToDStatus`, `UpstreamServiceFlowParams`, `DownstreamServiceFlowParams`, `DOCSISDownstreamDataRate`, `DOCSISUpstreamDataRate`, `CoreVersion`; `ULONG DOCSISDHCPAttempts`, `DOCSISTftpAttempts`, `MaxCpeAllowed`; `BOOLEAN BPIState`, `NetworkAccess`; `ANSC_IPV4_ADDRESS UpgradeServerIP`. |
| `CMMGMT_CM_ERROR_CODEWORDS` | `ULONG UnerroredCodewords`, `CorrectableCodewords`, `UncorrectableCodewords`. |

### Logs and address structs

| Type | Complete fields |
| --- | --- |
| `CMMGMT_CM_EventLogEntry_t` | `UINT docsDevEvIndex`, `docsDevEvCounts`, `docsDevEvLevel`, `docsDevEvId`; `struct timeval docsDevEvFirstTime`, `docsDevEvLastTime`; `CHAR docsDevEvText[EVM_MAX_EVENT_TEXT]`. |
| `CMMGMT_DML_CM_LOG` | `BOOLEAN EnableLog`, `ClearDocsisLog`. |
| `CMMGMT_DML_DOCSISLOG_FULL` | `ULONG Index`, `EventID`, `EventLevel`; `CHAR Time[64]`, `Description[256]`. |
| `CMMGMT_CM_DHCP_INFO` | `ANSC_IPV4_ADDRESS IPAddress`, `SubnetMask`, `Gateway`, `TFTPServer`; `CHAR BootFileName[256]`; `CHAR TimeServer[64]`, `RebindTimeRemaining[64]`, `RenewTimeRemaining[64]`, `MACAddress[64]`, `DOCSISDHCPStatus[64]`; `INT TimeOffset`; `ULONG LeaseTimeRemaining`. |
| `CMMGMT_CM_IPV6DHCP_INFO` | `CHAR IPv6Address[40]`, `IPv6Prefix[40]`, `IPv6Router[40]`, `IPv6TFTPServer[40]`, `IPv6TimeServer[40]`; `CHAR IPv6BootFileName[256]`; `ULONG IPv6LeaseTimeRemaining`, `IPv6RebindTimeRemaining`, `IPv6RenewTimeRemaining`. |
| `CMMGMT_DML_CPE_LIST` | `CHAR IPAddress[32]`, `MACAddress[32]`. |

Forty-byte IPv6 text storage must not be generalized into support for every decorated/prefixed textual address format. String measurements/time fields remain strings rather than native counters.

### DOCSIS 3.1 structs

| Type | Complete fields |
| --- | --- |
| `DOCSIF31_CM_DS_OFDM_CHAN` | `unsigned int ChannelId`, `ChanIndicator`, `SubcarrierZeroFreq`, `FirstActiveSubcarrierNum`, `LastActiveSubcarrierNum`, `NumActiveSubcarriers`, `SubcarrierSpacing`, `CyclicPrefix`, `RollOffPeriod`, `PlcFreq`, `NumPilots`, `TimeInterleaverDepth`; `char averageSNR[OFDM_PARAM_STR_MAX_LEN]`, `PowerLevel[OFDM_PARAM_STR_MAX_LEN]`; `unsigned long long PlcTotalCodewords`, `PlcUnreliableCodewords`, `NcpTotalFields`, `NcpFieldCrcFailures`. |
| `DOCSIF31_CM_US_OFDMA_CHAN` | `unsigned int ChannelId`, `ConfigChangeCt`, `SubcarrierZeroFreq`, `FirstActiveSubcarrierNum`, `LastActiveSubcarrierNum`, `NumActiveSubcarriers`, `SubcarrierSpacing`, `CyclicPrefix`, `RollOffPeriod`, `NumSymbolsPerFrame`, `TxPower`; `unsigned char PreEqEnabled`. |
| `DOCSIF31_CMSTATUSOFDMA_US` | `unsigned int ChannelId`, `T3Timeouts`, `T4Timeouts`, `RangingAborteds`, `T3Exceededs`, `RangingStatus`; `unsigned char IsMuted`. |

### SNMP and diplexer structs

| Type | Complete fields |
| --- | --- |
| `fixed_length_buffer_t` | `USHORT length`; `UINT8 *buffer`. Length-based data is not automatically a NUL-terminated string. |
| `snmp_kickstart_row_t` | `fixed_length_buffer_t security_name`, `security_number`. |
| `snmpv3_kickstart_table_t` | `UINT8 n_rows`; `snmp_kickstart_row_t *kickstart_values[MAX_KICKSTART_ROWS]`. Bound rows to five and respect nested buffer lengths. |
| `CM_DIPLEXER_SETTINGS` | `UINT usDiplexerSetting`, `dsDiplexerSetting`, upper band edges in MHz. |

The following twelve pointer aliases are declared, each pointing to the matching struct: `PCMMGMT_CM_DS_CHANNEL`, `PCMMGMT_CM_US_CHANNEL`, `PCMMGMT_CM_DOCSIS_INFO`, `PCMMGMT_CM_ERROR_CODEWORDS`, `PCMMGMT_DML_CM_LOG`, `PCMMGMT_DML_DOCSISLOG_FULL`, `PCMMGMT_CM_DHCP_INFO`, `PCMMGMT_CM_IPV6DHCP_INFO`, `PCMMGMT_DML_CPE_LIST`, `PDOCSIF31_CM_DS_OFDM_CHAN`, `PDOCSIF31_CM_US_OFDMA_CHAN`, `PDOCSIF31_CMSTATUSOFDMA_US`. The remaining five structs have no separate pointer typedef. Pointer-to-pointer signatures add a level beyond these aliases.

### Callback

~~~c
typedef INT (*cm_hal_DiplexerVariationCallback)(CM_DIPLEXER_SETTINGS stCMDiplexerValue);
~~~

Settings are passed by value, so retaining a private copy does not retain vendor-owned pointer storage. Callback code/state must remain valid while it can be invoked. Dispatch thread, inline invocation, serialization, replacement registration, return-value handling and shutdown quiescence are not fully specified.

### Scalar aliases and all public constants

Conditional scalar macro aliases: `CHAR=char`, `UCHAR=unsigned char`, `BOOLEAN=unsigned char`, `USHORT=unsigned short`, `UINT8=unsigned char`, `INT=int`, `UINT=unsigned int`, `LONG=long`, `ULONG=unsigned long`. Existing definitions may override them; widths/alignment must match vendor ABI. In particular, `ULONG` is not guaranteed 64 bits.

Constants: `TRUE=1`, `FALSE=0`, `ENABLE=1`, `DISABLE=0`, `RETURN_OK=0`, `RETURN_ERR=-1`, `OFDM_PARAM_STR_MAX_LEN=64`, `IPV4_ADDRESS_SIZE=4`, `EVM_MAX_EVENT_TEXT=255`, `MAX_KICKSTART_ROWS=5`.

`ANSC_IPV4_ADDRESS` expands to an anonymous union of `unsigned char Dot[IPV4_ADDRESS_SIZE]` and `uint32_t Value`. Its surrounding comments describe dotted octets/network-byte-order value; agree host/network representation at the boundary rather than accessing the union as a string.

## Lifecycle and representative sequence

Retained startup ordering is `cm_hal_InitDB`, `docsis_InitDS`, `docsis_InitUS`, checking success before continuing. There is no public deinit or independent release of global HAL state. Reinitialization/idempotency and readiness after recovery are not a complete declared state machine.

~~~mermaid
sequenceDiagram
    participant C as CM caller
    participant H as Vendor CM HAL
    C->>H: cm_hal_InitDB()
    H-->>C: INT status
    C->>H: docsis_InitDS()
    H-->>C: INT status
    C->>H: docsis_InitUS()
    H-->>C: INT status
    opt Supported diplexer subscription during initialization
        C->>H: cm_hal_Register_DiplexerVariationCallback(callback_proc)
        H-->>C: INT status
        H-->>C: callback_proc(stCMDiplexerValue)
    end
    C->>H: docsis_getCMStatus(cm_status)
    H-->>C: INT status; status text on success
    C->>H: docsis_GetDOCSISInfo(pinfo)
    H-->>C: INT status; registration information on success
    opt Explicitly authorized firmware operation
        C->>H: cm_hal_Set_HTTP_Download_Url(pHttpUrl, pfilename)
        H-->>C: INT status
        C->>H: cm_hal_Set_HTTP_Download_Interface(interface)
        H-->>C: INT status
        C->>H: cm_hal_HTTP_Download()
        H-->>C: INT request status
        loop Bounded polling under caller policy
            C->>H: cm_hal_Get_HTTP_Download_Status()
            H-->>C: progress or error value
        end
        Note over C,H: No reboot on transfer errors; 100 is pending reboot
        C->>H: cm_hal_Reboot_Ready(pValue)
        H-->>C: INT status; 1 ready or 2 not ready
        opt Ready and explicit reboot authorization
            C->>H: cm_hal_HTTP_Download_Reboot_Now()
            H-->>C: INT status
        end
    end
~~~

The diagram assumes successful prerequisites; it does not promise callback order, request completion, image authenticity, atomic updates, rollback, reboot return delivery, or post-reboot health. A caller supplies its own polling deadline without relabeling it a header requirement.

## Observed status vocabularies, not inferred transitions

`docsis_getCMStatus` documents these strings:

- Completion/bring-up: `NOT_READY`, `NOT_SYNCHRONIZED`, `PHY_SYNCHRONIZED`, `US_PARAMETERS_ACQUIRED`, `RANGING_COMPLETE`, `DHCPV4_COMPLETE`, `DHCPV6_COMPLETE`, `TOD_ESTABLISHED`, `SECURITY_ESTABLISHED`, `CONFIG_FILE_DOWNLOAD_COMPLETE`, `REGISTRATION_COMPLETE`, `OPERATIONAL`.
- In progress: `RANGING_IN_PROGRESS`, `DHCPV4_IN_PROGRESS`, `DHCPV6_IN_PROGRESS`, `REGISTRATION_IN_PROGRESS`, `EAE_IN_PROGRESS`, `DS_TOPOLOGY_RESOLUTION_IN_PROGRESS`, `BPI_INIT`.
- Conditions/unmapped: `ACCESS_DENIED`, `FORWARDING_DISABLED`, `RF_MUTE_ALL`, `OTHER`, `Unsupported status`.

No public enum or legal transition matrix is supplied; tolerate unrecognized text rather than assuming a closed set.

| `CMMGMT_CM_DOCSIS_INFO` field | Documented vocabulary |
| --- | --- |
| `DOCSISDownstreamScanning`, `DOCSISDownstreamRanging`, `DOCSISUpstreamScanning`, `DOCSISUpstreamRanging` | `NotStarted`, `InProgress`, `Complete`. |
| `DOCSISTftpStatus` | `NotStarted`, `InProgress`, `DownloadComplete`. |
| `DOCSISDataRegComplete` | `InProgress`, `RegistrationComplete`. |
| `ToDStatus` | `NotStarted`, `Complete`. |
| `DOCSISDHCPAttempts`, `DOCSISTftpAttempts` | Counts, not states. |
| `BPIState`, `NetworkAccess` | Boolean annotations, not transition phases. |

No complete mapping between formatted status and struct fields is specified.

## Ownership, errors, blocking, concurrency and persistence

- Caller owns ordinary outputs, status/name buffers, event arrays, DHCP structs and input storage.
- DS/US channel getters and all three DOCSIS 3.1 table getters explicitly return dynamic storage caller must deallocate. Confirm allocator-compatible release, element count for DS/US returns, and validity; no dedicated public free API exists.
- Error-codeword output is pointer-to-pointer but its comment requires caller preallocation; CPE similarly requires preallocation without a capacity input. Do not infer allocation/layout solely from pointer depth or a separately queried count.
- SNMP rows and buffers are caller-supplied nested pointers. Confirm copy/retention duration and secret handling. Do not log security data, subscriber identifiers, certificate contents or sensitive URLs.
- Check status before using outputs; null behavior, partial outputs, rollback and detailed error reasons are not consistently defined. Void setters and by-value queries lack a universal error mechanism.
- Existing integration policy does not require thread safety; callers serialize and vendors protect internal threads and multi-process resources. No locking implementation or atomic snapshot guarantee follows from this policy.
- Diplexer callback cannot be removed according to its comment. No unregister/drain exists; avoid unload/destruction while callbacks can occur and avoid lock inversion if callbacks can occur inline.
- Synchronous operations have qualitative completion guidance, not measured deadlines. Initialization may wait for hardware; log clearing explicitly must not block. Earlier blanket “must not suspend” language cannot establish bounded nonblocking behavior for every operation.
- No general power-management API is declared; reboot/recovery are not general power-state controls. Settings, firmware, log clearing, factory reset and counters have stateful effects. Persistence/reset scope and safe reapplication require vendor agreement; do not assume either durability or automatic loss on restart.
- Vendors remain responsible for private resources; caller-freed output exceptions do not excuse internal leaks.

## Integration and delivery policy

Retain Linux/Yocto support, Apache License 2.0 implementation, shared library `libcm_mgnt.so`, and controlled semantic versioning. Include the linked public header and use the deployed matching vendor library. This contract does not prove hardware support from declaration presence alone.

Use timestamped syslog diagnostics routed to `cm_vendor_hal.log` under `/rdklogs/logs/`. FATAL/TRACE are project labels requiring mapping, not native Linux priorities. Numeric CPU/memory/deadline budgets remain unspecified. Static analysis, dependency/license review and memory analysis remain recommended; no tests, compiler, VTS or DUT operations were performed in this regeneration.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| CM-GAP-01 | Five dynamic outputs require caller release, but allocator/release routine, DS/US element counts and lifetime are unspecified. |
| CM-GAP-02 | Error-codeword preallocation wording versus double pointer; define pointee layout/capacity and mutation policy. |
| CM-GAP-03 | CPE list preallocation has no capacity input; resolve count races and `LanMode` input versus surrounding retrieval prose. |
| CM-GAP-04 | Lengthless certificate/provision-type outputs need representation, capacity, termination and failure-output rules. |
| CM-GAP-05 | MDD getter/setter comments disagree on possible returned strings; preserve accepted setter vocabulary. |
| CM-GAP-06 | Diplexer callback cannot be removed; define dispatch, replacement, reentrancy, return handling and quiescence. |
| CM-GAP-07 | Ordinary status, direct values, LLD and void setters differ; define unavailable sentinels and failed-call outputs. |
| CM-GAP-08 | Define concurrency, multi-process isolation, snapshot consistency, finite deadlines and recovery readiness. |
| CM-GAP-09 | Define SNMP nested buffer validation/retention, `ULONG` counter width/rollover, frequency/measurement formats and ABI alignment. |
| CM-GAP-10 | Download 100 is pending reboot, not health/rollback proof; define validation, reboot completion and factory-reset scope. |
| CM-GAP-11 | Runtime support/error behavior for DOCSIS 3.1/diplexer/energy is not a complete capability matrix. |
| CM-GAP-12 | No deinit, callback drain, persistence contract, threshold units/range or complete legal-transition matrix. |

## Version and canonical location

Retain recorded interface history: 2024-06-10 initial GitHub release 1.0.0; 2024-06-20 syntax corrections 1.0.1. Documentation regeneration does not assign a new ABI version. `docs/pages/CMhalSpec.md` remains canonical and root `README.md` remains its Git mode `120000` symlink.
