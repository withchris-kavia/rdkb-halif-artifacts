# EPON HAL Specification

## Scope and Evidence

This is the canonical EPON Hardware Abstraction Layer specification. `README.md` is a symlink to `docs/pages/EponhalSpec.md`; update this target, not the symlink. Repository links in this page resolve from the canonical target directory.

The sole public C header is [`epon_hal.h`](../../epon_hal.h). It declares **15 functions, 13 enum typedefs, 13 struct typedefs, and three callback function pointer fields**. There are no standalone callback typedefs. API version 1.0.0 describes the declared interface, not a verified vendor implementation.

This repository supplies no HAL implementation translation units, manager implementation, vendor driver, build recipe, or executable tests. All API execution traces stop at header declarations. The default logging macro is the only supplied runtime body. A **declared contract** below means a declaration or its associated header comment. **Vendor-dependent** behavior is not implemented or verified here. Integration recommendations are identified separately.

The lifecycle labels `epon_init` and `epon_term` mean initialization and termination conceptually. The actual declared functions are `epon_hal_init` and `epon_hal_deinit`; no `epon_init` or `epon_term` symbols exist.

## Version History

| Date | Comment | Version |
| --- | --- | --- |
| 08/24/26 | Initial Release | 1.0.0 |

The table records the existing document history. The enriched contract inventory does not change the public API version.

## Acronyms

| Acronym | Meaning |
| --- | --- |
| HAL | Hardware Abstraction Layer. |
| RDK-B | Reference Design Kit for Broadband Devices. |
| API / ABI | Application Programming Interface / Application Binary Interface. |
| PON / EPON | Passive Optical Network / Ethernet Passive Optical Network. |
| WAN | Wide Area Network; the operator-facing side of the gateway. |
| ONU | Optical Network Unit; the subscriber-side device abstracted here. |
| OLT | Optical Line Terminal; the network-side peer. |
| LLID | Logical Link Identifier. |
| MPCP | Multi-Point Control Protocol. |
| OAM | Operations, Administration and Maintenance. |
| DOCSIS | Data Over Cable Service Interface Specification. |
| DPoE | DOCSIS Provisioning of EPON. |
| CPE | Customer Premises Equipment. |
| FEC / BER | Forward Error Correction / Bit Error Rate. |
| MAC / OUI | Media Access Control / Organizationally Unique Identifier. |
| AES | Advanced Encryption Standard. |
| TR-181 | Broadband Forum Device Data Model. |

## Description

The EPON HAL is the common C interface between upper RDK-B consumers, represented by the EPON Manager, and vendor software controlling ONU/optical hardware. The following diagram describes integration intent, not implemented repository modules.

```mermaid
flowchart TD
    Caller["Upper RDK-B stack components: EPON Manager and callers"]
    EponHAL["EPON HAL C interface: epon_hal.h"]
    VendorSoftware["Vendor implementation and SoC SDK / driver layer"]
    Onu["ONU / optical hardware"]
    Olt["OLT: external network peer"]
    Caller -->|"15 declared C functions"| EponHAL
    EponHAL -->|"Implementation boundary"| VendorSoftware
    VendorSoftware -->|"Platform-specific access"| Onu
    Onu <-->|"Optical link and MPCP / OAM"| Olt
    VendorSoftware -.->|"Status, alarm, interface callbacks via HAL contract"| Caller
```

The upper stack owns application policy and consumes observations. The HAL defines function signatures, data structures, return vocabulary, and notifications. The vendor supplies hardware access, interface mapping, MPCP/OAM processing, discovery/registration mechanisms, and measurements. No particular SoC, SDK, kernel driver, bus, register map, device node, or optical module is identified. The OLT is an external peer, not a component implemented here.

Callers can retrieve LLIDs, interfaces, OLT and manufacturer identity, link and optical statistics, operational mode, and encryption state. Maintenance calls clear counters, reset the ONU, or restore defaults. An optional DPoE operation retrieves the CPE MAC table.

The interface has no instance, device, port, or context handle. This does not establish a singleton implementation, a single process, or process isolation. Direct function returns and callback notifications are separate interfaces; no general nonblocking or thread-safety guarantee exists.

## Optional Components

DPoE is the optional extension represented by `epon_hal_config_t.dpoe_supported`, `dpoe_hal_get_cpe_mac_table`, `dpoe_cpe_mac_type_t`, `dpoe_cpe_mac_entry_t`, and `dpoe_cpe_mac_table_t`. Vendor-specific alarm values are carried through the common alarm callback.

All DPoE declarations are unconditional; no DPoE feature compile guard surrounds them. The initialization flag is an input setting, not a capability-discovery API or proof that a vendor implements DPoE. The CPE getter documents `EPON_HAL_ERROR_NOT_SUPPORTED` when DPoE is unsupported. Enumerating vendor alarms likewise does not guarantee every platform can detect them.

## Component Runtime Execution Requirements

### Initialization and Startup

Call `epon_hal_get_version` to check compatibility before initialization, as intended by its header example. Then prepare a non-null `epon_hal_config_t`, set `struct_size = sizeof(epon_hal_config_t)`, select the DPoE setting, and supply the three callback fields. Whether any callback may be null is unspecified.

`epon_hal_init` sets up callback handlers, DPoE support when enabled, and interface mapping. Its documented errors cover invalid input, wrong PON mode, hardware failure, callback registration failure, and initialization blocked for more than three minutes. Success establishes initialized operational use; it does not explicitly guarantee completion of ONU registration or interface readiness.

Repeated initialization, retention or copying of the configuration, partial-init rollback, and cleanup after initialization failure are unspecified. Do not assume automatic retry or that failed initialization leaves no allocated resources.

### Threading Model

Every public function has **unspecified thread safety**, including read-only getters and the version query. The header defines no locking, callback dispatch thread, reentrancy, callback serialization, or concurrent-call guarantees. Calls return a value directly, but may block; only initialization has a documented duration threshold.

As a conservative integration recommendation, serialize HAL operations until the vendor supplies a concurrency contract. Do not call HAL operations recursively from callbacks without a reentrancy guarantee. Keep callback work bounded and coordinate shutdown before destroying callback state. These are recommendations rather than requirements established by the header.

### Process Model

No public context or instance handle exists. Whether state is global, per-process, shared across processes, or managed by a separate vendor service is unknown. The header provides C linkage under C++ with `extern "C"`; this is not an IPC or process model.

### Memory Model

The caller supplies and owns fixed request/result containers. Exactly five types carry `struct_size`: `epon_hal_config_t`, `epon_hal_link_stats_t`, `epon_hal_transceiver_stats_t`, `epon_onu_manufacturer_info_t`, and `epon_olt_info_t`. The caller must set it to the compiled `sizeof` of the corresponding type. No size field should be invented for the other structures.

The HAL allocates `epon_llid_list_t.llid_list` for `llid_count` entries and `dpoe_cpe_mac_table_t.cpe_list` for `static_cpe_count + dynamic_cpe_count` entries. The comments explicitly require the caller to free these arrays. The outer containers remain caller-owned. The relevant pointer declarations are:

```c
epon_llid_info_t *llid_list;
dpoe_cpe_mac_entry_t *cpe_list;
```

The allocator, compatible deallocator, empty-table representation, reuse rules, partial-failure ownership, and validity across teardown are unspecified. There is no public release function. Confirm allocator compatibility before assuming standard `free`, and do not assume that deinitialization releases arrays already returned to the caller.

`epon_interface_list_t.interface` is instead an embedded array of `EPON_HAL_MAX_INTERFACES` entries; it is not separately allocated or freed. Validate `interface_count` against this capacity before indexing.

The init pointer is const, but configuration copying and retention duration are undefined. Keeping config and callback code/state valid through vendor-confirmed shutdown is a conservative integration policy. Alarm callback pointer lifetime is unspecified; no ownership transfer is declared. Do not free it or retain the pointer without a stronger vendor agreement.

Consume outputs only after success unless a vendor explicitly documents valid partial results. Character array NUL termination, encoding, truncation, and unavailable-value representation are undefined, so bounded inspection is recommended. `struct_size` does not by itself define compatible size ranges or cross-version write bounds.

### Power Management Requirements

No power-management control operation is declared. The alarm vocabulary includes imminent power loss through `EPON_VENDOR_ALARM_DYING_GASP` and optical-power conditions. Actual detection and hardware power-management behavior are vendor-dependent.

### Asynchronous Notification Model

The three callbacks are fields of `epon_hal_config_t`, installed through `epon_hal_init`; there is no separate registration API. Deinitialization promises to unregister them. Their exact signatures are:

```c
void (*status_callback)(epon_onu_status_t status);
void (*alarm_callback)(const epon_alarm_info_t *alarm_info);
void (*interface_status_callback)(epon_onu_interface_info_t status);
```

| Callback | Declared event/payload | Ownership and execution boundary |
| --- | --- | --- |
| `status_callback` | ONU status enum passed by value when aggregate ONU status changes. | No allocation transfer; dispatch context, ordering, and duplicate delivery are unspecified. |
| `alarm_callback` | Const pointer to tagged alarm data on raise/clear; `alarm_type` selects the union member, `llid` selects scope, and `is_active` distinguishes raised from cleared. | No ownership transfer is declared; pointer lifetime and nullability are unspecified. Treat as borrowed during invocation as a conservative policy. |
| `interface_status_callback` | Interface structure passed by value, separately for each interface change; `name` identifies it and `status` is up/down. | No separate buffer allocation; callback threading and ordering are unspecified. |

All callbacks return `void`; none acknowledges an event or carries a caller-supplied user-data pointer. Queueing, loss, delivery during init/deinit, in-flight callback draining, and invocation ordering are not defined.

The interface-list getter's comment requires the ONU registration notification only after all configured interfaces are `EPON_ONU_INTF_STATUS_LINK_UP`. This is a readiness condition, not a guarantee that individual interface callbacks are invoked before the ONU callback. No polling getter for aggregate ONU status exists; callers receive aggregate status through the callback and poll interface states through `epon_hal_get_interface_list`.

### Blocking calls

`epon_hal_init` documents `EPON_HAL_ERROR_TIMEOUT` when initialization is blocked for more than three minutes. This is the sole stated duration threshold. Other call timeouts, reset completion times, polling intervals, cancellation, and callback delivery deadlines are unspecified.

### Internal Error Handling

Fourteen functions return `epon_hal_return_t`; `epon_hal_get_version` returns a packed `uint32_t` version directly. The complete return vocabulary from the header is:

| Code | Value | Meaning |
| --- | ---: | --- |
| `EPON_HAL_SUCCESS` | 0 | Operation completed successfully. |
| `EPON_HAL_ERROR_INVALID_PARAM` | -1 | Invalid parameter provided. |
| `EPON_HAL_ERROR_NOT_INITIALIZED` | -2 | HAL not initialized. |
| `EPON_HAL_ERROR_HW_FAILURE` | -3 | Hardware operation failed. |
| `EPON_HAL_ERROR_NOT_SUPPORTED` | -4 | Operation not supported. |
| `EPON_HAL_ERROR_TIMEOUT` | -5 | Operation timeout. |
| `EPON_HAL_ERROR_MEMORY` | -6 | Memory allocation failed. |
| `EPON_HAL_ERROR_RESOURCE` | -7 | Resource unavailable. |
| `EPON_HAL_ERROR_CALLBACK_REG` | -8 | Callback registration failed. |
| `EPON_HAL_ERROR_CONFIG` | -9 | Configuration error. |
| `EPON_HAL_ERROR_WRONG_PON_MODE` | -10 | Hardware configured for a different PON mode, such as ITU PON instead of EPON. |
| `EPON_HAL_ERROR` | -11 | General error. |

The per-function inventory reproduces documented `@retval` lists, not verified exhaustive implementation behavior. `EPON_HAL_ERROR_MEMORY`, `EPON_HAL_ERROR_RESOURCE`, and `EPON_HAL_ERROR` exist but have no per-function mapping. In particular, allocation-failure returns and cleanup are not documented for the two allocating getters. No error precedence or failed-output validity rule is defined.

### Persistence Model

No persistence store or durability contract is declared. `epon_hal_factory_reset` restores defaults, clears custom settings and statistics, and requires reinitialization. Which persistent stores are affected and which settings survive ordinary deinitialization are unknown.

`epon_hal_deinit` promises callback unregistration, initialization-resource release, hardware cleanup, and ONU deregistration. After teardown, initialize again before operational use; version checking remains exempt. Callback quiescence, concurrent-call handling, deinit timeout, and state after teardown failure require vendor agreement.

## Hardware and Operational Capabilities

“Declared” here means the interface can represent a value or request an operation, not that all hardware implements it. Detailed field names and units appear in the type inventory.

| Area | Declared capability and evidence | Vendor-dependent or absent behavior |
| --- | --- | --- |
| Optical diagnostics | `epon_hal_transceiver_stats_t`: Tx/Rx power and thresholds in dBm, laser bias in mA, temperature in Celsius, supply voltage in volts. | Sensor presence, sampling, accuracy, calibration, missing values, and threshold provenance; getter may return `NOT_SUPPORTED`. |
| Link telemetry | `epon_hal_link_stats_t`: packet/byte/error/discard counts, maximum bit rate in Mbps, FEC counts, broadcast/multicast counts, ranging resyncs, MAC resets. | Snapshot consistency, counter epoch, rollover, and implementation support. |
| BER | No BER member or getter exists. | FEC corrected bits and uncorrectable codewords are not BER; the header defines no measurement interval or total-bit denominator. |
| Provisioning observations | `epon_onu_status_t`, interface link state, and LLID registration/forwarding state. | No explicit provisioning transaction, registration timer, LLID setter, or retry policy. |
| Link mode and encryption | `epon_hal_link_info_t` reports a mode string and encryption enum; each LLID has an encryption-enabled flag. | Example strings `1G-EPON`/`10G-EPON` are not guaranteed rates; enumerated algorithms do not guarantee hardware support. No key/encryption setter exists. |
| Identity and topology | Manufacturer/model/versions/serial/OUI, registered OLT MAC/OUI, LLIDs, and interface names/statuses. | OLT field availability, interface creation, VLAN/service mapping, and LLID/interface associations. |
| Alarms | Standard and vendor conditions with LLID/device-wide scope and raised/cleared status. | Detection, thresholds, alarm history, acknowledgment, and reliable delivery. |
| DPoE | Static/dynamic CPE MAC inventory, age, counts, and capacity. | No CPE add/delete API or complete DOCSIS provisioning engine. |
| Maintenance | Clear link counters, initiate ONU reset/re-registration, restore defaults, deinitialize. | Recovery timing, reset-time HAL usability, rollback, and affected persistent stores. |

There is no active BER test, optical loopback-test function, laser-control API, firmware-update API, or power-control API. The OAM loopback logging bit selects a log category; it does not enable loopback testing.

## Non-functional requirements

These sections describe declared logging/versioning facilities, existing integration intent, and recommendations. They do not assert measured performance or implemented quality tooling.

### Logging and debugging requirements

`HAL_LOG(level, format, ...)` forwards a printf-style message with `__FUNCTION__` and `__LINE__` to `HAL_LOG_FUNCTION`. The eight levels are fully enumerated below. Define `HAL_LOG_FUNCTION` before including the header to replace the backend where the macro is expanded; a consumer-side override does not reconfigure a prebuilt vendor library.

Without an override, the backend appends to `/rdklogs/logs/EPONMANAGERLog.txt.0`. The source body opens, conditionally writes, and closes the file:

```c
FILE *fp = fopen("/rdklogs/logs/EPONMANAGERLog.txt.0", "a+");
if (fp) {
    fprintf(fp, "[%d][%s:%d] " format "\n", level, func, line, ##__VA_ARGS__);
    fclose(fp);
}
```

This is an excerpt of the macro body, not a standalone function. Opening failure silently produces no output; no write/close error status is exposed. The macro creates no directory and provides no rotation, severity filter, or cross-call synchronization. Including the header alone does not execute it.

`epon_hal_set_oam_log_mask` selects logged message categories using OR-combined `epon_oam_log_type_t` bits. Zero disables OAM logging; `EPON_OAM_ALL` enables all categories. Selected messages use `HAL_LOG_LEVEL_OAM`. The mask changes logging, not protocol processing.

The header assigns organization-specific `0xFE` OAM messages to variable-request/response logging flags and supplies MPCP REGISTER/REGISTER_ACK flags. It describes GATE and REPORT as hardware-handled and unavailable for software logging. These are header statements, not verified protocol-engine behavior. Default mask, unknown-bit handling, filtering, and platform visibility are unspecified.

### Memory and performance requirements

Variable-length allocation sizes depend on `llid_count` and on `static_cpe_count + dynamic_cpe_count`; fixed result structures remain caller-owned. No throughput, memory budget, polling cadence, or snapshot-atomicity guarantee is supplied. Only initialization has a stated timeout condition.

### Quality Control

As integration recommendations, use suitable static analysis, dependency/license analysis, and memory instrumentation, such as Coverity, Black Duck, and Valgrind, on the vendor implementation. Enable compiler warnings and verify allocation/deallocation, callback lifetimes, size handling, failure cleanup, and disruptive reset behavior. These tools and conformance tests are not supplied by this repository.

### Licensing

The public header declares Apache License 2.0. The repository provides [`LICENSE`](../../LICENSE) and [`NOTICE`](../../NOTICE). These links reference existing, resolvable files.

### Build Requirements

The existing integration intent is a vendor `libepon_hal.so` linked to the consuming EPON Manager. Neither the library nor a build system is supplied; the header alone cannot link an application. The header includes `<stdint.h>`, `<stdbool.h>`, and `<stdio.h>`, and provides C linkage under C++.

Compiler/SDK minimums and target ABI are unspecified. The anonymous union, GNU-style `##__VA_ARGS__`, `__FUNCTION__`, and `EPON_OAM_ALL = 0xFFFFFFFF` warrant checking the selected C/C++ compiler mode. No particular compiler configuration is mandated.

### Variability Management

The header declares Semantic Versioning: major changes are incompatible API/ABI changes, minor changes are backwards-compatible additions, and patch changes are backwards-compatible fixes. `EPON_HAL_API_VERSION` is 1.0.0 packed as `0x01000000` in `0xMMmmpppp` format.

The header's compatibility example compares `version >> 24` with `EPON_HAL_API_VERSION >> 24`. This major-byte check does not verify all structure layouts, enum representations, or accepted `struct_size` ranges. The packing macro performs raw shifts and ORs without masking or range checking.

### Platform or Product Customization

Customization surfaces are the initialization DPoE flag, compile-time logging backend override, reported mode/encryption, interface inventory, and returned LLID/CPE capacities. They do not identify a specific platform or guarantee optional functionality. No public mode, encryption, VLAN, or capacity setter is declared.

## Interface API Documentation

### Data Structures and Defines

All public user-defined types are the enum and struct typedefs below; callback pointers are configuration fields, not separately named typedefs. Field names and member values are taken from `epon_hal.h`. No packing attribute or stable byte-size table is provided.

**Enumerations: thirteen.** Each member's numeric value is shown explicitly for clarity, including values implicit in C declaration order. `_MAX` alarm members are sentinels, not reportable alarm conditions.

| Type | Complete members, values, and meaning |
| --- | --- |
| `hal_log_level_t` | `HAL_LOG_LEVEL_FATAL=0`: critical failure; `HAL_LOG_LEVEL_ERROR=1`: error; `HAL_LOG_LEVEL_WARN=2`: warning; `HAL_LOG_LEVEL_NOTICE=3`: significant normal condition; `HAL_LOG_LEVEL_INFO=4`: information; `HAL_LOG_LEVEL_OAM=5`: OAM messages; `HAL_LOG_LEVEL_DEBUG=6`: debugging; `HAL_LOG_LEVEL_TRACE=7`: detailed trace. |
| `epon_hal_return_t` | All 12 members and values are listed under Internal Error Handling, from `EPON_HAL_SUCCESS=0` through `EPON_HAL_ERROR=-11`. |
| `epon_onu_status_t` | `EPON_ONU_STATUS_LOS=0`: PHY down/no signal; `EPON_ONU_STATUS_DOWNSTREAM_SIGNAL_DETECTED=1`: signal present, not registered; `EPON_ONU_STATUS_REGISTRATION=2`: LLID-0 online including MPCP/OAM; `EPON_ONU_STATUS_DEREGISTRATION=3`: LLID-0 offline. |
| `epon_interface_link_status_t` | `EPON_ONU_INTF_STATUS_LINK_DOWN=0`: interface down; `EPON_ONU_INTF_STATUS_LINK_UP=1`: ONU registered and interface up. |
| `epon_hal_alarm_t` | `EPON_HAL_ALARM_LOFI=0`: loss of frame/lock; `EPON_HAL_ALARM_ERROR_SYMBOL_PERIOD=1`: errored-symbol-period threshold; `EPON_HAL_ALARM_ERROR_FRAME=2`: errored-frame threshold; `EPON_HAL_ALARM_ERROR_FRAME_PERIOD=3`: errored-frame-period threshold; `EPON_HAL_ALARM_ERROR_FRAME_SECONDS=4`: errored-frame-seconds threshold; `EPON_HAL_ALARM_OAM_SESSION_LOST=5`: OAM loss; `EPON_HAL_ALARM_EQUIPMENT_FAILURE=6`: equipment failure; `EPON_HAL_ALARM_MAX=7`: sentinel. |
| `epon_vendor_alarm_t` | `EPON_VENDOR_ALARM_LOS=0`: signal loss; `EPON_VENDOR_ALARM_DYING_GASP=1`: imminent power loss; `EPON_VENDOR_ALARM_POWER_LOW=2`: low optical power; `EPON_VENDOR_ALARM_POWER_HIGH=3`: high optical power; `EPON_VENDOR_ALARM_TEMPERATURE=4`: temperature threshold; `EPON_VENDOR_ALARM_FEC_THRESHOLD=5`: uncorrectable-FEC threshold; `EPON_VENDOR_ALARM_LASER_BIAS_CURRENT=6`: bias out of range; `EPON_VENDOR_ALARM_SUPPLY_VOLTAGE=7`: voltage out of range; `EPON_VENDOR_ALARM_MAX=8`: sentinel. |
| `epon_alarm_type_t` | `EPON_ALARM_TYPE_STANDARD=0`: standard IEEE 802.3ah alarm; `EPON_ALARM_TYPE_VENDOR_SPECIFIC=1`: vendor-specific alarm. |
| `epon_oam_log_type_t` | `EPON_OAM_INFO=1<<0`: Information PDU, `0x00`; `EPON_OAM_EVENT=1<<1`: Event Notification, `0x01`; `EPON_OAM_VAR_REQUEST=1<<2`: Variable Request, `0x02`, also organization-specific messages; `EPON_OAM_VAR_RESPONSE=1<<3`: Variable Response, `0x03`, also organization-specific messages; `EPON_OAM_LOOPBACK=1<<4`: Loopback Control, `0x04`; `EPON_OAM_MPCP_REGISTER=1<<5`: REGISTER; `EPON_OAM_MPCP_REGISTER_ACK=1<<6`: REGISTER_ACK; `EPON_OAM_ALL=0xFFFFFFFF`: all categories. |
| `epon_llid_mode_t` | `EPON_LLID_MODE_UNICAST=0`: point-to-point emulation; `EPON_LLID_MODE_BROADCAST=1`: shared broadcast/multicast emulation. |
| `epon_llid_state_t` | `EPON_LLID_STATE_UNREGISTERED=0`: no assignment; `EPON_LLID_STATE_REGISTERING=1`: assignment in progress; `EPON_LLID_STATE_REGISTERED=2`: assigned/registered; `EPON_LLID_STATE_DEREGISTERING=3`: release in progress; `EPON_LLID_STATE_FAILED=4`: registration or link failure. |
| `epon_llid_forwarding_state_t` | `EPON_LLID_FORWARDING_DISABLED=0`: blocked; `EPON_LLID_FORWARDING_ENABLED=1`: traffic allowed; `EPON_LLID_FORWARDING_LEARNING=2`: limited forwarding while learning. |
| `epon_encryption_mode_t` | `EPON_ENCRYPTION_MODE_DISABLED=0`; `EPON_ENCRYPTION_MODE_AES_128=1`; `EPON_ENCRYPTION_MODE_TRIPLE_CHURNING=2`; `EPON_ENCRYPTION_MODE_AES_256=3`. AES-256 is described as a non-standard IEEE 802.3ah extension. Enumeration does not guarantee support or establish standards compliance. |
| `dpoe_cpe_mac_type_t` | `DPOE_CPE_MAC_STATIC=0`: configured; `DPOE_CPE_MAC_DYNAMIC=1`: dynamically learned. |

**Structures: thirteen.** All fields below are in declaration order. The five types with `struct_size` require caller initialization of that member before use.

| Structure | Complete field declarations and interpretation |
| --- | --- |
| `epon_onu_interface_info_t` | `char name[EPON_HAL_INTERFACE_NAME_LEN]`; `epon_interface_link_status_t status`. Interface name, such as `veip0`, and operational up/down state. |
| `epon_alarm_info_t` | `epon_alarm_type_t alarm_type`; anonymous union containing `epon_hal_alarm_t standard_alarm` and `epon_vendor_alarm_t vendor_alarm`; `uint16_t llid`; `bool is_active`. Read only the discriminator-selected union member. `EPON_LLID_NOT_APPLICABLE` denotes a device-wide alarm; true means raised, false cleared. |
| `epon_hal_link_stats_t` | `uint32_t struct_size`; `uint64_t packets_sent`, `packets_received`, `bytes_sent`, `bytes_received`, `errors_sent`, `errors_received`, `discard_packets_sent`, `discard_packets_received`; `uint32_t max_bit_rate`; `uint64_t fec_corrected`, `fec_uncorrectable`, `broadcast_packets_sent`, `broadcast_packets_received`, `multicast_packets_sent`, `multicast_packets_received`, `ranging_resyncs`, `mac_resets`. Units and mappings follow below. |
| `epon_hal_transceiver_stats_t` | `uint32_t struct_size`; `float transmit_optical_level`, `optical_signal_level`, `lower_optical_threshold`, `upper_optical_threshold`, `lower_transmit_power_threshold`, `upper_transmit_power_threshold`, `bias_current`, `temperature`, `supply_voltage`. Units and meanings follow below. |
| `epon_llid_info_t` | `uint16_t llid_value`; `epon_llid_mode_t mode`; `epon_llid_state_t state`; `epon_llid_forwarding_state_t forwarding_state`; `bool encryption_enabled`; `uint8_t local_mac_address[EPON_HAL_MAC_ADDR_LEN]`. LLID identity, mode, registration and forwarding state, encryption flag, and local MAC. Encryption algorithm is reported separately in link info. |
| `epon_llid_list_t` | `uint32_t max_llid_count`, `llid_count`; `epon_llid_info_t *llid_list`. Maximum supported LLIDs, current configured/active count, and HAL-allocated array of that length; caller frees the array. |
| `epon_onu_manufacturer_info_t` | `uint32_t struct_size`; `char manufacturer[EPON_HAL_MANUFACTURER_LEN]`, `model_number[EPON_HAL_MODEL_NUMBER_LEN]`, `hardware_version[EPON_HAL_HW_VERSION_LEN]`, `software_version[EPON_HAL_SW_VERSION_LEN]`, `serial_number[EPON_HAL_SERIAL_NUMBER_LEN]`; `uint8_t vendor_oui[EPON_HAL_VENDOR_OUI_LEN]`. ONU identity; the five strings map to the corresponding TR-181 `Device.DeviceInfo` properties. |
| `epon_hal_link_info_t` | `char mode[EPON_HAL_MODE_LEN]`; `epon_encryption_mode_t encryption`. Current operational mode, with examples `1G-EPON`/`10G-EPON`, and negotiated encryption. Mode vocabulary is not exhaustive. |
| `epon_interface_list_t` | `uint32_t interface_count`; `epon_onu_interface_info_t interface[EPON_HAL_MAX_INTERFACES]`. Returned prefix of an embedded 16-entry array; entries may be link-up or link-down. |
| `epon_olt_info_t` | `uint32_t struct_size`; `uint8_t mac_address[EPON_HAL_MAC_ADDR_LEN]`, `vendor_oui[EPON_HAL_VENDOR_OUI_LEN]`. OLT OAM MAC and vendor OUI learned during registration/OAM discovery. Availability requires registration; OUI availability is implementation-dependent. No specific GATE-message provenance is established. |
| `epon_hal_config_t` | `uint32_t struct_size`; `bool dpoe_supported`; `void (*status_callback)(epon_onu_status_t status)`; `void (*alarm_callback)(const epon_alarm_info_t *alarm_info)`; `void (*interface_status_callback)(epon_onu_interface_info_t status)`. Initialization setting and three callbacks; signatures and lifetime caveats are documented above. |
| `dpoe_cpe_mac_entry_t` | `uint8_t mac_address[EPON_HAL_MAC_ADDR_LEN]`; `dpoe_cpe_mac_type_t type`; `uint32_t age_time`. CPE MAC, static/dynamic classification, and age in seconds; static entries have age zero. |
| `dpoe_cpe_mac_table_t` | `uint32_t max_cpe`, `static_cpe_count`, `dynamic_cpe_count`; `dpoe_cpe_mac_entry_t *cpe_list`. Supported capacity, static/dynamic counts, and HAL-allocated array of their sum; caller frees the array. |

**Link statistics field semantics.** The first nine measurements carry TR-181 mappings in header comments; subsequent measurements are EPON extensions. These annotations do not implement a TR-181 agent.

| Field(s) | Meaning / unit |
| --- | --- |
| `packets_sent`, `packets_received` | Total transmitted/received packets; `PacketsSent` / `PacketsReceived`. |
| `bytes_sent`, `bytes_received` | Total transmitted/received bytes; `BytesSent` / `BytesReceived`. |
| `errors_sent`, `errors_received` | Transmission/reception error counts; `ErrorsSent` / `ErrorsReceived`. |
| `discard_packets_sent`, `discard_packets_received` | Packets discarded before transmission/on reception; `DiscardPacketsSent` / `DiscardPacketsReceived`. |
| `max_bit_rate` | Maximum bit rate in Mbps; `MaxBitRate`, not a counter or current throughput sample. |
| `fec_corrected` | Number of FEC-corrected bits. |
| `fec_uncorrectable` | Number of uncorrectable FEC codewords; not the same unit as corrected bits. |
| `broadcast_packets_sent`, `broadcast_packets_received` | Transmitted/received broadcast packet counts. |
| `multicast_packets_sent`, `multicast_packets_received` | Transmitted/received multicast packet counts. |
| `ranging_resyncs` | Number of ranging resynchronizations. |
| `mac_resets` | Number of MAC resets. |

**Optical statistics field semantics.** Optical levels and thresholds map to TR-181 `Device.Optical.Interface.{i}` properties; the last three measurements are vendor extensions.

| Field(s) | Meaning / unit |
| --- | --- |
| `transmit_optical_level` | Tx optical power, dBm; `TransmitOpticalLevel`. |
| `optical_signal_level` | Rx optical power, dBm; `OpticalSignalLevel`. |
| `lower_optical_threshold`, `upper_optical_threshold` | Lower/upper Rx power thresholds, dBm; `LowerOpticalThreshold` / `UpperOpticalThreshold`. |
| `lower_transmit_power_threshold`, `upper_transmit_power_threshold` | Lower/upper Tx power thresholds, dBm; `LowerTransmitPowerThreshold` / `UpperTransmitPowerThreshold`. |
| `bias_current` | Laser bias current, mA. |
| `temperature` | Module temperature, Celsius. |
| `supply_voltage` | Supply voltage, volts. |

**Macro constants.** Capacities are buffer/array extents, not guaranteed usable string lengths or actual interface populations.

| Macro | Definition / purpose |
| --- | --- |
| `EPON_HAL_VERSION_MAJOR`, `EPON_HAL_VERSION_MINOR`, `EPON_HAL_VERSION_PATCH` | `1`, `0`, `0`. |
| `EPON_HAL_MAKE_VERSION(major, minor, patch)` | `((major << 24) \| (minor << 16) \| (patch))`; no masking or range checks. |
| `EPON_HAL_API_VERSION` | Packing of the three version constants; `0x01000000`. |
| `EPON_HAL_MAC_ADDR_LEN` | `6` bytes; MAC address. |
| `EPON_HAL_VENDOR_OUI_LEN` | `3` bytes; OUI. |
| `EPON_HAL_MANUFACTURER_LEN` | `32` characters; manufacturer buffer. |
| `EPON_HAL_MODEL_NUMBER_LEN` | `16` characters; model buffer. |
| `EPON_HAL_HW_VERSION_LEN`, `EPON_HAL_SW_VERSION_LEN` | `16` characters each; hardware/software version buffers. |
| `EPON_HAL_SERIAL_NUMBER_LEN` | `32` characters; serial buffer. |
| `EPON_HAL_MODE_LEN` | `16` characters; mode buffer. |
| `EPON_HAL_MAX_INTERFACES` | `16` embedded interface slots. |
| `EPON_HAL_INTERFACE_NAME_LEN` | `32` characters; interface-name buffer. |
| `EPON_HAL_OLT_VENDOR_INFO_LEN` | `64`; currently unused by public structure fields. |
| `EPON_LLID_NOT_APPLICABLE` | `0xFFFF`; device-wide alarm LLID sentinel. |
| `HAL_LOG(level, format, ...)` | Logging front end; forwards function and line to the backend. |
| `HAL_LOG_FUNCTION(level, func, line, format, ...)` | Replaceable backend; default stdio file append behavior described above. |
| `_EPON_HAL_H_` | Header include guard, not a feature switch. |

### API Surface

These are the complete function declarations, in header order:

```c
uint32_t epon_hal_get_version(void);
epon_hal_return_t epon_hal_init(const epon_hal_config_t *config);
epon_hal_return_t epon_hal_deinit(void);
epon_hal_return_t epon_hal_get_link_stats(epon_hal_link_stats_t *stats);
epon_hal_return_t epon_hal_get_transceiver_stats(epon_hal_transceiver_stats_t *stats);
epon_hal_return_t epon_hal_get_llid_info(epon_llid_list_t *llid_list);
epon_hal_return_t epon_hal_get_manufacturer_info(epon_onu_manufacturer_info_t *info);
epon_hal_return_t epon_hal_clear_stats(void);
epon_hal_return_t epon_hal_reset_onu(void);
epon_hal_return_t epon_hal_factory_reset(void);
epon_hal_return_t epon_hal_get_link_info(epon_hal_link_info_t *info);
epon_hal_return_t epon_hal_get_interface_list(epon_interface_list_t *if_list);
epon_hal_return_t epon_hal_get_olt_info(epon_olt_info_t *olt_info);
epon_hal_return_t epon_hal_set_oam_log_mask(uint32_t oam_log_mask);
epon_hal_return_t dpoe_hal_get_cpe_mac_table(dpoe_cpe_mac_table_t *cpe_table);
```

In the following table, `SUCCESS` means `EPON_HAL_SUCCESS`, and each error abbreviation is the exact suffix of `EPON_HAL_ERROR_`; for example, `INVALID_PARAM` means `EPON_HAL_ERROR_INVALID_PARAM`. The listed codes are the documented per-function return lists, not proven exhaustive behavior. “Unspecified” in the thread-safety column means no safe concurrent use is promised.

| Function name | Input parameters and output | Documented return codes | Memory ownership | Thread-safety expectations |
| --- | --- | --- | --- | --- |
| `epon_hal_get_version` | No parameters; returns packed API version `uint32_t`. | Version value, not a status code; no error channel documented. | Scalar result; no allocation transfer. | Unspecified. |
| `epon_hal_init` | Input `const epon_hal_config_t *config`; non-null, valid size, DPoE setting, callbacks. | `SUCCESS`, `INVALID_PARAM`, `WRONG_PON_MODE`, `HW_FAILURE`, `CALLBACK_REG`, `TIMEOUT`. | Caller owns config; copying/retention unspecified. HAL manages initialization resources. | Unspecified; repeated/concurrent init undefined. |
| `epon_hal_deinit` | No parameters. | `SUCCESS`, `NOT_INITIALIZED`, `HW_FAILURE`. | HAL releases initialization resources; returned-array cleanup relation unspecified. | Unspecified; in-flight call/callback draining undefined. |
| `epon_hal_get_link_stats` | In/out `epon_hal_link_stats_t *stats`; size is input, measurements are output. | `SUCCESS`, `INVALID_PARAM`, `NOT_INITIALIZED`. | Caller owns the fixed structure. | Unspecified; snapshot atomicity undefined. |
| `epon_hal_get_transceiver_stats` | In/out `epon_hal_transceiver_stats_t *stats`; set size, receive measurements. | `SUCCESS`, `INVALID_PARAM`, `NOT_INITIALIZED`, `NOT_SUPPORTED`. | Caller owns the fixed structure. | Unspecified. |
| `epon_hal_get_llid_info` | In/out `epon_llid_list_t *llid_list`; receives capacity, count, array pointer. | `SUCCESS`, `INVALID_PARAM`, `NOT_INITIALIZED`. | Caller owns container; HAL allocates array, caller frees it. | Unspecified; concurrent table mutation undefined. |
| `epon_hal_get_manufacturer_info` | In/out `epon_onu_manufacturer_info_t *info`; set size, receive identity. | `SUCCESS`, `INVALID_PARAM`, `NOT_INITIALIZED`. | Caller owns the fixed structure. | Unspecified. |
| `epon_hal_clear_stats` | No parameters. | `SUCCESS`, `NOT_INITIALIZED`, `HW_FAILURE`. | No result allocation transfer. | Unspecified; clear/read atomicity undefined. |
| `epon_hal_reset_onu` | No parameters. | `SUCCESS`, `NOT_INITIALIZED`, `HW_FAILURE`. | No result allocation transfer. | Unspecified; reset-time call legality undefined. |
| `epon_hal_factory_reset` | No parameters. | `SUCCESS`, `HW_FAILURE`, `CONFIG`. | No result allocation transfer; internal cleanup details unspecified. | Unspecified; coordinate disruptive use with vendor. |
| `epon_hal_get_link_info` | Output `epon_hal_link_info_t *info`; no size field. | `SUCCESS`, `INVALID_PARAM`, `NOT_INITIALIZED`. | Caller owns the fixed structure. | Unspecified. |
| `epon_hal_get_interface_list` | Output `epon_interface_list_t *if_list`; embedded array, no size field. | `SUCCESS`, `INVALID_PARAM`, `NOT_INITIALIZED`. | Caller owns container and embedded entries; no separate free. | Unspecified; snapshot/callback consistency undefined. |
| `epon_hal_get_olt_info` | In/out `epon_olt_info_t *olt_info`; set size, receive identity. | `SUCCESS`, `INVALID_PARAM`, `NOT_INITIALIZED`, `NOT_SUPPORTED`. | Caller owns the fixed structure. | Unspecified. |
| `epon_hal_set_oam_log_mask` | Input `uint32_t oam_log_mask`; OR flags, zero disables, `EPON_OAM_ALL` enables all. | `SUCCESS`, `NOT_INITIALIZED`, `NOT_SUPPORTED`. | Scalar input; no allocation transfer. | Unspecified; concurrent updates undefined. |
| `dpoe_hal_get_cpe_mac_table` | Output `dpoe_cpe_mac_table_t *cpe_table`; receives counts, capacity, array pointer. | `SUCCESS`, `INVALID_PARAM`, `NOT_INITIALIZED`, `NOT_SUPPORTED`. | Caller owns container; HAL allocates array, caller frees it. | Unspecified; concurrent table mutation undefined. |

### Operational Preconditions and Effects

All pointer-taking functions document `INVALID_PARAM` for null pointers; the five size-bearing calls also document invalid size. Only init additionally mentions invalid configuration values. This does not specify all accepted values or callback nullability.

| HAL call | Preconditions / availability | Declared effect and completion boundary |
| --- | --- | --- |
| `epon_hal_get_version` | Intended before initialization for compatibility checking. | Returns implementation API version; does not initialize hardware. |
| `epon_hal_init` | Non-null valid config and matching `struct_size`; EPON-capable hardware mode. Prior/repeated-init policy unspecified. | Installs callbacks, configures DPoE when enabled, initializes interface mapping. Success is not explicitly registration completion. |
| `epon_hal_deinit` | Initialized HAL; otherwise documents `NOT_INITIALIZED`. | Unregisters callbacks, frees initialization resources, cleans hardware, deregisters ONU; init required before renewed operational use. Failure state and callback draining unspecified. |
| `epon_hal_get_link_stats` | Initialized HAL; non-null output with size set. | Reports current link statistics; no registration prerequisite or freshness guarantee is stated. |
| `epon_hal_get_transceiver_stats` | Initialized HAL; non-null output with size set; optical telemetry available. | Reports measurements/thresholds; unavailable telemetry returns `NOT_SUPPORTED`. |
| `epon_hal_get_llid_info` | Initialized HAL; non-null container. | Reports configured LLIDs and states; allocates array sized by `llid_count`. Empty-result and allocation-failure behavior unspecified. |
| `epon_hal_get_manufacturer_info` | Initialized HAL; non-null output with size set. | Reports ONU identity; no registration prerequisite is stated. |
| `epon_hal_clear_stats` | Initialized HAL. | Zeros link counters, including packet/frame, byte, FEC, and MAC reset counts. Optical power is unaffected. Treatment of non-counter `max_bit_rate` unspecified. |
| `epon_hal_reset_onu` | Initialized HAL. | Deregisters, soft-resets, and initiates MPCP discovery/re-registration; service disruption. Success means reset initiated, not re-registration complete. |
| `epon_hal_factory_reset` | General init-before-operational-use guidance applies; pre-init legality is not expressly resolved and no `NOT_INITIALIZED` retval is listed. | Clears custom settings/statistics and restores defaults; configuration loss/service disruption. Reconfiguration and init required afterward; failure state unspecified. |
| `epon_hal_get_link_info` | Initialized HAL; non-null output. | Reports operational mode and negotiated encryption. Pre-registration field validity is not defined. |
| `epon_hal_get_interface_list` | Initialized HAL; non-null output. | Reports OLT-configured S1/IP interfaces and their current up/down states. Does not create interfaces or configure VLANs. |
| `epon_hal_get_olt_info` | Initialized HAL, successful ONU registration, non-null output with size set. | Returns learned OLT MAC/OUI; `NOT_SUPPORTED` if unavailable/not registered. Per-field validity remains vendor-dependent. |
| `epon_hal_set_oam_log_mask` | Initialized HAL; implementation supports OAM logging. | Updates logging selection at `HAL_LOG_LEVEL_OAM`, never protocol processing. Unknown-bit behavior unspecified. |
| `dpoe_hal_get_cpe_mac_table` | Initialized HAL, non-null container, runtime DPoE support. | Returns static/dynamic entries in an array sized by their count sum; unsupported DPoE returns `NOT_SUPPORTED`. |

### Sequence Diagram

This is an illustrative successful integration sequence, not a hardware trace or guaranteed event order. Internal vendor/hardware exchanges are conceptual; no such function bodies are supplied. Discovery/registration may overlap initialization, and callbacks may occur during calls. The diagram places them after init only for readability. Polling cadence is application/vendor policy, not specified by the HAL.

```mermaid
sequenceDiagram
    participant Caller as RDK-B EPON Manager
    participant HAL as EPON HAL C interface
    participant Vendor as Vendor SoC and driver
    participant ONU as ONU optical hardware
    participant OLT as OLT network peer
    Caller->>HAL: epon_hal_get_version()
    HAL-->>Caller: Packed API version
    Caller->>HAL: epon_hal_init(config with size and callbacks)
    HAL->>Vendor: Set up hardware, callbacks, interface mapping
    Vendor->>ONU: Platform initialization
    Vendor-->>HAL: Initialization result
    HAL-->>Caller: EPON_HAL_SUCCESS
    Note over Caller,OLT: Init success does not guarantee registration completion
    ONU-->>Vendor: Downstream signal observed
    Vendor-->>Caller: status_callback(DOWNSTREAM_SIGNAL_DETECTED)
    ONU->>OLT: MPCP discovery and registration exchange
    OLT-->>ONU: LLID assignment and OAM discovery
    ONU-->>Vendor: Registration and configured interface readiness
    Vendor-->>Caller: interface_status_callback(status) per interface
    Vendor-->>Caller: status_callback(EPON_ONU_STATUS_REGISTRATION)
    Note over Caller,Vendor: Registration notification requires all configured interfaces up. Callback order is unspecified
    Caller->>HAL: epon_hal_get_olt_info(olt_info with size set)
    HAL-->>Caller: EPON_HAL_SUCCESS and available OLT identity
    loop Application-selected telemetry and link-state polling
        Caller->>HAL: epon_hal_get_link_stats(stats with size set)
        HAL->>Vendor: Read link counters
        Vendor-->>HAL: Counter snapshot
        HAL-->>Caller: EPON_HAL_SUCCESS and counters
        Caller->>HAL: epon_hal_get_transceiver_stats(stats with size set)
        HAL-->>Caller: EPON_HAL_SUCCESS or EPON_HAL_ERROR_NOT_SUPPORTED
        Caller->>HAL: epon_hal_get_interface_list(if_list)
        HAL-->>Caller: EPON_HAL_SUCCESS and per-interface states
        opt Independent status or alarm event
            ONU-->>Vendor: Hardware status or alarm change
            Vendor-->>Caller: status_callback or interface_status_callback
            Vendor-->>Caller: alarm_callback(alarm_info) on raise or clear
        end
    end
    opt Service-disrupting ONU reset
        Caller->>HAL: epon_hal_reset_onu()
        HAL->>Vendor: Initiate soft reset and re-registration
        HAL-->>Caller: EPON_HAL_SUCCESS means initiated
        Note over Caller,OLT: Completion, retries, and reset-time usability are vendor-dependent
    end
    Note over Caller,Vendor: Coordinate in-flight work and callback lifetime before shutdown
    Caller->>HAL: epon_hal_deinit()
    HAL->>Vendor: Unregister callbacks and clean up hardware
    Vendor->>ONU: Deregister from OLT and release resources
    Vendor-->>HAL: Teardown result
    HAL-->>Caller: EPON_HAL_SUCCESS
```

`DOWNSTREAM_SIGNAL_DETECTED` in the diagram abbreviates `EPON_ONU_STATUS_DOWNSTREAM_SIGNAL_DETECTED`. The registration notification readiness condition is declared, but ordering of callback invocations is not. Alarm events, loss of signal, deregistration, and interface changes need not occur on every poll.

### State Diagram

The following states are documentation concepts, not a public HAL-state enum. Edges show successful call effects only; failed-call state is unknown. In particular, no self-loop asserting that ONU reset always preserves HAL usability is justified.

```mermaid
stateDiagram-v2
    state "Initialization required" as NeedsInit
    state "Operational HAL use" as Initialized
    [*] --> NeedsInit
    NeedsInit --> Initialized: epon_hal_init returns EPON_HAL_SUCCESS
    Initialized --> NeedsInit: epon_hal_deinit returns EPON_HAL_SUCCESS
    Initialized --> NeedsInit: epon_hal_factory_reset returns EPON_HAL_SUCCESS
```

ONU observations, interface state, and per-LLID state are distinct from HAL initialization. Their declared meanings support the following interpretation without inventing legal transition edges:

| Observation / operation | Interpretation and transition boundary |
| --- | --- |
| `EPON_ONU_STATUS_LOS` | PHY down/no detected signal; not a declaration that HAL is uninitialized. |
| `EPON_ONU_STATUS_DOWNSTREAM_SIGNAL_DETECTED` | Signal present but ONU not registered; next state/timer unspecified. |
| `EPON_ONU_STATUS_REGISTRATION` | LLID-0 online with MPCP/OAM; notification only after all configured interfaces are up. |
| `EPON_ONU_STATUS_DEREGISTRATION` | LLID-0 offline; does not imply deinit or a required automatic retry. |
| Per-LLID `UNREGISTERED`, `REGISTERING`, `REGISTERED`, `DEREGISTERING`, `FAILED` | Observed through `epon_llid_info_t.state`; enum names and meanings do not define an exhaustive transition graph or retry policy. |
| Interface `LINK_DOWN` / `LINK_UP` | Returned in interface snapshots and per-interface callback payloads; not an aggregate ONU status getter. |
| ONU reset | Initiates deregistration, soft reset, and re-registration. Intermediate HAL usability, completion notification, timeout, and rollback unspecified. |
| Factory reset / deinit | Successful completion requires init before renewed operational use. Effects after failure are unspecified. |

## Contract Gaps and Vendor Integration Decisions

These are missing or ambiguous interface contracts, not verified vendor bugs. They require maintainer/vendor agreement before relying on stronger behavior. No C declaration or header comment is changed by this specification update.

| ID | Source location / evidence in `epon_hal.h` | Missing contract or ambiguity |
| --- | --- | --- |
| G01 | All 15 function declarations | No implementation to verify capabilities, validation, hardware behavior, or timing. |
| G02 | Three callback fields in `epon_hal_config_t` | Callback nullability, dispatch thread, serialization, reentrancy, ordering, duplicate/lost events, user-state association. |
| G03 | `alarm_callback(const epon_alarm_info_t *)` | Payload lifetime, nullability, copy/retention rules; const does not transfer ownership. |
| G04 | `epon_hal_init(const epon_hal_config_t *)` | Config retention, repeated init, registration completion criterion, partial-failure cleanup, retry legality. |
| G05 | `epon_hal_deinit` cleanup comments | In-flight-call handling, callback draining, timeout, failure state, returned-array cleanup ordering. |
| G06 | Allocated `llid_list` and `cpe_list` | Allocator/deallocator pairing, empty-table representation, count limits, reuse, and partial-failure ownership. No release API exists. |
| G07 | Five `struct_size` members | Accepted older/newer sizes, layout compatibility, validation ranges, and write bounds. |
| G08 | Fixed character arrays | NUL termination, encoding, truncation, and unavailable-value policy. |
| G09 | Link statistics and `epon_hal_clear_stats` | Counter epochs, rollover, snapshot/clear atomicity, and treatment of `max_bit_rate`. No BER contract exists. |
| G10 | Optical float fields | Missing-sensor representation, accuracy, freshness, calibration, and threshold provenance. |
| G11 | Interface array/count and registration note | Overflow handling, returned/configured population, zero-interface readiness, LLID/interface mapping, callback ordering. |
| G12 | Factory reset requires init but omits `NOT_INITIALIZED` | Pre-init legality, persistent stores, callback survival, whether deinit is also needed, and post-failure state. |
| G13 | Reset success means initiation | Completion/progress indication, retry/timeout policy, concurrent-call legality, and reset-time initialized-state usability. |
| G14 | Return enum versus per-function `@retval` lists | `MEMORY`, `RESOURCE`, and general error have no per-function mapping. Allocation failures, failed-output validity, error precedence, and cleanup are unresolved. |
| G15 | `dpoe_supported` and unconditional DPoE declarations | Runtime setting versus actual support; whether disabling the setting forces unsupported behavior. |
| G16 | Version packing and major-byte comparison | Valid component ranges, minor/patch compatibility, enum/structure ABI policy. |
| G17 | OAM mask setter and categories | Default mask, unknown/reserved-bit handling, logging visibility, filtering and persistence. |
| G18 | Default stdio logging macro | Error reporting, rotation/filtering policy, directory requirements, and concurrent log behavior. |

The current header already uses the correct lifecycle function names, describes actual counter fields rather than BER, supplies three callbacks, and documents the default file logger. This page follows those declarations rather than retaining older prose about guaranteed singleton state, immediate returns, OLT MAC provenance from GATE messages, or guaranteed initialized-state preservation during ONU reset.

## Validation Boundary

Documentation checks can verify declaration/type/member coverage, prototype transcription, Markdown heading structure, relative-link targets, Mermaid syntax, and preservation of the README symlink and header contents. They cannot establish library linkage, vendor thread safety, MPCP/OAM conformance, callback timing, optical accuracy, or hardware behavior.

Before deployment, validate the selected vendor library and target equipment against the per-function contracts, including unsupported features, size handling, returned-array release, registration readiness, disruptive resets, and shutdown quiescence. These are integration recommendations, not tests or implementation guarantees supplied by this repository.
