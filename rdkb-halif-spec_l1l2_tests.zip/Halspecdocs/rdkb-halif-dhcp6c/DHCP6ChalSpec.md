# DHCPv6 Client HAL Specification

## Scope and evidence

[dhcp6cApi.h](../../include/dhcp6cApi.h) exposes retrieval of E-Router and embedded cable modem (ECM) DHCPv6 snapshots. It declares no start, stop, renew, release, configuration, initialization, or subscription API. HAL means Hardware Abstraction Layer; DHCP means Dynamic Host Configuration Protocol.

Header declarations and comments are the evidence for this specification. Vendor architecture below is conceptual, not proof of a particular DHCP client daemon or transport.

## Architecture

~~~mermaid
flowchart TD
    C["RDK-B caller"] --> H["dhcp6cApi.h"]
    H --> V["Vendor snapshot implementation"]
    V --> D["Existing E-Router or ECM DHCPv6 state"]
~~~

## Complete API inventory

| Exact declaration | Output |
| --- | --- |
| `int ert_dhcp6c_get_info(dhcp6cInfo_t *pInfo);` | Current E-Router client information in caller storage. |
| `int ecm_dhcp6c_get_info(dhcp6cInfo_t *pInfo);` | Current ECM client information in caller storage. |

Comments name `STATUS_SUCCESS` and `STATUS_FAILURE`, but this header defines neither symbol nor its numeric value. Do not silently assign a `0/-1` ABI from another header.

## Complete type and constant inventory

`IPV6_ADDR_SIZE = 16`; `MAX_IPV6_ADDR_LIST_SIZE = 3`. The only public data type is `dhcp6cInfo_t`, with all fields listed below in declaration order.

| Fields | Declared representation and meaning |
| --- | --- |
| `ifname` | `char[32]`, interface name. |
| `smState` | `int`, state-machine state; values not enumerated. |
| `configAttemps` | `int`, configuration attempts; spelling is part of the declaration. |
| `ipAddr`, `prefix`, `gw`, `dhcpServer` | Each `unsigned char[IPV6_ADDR_SIZE]`; binary address, prefix, gateway, and server. These are not textual IPv6 strings. |
| `t1`, `t2` | `unsigned int`, renewal and rebinding time. |
| `leaseTime`, `leaseGotTime` | `unsigned int`, total lease duration and acquisition timestamp. |
| `remainLeaseTime`, `remainRenewTime`, `remainRebindTime` | `unsigned int`, remaining durations. |
| `numOfDns` | `int`, valid DNS address count. |
| `dnsAddrList` | `unsigned char[MAX_IPV6_ADDR_LIST_SIZE][IPV6_ADDR_SIZE]`, at most three binary DNS addresses. |

No enums, callback types, public variables, or release functions are declared.

## Lifecycle and sequence

A caller allocates `dhcp6cInfo_t`, retrieves the needed role's snapshot, checks the implementation-agreed success value, and consumes it. The caller does not create a DHCP client through this HAL. Either getter may be used independently; there is no required E-Router-before-ECM ordering.

~~~mermaid
sequenceDiagram
    participant C as Caller
    participant H as Vendor HAL
    C->>H: ert_dhcp6c_get_info(pInfo)
    H-->>C: int status; E-Router snapshot on success
    opt ECM information needed
        C->>H: ecm_dhcp6c_get_info(pInfo)
        H-->>C: int status; ECM snapshot on success
    end
~~~

State values are observations, not a declared transition table. A successful snapshot call does not itself prove that an address or lease is active.

## Ownership, errors, threading, and timing

- Caller owns the entire output struct; fixed arrays require no separate release. Bound `numOfDns` to the declared capacity before indexing and validate interface-name termination before treating it as a string.
- Null handling, partial output on failure, snapshot atomicity, stale-data indication, lease-infinity encoding, and timestamp epoch are not defined.
- No callbacks or event registration exist. Polling cadence is caller policy.
- The header provides no thread-safety, multi-process, timeout, cancellation, or nonblocking guarantee. Serialize calls until the vendor contract establishes safe concurrency; do not equate synchronous return with bounded latency.
- There is no power-management or persistence control. Read-only declarations do not specify the daemon's own persistence behavior.

## Integration and delivery policy

Existing project guidance expects Linux/Yocto support, Apache License 2.0 implementation, and shared library `libdhcp6cApi.so`. Use the public header and that linker dependency. Controlled semantic versioning remains policy, not a declared version query.

Callers manage output storage; vendors clean up internal resources and coordinate access by multiple processes. No numeric footprint or response deadline has been assigned. Favor bounded operations and preserve main-loop responsiveness without claiming an asynchronous ABI.

Route timestamped syslog diagnostics to `dhcp6c_vendor_hal.log` under `/var/tmp/` or `/rdklogs/logs/`. Project FATAL/TRACE labels require mapping to actual syslog priorities. Avoid exposing network identifiers unnecessarily. Static analysis, license/dependency review, and memory analysis remain quality guidance, not work performed by this documentation update.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| DHCP6-GAP-01 | Getter comments reference undefined status macros: establish authoritative numeric return values. |
| DHCP6-GAP-02 | `smState` is an unenumerated integer: define states and unavailable-client representation. |
| DHCP6-GAP-03 | Time fields have no explicit units, epoch, rollover, or infinity contract. |
| DHCP6-GAP-04 | `prefix[16]` has no prefix-length field; clarify how prefix length is conveyed. |
| DHCP6-GAP-05 | Define snapshot consistency, DNS count validation, name termination, and failure-output validity. |
| DHCP6-GAP-06 | No concurrency or timing contract is declared; specify deadlines and process coordination. |
