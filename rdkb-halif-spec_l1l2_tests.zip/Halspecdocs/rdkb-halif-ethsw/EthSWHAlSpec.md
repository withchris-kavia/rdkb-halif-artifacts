# Ethernet Switch HAL Specification

## Version History

| Date | Comment | Version |
| --- | --- | --- |
| 2024-08-13 | Initial release. Ethernet Switch HAL header migrated to GitHub. | 1.0.0 |
| 2024-09-16 | Header corrections: a stray comment terminator removed, and `CcspHalExtSw_getCurrentWanHWConf()` placed behind `FEATURE_RDKB_AUTO_PORT_SWITCH`. | 1.0.1 |
| 2024-09-25 | `ETH_5_PORTS` added to the `ETHWAN_DEF_INTF_NUM` ladder (`pri#7`, `RDKCOM-5064`). | 1.1.0 |
| 2026-08-24 | Specification reorganized around the canonical RDK-B HAL topics. | 1.1.0 |
| Current consolidation | Documentation-only reconciliation against the checked-in public header: complete API/type inventory, architecture and lifecycle diagrams, and explicit separation of declared contracts, integration policies, and unresolved gaps. No C interface version change. | 1.1.0 |

## Acronyms

| Acronym | Meaning |
| --- | --- |
| API | Application Programming Interface |
| CCSP | Common Component Software Platform |
| ETHSW / HAL | Ethernet Switch / Hardware Abstraction Layer |
| LAN / WAN | Local Area Network / Wide Area Network |
| MAC | Media Access Control |
| MoCA | Multimedia over Coax Alliance |
| PHY | Physical Layer transceiver |
| QoS | Quality of Service |
| RDK-B | Reference Design Kit for Broadband |
| SDK / SoC | Software Development Kit / System on Chip |
| SLA | Service Level Agreement |
| VLAN / WLAN | Virtual Local Area Network / Wireless Local Area Network |

## Description and Source of Truth

The Ethernet Switch HAL separates the CCSP Ethsw Agent / upper RDK-B stack from
vendor-specific switch control. Its authoritative public C interface is
[`include/ccsp_hal_ethsw.h`](../../include/ccsp_hal_ethsw.h).

This document inventories **20 function declarations** across all feature configurations:
**18 unconditional functions and 2 feature-gated functions**, plus **5 enums,
3 structures, and 3 callback typedefs**. Callback typedefs are not additional callable
HAL entry points.

The following evidence labels apply throughout:

- **Declared contract**: a declaration, constant, member, or behavior explicitly described
  in the checked-in header. A declaration alone is not proof of implementation on a product.
- **Integration policy / recommendation**: operational guidance in this specification,
  including retained runtime and nonfunctional expectations. It is not an additional
  guarantee made by the C header.
- **Vendor-dependent / unspecified**: behavior that must be established for the selected
  implementation, or a gap for which this header provides no portable contract.

The header's file-level description mentions VLAN management, bridging, and link
aggregation. **There are no public VLAN membership/tagging, bridge configuration, trunk/access
mode, or link-aggregation configuration functions in this header.** Do not interpret that
description, or a reported VLAN ID, as a programmable capability.

### Source Traceability and Verification Boundary

The reviewed public-header SHA-256 is
`b87579a3f08383570252b6c30cf04ac72902f3934a472c5a35e9349ffbb0141e`.
This identifies the source reviewed for this consolidation, not a runtime ABI
negotiation mechanism. Reconcile the inventory and this digest whenever the header changes.

| Source anchor in `ccsp_hal_ethsw.h` | Specification coverage | Evidence boundary |
| --- | --- | --- |
| `ETHSW_HAL_TYPES`, `_CCSP_HAL_ETHSW_PORT`, and the four other enum declarations | Data Structures and Defines; port-numbering table | Enumerated choices are not hardware capability discovery. |
| `_CCSP_HAL_ETH_STATS`, `_eth_device`, `__appCallBack`, and three callback typedefs | Complete field and callback tables; Memory Model | Width, ownership, and callback lifetime gaps remain explicit. |
| `ETHSW_HAL_APIS` and all 20 function declarations | Four API Surface tables, totaling 7 + 4 + 6 + 3 functions | Includes feature-gated declarations; does not assert vendor symbol availability. |
| `FEATURE_RDKB_WAN_MANAGER`, `FEATURE_RDKB_AUTO_PORT_SWITCH`, and `ETHWAN_DEF_INTF_NUM` | Platform or Product Customization | Compile-time presence and defaults are separate from runtime support. |
| Header comments on allocation, admin status, interface-name size, and WAN results | Memory Model; Internal Error Handling; G02, G05, G06, G11 | Contradictions are preserved and surfaced, not silently repaired. |
| File-level VLAN, bridging, and aggregation description | Operational Capabilities; lifecycle platform lane; G01 | Introductory intent has no corresponding configuration API. |

This is a source-reviewed interface specification. It does not certify a vendor
shared library, physical forwarding, event delivery, thread safety, or device behavior.
Compile-only contract probes cannot supply that runtime evidence. Product acceptance
must separately verify the selected ABI/feature profile, direct HAL behavior, and
externally observed forwarding/isolation where applicable.

To repeat this consolidation for another workspace repository, use the
[workspace specification workflow](../../../.kavia/workflows/recreate-component-spec.md)
and its linked template. The workflow updates one selected canonical document at a
time and preserves README symlinks rather than replacing them.

## Architecture

~~~mermaid
flowchart TD
    Stack["CCSP Ethsw Agent / Upper Stack"]
    HAL["Ethsw HAL Interface: ccsp_hal_ethsw.h"]
    Vendor["Vendor Switch Driver / SDK and HAL implementation"]
    Physical["Physical Ethernet Switch and Ports: LAN / WAN"]
    Stack -->|"Declared C APIs"| HAL
    HAL -->|"Vendor implementation maps calls"| Vendor
    Vendor -->|"Hardware control and observation"| Physical
    Physical -.->|"Link and device observations"| Vendor
    Vendor -.->|"Registered callbacks through HAL"| Stack
~~~

The HAL is an interface boundary, not a driver implementation supplied by this header.
A vendor adapter translates the declared operations into SDK/driver accesses; register
layout, PHY control, forwarding behavior, event detection, and hardware capabilities
remain product-specific. The dashed path represents asynchronous notification via the
registered function pointers, not a separate public event API.

The existing integration packaging convention is a vendor-supplied `libhal_ethsw.so`
consumed by the upper stack, commonly `CcspEthAgent`. That library name and deployment
choice are specification-level integration expectations, not symbols defined in the header.

## Operational Capabilities

| Capability | Declared interface or data | Scope and limitations |
| --- | --- | --- |
| Switch initialization | `CcspHalEthSwInit()` | Sets up HAL resources/configuration. No separate port initializer, readiness query, reset, or deinitializer is declared. |
| Live port state | `CcspHalEthSwGetPortStatus()` | Returns link rate, duplex mode, and link status for a `CCSP_HAL_ETHSW_PORT`. Link detection and update latency are vendor-dependent. |
| Configured speed and duplex | `CcspHalEthSwGetPortCfg()`, `CcspHalEthSwSetPortCfg()` | Read/write configured enum values. Enum availability does not advertise supported hardware combinations or rates. |
| Administrative state | `CcspHalEthSwGetPortAdminStatus()`, `CcspHalEthSwSetPortAdminStatus()` | Read/write Up, Down, or Test. The setter comment contradicts enum values; see Contract Gaps. No normative state-transition graph is declared. |
| Forwarding-table maintenance | `CcspHalEthSwSetAgingSpeed()`, `CcspHalEthSwLocatePortByMacAddress()` | Set vendor-specific aging speed and locate a MAC in MoCA/Ethernet MAC tables. No aging readback or table enumeration/flush API. |
| Packet counters / statistics | `CcspHalEthSwGetEthPortStats()` and `CCSP_HAL_ETH_STATS` | Tx/Rx bytes, packets, errors, discards/drops, unicast, multicast, broadcast, and unknown-protocol reception. Snapshot atomicity, reset, rollover, and sampling semantics are unspecified. |
| Associated clients | `CcspHalExtSw_getAssociatedDevice()` and association callback | Enumerate or receive device details, including reported VLAN ID and active state. No snapshot/event consistency protocol. |
| Ethernet WAN selection | WAN enable/port APIs and feature-gated configuration APIs | Select a zero-based WAN port, enable/disable WAN, and optionally configure by interface name. Switching effects on VLANs, bridges, connectivity, and rollback are unspecified. |
| WAN link observation | `GWP_GetEthWanLinkStatus()`, `GWP_RegisterEthWan_Callback()` | Poll the current WAN link or register separate up/down callbacks. No generic per-port link callback is declared. |
| VLAN port membership, isolation, tagging | Only `eth_device_t.eth_vlanid` is exposed | This is reported device metadata, not a membership table, PVID, tag policy, or setter. Provision isolation/tagging outside this HAL using a separately documented platform mechanism. |
| Trunk/access mode | No declaration | Neither VLAN trunk/access configuration nor link aggregation is exposed. Do not assume either from the header's introductory text. |

## Component Runtime Execution Requirements

### Initialization and Startup

**Declared contract:** `CcspHalEthSwInit(void)` initializes the Ethernet Switch HAL and
returns `RETURN_OK` or `RETURN_ERR`. The header does not define idempotency, startup
ordering relative to other calls, retry safety, per-port startup, or a maximum wait.

**Integration policy:** initialize once during normal startup and use the interface only
after success. Stop the dependent startup path on failure; establish vendor recovery
and retry behavior rather than assuming that another initialization resets the hardware.
The older specification warned that initialization can wait for hardware readiness.
Treat this as a deployment consideration to verify, not a header-defined blocking exception.

### Threading and Process Model

**Header limitation:** no function or callback declaration specifies thread safety,
reentrancy, locking, callback execution context, or cross-process coordination.

**Retained integration policy:** upper-layer clients should serialize HAL calls, including
registrations. The previous specification required safe multi-process access through
vendor-side protection; retain that as an implementation expectation to validate on each
product, not as proof that an arbitrary vendor library supports concurrent callers.

All API-table entries marked **T** inherit these caveats. Registration entries marked
**T/E** also inherit the asynchronous-event caveats below. Do not call back into the HAL
while holding the same serialization lock that a notification may need. A conservative
callback copies needed data and queues work to the serialized HAL owner; it does not
assume that calling getters directly from a callback is reentrant or deadlock-free.
Process-local locking alone cannot serialize independent processes.

### Memory Model

The API tables use the following ownership vocabulary:

- **Caller storage**: the caller supplies a writable output object/buffer or an input
  object valid for the call. No allocation transfer is documented for ordinary scalar,
  statistics, MAC-address, or interface-name parameters. Pointer retention is not
  generally specified; confirm any longer-lived use with the vendor.
- **HAL allocation to caller**: `CcspHalExtSw_getAssociatedDevice()` explicitly allocates
  the returned device array in the HAL and makes the caller responsible for freeing it.
  The allocator and matching deallocator are unspecified; no release API is declared.
  Confirm the vendor's deallocator before use rather than assuming `free()` is portable.
- **Registration lifetime**: function pointers must remain callable while delivery is
  possible. `GWP_RegisterEthWan_Callback()` does not state whether it copies `appCallBack`
  or retains its pointer. Conservatively keep the object and callback code alive until
  vendor-specific quiescence is established.
- **Callback payload**: the owner and lifetime of `eth_device_t *eth_dev` are unspecified.
  Do not free or retain that pointer without an explicit vendor agreement. Copy needed
  fields during the callback if the vendor confirms validity for that invocation.

Provide non-null, correctly sized objects for required pointers. Unless explicitly
documented otherwise, outputs after an error, partial allocations, and failure-side
cleanup obligations are **unspecified**. Initializing the device-array pointer to null
and its count to zero is prudent, but does not define the HAL's failure behavior; agree
how any non-null allocation returned on error is released.

For `GWP_GetEthWanInterfaceName()`, pass the actual buffer capacity in `maxSize`; the
documented minimum is 64 bytes, despite a conflicting 32-byte macro and a documented
`maxSize` range of 11 to 262. Pending clarification, a capacity of at least 64 and at
most 262 satisfies both numeric constraints. Check success and bounded string
termination before use. Pre-zeroing alone does not guarantee termination if every
byte is overwritten. No maximum associated-device count or memory footprint is specified.

### Asynchronous Notification Model

There are two independent notification paths:

| Path | Registration | Event information | Missing guarantees |
| --- | --- | --- | --- |
| Ethernet client association/disassociation | `CcspHalExtSw_ethAssociatedDevice_callback_register()` | `eth_device_t *`, including `eth_Active` (online/offline), port, MAC, VLAN ID, and vendor-specific rates. Callback returns `RETURN_OK` / `RETURN_ERR`. | Payload lifetime, initial delivery, event ordering, duplicate/lost events, callback-return handling, and association-to-active-state timing. |
| Ethernet WAN link changes | `GWP_RegisterEthWan_Callback()` | Separate `fpEthWanLink_Up` and `fpEthWanLink_Down` functions, with no documented payload and no result. | Port/interface identity, event timestamp, delivery context, and relationship to the polled link state. |

Both registration functions return `void`. Registration failure cannot be detected from a
return code. There is no declared unregister, registration handle, callback-drain operation,
or replay/resynchronization facility. Behavior on null callbacks, repeat registration,
multiple subscribers, callback errors, and events concurrent with registration or process
shutdown is unspecified. The checked-in header contains no callback `execution` annotation.

Notifications can complement polling; the header does not promise that they replace it
losslessly. A recommended integration pattern is to register, obtain an initial snapshot,
then reconcile queued events with fresh observations. This does not eliminate races:
there is no atomic register-and-snapshot or generation identifier in the contract.
Defer follow-up HAL queries to the serialized owner instead of assuming callback reentrancy.
For all-port link monitoring use `CcspHalEthSwGetPortStatus()` polling; the WAN callbacks
are not a generic switch-port subscription.

### Blocking Calls and Timeout Handling

The header defines no synchronous-call deadline, cancellation interface, timeout argument,
or distinct timeout error. Synchronous getters/setters return a result, while callback
delivery is asynchronous with unspecified timing.

**Retained integration policy:** keep normal calls responsive and avoid blocking the main
event loop; measure worst-case initialization and SDK/driver latency on the product.
An upper-layer watchdog does not itself cancel a blocked C call. Use an appropriate
supervised execution boundary if a hard response deadline is required; do not terminate
a thread inside vendor code or free in-use resources merely because a timer expired.

### Internal Error Handling

Unless an API row states otherwise, the documented result is `RETURN_OK` (default 0)
on success or `RETURN_ERR` (default -1) on failure. These guarded macros may be defined by
the including environment. No typed error enumeration or portable `NOT_SUPPORTED`
result is declared. Invalid pointers/ports, allocation failures, and driver failures
therefore cannot in general be distinguished by the result alone.

Exceptions must not be interpreted as generic status codes:

- `GWP_GetEthWanLinkStatus()` returns **1 for up, 0 for down, and a negative value for
  error**; the header directs the caller to check `errno`, without enumerating its values.
  Zero is a successful down-state observation, not generic operation success.
- `CcspHalExtSw_getCurrentWanHWConf()` returns `BOOLEAN`: `TRUE` means WAN configuration,
  `FALSE` means LAN configuration. There is no separate failure channel.
- The two callback-registration APIs return `void`, so their registration errors are not
  reported through the interface.
- The association callback returns `INT` success/error; how the HAL responds to a callback
  error, including any retry, is unspecified. WAN link callbacks return `void`.

Check return codes before using outputs. Setter failure does not guarantee rollback or an
unchanged switch. Read back exposed configuration where useful and consult vendor
diagnostics; aging speed has no getter. Avoid claiming that a successful write alone proves
physical link convergence, traffic forwarding, VLAN isolation, or persistence.

### Persistence, Power Management, and Shutdown

There is no declared persistence, suspend/resume, power-management, or shutdown API.
A normal administrative-down setting is not a resource-release or power-management call.
Initialization retry, behavior after reboot, and retention of configuration depend on
the vendor/product; revalidate and reapply required configuration under product policy.

**Shutdown recommendation:** stop new HAL work and polling, coordinate with the platform
to quiesce event production and in-flight callbacks, and only then release caller resources.
The public header provides no portable way to perform or acknowledge that quiescence.
Do not treat registering null pointers as a supported unregister, free a potentially
retained callback object early, or unload callback code while delivery is possible.
Vendor driver cleanup belongs to the vendor/platform lifecycle, not an invented
`CcspHalEthSwDeinit()` entry point.

## Interface API Documentation

### Theory of Operation and Key Concepts

Use separate queries for separate facts: administrative state is requested configuration;
link state is an observation; configured speed/duplex need not equal the live rate/mode.
The header does not define convergence timing or all results while a link is down.
`LINK_NULL` and `Auto` are enum values, not capability discovery or evidence that any
particular speed/duplex combination is supported.

Port numbering is deliberately not normalized in this document:

| Context | Declared numbering | Integration consequence |
| --- | --- | --- |
| Port-scoped `CcspHalEthSw*` APIs | `CCSP_HAL_ETHSW_PORT`, starting at 1 and including non-Ethernet identifiers | Enum presence does not prove a physical port exists. Do not pass sentinels as ports. |
| WAN port getters/setters and default | Zero-based `UINT`, documented range 0 to `MaxEthPort - 1` | `MaxEthPort` is not defined here. Obtain the implemented count and mapping from the platform. |
| `eth_device_t.eth_port` | Zero-based external port, 0 to `MaxEthPort - 1` | It is not a `CCSP_HAL_ETHSW_PORT` value. |
| `CcspHalEthSwLocatePortByMacAddress()` output | 0 denotes MoCA; 1–4 denote Ethernet | Do not generalize this range to all eight Ethernet enumerators or equate 0 with WAN port zero. |
| Interface-name configuration | `char *ifname` | No portable mapping from name to enum, external index, or WAN index is declared. |

No conversion API is provided. The actual product mapping, supported ports, and handling
of unsupported values must be established with the vendor.

### Data Structures and Defines

All names and values below come from
[`ccsp_hal_ethsw.h`](../../include/ccsp_hal_ethsw.h). Implicit enum values are shown as
their C declaration-order values, not as hardware register encodings.

#### Constants and C Type Macros

| Macro | Default definition | Contract note |
| --- | --- | --- |
| `UP`, `DOWN` | `"up"`, `"down"` | String constants; no API in this header returns a string-valued link status using them. |
| `ULONG`, `ULLONG` | `unsigned long`, `unsigned long long` | Guarded type macros, not fixed-width typedefs. `unsigned long` width is ABI-dependent. |
| `CHAR`, `UCHAR` | `char`, `unsigned char` | Guarded type macros. |
| `BOOLEAN`, `INT`, `UINT` | `UCHAR`, `int`, `unsigned int` | Guarded type macros; include-environment overrides affect the ABI. |
| `TRUE`, `FALSE`, `ENABLE` | 1, 0, 1 | Guarded numeric macros; `ENABLE` does not have a matching declared `DISABLE` macro. |
| `RETURN_OK`, `RETURN_ERR` | 0, -1 | Guarded success/failure constants for status-returning calls. |
| `ETHWAN_DEF_INTF_NUM` | See compile-time ladder below | Guarded zero-based default, not a runtime query or port count. |
| `ETHWAN_INTERFACE_NAME_MAX_LENGTH` | 32 | Guarded constant; its comment references `GetEthWanInterfaceName`, which is not a declared function. The actual `GWP_GetEthWanInterfaceName()` takes `maxSize` and documents a minimum 64-byte buffer. |
| `__CCSP_HAL_ETHSW_H__` | Header include guard | Prevents repeat inclusion; not a runtime capability. |

These type names are tested with `#ifndef`, which detects macros, not pre-existing C
typedefs. Integration must keep macro/type definitions consistent across caller and vendor.
No packed layout, fixed-width ABI, or enum storage size is specified.

#### Enumerations

| Type (tag) | Enumerators and numeric values | Meaning / caveat |
| --- | --- | --- |
| `CCSP_HAL_ETHSW_PORT` (`_CCSP_HAL_ETHSW_PORT`) | `CCSP_HAL_ETHSW_EthPort1` = 1, `CCSP_HAL_ETHSW_EthPort2` = 2, `CCSP_HAL_ETHSW_EthPort3` = 3, `CCSP_HAL_ETHSW_EthPort4` = 4, `CCSP_HAL_ETHSW_EthPort5` = 5, `CCSP_HAL_ETHSW_EthPort6` = 6, `CCSP_HAL_ETHSW_EthPort7` = 7, `CCSP_HAL_ETHSW_EthPort8` = 8 | Ethernet identifiers; not a product port-count advertisement. |
| Same port enum | `CCSP_HAL_ETHSW_Moca1` = 9, `CCSP_HAL_ETHSW_Moca2` = 10 | MoCA identifiers. |
| Same port enum | `CCSP_HAL_ETHSW_Wlan1` = 11, `CCSP_HAL_ETHSW_Wlan2` = 12, `CCSP_HAL_ETHSW_Wlan3` = 13, `CCSP_HAL_ETHSW_Wlan4` = 14 | WLAN identifiers. |
| Same port enum | `CCSP_HAL_ETHSW_Processor1` = 15, `CCSP_HAL_ETHSW_Processor2` = 16, `CCSP_HAL_ETHSW_InterconnectPort1` = 17, `CCSP_HAL_ETHSW_InterconnectPort2` = 18 | Processor/interconnect identifiers. |
| Same port enum | `CCSP_HAL_ETHSW_MgmtPort` = 19, `CCSP_HAL_ETHSW_PortMax` = 20 | Despite its name, the header calls `MgmtPort` a maximum/not-valid-port value; `PortMax` is also described as a maximum. Neither establishes a physical port count. |
| `CCSP_HAL_ETHSW_LINK_RATE` (`_CCSP_HAL_ETHSW_LINK_RATE`) | `CCSP_HAL_ETHSW_LINK_NULL` = 0, `CCSP_HAL_ETHSW_LINK_10Mbps` = 1, `CCSP_HAL_ETHSW_LINK_100Mbps` = 2, `CCSP_HAL_ETHSW_LINK_1Gbps` = 3, `CCSP_HAL_ETHSW_LINK_2_5Gbps` = 4, `CCSP_HAL_ETHSW_LINK_5Gbps` = 5, `CCSP_HAL_ETHSW_LINK_10Gbps` = 6, `CCSP_HAL_ETHSW_LINK_Auto` = 7 | No link, 10/100 Mbps, 1/2.5/5/10 Gbps, and autonegotiation. Numeric enum values are not Mbps. No supported-rate bitmap is declared. |
| `CCSP_HAL_ETHSW_DUPLEX_MODE` (`_CCSP_HAL_ETHSW_DUPLEX_MODE`) | `CCSP_HAL_ETHSW_DUPLEX_Auto` = 0, `CCSP_HAL_ETHSW_DUPLEX_Half` = 1, `CCSP_HAL_ETHSW_DUPLEX_Full` = 2 | Auto, half duplex, full duplex. No per-speed duplex-capability query. |
| `CCSP_HAL_ETHSW_LINK_STATUS` (`_CCSP_HAL_ETHSW_LINK_STATUS`) | `CCSP_HAL_ETHSW_LINK_Up` = 0, `CCSP_HAL_ETHSW_LINK_Down` = 1, `CCSP_HAL_ETHSW_LINK_Disconnected` = 2 | Up, down, disconnected. The header does not precisely distinguish down from disconnected or define transitions. **Enum zero means up**, unlike the WAN polling result. |
| `CCSP_HAL_ETHSW_ADMIN_STATUS` (`_CCSP_HAL_ETHSW_ADMIN_STATUS`) | `CCSP_HAL_ETHSW_AdminUp` = 0, `CCSP_HAL_ETHSW_AdminDown` = 1, `CCSP_HAL_ETHSW_AdminTest` = 2 | Enabled, disabled, test. Setter prose reverses 0/1; use named enum constants and verify vendor behavior rather than copying that prose. Test-mode effects are unspecified. |

The corresponding pointer typedefs are `PCCSP_HAL_ETHSW_PORT`,
`PCCSP_HAL_ETHSW_LINK_RATE`, `PCCSP_HAL_ETHSW_DUPLEX_MODE`,
`PCCSP_HAL_ETHSW_LINK_STATUS`, and `PCCSP_HAL_ETHSW_ADMIN_STATUS`. Each is a
pointer to its named enum, not a distinct allocated object or a capability descriptor.

#### Port Statistics Structure

`CCSP_HAL_ETH_STATS` (tag `_CCSP_HAL_ETH_STATS`, pointer alias
`PCCSP_HAL_ETH_STATS`) contains all 15 fields below. The caller supplies the structure
to `CcspHalEthSwGetEthPortStats()`.

| Field | C type | Header meaning |
| --- | --- | --- |
| `BytesSent` | `ULLONG` | Number of transmitted bytes. |
| `BytesReceived` | `ULLONG` | Number of received bytes. |
| `PacketsSent` | `ULONG` | Number of transmitted packets. |
| `PacketsReceived` | `ULONG` | Number of received packets. |
| `ErrorsSent` | `ULONG` | Number of transmit errors. |
| `ErrorsReceived` | `ULONG` | Number of receive errors. |
| `UnicastPacketsSent` | `ULONG` | Number of transmitted unicast packets. |
| `UnicastPacketsReceived` | `ULONG` | Number of received unicast packets. |
| `DiscardPacketsSent` | `ULONG` | Number of transmitted-side discarded packets (drops). |
| `DiscardPacketsReceived` | `ULONG` | Number of received-side discarded packets (drops). |
| `MulticastPacketsSent` | `ULONG` | Number of transmitted multicast packets. |
| `MulticastPacketsReceived` | `ULONG` | Number of received multicast packets. |
| `BroadcastPacketsSent` | `ULONG` | Number of transmitted broadcast packets. |
| `BroadcastPacketsReceived` | `ULONG` | Number of received broadcast packets. |
| `UnknownProtoPacketsReceived` | `ULONG` | Number of packets received with unknown protocols. |

These are counter fields, not a defined packets/second or errors/second API. The header
does not define the counting epoch/window, FCS/overhead inclusion, hardware counter widths,
clear-on-read behavior, reset behavior, saturation/wrap, or coherent multi-field sampling.
A derived rate requires timed samples and a vendor-verified treatment of reset/rollover.

#### Associated-Device Structure

`eth_device_t` has tag `_eth_device`.

| Field | C type | Header meaning / limitation |
| --- | --- | --- |
| `eth_devMacAddress` | `UCHAR[6]` | Six-byte MAC storage. The textual MAC example is illustrative, not a buffer large enough for a colon-separated string. |
| `eth_port` | `INT` | External zero-based port, 0 to `MaxEthPort - 1`; maximum is not declared here. |
| `eth_vlanid` | `INT` | Reported VLAN ID, documented range 1–4094. No setter, membership list, trunk mode, or untagged/native-VLAN representation. |
| `eth_devTxRate` | `INT` | Vendor-specific transmit speed; units and range unspecified. |
| `eth_devRxRate` | `INT` | Vendor-specific receive speed; units and range unspecified. |
| `eth_Active` | `BOOLEAN` | Online (`TRUE`) / offline (`FALSE`). Timing relative to association/disassociation delivery is unspecified. |

This is observation data; editing a returned structure is not a switch configuration API.

#### Callback Types and Registration Object

| Callback typedef | Exact declaration | Parameters / result / ownership |
| --- | --- | --- |
| `CcspHalExtSw_ethAssociatedDevice_callback` | `typedef INT (*CcspHalExtSw_ethAssociatedDevice_callback)(eth_device_t *eth_dev);` | Input `eth_dev`: associated/disassociated device details. Returns `RETURN_OK` or `RETURN_ERR`. Payload ownership and retention lifetime unspecified; no ownership transfer is declared. Apply T/E. |
| `fpEthWanLink_Up` | `typedef void (*fpEthWanLink_Up)();` | WAN link-up notification. No documented arguments; no result or allocation transfer. Apply T/E. |
| `fpEthWanLink_Down` | `typedef void (*fpEthWanLink_Down)();` | WAN link-down notification. No documented arguments; no result or allocation transfer. Apply T/E. |

`appCallBack` (tag `__appCallBack`) is the registration structure:

| Field | Type | Purpose |
| --- | --- | --- |
| `pGWP_act_EthWanLinkUP` | `fpEthWanLink_Up` | WAN link-up function pointer. |
| `pGWP_act_EthWanLinkDown` | `fpEthWanLink_Down` | WAN link-down function pointer. |

Legacy empty `()` parameter lists are reproduced exactly. In C before C23 they do not
provide a strict no-argument prototype; the documented intention is a notification with
no payload. The same issue affects `GWP_GetEthWanLinkStatus()` and
`CcspHalExtSw_getCurrentWanHWConf()`. No callback context/user-data pointer is provided.

### API Surface

The tables below are exhaustive across all feature configurations. Parameter names and C
types are preserved; `in`/`out` directions follow header comments, not C `const` qualifiers
(the relevant input pointers are not const-qualified). **S** means the function's documented
status result: `RETURN_OK` / `RETURN_ERR`. **T** means thread safety/reentrancy is
unspecified and the serialization policy above applies. **T/E** adds the asynchronous
lifetime, race, and callback-context caveats. Ordinary pointer outputs use caller storage
unless the row explicitly says otherwise.

#### Lifecycle and Port Configuration: 7 Functions

| Function | Input parameters | Output parameters | Return | Memory / ownership | Thread caveat |
| --- | --- | --- | --- | --- | --- |
| `INT CcspHalEthSwInit(void)` | None | None | S: initialization success/failure | No public allocation/handle returned; internal resources are vendor-managed. | T; repeat-call and readiness timing unspecified. |
| `INT CcspHalEthSwGetPortStatus(...)` | `CCSP_HAL_ETHSW_PORT PortId` | `PCCSP_HAL_ETHSW_LINK_RATE pLinkRate`, `PCCSP_HAL_ETHSW_DUPLEX_MODE pDuplexMode`, `PCCSP_HAL_ETHSW_LINK_STATUS pStatus` | S | Caller-owned enum outputs; no allocation transfer. | T; coherent snapshot/convergence unspecified. |
| `INT CcspHalEthSwGetPortCfg(...)` | `CCSP_HAL_ETHSW_PORT PortId` | `PCCSP_HAL_ETHSW_LINK_RATE pLinkRate`, `PCCSP_HAL_ETHSW_DUPLEX_MODE pDuplexMode` | S | Caller-owned enum outputs; no allocation transfer. | T. |
| `INT CcspHalEthSwSetPortCfg(...)` | `CCSP_HAL_ETHSW_PORT PortId`, `CCSP_HAL_ETHSW_LINK_RATE LinkRate`, `CCSP_HAL_ETHSW_DUPLEX_MODE DuplexMode` | None | S | Values only; no allocation transfer. | T; atomicity and application timing unspecified. |
| `INT CcspHalEthSwGetPortAdminStatus(...)` | `CCSP_HAL_ETHSW_PORT PortId` | `PCCSP_HAL_ETHSW_ADMIN_STATUS pAdminStatus` | S | Caller-owned enum output; no allocation transfer. | T. |
| `INT CcspHalEthSwSetPortAdminStatus(...)` | `CCSP_HAL_ETHSW_PORT PortId`, `CCSP_HAL_ETHSW_ADMIN_STATUS AdminStatus` | None | S; parameter prose contradicts enum values | Values only; no allocation transfer. | T; resulting link transition timing unspecified. |
| `INT CcspHalEthSwSetAgingSpeed(...)` | `CCSP_HAL_ETHSW_PORT PortId`, `INT AgingSpeed` (vendor-specific) | None | S | Values only; no allocation transfer. | T; units/range and effect timing unspecified. |

#### Discovery, Association, and Statistics: 4 Functions

| Function | Input parameters | Output parameters | Return | Memory / ownership | Thread caveat |
| --- | --- | --- | --- | --- | --- |
| `INT CcspHalEthSwLocatePortByMacAddress(...)` | `unsigned char *mac`: documented six-byte MAC array; textual example is ambiguous | `INT *port`: 0 = MoCA, 1–4 = Ethernet | S; not-found and retrieval failures share error result | Caller supplies MAC storage and integer output. No allocation transfer. | T; forwarding-table changes may race lookup. |
| `INT CcspHalExtSw_getAssociatedDevice(...)` | None | `ULONG *output_array_size`, `eth_device_t **output_struct` | S | Caller owns count/pointer slots; **HAL allocates array, caller must free it** using a vendor-confirmed deallocator. Failure/zero-count ownership unspecified. | T; snapshot versus callback consistency unspecified. |
| `void CcspHalExtSw_ethAssociatedDevice_callback_register(...)` | `CcspHalExtSw_ethAssociatedDevice_callback callback_proc` | None | `void`: no registration status | Callback code supplied by caller must remain valid; event payload ownership unspecified. | T/E; no unregister, drain, or multiple-subscriber semantics. |
| `INT CcspHalEthSwGetEthPortStats(...)` | `CCSP_HAL_ETHSW_PORT PortId` | `PCCSP_HAL_ETH_STATS pStats` | S | Caller allocates/frees statistics structure; HAL fills fields. | T; counter snapshot atomicity/reset behavior unspecified. |

#### Ethernet WAN Selection and Configuration: 6 Functions

| Function | Input parameters | Output parameters | Return | Memory / ownership | Thread caveat |
| --- | --- | --- | --- | --- | --- |
| `int CcspHalExtSw_ethPortConfigure(...)` | `char *ifname`, `BOOLEAN WanMode` | None | S | Caller-owned interface-name input; encoding/maximum input length and retention unspecified. | T; present only with both `FEATURE_RDKB_WAN_MANAGER` and `FEATURE_RDKB_AUTO_PORT_SWITCH`. |
| `INT CcspHalExtSw_getEthWanEnable(...)` | None | `BOOLEAN *pFlag`: 1 = enabled, 0 = disabled | S | Caller-owned Boolean output; no allocation transfer. | T. |
| `INT CcspHalExtSw_setEthWanEnable(...)` | `BOOLEAN Flag`: 1 = enable, 0 = disable | None | S | Value only; no allocation transfer. | T; interaction with port selection/partial changes unspecified. |
| `BOOLEAN CcspHalExtSw_getCurrentWanHWConf()` | No documented arguments; legacy `()` declaration | None; configuration is the function result | `TRUE` = WAN enabled, `FALSE` = LAN enabled; **not S**, no failure result | No public allocation transfer. | T; present only with `FEATURE_RDKB_AUTO_PORT_SWITCH`. |
| `INT CcspHalExtSw_getEthWanPort(...)` | None | `UINT *pPort`: 0 to `MaxEthPort - 1` | S | Caller-owned unsigned-integer output; no allocation transfer. | T; no atomic snapshot with enable state. |
| `INT CcspHalExtSw_setEthWanPort(...)` | `UINT Port`: 0 to `MaxEthPort - 1` | None | S | Value only; no allocation transfer. | T; behavior while WAN enabled and rollback unspecified. |

#### Ethernet WAN Events and Identity: 3 Functions

| Function | Input parameters | Output parameters | Return | Memory / ownership | Thread caveat |
| --- | --- | --- | --- | --- | --- |
| `void GWP_RegisterEthWan_Callback(...)` | `appCallBack *obj` | None | `void`: no registration status | Caller supplies structure and code; whether HAL retains `obj` or copies it is unspecified. Keep both valid pending quiescence. | T/E; no unregister/drain or callback execution-context contract. |
| `INT GWP_GetEthWanLinkStatus()` | No documented arguments; legacy `()` declaration | None; state is the function result | **1 up, 0 down, negative error**; check `errno` per header; **not S** | No public allocation transfer. | T; polling/event ordering unspecified. |
| `INT GWP_GetEthWanInterfaceName(...)` | `ULONG maxSize`: maximum buffer size, documented 11–262 | `unsigned char *Interface`: caller buffer, documented minimum 64 bytes | S | Caller allocates/frees buffer; no transfer. Honor actual capacity; termination and conflict with 32-byte macro require care. | T; consistency with concurrent WAN port changes unspecified. |

### Core Operational Lifecycle

This sequence is an **illustrative integration flow**, not a normative state machine or
a claim that the header mandates this order. It includes initialization, callback
registration, polling, admin/speed/duplex configuration, optional VLAN provisioning,
WAN selection, and shutdown responsibilities. Only calls named on the Agent-to-HAL path
are declared public APIs. SDK/driver messages are conceptual vendor actions.

~~~mermaid
sequenceDiagram
    participant Agent as CCSP Ethsw Agent / Upper Stack
    participant HAL as Ethsw HAL Interface
    participant SDK as Vendor Switch Driver / SDK
    participant Ports as Physical LAN / WAN Ports
    participant Platform as Platform Provisioning / Lifecycle
    Agent->>HAL: CcspHalEthSwInit()
    HAL->>SDK: Initialize vendor resources and switch access
    SDK->>Ports: Prepare hardware as required by product
    SDK-->>HAL: Initialization result
    alt Initialization succeeds
        HAL-->>Agent: RETURN_OK
        Agent->>HAL: CcspHalExtSw_ethAssociatedDevice_callback_register(callback_proc)
        HAL-->>Agent: void - registration status unavailable
        Agent->>HAL: GWP_RegisterEthWan_Callback(obj)
        HAL-->>Agent: void - registration status unavailable
        Note over Agent,HAL: Callback delivery context and registration races are unspecified
        loop Initial snapshot and periodic port polling
            Agent->>HAL: CcspHalEthSwGetPortStatus(PortId, pLinkRate, pDuplexMode, pStatus)
            HAL->>SDK: Read rate, duplex and link state
            SDK->>Ports: Observe physical port
            Ports-->>SDK: Port observation
            SDK-->>HAL: Values or failure
            HAL-->>Agent: RETURN_OK with outputs or RETURN_ERR
        end
        Agent->>HAL: CcspHalEthSwSetPortAdminStatus(PortId, AdminStatus)
        HAL->>SDK: Apply requested administrative state
        HAL-->>Agent: RETURN_OK or RETURN_ERR
        Agent->>HAL: CcspHalEthSwSetPortCfg(PortId, LinkRate, DuplexMode)
        HAL->>SDK: Apply requested speed and duplex
        HAL-->>Agent: RETURN_OK or RETURN_ERR
        Agent->>HAL: CcspHalEthSwGetPortCfg(PortId, pLinkRate, pDuplexMode)
        HAL-->>Agent: RETURN_OK with configuration or RETURN_ERR
        Note over Agent,HAL: Check each result and read back exposed state before relying on changes
        opt Product requires VLAN isolation or tagging
            Note over HAL,Platform: No VLAN membership or trunk-access API exists in this header
            Agent->>Platform: Request separately specified VLAN provisioning
            Platform->>SDK: Configure membership, isolation and tag policy outside HAL
            SDK->>Ports: Apply product-specific forwarding policy
            Platform-->>Agent: Platform-defined result and verification
        end
        opt Ethernet WAN selection required
            Agent->>HAL: CcspHalExtSw_setEthWanPort(Port)
            HAL-->>Agent: RETURN_OK or RETURN_ERR
            Agent->>HAL: CcspHalExtSw_setEthWanEnable(TRUE)
            HAL-->>Agent: RETURN_OK or RETURN_ERR
        end
        opt Vendor reports association or disassociation
            SDK-->>HAL: Device observation
            HAL-->>Agent: Registered association callback with eth_dev
            Agent-->>HAL: RETURN_OK or RETURN_ERR from callback
            Note over Agent,HAL: Queue follow-up work rather than assuming callback reentrancy
        end
        opt Vendor reports WAN link change
            SDK-->>HAL: WAN link observation
            HAL-->>Agent: Registered up or down callback with no payload
            Agent->>HAL: GWP_GetEthWanLinkStatus() from serialized owner
            HAL-->>Agent: 1 up, 0 down, or negative error
        end
        Agent->>Agent: Stop new work and polling for shutdown
        Agent->>Platform: Coordinate vendor event quiescence and resource cleanup
        Note over HAL,Platform: No HAL deinit, unregister or callback-drain API is declared
        Platform->>SDK: Product-specific shutdown if supported
        Note over Agent,Platform: Release retained caller resources only after quiescence is established
    else Initialization fails
        HAL-->>Agent: RETURN_ERR
        Agent->>Agent: Stop dependent startup and report vendor diagnostics
    end
~~~

The WAN-select-then-enable ordering is a recommendation, not a documented transaction.
No guarantee of uninterrupted traffic, event delivery, atomic VLAN/WAN changes, or rollback
is implied. Admin configuration order and link convergence must be verified per product.

### State-Dependent Behavior

No normative state-transition graph is provided by the header. The link and administrative
enums enumerate states, not legal edges, transition triggers, timing, or recovery actions.
In particular:

- Admin Up and operational link Up are not interchangeable measurements. Do not infer a
  successful physical link or forwarding behavior solely from an admin setter result.
- The distinction between Down and Disconnected, and behavior in AdminTest, needs a
  vendor definition.
- Configured `Auto` versus observed rate/duplex requires product verification; the header
  does not fully specify getter results during negotiation or link loss.
- WAN enable, selected port, hardware LAN/WAN configuration, and live WAN link are
  separate observations, without an atomic multi-property query.
- MAC lookup may fail because an address is absent or because table access failed;
  the generic error code does not distinguish those cases.

## Platform or Product Customization

Declarations depend on the following compile-time gates:

| `FEATURE_RDKB_WAN_MANAGER` | `FEATURE_RDKB_AUTO_PORT_SWITCH` | Functions available |
| --- | --- | --- |
| Not defined | Not defined | 18 unconditional declarations. |
| Defined | Not defined | 18 unconditional declarations. |
| Not defined | Defined | 18 unconditional declarations plus `CcspHalExtSw_getCurrentWanHWConf()` (19 total). |
| Defined | Defined | All 20, including `CcspHalExtSw_ethPortConfigure()`. |

When `ETHWAN_DEF_INTF_NUM` is not already defined, the first matching branch selects it:

| Compile-time condition, in precedence order | Default zero-based WAN index |
| --- | --- |
| `ETH_6_PORTS` | 5 |
| `ETH_5_PORTS` | 4 |
| `ETH_4_PORTS` | 3 |
| `ETH_2_PORTS` and `MODEM_ONLY_SUPPORT` | 0 |
| Otherwise | 0 |

An externally predefined `ETHWAN_DEF_INTF_NUM` bypasses the ladder. The introductory
comment omits the five-port case, but the preprocessor branch exists and is authoritative.
The default is not a runtime port-count query; `CcspHalExtSw_setEthWanPort()` selects a
runtime WAN port without redefining the macro.

The header proposes replacing interface feature flags and generic errors with a uniform
runtime-supported/not-supported contract. Those TODOs are **not implemented declarations**:
do not document an existing capability discovery or `NOT_SUPPORTED` result.

## Contract Gaps and Vendor Clarification Checklist

These are limitations or contradictions in the current public interface, not changes made
by this documentation update. Resolve them in vendor integration agreements and tests;
a public-header correction requires a separate compatibility-reviewed change.

| ID | Gap / ambiguity evidenced in the header | Consequence / clarification needed |
| --- | --- | --- |
| G01 | VLAN, bridging, and link aggregation appear in introductory prose without configuration APIs. | Specify an external platform contract for VLAN membership, isolation, PVID/tagging, trunk/access, and aggregation; do not invent HAL calls. |
| G02 | `CCSP_HAL_ETHSW_ADMIN_STATUS` defines Up = 0, Down = 1, while the setter parameter comment says 0 = Down, 1 = Up. | Named enum values reflect the declaration; confirm vendor interpretation and correct contradictory prose through a separate header review. |
| G03 | Enum, zero-based WAN/device ports, and MAC-lookup 0/MoCA and 1–4/Ethernet numbering coexist; `MaxEthPort` is undeclared. | Obtain product port count and explicit mappings. Eight Ethernet identifiers do not prove eight hardware ports. |
| G04 | `MgmtPort` is described as not valid despite its management-port name; both it and `PortMax` have maximum-related comments. | Clarify valid identifiers and sentinel handling. Do not derive physical port count from either. |
| G05 | `GWP_GetEthWanInterfaceName()` requires minimum 64 bytes and `maxSize` 11–262, while `ETHWAN_INTERFACE_NAME_MAX_LENGTH` is 32 and its comment describes a different, size-less function name. | Confirm true capacity, whether limits include termination, null termination, and insufficient-buffer behavior. Use the actual size-aware declaration. |
| G06 | `CcspHalExtSw_getAssociatedDevice()` allocates memory for the caller to free, but has no deallocator or allocator specification. | Agree allocator compatibility, zero-device behavior, maximum count, and cleanup for partial/failure allocations. Do not assume error means no allocation. |
| G07 | Callback payload ownership, retention, callback-object copying, and input pointer retention are unspecified. | Define lifetimes and copy/borrow rules before freeing storage or using callbacks beyond process lifetime. |
| G08 | No unregister/drain, registration status, subscriber model, user context, delivery thread, ordering, replay, or backpressure contract. | Define safe shutdown, repeated/null registration, events during registration, missed/duplicate events, and callback-error handling. Void registration cannot acknowledge success. |
| G09 | WAN notifications carry no interface/port ID and do not cover arbitrary switch ports. | Establish association with the selected WAN, stale-event handling during port changes, and polling reconciliation. |
| G10 | No thread-safety, reentrancy, process-safety, or locking contract. | Serialize client access and validate vendor cross-process protection; do not assume callbacks can safely reenter getters/setters. |
| G11 | Generic status codes lack error categories and a runtime unsupported result; Boolean configuration query cannot report failure. | Agree diagnostics and handling of unsupported operations. `errno` is mentioned only for `GWP_GetEthWanLinkStatus()`, not all failures. |
| G12 | No initialization idempotency, readiness timing, timeout, cancel, reset, deinit, or power-management API. | Define startup/recovery/deadline supervision and platform-owned shutdown. No portable cleanup call can be assumed. |
| G13 | Aging speed and device Tx/Rx rates use `INT` without standardized units/ranges; MAC lookup uses mutable bytes with a textual example. | Confirm aging scale, rate units, binary MAC representation, byte order, input mutability, and bounds. |
| G14 | Rate/duplex enums enumerate choices but no capability query or supported-combination matrix. | Establish per-port supported rates/modes, Auto semantics, invalid-combination handling, and negotiation latency. |
| G15 | Statistics use ABI-dependent types and omit epochs, counter widths, reset/wrap, overhead accounting, and atomicity. | Define comparable measurements and safe rate calculations, especially across 32-/64-bit ABIs or device resets. |
| G16 | Legacy empty `()` declarations, macro-based types, non-const inputs, no fixed structure layout, and no `extern "C"` guard. | Build caller/vendor with compatible C ABI; C++ consumers need appropriate linkage wrapping. Header modernization is out of scope. |
| G17 | Setter rollback, read-after-write consistency, inter-property atomicity, persistence, and physical forwarding effects are unspecified. | Validate independently; a success result is not evidence of VLAN isolation or packet delivery. No aging getter exists. |
| G18 | Existing narrative policies such as serialization, multi-process protection, logging, and packaging are not expressed in the header. | Treat retained policies below as specification-level expectations to validate, not proven vendor behavior or header annotations. |

## Nonfunctional Requirements and Integration Policies

This section preserves useful expectations from the existing specification. These are
**specification-level policies**, not claims that the header defines or enforces them.

### Logging and Debugging Requirements

Implementations should record errors and useful operational context using the platform's
logging facilities, preferring syslog integration over ad hoc `printf`. The existing log
destination convention is `ethsw_vendor_hal.log` under `/var/tmp/` or `/rdklogs/logs/`;
confirm the actual product logging configuration.

Use timestamped severity and context, such as function, port/interface, and vendor error.
The previous policy named FATAL, ERROR, WARNING, NOTICE, INFO, DEBUG, and TRACE; map these
to available platform levels rather than assuming each is a native syslog priority.
Avoid exposing sensitive connected-client information unnecessarily.

Logging is a recommended diagnostic channel, not a declared API. The header does not
guarantee a log file or that logging is the only available vendor diagnostic mechanism.

### Memory and Performance Requirements

Minimize CPU/memory overhead, manage internal allocations/threads/handles without leaks,
and honor supplied output capacities. Validate responsive calls and event handling under
load. Neither a numeric memory budget nor a latency/event-throughput SLA is provided by
the header; agree measurable limits for the product.

### Quality Control

Retain static analysis, dependency/license analysis, and runtime memory checks as recommended
implementation practices (for example Coverity, Black Duck, and Valgrind where applicable).
Exercise invalid inputs, unsupported ports, initialization failure, allocation failure,
repeated configuration, callback races, shutdown, and counter reset/wrap behavior.
The absence of a portable error discriminator or cleanup API must be accounted for in
the test design rather than hidden by assumed behavior.

### Licensing

The public header carries an Apache License 2.0 notice. Retain the existing expectation
that the HAL implementation is released under Apache License 2.0; check vendor driver/SDK
and third-party licensing separately instead of inferring it from this interface.

### Build Requirements

The existing integration target is Yocto-compatible packaging of a vendor
`libhal_ethsw.so`. Consumers include `ccsp_hal_ethsw.h` and link the appropriate vendor
library. This interface repository does not supply the vendor switch implementation.

The header specifies no compiler version, language-standard minimum, platform port count,
runtime shared-library filename, or dependencies on a particular switch SDK. Match ABI,
feature definitions, and packaging with the product build. This documentation update
changes neither declarations nor build configuration.

### Variability Management

Retain Semantic Versioning as the interface-versioning policy:
[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html).
Vendors should target an agreed interface revision under product/SLA arrangements.
Compile-time feature presence must match between consumers and the selected implementation;
there is no runtime version/capability negotiation declared here.

## Integration Review Checklist

- Match the 18/19/20-function feature profile and caller/vendor ABI.
- Verify enum interpretation, supported rate/duplex combinations, and each port-number mapping.
- Establish startup error handling, bounded execution strategy, and cross-process/thread policy.
- Agree the associated-device deallocator, failure-side ownership, and all callback lifetimes.
- Verify interface-name capacity/termination without relying on the 32-byte macro.
- Keep VLAN membership, tagging, isolation, and trunk/access verification under an explicit
  external platform contract; reported `eth_vlanid` is insufficient proof.
- Confirm callback registration, event reconciliation, WAN switching, and shutdown quiescence.
- Define counter sampling/reset semantics and independently validate forwarding behavior.
