# eSIM LPA HAL Specification

## Scope and evidence

[lpa_hal.h](../../include/lpa_hal.h) defines an eSIM Local Profile Assistant (LPA) interface for profile download, enumeration, enable/disable/delete, initialization, exit, and EID/eUICC queries. It is not a low-power abstraction. No standby, wake-event, battery, or clock-control API is declared.

eSIM means embedded SIM; eUICC means embedded Universal Integrated Circuit Card; SM-DP refers to Subscription Manager Data Preparation and SM-DS to Subscription Manager Discovery Server. This specification distinguishes declarations from implementation and integration guidance.

## Architecture

~~~mermaid
flowchart TD
    C["Cellular profile-management caller"] --> H["lpa_hal.h"]
    H --> V["Vendor LPA implementation"]
    V --> E["eUICC profile services"]
    V --> S["Profile download services"]
    V -. "Progress callback" .-> C
~~~

Transport and vendor threading are not prescribed by this diagram.

## Complete API inventory

| Exact declaration | Contract |
| --- | --- |
| `int cellular_esim_download_profile_with_activationcode(char* ActivationCodeStr, cellular_sim_download_progress_callback download_progress);` | Download using activation code; reports progress through supplied callback. Returns `TRUE=1` when initiation succeeds and modem is present, `FALSE=0` otherwise. |
| `int cellular_esim_download_profile_from_smds(char* smds);` | Download using discovery-server information. |
| `int cellular_esim_download_profile_from_defaultsmdp(char* smdp);` | Download using default SM-DP information. |
| `int cellular_esim_get_profile_info(eSIMProfileStruct **profile_list, int *nb_profiles);` | HAL dynamically allocates profile data and returns count; caller must release it, but allocator and release procedure are unspecified. |
| `int cellular_esim_enable_profile(char* iccid, int iccid_size);` | Enable the identified profile. |
| `int cellular_esim_disable_profile(char* iccid, int iccid_size);` | Disable the identified profile. |
| `int cellular_esim_delete_profile(char* iccid, int iccid_size);` | Delete the identified profile. |
| `int cellular_esim_lpa_init(void);` | Initialize the LPA. |
| `int cellular_esim_lpa_exit(void);` | Exit/clean up the LPA. |
| `int cellular_esim_get_eid();` | Declared integer-return query with no output argument; textual EID delivery is not specified. |
| `int cellular_esim_get_euicc();` | Declared integer-return query with no output argument; result representation is not specified. |

The last two use old-style empty parameter lists in C. Do not add invented buffer or context arguments. Except for activation-code download, comments specify `RETURN_OK=0` on success and `RETURN_ERR` on failure, while the header actually defines `RETURN_ERROR=-1`, not `RETURN_ERR`. The callback comments use the same undefined `RETURN_ERR` spelling. This inconsistency needs resolution; the EID/eUICC functions document operation status but not how the queried information is delivered. The activation-code comment references `lpaGetErrorCodeDescription(lpaGetErrorCode())`, neither of which is declared here.

## Complete type and constant inventory

| Type or constant | Complete definition |
| --- | --- |
| `CellularPreferredUICC_t` | `CELLULAR_UICC_USIM=0`, `CELLULAR_UICC_ESIM=1`. |
| `CellularDeviceSimStatus_t` | `SIM_PREPARATION_PENDING=1`, `SIM_PREPARATION_INPROGRESS=2`, `SIM_PREPARATION_DOWNLOADED=3`, `SIM_PREPARATION_DONE=4`. Vocabulary alone does not define legal transitions. |
| `eSIMProfileStruct` | `char iccid[32]`; `int profileState`; `char profileName[16]`. |
| `cellular_sim_download_progress_callback` | `typedef int (*cellular_sim_download_progress_callback)(char *progress);` |
| Constants | `RETURN_ERROR=-1`, `RETURN_OK=0`, conditional `TRUE=1`, `FALSE=0`. |

No context handles, public variables, list-release function, or callback-unregister function are declared. Enum values do not define the domain of `profileState`.

## Lifecycle and representative sequence

Initialize before using the LPA, then exit after operations have quiesced. This is a global API, not creation/destruction of per-profile C handles. Profiles are identified by ICCID. The sequence illustrates one download path; it does not require an automatic enable or deletion afterward.

~~~mermaid
sequenceDiagram
    participant C as Caller
    participant H as Vendor LPA
    C->>H: cellular_esim_lpa_init()
    H-->>C: int status
    opt Initialization successful and download authorized
        C->>H: cellular_esim_download_profile_with_activationcode(ActivationCodeStr, download_progress)
        H-->>C: download_progress(progress)
        Note over C,H: Callback may occur during or after call; timing unspecified
        H-->>C: int download result
        C->>H: cellular_esim_get_profile_info(profile_list, nb_profiles)
        H-->>C: int status; list and count on success
    end
    Note over C,H: Confirm callback and operation quiescence before exit
    C->>H: cellular_esim_lpa_exit()
    H-->>C: int status
~~~

Progress callback invocation is not itself proof that download, activation, or provisioning succeeded.

## Ownership, errors, callbacks, and concurrency

- Caller owns input strings, ICCID buffers, and count/output-pointer variables. Profile-action comments require a 20-digit ICCID and `iccid_size=20`; terminator handling still needs clarification.
- The enumeration comment explicitly says the function dynamically allocates profile data and the caller must free it. It also calls the output an “array of pointers” although the declared double pointer can return a contiguous struct array. Confirm layout and allocator-compatible release with the vendor; no dedicated release API exists.
- Callback progress text has no length or lifetime contract. Copy needed data while valid; do not free vendor memory or retain pointers without agreement. The callback documents success/failure status, but how the vendor acts on that result, its dispatch thread, serialization, reentrancy, registration lifetime, and exit-time draining are unspecified.
- Use status checks and do not consume outputs after failure. Detailed error categories, partial-list behavior, retries, and cancellation are not defined.
- No thread-safety, process locking, or timing guarantee is declared. Existing integration policy requires caller serialization and vendor multi-process protection. Download/network calls may take time; no numeric response deadline is established.
- eUICC profile enable/delete actions affect operational state; reboot persistence is not specified by the C API. No general power-management API exists.

## Integration and delivery policy

Retain Linux/Yocto support, shared library `libesim_lpa.so`, Apache License 2.0 implementation, and controlled semantic versioning. Vendors manage internal threads/resources and cleanup. Numeric footprint, CPU, and timeout budgets remain unresolved.

Route timestamped syslog diagnostics to `lpa_vendor_hal.log` under `/var/tmp/` or `/rdklogs/logs/`; map FATAL/TRACE labels to supported priorities. Do not log activation codes, profile credentials, or unnecessary subscriber identifiers. Static analysis, dependency/license review, and leak analysis remain recommended; no device provisioning or tests were run for this documentation.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| LPA-GAP-01 | Profile data is HAL-allocated and caller-freed, but layout wording, allocator, release procedure, and lifetime remain unspecified. |
| LPA-GAP-02 | Define `profileState` values, profile count limits, field termination, and truncation. |
| LPA-GAP-03 | Define progress format, callback return semantics, dispatch context, and quiescence on exit. |
| LPA-GAP-04 | `get_eid` and `get_euicc` return documented status but expose no output storage; clarify information delivery. Resolve undefined `RETURN_ERR` and undeclared detailed-error accessors referenced by comments. |
| LPA-GAP-05 | Profile-action comments specify a 20-digit ICCID and `iccid_size=20`; clarify terminator handling, other input-string limits, null handling, and failure-output validity. |
| LPA-GAP-06 | Define init/exit repeatability, concurrent-process behavior, deadlines, cancellation, and durable profile effects. |
