# Cellular Modem HAL Specification

## Scope and evidence

The public contract is [cellular_modem_hal_api.h](../../include/cellular_modem_hal_api.h). It declares exactly three functions: factory reset, reboot, and firmware-version retrieval. It does not declare context handles, initialization, teardown, SIM control, network attachment, event registration, or modem enumeration. Such operations must not be inferred from the broader Cellular HAL.

HAL means Hardware Abstraction Layer; RDK-B means Reference Design Kit for Broadband. This document describes declarations and header comments, not verified vendor runtime behavior.

## Architecture

~~~mermaid
flowchart TD
    C["RDK-B caller"] --> H["cellular_modem_hal_api.h: three C functions"]
    H --> V["Vendor HAL implementation"]
    V --> M["Modem control and firmware information"]
~~~

Vendor internals and transport are implementation-specific; the diagram does not require a particular driver or IPC mechanism.

## Complete API inventory

| Exact declaration | Contract |
| --- | --- |
| `int Modem_FactoryReset(void);` | Restore factory settings, erasing custom modem configuration. Returns `STATUS_SUCCESS` or `STATUS_FAILED`. |
| `int Modem_Reboot(void);` | Reboot modem hardware. Returns `STATUS_SUCCESS` or `STATUS_FAILED`. A returned success does not specify a post-boot readiness deadline. |
| `int Modem_Firmware_Version(char *firmware_version);` | Caller supplies an output buffer of at least 128 bytes. Returns `STATUS_SUCCESS` or `STATUS_FAILED`. |

## Complete type and constant inventory

No structs, enums, typedefs, callbacks, or public variables are declared. `STATUS_SUCCESS` is `0`; `STATUS_FAILED` is `-1`. The header provides C++ linkage guards. Its include guard is not an API version.

## Lifecycle and representative sequence

There is no declared initializer, finalizer, context allocation, or handle. Queries and destructive actions are independent entry points, not a mandated reset-then-query workflow. The sequence below is illustrative, with an optional explicitly authorized reboot; `firmware_version` denotes caller-owned storage.

~~~mermaid
sequenceDiagram
    participant C as Caller
    participant H as Vendor HAL
    C->>H: Modem_Firmware_Version(firmware_version)
    H-->>C: int status; firmware_version on success
    opt Explicitly authorized maintenance
        C->>H: Modem_Reboot()
        H-->>C: int status
    end
~~~

Factory reset is more destructive than reboot and is not an automatic error-recovery action.

## Ownership, errors, concurrency, and timing

- Caller owns the firmware buffer throughout the call and releases it. There is no allocation-return or release API.
- Output capacity is a documented minimum, not a runtime length argument. The header does not define truncation, termination on failure, or partial-output validity. Consume output only after success.
- Reset/reboot errors may include permissions, resource, storage, hardware, or firmware failures. Only the two status values are specified; no detailed error accessor or `errno` contract exists.
- No callback is declared. This does not prohibit private vendor threads.
- Thread safety, reentrancy, cross-process exclusion, maximum blocking duration, cancellation, and modem readiness after reboot are unspecified by the header. Integration policy is to serialize access, coordinate destructive operations across processes, and keep potentially blocking calls off latency-critical paths.
- No general power-state or persistence interface is declared. Factory reset explicitly changes configuration; absence of a persistence API does not mean the device has no persistent state.

## Integration and delivery policy

Retained project guidance, not additional C declarations: support Linux/Yocto delivery as `libhal_cellular_modem_hal_api.so`, include the linked header, and target Apache License 2.0. Interface changes follow controlled semantic versioning; the current header does not expose version negotiation.

Vendors manage and clean up their private memory, threads, and descriptors. Multiple processes may invoke the interface, so implementation-level coordination is required. Numeric CPU, memory, and response-time budgets remain unassigned rather than invented.

Use syslog-backed diagnostics routed to `cellular_modem_vendor_hal.log` under `/var/tmp/` or `/rdklogs/logs/`, with timestamps and severity. Map project FATAL/TRACE labels to supported logging levels; they are not native syslog priorities. Avoid logging device identifiers unnecessarily. Static analysis, dependency/license review, and leak analysis remain recommended quality practices; no such execution is claimed here.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| MODEM-GAP-01 | `Modem_Firmware_Version` has no capacity argument: clarify maximum output, NUL termination, and short-buffer behavior. |
| MODEM-GAP-02 | Reboot/reset return only status: clarify completion versus acceptance and subsequent readiness observation. |
| MODEM-GAP-03 | No locking/process protocol or deadlines are declared: define serialization and bounded blocking. |
| MODEM-GAP-04 | Generic failure only: define failure-output validity and diagnostic detail without inventing error codes. |
| MODEM-GAP-05 | No declared initialization/shutdown contract: document vendor readiness and private-resource lifecycle outside the ABI. |
