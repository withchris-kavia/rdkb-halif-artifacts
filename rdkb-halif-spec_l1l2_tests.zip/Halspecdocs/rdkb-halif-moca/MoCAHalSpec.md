# MoCA HAL Specification

## Document Scope and Source of Truth

The MoCA (Multimedia over Coax Alliance) HAL separates RDK-B provisioning and
management from vendor-specific coax-network drivers and firmware. The authoritative
public interface is [`include/moca_hal.h`](../../include/moca_hal.h).

This documentation-only consolidation inventories **21 function declarations,
14 structures, 2 active enums, and 1 callback typedef** across the source's feature
branches. The disabled `ACA_STATUS` enum is not a public active type. Counts do not
include common type macros as typedefs or callback types as functions.

Reviewed header SHA-256:
`db019f89392e031c770caca48bc88776ac0f05c31a1bb4dd5e78824d9dfdf1f5`.

Evidence labels used throughout:

- **Declared contract:** declarations and explicit comments in the public header.
  These do not prove that a vendor implementation behaves correctly.
- **Integration policy:** retained or recommended operational expectations, not
  additional guarantees supplied by the header.
- **Unspecified/vendor-dependent:** behavior requiring product or vendor agreement.

This update changes no public interface version, declarations, or build configuration.
It replaces the previous incomplete narrative and placeholder sequence diagram,
preserving useful integration policies while distinguishing them from header guarantees.

## Acronyms

| Acronym | Meaning |
| --- | --- |
| HAL | Hardware Abstraction Layer |
| RDK-B / CCSP | Reference Design Kit for Broadband / Common Component Software Platform |
| MoCA / CPE | Multimedia over Coax Alliance / Customer Premises Equipment |
| NC / PHY | Network Coordinator / Physical Layer |
| ACA | Automatic Channel Adaptation, as named by the public header |
| EVM / SCMOD | Error Vector Magnitude / Subcarrier Modulation |
| PQoS / PDU | Priority Quality of Service / Payload Data Unit |
| OEM | Original Equipment Manufacturer |

## Architecture

~~~mermaid
flowchart TD
    Stack["RDK-B Stack"]
    Agent["CCSP MoCA Provisioning and Management"]
    HAL["MoCA HAL Interface: moca_hal.h"]
    Vendor["Vendor HAL Implementation and Driver or SDK"]
    Physical["MoCA Firmware and Physical Coax Network"]
    Stack --> Agent
    Agent -->|"Declared C APIs"| HAL
    HAL --> Vendor
    Vendor --> Physical
    Physical -.->|"Device observations"| Vendor
    Vendor -.->|"Registered callback through HAL"| Agent
~~~

The interface header is not a driver or firmware implementation. The existing
specification identifies `CcspMoCA` and a vendor library packaged as `libhal_moca.so`;
these are integration conventions rather than identifiers enforced by the header.
The physical network and driver actions shown above are conceptual implementation
responsibilities. Actual hardware readiness, channel behavior, supported MoCA
versions, and forwarding remain product-specific.

## Operational Capabilities

| Capability | Declared interface/data | Limitations |
| --- | --- | --- |
| Presence | `moca_HardwareEquipped()` | Boolean availability; no independent diagnostic error channel. |
| Interface configuration | `moca_GetIfConfig()`, `moca_SetIfConfig()`, `moca_cfg_t` | Enable, preferred NC, privacy, masks, power, bandwidth thresholds, reset and scanning settings. No dedicated initialize/open API. |
| Static/dynamic observation | `moca_IfGetStaticInfo()`, `moca_IfGetDynamicInfo()` | Versions, capabilities, network identity, status, bandwidth and timing. Snapshot coherence and update latency unspecified. |
| Traffic and MAC counters | `moca_IfGetStats()`, `moca_IfGetExtCounter()`, `moca_IfGetExtAggrCounter()` | Bytes, packets, errors, drops, MAC messages, PDUs. Reset/wrap/atomicity mostly unspecified. |
| Associated devices and CPEs | Count/list APIs and device callback | CPE list has documented 256-entry allocation; associated-device list has no capacity/count argument. |
| Full mesh rates | `moca_GetFullMeshRates()` | Caller-allocated pair table; excluded when `MOCA_VAR` is defined. |
| PQoS flow observation | `moca_GetFlowStatistics()` | Flow table retrieval, not flow creation/deletion or admission control. |
| Frequency interpretation | `moca_FreqMaskToValue()` | Vendor-specific mask representation and frequency units; no explicit error result. |
| Reset observation | `moca_GetResetCount()` | Global count query with no interface argument; not an explicit reset operation. |
| ACA control/results | Five ACA/SCMOD functions | Configure/start, read configuration, cancel, retrieve status and subcarrier data. Completion timing and array capacities unspecified. |
| VLAN, trunk/access, bridging | No declared configuration API | Do not infer programmable Ethernet switch capabilities from MoCA connectivity. |
| Shutdown/power management | No dedicated API | Platform lifecycle and vendor cleanup are separate integration responsibilities. |

## Public API Contract

### Shared Conventions

**S** in the tables means the documented result is `STATUS_SUCCESS` (default 0)
or `STATUS_FAILURE` (default -1). It does not imply distinct invalid-argument,
unsupported, timeout, or allocation errors.

**T** means the header specifies no thread safety, reentrancy, locking, or
cross-process coordination. Apply the serialization policy below.
**T/E** adds unspecified callback context, lifetime, registration races, and shutdown.

Caller-owned output storage is the general documented model. No public allocation
release API or explicit ownership-transfer allocation is declared. In particular,
double pointers do **not** imply that the HAL allocates: both associated-device and
SCMOD comments explicitly assign array allocation to the caller.

Parameter names and types below preserve the declarations. Directions follow comments;
input pointers are not generally `const`. Pointer retention, partial results, and
failure-side output validity are unspecified unless a row states otherwise.

### Configuration, Identity, and Scalar Observation: 9 Functions

| Exact signature | Inputs | Outputs | Result | Memory and concurrency caveats |
| --- | --- | --- | --- | --- |
| `INT moca_GetIfConfig(ULONG ifIndex, moca_cfg_t *pmoca_config)` | Interface index | Configuration structure | S | Caller storage; T. |
| `INT moca_SetIfConfig(ULONG ifIndex, moca_cfg_t *pmoca_config)` | Index and configuration structure | None documented | S | Caller input; mutability/retention unspecified; T; atomicity/rollback unspecified. |
| `INT moca_IfGetDynamicInfo(ULONG ifIndex, moca_dynamic_info_t *pmoca_dynamic_info)` | Index | Dynamic structure | S | Caller storage; T; prototype remains unconditional although its type is excluded by `MOCA_VAR`. |
| `INT moca_IfGetStaticInfo(ULONG ifIndex, moca_static_info_t *pmoca_static_info)` | Index | Static structure | S | Caller storage; T. |
| `INT moca_IfGetStats(ULONG ifIndex, moca_stats_t *pmoca_stats)` | Index | Traffic counters | S | Caller storage; T; snapshot/reset semantics unspecified. |
| `INT moca_GetNumAssociatedDevices(ULONG ifIndex, ULONG *pulCount)` | Index | Associated-device count | S | Caller scalar; T; no atomic relationship with list retrieval. |
| `INT moca_FreqMaskToValue(UCHAR *mask)` | Mask buffer: at least 16 bytes, vendor-dependent | Frequency in return value | Frequency, not S; units/range/error encoding unspecified | Caller input; T; no length parameter. |
| `BOOL moca_HardwareEquipped(void)` | None | Presence/availability in return value | TRUE/FALSE, not S | No public storage transfer; T; false cannot distinguish absence from other causes. |
| `INT moca_GetResetCount(ULONG *resetcnt)` | None | Global reset count | S | Caller scalar; **unchanged on failure** per header; T; counting epoch unspecified. |

### Counters, Tables, and Events: 7 Functions

| Exact signature | Inputs | Outputs | Result | Memory and concurrency caveats |
| --- | --- | --- | --- | --- |
| `INT moca_IfGetExtCounter(ULONG ifIndex, moca_mac_counters_t *pmoca_mac_counters)` | Index | MAC counters | S | Caller structure; T. |
| `INT moca_IfGetExtAggrCounter(ULONG ifIndex, moca_aggregate_counters_t *pmoca_aggregate_counts)` | Index | Tx/Rx PDU totals excluding MoCA control packets | S | Caller structure; T. |
| `INT moca_GetMocaCPEs(ULONG ifIndex, moca_cpe_t *cpes, INT *pnum_cpes)` | Index | CPE array and count | S | Caller preallocates **256 entries** (`kMoca_MaxCpeList`) and count storage; T; no input capacity. |
| `INT moca_GetAssociatedDevices(ULONG ifIndex, moca_associated_device_t **ppdevice_array)` | Index; caller-allocated backing array | Device array through pointer slot | S | Caller allocation explicitly required; no returned count/capacity or replacement/release rules; T. |
| `INT moca_GetFullMeshRates(ULONG ifIndex, moca_mesh_table_t *pDeviceArray, ULONG *pulCount)` | Index | Mesh entries and written count | S | Caller allocates for all possible node pairs; no capacity argument; T; only without `MOCA_VAR`. |
| `INT moca_GetFlowStatistics(ULONG ifIndex, moca_flow_table_t *pDeviceArray, ULONG *pulCount)` | Index | Flow entries and written count | S | Caller allocates all entries; no bound or capacity negotiation; T. |
| `void moca_associatedDevice_callback_register(moca_associatedDevice_callback callback_proc)` | Callback function pointer | None | `void`; no registration status | Caller code must remain callable; payload lifetime/ownership unknown; T/E; no unregister/drain. |

### ACA Control and Results: 5 Functions

| Exact signature | Inputs | Outputs | Result | Memory and concurrency caveats |
| --- | --- | --- | --- | --- |
| `int moca_setIfAcaConfig(int interfaceIndex, moca_aca_cfg_t acaCfg)` | Signed index; configuration **by value** | None | S or `STATUS_INPROGRESS`; failure and in-progress both equal -1 | T; TRUE starts immediately, FALSE configures only; running ACA prevents a new start. |
| `int moca_getIfAcaConfig(int interfaceIndex, moca_aca_cfg_t *acaCfg)` | Signed index | ACA configuration | S | Caller structure; T. |
| `int moca_cancelIfAca(int interfaceIndex)` | Signed index | None | S; success also when no ACA is running | No storage transfer; T; no callback-drain or hard deadline guarantee. |
| `int moca_getIfAcaStatus(int interfaceIndex, moca_aca_stat_t *pacaStat)` | Signed index | ACA status/results/configuration | S; no valid ACA information on failure | Caller structure; T; function return and `stat` field are distinct channels. |
| `int moca_getIfScmod(int interfaceIndex, int *pnumOfEntries, moca_scmod_stat_t **ppscmodStat)` | Signed index; caller-allocated backing array | Entry count and SCMOD array | S; no valid SCMOD information on failure | Caller allocation explicitly required; capacity/maximum and replacement rules unspecified; T. |

## Types, Constants, and Data Reference

### Common Macros and ABI

| Macro | Default | Meaning/caveat |
| --- | --- | --- |
| `ULONG`, `BOOL`, `CHAR`, `UCHAR`, `INT`, `UINT` | `unsigned long`, `unsigned char`, `char`, `unsigned char`, `int`, `unsigned int` | Guarded macros, not fixed-width typedefs; caller/vendor definitions and ABI must agree. |
| `TRUE`, `FALSE`, `ENABLE` | 1, 0, 1 | Guarded value macros; no corresponding `DISABLE` is declared. |
| `STATUS_SUCCESS`, `STATUS_FAILURE`, `STATUS_NOT_AVAILABLE` | 0, -1, -2 | Guarded generic values. The presence of -2 does not establish that every API returns it. |
| `STATUS_INPROGRESS`, `STATUS_NO_NODE` | -1, -2 | ACA-related values alias generic failure/not-available. |
| `STATUS_INVALID_PROBE`, `STATUS_INVALID_CHAN` | -3, -4 | Defined constants; individual functions do not comprehensively specify their use. |
| `kMoca_MaxCpeList`, `kMoca_MaxMocaNodes` | 256, 16 | Different CPE/node maxima; do not equate attached clients with MoCA node count. |
| `MAC_PADDING` | 12 | Makes selected six-byte MAC buffers 18 bytes; representation remains ambiguous. |
| `__MOCA_HAL_H__` | Include guard | Not a runtime capability. |
| `MOCA_VAR` | Externally controlled | Removes selected types and full-mesh function; see variability defect below. |

`ULONG` can be 32 or 64 bits; comments describing 32-bit ranges do not make it
fixed-width. No packing, enum width, structure offsets, or `extern "C"` wrapper is
declared. C++ callers need appropriate linkage integration. `#ifndef` checks macros,
not existing typedefs. No target ABI is certified by this source-only document.

### Enumerations and Callback

| Type | Complete values/signature | Caveats |
| --- | --- | --- |
| `moca_if_status_t` | `IF_STATUS_Up=1`, `IF_STATUS_Down=2`, `IF_STATUS_Unknown=3`, `IF_STATUS_Dormant=4`, `IF_STATUS_NotPresent=5`, `IF_STATUS_LowerLayerDown=6`, `IF_STATUS_Error=7` | Only without `MOCA_VAR`; states do not define legal transitions. |
| `PROBE_TYPE` | `PROBE_QUITE=0`, `PROBE_EVM=1` | Preserve spelling `QUITE`; comments describe quiet/no transmission versus EVM signal transmission. |
| `moca_associatedDevice_callback` | `typedef INT (*moca_associatedDevice_callback)(ULONG ifIndex, moca_associated_device_t *moca_dev);` | Device `Active` indicates activated/deactivated. Return is described only as a handling status; specific values and HAL response are unspecified. |
| `ACA_STATUS` | Disabled by `#if 0`: `STAT_SUCCESS=0`, `STAT_FAIL_BADCHANNEL=1`, `STAT_FAIL_NOEVMPROBE=2`, `STAT_FAIL=3`, `STAT_INPROGRESS=4` | Not an active public enum; do not reference these names as compiled constants. |

### Configuration and Static/Dynamic Structures

Rows group fields only when their exact C type is the same. All fields are listed.

| Structure | Fields and exact types | Declared meaning / limitation |
| --- | --- | --- |
| `moca_cfg_t` | `ULONG InstanceNumber` | 0 for single interface, 1–256 for multiple; interface discovery/mapping not provided. |
| Same | `CHAR Alias[64]`, `CHAR KeyPassphrase[18]` | Vendor alias; privacy password used when enabled. Capacity includes storage, not a guarantee of room for maximum stated characters plus terminator. |
| Same | `BOOL bEnabled`, `bPreferredNC`, `PrivacyEnabledSetting` | Enable, prefer NC, privacy setting. |
| Same | `UCHAR FreqCurrentMaskSetting[128]`, `NodeTabooMask[128]`, `ChannelScanMask[128]` | Vendor-specific operating, taboo and scanning masks. |
| Same | `INT TxPowerLimit` | Signed power limit; units not standardized here. |
| Same | `ULONG AutoPowerControlPhyRate`, `BeaconPowerLimit`, `MaxIngressBWThreshold`, `MaxEgressBWThreshold` | Target PHY rate, beacon power and thresholds; comments use 32-bit ranges despite ABI-dependent type; clarify units. |
| Same | `BOOL Reset`, `MixedMode`, `ChannelScanning`, `AutoPowerControlEnable`, `EnableTabooBit` | Reset defaults, mixed 1.0/1.1/2.0 operation, scanning, power control and taboo support; ordering/partial update semantics unspecified. |
| `moca_static_info_t` | `CHAR Name[64]`, `FirmwareVersion[64]`, `HighestVersion[64]` | Interface name, vendor firmware and highest supported version. |
| Same | `UCHAR MacAddress[6 + MAC_PADDING]` | Local MAC buffer; comments combine six-byte and textual representation conventions. |
| Same | `ULONG MaxBitRate`, `TxBcastPowerReduction` | Maximum PHY rate; beacon backoff in dB. |
| Same | `UCHAR FreqCapabilityMask[8]`, `NetworkTabooMask[128]` | Vendor-defined frequency support/taboo masks. |
| Same | `BOOL QAM256Capable`, `PacketAggregationCapability` | QAM-256 and Ethernet packet aggregation support. |
| `moca_dynamic_info_t` | `moca_if_status_t Status` | Current interface status; entire structure excluded with `MOCA_VAR`. |
| Same | `ULONG LastChange`, `LinkUpTime` | Last change in seconds since epoch; duration connected to at least one other node in seconds. Epoch clock source, wrap and reset handling unspecified. |
| Same | `ULONG MaxIngressBW`, `MaxEgressBW` | Maximum reached bandwidth in bits/s. |
| Same | `CHAR CurrentVersion[64]` | Current MoCA version. |
| Same | `ULONG NetworkCoordinator`, `NodeID`, `BackupNC` | NC/local/backup IDs: 0–7 for 1.0; 0–15 for 1.1/2.0. |
| Same | `BOOL PrivacyEnabled`, `MaxIngressBWThresholdReached`, `MaxEgressBWThresholdReached` | Privacy and threshold flags. |
| Same | `UCHAR FreqCurrentMask[8]` | Vendor-defined current frequencies; differs in size from configuration mask. |
| Same | `ULONG CurrentOperFreq`, `LastOperFreq`, `TxBcastRate` | Current/previous frequency and broadcast rate; units vendor-dependent or unstated. |
| Same | `ULONG NumberOfConnectedClients` | Documented 0–256; not necessarily number of MoCA nodes. |
| Same | `CHAR NetworkCoordinatorMACAddress[18]` | Textual MAC example; termination requirements need confirmation. |

### Counter Structures

| Structure | Complete fields | Meaning / limitations |
| --- | --- | --- |
| `moca_stats_t` | All `ULONG`: `BytesSent`, `BytesReceived`, `PacketsSent`, `PacketsReceived`, `ErrorsSent`, `ErrorsReceived`, `UnicastPacketsSent`, `UnicastPacketsReceived`, `DiscardPacketsSent`, `DiscardPacketsReceived`, `MulticastPacketsSent`, `MulticastPacketsReceived`, `BroadcastPacketsSent`, `BroadcastPacketsReceived`, `UnknownProtoPacketsReceived`, `ExtAggrAverageTx`, `ExtAggrAverageRx` | Byte/packet/error/drop totals and vendor-specific aggregation averages. No counting epoch, wrap, reset, average window, or atomic snapshot contract. |
| `moca_mac_counters_t` | All `ULONG`: `Map`, `Rsrv`, `Lc`, `Adm`, `Probe`, `Async` | Received MAP, reservation, link control, admission, probe, asynchronous/beacon packets. |
| `moca_aggregate_counters_t` | `ULONG Tx`, `Rx` | Transmitted/received PDUs excluding MoCA control packets; rollover/clear-on-read unspecified. |

### Device, Mesh, and Flow Structures

| Structure | Fields and exact types | Meaning / limitation |
| --- | --- | --- |
| `moca_cpe_t` | `CHAR mac_addr[6]` | Six-byte MAC storage; textual example cannot fit as text. |
| `moca_associated_device_t` | `UCHAR MACAddress[6 + MAC_PADDING]` | Associated-device MAC; binary/text interpretation unresolved. |
| Same | `ULONG NodeID`, `PHYTxRate`, `PHYRxRate`, `TxPowerControlReduction` | Node ID, PHY rates and reduction in dB; PHY-rate units not explicit. |
| Same | `BOOL PreferredNC`, `QAM256Capable`, `PacketAggregationCapability`, `Active` | Preferred NC, capabilities, activated/deactivated state. |
| Same | `CHAR HighestVersion[64]` | Highest supported version. |
| Same | `INT RxPowerLevel`, `RxBcastPowerLevel` | Received unicast/broadcast power in dBm. |
| Same | `ULONG TxBcastRate`, `RxBcastRate`, `RxSNR` | Broadcast rates and SNR; units/range need clarification. |
| Same | `ULONG TxPackets`, `RxPackets`, `RxErroredAndMissedPackets`, `NumberOfClients` | Packet/error counts and clients attached to this node. |
| `moca_mesh_table_t` | All `ULONG`: `RxNodeID`, `TxNodeID`, `TxRate`, `TxRateNper`, `TxRateVlper` | Directed Tx-to-Rx rates in Mbps; NPER/VLPER for MoCA 2.x. Excluded with `MOCA_VAR`; diagonal/ordering/cardinality unspecified. |
| `moca_flow_table_t` | `ULONG FlowID`, `IngressNodeID`, `EgressNodeID`, `FlowTimeLeft` | PQoS flow ID, endpoints and remaining lease time; remaining-time unit not explicit. |
| Same | `char DestinationMACAddress[18]` | Destination Ethernet MAC text example. |
| Same | `ULONG PacketSize`, `PeakDataRate`, `BurstSize`, `FlowTag`, `LeaseTime` | PacketSize comment means aggregated frame count; peak bits/s, burst bytes, application tag, initial lease seconds. |
| `moca_assoc_pnc_info_t` (tag `moca_assoc_pnc_info`) | `ULONG mocaNodeIndex`, `BOOL mocaNodePreferredNC`, `ULONG mocaNodeMocaversion` | Node index, NC preference, version encodings such as 10/11/20. No declared API directly consumes or returns this structure. |

### ACA and Subcarrier Structures

| Structure | Complete fields and types | Meaning / limitation |
| --- | --- | --- |
| `moca_scmod_stat_t` | `INT TxNode`, `RxNode`, `Channel`; `UCHAR Mod[512]`, `Nper[512]`, `Vlper[512]` | Node pair/channel and per-subcarrier data. Comments claim 32-bit element ranges, incompatible with unsigned-char storage on conventional 8-bit-byte targets. |
| `moca_aca_cfg_t` | `UINT NodeID`; `PROBE_TYPE Type`; `UINT Channel`, `ReportNodes`; `BOOL ACAStart` | Probe target/type/channel; report bitmask LSB = node 0; TRUE starts, FALSE configures without starting. Bounds/channel mapping unspecified. |
| `moca_aca_stat_t` | `moca_aca_cfg_t acaCfg`; `INT stat`, `RxPower`; `INT ACAPowProfile[512]`; `BOOL ACATrapCompleted` | Config, result state, total received dBm, power-profile entries described as channel dBm, and profile-ready flag. Exact channel/subcarrier mapping unspecified. |

`moca_aca_stat_t.stat` comments define 0 success, 1 bad channel, 2 no EVM probe,
3 failure, 4 in progress. These positive result states are distinct from the
negative function-result macros. `ACATrapCompleted` is a field, not a declared trap
registration or completion-callback API.

## Runtime Execution and Integration Policies

### Presence, Startup, and Configuration

**Declared:** presence can be queried, configuration read/written, and dynamic/static
information retrieved. No `init`, `open`, readiness, `deinit`, or `close` API is declared.

**Integration policy:** establish vendor/platform readiness before calls. Presence
does not prove link readiness. Read current configuration, change only intended fields,
check the setter result and read back exposed settings. This is a recommended workflow,
not a header-mandated ordering or a transaction. Reset is a configuration field, not a
guaranteed resource cleanup/reset lifecycle. Preserve privacy credentials carefully;
never log passphrases or publish their values.

### Memory and Capacity

Callers allocate structures, array storage, pointer slots, and count outputs and release
their own allocations. Vendor-internal resources remain vendor-managed. Double-pointer
replacement/retention is not specified; obtain agreement before relying on pointer identity.

`moca_GetMocaCPEs()` explicitly requires 256 entries. The 16-node constant does not
alone establish associated-device, flow, or SCMOD capacities. Full mesh requires all
possible pairs but does not specify inclusion of self-pairs or ordering. Do not convert
a theoretical 16-by-16 matrix into an undocumented capacity guarantee.

Count-then-list calls can race network membership changes and do not establish a safe
capacity protocol. Several APIs cannot receive capacity at all. Agree maximum sizes,
allocation strategy, written-count bounds, zero-entry behavior, and failure cleanup with
the vendor before invoking them. Do not infer HAL allocation from `**` parameters.

The previous specification required zero-terminated strings. Retain that as an integration
policy, but the header does not guarantee termination or define whether stated maxima
include the terminator. Treat binary MAC/mask arrays separately from text. Pre-zeroing
does not guarantee termination when the complete buffer can be overwritten.

### Threading, Processes, and Notifications

The header has no thread-safety or cross-process protection guarantee. Retain the previous
client-serialization policy and vendor multi-process protection expectation as requirements
to validate, not proven behavior. A process-local mutex does not coordinate other processes.

The association callback receives interface index and device information; `Active`
distinguishes activation/deactivation. Payload ownership, lifetime, copying, event loss,
ordering, duplicate delivery, initial replay, and concurrency with list snapshots are unknown.
Callback return values and retry behavior are not defined. Registration returns `void`
and has no unregister, handle, context pointer, replacement, or drain contract.

Keep callback code callable while delivery is possible. Copy required fields only under
a vendor-confirmed valid invocation lifetime and queue follow-up work to the serialized
owner. Do not free a borrowed payload, assume reentrant HAL calls, or register NULL as
an undocumented unsubscribe. Registration plus snapshot is a reconciliation recommendation,
not an atomic lossless protocol.

### Blocking, Errors, and ACA Progress

The older narrative simultaneously expected hardware-readiness blocking and non-blocking
single-threaded use. The header gives no deadlines, generic cancellation, or execution
annotations. Treat responsiveness and bounded startup as product requirements to measure.
A watchdog does not cancel a blocked C function; do not free resources still in use.

Most APIs use S; exceptions are frequency conversion, hardware presence, void registration,
and ACA configuration's overlapping in-progress value. Do not treat every result as a generic
success/failure code or assume `STATUS_NOT_AVAILABLE` is universally returned. No general
`errno` contract is declared.

ACA TRUE starts immediately; FALSE sets configuration without starting. A new start while
ACA is running is rejected as in-progress, but -1 cannot distinguish that from generic failure.
Cancellation succeeds when nothing is running. Status retrieval returns valid information on
success; its `stat` and profile-ready flag must be interpreted separately. No completion
deadline, result-generation ID, retention period, cancellation-drain acknowledgment, or
full legal transition graph is specified. Polling intervals and stale-result handling
therefore need a vendor contract.

`moca_GetResetCount()` alone explicitly preserves its output on failure.
ACA status/SCMOD failures yield no valid information. Do not generalize either behavior
to every getter or assume setter failure leaves configuration unchanged.

### Persistence, Power, and Shutdown

Retain the prior policy that application/client code persists required settings; the header
does not promise persistence or reset/reboot retention. No dedicated power-management API
exists. Disabling an interface is not documented as releasing resources or powering hardware.

Recommended shutdown: stop new calls and polling, cancel a running ACA if appropriate,
coordinate platform/vendor event quiescence, and release caller resources only when no
delivery or call can still access them. ACA cancellation is not callback unregistration
or vendor-library deinitialization. The header cannot acknowledge generic quiescence.

## Illustrative Operational Lifecycle

This is an integration example, not a normative ordering/state machine. Vendor readiness
and cleanup are deliberately outside the HAL. Every named Client-to-HAL call is declared.

~~~mermaid
sequenceDiagram
    participant Client as CCSP MoCA Client
    participant HAL as MoCA HAL
    participant Vendor as Vendor Driver and Firmware
    participant Platform as Platform Lifecycle
    Client->>Platform: Establish product-specific readiness
    Platform-->>Client: Platform-defined readiness result
    Client->>HAL: moca_HardwareEquipped()
    HAL-->>Client: TRUE or FALSE
    alt Hardware available
        Client->>HAL: moca_GetIfConfig(ifIndex, config)
        HAL->>Vendor: Read configuration
        Vendor-->>HAL: Values or failure
        HAL-->>Client: STATUS_SUCCESS or STATUS_FAILURE
        Note over Client,HAL: Continue dependent work only after checking each result
        Client->>HAL: moca_SetIfConfig(ifIndex, config)
        HAL-->>Client: STATUS_SUCCESS or STATUS_FAILURE
        Client->>HAL: moca_associatedDevice_callback_register(callback)
        HAL-->>Client: void - registration status unavailable
        loop Snapshot and periodic observation
            Client->>HAL: moca_IfGetDynamicInfo(ifIndex, dynamicInfo)
            HAL-->>Client: Status and outputs on success
            Client->>HAL: moca_IfGetStats(ifIndex, stats)
            HAL-->>Client: Status and counters on success
        end
        opt Vendor detects device activation or deactivation
            Vendor-->>HAL: Device observation
            HAL-->>Client: Registered callback with ifIndex and device
            Client-->>HAL: Callback handling status
            Note over Client,HAL: Payload lifetime and handling-status semantics require agreement
        end
        opt Product requests ACA
            Client->>HAL: moca_setIfAcaConfig(interfaceIndex, acaCfg)
            HAL-->>Client: Success or overlapping failure and in-progress code
            loop Product-defined polling after accepted start
                Client->>HAL: moca_getIfAcaStatus(interfaceIndex, acaStat)
                HAL-->>Client: Function status and separate ACA result fields
            end
            opt Cancellation required
                Client->>HAL: moca_cancelIfAca(interfaceIndex)
                HAL-->>Client: STATUS_SUCCESS or STATUS_FAILURE
            end
        end
        Client->>Client: Stop new work and polling
        Client->>Platform: Coordinate events and in-flight call quiescence
        Platform->>Vendor: Product-specific cleanup if supported
        Note over Client,Platform: No HAL unregister, drain or deinit API
    else Hardware unavailable
        Client->>Client: Stop dependent setup and report availability
    end
~~~

The dynamic-information call in this example requires the ordinary profile without
`MOCA_VAR`, or an explicitly supplied compatible external definition in the other profile.
The sequence does not require a configuration write before every getter. Admin/link states,
ACA progress, client membership, and physical forwarding are separate observations.

## Product Variability and Contract Gaps

### Compile-Time Profiles

| Profile | Declared surface | Important limitation |
| --- | --- | --- |
| `MOCA_VAR` not defined | 21 functions, 14 structures, 2 active enums, 1 callback type | Baseline interface; actual implementation support still requires verification. |
| `MOCA_VAR` defined | 20 function declarations; 12 structures; `PROBE_TYPE` and callback remain | `moca_if_status_t`, `moca_dynamic_info_t`, `moca_mesh_table_t`, and `moca_GetFullMeshRates()` are excluded, but `moca_IfGetDynamicInfo()` still references the excluded dynamic type. |

The second profile is not self-contained unless an including environment supplies a
compatible `moca_dynamic_info_t`. Do not claim that dynamic-info functionality is cleanly
removed or that the header compiles standalone in that profile. The disabled `ACA_STATUS`
block is absent in both profiles. No runtime interface-version negotiation is declared.

### Vendor Clarification Checklist

| ID | Header evidence / missing contract | Consequence and required clarification |
| --- | --- | --- |
| G01 | `MOCA_VAR` removes a type used by an unconditional prototype. | Establish external definition requirements or pursue a separate compatibility-reviewed header correction. |
| G02 | Array APIs omit capacities; associated-device API also omits count. | Agree maximum backing sizes, safe retrieval protocol, zero-count behavior, and concurrent membership handling. |
| G03 | Double-pointer APIs require caller allocation but omit replacement/retention rules. | Define pointer identity, storage lifetime and failure cleanup; never assume HAL allocation. |
| G04 | `STATUS_FAILURE` and `STATUS_INPROGRESS` both -1; `STATUS_NOT_AVAILABLE` and `STATUS_NO_NODE` both -2. | Numeric results cannot distinguish meanings without API-specific/vendor diagnostics. |
| G05 | Positive ACA result-field values coexist with negative function statuses; enum disabled. | Keep channels separate; define stale results, completion readiness, and valid transitions. |
| G06 | MAC arrays mix six-byte storage, padded 18-byte storage, and textual examples. | Confirm per-field binary/text representation, padding, termination and byte order. |
| G07 | 64-/18-character comments match total array capacities. | Clarify terminator-inclusive bounds for strings, especially passphrases. |
| G08 | Configuration masks are 128 bytes, observation masks 8, conversion requires at least 16. | Specify format, length, bit/frequency mapping and units; buffers are not interchangeable. |
| G09 | `ULONG` widths conflict with comments assuming 32-bit ranges; SCMOD bytes claim 32-bit values. | Match caller/vendor ABI and clarify true representable ranges. |
| G10 | Interface indices use `ULONG` in most APIs and `int` in ACA; single/multiple conventions differ. | Specify discovery, valid ranges and mapping without unchecked signed conversions. |
| G11 | No registration result, unregister/drain, context, lifetime, subscriber or event reliability contract. | Agree safe startup/shutdown, replacement, null behavior, race handling and callback errors. |
| G12 | No thread/process-safety or call deadline contract. | Validate serialization, cross-process protection, responsiveness and supervision. |
| G13 | No initialize, readiness, close, power or persistence APIs. | Define platform lifecycle; do not invent HAL entry points or readiness guarantees. |
| G14 | Setter transaction, rollback, reset effects and read-after-write timing unspecified. | Verify behavior and recovery; success alone does not prove link convergence or forwarding. |
| G15 | Counter epochs, wrap/reset and snapshot/average semantics unspecified. | Define meaningful comparisons and rate calculations across device resets and ABIs. |
| G16 | Several power/rate/frequency/time units and valid probe/channel bounds unstated. | Confirm units, channel map, report-mask width and supported hardware choices. |
| G17 | `moca_assoc_pnc_info_t` has no consuming/producing API; flow APIs are retrieval only. | Do not infer NC mutation, PQoS creation or other absent functionality. |
| G18 | Generic failures lack typed causes; frequency conversion and presence lack diagnostic error channels. | Agree unsupported/error diagnostics; do not invent `errno` or universal -2 behavior. |

## Nonfunctional Requirements and Integration Policies

These retain useful expectations from the previous specification. They are not evidence
that a particular vendor library already satisfies them.

### Logging and Debugging

Prefer platform/syslog integration over ad hoc `printf`; record timestamps, severity,
operation, interface and useful vendor diagnostics. Retain `moca_vendor_hal.log` under
`/var/tmp/` or `/rdklogs/logs/` as an integration convention to confirm per product.
Map FATAL, ERROR, WARNING, NOTICE, INFO, DEBUG and TRACE to available platform levels;
not all names are native syslog priorities. Never log privacy passphrases and minimize
unnecessary disclosure of connected-client identities.

### Memory, Performance, and Quality

Callers manage supplied buffers; vendors manage internal allocations, threads, handles,
and failure cleanup. Avoid leaks and honor agreed bounds. Numeric memory budgets and
latency/event-throughput limits remain unspecified and need product acceptance criteria.

Retain static analysis, dependency/license scanning, and runtime memory tooling such as
Coverity, Black Duck and Valgrind where applicable. Test invalid inputs only against defined
or vendor-agreed expectations; exercise buffer/count bounds, callback races, ACA overlap,
cancellation, configuration failure, reboot and counter rollover. Source or compiler checks
are not substitutes for direct vendor HAL execution and independently observed network behavior.

### Build, Licensing, and Versioning

The retained packaging expectation is a Yocto-compatible vendor `libhal_moca.so`.
Consumers include `moca_hal.h` and link the compatible implementation. The header does
not prescribe compiler version, target ABI, SDK dependency, or shared-library deployment path.

The header carries Apache License 2.0 notices. Retain the expectation that the HAL
implementation is released under Apache License 2.0; inspect vendor SDK/firmware licenses
separately. Retain [Semantic Versioning](https://semver.org/) and agreed vendor interface
revisions as integration policies; no runtime negotiation API is present.

## Source Traceability and Review Checklist

| Source anchor in `moca_hal.h` | Specification coverage | Evidence boundary |
| --- | --- | --- |
| Common macros and `MOCA_VAR` branches | ABI, constants and compile-time profiles | Source declarations, not runtime support discovery. |
| All 21 function declarations | Three API tables: 9 + 7 + 5 | Complete source surface, including conditional mesh function. |
| Fourteen structure definitions and their fields | Configuration, counters, device/mesh/flow and ACA tables | Storage and comment semantics; no certified layout or vendor behavior. |
| `moca_if_status_t`, `PROBE_TYPE`, disabled `ACA_STATUS` | Enum table and variability | Active values distinguished from disabled names. |
| `moca_associatedDevice_callback` and registration | Event inventory and async policy | No inferred unregister or delivery guarantee. |
| Array, status and mask comments | G02–G09 and memory/error policies | Contradictions retained as explicit gaps. |

Before product integration:

- Match feature profile, types and caller/vendor ABI.
- Resolve array capacity and MAC/mask representation before invoking list/conversion APIs.
- Establish readiness, error diagnostics, callback lifetime and safe quiescence.
- Verify ACA numeric status interpretation, polling and cancellation on the real implementation.
- Measure network effects, counter semantics and performance independently.
- Preserve the root README symlink to this canonical document when updating it.

This document is a source-reviewed specification, not a vendor implementation certification.
The reusable workspace workflow is `.kavia/workflows/recreate-component-spec.md` at the
workspace root; it applies separately to explicitly selected components.
