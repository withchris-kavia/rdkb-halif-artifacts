# Platform HAL Specification

## Scope and evidence

[platform_hal.h](../../include/platform_hal.h) declares platform identity, service access settings, firmware metadata, memory information, LED/fan/thermal controls, MACsec, DHCP options, low-power state control, DSCP accounting, interface statistics, PPP credentials, and flow QoS.

HAL means Hardware Abstraction Layer; MACsec means Media Access Control Security; DSCP means Differentiated Services Code Point. This is a declaration-based contract specification, not verified vendor behavior. No generic context handle, deinitializer, callback registration, or complete runtime capability-discovery mechanism is declared.

## Architecture

~~~mermaid
flowchart TD
    C["RDK-B management caller"] --> H["platform_hal.h"]
    H --> V["Vendor platform implementation"]
    V --> I["Identity, firmware, memory and configuration"]
    V --> P["LED, fan, thermal and low-power services"]
    V --> N["MACsec, DHCP, DSCP, statistics and QoS"]
~~~

Vendor subsystem labels are conceptual. Header inclusion or enum presence does not prove hardware support.

## Complete API inventory

The following list preserves declared argument types and order. `FEATURE_RDKB_LED_MANAGER` and `FEATURE_RDKB_THERMAL_MANAGER` affect the available surface and LED struct layout.

### Base identity, configuration, memory and firmware

~~~c
INT platform_hal_GetDeviceConfigStatus(CHAR *pValue);
INT platform_hal_GetTelnetEnable(BOOLEAN *pFlag);
INT platform_hal_SetTelnetEnable(BOOLEAN Flag);
INT platform_hal_GetSSHEnable(BOOLEAN *pFlag);
INT platform_hal_SetSSHEnable(BOOLEAN Flag);
INT platform_hal_GetSNMPEnable(CHAR *pValue);
INT platform_hal_SetSNMPEnable(CHAR *pValue);
INT platform_hal_GetWebUITimeout(ULONG *pValue);
INT platform_hal_SetWebUITimeout(ULONG value);
INT platform_hal_GetWebAccessLevel(INT userIndex, INT ifIndex, ULONG *pValue);
INT platform_hal_SetWebAccessLevel(INT userIndex, INT ifIndex, ULONG value);
INT platform_hal_PandMDBInit(void);
INT platform_hal_DocsisParamsDBInit(void);
INT platform_hal_GetModelName(CHAR *pValue);
INT platform_hal_GetRouterRegion(CHAR *pValue);
INT platform_hal_GetSerialNumber(CHAR *pValue);
INT platform_hal_GetHardwareVersion(CHAR *pValue);
INT platform_hal_GetSoftwareVersion(CHAR* pValue, ULONG maxSize);
INT platform_hal_GetBootloaderVersion(CHAR *pValue, ULONG maxSize);
INT platform_hal_GetFirmwareName(CHAR *pValue, ULONG maxSize);
INT platform_hal_GetBaseMacAddress(CHAR *pValue);
INT platform_hal_GetHardware(CHAR *pValue);
INT platform_hal_GetHardware_MemUsed(CHAR *pValue);
INT platform_hal_GetHardware_MemFree(CHAR *pValue);
INT platform_hal_GetTotalMemorySize(ULONG *pulSize);
INT platform_hal_GetUsedMemorySize(ULONG *pulSize);
INT platform_hal_GetFreeMemorySize(ULONG *pulSize);
INT platform_hal_GetFactoryResetCount(ULONG *pulSize);
INT platform_hal_ClearResetCount(BOOLEAN bFlag);
INT platform_hal_getTimeOffSet(CHAR *timeOffSet);
INT platform_hal_SetDeviceCodeImageTimeout(INT seconds);
INT platform_hal_SetDeviceCodeImageValid(BOOLEAN flag);
INT platform_hal_getFactoryPartnerId(CHAR *pValue);
INT platform_hal_getFactoryCmVariant(CHAR *pValue);
INT platform_hal_setFactoryCmVariant(CHAR *pValue);
~~~

### LED, fan and conditional thermal management

~~~c
#ifdef FEATURE_RDKB_LED_MANAGER
int platform_hal_initLed(char *config_file_name);
#endif
INT platform_hal_setLed(PLEDMGMT_PARAMS pValue);
INT platform_hal_getLed(PLEDMGMT_PARAMS pValue);
UINT platform_hal_getFanSpeed(UINT fanIndex);
UINT platform_hal_getRPM(UINT fanIndex);
INT platform_hal_getRotorLock(UINT fanIndex);
BOOLEAN platform_hal_getFanStatus(UINT fanIndex);
INT platform_hal_setFanMaxOverride(BOOLEAN bOverrideFlag, UINT fanIndex);
#ifdef FEATURE_RDKB_THERMAL_MANAGER
INT platform_hal_initThermal(THERMAL_PLATFORM_CONFIG *pThermalPlatformConfig);
INT platform_hal_LoadThermalConfig(THERMAL_PLATFORM_CONFIG *pThermalPlatformConfig);
INT platform_hal_setFanSpeed(UINT fanIndex, FAN_SPEED fanSpeed, FAN_ERR *pErrReason);
INT platform_hal_getFanTemperature(INT *pTemp);
INT platform_hal_getInputCurrent(INT *pValue);
INT platform_hal_getInputPower(INT *pValue);
INT platform_hal_getRadioTemperature(INT radioIndex, INT *pValue);
INT platform_hal_getEcoModeStatus(INT radioIndex, INT *pValue);
#endif
~~~

### Network, low-power, traffic and credential operations

~~~c
INT platform_hal_SetSNMPOnboardRebootEnable(CHAR *pValue);
INT platform_hal_GetMACsecEnable(INT ethPort, BOOLEAN *pFlag);
INT platform_hal_SetMACsecEnable(INT ethPort, BOOLEAN Flag);
INT platform_hal_GetMACsecOperationalStatus(INT ethPort, BOOLEAN *pFlag);
INT platform_hal_StartMACsec(INT ethPort, INT timeoutSec);
INT platform_hal_StopMACsec(INT ethPort);
INT platform_hal_GetMemoryPaths(RDK_CPUS index, PPLAT_PROC_MEM_INFO *ppinfo);
INT platform_hal_GetDhcpv4_Options(dhcp_opt_list **req_opt_list, dhcp_opt_list **send_opt_list);
INT platform_hal_GetDhcpv6_Options(dhcp_opt_list **req_opt_list, dhcp_opt_list **send_opt_list);
INT platform_hal_SetLowPowerModeState(PPSM_STATE pState);
INT platform_hal_getCMTSMac(CHAR *pValue);
INT platform_hal_setDscp(WAN_INTERFACE interfaceType, TRAFFIC_CNT_COMMAND cmd, char *pDscpVals);
INT platform_hal_resetDscpCounts(WAN_INTERFACE interfaceType);
INT platform_hal_getDscpClientList(WAN_INTERFACE interfaceType, pDSCP_list_t pDSCP_List);
INT platform_hal_GetCPUSpeed(char *cpuSpeed);
INT platform_hal_GetFirmwareBankInfo(FW_BANK bankIndex, PFW_BANK_INFO pFW_Bankinfo);
INT platform_hal_GetInterfaceStats(const char *ifname, PINTF_STATS pIntfStats);
INT platform_hal_GetPppUserName(CHAR* pUserName, ULONG maxSize);
INT platform_hal_GetPppPassword(CHAR* pPassword, ULONG maxSize);
INT platform_hal_qos_apply(const hal_network_params_t *params);
~~~

### Argument and return contracts

| Family | Header detail |
| --- | --- |
| Common status | Most `INT` operations use `RETURN_OK=0`/`RETURN_ERR=-1`. Some thermal APIs explicitly permit `RETURN_UNSUPPORTED=-2`; do not generalize that return to all operations. QoS documents zero success and negative error. |
| Direct fan returns | `getFanSpeed` and `getRPM` return raw `UINT` measurements; do not interpret them as status. `getRotorLock` returns `1/0/-1`; `getFanStatus` returns a Boolean. Fan indices are documented as `0..1`; raw speed units are OEM-specific. |
| Access settings | Telnet/SSH use Boolean arguments. SNMP enable strings include `rgWan`, `rgDualIp`, `rgLanIp`; buffers are documented as 32 bytes. Web timeout is documented as 30..86400 seconds, default 840; setter also permits zero with semantics needing clarification. Web access-level APIs are marked for future deprecation. |
| Lengthless strings | Device config status: 128 bytes. Model, region, serial, hardware version, base MAC and hardware flash-size string: 256 bytes. Used-memory string: documented 1024..2048; free-memory string: 1024. Time-offset string: 256. Factory partner/CM variant: 512. CMTS MAC: 100. CPU-speed string: 64. These are API-comment buffer guidance, not universal string limits. |
| Explicit capacities | Software/bootloader/firmware version and PPP credential getters accept `maxSize`; confirm truncation and termination behavior. |
| Memory | Total/used/free memory sizes describe DRAM in MB. `GetHardware` describes flash size in MB. `GetMemoryPaths` returns allocated path information through a double pointer, but supplies no count/release entry point. |
| Image validity | Code-image timeout accepts 0..3600 seconds; validity setter is Boolean. These are not a complete firmware-upgrade/rollback API. |
| LED | `initLed` config filename guidance is 128 bytes. Struct `State` is `0=solid`, `1=blink`; `Interval` is seconds. LED-name/parameter fields are conditional. |
| Thermal | Temperature values are Celsius; input current mA, input power mW. Radio-temperature index is documented `0..2`; eco-mode radio index `0..1`. Fan-speed setting has both operation status and `FAN_ERR` reason. |
| MACsec | Start/stop are documented blocking operations. Start has `timeoutSec`; zero is described as retrying forever, while the comment also calls the parameter unused. Resolve this before relying on bounded blocking. Enable and operational status are separate observables. |
| Low power | Setter accepts `PPSM_STATE`, a pointer to enum, not an enum value. No general transition table is declared. |
| DSCP | CSV string guidance is maximum 195 bytes; NULL means all values. Header's 0..65534 range conflicts with six-bit DSCP. Do not substitute that range into the QoS struct, which documents 0..63. |
| Interface statistics | `GetInterfaceStats` comments limit support to LAN/WAN interfaces. No global support for every interface type follows from accepting a string. |
| CPU speed | Comments describe bogomips text; do not silently relabel it MHz. |

## Complete enum inventory

| Type | Members and values |
| --- | --- |
| `RDK_CPUS` | `HOST_CPU=0`, `PEER_CPU=1`, `NOT_SUPPORTED_CPU=3`. |
| `LED_COLOR` | `LED_WHITE=0`, `LED_YELLOW=1`, `LED_GREEN=2`, `LED_RED=3`, `LED_BLUE=4`, `LED_RED_AND_GREEN=5`, `LED_YELLOW_AND_GREEN=6`, `NOT_SUPPORTED=7`. |
| `FAN_SPEED` (thermal guard) | `FAN_SPEED_OFF=0`, `FAN_SPEED_SLOW=1`, `FAN_SPEED_MEDIUM=2`, `FAN_SPEED_FAST=3`, `FAN_SPEED_MAX=4`. |
| `FAN_ERR` (thermal guard) | `FAN_ERR_NONE=0`, `FAN_ERR_HW=1`, `FAN_ERR_MAX_OVERRIDE_SET=2`. |
| `PSM_STATE`, pointer alias `PPSM_STATE` | `PSM_UNKNOWN=0`, `PSM_AC=1`, `PSM_BATT=2`, `PSM_HOT=3`, `PSM_COOLED=4`, `PSM_NOT_SUPPORTED=5`. |
| `WAN_INTERFACE` | `DOCSIS=1`, `EWAN=2`, `EPON=3`, `XGSPON=4`, `WAN_INTERFACE_MAX=5`. |
| `TRAFFIC_CNT_COMMAND` | `TRAFFIC_CNT_START=1`, `TRAFFIC_CNT_STOP=2`. |
| `FW_BANK` | `ACTIVE_BANK=0`, `INACTIVE_BANK=1`. |
| `ip_version_t` | `IP_VERSION_IPV4=0`, `IP_VERSION_IPV6=1`. |
| `net_proto_t` | `PROTOCOL_TCP=0`, `PROTOCOL_UDP=1`. |

## Complete struct inventory

| Type and pointer alias | Fields |
| --- | --- |
| `PLAT_PROC_MEM_INFO`, `PPLAT_PROC_MEM_INFO` | `CHAR dramPath[40]`, `emmcPath1[40]`, `emmcPath2[40]`, `emmcPath3[40]`, using `PLAT_PROC_MEM_MAX_LEN`. |
| `LEDMGMT_PARAMS`, `PLEDMGMT_PARAMS` | Conditional `char *led_name`, `*led_param` under `FEATURE_RDKB_LED_MANAGER`; unconditional `LED_COLOR LedColor`; `INT State`, `Interval`. Both sides must agree on the build flag because layout changes. |
| `THERMAL_PLATFORM_CONFIG` (thermal guard) | `UINT FanCount`, `SlowSpeedThresh`, `MediumSpeedThresh`, `FastSpeedThresh`, `FanMinRunTime`, `MonitoringDelay`, `PowerMonitoring`, `LogInterval`. |
| `dhcp_opt_list` | `int dhcp_opt`; `char *dhcp_opt_val`; `struct dhcp_opt_list *next`. Returned lists have nested allocations/pointers. |
| `Traffic_client_t`, `pTraffic_client_t` | `char mac[18]`; `ULONG rxBytes`, `txBytes`. Comments describe 64-bit counters but `ULONG` width is ABI-dependent. |
| `DSCP_Element_t`, `pDSCP_Element_t` | `UINT dscp_value`, `numClients`; `Traffic_client_t Client[256]`. |
| `DSCP_list_t`, `pDSCP_list_t` | `UINT numElements`; `DSCP_Element_t DSCP_Element[64]`. |
| `FW_BANK_INFO`, `PFW_BANK_INFO` | `CHAR fw_name[FW_NAME_MAX_LEN]`, `fw_state[FW_STATE_MAX_LEN]`, each 64 bytes. |
| `INTF_STATS`, `PINTF_STATS` | `UINT64_t rx_packet`, `tx_packet`, `rx_bytes`, `tx_bytes`. |
| `hal_network_params_t` | `UINT8_t src_mac[6]`; `ip_version_t ip_version`; unions `src_ip` and `dest_ip`, each `UINT32_t ipv4` or `UINT8_t ipv6[16]`; `UINT16_t dest_port`, `src_port` in network byte order; `net_proto_t protocol`; `UINT8_t dscp_value` documented 0..63. IP integer byte order is not explicitly stated. |

No callback typedefs or public variables are declared.

### Complete macro/scalar inventory

Conditional aliases: `CHAR=char`, `UCHAR=unsigned char`, `BOOLEAN=unsigned char`, `INT=int`, `UINT=unsigned int`, `ULONG=unsigned long`, `UINT8_t=unsigned char`, `UINT16_t=unsigned short`, `UINT32_t=unsigned int`, `UINT64_t=unsigned long long`. Widths depend on the target C ABI rather than spelling alone.

Constants: `TRUE=1`, `FALSE=0`, `ENABLE=1`, `RETURN_OK=0`, `RETURN_ERR=-1`, `RETURN_UNSUPPORTED=-2`; `FW_NAME_MAX_LEN=64`, `FW_STATE_MAX_LEN=64`, `PLAT_PROC_MEM_MAX_LEN=40`, `LED_BUFFER_SIZE=3`.

DHCPv6 option constants, each equal to its numeric suffix: `DHCPV6_OPT_3`, `DHCPV6_OPT_5`, `DHCPV6_OPT_15`, `DHCPV6_OPT_16`, `DHCPV6_OPT_17`, `DHCPV6_OPT_20`, `DHCPV6_OPT_22`, `DHCPV6_OPT_23`, `DHCPV6_OPT_24`, `DHCPV6_OPT_25`, `DHCPV6_OPT_31`, `DHCPV6_OPT_64`, `DHCPV6_OPT_82`, `DHCPV6_OPT_83`, `DHCPV6_OPT_95`.

DHCPv4 option constants, each equal to its numeric suffix: `DHCPV4_OPT_2`, `DHCPV4_OPT_42`, `DHCPV4_OPT_43`, `DHCPV4_OPT_58`, `DHCPV4_OPT_59`, `DHCPV4_OPT_60`, `DHCPV4_OPT_61`, `DHCPV4_OPT_100`, `DHCPV4_OPT_122`, `DHCPV4_OPT_125`, `DHCPV4_OPT_242`, `DHCPV4_OPT_243`; `DHCPV4_OPT_END=255`.

## Lifecycle and representative sequence

There is no one global initialization/deinitialization pair. Database, LED and thermal initialization functions serve distinct responsibilities; do not invent a universal order among every API. Select the required build configuration and initialize the relevant subsystem according to its integration contract.

This example uses only base identity/memory calls, without implying that setting LEDs, MACsec or low-power state is mandatory.

~~~mermaid
sequenceDiagram
    participant C as Platform caller
    participant H as Vendor HAL
    C->>H: platform_hal_PandMDBInit()
    H-->>C: INT status
    C->>H: platform_hal_GetModelName(pValue)
    H-->>C: INT status; model on success
    C->>H: platform_hal_GetTotalMemorySize(pulSize)
    H-->>C: INT status; MB on success
    opt Authorized low-power state change
        C->>H: platform_hal_SetLowPowerModeState(pState)
        H-->>C: INT status
    end
~~~

The sequence is illustrative, not proof that the model and memory getters depend on `PandMDBInit`. No notification mechanism reports completion of all platform changes.

## Ownership, security, errors, and concurrency

Ordinary output structs/buffers remain caller-owned. LED pointer fields, QoS input and other input storage have no uniform retention guarantee. Returned memory-path arrays and DHCP option lists require vendor clarification for count, allocation, allocator-compatible release, nested strings, and validity after later calls. No public free API is declared.

Bound `numClients`/`numElements` to actual arrays before indexing; comments giving maxima 255/63 conflict with capacities 256/64 and need reconciliation. Do not consume outputs after failure or assume they were cleared.

Never log PPP passwords, credentials or sensitive DHCP contents. Credential access authorization, erasure and secret lifetime are integration responsibilities not defined by the getter signatures.

The header does not guarantee thread safety, cross-process isolation, snapshot atomicity, failure rollback, or bounded duration. Retained integration policy requires serialized calls, vendor multi-process protection, and cleanup of private resources. MACsec start/stop explicitly block; avoid critical event-loop invocation.

No callback is declared, but vendors may use internal threads. Platform settings and low-power/LED/fan/MACsec/QoS actions have stateful effects; persistence, reset scope and power-loss behavior are not universally defined.

## Integration and delivery policy

Retain Linux/Yocto support, Apache License 2.0 implementation, shared library `libhal_platform.so`, and controlled semantic versioning. Build flags affecting public types must match across caller and library. Numeric CPU, memory and response-time budgets remain unresolved.

Existing logging guidance uses syslog and `/var/tmp/` or `/rdklogs/logs/`, but its filename `xxx_vendor_hal.log` is a placeholder, not a verified platform sink. Choose the actual sink through integration policy. Include timestamps/severity, redact secrets, and map FATAL/TRACE project labels to supported priorities. Static analysis, dependency/license review and leak analysis remain recommended; no compiler, tests, or device operations were performed here.

## Header-reverified gap register

| ID | Evidence and unresolved contract |
| --- | --- |
| PLAT-GAP-01 | Resolve allocation/count/release/lifetime of `GetMemoryPaths` and nested DHCP option lists. |
| PLAT-GAP-02 | LED build flag changes ABI layout; document deployed flag combinations and runtime unsupported behavior. |
| PLAT-GAP-03 | MACsec timeout comment conflicts with “unused”; define zero/finite timeout, cancellation and actual blocking limits. |
| PLAT-GAP-04 | DSCP CSV range conflicts with six-bit QoS DSCP; resolve counts versus capacities and `ULONG` counter widths. |
| PLAT-GAP-05 | Lengthless getters need maximum/termination/failure-output rules; resolve used-memory buffer range. |
| PLAT-GAP-06 | Define low-power pointer direction, valid transitions, subsystem initialization dependencies and durable effects. |
| PLAT-GAP-07 | Define per-API unsupported/error values, direct-fan unavailable indications and fan speed units. |
| PLAT-GAP-08 | Time-offset examples have inconsistent EST/MST offsets; specify authoritative format and timezone semantics. |
| PLAT-GAP-09 | Define concurrency, process locking, atomicity, resource cleanup and numeric budgets. |
| PLAT-GAP-10 | Replace placeholder logging sink through integration agreement, not an invented filename. |
| PLAT-GAP-11 | Specify QoS IP byte order, flow matching/replacement, validation and application lifetime. |
