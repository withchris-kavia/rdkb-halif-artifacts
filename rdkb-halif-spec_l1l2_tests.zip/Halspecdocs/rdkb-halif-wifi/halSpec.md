# RDKB Wifi HAL Documentation

## Version History

| Revision | Comment | Document version |
| --- | --- | --- |
| 08/16/22 | Initial release. | 0.1.0 |
| Current header snapshot | Consolidated public-header inventory, architecture, lifecycle, telemetry and contract-gap reference. The main header version macros are 3.0.7; the separate emulator header identifies itself as 2.2.1. | 0.2.0 |

## Scope and Source of Truth

This is the canonical specification for the public C interfaces found recursively under `rdkb-halif-wifi/`. The root `README.md` is a symlink to this page, not a second specification. This revision describes declarations and their comments, not a verified vendor implementation. No vendor driver, chipset SDK, radio implementation or executable HAL implementation is supplied by these headers. A declared feature is not evidence that every platform supports it.

The recursive header inventory contains ten files, all currently under `include/`. The following links are relative to this canonical page. The module tables below refer back to these source files; exact field order, packing attributes, array extents and preprocessor branches remain authoritative in the headers.

| Source | Role and scope |
| --- | --- |
| [wifi_hal.h](../../include/wifi_hal.h) | Main umbrella. Includes generic, radio, AP, STA, telemetry, client-management, extender and deprecated headers, in that order. Declares no functions itself. |
| [wifi_hal_generic.h](../../include/wifi_hal_generic.h) | Shared primitives, capabilities, bands, indices, TWT, CSI and subsystem APIs. |
| [wifi_hal_radio.h](../../include/wifi_hal_radio.h) | Radio parameters, channel state, scanning, temperature and radio APIs. Also includes `wifi_hal_ap.h`. |
| [wifi_hal_ap.h](../../include/wifi_hal_ap.h) | AP/VAP configuration, security, ANQP, Passpoint, frame handling, WPS and notifications. |
| [wifi_hal_sta.h](../../include/wifi_hal_sta.h) | Client-VAP connection, discovery, capabilities, statistics and connection-status callback. |
| [wifi_hal_telemetry.h](../../include/wifi_hal_telemetry.h) | Radio/SSID/client statistics, neighboring APs and unassociated-station metrics. Includes the generic header. |
| [wifi_hal_client_mgt.h](../../include/wifi_hal_client_mgt.h) | Band steering, high-watermarks, EAP, fast transition, BSS transition and neighbor-report activation. |
| [wifi_hal_extender.h](../../include/wifi_hal_extender.h) | Channel and client metrics, steering, BTM and 802.11k radio measurement. |
| [wifi_hal_deprecated.h](../../include/wifi_hal_deprecated.h) | Legacy declarations still included by the main umbrella, including DPP, ANQP and channel-event interfaces. “Deprecated” does not mean absent from the public include surface. |
| [wifi_hal_emu.h](../../include/wifi_hal_emu.h) | Separate legacy emulator interface, shared declarations and emulator/hostapd helpers. It is not included by the main umbrella and is not an additive extension to it. |

The main umbrella explicitly warns that some deprecated APIs are still used and need correction or removal. Comment-only prototypes are excluded from the inventory. Conditional declarations are included and identified rather than treated as simultaneously available.

## Acronyms

HAL means Hardware Abstraction Layer; RDK-B means Reference Design Kit for Broadband Devices. OEM means Original Equipment Manufacturer, and SoC means System on a Chip. AP means Access Point, STA means Station, BSS means Basic Service Set, SSID means Service Set Identifier, and VAP means Virtual Access Point. CSI means Channel State Information, TWT means Target Wake Time, BTM means BSS Transition Management, and RRM means Radio Resource Management. HATS refers to HAL Automated Testing System. An implementation wrapper supplied by an OEM or SoC vendor is distinct from the public `wifi_hal.h` interface.

## Architecture and Description

The HAL abstracts RDK Wi-Fi requirements so that upper layers can configure radios and VAPs and retrieve measurements without directly depending on a particular vendor driver. The following is the intended integration hierarchy, not an implementation call graph proven by this interface-only repository.

```mermaid
flowchart TD
    Upper["Upper OneWifi / CCSP Stack"]
    HAL["Wi-Fi HAL Interface: wifi_hal.h"]
    Vendor["Vendor Driver / Chipset SDK"]
    Hardware["Radio Hardware"]
    Band24["2.4 GHz"]
    Band5["5 GHz"]
    Band6["6 GHz"]
    Upper --> HAL
    HAL --> Vendor
    Vendor --> Hardware
    Hardware --> Band24
    Hardware --> Band5
    Hardware --> Band6
```

The main declarations include 2.4, 5, split 5-low/5-high, 6 and 60 GHz band identifiers, plus 802.11ax/be/bn and 320 MHz identifiers. These are vocabulary and capability fields, not a promise of hardware availability, regulatory approval or interoperability. Discover the actual supported bands, channels, widths, ciphers, VAP count and radio presence through `wifi_getHalCapability`, then use its platform mappings.

The original platform illustration remains available as a complementary view.

![WiFi HAL DIAGRAM](images/WifiHALDiagram.PNG)

## Optional Components

The original integration guidance allows vendor-dependent use of `hostapd` and `nl80211/cfg80211`. `hostapd` provides AP/authentication services; `nl80211` is a user/kernel wireless interface associated with `cfg80211` and wireless drivers. Their use, process arrangement and SDK interactions are not universally prescribed by the public headers. The presence of `wifi_createHostApdConfig`, `wifi_startHostApd`, `wifi_stopHostApd`, `wifi_getLibhostapd` and emulator helpers must not be read as evidence that all vendors use the same daemon architecture.

## Component Runtime Execution Requirements

### Initialization, Configuration and Shutdown

The retained integration expectation is one HAL instance for the system, loaded as a library for the lifetime of its owning process. Initialize it using the actual declared `INT wifi_init();` before configuration or measurement calls. Dependency startup, repeat-initialization behavior, partial-failure recovery and ABI loading are not specified in these declarations.

The attachment's lifecycle names `wifi_hal_init` and `wifi_hal_deinit` are conceptual labels only: neither symbol, nor `wifi_deinit`, is declared in any inspected public header. The diagram deliberately distinguishes those labels from real API calls. `wifi_down()` turns off transmit power; `wifi_reset()` resets subsystem/AP variables; neither is documented as a deallocator or an inverse of initialization.

```mermaid
sequenceDiagram
    participant Upper as OneWifi / CCSP
    participant HAL as Wi-Fi HAL
    participant Vendor as Vendor Driver / SDK
    Note over Upper,HAL: Conceptual wifi_hal_init stage maps to the declared wifi_init entry
    Upper->>HAL: wifi_init()
    HAL-->>Upper: Initialization status
    Upper->>HAL: wifi_getHalCapability(cap)
    HAL-->>Upper: Supported radios and mappings
    Upper->>HAL: wifi_setRadioOperatingParameters(index, parameters)
    Upper->>HAL: wifi_createVAP(index, map)
    Note over Upper,HAL: Radio and SSID/VAP configuration
    Upper->>HAL: Register supported event callbacks
    loop Polling and asynchronous operation
        Upper->>HAL: wifi_getRadioTrafficStats2(radioIndex, stats)
        HAL-->>Upper: Radio measurements and status
        Upper->>HAL: wifi_getApAssociatedDeviceDiagnosticResult3(apIndex, devices, count)
        HAL-->>Upper: Client measurements and status
        opt Driver reports an event
            Vendor-->>HAL: Association, scan or steering event
            HAL-->>Upper: Registered callback
        end
    end
    Note over Upper,Vendor: wifi_hal_deinit is conceptual and not declared
    Note over Upper,HAL: Quiesce consumers and release caller-owned results
    Note over HAL,Vendor: Vendor-specific teardown contract is required
```

The sequence is an integration outline, not a mandated transactional sequence or evidence of internal driver calls. Radio parameters and VAP maps carry channel, SSID, security and enable settings. Legacy setters may require `wifi_applyRadioSettings` or `wifi_applySSIDSettings`; their behavior must be taken from the selected API rather than assuming every setter commits immediately. There is no declared rollback or cross-radio atomic-commit protocol.

### Threading, Process and Blocking Model

Thread safety remains an integration requirement, not a verified property of these headers. They provide no general lock ordering, reentrancy, callback-thread affinity, concurrent setter semantics or shutdown barrier. Vendors may create internal threads, but callers must establish a vendor concurrency contract before issuing overlapping configuration operations or calling back into the HAL from a notification.

Many radio, AP, legacy and telemetry comments explicitly forbid suspension or blocking system calls. The extender receive/transmit/TID/aggregate-statistics comments say they “should be non-blocking.” Other declarations provide no latency limit. A synchronous return annotation does not itself mean blocking, nor does it guarantee completion of a hardware transition. The former blanket statement that every call is nonblocking is therefore an integration goal, not a universal header guarantee.

### Memory and Asynchronous Notification Model

Caller-provided scalar/struct/string storage remains caller-managed unless an individual contract states otherwise. A pointer parameter alone does not establish transfer, retention, capacity or release rules. In particular, `T **` does not automatically mean either “HAL allocates” or “caller frees.” The inventory explicitly marks returned-array and nested-allocation ambiguities.

The station header's `wifi_findNetworks`, and the extender header's `wifi_getApAssociatedDeviceRxStatsResult` and `wifi_getApAssociatedDeviceTxStatsResult`, expressly say that the HAL allocates the result and the caller frees it. They do not name a HAL-specific deallocator. The legacy neighboring-AP and associated-device diagnostic comments require HAL allocation but do not specify a matching release API. Obtain allocator compatibility and failure-path cleanup rules from the vendor instead of assuming all arrays use the same allocator.

There is a special CSI inconsistency in `wifi_hal_generic.h`, inside `wifi_associated_dev3_t`. Its comment describes caller allocation of the outer associated-device array for selected clients and HAL allocation/caller deallocation of nested CSI data. The declaration is `wifi_csi_data_t *cli_CsiData;`, while the prose spells it `cli_CSIData`. In contrast, `wifi_hal_telemetry.h::wifi_getApAssociatedDeviceDiagnosticResult3` documents the outer array and count as outputs without defining this selected-client mode. This is an unresolved dual-mode ownership/direction contract, not permission to guess.

Callbacks notify association, disassociation, deauthentication, station connection, scan results, management frames, CSI, steering, BTM, beacon reports, channel events and other status changes. Keep callback function code and application state alive while registered. Treat payload pointers as borrowed during the callback and copy needed data before returning unless a particular vendor contract explicitly grants ownership. This is a conservative integration policy: the headers do not provide a universal payload-lifetime guarantee. Registration replacement, null-callback unregister behavior, maximum subscribers and in-flight callback draining are generally unspecified. The explicit steering and beacon-request unregister APIs do not establish such guarantees for other callback families.

WPS registration is an explicit exception to the unspecified subscription rules: `wifi_wpsEvent_callback_register` permits only one callback at a time, and a new registration replaces the previous callback. Its comment does not define null-callback unregistration or draining of an invocation already in flight. Do not extend this replacement rule to other callback families.

### Persistence, Power and Errors

Upper layers are expected to maintain configuration. This is not equivalent to a no-persistence guarantee: initial-configuration and hostapd APIs explicitly describe implementation-dependent configuration files. File format, durability, transaction boundaries and recovery after restart are vendor-dependent.

There is no universal component power-management lifecycle in the headers. However, radio transmit-power controls, `wifi_down`, TWT configuration and `EcoPowerDown` fields exist, so “no power-management requirement” must not be interpreted as “no power-related API.”

Implementations should handle allocation failures, boundary checks and system errors without exposing undocumented result values. The inventory records actual documented return codes; several legacy APIs have none, and some `void` registration comments incorrectly claim status returns. A global error macro does not establish that every function can return it.

## Indices, Capacities and ABI Variability

`wifi_radio_index_t` and `wifi_vap_index_t` are aliases of `UINT`, not validation-enforcing types. The generic header defines `RADIO_INDEX_1=1`, `RADIO_INDEX_2=2`, `RADIO_INDEX_3=3` and `AP_INDEX_1` through `AP_INDEX_24` as 1 through 24, under the same `#ifndef RADIO_INDEX_1` guard. The emulator defines only two radio macros and AP macros 1 through 16.

These macros do not settle runtime array indexing. Legacy `wifi_getRadioChannels` documents first radio index 0 and second radio index 1, extender comments refer to radio/AP array indices, and platform structures expose `index`, `rdk_radio_index`, `phy_index`, `radio_index`, interface maps and radio presence. Use discovered mappings; do not assume index 1 always means 2.4 GHz or index 3 always means 6 GHz.

| Constant or representation | Declared bound or meaning |
| --- | --- |
| `MAX_NUM_RADIOS` | 3 with `WIFI_HAL_VERSION_3`; otherwise 2. |
| `MAX_NUM_VAP_PER_RADIO`; `MAX_VAP` | 8; radio count multiplied by 8. |
| `MAX_NUM_FREQ_BAND`; `MAX_CHANNELS` | 4 capability-band slots; 64 channels per channel list. The band enum contains more identifiers than this array capacity. |
| `MAXNUMSECONDARYCHANNELS`; `MAX_NUM_CHANNELBANDWIDTH_SUPPORTED` | 7 secondary channels; 6 per-bandwidth entries. |
| `MAX_CHANNELS_PER_OP_CLASS`; `MAX_OP_CLASS_ENTRIES` | Default 70 channels and 60 operating-class entries. |
| `MAXNUMNONOPERABLECHANNELS`; `MAXNUMOPERCLASSESPERBAND` | 10 nonoperable channels; 20 operating-class entries in radio operation parameters. |
| `MAX_NUM_MLD_LINKS`; `MIN_MLO_GROUP_SIZE`; `MLD_UNIT_COUNT` | Default 15 links; 2; 8. Undefined MLD and link IDs are 255. These are not discovered hardware counts. |
| `MAX_NUM_TWT_SESSION`; `MAX_STA_PER_SESSION` | 50 sessions; 100 stations per session. |
| `MAX_BSR`; `MAX_RU_ALLOCATIONS` | 32 buffer-status reports; 74 RU allocations. |
| `MAX_NR`; `MAX_NC`; `MAX_SUB_CARRIERS`; `MAX_PILOTS` | 4; 1; 256; 26 for CSI/EVM arrays. |
| `MAX_KEY_HOLDERS`; `MAX_BTM_DEVICES`; `MAX_CANDIDATES` | 8 key holders; 64 BTM devices; 64 candidates. |
| `MAX_URL_LEN`; `MAX_VENDOR_SPECIFIC`; `MAX_REQUESTED_ELEMS`; `MAX_CHANNELS_REPORT` | 512; 32; 8; 64. |
| `wifi_radioQueueType_t` | Legacy queue enumeration, not radio indices. |
| `ssid_t`; `WIFI_AP_MAX_SSID_LEN` | `char[32]`; 33. Do not assume all SSID representations have a spare terminator byte. |
| `mac_address_t`; `bssid_t`; `mac_addr_str_t` | Six binary octets; alias of binary MAC; 18-character textual buffer. Legacy `char *` MACs are not interchangeable with all binary-MAC variants. |

`WIFI_HAL_VERSION_3_PHASE2` changes MAC representations, callback types and several function signatures. It is distinct from `WIFI_HAL_VERSION_3`, which changes radio-array capacity and the MFP representation. All cooperating binaries must agree on these flags, primitive widths, alignment and packing. Many structs are packed, contain native `long`, pointers or enums, and are not portable serialized messages.

The emulator and main umbrella both use `__WIFI_HAL_H__`. Including the main umbrella before the emulator reaches the emulator's `#error` branch; including the emulator first can suppress the main umbrella. Treat them as alternative header surfaces. Do not include both to obtain a union of their declarations.

## Telemetry and Operational Capabilities

The following are declared metrics, not a claim that all chipsets populate every field. Counter scope, sampling availability, calibration and refresh cadence require vendor confirmation unless specifically described.

| Capability | Declared access and fields | Contract details and limitations |
| --- | --- | --- |
| Client RSSI and signal quality | `wifi_getApAssociatedDeviceDiagnosticResult3`, `wifi_getApAssociatedClientDiagnosticResult`, `wifi_associated_dev3_t::{cli_SignalStrength,cli_RSSI,cli_MinRSSI,cli_MaxRSSI,cli_SNR}`; steering RSSI events; legacy `wifi_getApDeviceRSSI`. | Multiple representations exist. Extender rate RSSI is unsigned, snapshots use byte arrays, and neighboring-AP signal strength is documented in dBm. Do not apply a single signed conversion to all fields. |
| Transmit/receive rates | `cli_LastDataDownlinkRate`, `cli_LastDataUplinkRate`, `cli_MaxDownlinkRate`, `cli_MaxUplinkRate`; `wifi_associated_dev_stats_t::{cli_rx_rate,cli_tx_rate}`; per-rate NSS/MCS/BW arrays; legacy Rxrate/Txrate calls. | Legacy parameter names use RxMb/TxMb; the interfaces do not establish one common unit or averaging window for every rate field. Use each header's field contract and vendor clarification. |
| Radio counters | `wifi_getRadioTrafficStats2`; `radio_BytesSent/Received`, packets, errors, discards, PLCP/FCS errors, invalid MAC and other-destination packets. | Bytes explicitly include framing characters. `radio_StatisticsStartTime` must change when statistics reset. General counter wrap behavior is not defined; `ULONG` width is platform-dependent. |
| SSID/AP counters | `wifi_getSSIDTrafficStats2`, `wifi_getWifiTrafficStats`, `wifi_getVAPTelemetry`; retransmission, retry, ACK failure, aggregation, unicast/multicast/broadcast/discard/unknown counters and `txOverflow`. | RetransCount counts each retry attempt; RetryCount counts successfully transmitted packets requiring retries. Some field descriptions have copy errors, recorded below. |
| Client aggregate/TID metrics | Rx/Tx rate-statistics APIs, `wifi_getApAssociatedDeviceStats`, `wifi_getApAssociatedDeviceTidStatsResult`. | Includes bytes, MSDUs/MPDUs/PPDUs, retries, attempts, frames, errors and per-TID timing. The association handle is incremented on reconnection; two handle pointer annotations are inconsistent with other result APIs. |
| Channel utilization | `wifi_getRadioBandUtilization`, `radio_ChannelUtilization`, activity factor, carrier-sense threshold exceeded, retransmission metric and `wifi_getRadioChannelStats`. | Band utilization and `ch_utilization` are percentages. Radio interval metrics use only the just-completed measuring interval. Channel busy/total counters have no declared universal time unit. |
| Noise and neighboring APs | Radio noise floor/minimum/maximum/median; neighboring AP RSSI, noise, channel, band, standard, frequency and BSS-load fields. | Radio noise-floor comment specifies -110 to 0 dBm. Neighbor signal strength averages the last 100 received packets. Neighbor `ap_ChannelUtilization` and `ap_StaCount` are valid only when `bss_load_element_present` is true. |
| Unassociated station | `wifi_getNASta`, `wifi_na_sta_req_params_t`, `wifi_na_sta_info_t::rcpi`. | Supply MAC, channel and operating class in valid input storage and writable output storage. STA must not be associated to the queried AP. RCPI is `(RSSI_dBm + 110) * 2`, clamped to 0 through 220. Invalid, unsupported and internal-error cases are all documented as `WIFI_HAL_ERROR`. |
| Station status | `wifi_getStationStats`, `wifi_staConnectionStatus_callback`. | Reports connection status, channel, channel width and operating class, not a general traffic-statistics structure. Station capability type is currently empty. |
| CSI, MU, TWT and MLO | CSI engine/callback, nested client CSI, MU buffer/RU arrays, TWT sessions, MLD fields and capability maps. | Declaration of fields does not guarantee sounding support, active CSI, TWT scheduling, MLO combinations or RF performance. |
| DFS and temperature | DFS/zero-DFS setters/status, channel-event callback, radar/channel-state enums, `wifi_hal_getRadioTemperature`. | Regulatory operation, radar/CAC behavior, sensor availability and actual hardware timing remain implementation-dependent. |

The telemetry header requires interval-derived radio metrics to return -1 before the first calculation. However, `radio_ChannelUtilization` is `ULONG`, so the representation of that sentinel is ambiguous. It is not a negative function return code. The same header defines the reporting interval semantics, but does not provide a complete atomic-snapshot, stale-data or counter-reset protocol. `wifi_setRadioStatsEnable`, `wifi_setClientDetailedStatisticsEnable` and radio measuring-rate/interval fields expose collection controls; enabling them does not establish a universal polling cadence.

## Public Data Type Reference

Every named public struct and enum is registered below, including legacy and emulator definitions. Related entries share a row to keep this reference readable; the linked header supplies the complete member layout and enum values. Anonymous unions are members of their enclosing named struct, not additional named public types. Callback typedef signatures are listed separately.

### Generic Types

Source: [wifi_hal_generic.h](../../include/wifi_hal_generic.h).

| Type or related types | Declared content |
| --- | --- |
| `mac_address_t`, `mac_addr_str_t`, `bssid_t`, `ssid_t` | Binary/text MAC, BSSID and SSID arrays described above. |
| `wifi_radio_index_t`, `u_int32_t`, `wifi_interface_name_t`, `wifi_vap_name_t` | Unsigned index/integer and fixed interface/VAP name arrays. |
| `nas_id_t`, `r0r1_key_t`, `r0r1_key_str_t` | 49-character NAS identifier, 16-byte key and 33-character key string. |
| `wifi_security_modes_t` | Bit-valued none, WEP64/128, WPA/WPA2 personal/enterprise/mixed, WPA3 personal/transition/enterprise/compatibility and enhanced-open modes. Values run from `0x1` through `0x2000`. |
| `wifi_encryption_method_t` | None, TKIP, AES, AES/TKIP, AES/GCMP256, GCMP256 and AES/GCMP. |
| `wifi_freq_bands_t` | 2.4=`0x1`, 5=`0x2`, 5L=`0x4`, 5H=`0x8`, 6=`0x10`, 60 GHz=`0x20`. |
| `wifi_ieee80211Variant_t` | Bitmask A/B/G/N/H/AC/AD/AX/BE/BN, from `0x01` through `0x200`. |
| `wifi_channelBandwidth_t` | 20/40/80/160/80+80/320 MHz, respectively `0x1/0x2/0x4/0x8/0x10/0x20`. |
| `wifi_bitrate_t` | Bit-valued default and legacy rates 1 through 54 Mbps, including 5.5 Mbps. |
| `wifi_bss_info_t` | Packed BSSID/SSID, RSSI, capabilities, beacon interval, frequency, IE bytes/length, security/encryption, bands/standards/widths/rates, DTIM, utilization, noise/SNR and BSS load. |
| `wifi_ip_family_t`, `ip_addr_t` | IPv4/IPv6 discriminator and packed address union. |
| `eWifiEnable`, `wifi_hal_version_t` | Disable/enable values 0/1; packed major/minor version fields. |
| `wifi_channel_t`, `wifi_channels_list_t`, `wifi_channels_list_per_bandwidth_t` | Channel and band; counted channel array; bandwidth-specific counted channel lists. |
| `wifi_radio_trasmitPowerSupported_list_t` | Counted supported-transmit-power array. The spelling `trasmit` is the declared identifier. |
| `wifi_countrycode_type_t`, `wifi_operating_env_t` | Enumerated country-code identifiers from `wifi_countrycode_AC` through added codes and `wifi_countrycode_00`, ending in `wifi_countrycode_max`; all/indoor/outdoor/non-country environment. Country values are enum ordinals, not two-character strings. |
| `wifi_radio_csi_capabilities_t` | Maximum devices and `soudingFrameSupported` flag, with the declared spelling retained. |
| `wifi_multi_link_bands_t`, `wifi_multi_link_modes_t` | Supported band combinations; STR=`0x1`, NSTR=`0x2`, eMLSR=`0x4`, eMLMR=`0x8`. |
| `wifi_channel_scan_impact_t`, `op_class_ch_list_t` | Scan impact none/reduced-streams/time-slicing/radio-unavailable; operating-class channel list. |
| `wifi_radio_capabilities_t` | Indices, interface, bands, channels, widths, standards/rates/power, DCS/DFS/CSI/cipher/country/VAP support, HT/VHT/HE/EHT/MLO and scan limits. |
| `wifi_interface_name_idex_map_t`, `radio_interface_mapping_t` | PHY/RDK/VAP indices, interface/MLD/bridge/VAP names and VLAN mapping; radio-name mapping. The spelling `idex` is intentional here because it is in the declaration. |
| `wifi_multi_link_info_t`, `wifi_platform_property_t`, `wifi_hal_capability_t` | MLO bands/modes; radios, presence, mappings and device identity; version/platform properties and band-steering support. |
| `wifi_twt_agreement_type_t`, `wifi_twt_operation_t` | Individual/broadcast agreement; implicit/announced/trigger/flow-ID controls. |
| `wifi_twt_individual_params_t`, `wifi_twt_broadcast_params_t`, `wifi_twt_params_t` | Microsecond wake/interval/duration fields, channel where applicable, operation, agreement-tagged union and paused state. |
| `wifi_80211ax_params_t`, `wifi_twt_dev_info_t`, `wifi_twt_sessions_t` | TWT default parameters, device session list and session ID/device-MAC list. |
| `wifi_ru_type_t`, `wifi_access_category_t`, `wifi_bsr_t`, `wifi_ru_allocation_t` | RU sizes 26 through 2x996; background/best-effort/video/voice; buffer status and RU allocation. |
| `wifi_dl_mu_type_t`, `wifi_ul_mu_type_t`, `wifi_dl_mu_stats_t`, `wifi_ul_mu_stats_t` | Downlink none/OFDMA/MIMO/combined and uplink none/OFDMA, plus buffer/RU/CSI statistics. |
| `wifi_chan_eventType_t`, `wifi_connection_status_t` | Channels-changed/DFS-radar; disabled/disconnected/connected/AP-not-found. |
| `radius_eap_failure_code_t`, `radius_fallback_failover_code_t` | Access reject/EAP failure; initialization/failover/fallback. |
| `wifi_streams_rssi_t`, `wifi_carrier_data_t`, `wifi_csi_matrix_t`, `wifi_evm_data_t`, `wifi_evm_matrix_t` | Fixed-dimensional CSI/EVM array aliases. |
| `wifi_frame_info_t`, `wifi_csi_data_t` | Bandwidth/MCS/Nr/Nc/RSSI/validity/channel/timestamp metadata and CSI/EVM matrices. |
| `wifi_associated_dev3_t` | Client identity/authentication, rates, RSSI/SNR, counters, MU/TWT, nested CSI pointer, spatial streams, MLD state/address, power-save and sleep information. |

### Radio, Station and Telemetry Types

Sources: [radio](../../include/wifi_hal_radio.h), [station](../../include/wifi_hal_sta.h) and [telemetry](../../include/wifi_hal_telemetry.h).

| Type or related types | Declared content |
| --- | --- |
| `wifi_guard_interval_t` | 400/800/1600/3200 and auto, bit-valued `0x01` through `0x10`. |
| `wifi_radar_eventType_t` | Radar detected; CAC finished/aborted/started; NOP finished; pre-CAC expired. |
| `wifi_channelState_t`, `wifi_channelMap_t` | Available and DFS NOP/CAC states; channel-to-state pair. |
| `wifi_radio_11be_puncturing_info_t`, `wifi_operating_classes_t` | Puncture bitmap/ACS threshold; operating class, maximum power and nonoperable channels. |
| `wifi_radioTemperature_t` | Unsigned `radio_Temperature`; the struct alone does not establish a unit or invalid-value convention. |
| `wifi_radio_operationParam_t` | Enable/band/channel/secondary channels/width/standard/CSA/country/environment; channel map; DCS/DFS; beacon/DTIM/rates/power; thresholds/guard/CTS/OBSS/STBC; statistics; eco state; puncturing; AMSDU; operating-class and per-bandwidth arrays. |
| `wifi_edca_t`, `wifi_dl_data_ack_type_t` | AIFSN, minimum/maximum contention windows and timer; immediate ACK/immediate block ACK/deferred block ACK. |
| `wifi_sta_capability_t` | Empty struct; no station capability fields are defined. |
| `wifi_station_stats_t` | VAP index, connection state, channel, channel width and operating class. |
| `wifi_radioTrafficStats2_t` | Radio byte/packet/error/discard counters, noise, utilization/interval metrics and statistics start time. |
| `wifi_ssidTrafficStats2_t` | SSID byte/packet/retransmission/retry/ACK/aggregation/error and traffic-class counters. |
| `wifi_neighbor_ap2_t` | Neighbor identity, security, channel/band/standards/rates, RSSI/noise/beacon/DTIM and conditional BSS-load measurements. |
| `wifi_rssi_snapshot_t` | Four RSSI bytes, four relative-age bytes and a `USHORT` sample counter; comments also discuss host-endian integer interpretation. |
| `wifi_apRssi_t` | Six-byte BSSID, width and RSSI. Width is `wifi_channelBandwidth_t` in phase 2, otherwise `UINT`. |
| `wifi_VAPTelemetry_t` | `UINT txOverflow`. |
| `wifi_na_sta_req_params_t`, `wifi_na_sta_info_t` | STA MAC/channel/operating-class request and matching output with RCPI. |

### AP, Security and Interworking Types

Source: [wifi_hal_ap.h](../../include/wifi_hal_ap.h).

| Type or related types | Declared content |
| --- | --- |
| `wifi_trafficStats_t` | AP error, discard, unicast/multicast/broadcast and unknown-packet counters. |
| `wifi_ipv4_field_values_t`, `wifi_ipv6_field_values_t`, `wifi_ipAddressAvailabality_t` | Address-availability enumerations and packed format byte. The `Availabality` spelling is declared. |
| `wifi_auth_id_t`, `wifi_authMethod_t`, `wifi_eapMethod_t` | Authentication parameter kinds and counted method/parameter tuples. |
| `wifi_naiRealm_t`, `wifi_naiRealmElement_t` | Realm lengths/encoding/EAP methods and counted realm tuples. |
| `wifi_venueName_t`, `wifi_venueNameElement_t` | Language/name tuples and venue group/type. |
| `wifi_plmn_t`, `wifi_3gpp_plmn_list_information_element_t`, `wifi_3gppCellularNetwork_t` | PLMN bytes, counted list and 3GPP network container. |
| `wifi_domainNameTuple_t`, `wifi_domainName_t` | Length-prefixed domain tuple and tuple array. |
| `wifi_ouiDuple_t`, `wifi_roamingConsortium_t`, `wifi_roamingConsortiumElement_t` | OUI tuple/list and advertised consortium OUIs/lengths. |
| `wifi_capabilityListANQP_t`, `wifi_HS2_CapabilityList_t` | ANQP and Hotspot 2.0 capability arrays. |
| `wifi_HS2_OperatorNameDuple_t`, `wifi_HS2_OperatorFriendlyName_t` | Language/operator-name tuple and tuple array. |
| `wifi_HS2_WANMetrics_t`, `wifi_HS2_Wan_Info_Link_Status_t` | WAN info, link speeds/loads and measurement duration; reserved/up/down/test link state. |
| `wifi_HS2_Proto_Port_Tuple_t`, `wifi_HS2_ConnectionCapability_t`, `wifi_HS2_ConnectionCapability_Status_t` | IP protocol/port/status tuple/list; closed/open/unknown/reserved. |
| `wifi_HS2_NAI_Home_Realm_Data_t`, `wifi_HS2_NAI_Home_Realm_Query_t` | Encoded realm and counted home-realm query. |
| `wifi_eapol_key_frame_t`, `wifi_eap_frame_t`, `wifi_8021x_frame_t` | Wire-frame fields, including zero-length trailing data arrays. These are compiler-specific C layouts, not bounds-checking containers. |
| `wifi_eap_code_t`, `wifi_eapol_type_t` | Request/response/success/failure; EAP packet/start/logoff/key. |
| `eapol_msg_type_t`, `eapol_frame_type_t`, `eapol_status_type_idx_t` | None/M1-M4; unknown/association/reassociation; M1-M3 association/reassociation status slots. |
| `wifi_direction_t`, `wifi_neighborScanMode_t` | Unknown/uplink/downlink; none/full/on-channel/off-channel/survey/selected-channel scan. |
| `wifi_radius_setting_t` | Retry/timeouts, PMK lifetime/cache, authentication attempts, blacklist and identity retry/quiet periods. |
| `wifi_eap_t`, `phase2_type` | Declared EAP method numbers including TLS/TTLS/PEAP/TEAP/expanded; EAP/MSCHAPv2/MSCHAP/PAP/CHAP/GTC inner method. |
| `wifi_eap_status_code_t`, `wifi_reason_code_t`, `wifi_status_code_t` | Authentication status and selected IEEE reason/status codes; not HAL function return codes. |
| `wifi_mld_sta_link_info_t`, `wifi_mld_sta_info_t` | Valid/association link, link ID/VAP/RSSI/MAC; MLD support, mode, TID mapping and link array. |
| `wifi_associated_dev_t` | Legacy diagnostic fields plus capable streams and MLD info in the main non-phase-2 definition. The emulator's same-named struct lacks these additions. |
| `wifi_InterworkingElement_t` | Interworking enable/access type, Internet/ASRA/ESR/UESA flags, venue and HESSID. |
| `wifi_mgmtFrameType_t`, `wifi_dataFrameType_t`, `wifi_frameType_t` | Management types including probe/association/auth/deauth/reassociation/disassociation/action/beacon; 802.1X data; management/control/data classification. |
| `wifi_frame_t` | Packed AP/MAC/type/direction, signal/rate/token/frequency and length/data pointer. |
| `wifi_data_priority_t` | Best-effort/background/excellent-effort/critical/video/voice/internetwork/network control priorities, retaining `wifi_data_prioirty_ic` spelling. |
| `wifi_GASConfiguration_t`, `wifi_config_t` | Advertisement ID, pause/timeout/comeback/buffering/length controls and containing config. |
| `wifi_key_multi_psk_t`, `wifi_vap_index_t` | Key-ID and PSK arrays; unsigned VAP index. |
| `wifi_onboarding_methods_t`, `wifi_wps_t` | Bit-valued USB/Ethernet/label/display/NFC/button/PIN/EasyConnect methods; WPS enable/methods/PIN. |
| `wifi_mfp_cfg_t`, `wifi_mac_filter_mode_t` | MFP disabled/optional/required; blacklist/whitelist. This two-value filter enum is not the legacy 0/1/2 ACL-mode enum. |
| `wifi_radius_settings_t` | Primary/secondary/connected/DAS endpoints, secrets, identity, retry/blacklist/EAP settings. Primary/secondary/connected endpoint fields change representation with phase 2. |
| `wifi_security_key_type_t`, `wifi_security_key_t` | PSK/passphrase/SAE and combined/SAE-extension key kinds; type and key storage. |
| `wifi_vap_security_t` | Mode/repurposed mode/cipher/MFP, rekey and EAP controls, cache/key ID, repurposed RADIUS and RADIUS-or-key union. MFP changes with `WIFI_HAL_VERSION_3`. |
| `wifi_anqp_settings_t`, `wifi_passpoint_settings_t`, `wifi_interworking_t` | ANQP fields/response statistics/raw parameters; Passpoint policies/capabilities/operator/realm/WAN data; combined interworking settings. |
| `wifi_preassoc_control_t`, `wifi_postassoc_control_t` | String-form thresholds/rates/deny or force-disassociate information, sampling controls and VAP name. |
| `network_param_config_t`, `amenities_network_config_t` | Speed-tier network parameter and containing amenities config. |
| `wifi_vap_mode_t`, `wifi_scan_params_t` | AP/STA/monitor modes; period/channel scan configuration. |
| `wifi_mld_common_info_t`, `wifi_mld_info_sta_t`, `wifi_mld_info_ap_t` | MLD enable/IDs/address; STA local/peer addresses and common data; AP common data. |
| `wifi_back_haul_sta_t` | SSID/repurposed SSID/BSSID, enable/connection/scan/security/MAC/MLD and backhaul credential flags. |
| `wifi_front_haul_bss_t` | SSID, enable/visibility/isolation, security/interworking/admission/WPS/WMM, MAC filtering, BSSID, MLD, vendor IEs, multi-AP backhaul and offload controls. |
| `wifi_vap_info_t`, `wifi_vap_info_map_t` | VAP/radio/name/bridge/mode/repurposing fields with AP-or-STA union; counted per-radio VAP array. |
| `wifi_ap_capabilities_t` | RTS/security/onboarding/WMM/UAPSD/interworking/BSS-transition capability flags. |
| `wifi_vapstatus_t`, `wifi_wps_ev_t` | Down/up; WPS M2D/failure/success/password/overlap/timeouts/active/disable and external-registrar events. |

### Client-Management and Extender Types

Sources: [client management](../../include/wifi_hal_client_mgt.h) and [extender](../../include/wifi_hal_extender.h).

| Type or related types | Declared content |
| --- | --- |
| `wifi_eap_config_t` | EAPOL key/identity/request timeouts and retry counts. |
| `wifi_fastTrasitionSupport_t`, `wifi_r0KH_t`, `wifi_r1KH_t`, `wifi_FastTransitionConfig_t` | Disabled/full/adaptive support, key-holder identity/key records and mobility-domain/DS/lifetime/deadline/key-holder lists. The `Trasition` spelling is declared. |
| `wifi_channelStats_t` | Channel/pool/noise/radar/RSSI/utilization and cumulative total/busy/Tx/Rx/self/extension busy times. |
| `wifi_associated_dev_rate_info_rx_stats_t`, `wifi_associated_dev_rate_info_tx_stats_t` | NSS/MCS/bandwidth/flags and byte/MSDU/MPDU/PPDU/retry counters; Rx RSSI arrays or Tx attempts. |
| `wifi_associated_dev_tid_entry_t`, `wifi_associated_dev_tid_stats_t` | AC/TID, EWMA/summed time and MSDU count; 16 TID entries. |
| `wifi_associated_dev_stats_t` | 64-bit Rx/Tx bytes/frames/retries/errors, double rates and beacon/ACK RSSI snapshots. |
| `wifi_steering_apConfig_t`, `wifi_steering_clientConfig_t` | AP utilization/inactivity schedules and thresholds; client RSSI thresholds and rejection reason. |
| `wifi_disconnectSource_t`, `wifi_disconnectType_t` | Unknown/local/remote source; unknown/disassociation/deauthentication/reconnect type. |
| `wifi_steering_eventType_t`, `wifi_steering_rssiChange_t` | Probe/connect/disconnect/activity/utilization/RSSI-crossing/RSSI/auth-failure events; unchanged/higher/lower. |
| `wifi_steering_datarateInfo_t`, `wifi_steering_rrmCaps_t` | Width/streams/PHY/MCS/power/SMPS/MU-MIMO; link/neighbor/beacon/LCI/FTM capabilities. |
| `wifi_steering_evProbeReq_t`, `wifi_steering_evConnect_t`, `wifi_steering_evDisconnect_t` | Probe MAC/RSSI/broadcast/block flags; connect BTM/RRM/band/rate/RRM support; disconnect reason/source/type. Connect uses a band mask in phase 2, separate 2G/5G/6G flags otherwise. |
| `wifi_steering_evActivity_t`, `wifi_steering_evChanUtil_t`, `wifi_steering_evRssiXing_t`, `wifi_steering_evRssi_t`, `wifi_steering_evAuthFail_t` | Client activity, utilization, RSSI crossings/sample and authentication rejection payloads. |
| `wifi_steering_event_t` | Event type, AP index, millisecond timestamp and tagged payload union. |
| `wifi_BTMTerminationDuration_t`, `wifi_CondensedCountryString_t`, `wifi_TSFInfo_t`, `wifi_BSSTransitionCandidatePreference_t` | TSF/duration, three-byte country, TSF offset/interval and candidate preference. |
| `wifi_Bearing_t`, `wifi_WideBWChannel_t`, `wifi_Measurement_t` | Bearing/distance/height, bandwidth/center segments and token/mode/type with LCI/LCR union. |
| `wifi_HTCapabilities_t`, `wifi_VHTCapabilities_t`, `wifi_HTOperation_t`, `wifi_VHTOperation_t` | HT/VHT capability/MCS and operational-channel information. |
| `wifi_SecondaryChannelOffset_t`, `wifi_RMEnabledCapabilities_t` | Secondary-channel offset and five capability octets. |
| `wifi_VendorSpecific_t`, `wifi_MeasurementPilotTransmission_t` | OUI/vendor bytes and pilot/vendor data. |
| `wifi_NeighborReport_t` | BSSID/channel/class/PHY and presence-tagged TSF/country/preference/termination/bearing/width/HT/VHT/RM/vendor elements, plus target SSID. |
| `wifi_BTMRequest_t`, `wifi_BTMQuery_t`, `wifi_BTMResponse_t` | Dialog token/mode/timer/URL/candidates; query reason/candidates; response status/target/candidates. |
| `wifi_NeighborRequestFrame_t` | Token, SSID and measurement list. |
| `wifi_BeaconReporting_t`, `wifi_RequestedElementIDS_t`, `wifi_ExtdRequestedElementIDS_t`, `wifi_ChannelReport_t` | Reporting condition/threshold, requested-element array and alias, operating-class/channel report. |
| `wifi_BeaconRequest_t`, `wifi_BeaconReport_t` | Channel/class/duration/mode/BSSID and optional request elements; measurement time/RCPI/RSNI/BSSID/antenna/TSF/report data. |
| `wifi_steer_type_t`, `wifi_steer_matching_condition_t`, `wifi_steer_trigger_data_t` | Pre/post-association steering kinds, unsigned condition mask and module/client/source/destination/type/condition payload. |

### Deprecated and Emulator Types

Sources: [deprecated](../../include/wifi_hal_deprecated.h) and [emulator](../../include/wifi_hal_emu.h).

| Type or related types | Declared content |
| --- | --- |
| `wifi_basicTrafficStats_t`, `wifi_radioTrafficStats_t`, `wifi_ssidTrafficStats_t` | Legacy basic bytes/packets/associations; radio error/noise; SSID retry/ACK/aggregation counters. Also declared by the emulator. |
| `wifi_neighbor_ap_t` | Legacy neighbor record with radio name. Also declared by the emulator. |
| `wifi_diag_ipping_setting_t`, `wifi_diag_ipping_result_t` | Interface/host/repetition/timeout/block size/DSCP and diagnostic state/count/timing. The associated example API is commented out, not a declared callable operation. |
| `wifi_device_t`, `athstat_results_t` | Legacy MAC/IP/auth/signal/Tx/Rx record; chipset-style transmit/receive totals/deltas. |
| `wifi_csaDeauthMode_t`, `wifi_scanFilterMode_t`, `wifi_macAclMode_t` | None/unicast/broadcast; disabled/enabled/first; disabled=0/whitelist=1/blacklist=2. |
| `mac_t`, `wifi_channelStats2_t`, `wifi_channelMetrics_t` | Six-byte MAC wrapper; frequency/noise/OBSS/self-BSS metrics; channel/pool/noise/radar/utilization/power and neighboring RSSI array. |
| `wifi_radioTrafficStatsMeasure_t`, `wifi_associated_dev2_t` | Measuring rate/interval; legacy client diagnostics plus association counter. |
| `wifi_radioQueueType_t`, `wifi_BTMCapabilities_t` | VI/VO/BE/BK/CAB/BCN queue identifiers and limits; peer/capability list. |
| `wifi_dpp_technology_t`, `wifi_dpp_key_management_t` | Infrastructure technology; PSK/DPP/SAE and combined key management. |
| `wifi_dpp_credential_object_t`, `wifi_dpp_discovery_object_t`, `wifi_dpp_configuration_object_t` | PSK/passphrase credentials, SSID alias and technology/discovery/credentials with opaque reconfiguration/signing pointers. |
| `wifi_dpp_state_t`, `wifi_enrollee_responder_status_t`, `wifi_activation_status_t` | DPP provisioning/reconfiguration state, responder result codes and activation status. |
| `wifi_dpp_config_data_t`, `wifi_dpp_reconfig_data_t`, `wifi_dpp_session_type_t`, `wifi_dpp_session_data_t` | Bootstrap keys/transaction ID, config/reconfig discriminator and station/channel/instance/state/session union. |
| `wifi_device_dpp_context_type_t`, `wifi_dpp_public_action_frame_type_t` | Session/received-frame context kind and DPP authentication/discovery/PKEX/configuration/reconfiguration action-frame types. |
| `wifi_dpp_received_frame_t`, `wifi_device_dpp_context_t` | Frame pointer/length/type; AP/version/session/frame/retry/token/config/status/channel-attempt context. Pointer ownership is not fully specified. |
| `wifi_anqp_element_name_t`, `wifi_anqp_element_hs_subtype_t`, `wifi_anqp_id_type_t` | ANQP element IDs including query-list=256 and vendor-specific=56797, HS subtypes and ANQP-versus-HS discriminator. |
| `wifi_anqp_elem_t`, `wifi_anqp_node_t` | Typed element ID/length/data pointer and linked node/value pointers. Ownership of nested lists is not specified universally. |
| `COSA_DML_WIFI_AP_MAC_FILTER` | Emulator-only instance/alias/text-MAC/device-name record. |
| `wifi_band` | Emulator-only `band_invalid=-1`, `band_2_4=0`, `band_5=1`. Not the main `wifi_freq_bands_t` bitmask. |
| `struct hostDetails`, `enum hostap_names`, `struct params`, `struct hostap_conf`, `param_list_t` | Emulator hostname/interface; `ssid=0`, `passphrase=1`; 64-byte name/value fields; SSID and pointer-valued hostapd security settings; counted parameter-list pointer. |

The emulator additionally redeclares `wifi_trafficStats_t`, `wifi_radioTrafficStats2_t`, `wifi_ssidTrafficStats2_t`, `wifi_neighbor_ap2_t`, `wifi_associated_dev_t` and `wifi_radius_setting_t`, alongside the legacy shared types above. The same names do not imply layout compatibility: emulator neighbor records lack newer frequency/BSS-load fields, and associated-device records lack the main header's newer MLD additions.

### Struct Tags and Typedef Names

The following named struct tags identify the typedef-defined records already described above. They are not additional layouts. A tag reused by the alternative emulator header still refers to that header's own definition. The emulator's separately named `struct hostDetails`, `struct params`, `struct hostap_conf` and `enum hostap_names` are registered in the preceding table.

| Struct tag | Public typedef |
| --- | --- |
| `_wifi_trafficStats` | `wifi_trafficStats_t` |
| `_wifi_HS2_OperatorNameDuple_t` | `wifi_HS2_OperatorNameDuple_t` |
| `_wifi_radius_setting_t` | `wifi_radius_setting_t` |
| `_wifi_associated_dev` | `wifi_associated_dev_t` |
| `_wifi_GASConfiguration_t` | `wifi_GASConfiguration_t` |
| `_wifi_key_multi_psk` | `wifi_key_multi_psk_t` |
| `_wifi_eap_config_t` | `wifi_eap_config_t` |
| `_wifi_basicTrafficStats` | `wifi_basicTrafficStats_t` |
| `_wifi_radioTrafficStats` | `wifi_radioTrafficStats_t` |
| `_wifi_ssidTrafficStats` | `wifi_ssidTrafficStats_t` |
| `_wifi_neighbor_ap` | `wifi_neighbor_ap_t` |
| `_wifi_diag_ipping_setting` | `wifi_diag_ipping_setting_t` |
| `_wifi_diag_ipping_result` | `wifi_diag_ipping_result_t` |
| `_wifi_device` | `wifi_device_t` |
| `athstat_results` | `athstat_results_t` |
| `_mac_t` | `mac_t` |
| `_wifi_channelStats2` | `wifi_channelStats2_t` |
| `_wifi_channelMetrics` | `wifi_channelMetrics_t` |
| `_wifi_radioTrafficStatsMeasure` | `wifi_radioTrafficStatsMeasure_t` |
| `_wifi_associated_dev2` | `wifi_associated_dev2_t` |
| `wifi_anqp_node` | `wifi_anqp_node_t` |
| `_COSA_DML_WIFI_AP_MAC_FILTER` | `COSA_DML_WIFI_AP_MAC_FILTER` |
| `__param_list` | `param_list_t` |
| `_wifi_radioTrafficStats2` | `wifi_radioTrafficStats2_t` |
| `_wifi_ssidTrafficStats2` | `wifi_ssidTrafficStats2_t` |
| `_wifi_neighbor_ap2` | `wifi_neighbor_ap2_t` |
| `_wifi_channelStats` | `wifi_channelStats_t` |
| `_wifi_associated_dev_rate_info_rx_stats` | `wifi_associated_dev_rate_info_rx_stats_t` |
| `_wifi_associated_dev_rate_info_tx_stats` | `wifi_associated_dev_rate_info_tx_stats_t` |
| `wifi_associated_dev_tid_entry` | `wifi_associated_dev_tid_entry_t` |
| `wifi_associated_dev_tid_stats` | `wifi_associated_dev_tid_stats_t` |
| `_wifi_associated_dev_stats` | `wifi_associated_dev_stats_t` |
| `_wifi_multi_link_info_t` | `wifi_multi_link_info_t` |
| `_wifi_frame_info` | `wifi_frame_info_t` |
| `_wifi_csi_data` | `wifi_csi_data_t` |
| `_wifi_associated_dev3` | `wifi_associated_dev3_t` |
| `_wifi_channelMap_t` | `wifi_channelMap_t` |
| `_wifi_radioTemperature_t` | `wifi_radioTemperature_t` |
| `_wifi_rssi_snapshot` | `wifi_rssi_snapshot_t` |
| `_wifi_apRssi` | `wifi_apRssi_t` |

## Callback Signature Reference

The following signatures are declarations, not sample registration wrappers. `P2` means `WIFI_HAL_VERSION_3_PHASE2` defined; `!P2` means undefined. Callback return interpretation is not uniformly documented. `void` means there is no return value, while an `INT` callback does not by itself define which codes the vendor consumes. The BTM query/response comments explicitly specify `WIFI_HAL_SUCCESS`/`WIFI_HAL_ERROR`. Apply the borrowed-payload and concurrency caveats above to every callback unless a more specific contract exists.

### AP and Frame Callbacks

Source: [wifi_hal_ap.h](../../include/wifi_hal_ap.h).

```c
/* P2 */
typedef INT (*wifi_newApAssociatedDevice_callback)(INT apIndex, wifi_associated_dev3_t *associated_dev);
/* !P2; the emulator also declares this signature, with its own struct layout */
typedef INT (*wifi_newApAssociatedDevice_callback)(INT apIndex, wifi_associated_dev_t *associated_dev);

typedef INT (*wifi_apDisassociatedDevice_callback)(INT apIndex, char *MAC, INT event_type);
typedef INT (*wifi_device_disassociated_callback)(INT apIndex, char *src_mac, char *dest_mac, INT frame_type, INT event_type);
typedef INT (*wifi_stamode_callback)(int apIndex, char *mac, int key_mgmt, int type, int radio, int mode);
typedef INT (*wifi_handshake_callback)(int apIndex, char *mac, int status);
typedef INT (*wifi_eapol_key_callback)(int apIndex, char *mac, eapol_msg_type_t msg_type, unsigned long long replay_counter);
typedef INT (*wifi_eapol_timeouts_callback)(int apIndex, char *mac, int type);
typedef INT (*wifi_apMaxClientRejection_callback)(INT apIndex, char *MAC, INT reason);
typedef INT (*wifi_apStatusCode_callback)(int apIndex, char *src_mac, char *dest_mac, int frame_type, int status);
typedef INT (*wifi_radiusEapFailure_callback)(INT apIndex, mac_address_t sta_mac, INT failure_reason);
typedef INT (*wifi_radiusFallback_failover_callback)(INT apIndex, INT failure_reason);
typedef INT (*wifi_apDeAuthEvent_callback)(int ap_index, char *mac, int reason);
typedef INT (*wifi_device_deauthenticated_callback)(int ap_index, char *src_mac, char *dest_mac, int frame_type, int reason);
typedef INT (*wifi_apFrameDropUnencrypted_callback)(int ap_index, char *src_mac, unsigned short ether_type);

typedef void (*wifi_received8021xFrame_callback)(unsigned int ap_index, mac_address_t sta, wifi_eapol_type_t type, void *data, unsigned int len);
typedef void (*wifi_sent8021xFrame_callback)(unsigned int ap_index, mac_address_t sta, wifi_eapol_type_t type, void *data, unsigned int len);
typedef void (*wifi_receivedAuthFrame_callback)(unsigned int ap_index, mac_address_t sta, void *data, unsigned int len);
typedef void (*wifi_sentAuthFrame_callback)(unsigned int ap_index, mac_address_t sta, void *data, unsigned int len);
typedef void (*wifi_receivedAssocReqFrame_callback)(unsigned int ap_index, mac_address_t sta, void *data, unsigned int len);
typedef void (*wifi_sentAssocRspFrame_callback)(unsigned int ap_index, mac_address_t sta, void *data, unsigned int len);
typedef INT (*wifi_hal_frame_hook_fn_t)(INT ap_index, wifi_mgmtFrameType_t type);

/* P2 */
typedef INT (*wifi_receivedMgmtFrame_callback)(INT apIndex, wifi_frame_t *frame);
typedef INT (*wifi_receivedDataFrame_callback)(INT apIndex, mac_address_t sta_mac, UCHAR *frame, UINT len, wifi_dataFrameType_t type, wifi_direction_t dir);
/* !P2 */
typedef INT (*wifi_receivedMgmtFrame_callback)(INT apIndex, UCHAR *sta_mac, UCHAR *frame, UINT len, wifi_mgmtFrameType_t type, wifi_direction_t dir, unsigned int recv_freq);
typedef INT (*wifi_receivedDataFrame_callback)(INT apIndex, UCHAR *sta_mac, UCHAR *frame, UINT len, wifi_dataFrameType_t type, wifi_direction_t dir);

typedef INT (*wifi_csi_callback)(mac_address_t mac_addr, wifi_csi_data_t *csi_data);
typedef INT (*wifi_vapstatus_callback)(INT apIndex, wifi_vapstatus_t status);
typedef INT (*wifi_analytics_callback)(CHAR *fmt, ...);
typedef INT (*wifi_wpsEvent_callback)(INT apIndex, wifi_wps_ev_t event);
```

Not every callback typedef has a corresponding declared registration function in this snapshot. In particular, do not infer registration names for the device-disassociated/deauthenticated, EAPOL, maximum-client-rejection, individual 802.1X/auth/association-frame or received-data callback types. The management-frame registration accepts the management callback actually declared in the selected branch.

### Radio, Station and Extender Callbacks

Sources: [radio](../../include/wifi_hal_radio.h), [station](../../include/wifi_hal_sta.h) and [extender](../../include/wifi_hal_extender.h).

```c
typedef INT (*wifi_scanResults_callback)(wifi_radio_index_t index, wifi_bss_info_t **bss, UINT *num_bss);
typedef INT (*wifi_staConnectionStatus_callback)(INT apIndex, wifi_bss_info_t *bss_dev, wifi_station_stats_t *sta);
typedef INT (*wifi_steerTriggered_callback)(INT apIndex, wifi_steer_trigger_data_t *data);
typedef void (*wifi_steering_eventCB_t)(UINT steeringgroupIndex, wifi_steering_event_t *event);

/* P2 */
typedef INT (*wifi_BTMQueryRequest_callback)(UINT apIndex, mac_address_t peerMac, wifi_BTMQuery_t *query, UINT inMemSize, wifi_BTMRequest_t *request);
typedef INT (*wifi_BTMResponse_callback)(UINT apIndex, mac_address_t peerMac, wifi_BTMResponse_t *response);
/* !P2 */
typedef INT (*wifi_BTMQueryRequest_callback)(UINT apIndex, CHAR *peerMac, wifi_BTMQuery_t *query, UINT inMemSize, wifi_BTMRequest_t *request);
typedef INT (*wifi_BTMResponse_callback)(UINT apIndex, CHAR *peerMac, wifi_BTMResponse_t *response);

typedef INT (*wifi_RMBeaconReport_callback)(UINT apIndex, wifi_BeaconReport_t *out_struct, UINT *out_array_size, UCHAR *out_DialogToken);
```

For the BTM query callback, `query` is input and `request` is writable response storage constrained by `inMemSize`. The comments describe caller allocation and release after callback return and transmission to the STA, but also ambiguously call it memory “allocated by the callback.” Clarify which invocation-side entity owns that storage and the send-completion boundary. The scan callback's double pointer is not an ownership-transfer guarantee.

### Deprecated and Emulator Callbacks

Source: [wifi_hal_deprecated.h](../../include/wifi_hal_deprecated.h). The emulator also defines `wifi_apAuthEvent_callback`.

```c
typedef INT (*wifi_apAuthEvent_callback)(INT apIndex, char *MAC, INT event_type);
typedef INT (*wifi_apAuthenticatedEvent_callback)(INT apIndex, char *MAC);
typedef INT (*wifi_apAssociatedDevice_callback)(INT apIndex, char *MAC, INT event_type);
typedef void (*wifi_dppAuthResponse_callback_t)(UINT apIndex, mac_address_t sta, UCHAR *frame, UINT len);
typedef void (*wifi_dppConfigRequest_callback_t)(UINT apIndex, mac_address_t sta, UCHAR token, UCHAR *attribs, UINT length);
typedef void (*wifi_dppConfigResult_callback_t)(UINT apIndex, mac_address_t sta, UCHAR *attribs, UINT length);
typedef void (*wifi_dppReconfigAnnounce_callback_t)(UINT apIndex, mac_address_t sta, UCHAR *attribs, UINT length);
typedef void (*wifi_dppReconfigAuthResponse_callback_t)(UINT apIndex, mac_address_t sta, UCHAR *frame, UINT len);
typedef void (*wifi_anqp_request_callback_t)(UINT apIndex, mac_address_t sta, unsigned char token, wifi_anqp_node_t *list);
typedef void (*wifi_chan_eventCB_t)(UINT radioIndex, wifi_chan_eventType_t event, UCHAR channel);
```

`wifi_apAuthenticatedEvent_callback_register` takes `wifi_apAuthEvent_callback`, not the separately declared `wifi_apAuthenticatedEvent_callback`. This mismatch is preserved in the API inventory and must not be silently corrected by an integrator.

### Callback Return Contracts

Callback results are distinct from the return values of registration functions. The following groups exhaust the callback typedefs listed above, including both phase-2 branches and the alternative emulator definitions. A documented success/error pair specifies what the callback returns; it does not specify whether the vendor retries, drops an event or takes another action after an error.

| Callback typedefs and source scope | Documented callback result |
| --- | --- |
| AP: `wifi_newApAssociatedDevice_callback` in both branches, `wifi_apDisassociatedDevice_callback`, `wifi_apStatusCode_callback`, `wifi_radiusFallback_failover_callback`, `wifi_apDeAuthEvent_callback`, `wifi_apFrameDropUnencrypted_callback`, `wifi_vapstatus_callback`, `wifi_analytics_callback`, `wifi_wpsEvent_callback` | `WIFI_HAL_SUCCESS=0` on success; `WIFI_HAL_ERROR=-1` on error. |
| AP: `wifi_device_disassociated_callback`, `wifi_stamode_callback`, `wifi_apMaxClientRejection_callback`, `wifi_device_deauthenticated_callback` | `RETURN_OK=0` on success; `RETURN_ERR=-1` on error. |
| Extender: `wifi_BTMQueryRequest_callback`, `wifi_BTMResponse_callback`, in both branches | `WIFI_HAL_SUCCESS=0` on success; `WIFI_HAL_ERROR=-1` on error. |
| Extender: `wifi_RMBeaconReport_callback` | `RETURN_OK=0` on success; `RETURN_ERR=-1` on error. |
| Emulator: its own `wifi_newApAssociatedDevice_callback` and `wifi_apAuthEvent_callback` | `WIFI_HAL_SUCCESS=0` on success; `WIFI_HAL_ERROR=-1` on error. This does not supply a missing contract for the deprecated header's same-named authentication callback. |
| AP: `wifi_handshake_callback`, `wifi_eapol_key_callback`, `wifi_eapol_timeouts_callback`, `wifi_radiusEapFailure_callback`, `wifi_hal_frame_hook_fn_t`, `wifi_receivedMgmtFrame_callback`, `wifi_receivedDataFrame_callback`, `wifi_csi_callback`; radio: `wifi_scanResults_callback`; station: `wifi_staConnectionStatus_callback`; extender: `wifi_steerTriggered_callback`; deprecated: `wifi_apAuthEvent_callback`, `wifi_apAuthenticatedEvent_callback`, `wifi_apAssociatedDevice_callback` | `INT` is declared, but no dedicated return-code values are specified. This applies to both branches where present. The scan callback comment explicitly leaves return values as a TODO. |
| AP: `wifi_received8021xFrame_callback`, `wifi_sent8021xFrame_callback`, `wifi_receivedAuthFrame_callback`, `wifi_sentAuthFrame_callback`, `wifi_receivedAssocReqFrame_callback`, `wifi_sentAssocRspFrame_callback`; extender: `wifi_steering_eventCB_t`; deprecated: all five DPP callback typedefs, `wifi_anqp_request_callback_t`, `wifi_chan_eventCB_t` | `void`; there is no callback return value. |

These classifications do not change callback payload ownership, thread affinity, nonblocking requirements or the unresolved registration and teardown contracts. In particular, status annotations on a callback typedef must not be used to invent a return value for a `void` registration function.

## Contract Gaps and Vendor-Dependent Behavior

| Gap | Header evidence and required clarification |
| --- | --- |
| No deinitialization contract | Generic declares `wifi_init`, `wifi_reset` and `wifi_down`, but no `wifi_hal_init`, `wifi_hal_deinit` or `wifi_deinit`. Teardown ordering, outstanding work and callback draining need a vendor contract. |
| Missing return codes | Deprecated declarations without a dedicated status set include `wifi_getTWTParams`, `wifi_setBSSColorEnabled`, `wifi_getBSSColorEnabled`, `wifi_getRadioChannelStats2`, `wifi_getSSIDTrafficStats`, `wifi_getBasicTrafficStats`, `wifi_getNeighboringWiFiDiagnosticResult`, `wifi_getAllAssociatedDeviceDetail`, `wifi_pushRadioChannelMode`, `wifi_pushRadioTxChainMask`, `wifi_pushRadioRxChainMask`, `wifi_pushBridgeInfo`, non-phase-2 `wifi_getApAssociatedClientDiagnosticResult`, `wifi_getApAuthenticatedDevices`, `wifi_getRadioClientInactivityTimout`, `mgmt_frame_received_callback`, `wifi_anqp_request_callback_register`, `wifi_anqpSendResponse` and `wifi_chan_eventRegister`. AP helpers `get_vap_ssid`, `get_vap_bridge_name` and `get_vap_security_mode` lack dedicated return semantics. Emulator `wifi_getApIndexForWiFiBand` returns an index but does not define its invalid-band/error range. Do not borrow a preceding declaration's comment. Legacy `wifi_steering_setGroup` does document `RETURN_OK`/`RETURN_ERR`. |
| Impossible status returns | AP `wifi_apStatusCode_callback_register` and `wifi_ap_stamode_callback_register` are `void` but their comments claim `RETURN_OK`/`RETURN_ERR`. No value can be tested from these declarations. Adjacent `wifi_handshake_callback_register` is also `void`, but has no dedicated status comment; it must not inherit the preceding registration's documentation. |
| Error vocabulary is not per-API coverage | Generic defines 0 through -6, but most modern API comments specify only success 0 and generic error -1. `wifi_getNASta` explicitly collapses invalid/unsupported/internal failures to -1. |
| Array allocation and release | Explicit caller-free contracts exist for station network discovery and extender rate arrays; other `**` outputs omit allocator/release/failure cleanup details. Legacy HAL-allocation comments do not define release. CSI adds conflicting outer-array directions and nested allocation. |
| Callback lifetime and concurrency | No universal event-thread, ordering, reentrancy, unregister barrier, retained-buffer or callback-status handling contract. Some callback types have no registration entry point. |
| Index base and mapping | One-based macros coexist with documented zero-based radio indexing and platform/PHY/interface mapping fields. There is no universal band-to-index rule. |
| Conditional ABI | Phase 2 changes MAC types and function/callback signatures; version 3 changes capacity and MFP fields. Mixed compilation settings are unsafe. |
| Same-name alternate interfaces | Emulator/main shared include guard and older struct layouts prevent treating both headers as one compatible API. Emulator `wifi_getApWpaEncryptoinMode` differs in spelling from main `wifi_getApWpaEncryptionMode`. Both declare `wifi_setApWmmOgAckPolicy`, but the emulator uses parameter name `class` instead of main `cla`; `class` is a C++ keyword. |
| Parameter-direction errors | Deprecated `wifi_setRadioDCSEnable` labels scalar `enable` as output; `wifi_getRadioDcsDwelltime` labels its pointer input; some size scalars are labeled output; setter strings and some diagnostic parameters have copied output/input annotations. Extender TID/aggregate handle pointers are labeled input while Rx/Tx handles are outputs. The table distinguishes intended result use from a guaranteed annotation. |
| Unsized buffers | Many `CHAR *` APIs lack capacity parameters, required termination rules or truncation behavior. Explicit exceptions include AP name minimum 16 bytes and MFP output minimum 64 bytes. Legacy string-size comments must be checked individually. |
| Units, widths and invalid data | Native `ULONG` counters vary by ABI; channel busy-time units, some rate units, counter rollover, invalid RSSI encodings and snapshot consistency are incompletely defined. The unsigned channel-utilization field conflicts with its -1 sentinel. |
| Telemetry comment drift | `wifi_ssidTrafficStats2_t::ssid_UnicastPacketsSent` describes inbound errors; `ssid_BroadcastPacketsRecevied` repeats a transmission-oriented description. The spelling `radio_RetransmissionMetirc` and the 80+80-width comment's “10” versus enum `0x10` must not be silently normalized into ABI changes. |
| Incomplete/extension-heavy C declarations | `wifi_sta_capability_t` is empty; several functions use old-style `()` rather than `(void)`; packet structs use zero-length arrays. C/C++ and compiler portability need separate verification. |
| Configuration and hardware effects | Commit timing, rollback, persistence, RF calibration, regulatory DFS/CAC compliance, scan interference, supported MLO/TWT combinations and exact sensor/metric availability are not proven by declarations. |
| Emulator macro dependency | Emulator comments use `WIFI_HAL_SUCCESS`/`WIFI_HAL_ERROR` although that header itself defines `RETURN_OK`/`RETURN_ERR`, not the complete modern error family. Do not assume the main umbrella can be included to resolve this. |

These gaps are documentation findings, not changes to the public ABI. Integrators should obtain explicit vendor answers before implementing tests that assert unspecified buffer sizes, error values, execution time or hardware behavior. No missing function or struct field is invented here.

## Non Functional Requirements

### Logging and Debugging

The retained integration guidance asks vendors to log errors and critical information consistently across HAL components, using Linux-style levels and `wifi_vendor_hal.log` if a vendor log is produced. The headers do not provide a logging API, guarantee that filename or define redaction. Do not log PSKs, passphrases, RADIUS secrets, key-holder keys or raw DPP credentials contained in configuration structures.

### Memory, Performance and Quality Control

Idle and standby CPU/memory consumption should be minimal; product-specific budgets must come from the product specification rather than this interface. Static analysis, a zero-warning compilation policy and memory checking remain recommended quality practices. Conformance tests should cover documented return codes, capacity limits and explicit ownership rules, without treating a header-only inventory as hardware verification.

### Licensing, Build and Variability

The component is licensed under Apache License 2.0; see the existing [LICENSE](../../LICENSE). Linux library integration may use the platform's C/C++ toolchain. This page does not prescribe an unverified build recipe. Preserve versioned source delivery and align compile-time flags across callers and vendors. Runtime capability discovery, not a fictional `getCapabilities()` entry point, uses the declared `wifi_getHalCapability`.

## Public API Inventory

### Reading the Inventory

The tables record declarations from all ten public headers. The declaration column includes every formal parameter and its C type. Parameters not listed in the result column are inputs for ordinary use; `IO:` marks in/out storage, and `?:` marks unresolved direction. For legacy annotation errors, a result name describes the function's intended use, not an ABI correction or a stronger header guarantee. A dash means no output parameter, not necessarily no hardware side effect.

`P2` and `!P2` identify conditional declarations. Other declarations are shown independently of the selected branch. All ordinary `INT` results are status values unless noted otherwise. Return code `H` means documented `WIFI_HAL_SUCCESS=0` or `WIFI_HAL_ERROR=-1`; `R` means documented `RETURN_OK=0` or `RETURN_ERR=-1`; `?` means no dedicated return-code or result-semantics contract; `V` means `void`; `V!` flags contradictory status documentation on a `void` declaration. `B` means a documented Boolean test, whose meaning is stated per function; `Z` means the literal documented success 0/error -1 pair without asserting a macro name. The generic header also defines `WIFI_HAL_INTERNAL_ERROR=-2`, `WIFI_HAL_UNSUPPORTED=-3`, `WIFI_HAL_INVALID_ARGUMENTS=-4`, `WIFI_HAL_INVALID_VALUE=-5`, and `WIFI_HAL_NOT_READY=-6`, but those are not inferred as valid results for every API.

Ownership code `C` means caller-supplied storage with no declared transfer; input retention and exact output capacity still require the individual contract. `N` means no data pointer. `F` means explicitly HAL-allocated array, caller frees it; no named deallocator is supplied. `A` means returned-array ownership/release is unresolved. `L` means legacy HAL allocation is stated but release is not. `CSI` means the special outer/nested-array conflict above. `K` means a retained callback registration with unresolved subscription/lifetime rules. `T` applies to every row and means no general locking/reentrancy/thread-affinity guarantee; nonblocking requirements are discussed above and do not remove `T`.

These codes avoid inventing per-function memory or thread guarantees. Exact argument spellings, including typographical errors in public identifiers, are preserved.

### Generic Subsystem APIs

Source: [wifi_hal_generic.h](../../include/wifi_hal_generic.h).

| Declaration | Output / in-out parameters | Return | Ownership / thread caveat |
| --- | --- | --- | --- |
| `INT wifi_getHalCapability(wifi_hal_capability_t *cap)` | `cap` | H | C/T |
| `INT wifi_factoryReset()` | - | H | N/T |
| `INT wifi_setLED(INT radioIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_init()` | - | H | N/T |
| `INT wifi_reset()` | - | H | N/T |
| `INT wifi_down()` | - | H | N/T |
| `INT wifi_createInitialConfigFiles()` | - | H | N/T |
| `INT wifi_createHostApdConfig(INT apIndex, BOOL createWpsCfg)` | - | H | N/T |
| `INT wifi_startHostApd()` | - | H | N/T |
| `INT wifi_stopHostApd()` | - | H | N/T |

### Radio APIs

Source: [wifi_hal_radio.h](../../include/wifi_hal_radio.h).

| Declaration | Output / in-out parameters | Return | Ownership / thread caveat |
| --- | --- | --- | --- |
| `INT wifi_getRadioResetCount(INT radioIndex, ULONG *output_int)` | `output_int` | H | C/T |
| `INT wifi_factoryResetRadios()` | - | H | N/T |
| `INT wifi_factoryResetRadio(int radioIndex)` | - | H | N/T |
| `INT wifi_getRadioEnable(INT radioIndex, BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_setRadioEnable(INT radioIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_getRadioStatus(INT radioIndex, BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_getRadioIfName(INT radioIndex, CHAR *output_string)` | `output_string` | H | C/T |
| P2: `INT wifi_getRadioChannelsInUse(wifi_radio_index_t radioIndex, wifi_channels_list_t *channel_list)` | `channel_list` | H | C/T |
| `INT wifi_getRadioDfsEnable(INT radioIndex, BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_setRadioDfsEnable(INT radioIndex, BOOL enabled)` | - | H | N/T |
| `INT wifi_getRadioDfsAtBootUpEnable(INT radioIndex, BOOL *enable)` | `enable` | H | C/T |
| `INT wifi_setRadioDfsAtBootUpEnable(INT radioIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_getRadioMCS(INT radioIndex, INT *output_INT)` | `output_INT` | H | C/T |
| `INT wifi_setRadioMCS(INT radioIndex, INT MCS)` | - | H | N/T |
| `INT wifi_getRadioTransmitPower(INT radioIndex, ULONG *output_ulong)` | `output_ulong` | H | C/T |
| `INT wifi_getRadioPercentageTransmitPower(INT radioIndex, ULONG *output_ulong)` | `output_ulong` | H | C/T |
| `INT wifi_setRadioTransmitPower(INT radioIndex, ULONG TransmitPower)` | - | H | N/T |
| `INT wifi_getRadioCarrierSenseThresholdRange(INT radioIndex, INT *output)` | `output` | H | C/T |
| `INT wifi_getRadioCarrierSenseThresholdInUse(INT radioIndex, INT *output)` | `output` | H | C/T |
| `INT wifi_setRadioCarrierSenseThresholdInUse(INT radioIndex, INT threshold)` | - | H | N/T |
| `INT wifi_applyRadioSettings(INT radioIndex)` | - | H | N/T |
| `INT wifi_setRadioCtsProtectionEnable(INT radioIndex, BOOL enable)` | - | R | N/T |
| `INT wifi_setRadioObssCoexistenceEnable(INT apIndex, BOOL enable)` | - | H | N/T; AP-index spelling retained |
| `INT wifi_setRadioFragmentationThreshold(INT radioIndex, UINT threshold)` | - | H | N/T |
| `INT wifi_setRadioSTBCEnable(INT radioIndex, BOOL STBC_Enable)` | - | H | N/T |
| `INT wifi_getRadioAMSDUEnable(INT radioIndex, BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_setRadioAMSDUEnable(INT radioIndex, BOOL amsduEnable)` | - | H | N/T |
| `INT wifi_getRadioUpTime(INT radioIndex, ULONG *uptime)` | `uptime` | H | C/T |
| `INT wifi_getRadioReverseDirectionGrantSupported(INT radioIndex, BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_getRadioAutoBlockAckEnable(INT radioIndex, BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_setRadioAutoBlockAckEnable(INT radioIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_getRadioIGMPSnoopingEnable(INT radioIndex, BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_setRadioIGMPSnoopingEnable(INT radioIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_setZeroDFSState(UINT radioIndex, BOOL enable, BOOL precac)` | - | H | N/T |
| `INT wifi_getZeroDFSState(UINT radioIndex, BOOL *enable, BOOL *precac)` | `enable`, `precac` | H | C/T |
| `INT wifi_setDownlinkMuType(INT radio_index, wifi_dl_mu_type_t mu_type)` | - | H | N/T |
| `INT wifi_getDownlinkMuType(INT radio_index, wifi_dl_mu_type_t *mu_type)` | `mu_type` | H | C/T |
| `INT wifi_setUplinkMuType(INT radio_index, wifi_ul_mu_type_t mu_type)` | - | H | N/T |
| `INT wifi_getUplinkMuType(INT radio_index, wifi_ul_mu_type_t *mu_type)` | `mu_type` | H | C/T |
| `INT wifi_setGuardInterval(INT radio_index, wifi_guard_interval_t guard_interval)` | - | H | N/T |
| `INT wifi_getGuardInterval(INT radio_index, wifi_guard_interval_t *guard_interval)` | `guard_interval` | H | C/T |
| `INT wifi_setBSSColor(INT radio_index, UCHAR color)` | - | H | N/T |
| `INT wifi_getBSSColor(INT radio_index, UCHAR *color)` | `color` | H | C/T |
| `INT wifi_getAvailableBSSColor(INT radio_index, INT maxNumberColors, UCHAR *colorList, INT *numColorReturned)` | `colorList`, `numColorReturned` | H | C/T |
| `INT wifi_getMuEdca(INT radio_index, wifi_access_category_t ac, wifi_edca_t *edca)` | `edca` | H | C/T |
| `INT wifi_setDownlinkDataAckType(INT radio_index, wifi_dl_data_ack_type_t ack_type)` | - | H | N/T |
| `INT wifi_get80211axDefaultParameters(INT radio_index, wifi_80211ax_params_t *params)` | `params` | H | C/T |
| `INT wifi_setRadioOperatingParameters(wifi_radio_index_t index, wifi_radio_operationParam_t *operationParam)` | - | H | C/T |
| `INT wifi_getRadioOperatingParameters(wifi_radio_index_t index, wifi_radio_operationParam_t *operationParam)` | `operationParam` | H | C/T |
| `INT wifi_getScanResults(wifi_radio_index_t index, wifi_channel_t *channel, wifi_bss_info_t **bss, UINT *num_bss)` | `bss`, `num_bss` | H | A/T |
| `void wifi_scanResults_callback_register(wifi_scanResults_callback callback_proc)` | - | V | K/T |
| `INT wifi_hal_getRadioTemperature(wifi_radio_index_t radioIndex, wifi_radioTemperature_t *output_struct)` | `output_struct` | H | C/T |

### Station APIs

Source: [wifi_hal_sta.h](../../include/wifi_hal_sta.h).

| Declaration | Output / in-out parameters | Return | Ownership / thread caveat |
| --- | --- | --- | --- |
| `INT wifi_connect(INT ap_index, wifi_bss_info_t *bss)` | - | R | C/T |
| `INT wifi_disconnect(INT ap_index)` | - | R | N/T |
| `INT wifi_getStationCapability(INT ap_index, wifi_sta_capability_t *cap)` | `cap` | R | C/T; empty capability struct |
| `INT wifi_findNetworks(INT ap_index, wifi_channel_t *channel, wifi_bss_info_t **bss, UINT *num_bss)` | `bss`, `num_bss` | R | F/T |
| `INT wifi_getStationStats(INT ap_index, wifi_station_stats_t *sta)` | `sta` | R | C/T |
| `void wifi_staConnectionStatus_callback_register(wifi_staConnectionStatus_callback callback_proc)` | - | V | K/T |

### Telemetry APIs

Source: [wifi_hal_telemetry.h](../../include/wifi_hal_telemetry.h).

| Declaration | Output / in-out parameters | Return | Ownership / thread caveat |
| --- | --- | --- | --- |
| `INT wifi_getRadioTrafficStats2(INT radioIndex, wifi_radioTrafficStats2_t *output_struct)` | `output_struct` | H | C/T |
| `INT wifi_getSSIDTrafficStats2(INT ssidIndex, wifi_ssidTrafficStats2_t *output_struct)` | `output_struct` | H | C/T |
| P2: `INT wifi_getNeighboringWiFiStatus(INT radioIndex, BOOL scan, wifi_neighbor_ap2_t **neighbor_ap_array, UINT *output_array_size)` | `neighbor_ap_array`, `output_array_size` | H | A/T |
| `INT wifi_getRadioBandUtilization(INT radioIndex, INT *output_percentage)` | `output_percentage` | H | C/T |
| `INT wifi_getApAssociatedDeviceDiagnosticResult3(INT apIndex, wifi_associated_dev3_t **associated_dev_array, UINT *output_array_size)` | `associated_dev_array`, `output_array_size`; CSI mode unresolved | H | CSI/T |
| P2: `INT wifi_getApAssociatedClientDiagnosticResult(INT apIndex, mac_address_t mac_addr, wifi_associated_dev3_t *dev_conn)` | `dev_conn` | H | C/T; nested CSI lifetime unresolved |
| `INT wifi_setClientDetailedStatisticsEnable(INT radioIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_getRadioStatsEnable(INT radioIndex, BOOL *output_enable)` | `output_enable` | H | C/T |
| `INT wifi_setRadioStatsEnable(INT radioIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_getVAPTelemetry(UINT apIndex, wifi_VAPTelemetry_t *telemetry)` | `telemetry` | H | C/T |
| `INT wifi_getNASta(INT apIndex, const wifi_na_sta_req_params_t *params, wifi_na_sta_info_t *sta_info)` | `sta_info` | H | C/T; STA must be unassociated |

### AP and VAP APIs

Source: [wifi_hal_ap.h](../../include/wifi_hal_ap.h).

| Declaration | Output / in-out parameters | Return | Ownership / thread caveat |
| --- | --- | --- | --- |
| `INT wifi_getWifiTrafficStats(INT apIndex, wifi_trafficStats_t *output_struct)` | `output_struct` | H | C/T |
| P2: `INT wifi_getApAssociatedDevice(INT ap_index, mac_address_t *output_deviceMacAddressArray, UINT maxNumDevices, UINT *output_numDevices)` | `output_deviceMacAddressArray`, `output_numDevices` | H | C/T; bounded array |
| `INT wifi_factoryResetAP(int apIndex)` | - | H | N/T |
| `INT wifi_deleteAp(INT apIndex)` | - | H | N/T |
| `INT wifi_getApName(INT apIndex, CHAR *output_string)` | `output_string` | H | C/T; at least 16 bytes |
| `INT wifi_setApRtsThreshold(INT apIndex, UINT threshold)` | - | H | N/T |
| `INT wifi_removeApSecVaribles(INT apIndex)` | - | H | N/T |
| `INT wifi_disableApEncryption(INT apIndex)` | - | H | N/T |
| `INT wifi_getApNumDevicesAssociated(INT apIndex, ULONG *output_ulong)` | `output_ulong` | H | C/T |
| P2: `INT wifi_kickApAssociatedDevice(INT apIndex, mac_address_t client_mac)` | - | H | C/T; binary MAC |
| `INT wifi_getApRadioIndex(INT apIndex, INT *output_int)` | `output_int` | H | C/T |
| P2: `INT wifi_getApAclDevices(INT apIndex, mac_address_t *macArray, UINT maxArraySize, UINT *output_numEntries)` | `macArray`, `output_numEntries` | H | C/T; bounded array |
| P2: `INT wifi_addApAclDevice(INT apIndex, mac_address_t DeviceMacAddress)` | - | H | C/T |
| P2: `INT wifi_delApAclDevice(INT apIndex, mac_address_t deviceMacAddress)` | - | H | C/T |
| `INT wifi_delApAclDevices(INT apIndex)` | - | H | N/T |
| `INT wifi_getApAclDeviceNum(INT apIndex, UINT *output_uint)` | `output_uint` | H | C/T |
| `INT wifi_kickApAclAssociatedDevices(INT apIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_setApMacAddressControlMode(INT apIndex, INT filterMode)` | - | H | N/T; 0 disabled, 1 whitelist, 2 blacklist |
| `INT wifi_getApMacAddressControlMode(INT apIndex, INT *output_filterMode)` | `output_filterMode` | H | C/T |
| `INT wifi_setApVlanID(INT apIndex, INT vlanId)` | - | H | N/T |
| `INT wifi_resetApVlanCfg(INT apIndex)` | - | H | N/T |
| `INT wifi_setApEnable(INT apIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_getApEnable(INT apIndex, BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_getApStatus(INT apIndex, CHAR *output_string)` | `output_string` | H | C/T |
| `INT wifi_getApSsidAdvertisementEnable(INT apIndex, BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_setApSsidAdvertisementEnable(INT apIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_getApRetryLimit(INT apIndex, UINT *output)` | `output` | H | C/T |
| `INT wifi_setApRetryLimit(INT apIndex, UINT number)` | - | H | N/T |
| `INT wifi_getApWmmEnable(INT apIndex, BOOL *output)` | `output` | H | C/T |
| `INT wifi_setApWmmEnable(INT apIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_getApWmmUapsdEnable(INT apIndex, BOOL *output)` | `output` | H | C/T |
| `INT wifi_setApWmmUapsdEnable(INT apIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_setApWmmOgAckPolicy(INT apIndex, INT cla, BOOL ackPolicy)` | - | H | N/T; `cla` is the declared name |
| `INT wifi_getApIsolationEnable(INT apIndex, BOOL *output)` | `output` | H | C/T |
| `INT wifi_setApIsolationEnable(INT apIndex, BOOL enable)` | - | H | N/T |
| `INT wifi_setApBeaconRate(INT apIndex, char *sBeaconRate)` | - | H | C/T |
| `INT wifi_getApBeaconRate(INT apIndex, char *output_BeaconRate)` | `output_BeaconRate` | H | C/T |
| `INT wifi_getApMaxAssociatedDevices(INT apIndex, UINT *output)` | `output` | H | C/T |
| `INT wifi_setApMaxAssociatedDevices(INT apIndex, UINT number)` | - | H | N/T |
| `INT wifi_setApSecurityReset(INT apIndex)` | - | H | N/T |
| `INT wifi_getApSecurityMFPConfig(INT apIndex, CHAR *output_string)` | `output_string` | H | C/T; at least 64 bytes |
| `INT wifi_setApSecurityMFPConfig(INT apIndex, CHAR *MfpConfig)` | - | H | C/T |
| `INT wifi_getApSecurityRadiusServer(INT apIndex, CHAR *IP_output, UINT *Port_output, CHAR *RadiusSecret_output)` | All three pointer parameters | H | C/T; secret output |
| `INT wifi_setApSecurityRadiusServer(INT apIndex, CHAR *IPAddress, UINT port, CHAR *RadiusSecret)` | - | H | C/T; secret input |
| `INT wifi_getApSecuritySecondaryRadiusServer(INT apIndex, CHAR *IP_output, UINT *Port_output, CHAR *RadiusSecret_output)` | All three pointer parameters | H | C/T; secret output |
| `INT wifi_setApSecuritySecondaryRadiusServer(INT apIndex, CHAR *IPAddress, UINT port, CHAR *RadiusSecret)` | - | H | C/T; secret input |
| `INT wifi_getApDASRadiusServer(INT apIndex, CHAR *IP_output, UINT *Port_output, CHAR *RadiusdasSecret_output)` | All three pointer parameters | H | C/T; secret output |
| `INT wifi_setApDASRadiusServer(INT apIndex, CHAR *IPAddress, UINT port, CHAR *RadiusdasSecret)` | - | H | C/T; secret input |
| `INT wifi_enableGreylistAccessControl(BOOL enable)` | - | H | N/T |
| `INT wifi_getApSecurityRadiusSettings(INT apIndex, wifi_radius_setting_t *output)` | `output` | H | C/T |
| `INT wifi_setApSecurityRadiusSettings(INT apIndex, wifi_radius_setting_t *input)` | - | H | C/T |
| `INT wifi_getApWpsConfigurationState(INT apIndex, CHAR *output_string)` | `output_string` | H | C/T |
| `INT wifi_setApWpsEnrolleePin(INT apIndex, CHAR *pin)` | - | H | C/T |
| `INT wifi_setApWpsButtonPush(INT apIndex)` | - | H | N/T |
| `INT wifi_cancelApWPS(INT apIndex)` | - | H | N/T |
| `INT wifi_getApManagementFramePowerControl(INT apIndex, INT *output_dBm)` | `output_dBm` | H | C/T |
| `INT wifi_setApManagementFramePowerControl(INT apIndex, INT dBm)` | - | H | N/T |
| `void wifi_newApAssociatedDevice_callback_register(wifi_newApAssociatedDevice_callback callback_proc)` | - | V | K/T; callback type varies with P2 |
| `void wifi_radiusEapFailure_callback_register(wifi_radiusEapFailure_callback callback_proc)` | - | V | K/T |
| `void wifi_apStatusCode_callback_register(wifi_apStatusCode_callback callback_proc)` | - | V! | K/T |
| `void wifi_ap_stamode_callback_register(wifi_stamode_callback callback_proc)` | - | V! | K/T |
| `void wifi_handshake_callback_register(wifi_handshake_callback callback_proc)` | - | V | K/T; no dedicated registration comment |
| `void wifi_radiusFallback_failover_callback_register(wifi_radiusFallback_failover_callback callback_proc)` | - | V | K/T |
| `void wifi_apDisassociatedDevice_callback_register(wifi_apDisassociatedDevice_callback callback_proc)` | - | V | K/T |
| `void wifi_apDeAuthEvent_callback_register(wifi_apDeAuthEvent_callback callback_proc)` | - | V | K/T |
| `void wifi_apFrameDropUnencrypted_callback_register(wifi_apFrameDropUnencrypted_callback callback_proc)` | - | V | K/T |
| `INT wifi_setInterworkingAccessNetworkType(INT apIndex, INT accessNetworkType)` | - | H | N/T |
| `INT wifi_getInterworkingAccessNetworkType(INT apIndex, UINT *output_uint)` | `output_uint` | H | C/T |
| `INT wifi_getApInterworkingServiceEnable(INT apIndex, BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_setApInterworkingServiceEnable(INT apIndex, BOOL input_bool)` | - | H | N/T |
| `INT wifi_getApInterworkingElement(INT apIndex, wifi_InterworkingElement_t *output_struct)` | `output_struct` | H | C/T |
| `INT wifi_pushApInterworkingElement(INT apIndex, wifi_InterworkingElement_t *infoEelement)` | - | H | C/T |
| `INT wifi_mgmt_frame_callbacks_register(wifi_receivedMgmtFrame_callback mgmtRxCallback)` | - | H | K/T; callback type varies with P2 |
| `void wifi_csi_callback_register(wifi_csi_callback callback_proc)` | - | V | K/T |
| `void wifi_hal_register_frame_hook(wifi_hal_frame_hook_fn_t hook_fn)` | - | V | K/T |
| `INT wifi_enableCSIEngine(INT apIndex, mac_address_t sta, BOOL enable)` | - | H | C/T |
| `INT wifi_sendDataFrame(INT apIndex, mac_address_t sta, UCHAR *data, UINT len, BOOL insert_llc, UINT eth_proto, wifi_data_priority_t prio)` | - | H | C/T; length-bounded input, retention unspecified |
| `INT wifi_sendActionFrame(INT apIndex, mac_address_t sta, UINT frequency, UCHAR *frame, UINT len)` | - | H | C/T |
| `INT wifi_sendActionFrameExt(INT apIndex, mac_address_t sta, UINT frequency, UINT wait, UCHAR *frame, UINT len)` | - | H | C/T; no universal completion guarantee |
| `INT wifi_applyGASConfiguration(wifi_GASConfiguration_t *input_struct)` | - | H | C/T |
| `INT wifi_setCountryIe(INT apIndex, BOOL enabled)` | - | H | N/T |
| `INT wifi_getCountryIe(INT apIndex, BOOL *enabled)` | `enabled` | H | C/T |
| `INT wifi_setLayer2TrafficInspectionFiltering(INT apIndex, BOOL enabled)` | - | H | N/T |
| `INT wifi_getLayer2TrafficInspectionFiltering(INT apIndex, BOOL *enabled)` | `enabled` | H | C/T |
| `INT wifi_setDownStreamGroupAddress(INT apIndex, BOOL disabled)` | - | H | N/T |
| `INT wifi_getDownStreamGroupAddress(INT apIndex, BOOL *disabled)` | `disabled` | H | C/T |
| `INT wifi_setBssLoad(INT apIndex, BOOL enabled)` | - | H | N/T |
| `INT wifi_getBssLoad(INT apIndex, BOOL *enabled)` | `enabled` | H | C/T |
| `INT wifi_setProxyArp(INT apIndex, BOOL enabled)` | - | H | N/T |
| `INT wifi_getProxyArp(INT apIndex, BOOL *enabled)` | `enabled` | H | C/T |
| `INT wifi_pushApHotspotElement(INT apIndex, BOOL enabled)` | - | H | N/T |
| `INT wifi_getApHotspotElement(INT apIndex, BOOL *enabled)` | `enabled` | H | C/T |
| `INT wifi_pushApRoamingConsortiumElement(INT apIndex, wifi_roamingConsortiumElement_t *infoElement)` | - | H | C/T |
| `INT wifi_getApRoamingConsortiumElement(INT apIndex, wifi_roamingConsortiumElement_t *infoElement)` | `infoElement` | H | C/T |
| `INT wifi_setP2PCrossConnect(INT apIndex, BOOL disabled)` | - | H | N/T |
| `INT wifi_getP2PCrossConnect(INT apIndex, BOOL *disabled)` | `disabled` | H | C/T |
| `INT wifi_getTWTsessions(INT ap_index, UINT maxNumberSessions, wifi_twt_sessions_t *twtSessions, UINT *numSessionReturned)` | `twtSessions`, `numSessionReturned` | H | C/T; bounded array |
| `INT wifi_setBroadcastTWTSchedule(INT ap_index, wifi_twt_params_t twtParams, BOOL create, INT *sessionID)` | IO: `sessionID` | H | C/T |
| `INT wifi_setTeardownTWTSession(INT ap_index, INT sessionID)` | - | H | N/T |
| `INT wifi_pushMultiPskKeys(INT apIndex, wifi_key_multi_psk_t *keys, INT keysNumber)` | - | H | C/T; secret input array |
| `INT wifi_getMultiPskKeys(INT apIndex, wifi_key_multi_psk_t *keys, INT keysNumber)` | `keys` | H | C/T; secret output array |
| `INT wifi_getMultiPskClientKey(INT apIndex, mac_address_t mac, wifi_key_multi_psk_t *key)` | `key` | H | C/T; secret output |
| `INT wifi_createVAP(wifi_radio_index_t index, wifi_vap_info_map_t *map)` | - | H | C/T |
| `INT wifi_getRadioVapInfoMap(wifi_radio_index_t index, wifi_vap_info_map_t *map)` | `map` | H | C/T |
| `INT wifi_setApSecurity(INT ap_index, wifi_vap_security_t *security)` | - | H | C/T; secret input |
| `INT wifi_getApSecurity(INT ap_index, wifi_vap_security_t *security)` | `security` | H | C/T; secret output |
| `INT wifi_getAPCapabilities(INT ap_index, wifi_ap_capabilities_t *apCapabilities)` | `apCapabilities` | H | C/T |
| `INT wifi_getApWpsConfiguration(INT ap_index, wifi_wps_t *wpsConfig)` | `wpsConfig` | H | C/T |
| `INT wifi_setApWpsConfiguration(INT ap_index, wifi_wps_t *wpsConfig)` | - | H | C/T |
| `INT wifi_getLibhostapd(BOOL *output_bool)` | `output_bool` | H | C/T |
| `INT wifi_updateLibHostApdConfig(int apIndex)` | - | H | N/T |
| `INT wifi_vapstatus_callback_register(wifi_vapstatus_callback callback)` | - | H | K/T |
| `INT wifi_hal_analytics_callback_register(wifi_analytics_callback callback)` | - | H | K/T |
| `INT wifi_wpsEvent_callback_register(wifi_wpsEvent_callback callback)` | - | H | K/T; one callback, new registration replaces previous |
| `const char *get_vap_ssid(wifi_vap_info_t *vap)` | Returned pointer; parameter direction undocumented | ? | C/T for input storage; returned string ownership, lifetime and null/error behavior unspecified |
| `const char *get_vap_bridge_name(wifi_vap_info_t *vap)` | Returned pointer; parameter direction undocumented | ? | C/T for input storage; returned string ownership, lifetime and null/error behavior unspecified |
| `unsigned int get_vap_security_mode(wifi_vap_info_t *vap, wifi_vap_security_t *sec)` | ?: `vap`, `sec`; direct unsigned result | ? | C/T; result namespace, parameter directions and side effects undocumented |

### Client-Management APIs

Source: [wifi_hal_client_mgt.h](../../include/wifi_hal_client_mgt.h).

| Declaration | Output / in-out parameters | Return | Ownership / thread caveat |
| --- | --- | --- | --- |
| `INT wifi_getBandSteeringEnable(BOOL *enable)` | `enable` | H | C/T |
| `INT wifi_setBandSteeringEnable(BOOL enable)` | - | H | N/T |
| `INT wifi_getBandSteeringApGroup(char *output_ApGroup)` | `output_ApGroup` | H | C/T |
| `INT wifi_setBandSteeringApGroup(char *ApGroup)` | - | R | C/T |
| `INT wifi_getBandSteeringBandUtilizationThreshold(INT radioIndex, INT *pBuThreshold)` | `pBuThreshold` | H | C/T |
| `INT wifi_setBandSteeringBandUtilizationThreshold(INT radioIndex, INT buThreshold)` | - | H | N/T |
| `INT wifi_getBandSteeringRSSIThreshold(INT radioIndex, INT *pRssiThreshold)` | `pRssiThreshold` | H | C/T |
| `INT wifi_setBandSteeringRSSIThreshold(INT radioIndex, INT rssiThreshold)` | - | H | N/T |
| `INT wifi_getBandSteeringPhyRateThreshold(INT radioIndex, INT *pPrThreshold)` | `pPrThreshold` | H | C/T |
| `INT wifi_setBandSteeringPhyRateThreshold(INT radioIndex, INT prThreshold)` | - | H | N/T |
| `INT wifi_getBandSteeringOverloadInactiveTime(INT radioIndex, INT *overloadInactiveTime)` | `overloadInactiveTime` | H | C/T |
| `INT wifi_setBandSteeringOverloadInactiveTime(INT radioIndex, INT overloadInactiveTime)` | - | H | N/T |
| `INT wifi_getBandSteeringIdleInactiveTime(INT radioIndex, INT *idleInactiveTime)` | `idleInactiveTime` | H | C/T |
| `INT wifi_setBandSteeringIdleInactiveTime(INT radioIndex, INT idleInactiveTime)` | - | H | N/T |
| `INT wifi_getBandSteeringLog(INT record_index, ULONG *pSteeringTime, CHAR *pClientMAC, INT *pSourceSSIDIndex, INT *pDestSSIDIndex, INT *pSteeringReason)` | All five pointer parameters | H | C/T |
| `INT wifi_getApAssociatedDevicesHighWatermarkThreshold(INT apIndex, UINT *output)` | `output` | R | C/T |
| `INT wifi_setApAssociatedDevicesHighWatermarkThreshold(INT apIndex, UINT Threshold)` | - | R | N/T |
| `INT wifi_getApAssociatedDevicesHighWatermarkThresholdReached(INT apIndex, UINT *output)` | `output` | R | C/T |
| `INT wifi_getApAssociatedDevicesHighWatermark(INT apIndex, UINT *output)` | `output` | H | C/T |
| `INT wifi_getApAssociatedDevicesHighWatermarkDate(INT apIndex, ULONG *output_in_seconds)` | `output_in_seconds` | H | C/T |
| `INT wifi_setFastBSSTransitionActivated(INT apIndex, UCHAR activate)` | - | H | N/T |
| `INT wifi_getBSSTransitionActivated(INT apIndex, BOOL *activate)` | `activate` | H | C/T |
| `INT wifi_setEAP_Param(UINT apIndex, UINT value, char *param)` | - | R | C/T |
| `INT wifi_getEAP_Param(UINT apIndex, wifi_eap_config_t *output)` | `output` | R | C/T |
| `INT wifi_getFTOverDSActivated(INT apIndex, BOOL *activate)` | `activate` | H | C/T |
| `INT wifi_setFTOverDSActivated(INT apIndex, BOOL *activate)` | - | H | C/T; pointer is input |
| `INT wifi_getFTMobilityDomainID(INT apIndex, UCHAR mobilityDomain[2])` | `mobilityDomain` | H | C/T |
| `INT wifi_setFTMobilityDomainID(INT apIndex, UCHAR mobilityDomain[2])` | - | H | C/T |
| `INT wifi_getFTResourceRequestSupported(INT apIndex, BOOL *supported)` | `supported` | H | C/T |
| `INT wifi_setFTResourceRequestSupported(INT apIndex, BOOL *supported)` | - | H | C/T; pointer is input |
| `INT wifi_getFTR0KeyLifetime(INT apIndex, UINT *lifetime)` | `lifetime` | H | C/T |
| `INT wifi_setFTR0KeyLifetime(INT apIndex, UINT *lifetime)` | - | H | C/T; pointer is input |
| `INT wifi_getFTR0KeyHolderID(INT apIndex, UCHAR *keyHolderID)` | `keyHolderID` | H | C/T |
| `INT wifi_setFTR0KeyHolderID(INT apIndex, UCHAR *keyHolderID)` | - | H | C/T |
| `INT wifi_getFTR1KeyHolderID(INT apIndex, UCHAR *keyHolderID)` | `keyHolderID` | H | C/T |
| `INT wifi_setFTR1KeyHolderID(INT apIndex, UCHAR *keyHolderID)` | - | H | C/T |
| `INT wifi_pushApFastTransitionConfig(INT apIndex, wifi_FastTransitionConfig_t *ftData)` | - | H | C/T |
| `INT wifi_setBSSTransitionActivation(UINT apIndex, BOOL activate)` | - | R | N/T |
| `INT wifi_getBSSTransitionActivation(UINT apIndex, BOOL *activate)` | `activate` | H | C/T |
| `INT wifi_setNeighborReportActivation(UINT apIndex, BOOL activate)` | - | R | N/T |
| `INT wifi_getNeighborReportActivation(UINT apIndex, BOOL *activate)` | `activate` | H | C/T |

### Extender and Steering APIs

Source: [wifi_hal_extender.h](../../include/wifi_hal_extender.h).

| Declaration | Output / in-out parameters | Return | Ownership / thread caveat |
| --- | --- | --- | --- |
| `INT wifi_getRadioChannelStats(INT radioIndex, wifi_channelStats_t *input_output_channelStats_array, INT array_size)` | IO: `input_output_channelStats_array` | H | C/T; zero-size ONCHAN mode is described in the header |
| `INT wifi_getApAssociatedDeviceRxStatsResult(INT radioIndex, mac_address_t *clientMacAddress, wifi_associated_dev_rate_info_rx_stats_t **stats_array, UINT *output_array_size, ULLONG *handle)` | `stats_array`, `output_array_size`, `handle` | H | F/T |
| `INT wifi_getApAssociatedDeviceTxStatsResult(INT radioIndex, mac_address_t *clientMacAddress, wifi_associated_dev_rate_info_tx_stats_t **stats_array, UINT *output_array_size, ULLONG *handle)` | `stats_array`, `output_array_size`, `handle` | H | F/T |
| `INT wifi_getApAssociatedDeviceTidStatsResult(INT radioIndex, mac_address_t *clientMacAddress, wifi_associated_dev_tid_stats_t *tid_stats, ULLONG *handle)` | `tid_stats`; ?: `handle` annotated input | H | C/T |
| `INT wifi_getApAssociatedDeviceStats(INT apIndex, mac_address_t *clientMacAddress, wifi_associated_dev_stats_t *associated_dev_stats, ULLONG *handle)` | `associated_dev_stats`; ?: `handle` annotated input | H | C/T |
| `INT wifi_getSSIDRadioIndex(INT ssidIndex, INT *radioIndex)` | `radioIndex` | H | C/T |
| `INT wifi_applySSIDSettings(INT ssidIndex)` | - | H | N/T |
| `INT wifi_startNeighborScan(INT apIndex, wifi_neighborScanMode_t scan_mode, INT dwell_time, UINT chan_num, UINT *chan_list)` | - | H | C/T |
| `INT wifi_setApCsaDeauth(INT apIndex, INT mode)` | - | H | N/T |
| `INT wifi_setApScanFilter(INT apIndex, INT mode, CHAR *essid)` | - | H | C/T; special AP index -1 described by header |
| P2: `INT wifi_steering_setGroup(UINT steeringGroupIndex, UINT numElements, wifi_steering_apConfig_t *cfgArray)` | - | R | C/T; retention unspecified |
| `void wifi_steerTriggered_callback_register(wifi_steerTriggered_callback callback_proc, CHAR *module)` | - | V | K/T; module-string retention unspecified |
| `INT wifi_steering_eventRegister(wifi_steering_eventCB_t event_cb)` | - | R | K/T |
| `INT wifi_steering_eventUnregister(void)` | - | R | K/T; in-flight drain unspecified |
| `INT wifi_steering_clientSet(UINT steeringgroupIndex, INT apIndex, mac_address_t client_mac, wifi_steering_clientConfig_t *config)` | - | R | C/T |
| `INT wifi_steering_clientRemove(UINT steeringgroupIndex, INT apIndex, mac_address_t client_mac)` | - | R | C/T |
| `INT wifi_steering_clientMeasure(UINT steeringgroupIndex, INT apIndex, mac_address_t client_mac)` | - | R | C/T; RSSI measurement request |
| `INT wifi_steering_clientDisconnect(UINT steeringgroupIndex, INT apIndex, mac_address_t client_mac, wifi_disconnectType_t type, UINT reason)` | - | R | C/T |
| `INT wifi_BTMQueryRequest_callback_register(UINT apIndex, wifi_BTMQueryRequest_callback btmQueryCallback, wifi_BTMResponse_callback btmResponseCallback)` | - | H | K/T; callback MAC types vary with P2 |
| P2: `INT wifi_setBTMRequest(UINT apIndex, mac_address_t peerMac, wifi_BTMRequest_t *request)` | - | H | C/T |
| `INT wifi_RMBeaconRequestCallbackRegister(UINT apIndex, wifi_RMBeaconReport_callback beaconReportCallback)` | - | H | K/T |
| `INT wifi_RMBeaconRequestCallbackUnregister(UINT apIndex, wifi_RMBeaconReport_callback beaconReportCallback)` | - | H | K/T; in-flight drain unspecified |
| `INT wifi_cancelRMBeaconRequest(UINT apIndex, UCHAR dialogToken)` | - | H | N/T |
| P2: `INT wifi_setRMBeaconRequest(UINT apIndex, mac_address_t peer, wifi_BeaconRequest_t *in_request, UCHAR *out_DialogToken)` | `out_DialogToken` | R | C/T |
| P2: `INT wifi_getRMCapabilities(mac_address_t peer, UCHAR out_Capabilities[5])` | `out_Capabilities` | H | C/T |

### Deprecated Public APIs

Source: [wifi_hal_deprecated.h](../../include/wifi_hal_deprecated.h). These declarations are included by `wifi_hal.h`; their placement is not evidence of implementation removal. `!P2` entries are alternatives to newer signatures, not overloads available in the same C translation unit. For copied or missing parameter annotations, the result column explicitly flags uncertainty rather than rewriting the header.

| Declaration | Output / in-out parameters | Return | Ownership / thread caveat |
| --- | --- | --- | --- |
| `INT wifi_getTWTParams(CHAR *sta, wifi_twt_params_t *twt_params)` | ?: `twt_params` | ? | C/T |
| `INT wifi_setBSSColorEnabled(INT apIndex, BOOL enabled)` | - | ? | N/T |
| `INT wifi_getBSSColorEnabled(INT apIndex, BOOL *enabled)` | ?: `enabled` | ? | C/T |
| `INT wifi_getRadioChannelStats2(INT radioIndex, wifi_channelStats2_t *outputChannelStats2)` | ?: `outputChannelStats2` | ? | C/T |
| `INT wifi_getHalVersion(CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_getRadioCountryCode(INT radioIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_setRadioCountryCode(INT radioIndex, CHAR *CountryCode)` | - | R | C/T |
| `INT wifi_pushCountryCode(CHAR *CountryCode)` | - | R | C/T |
| `INT wifi_getATMCapable(BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_setATMEnable(BOOL enable)` | - | R | N/T |
| `INT wifi_getATMEnable(BOOL *output_enable)` | `output_enable` | R | C/T |
| `INT wifi_setApATMAirTimePercent(INT apIndex, UINT ap_AirTimePercent)` | - | R | N/T |
| `INT wifi_getApATMAirTimePercent(INT apIndex, UINT *output_ap_AirTimePercent)` | `output_ap_AirTimePercent` | R | C/T |
| `INT wifi_setApATMSta(INT apIndex, UCHAR *sta_MAC, UINT sta_AirTimePercent)` | - | R | C/T |
| `INT wifi_getApATMSta(INT apIndex, UCHAR *output_sta_MAC_ATM_array, UINT buf_size)` | `output_sta_MAC_ATM_array`; size is a value | R | C/T |
| `INT wifi_getRadioNumberOfEntries(ULONG *output)` | `output` | R | C/T |
| `INT wifi_getSSIDNumberOfEntries(ULONG *output)` | `output` | R | C/T |
| `INT wifi_getRadioMaxBitRate(INT radioIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_getRadioSupportedFrequencyBands(INT radioIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_getRadioOperatingFrequencyBand(INT radioIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_getRadioSupportedStandards(INT radioIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_getRadioStandard(INT radioIndex, CHAR *output_string, BOOL *gOnly, BOOL *nOnly, BOOL *acOnly)` | All four pointer parameters | R | C/T |
| `INT wifi_getRadioMode(INT radioIndex, CHAR *output_string, UINT *pureMode)` | `output_string`, `pureMode` | R | C/T |
| `INT wifi_setRadioChannelMode(INT radioIndex, CHAR *channelMode, BOOL gOnlyFlag, BOOL nOnlyFlag, BOOL acOnlyFlag)` | - | R | C/T |
| `INT wifi_setRadioMode(INT radioIndex, CHAR *channelMode, UINT pureMode)` | - | R | C/T |
| `INT wifi_getRadioPossibleChannels(INT radioIndex, CHAR *output_string)` | `output_string` | R | C/T |
| !P2: `INT wifi_getRadioChannelsInUse(INT radioIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_getRadioChannel(INT radioIndex, ULONG *output_ulong)` | `output_ulong` | R | C/T |
| `INT wifi_setRadioChannel(INT radioIndex, ULONG channel)` | - | R | N/T |
| `INT wifi_setRadioAutoChannelEnable(INT radioIndex, BOOL enable)` | - | R | N/T |
| `INT wifi_getRadioAutoChannelSupported(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_getRadioAutoChannelEnable(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_getRadioDCSSupported(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_getRadioDCSEnable(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_setRadioDCSEnable(INT radioIndex, BOOL enable)` | ?: scalar `enable` is incorrectly labeled output | R | N/T |
| `INT wifi_getRadioDCSChannelPool(INT radioIndex, CHAR *output_pool)` | `output_pool` | R | C/T |
| `INT wifi_setRadioDCSChannelPool(INT radioIndex, CHAR *pool)` | - | R | C/T |
| `INT wifi_getRadioDCSScanTime(INT radioIndex, INT *output_interval_seconds, INT *output_dwell_milliseconds)` | Both output pointers | R | C/T |
| `INT wifi_setRadioDCSScanTime(INT radioIndex, INT interval_seconds, INT dwell_milliseconds)` | - | R | N/T |
| `INT wifi_setRadioDcsDwelltime(INT radioIndex, INT millisecond)` | - | R | N/T |
| `INT wifi_getRadioDcsDwelltime(INT radioIndex, INT *output_millisecond)` | ?: `output_millisecond` is labeled input | R | C/T |
| `INT wifi_setRadioDcsScanning(INT radioIndex, BOOL enable)` | - | R | N/T |
| `INT wifi_getRadioDcsScanning(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_getRadioDcsChannelMetrics(INT radioIndex, wifi_channelMetrics_t *input_output_channelMetrics_array, INT array_size)` | ?: input/output array is labeled output; size is a value | R | C/T |
| `INT wifi_pushRadioChannel(INT radioIndex, UINT channel)` | - | R | N/T |
| `INT wifi_pushRadioChannel2(INT radioIndex, UINT channel, UINT channel_width_MHz, UINT csa_beacon_count)` | - | R | N/T |
| `INT wifi_getRadioDfsSupport(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_getRadioAutoChannelRefreshPeriodSupported(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_getRadioAutoChannelRefreshPeriod(INT radioIndex, ULONG *output_ulong)` | `output_ulong` | R | C/T |
| `INT wifi_setRadioAutoChannelRefreshPeriod(INT radioIndex, ULONG seconds)` | - | R | N/T |
| `INT wifi_getRadioOperatingChannelBandwidth(INT radioIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_setRadioOperatingChannelBandwidth(INT radioIndex, CHAR *bandwidth)` | - | R | C/T |
| `INT wifi_getRadioExtChannel(INT radioIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_setRadioExtChannel(INT radioIndex, CHAR *string)` | - | R | C/T |
| `INT wifi_getRadioGuardInterval(INT radioIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_setRadioGuardInterval(INT radioIndex, CHAR *string)` | - | R | C/T |
| `INT wifi_getRadioTransmitPowerSupported(INT radioIndex, CHAR *output_list)` | `output_list` | R | C/T |
| `INT wifi_getRadioIEEE80211hSupported(INT radioIndex, BOOL *Supported)` | `Supported` | R | C/T |
| `INT wifi_getRadioIEEE80211hEnabled(INT radioIndex, BOOL *enable)` | `enable` | R | C/T |
| `INT wifi_setRadioIEEE80211hEnabled(INT radioIndex, BOOL enable)` | - | R | N/T |
| `INT wifi_getRadioBeaconPeriod(INT radioIndex, UINT *output)` | `output` | R | C/T |
| `INT wifi_setRadioBeaconPeriod(INT radioIndex, UINT BeaconPeriod)` | - | R | N/T |
| `INT wifi_getRadioSupportedDataTransmitRates(INT radioIndex, char *output_rates)` | `output_rates` | R | C/T |
| `INT wifi_getRadioBasicDataTransmitRates(INT radioIndex, CHAR *output)` | `output` | R | C/T |
| `INT wifi_setRadioBasicDataTransmitRates(INT radioIndex, CHAR *TransmitRates)` | - | R | C/T |
| `INT wifi_getRadioOperationalDataTransmitRates(INT radioIndex, char *output_rates)` | `output_rates` | R | C/T |
| `INT wifi_setRadioOperationalDataTransmitRates(INT radioIndex, char *rates)` | ?: `rates` is labeled output in this setter | R | C/T |
| `INT wifi_setRadioTrafficStatsMeasure(INT radioIndex, wifi_radioTrafficStatsMeasure_t *input_struct)` | - | R | C/T |
| `INT wifi_setRadioTrafficStatsRadioStatisticsEnable(INT radioIndex, BOOL enable)` | ?: scalar `enable` is labeled output | R | N/T |
| `INT wifi_getRadioStatsReceivedSignalLevel(INT radioIndex, INT signalIndex, INT *SignalLevel)` | ?: `SignalLevel` lacks matching parameter annotation | R | C/T |
| `INT wifi_getSSIDEnable(INT ssidIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_setSSIDEnable(INT ssidIndex, BOOL enable)` | - | R | N/T |
| `INT wifi_getSSIDStatus(INT ssidIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_getSSIDName(INT apIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_getSSIDNameStatus(INT apIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_setSSIDName(INT apIndex, CHAR *ssid_string)` | ?: setter string is labeled output | R | C/T |
| `INT wifi_getBaseBSSID(INT ssidIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_getSSIDMACAddress(INT ssidIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_getNeighboringWiFiDiagnosticResult2(INT radioIndex, wifi_neighbor_ap2_t **neighbor_ap_array, UINT *output_array_size)` | `neighbor_ap_array`, `output_array_size` | R | L/T |
| !P2: `INT wifi_getNeighboringWiFiStatus(INT radioIndex, wifi_neighbor_ap2_t **neighbor_ap_array, UINT *output_array_size)` | `neighbor_ap_array`, `output_array_size` | R | A/T |
| `INT wifi_getSSIDTrafficStats(INT ssidIndex, wifi_ssidTrafficStats_t *output_struct)` | ?: `output_struct` | ? | C/T |
| `INT wifi_getBasicTrafficStats(INT apIndex, wifi_basicTrafficStats_t *output_struct)` | ?: `output_struct` | ? | C/T |
| `INT wifi_getNeighboringWiFiDiagnosticResult(wifi_neighbor_ap_t **neighbor_ap_array, UINT *output_array_size)` | ?: `neighbor_ap_array`, `output_array_size` | ? | A/T |
| `INT wifi_getAllAssociatedDeviceDetail(INT apIndex, ULONG *output_ulong, wifi_device_t **output_struct)` | ?: both pointer parameters | ? | A/T |
| `INT wifi_getBandSteeringCapability(BOOL *support)` | `support` | R | C/T |
| !P2: `INT wifi_getApAssociatedDevice(INT ap_index, CHAR *output_buf, INT output_buf_size)` | `output_buf`; size is a value | R | C/T |
| `INT wifi_getApDeviceRSSI(INT ap_index, CHAR *MAC, INT *output_RSSI)` | `output_RSSI`; ?: MAC also labeled output | R | C/T |
| `INT wifi_getApDeviceRxrate(INT ap_index, CHAR *MAC, INT *output_RxMb)` | ?: `output_RxMb` annotation is misspelled | R | C/T |
| `INT wifi_getApDeviceTxrate(INT ap_index, CHAR *MAC, INT *output_TxMb)` | `output_TxMb` | R | C/T |
| `INT wifi_getRadioTxChainMask(INT radioIndex, INT *output_int)` | `output_int` | R | C/T |
| `INT wifi_setRadioTxChainMask(INT radioIndex, INT numStreams)` | - | R | N/T |
| `INT wifi_getRadioRxChainMask(INT radioIndex, INT *output_int)` | `output_int` | R | C/T |
| `INT wifi_setRadioRxChainMask(INT radioIndex, INT numStreams)` | - | R | N/T |
| `INT wifi_pushRadioChannelMode(INT radioIndex)` | - | ? | N/T |
| `INT wifi_pushRadioTxChainMask(INT radioIndex)` | - | ? | N/T |
| `INT wifi_pushRadioRxChainMask(INT radioIndex)` | - | ? | N/T |
| `INT wifi_pushSSID(INT apIndex, CHAR *ssid)` | - | R | C/T |
| `INT wifi_pushSsidAdvertisementEnable(INT apIndex, BOOL enable)` | - | R | N/T |
| `INT wifi_getRadioReverseDirectionGrantEnable(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_setRadioReverseDirectionGrantEnable(INT radioIndex, BOOL enable)` | - | R | N/T |
| `INT wifi_getRadioDeclineBARequestEnable(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_setRadioDeclineBARequestEnable(INT radioIndex, BOOL enable)` | - | R | N/T |
| `INT wifi_getRadio11nGreenfieldSupported(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_getRadio11nGreenfieldEnable(INT radioIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_setRadio11nGreenfieldEnable(INT radioIndex, BOOL enable)` | - | R | N/T |
| `INT wifi_createAp(INT apIndex, INT radioIndex, CHAR *essid, BOOL hideSsid)` | - | R | C/T |
| `INT wifi_getApIndexFromName(CHAR *inputSsidString, INT *ouput_int)` | `ouput_int` | R | C/T; spelling retained |
| `INT wifi_setApDTIMInterval(INT apIndex, INT dtimInterval)` | - | R | N/T |
| `INT wifi_getApBeaconType(INT apIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_setApBeaconType(INT apIndex, CHAR *beaconTypeString)` | - | R | C/T |
| `INT wifi_setApBeaconInterval(INT apIndex, INT beaconInterval)` | - | R | N/T |
| `INT wifi_getApRtsThresholdSupported(INT apIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_getApWpaEncryptionMode(INT apIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_setApWpaEncryptionMode(INT apIndex, CHAR *encMode)` | - | R | C/T |
| `INT wifi_setApAuthMode(INT apIndex, INT mode)` | - | R | N/T |
| `INT wifi_setApBasicAuthenticationMode(INT apIndex, CHAR *authMode)` | - | R | C/T |
| !P2: `INT wifi_kickApAssociatedDevice(INT apIndex, CHAR *client_mac)` | - | R | C/T; textual MAC |
| `INT wifi_setApRadioIndex(INT apIndex, INT radioIndex)` | - | R | N/T |
| !P2: `INT wifi_getApAclDevices(INT apIndex, CHAR *macArray, UINT buf_size)` | `macArray`; size is a value | R | C/T |
| !P2: `INT wifi_addApAclDevice(INT apIndex, CHAR *DeviceMacAddress)` | - | R | C/T |
| !P2: `INT wifi_delApAclDevice(INT apIndex, CHAR *DeviceMacAddress)` | - | R | C/T |
| `INT wifi_setApVlanEnable(INT apIndex, BOOL VlanEnabled)` | - | R | N/T |
| `INT wifi_getApBridgeInfo(INT index, CHAR *bridgeName, CHAR *IP, CHAR *subnet)` | All three string pointers | R | C/T |
| `INT wifi_setApBridgeInfo(INT apIndex, CHAR *bridgeName, CHAR *IP, CHAR *subnet)` | - | R | C/T |
| `INT wifi_pushBridgeInfo(INT apIndex)` | - | ? | N/T; no dedicated parameter or return comment |
| `INT wifi_pushApEnable(INT apIndex, BOOL Enable)` | - | R | N/T |
| `INT wifi_pushApSsidAdvertisementEnable(INT apIndex, BOOL enable)` | - | R | N/T |
| `INT wifi_getApWMMCapability(INT apIndex, BOOL *output)` | `output` | R | C/T |
| `INT wifi_getApUAPSDCapability(INT apIndex, BOOL *output)` | `output` | R | C/T |
| `INT wifi_getApSecurityModesSupported(INT apIndex, CHAR *output)` | `output` | R | C/T |
| `INT wifi_getApSecurityModeEnabled(INT apIndex, CHAR *output)` | `output` | R | C/T |
| `INT wifi_setApSecurityModeEnabled(INT apIndex, CHAR *encMode)` | - | R | C/T |
| `INT wifi_getApSecurityPreSharedKey(INT apIndex, CHAR *output_string)` | `output_string` | R | C/T; secret output |
| `INT wifi_setApSecurityPreSharedKey(INT apIndex, CHAR *preSharedKey)` | - | R | C/T; secret input |
| `INT wifi_getApSecurityKeyPassphrase(INT apIndex, CHAR *output_string)` | `output_string` | R | C/T; secret output |
| `INT wifi_setApSecurityKeyPassphrase(INT apIndex, CHAR *passPhrase)` | - | R | C/T; secret input |
| `INT wifi_getApWpsEnable(INT apIndex, BOOL *output_bool)` | `output_bool` | R | C/T |
| `INT wifi_setApWpsEnable(INT apIndex, BOOL enableValue)` | - | R | N/T |
| `INT wifi_getApWpsConfigMethodsSupported(INT apIndex, CHAR *output)` | `output` | R | C/T |
| `INT wifi_getApWpsConfigMethodsEnabled(INT apIndex, CHAR *output_string)` | `output_string` | R | C/T |
| `INT wifi_setApWpsConfigMethodsEnabled(INT apIndex, CHAR *methodString)` | - | R | C/T |
| `INT wifi_getApWpsDevicePIN(INT apIndex, ULONG *output_ulong)` | ?: `output_ulong` is labeled input | R | C/T |
| `INT wifi_setApWpsDevicePIN(INT apIndex, ULONG pin)` | - | R | N/T |
| `INT wifi_getApAssociatedDeviceDiagnosticResult(INT apIndex, wifi_associated_dev_t **associated_dev_array, UINT *output_array_size)` | Arrays/count described as results but annotated input | R | L/T |
| `INT wifi_getApAssociatedDeviceDiagnosticResult2(INT apIndex, wifi_associated_dev2_t **associated_dev_array, UINT *output_array_size)` | Arrays/count described as results but annotated input | R | L/T |
| !P2: `INT wifi_getApAssociatedClientDiagnosticResult(INT apIndex, char *mac_addr, wifi_associated_dev3_t *dev_conn)` | ?: `dev_conn`; no dedicated parameter comment | ? | C/T; nested CSI lifetime unresolved |
| `extern BOOL wifi_steering_supported(void)` | Direct Boolean result | B | N/T; true if steering APIs supported, false otherwise |
| !P2: `INT wifi_steering_setGroup(UINT steeringgroupIndex, wifi_steering_apConfig_t *cfg_2, wifi_steering_apConfig_t *cfg_5)` | - | R | C/T; HAL stores configs; both null remove group |
| `void wifi_apAuthEvent_callback_register(wifi_apAuthEvent_callback callback_proc)` | - | V | K/T |
| `INT wifi_getApAuthenticatedDevices(INT apIndex, mac_t **mac_array, UINT *output_array_size)` | ?: `mac_array`, `output_array_size` | ? | A/T |
| `void wifi_apAuthenticatedEvent_callback_register(wifi_apAuthEvent_callback callback_proc)` | - | V | K/T; typedef mismatch noted above |
| `void wifi_apAssociatedDevice_callback_register(wifi_apAssociatedDevice_callback callback_proc)` | - | V | K/T |
| `INT wifi_getRadioClientInactivityTimout(INT radioIndex, INT *output_timout_sec)` | ?: `output_timout_sec` | ? | C/T; spelling retained |
| `INT wifi_getApInterworkingServiceCapability(INT apIndex, BOOL *output_bool)` | ?: `output_bool` is labeled input | R | C/T |
| !P2: `INT wifi_setBTMRequest(UINT apIndex, CHAR *peerMac, wifi_BTMRequest_t *request)` | - | R | C/T |
| `INT wifi_getBSSTransitionImplemented(UINT apIndex, BOOL *activate)` | ?: `activate` | R | C/T |
| `INT wifi_getBTMClientCapabilityList(UINT apIndex, wifi_BTMCapabilities_t *extBTMCapabilities)` | ?: `extBTMCapabilities` | R | C/T |
| `INT wifi_setNeighborReports(UINT apIndex, UINT numNeighborReports, wifi_NeighborReport_t *neighborReports)` | - | R | C/T |
| !P2: `INT wifi_setRMBeaconRequest(UINT apIndex, CHAR *peer, wifi_BeaconRequest_t *in_request, UCHAR *out_DialogToken)` | `out_DialogToken`; direction tag omitted | R | C/T |
| !P2: `INT wifi_getRMCapabilities(CHAR *peer, UCHAR out_Capabilities[5])` | `out_Capabilities`; direction tag omitted | R | C/T |
| `INT wifi_dppSetSTAPassphrase(UINT apIndex, CHAR *sta, CHAR *key)` | - | R | C/T; secret input |
| `INT wifi_dppRemoveSTAPassphrase(UINT apIndex, CHAR *sta)` | - | R | C/T |
| `INT wifi_getRadioChannels(INT radioIndex, wifi_channelMap_t *output_map, INT output_map_size)` | `output_map` | R | C/T; caller-preallocated array |
| `INT wifi_dppInitiate(wifi_device_dpp_context_t *ctx)` | ?: context mutation/retention not fully defined | R | C/T |
| `INT wifi_dppCancel(wifi_device_dpp_context_t *ctx)` | ?: context mutation/retention not fully defined | R | C/T |
| `int mgmt_frame_received_callback(INT ap_index, mac_address_t sta_mac, UCHAR *frame, UINT len, wifi_mgmtFrameType_t type, wifi_direction_t dir)` | - | ? | C/T; ordinary declared function, not a typedef |
| `INT wifi_dpp_frame_received_callbacks_register(wifi_dppAuthResponse_callback_t dppAuthCallback, wifi_dppConfigRequest_callback_t dppConfigCallback, wifi_dppConfigResult_callback_t dppConfigResultCallback, wifi_dppReconfigAnnounce_callback_t dppReconfigAnnounceCallback, wifi_dppReconfigAuthResponse_callback_t dppReconfigAuthRspCallback)` | - | R | K/T |
| `INT wifi_dppSendAuthCnf(wifi_device_dpp_context_t *ctx)` | ?: context mutation/retention not fully defined | R | C/T |
| `INT wifi_dppSendConfigResponse(wifi_device_dpp_context_t *ctx)` | ?: context mutation/retention not fully defined | R | C/T |
| `INT wifi_anqp_request_callback_register(wifi_anqp_request_callback_t callback)` | - | ? | K/T |
| `INT wifi_anqpSendResponse(UINT apIndex, mac_address_t sta, unsigned char token, wifi_anqp_node_t *list)` | ?: `list` mutation/consumption | ? | C/T; nested list retention/release unspecified |
| `INT wifi_chan_eventRegister(wifi_chan_eventCB_t event_cb)` | - | ? | K/T |
| `INT wifi_isZeroDFSSupported(UINT radioIndex, BOOL *supported)` | `supported` | R | C/T |

### Emulator Declaration Cross-Reference

The alternative [wifi_hal_emu.h](../../include/wifi_hal_emu.h) contains 257 function-declaration occurrences, representing 253 distinct textual declarations. Of these, 199 occurrences match 198 distinct complete declarations in the preceding main-header tables. The remaining 58 occurrences represent the 55 declarations listed in the next table. These comparisons ignore whitespace but preserve return types, formal parameter types and parameter spellings.

| Main-header table containing matching emulator declarations | Matching emulator declaration occurrences |
| --- | --- |
| Generic subsystem APIs | 9 |
| Radio APIs | 28 |
| AP and VAP APIs | 41 |
| Telemetry APIs | 2 |
| Client-management APIs | 5 |
| Extender and steering APIs | 2 |
| Deprecated public APIs | 112 |

For the shared declarations, the complete formal parameters and ordinary result positions are already recorded in the referenced tables. This cross-reference does not assert that every main-header API exists in the emulator. Use the emulator header to select its declared subset and its older type layouts. Its textual-MAC declarations are not controlled by the main header's phase-2 selection.

The emulator's integer-status comments specify `H`, including shared legacy functions whose main-header comments specify `R` or omit return codes. Its shared `wifi_newApAssociatedDevice_callback_register` and `wifi_apAuthEvent_callback_register` return `V`. All retain the global `T` caveat. Callback registrations retain `K`; caller-provided ordinary storage has no declared transfer. Emulator `wifi_getNeighboringWiFiDiagnosticResult2` and `wifi_getApAssociatedDeviceDiagnosticResult` explicitly describe HAL-allocated arrays without defining release (`L`). Other returned arrays do not automatically acquire caller-free semantics (`A`). The emulator's status comments use macro names that it does not itself define as a complete modern error family.

### Emulator-Specific Declarations and Spelling Variants

The following complete declarations use the emulator's own types. Their presence is not a promise about a production vendor HAL or daemon architecture. `checkWifi` returns true when hostapd is running; `checkLanInterface` returns true when wlan0 is up. `wifi_getApIndexForWiFiBand` returns an AP index directly, not an ordinary success status, and its error range is unspecified.

| Declaration | Output / in-out parameters | Return | Ownership / thread caveat |
| --- | --- | --- | --- |
| `INT wifi_setRadioDfsEnable(INT radioIndex, BOOL enable)` | - | H | N/T; main spells the parameter `enabled` |
| `INT wifi_getApWpaEncryptoinMode(INT apIndex, CHAR *output_string)` | `output_string` | H | C/T; comment specifies maximum length 32 bytes |
| `INT wifi_setApWmmOgAckPolicy(INT apIndex, INT class, BOOL ackPolicy)` | - | H | N/T; main uses `cla`, avoiding the C++ keyword |
| `void KillHostapd()` | - | V | N/T |
| `BOOL checkWifi()` | Direct hostapd-running test | B | N/T |
| `BOOL checkLanInterface()` | Direct wlan0-up test | B | N/T |
| `INT CcspHal_change_config_value(char *field_name, char *field_value, char *buf, unsigned int *nbytes)` | `buf`; IO: `nbytes` | Z | C/T |
| `int do_MacFilter_Addrule()` | - | H | N/T |
| `int do_MacFilter_Delrule()` | - | H | N/T |
| `int do_MacFilter_Update(char *Operation, int i_macFiltCnt, COSA_DML_WIFI_AP_MAC_FILTER *i_macFiltTabPtr, int count, struct hostDetails *hostPtr)` | - | H | C/T |
| `INT wifi_getApIndexForWiFiBand(wifi_band band)` | Direct AP-index result | ? | N/T; invalid-band/error behavior unspecified |
| `void wlan_encryption_mode_to_string(char *encryption_mode, char *string)` | `string` | V | C/T |
| `INT File_Reading(CHAR *file, char *Value)` | `Value` | H | C/T |
| `void wlan_wireless_mode_to_supported_standards_string(char *wireless_mode, char *string, char *freq)` | `string` | V | C/T |
| `void wlan_bitrate_to_operated_standards_string(char *bitrate, char *string, char *freq)` | `string` | V | C/T |
| `void wlan_operated_standards_to_channel_bandwidth_string(char *wireless_mode, char *string)` | `string` | V | C/T |
| `INT Hostapd_PublicWifi_status(char status[50])` | `status` | H | C/T |
| `INT Hostapd_PrivateWifi_status(char status[50])` | `status` | H | C/T |
| `INT GetInterfaceName(char interface_name[50], char conf_file[100])` | `interface_name` | H | C/T |
| `INT GetInterfaceName_virtualInterfaceName_2G(char interface_name[50])` | `interface_name` | H | C/T |
| `void RestartHostapd()` | - | V | N/T |
| `void xfinitywifi_2g(int ssidIndex)` | - | V | N/T |
| `void privatewifi_2g(int ssidIndex)` | - | V | N/T |
| `void KillHostapd_2g(int ssidIndex)` | - | V | N/T |
| `void KillHostapd_xfinity_2g(int ssidIndex)` | - | V | N/T |
| `void xfinitywifi_5g(int ssidIndex)` | - | V | N/T |
| `void privatewifi_5g(int ssidIndex)` | - | V | N/T |
| `void KillHostapd_5g(int ssidIndex)` | - | V | N/T |
| `void KillHostapd_xfinity_5g(int ssidIndex)` | - | V | N/T |
| `INT killXfinityWiFi()` | - | H | N/T |
| `void defaultwifi_restarting_process()` | - | V | N/T |
| `int hostapd_restarting_process(int apIndex)` | - | H | N/T |
| `void get_mac(unsigned char *mac)` | `mac` | V | C/T |
| `INT GettingHostapdSsid(INT ssidIndex, char *hostapd_conf, char *val)` | `val` | H | C/T |
| `void DisableWifi(int InstanceNumber)` | - | V | N/T |
| `int wifi_hostapdRead(int ap, struct params *params, char *output)` | `output` | H | C/T |
| `int wifi_hostapdWrite(int ap, param_list_t *list)` | - | H | C/T |
| `INT get_wifiMaxbitrate(int radioIndex, char *output_string)` | `output_string` | H | C/T |
| `void wifi_updateRadiochannel(INT radioIndex, ULONG channel)` | - | V | N/T |
| `INT wifi_setAutoChannelEnableVal(INT radioIndex, ULONG channel)` | - | H | N/T |
| `void wifi_storeprevchanval(INT radioIndex)` | - | V | N/T |
| `INT wifi_halgetRadioChannelBW(CHAR *file, CHAR *Value)` | `Value` | H | C/T |
| `INT wifi_halsetRadioChannelBW_40(char *file)` | - | H | C/T |
| `INT wifi_halsetRadioChannelBW_20(char *file)` | - | H | C/T |
| `INT wifi_halgetRadioExtChannel(CHAR *file, CHAR *Value)` | `Value` | H | C/T |
| `INT wifi_halGetIfStats(char *ifname, wifi_radioTrafficStats2_t *pStats)` | `pStats` | H | C/T |
| `INT GetIfacestatus(CHAR *interface_name, CHAR *status)` | `status` | H | C/T |
| `INT wifi_halGetIfStatsNull(wifi_radioTrafficStats2_t *output_struct)` | `output_struct` | H | C/T |
| `INT wifihal_getBaseBSSID(CHAR *interface_name, CHAR *mac, INT index)` | `mac` | H | C/T |
| `int GetScanningValues(char *file, char *value)` | `value` | H | C/T |
| `void converting_lowercase_to_uppercase(char *Value)` | IO: `Value` | V | C/T |
| `void wifihal_GettingNeighbouringAPScanningDetails(char *interface_name, wifi_neighbor_ap2_t **neighbor_ap_array, UINT *output_array_size)` | `neighbor_ap_array`, `output_array_size` | V | A/T |
| `INT SetWPSButton(char *interface_name)` | - | H | C/T |
| `INT wifihal_AssociatedDevicesstats(INT apIndex, CHAR *interface_name, wifi_associated_dev_t **associated_dev_array, UINT *output_array_size)` | `associated_dev_array`, `output_array_size` | H | A/T |
| `int wifihal_interfacestatus(CHAR *wifi_status, CHAR *interface_name)` | `wifi_status` | H | C/T |

The emulator repeats declarations of `wifi_setRadioAutoChannelEnable`, `KillHostapd`, `checkWifi` and `checkLanInterface`. Each operation is documented once; repeated declarations do not create another API. The helpers do not establish universal buffer capacities, safe process-restart behavior, filesystem transactions, callback draining or synchronization guarantees.

## Inventory Provenance and Verification Limits

The recursive source inventory contains ten public headers and 692 function-declaration occurrences before preprocessor-branch selection: 435 from the main umbrella's constituent headers and 257 from the alternative emulator. They represent 490 distinct textual declarations when whitespace is ignored but formal parameter spellings and return types are retained. These are documentation counts, not 490 simultaneously available operations or distinct C ABI signatures.

The type inventory covers 339 typedef occurrences, including 51 callback-typedef occurrences across conditional branches and repeated emulator definitions. Function extraction includes `extern`, pointer-returning and multiword-return declarations; comment-only prototypes are excluded. Struct tags are mapped to their typedef names rather than counted as additional records.

Architecture and lifecycle diagrams describe integration intent. The conceptual `wifi_hal_init` and `wifi_hal_deinit` labels are not introduced as new APIs. Header inspection and documentation validation do not establish vendor implementation correctness, hardware conformance, RF behavior, thread safety or allocator compatibility. Those require implementation evidence and platform-specific testing.
