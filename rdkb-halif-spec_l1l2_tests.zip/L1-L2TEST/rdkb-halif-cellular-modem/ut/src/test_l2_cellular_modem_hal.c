/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
/**
 * Stateful Linux reference-model tests, not hardware integration claims.
 * The public reset contract restores defaults and reboot restarts the device.
 * Internal counters, immediate readiness, firmware stability, config retention,
 * and atomic one-shot failures below are explicitly host-model policies.
 * Every case resets its own fixture; no ordering dependency or external DUT.
 */
#include <stddef.h>
#include <ut.h>
#ifdef BUILD_LINUX
#include "cellular_modem_test_helpers.h"

static void assert_state(unsigned int config, unsigned int reboots,
                         unsigned int resets)
{
    cellular_model_snapshot_t state = cellular_model_snapshot();
    UT_ASSERT_EQUAL(state.configuration, config);
    UT_ASSERT_EQUAL(state.reboot_count, reboots);
    UT_ASSERT_EQUAL(state.reset_count, resets);
    UT_ASSERT_EQUAL(state.ready, 1);
}

static void query_independence(void)
{
    firmware_buffer_t first, second;
    modem_case_begin();
    cellular_model_seed_config(41);
    firmware_query_check(&first);
    firmware_query_check(&second);
    UT_ASSERT_EQUAL(memcmp(first.value, second.value, sizeof(first.value)), 0);
    assert_state(41, 0, 0);
}

static void invalid_input_recovery(void)
{
    firmware_buffer_t buffer;
    modem_case_begin();
    cellular_model_seed_config(42);
    UT_ASSERT_EQUAL(Modem_Firmware_Version(NULL), STATUS_FAILED);
    assert_state(42, 0, 0);
    firmware_query_check(&buffer);
    assert_state(42, 0, 0);
}

static void reboot_sequence(void)
{
    firmware_buffer_t before, after;
    modem_case_begin();
    cellular_model_seed_config(43);
    firmware_query_check(&before);
    UT_ASSERT_EQUAL_FATAL(Modem_Reboot(), STATUS_SUCCESS);
    assert_state(43, 1, 0);
    firmware_query_check(&after);
    UT_ASSERT_EQUAL(memcmp(before.value, after.value, sizeof(before.value)), 0);
    assert_state(43, 1, 0);
}

static void factory_defaults(void)
{
    firmware_buffer_t buffer;
    modem_case_begin();
    cellular_model_seed_config(44);
    assert_state(44, 0, 0);
    UT_ASSERT_EQUAL_FATAL(Modem_FactoryReset(), STATUS_SUCCESS);
    assert_state(CELLULAR_MODEL_DEFAULT_CONFIG, 0, 1);
    firmware_query_check(&buffer);
    assert_state(CELLULAR_MODEL_DEFAULT_CONFIG, 0, 1);
}

static void controlled_failure_recovery(void)
{
    firmware_buffer_t buffer;
    modem_case_begin();
    cellular_model_seed_config(45);

    cellular_model_fail_next(CELLULAR_MODEL_QUERY);
    firmware_buffer_prepare(&buffer);
    UT_ASSERT_EQUAL(Modem_Firmware_Version(buffer.value), STATUS_FAILED);
    firmware_guards_check(&buffer);
    assert_state(45, 0, 0);
    firmware_query_check(&buffer);

    cellular_model_fail_next(CELLULAR_MODEL_REBOOT);
    UT_ASSERT_EQUAL(Modem_Reboot(), STATUS_FAILED);
    assert_state(45, 0, 0);
    UT_ASSERT_EQUAL_FATAL(Modem_Reboot(), STATUS_SUCCESS);
    assert_state(45, 1, 0);

    cellular_model_fail_next(CELLULAR_MODEL_RESET);
    UT_ASSERT_EQUAL(Modem_FactoryReset(), STATUS_FAILED);
    assert_state(45, 1, 0);
    UT_ASSERT_EQUAL_FATAL(Modem_FactoryReset(), STATUS_SUCCESS);
    assert_state(CELLULAR_MODEL_DEFAULT_CONFIG, 1, 1);
    firmware_query_check(&buffer);
}

static void repeated_operations(void)
{
    firmware_buffer_t buffer;
    modem_case_begin();
    cellular_model_seed_config(46);
    for (unsigned int i = 1; i <= 3; ++i)
    {
        UT_ASSERT_EQUAL_FATAL(Modem_Reboot(), STATUS_SUCCESS);
        assert_state(46, i, 0);
        firmware_query_check(&buffer);
    }
    for (unsigned int i = 1; i <= 3; ++i)
    {
        UT_ASSERT_EQUAL_FATAL(Modem_FactoryReset(), STATUS_SUCCESS);
        assert_state(CELLULAR_MODEL_DEFAULT_CONFIG, 3, i);
        firmware_query_check(&buffer);
    }
}

static void mixed_sequence_isolation(void)
{
    firmware_buffer_t buffer;
    modem_case_begin();
    cellular_model_seed_config(47);
    cellular_model_fail_next(CELLULAR_MODEL_RESET);
    UT_ASSERT_EQUAL_FATAL(Modem_Reboot(), STATUS_SUCCESS);
    firmware_query_check(&buffer);
    UT_ASSERT_EQUAL(Modem_FactoryReset(), STATUS_FAILED);
    assert_state(47, 1, 0);
    UT_ASSERT_EQUAL_FATAL(Modem_FactoryReset(), STATUS_SUCCESS);
    cellular_model_seed_config(48);
    UT_ASSERT_EQUAL(Modem_Firmware_Version(NULL), STATUS_FAILED);
    UT_ASSERT_EQUAL_FATAL(Modem_Reboot(), STATUS_SUCCESS);
    firmware_query_check(&buffer);
    assert_state(48, 2, 1);

    /* Resetting the private fixture also clears pending failures/counters. */
    cellular_model_fail_next(CELLULAR_MODEL_QUERY);
    cellular_model_fail_next(CELLULAR_MODEL_REBOOT);
    cellular_model_fail_next(CELLULAR_MODEL_RESET);
    cellular_model_reset_fixture();
    assert_state(CELLULAR_MODEL_DEFAULT_CONFIG, 0, 0);
    firmware_query_check(&buffer);
    UT_ASSERT_EQUAL_FATAL(Modem_Reboot(), STATUS_SUCCESS);
    UT_ASSERT_EQUAL_FATAL(Modem_FactoryReset(), STATUS_SUCCESS);
    assert_state(CELLULAR_MODEL_DEFAULT_CONFIG, 1, 1);
}
#endif

/* PUBLIC_INTERFACE */
/** Register seven group-2 model scenarios on Linux, or no model suite on vendors. */
int test_cellular_modem_hal_l2_register(void)
{
#ifdef BUILD_LINUX
    static const struct
    {
        const char *name;
        UT_TestFunction_t function;
    } cases[] = {
        {"l2_cellular_modem_query_independence", query_independence},
        {"l2_cellular_modem_invalid_input_recovery", invalid_input_recovery},
        {"l2_cellular_modem_reboot_sequence", reboot_sequence},
        {"l2_cellular_modem_factory_defaults", factory_defaults},
        {"l2_cellular_modem_controlled_failure_recovery", controlled_failure_recovery},
        {"l2_cellular_modem_repeated_operations", repeated_operations},
        {"l2_cellular_modem_mixed_sequence_isolation", mixed_sequence_isolation}
    };
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L2 cellular_modem_hal]", NULL, NULL, UT_TESTS_L2);
    if (suite == NULL)
        return -1;
    for (unsigned int i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i)
        if (UT_add_test(suite, cases[i].name, cases[i].function) == NULL)
            return -1;
#endif
    return 0;
}
