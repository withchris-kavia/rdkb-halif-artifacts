/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#ifndef CELLULAR_MODEM_TEST_HELPERS_H
#define CELLULAR_MODEM_TEST_HELPERS_H

#include <string.h>
#include <ut.h>
#include "cellular_modem_hal_api.h"
#ifdef BUILD_LINUX
#include "cellular_modem_test_control.h"
#endif

/** Exactly the documented minimum caller allocation, with adjacent guards. */
typedef struct
{
    unsigned char before[16];
    char value[128];
    unsigned char after[16];
} firmware_buffer_t;

static inline void modem_case_begin(void)
{
#ifdef BUILD_LINUX
    cellular_model_reset_fixture();
#endif
    UT_ASSERT_EQUAL(STATUS_SUCCESS, 0);
    UT_ASSERT_EQUAL(STATUS_FAILED, -1);
}

static inline void firmware_buffer_prepare(firmware_buffer_t *buffer)
{
    memset(buffer, 0xa5, sizeof(*buffer));
}

static inline void firmware_guards_check(const firmware_buffer_t *buffer)
{
    for (unsigned int i = 0; i < sizeof(buffer->before); ++i)
    {
        UT_ASSERT_EQUAL(buffer->before[i], 0xa5);
        UT_ASSERT_EQUAL(buffer->after[i], 0xa5);
    }
}

/* Do not read version text on failure or call strlen/strcmp on unbounded output. */
static inline void firmware_query_check(firmware_buffer_t *buffer)
{
    int status;
    firmware_buffer_prepare(buffer);
    status = Modem_Firmware_Version(buffer->value);
    firmware_guards_check(buffer);
    UT_ASSERT_EQUAL_FATAL(status, STATUS_SUCCESS);
    UT_ASSERT_PTR_NOT_NULL_FATAL(memchr(buffer->value, '\0', sizeof(buffer->value)));
    UT_ASSERT_TRUE(buffer->value[0] != '\0');
#ifdef BUILD_LINUX
    /* Fixed firmware is model policy, not a vendor conformance requirement. */
    UT_ASSERT_EQUAL(memcmp(buffer->value, CELLULAR_MODEL_FIRMWARE,
                           sizeof(CELLULAR_MODEL_FIRMWARE)), 0);
#endif
}
#endif
