/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
/**
 * L1 tests for include/cellular_modem_hal_api.h's three operations and 0/-1
 * statuses. Only correctly sized output buffers are passed (minimum 128).
 * BUILD_LINUX adds deterministic host failure probes, not vendor requirements.
 * On a real vendor target reset/reboot are destructive; no host result proves
 * hardware readiness or timing.
 */
#include "cellular_modem_test_helpers.h"

/* PUBLIC_INTERFACE */
/** Check reset success and, on Linux, one-shot failure and recovery statuses. */
void test_l1_cellular_modem_hal_api_positive1_Modem_FactoryReset(void)
{
    modem_case_begin();
    UT_ASSERT_EQUAL(Modem_FactoryReset(), STATUS_SUCCESS);
#ifdef BUILD_LINUX
    cellular_model_fail_next(CELLULAR_MODEL_RESET);
    UT_ASSERT_EQUAL(Modem_FactoryReset(), STATUS_FAILED);
    UT_ASSERT_EQUAL(Modem_FactoryReset(), STATUS_SUCCESS);
#endif
}

/* PUBLIC_INTERFACE */
/** Check reboot success and, on Linux, one-shot failure and recovery statuses. */
void test_l1_cellular_modem_hal_api_positive1_Modem_Reboot(void)
{
    modem_case_begin();
    UT_ASSERT_EQUAL(Modem_Reboot(), STATUS_SUCCESS);
#ifdef BUILD_LINUX
    cellular_model_fail_next(CELLULAR_MODEL_REBOOT);
    UT_ASSERT_EQUAL(Modem_Reboot(), STATUS_FAILED);
    UT_ASSERT_EQUAL(Modem_Reboot(), STATUS_SUCCESS);
#endif
}

/* PUBLIC_INTERFACE */
/** Check bounded nonempty firmware output in a nonzero-prefilled guarded buffer. */
void test_l1_cellular_modem_hal_api_positive1_Modem_Firmware_Version(void)
{
    firmware_buffer_t buffer;
    modem_case_begin();
    firmware_query_check(&buffer);
}

/* PUBLIC_INTERFACE */
/** Check NULL rejection, controlled retrieval failure, and subsequent recovery. */
void test_l1_cellular_modem_hal_api_negative1_Modem_Firmware_Version(void)
{
    firmware_buffer_t buffer;
    modem_case_begin();
    UT_ASSERT_EQUAL(Modem_Firmware_Version(NULL), STATUS_FAILED);
#ifdef BUILD_LINUX
    firmware_buffer_prepare(&buffer);
    cellular_model_fail_next(CELLULAR_MODEL_QUERY);
    UT_ASSERT_EQUAL(Modem_Firmware_Version(buffer.value), STATUS_FAILED);
    /* Failure output is unspecified publicly; inspect only surrounding guards. */
    firmware_guards_check(&buffer);
#endif
    firmware_query_check(&buffer);
}

/* PUBLIC_INTERFACE */
/** Register the four preserved L1 identities in group 1; return 0 or -1. */
int test_cellular_modem_hal_api_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L1 cellular_modem_hal_api]", NULL, NULL, UT_TESTS_L1);
    if (suite == NULL)
        return -1;
    if (UT_add_test(suite, "l1_cellular_modem_hal_api_positive1_Modem_FactoryReset",
                   test_l1_cellular_modem_hal_api_positive1_Modem_FactoryReset) == NULL)
        return -1;
    if (UT_add_test(suite, "l1_cellular_modem_hal_api_positive1_Modem_Reboot",
                   test_l1_cellular_modem_hal_api_positive1_Modem_Reboot) == NULL)
        return -1;
    if (UT_add_test(suite, "l1_cellular_modem_hal_api_positive1_Modem_Firmware_Version",
                   test_l1_cellular_modem_hal_api_positive1_Modem_Firmware_Version) == NULL)
        return -1;
    if (UT_add_test(suite, "l1_cellular_modem_hal_api_negative1_Modem_Firmware_Version",
                   test_l1_cellular_modem_hal_api_negative1_Modem_Firmware_Version) == NULL)
        return -1;
    return 0;
}
