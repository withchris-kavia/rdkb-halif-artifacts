/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
extern int test_cellular_modem_hal_api_l1_register(void);
extern int test_cellular_modem_hal_l2_register(void);

/* PUBLIC_INTERFACE */
/** Register all L1 modem tests; return zero only if every registration succeeds. */
int register_hal_l1_tests(void)
{
    return test_cellular_modem_hal_api_l1_register();
}

/* PUBLIC_INTERFACE */
/** Register all applicable L2 modem tests; return their registration status. */
int register_hal_l2_tests(void)
{
    return test_cellular_modem_hal_l2_register();
}
