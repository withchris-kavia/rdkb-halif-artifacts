#!/usr/bin/env bash
# Copyright 2023 RDK Management
# Licensed under the Apache License, Version 2.0.
# See http://www.apache.org/licenses/LICENSE-2.0

set -u
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || exit 1
cd -- "$SCRIPT_DIR" || exit 1

if [[ ! -d ut-core ]]; then
    git clone -- git@github.com:rdkcentral/ut-core.git ut-core || exit "$?"
    # Test the variable's value, not a variable named by its value.
    if [[ -z ${UT_CORE_PROJECT_VERSION:-} ]]; then
        UT_CORE_PROJECT_VERSION=$(git -C ut-core tag --list '3.*' --sort=-version:refname) || exit 1
        UT_CORE_PROJECT_VERSION=${UT_CORE_PROJECT_VERSION%%$'\n'*}
        if [[ -z $UT_CORE_PROJECT_VERSION ]]; then
            printf '%s\n' 'No compatible ut-core tag; set UT_CORE_PROJECT_VERSION.' >&2
            exit 1
        fi
    fi
    git -C ut-core checkout "$UT_CORE_PROJECT_VERSION" || exit "$?"
fi

# The component Makefile consumes bootstrapped dependencies read-only. Never
# invoke ut-core's recursive bootstrap/clean, which rewrites its framework tree.
exec make -C "$SCRIPT_DIR" -f Makefile "$@"
