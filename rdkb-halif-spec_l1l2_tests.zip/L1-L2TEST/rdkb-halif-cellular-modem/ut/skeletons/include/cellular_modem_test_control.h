/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#ifndef CELLULAR_MODEM_TEST_CONTROL_H
#define CELLULAR_MODEM_TEST_CONTROL_H

#ifndef BUILD_LINUX
#error "Cellular modem model controls are Linux-host-only"
#endif

#define CELLULAR_MODEL_FIRMWARE "EM06ALAR04A01M4G_01.003.01.003"
#define CELLULAR_MODEL_DEFAULT_CONFIG 0U

/** Host-model operations; not part of the modem HAL ABI. */
typedef enum
{
    CELLULAR_MODEL_QUERY,
    CELLULAR_MODEL_REBOOT,
    CELLULAR_MODEL_RESET,
    CELLULAR_MODEL_OPERATION_COUNT
} cellular_model_operation_t;

/** Successful operation counts and synchronous model state (not hardware readiness). */
typedef struct
{
    unsigned int configuration;
    unsigned int reboot_count;
    unsigned int reset_count;
    int ready;
} cellular_model_snapshot_t;

/* PUBLIC_INTERFACE */
/** Reset the host fixture to defaults, clearing counters and pending failures. */
void cellular_model_reset_fixture(void);

/* PUBLIC_INTERFACE */
/** Seed persistent host configuration without changing operation counters. */
void cellular_model_seed_config(unsigned int configuration);

/* PUBLIC_INTERFACE */
/** Fail the next valid call of operation once; ignore out-of-range operations. */
void cellular_model_fail_next(cellular_model_operation_t operation);

/* PUBLIC_INTERFACE */
/** Return a value copy of modeled state and successful-operation counters. */
cellular_model_snapshot_t cellular_model_snapshot(void);

#endif
