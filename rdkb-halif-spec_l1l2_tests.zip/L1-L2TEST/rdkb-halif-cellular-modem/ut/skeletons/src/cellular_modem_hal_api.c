/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <stdbool.h>
#include <string.h>
#include "cellular_modem_hal_api.h"
#include "cellular_modem_test_control.h"

/*
 * Single-threaded host reference policy, not simulated hardware timing:
 * reboot retains persistent config, factory reset restores defaults, failures
 * are one-shot and atomic, and successful calls finish ready. The public HAL
 * does not promise counters, failure atomicity, timing, or a fixed version.
 */
static cellular_model_snapshot_t state = {CELLULAR_MODEL_DEFAULT_CONFIG, 0, 0, 1};
static bool pending_failure[CELLULAR_MODEL_OPERATION_COUNT];

static bool fail_operation(cellular_model_operation_t operation)
{
    bool fail = pending_failure[operation];
    pending_failure[operation] = false;
    return fail;
}

/* PUBLIC_INTERFACE */
/** Restore all host fixture state, independently of public reset accounting. */
void cellular_model_reset_fixture(void)
{
    state = (cellular_model_snapshot_t){CELLULAR_MODEL_DEFAULT_CONFIG, 0, 0, 1};
    memset(pending_failure, 0, sizeof(pending_failure));
}

/* PUBLIC_INTERFACE */
/** Set the host's modeled persistent configuration to configuration. */
void cellular_model_seed_config(unsigned int configuration)
{
    state.configuration = configuration;
}

/* PUBLIC_INTERFACE */
/** Arm a one-shot failure for a valid model operation. */
void cellular_model_fail_next(cellular_model_operation_t operation)
{
    if (operation >= CELLULAR_MODEL_QUERY && operation < CELLULAR_MODEL_OPERATION_COUNT)
        pending_failure[operation] = true;
}

/* PUBLIC_INTERFACE */
/** Return the current host state without changing it. */
cellular_model_snapshot_t cellular_model_snapshot(void)
{
    return state;
}

/* PUBLIC_INTERFACE */
/** Restore modeled defaults; return STATUS_FAILED without mutation on injection. */
int Modem_FactoryReset(void)
{
    if (fail_operation(CELLULAR_MODEL_RESET))
        return STATUS_FAILED;
    state.ready = 0;
    state.configuration = CELLULAR_MODEL_DEFAULT_CONFIG;
    ++state.reset_count;
    state.ready = 1;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Restart the host model, retaining configuration; return the operation status. */
int Modem_Reboot(void)
{
    if (fail_operation(CELLULAR_MODEL_REBOOT))
        return STATUS_FAILED;
    state.ready = 0;
    ++state.reboot_count;
    state.ready = 1;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/**
 * Write a deterministic version including its terminator into firmware_version,
 * whose caller must provide at least 128 bytes per the public contract.
 * Return STATUS_FAILED on NULL or injection, without touching output on failure.
 */
int Modem_Firmware_Version(char *firmware_version)
{
    static const char version[] = CELLULAR_MODEL_FIRMWARE;
    _Static_assert(sizeof(version) <= 128, "Host firmware must fit the HAL buffer");
    if (firmware_version == NULL || fail_operation(CELLULAR_MODEL_QUERY))
        return STATUS_FAILED;
    memcpy(firmware_version, version, sizeof(version));
    return STATUS_SUCCESS;
}
