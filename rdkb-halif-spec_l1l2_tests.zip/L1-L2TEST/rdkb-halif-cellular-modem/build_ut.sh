#!/usr/bin/env bash
# Copyright 2023 RDK Management
# Licensed under the Apache License, Version 2.0.
# See http://www.apache.org/licenses/LICENSE-2.0

set -u
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || exit 1
BUILD_ROOT=$SCRIPT_DIR

if [[ ${1-} == -h || ${1-} == --help ]]; then
    printf 'Usage: %s [--dir BUILD_ROOT] [make arguments...]\n' "$0"
    exit 0
fi
if [[ ${1-} == --dir ]]; then
    if [[ $# -lt 2 || -z $2 ]]; then
        printf '%s\n' '--dir requires a build root' >&2
        exit 2
    fi
    # Resolve once relative to the caller, before changing directory.
    BUILD_ROOT=$(realpath -m -- "$2") || exit 1
    shift 2
fi

UT_DIR=$BUILD_ROOT/ut
if [[ ! -d $UT_DIR ]]; then
    TEST_REPO=$(git -C "$SCRIPT_DIR" remote get-url origin) || exit 1
    TEST_REPO=${TEST_REPO//halif/halif-test}
    TEST_REPO=${TEST_REPO//hal-/haltest-}
    mkdir -p -- "$BUILD_ROOT" || exit 1
    git clone -- "$TEST_REPO" "$UT_DIR" || exit "$?"
    git -C "$UT_DIR" checkout "${UT_PROJECT_VERSION:-main}" || exit "$?"
fi
cd -- "$UT_DIR" || exit 1
# No recursion or trailing command that could hide the build's status.
exec ./build.sh "$@"
