/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
/**
 * @file platform_hal.c
 * @brief In-process Linux reference model, NOT a physical-device HAL.
 *
 * LOCAL policies where the public contract is incomplete:
 * - serialized, process-local state; initialization is idempotent, not a reset;
 * - lengthless output callers provide the capacities documented in the header;
 *   explicit-size outputs reject insufficient space without truncating/writing;
 * - GetMemoryPaths allocates ONE calloc-compatible record, caller frees it;
 *   DHCP lists and each value are independently malloc-owned by the caller;
 * - LED output strings are borrowed until the next set; inputs are deep copied;
 * - fan speeds are simulated RPM (0..4000), never host sensor measurements;
 * - MACsec start/stop complete synchronously as model requests; no driver or
 *   peer exists, so operational status remains FALSE, independent of admin;
 * - DSCP CSV retains the declared 0..65534 domain, NOT QoS's six-bit domain.
 *   Up to 64 unique selectors fit the actual array; NULL selects 0..63.
 *   STOP removes selected selectors; NULL stops all. No synthetic client bytes.
 * - QoS IP bytes use network order locally; all uint16 port values are valid.
 *   One most-recent rule is retained, no host networking is reconfigured.
 * - reported identity, memory, firmware, DHCP and telemetry are model data.
 */
#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include "platform_hal.h"

extern int MaxEthPort;
extern char PartnerID[512];
extern char **InterfaceNames;
extern int num_InterfaceNames;

static BOOLEAN ssh, telnet, macsec_admin[64], fan_override[2];
static char snmp[32] = "rgWan", variant[512] = "unknown";
static ULONG web_timeout = 840, reset_count = 3;
static INT image_timeout = 3600;
static BOOLEAN image_valid = TRUE, snmp_reboot;
static PSM_STATE power_state = PSM_UNKNOWN;
static UINT fan_rpm[2] = {1000, 1000};
static LEDMGMT_PARAMS led = {
#ifdef FEATURE_RDKB_LED_MANAGER
    .led_name = NULL, .led_param = NULL,
#endif
    .LedColor = LED_WHITE, .State = 0, .Interval = 0
};
#ifdef FEATURE_RDKB_LED_MANAGER
static char led_name[128] = "reference", led_param[128] = "";
#endif
struct access_entry { INT user, iface; ULONG value; struct access_entry *next; };
static struct access_entry *access_levels;
static struct {
    UINT count;
    UINT values[64];
} dscp[WAN_INTERFACE_MAX];
static hal_network_params_t qos_rule;

static int boolean(BOOLEAN value) { return value == FALSE || value == TRUE; }
static int port(INT value) { return value >= 0 && value < MaxEthPort && value < 64; }
static int wan(WAN_INTERFACE value) { return value >= DOCSIS && value < WAN_INTERFACE_MAX; }
static INT text(CHAR *out, const char *value)
{
    if (!out) return RETURN_ERR;
    memcpy(out, value, strlen(value) + 1);
    return RETURN_OK;
}
static INT sized_text(CHAR *out, ULONG capacity, const char *value)
{
    if (!out || capacity <= strlen(value)) return RETURN_ERR;
    return text(out, value);
}
static INT number(ULONG *out, ULONG value)
{
    if (!out) return RETURN_ERR;
    *out = value;
    return RETURN_OK;
}
static INT get_boolean(BOOLEAN *out, BOOLEAN value)
{
    if (!out) return RETURN_ERR;
    *out = value;
    return RETURN_OK;
}

/** @brief Release only private allocations at process exit. */
static void release_access(void)
{
    while (access_levels) {
        struct access_entry *next = access_levels->next;
        free(access_levels);
        access_levels = next;
    }
}
INT platform_hal_PandMDBInit(void)
{
    static int initialized;
    if (!initialized) {
        if (atexit(release_access)) return RETURN_ERR;
        initialized = 1;
    }
    return RETURN_OK;
}
INT platform_hal_DocsisParamsDBInit(void) { return RETURN_OK; }
INT platform_hal_GetDeviceConfigStatus(CHAR *out) { return text(out, "Complete"); }
INT platform_hal_GetTelnetEnable(BOOLEAN *out) { return get_boolean(out, telnet); }
INT platform_hal_SetTelnetEnable(BOOLEAN value)
{
    if (!boolean(value)) return RETURN_ERR;
    telnet = value;
    return RETURN_OK;
}
INT platform_hal_GetSSHEnable(BOOLEAN *out) { return get_boolean(out, ssh); }
INT platform_hal_SetSSHEnable(BOOLEAN value)
{
    if (!boolean(value)) return RETURN_ERR;
    ssh = value;
    return RETURN_OK;
}
INT platform_hal_GetSNMPEnable(CHAR *out) { return text(out, snmp); }
INT platform_hal_SetSNMPEnable(CHAR *value)
{
    if (!value || (strcmp(value, "rgWan") && strcmp(value, "rgDualIp") &&
                   strcmp(value, "rgLanIp"))) return RETURN_ERR;
    return text(snmp, value);
}
INT platform_hal_GetWebUITimeout(ULONG *out) { return number(out, web_timeout); }
INT platform_hal_SetWebUITimeout(ULONG value)
{
    if (value && (value < 30 || value > 86400)) return RETURN_ERR;
    web_timeout = value;
    return RETURN_OK;
}
INT platform_hal_GetWebAccessLevel(INT user, INT iface, ULONG *out)
{
    if (!out) return RETURN_ERR;
    for (struct access_entry *e = access_levels; e; e = e->next)
        if (e->user == user && e->iface == iface) return number(out, e->value);
    return number(out, 0);
}
INT platform_hal_SetWebAccessLevel(INT user, INT iface, ULONG value)
{
    struct access_entry **link = &access_levels;
    if (value > INT_MAX || platform_hal_PandMDBInit()) return RETURN_ERR;
    while (*link && ((*link)->user != user || (*link)->iface != iface))
        link = &(*link)->next;
    if (!value) {
        if (*link) {
            struct access_entry *old = *link;
            *link = old->next;
            free(old);
        }
        return RETURN_OK;
    }
    if (!*link) {
        *link = calloc(1, sizeof(**link));
        if (!*link) return RETURN_ERR;
        (*link)->user = user;
        (*link)->iface = iface;
    }
    (*link)->value = value;
    return RETURN_OK;
}
INT platform_hal_GetModelName(CHAR *out) { return text(out, "Linux-reference-model"); }
INT platform_hal_GetRouterRegion(CHAR *out) { return text(out, "REGION_UNKNOWN"); }
INT platform_hal_GetSerialNumber(CHAR *out) { return text(out, "REFERENCE-NOT-HARDWARE"); }
INT platform_hal_GetHardwareVersion(CHAR *out) { return text(out, "reference-1"); }
INT platform_hal_GetSoftwareVersion(CHAR *out, ULONG size) { return sized_text(out, size, "ref-1"); }
INT platform_hal_GetBootloaderVersion(CHAR *out, ULONG size) { return sized_text(out, size, "ref-1"); }
INT platform_hal_GetFirmwareName(CHAR *out, ULONG size) { return sized_text(out, size, "ref-1"); }
INT platform_hal_GetBaseMacAddress(CHAR *out) { return text(out, "02:00:00:00:00:01"); }
INT platform_hal_GetHardware(CHAR *out) { return text(out, "4096"); }
INT platform_hal_GetHardware_MemUsed(CHAR *out) { return text(out, "1024"); }
INT platform_hal_GetHardware_MemFree(CHAR *out) { return text(out, "3072"); }
INT platform_hal_GetTotalMemorySize(ULONG *out) { return number(out, 1024); }
INT platform_hal_GetUsedMemorySize(ULONG *out) { return number(out, 256); }
INT platform_hal_GetFreeMemorySize(ULONG *out) { return number(out, 768); }
INT platform_hal_GetFactoryResetCount(ULONG *out) { return number(out, reset_count); }
INT platform_hal_ClearResetCount(BOOLEAN value)
{
    if (!boolean(value)) return RETURN_ERR;
    if (value) reset_count = 0;
    return RETURN_OK;
}
/* Numeric seconds only: deliberately do not repeat the contradictory zone labels. */
INT platform_hal_getTimeOffSet(CHAR *out) { return text(out, "-18000"); }
INT platform_hal_SetDeviceCodeImageTimeout(INT seconds)
{
    if (seconds < 0 || seconds > 3600) return RETURN_ERR;
    image_timeout = seconds;
    return RETURN_OK;
}
INT platform_hal_SetDeviceCodeImageValid(BOOLEAN value)
{
    if (!boolean(value)) return RETURN_ERR;
    image_valid = value;
    return RETURN_OK;
}
INT platform_hal_getFactoryPartnerId(CHAR *out) { return text(out, PartnerID); }
INT platform_hal_getFactoryCmVariant(CHAR *out) { return text(out, variant); }
INT platform_hal_setFactoryCmVariant(CHAR *value)
{
    const char *valid[] = {"unknown", "pc20", "pc20genband", "pc15sip", "pc15mgcp"};
    if (!value) return RETURN_ERR;
    for (size_t i = 0; i < sizeof(valid)/sizeof(*valid); ++i)
        if (!strcmp(value, valid[i])) return text(variant, value);
    return RETURN_ERR;
}
#ifdef FEATURE_RDKB_LED_MANAGER
int platform_hal_initLed(char *out)
{
    return text(out, "config/reference-led.json");
}
#endif
INT platform_hal_setLed(PLEDMGMT_PARAMS value)
{
    if (!value || value->LedColor < LED_WHITE || value->LedColor >= NOT_SUPPORTED ||
        (value->State != 0 && value->State != 1) || value->Interval < 0)
        return RETURN_ERR;
#ifdef FEATURE_RDKB_LED_MANAGER
    if ((value->led_name && strnlen(value->led_name, sizeof(led_name)) == sizeof(led_name)) ||
        (value->led_param && strnlen(value->led_param, sizeof(led_param)) == sizeof(led_param)))
        return RETURN_ERR;
    /* memmove supports set(get()) with the reference-owned borrowed pointers. */
    if (value->led_name) memmove(led_name, value->led_name, strlen(value->led_name) + 1);
    if (value->led_param) memmove(led_param, value->led_param, strlen(value->led_param) + 1);
    led.led_name = led_name;
    led.led_param = led_param;
#endif
    led.LedColor = value->LedColor;
    led.State = value->State;
    led.Interval = value->Interval;
    return RETURN_OK;
}
INT platform_hal_getLed(PLEDMGMT_PARAMS out)
{
    if (!out) return RETURN_ERR;
#ifdef FEATURE_RDKB_LED_MANAGER
    led.led_name = led_name;
    led.led_param = led_param;
#endif
    *out = led;
    return RETURN_OK;
}
UINT platform_hal_getFanSpeed(UINT index)
{
    if (index > 1) return 0; /* raw unsigned API has no error sentinel */
    return fan_override[index] ? 4000 : fan_rpm[index];
}
UINT platform_hal_getRPM(UINT index) { return platform_hal_getFanSpeed(index); }
INT platform_hal_getRotorLock(UINT index) { return index < 2 ? 0 : -1; }
BOOLEAN platform_hal_getFanStatus(UINT index)
{
    return index < 2 && platform_hal_getFanSpeed(index) != 0;
}
INT platform_hal_setFanMaxOverride(BOOLEAN value, UINT index)
{
    if (!boolean(value) || index > 1) return RETURN_ERR;
    fan_override[index] = value;
    return RETURN_OK;
}
#ifdef FEATURE_RDKB_THERMAL_MANAGER
INT platform_hal_LoadThermalConfig(THERMAL_PLATFORM_CONFIG *out)
{
    const THERMAL_PLATFORM_CONFIG config = {2, 30, 35, 40, 30, 5, 1, 60};
    if (!out) return RETURN_ERR;
    *out = config;
    return RETURN_OK;
}
INT platform_hal_initThermal(THERMAL_PLATFORM_CONFIG *out)
{
    return platform_hal_LoadThermalConfig(out);
}
INT platform_hal_setFanSpeed(UINT index, FAN_SPEED speed, FAN_ERR *reason)
{
    if (!reason) return RETURN_ERR;
    *reason = FAN_ERR_HW;
    if (index > 1 || speed < FAN_SPEED_OFF || speed > FAN_SPEED_MAX) return RETURN_ERR;
    if (fan_override[index]) {
        *reason = FAN_ERR_MAX_OVERRIDE_SET;
        return RETURN_ERR;
    }
    fan_rpm[index] = (UINT)speed * 1000;
    *reason = FAN_ERR_NONE;
    return RETURN_OK;
}
static INT reading(INT *out, INT value)
{
    if (!out) return RETURN_ERR;
    *out = value;
    return RETURN_OK;
}
INT platform_hal_getFanTemperature(INT *out) { return reading(out, 45); }
INT platform_hal_getInputCurrent(INT *out) { return reading(out, 0); }
INT platform_hal_getInputPower(INT *out) { return reading(out, 0); }
INT platform_hal_getRadioTemperature(INT index, INT *out)
{
    if (index < 0 || index > 2) return RETURN_ERR;
    return reading(out, 40);
}
INT platform_hal_getEcoModeStatus(INT index, INT *out)
{
    if (index < 0 || index > 1) return RETURN_ERR;
    return reading(out, 0);
}
#endif
INT platform_hal_SetSNMPOnboardRebootEnable(CHAR *value)
{
    if (!value || (strcasecmp(value, "enable") && strcasecmp(value, "disable")))
        return RETURN_ERR;
    snmp_reboot = !strcasecmp(value, "enable");
    return RETURN_OK;
}
INT platform_hal_GetMACsecEnable(INT index, BOOLEAN *out)
{
    if (!port(index)) return RETURN_ERR;
    return get_boolean(out, macsec_admin[index]);
}
INT platform_hal_SetMACsecEnable(INT index, BOOLEAN value)
{
    if (!port(index) || !boolean(value)) return RETURN_ERR;
    macsec_admin[index] = value;
    return RETURN_OK;
}
INT platform_hal_GetMACsecOperationalStatus(INT index, BOOLEAN *out)
{
    if (!port(index)) return RETURN_ERR;
    return get_boolean(out, FALSE);
}
INT platform_hal_StartMACsec(INT index, INT timeout)
{
    /* No handshake is attempted: even timeout=0 cannot hang the model. */
    return port(index) && timeout >= 0 ? RETURN_OK : RETURN_ERR;
}
INT platform_hal_StopMACsec(INT index) { return port(index) ? RETURN_OK : RETURN_ERR; }
INT platform_hal_GetMemoryPaths(RDK_CPUS cpu, PPLAT_PROC_MEM_INFO *out)
{
    PLAT_PROC_MEM_INFO *info;
    if (!out || (cpu != HOST_CPU && cpu != PEER_CPU)) return RETURN_ERR;
    info = calloc(1, sizeof(*info));
    if (!info) return RETURN_ERR;
    strcpy(info->dramPath, "/tmp");
    /* Scratch paths, NOT claims of mounted eMMC partitions. */
    strcpy(info->emmcPath1, "/tmp");
    strcpy(info->emmcPath2, "/tmp");
    *out = info;
    return RETURN_OK;
}
static void free_options(dhcp_opt_list *head)
{
    while (head) {
        dhcp_opt_list *next = head->next;
        free(head->dhcp_opt_val);
        free(head);
        head = next;
    }
}
static dhcp_opt_list *option(int code, const char *value)
{
    dhcp_opt_list *node = calloc(1, sizeof(*node));
    if (!node) return NULL;
    node->dhcp_opt = code;
    node->dhcp_opt_val = strdup(value);
    if (!node->dhcp_opt_val) { free(node); return NULL; }
    return node;
}
static INT options(dhcp_opt_list **req, dhcp_opt_list **send, int v6)
{
    dhcp_opt_list *r, *s;
    if (!req || !send || req == send) return RETURN_ERR;
    r = option(v6 ? DHCPV6_OPT_23 : DHCPV4_OPT_42, "");
    s = option(v6 ? DHCPV6_OPT_16 : DHCPV4_OPT_60, "linux-reference");
    if (!r || !s) { free_options(r); free_options(s); return RETURN_ERR; }
    *req = r;
    *send = s;
    return RETURN_OK;
}
INT platform_hal_GetDhcpv4_Options(dhcp_opt_list **r, dhcp_opt_list **s) { return options(r, s, 0); }
INT platform_hal_GetDhcpv6_Options(dhcp_opt_list **r, dhcp_opt_list **s) { return options(r, s, 1); }
INT platform_hal_SetLowPowerModeState(PPSM_STATE state)
{
    if (!state || *state < PSM_UNKNOWN || *state > PSM_NOT_SUPPORTED) return RETURN_ERR;
    power_state = *state;
    return RETURN_OK;
}
INT platform_hal_getCMTSMac(CHAR *out) { return text(out, "02:00:00:00:00:02"); }

static int selectors(const char *csv, UINT values[64], UINT *count)
{
    *count = 0;
    if (!csv) {
        for (UINT i = 0; i < 64; ++i) values[(*count)++] = i;
        return 0;
    }
    if (!*csv || strnlen(csv, 196) > 195) return -1;
    while (*csv) {
        unsigned value = 0;
        int duplicate = 0;
        if (!isdigit((unsigned char)*csv)) return -1;
        do {
            unsigned digit = (unsigned)(*csv++ - '0');
            if (value > (65534U - digit)/10U) return -1;
            value = value * 10 + digit;
        } while (isdigit((unsigned char)*csv));
        for (UINT i = 0; i < *count; ++i) duplicate |= values[i] == value;
        if (!duplicate) {
            if (*count == 64) return -1;
            values[(*count)++] = value;
        }
        if (!*csv) break;
        if (*csv++ != ',' || !*csv) return -1;
    }
    return 0;
}
INT platform_hal_setDscp(WAN_INTERFACE iface, TRAFFIC_CNT_COMMAND command, char *csv)
{
    UINT values[64], count;
    if (!wan(iface) || (command != TRAFFIC_CNT_START && command != TRAFFIC_CNT_STOP) ||
        selectors(csv, values, &count)) return RETURN_ERR;
    if (command == TRAFFIC_CNT_START) {
        memcpy(dscp[iface].values, values, count * sizeof(*values));
        dscp[iface].count = count;
    } else {
        for (UINT i = 0; i < count; ++i)
            for (UINT j = 0; j < dscp[iface].count; ++j)
                if (values[i] == dscp[iface].values[j]) {
                    memmove(&dscp[iface].values[j], &dscp[iface].values[j + 1],
                            (--dscp[iface].count - j) * sizeof(*values));
                    break;
                }
    }
    return RETURN_OK;
}
INT platform_hal_resetDscpCounts(WAN_INTERFACE iface) { return wan(iface) ? RETURN_OK : RETURN_ERR; }
INT platform_hal_getDscpClientList(WAN_INTERFACE iface, pDSCP_list_t out)
{
    if (!wan(iface) || !out) return RETURN_ERR;
    memset(out, 0, sizeof(*out));
    out->numElements = dscp[iface].count;
    for (UINT i = 0; i < out->numElements; ++i)
        out->DSCP_Element[i].dscp_value = dscp[iface].values[i];
    return RETURN_OK;
}
INT platform_hal_GetCPUSpeed(char *out) { return text(out, "1000.00"); }
INT platform_hal_GetFirmwareBankInfo(FW_BANK bank, PFW_BANK_INFO out)
{
    if (!out || (bank != ACTIVE_BANK && bank != INACTIVE_BANK)) return RETURN_ERR;
    memset(out, 0, sizeof(*out));
    strcpy(out->fw_name, bank == ACTIVE_BANK ? "reference-active" : "reference-inactive");
    strcpy(out->fw_state, bank == ACTIVE_BANK ? "confirmed" : "TrialBoot#0");
    return RETURN_OK;
}
INT platform_hal_GetInterfaceStats(const char *name, PINTF_STATS out)
{
    if (!name || !out) return RETURN_ERR;
    for (int i = 0; i < num_InterfaceNames; ++i)
        if (!strcmp(name, InterfaceNames[i])) {
            memset(out, 0, sizeof(*out));
            return RETURN_OK;
        }
    return RETURN_ERR;
}
INT platform_hal_GetPppUserName(CHAR *out, ULONG capacity) { return sized_text(out, capacity, "ref01"); }
INT platform_hal_GetPppPassword(CHAR *out, ULONG capacity) { return sized_text(out, capacity, "ref02"); }
INT platform_hal_qos_apply(const hal_network_params_t *params)
{
    if (!params || (params->ip_version != IP_VERSION_IPV4 &&
                    params->ip_version != IP_VERSION_IPV6) ||
        (params->protocol != PROTOCOL_TCP && params->protocol != PROTOCOL_UDP) ||
        params->dscp_value > 63) return RETURN_ERR;
    qos_rule = *params;
    return RETURN_OK;
}
