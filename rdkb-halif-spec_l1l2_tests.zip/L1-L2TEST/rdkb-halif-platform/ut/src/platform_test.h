/*
 * Copyright 2023 RDK Management. Licensed under the Apache License, Version 2.0.
 */
#ifndef PLATFORM_TEST_H
#define PLATFORM_TEST_H
#include <ut.h>
#include <ut_log.h>
#include "platform_hal.h"

extern int MaxEthPort;
extern char PartnerID[512];
extern char **factoryCmVariant, **InterfaceNames;
extern int num_FactoryCmVariant, num_InterfaceNames;
extern RDK_CPUS *supportedCpus;
extern int num_SupportedCPUs;
extern PSM_STATE *Supported_PSM_STATE;
extern int num_Supported_PSM_STATE;
extern int *FanIndex, num_FanIndex;
extern int init_platform_hal_init(void);
int load_platform_config(void);
void free_platform_config(void);

#define ADD_TEST(suite, fn) do { \
    if (!UT_add_test((suite), #fn, (fn))) return -1; \
} while (0)
#endif
