/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <stdio.h>
#include <stdlib.h>
#include <ut.h>
#include <ut_log.h>
#include "platform_hal.h"

extern int load_platform_config(void);
extern void free_platform_config(void);
extern int register_hal_l1_tests(void);
extern int register_hal_l2_tests(void);

static unsigned failed_assertions, failed_suites, tests_run;

/*
 * ut-core 1.7.0 clears all counters inside UT_run_tests(). Capture them at
 * its cleanup boundary without modifying the upstream framework or replacing
 * its basic/automated/console runner. Makefile supplies --wrap.
 */
void __real_CU_cleanup_registry(void);
void __wrap_CU_cleanup_registry(void)
{
    failed_assertions = CU_get_number_of_failures();
    failed_suites = CU_get_number_of_suites_failed();
    tests_run = CU_get_number_of_tests_run();
    fprintf(stderr, "PLATFORM_RESULT tests=%u assertions=%u failed=%u suites_failed=%u\n",
            tests_run, CU_get_number_of_asserts(), failed_assertions, failed_suites);
    __real_CU_cleanup_registry();
}

/** @brief Initialize only the subsystems required by these suites. */
int init_platform_hal_init(void)
{
    if (platform_hal_PandMDBInit() != RETURN_OK ||
        platform_hal_DocsisParamsDBInit() != RETURN_OK)
        return -1;
#ifdef FEATURE_RDKB_THERMAL_MANAGER
    THERMAL_PLATFORM_CONFIG thermal = {0};
    if (platform_hal_initThermal(&thermal) != RETURN_OK)
        return -1;
#endif
    return 0;
}

int main(int argc, char **argv)
{
    int result = EXIT_FAILURE;
    if (load_platform_config() != 0) {
        fprintf(stderr, "Invalid or missing platform configuration\n");
        goto done;
    }
    if (UT_init(argc, argv) != UT_STATUS_OK)
        goto done;
    if (register_hal_l1_tests() || register_hal_l2_tests() ||
        CU_get_error() != CUE_SUCCESS) {
        fprintf(stderr, "Platform suite registration failed\n");
        CU_cleanup_registry();
        goto done;
    }
    if (UT_run_tests() == UT_STATUS_OK && !failed_assertions && !failed_suites)
        result = EXIT_SUCCESS;
done:
    free_platform_config();
    return result;
}
