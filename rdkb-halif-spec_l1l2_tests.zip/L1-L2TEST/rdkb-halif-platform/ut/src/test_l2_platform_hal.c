/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
/**
 * @file test_l2_platform_hal.c
 * @page platform_hal_l2 Level 2 stateful Platform HAL tests
 * @brief Related operations, invariants and restoration, using public APIs only.
 *
 * Contract: ../../include/platform_hal.h and PlatformhalSpec.md.
 * After the first mutation ALL assertions are nonfatal so restoration executes.
 * No undocumented getters, reboot persistence, counter increments or low-power
 * state machine are invented. Hardware operation is not inferred from admin.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "platform_test.h"

static void test_l2_services_independence(void)
{
    BOOLEAN saved_ssh, saved_telnet, actual_ssh = 0, actual_telnet = 0;
    char saved_snmp[32] = {0}, actual_snmp[32] = {0};
    char *modes[] = {"rgWan", "rgDualIp", "rgLanIp"};
    UT_LOG("L2 snapshot -> service matrix -> independent reads -> restore");
    UT_ASSERT_EQUAL(platform_hal_GetSSHEnable(&saved_ssh), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetTelnetEnable(&saved_telnet), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetSNMPEnable(saved_snmp), RETURN_OK);
    for (int ssh = FALSE; ssh <= TRUE; ++ssh)
        for (int telnet = FALSE; telnet <= TRUE; ++telnet)
            for (size_t snmp = 0; snmp < 3; ++snmp) {
                UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetSSHEnable((BOOLEAN)ssh), RETURN_OK);
                UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetTelnetEnable((BOOLEAN)telnet), RETURN_OK);
                UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetSNMPEnable(modes[snmp]), RETURN_OK);
                UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetSSHEnable(&actual_ssh), RETURN_OK);
                UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetTelnetEnable(&actual_telnet), RETURN_OK);
                UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetSNMPEnable(actual_snmp), RETURN_OK);
                UT_ASSERT_EQUAL_NOT_FATAL(actual_ssh, ssh);
                UT_ASSERT_EQUAL_NOT_FATAL(actual_telnet, telnet);
                UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual_snmp, modes[snmp]);
            }
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetSSHEnable(saved_ssh), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetTelnetEnable(saved_telnet), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetSNMPEnable(saved_snmp), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetSSHEnable(&actual_ssh), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetTelnetEnable(&actual_telnet), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetSNMPEnable(actual_snmp), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual_ssh, saved_ssh);
    UT_ASSERT_EQUAL_NOT_FATAL(actual_telnet, saved_telnet);
    UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual_snmp, saved_snmp);
}
static void test_l2_rejected_settings_preserve_state(void)
{
    BOOLEAN ssh, telnet, actual = 0xa5;
    ULONG timeout, actual_timeout = 0;
    char snmp[32] = {0}, actual_snmp[32] = {0}, cm[512] = {0}, actual_cm[512] = {0};
    UT_LOG("L2 invalid setters must not corrupt accepted settings");
    UT_ASSERT_EQUAL(platform_hal_GetSSHEnable(&ssh), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetTelnetEnable(&telnet), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetSNMPEnable(snmp), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetWebUITimeout(&timeout), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_getFactoryCmVariant(cm), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetSSHEnable(2), RETURN_ERR);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetTelnetEnable(2), RETURN_ERR);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetSNMPEnable("invalid"), RETURN_ERR);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetWebUITimeout(29), RETURN_ERR);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setFactoryCmVariant("invalid"), RETURN_ERR);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetSSHEnable(&actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual, ssh);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetTelnetEnable(&actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual, telnet);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetSNMPEnable(actual_snmp), RETURN_OK);
    UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual_snmp, snmp);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetWebUITimeout(&actual_timeout), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual_timeout, timeout);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getFactoryCmVariant(actual_cm), RETURN_OK);
    UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual_cm, cm);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetSSHEnable(ssh), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetTelnetEnable(telnet), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetSNMPEnable(snmp), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetWebUITimeout(timeout), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setFactoryCmVariant(cm), RETURN_OK);
}
static void test_l2_web_timeout_cm_variant(void)
{
    ULONG saved_timeout, actual_timeout = 0;
    char saved_cm[512] = {0}, actual_cm[512] = {0};
    ULONG values[] = {0, 30, 86400, 840};
    UT_LOG("L2 WebUI/CM variant snapshot -> set/get -> independence -> restore");
    UT_ASSERT_EQUAL(platform_hal_GetWebUITimeout(&saved_timeout), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_getFactoryCmVariant(saved_cm), RETURN_OK);
    for (size_t i = 0; i < 4; ++i) {
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetWebUITimeout(values[i]), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getFactoryCmVariant(actual_cm), RETURN_OK);
        UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual_cm, saved_cm);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetWebUITimeout(&actual_timeout), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(actual_timeout, values[i]);
    }
    for (int i = 0; i < num_FactoryCmVariant; ++i) {
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setFactoryCmVariant(factoryCmVariant[i]), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getFactoryCmVariant(actual_cm), RETURN_OK);
        UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual_cm, factoryCmVariant[i]);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetWebUITimeout(&actual_timeout), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(actual_timeout, 840);
    }
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetWebUITimeout(saved_timeout), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setFactoryCmVariant(saved_cm), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetWebUITimeout(&actual_timeout), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual_timeout, saved_timeout);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getFactoryCmVariant(actual_cm), RETURN_OK);
    UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual_cm, saved_cm);
}
static void test_l2_web_access_independence(void)
{
    ULONG saved_a, saved_b, actual = 0;
    UT_LOG("L2 deprecated web access still round-trips and isolates keys");
    UT_ASSERT_EQUAL(platform_hal_GetWebAccessLevel(1, 1, &saved_a), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetWebAccessLevel(5, 40, &saved_b), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetWebAccessLevel(1, 1, 7), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetWebAccessLevel(5, 40, &actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual, saved_b);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetWebAccessLevel(5, 40, 9), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetWebAccessLevel(1, 1, &actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual, 7);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetWebAccessLevel(5, 40, &actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual, 9);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetWebAccessLevel(1, 1, saved_a), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetWebAccessLevel(5, 40, saved_b), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetWebAccessLevel(1, 1, &actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual, saved_a);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetWebAccessLevel(5, 40, &actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual, saved_b);
}
static void test_l2_led_round_trip(void)
{
    LEDMGMT_PARAMS saved = {0}, value = {0}, actual = {0};
#ifdef FEATURE_RDKB_LED_MANAGER
    char saved_name[128], saved_param[128];
    char input_name[] = "reference-test", input_param[] = "stateful";
#endif
    UT_LOG("L2 LED snapshot -> set/get -> restore under the selected ABI");
    UT_ASSERT_EQUAL(platform_hal_getLed(&saved), RETURN_OK);
#ifdef FEATURE_RDKB_LED_MANAGER
    UT_ASSERT_PTR_NOT_NULL(saved.led_name);
    UT_ASSERT_PTR_NOT_NULL(saved.led_param);
    UT_ASSERT_TRUE(strnlen(saved.led_name, sizeof(saved_name)) < sizeof(saved_name));
    UT_ASSERT_TRUE(strnlen(saved.led_param, sizeof(saved_param)) < sizeof(saved_param));
    strcpy(saved_name, saved.led_name); strcpy(saved_param, saved.led_param);
    saved.led_name = saved_name; saved.led_param = saved_param;
    value.led_name = input_name; value.led_param = input_param;
#endif
    value.LedColor = LED_BLUE; value.State = 1; value.Interval = 2;
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setLed(&value), RETURN_OK);
#ifdef FEATURE_RDKB_LED_MANAGER
#ifdef BUILD_LINUX
    input_name[0] = 'X'; input_param[0] = 'X'; /* prove local model deep copy */
#endif
#endif
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getLed(&actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual.LedColor, value.LedColor);
    UT_ASSERT_EQUAL_NOT_FATAL(actual.State, value.State);
    UT_ASSERT_EQUAL_NOT_FATAL(actual.Interval, value.Interval);
#ifdef FEATURE_RDKB_LED_MANAGER
    UT_ASSERT_PTR_NOT_NULL_NOT_FATAL(actual.led_name);
    UT_ASSERT_PTR_NOT_NULL_NOT_FATAL(actual.led_param);
    if (actual.led_name && actual.led_param) {
        UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual.led_name, "reference-test");
        UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual.led_param, "stateful");
    }
#endif
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setLed(&saved), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getLed(&actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual.LedColor, saved.LedColor);
    UT_ASSERT_EQUAL_NOT_FATAL(actual.State, saved.State);
    UT_ASSERT_EQUAL_NOT_FATAL(actual.Interval, saved.Interval);
#ifdef FEATURE_RDKB_LED_MANAGER
    if (actual.led_name && actual.led_param) {
        UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual.led_name, saved_name);
        UT_ASSERT_STRING_EQUAL_NOT_FATAL(actual.led_param, saved_param);
    } else UT_FAIL_NOT_FATAL("Restored LED strings are missing");
#endif
}
static void test_l2_fan_override(void)
{
    UT_LOG("L2 fan raw observations -> override -> restore");
    /*
     * There is no override getter. L1 leaves the reference override disabled;
     * snapshot/restore its observable RPM, not an invented private getter.
     * This is a serialized reference-profile precondition, not vendor discovery.
     */
    for (int i = 0; i < num_FanIndex; ++i) {
        UINT fan = (UINT)FanIndex[i], saved = platform_hal_getFanSpeed(fan);
        UINT saved_rpm = platform_hal_getRPM(fan);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setFanMaxOverride(TRUE, fan), RETURN_OK);
#ifdef BUILD_LINUX
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getFanSpeed(fan), 4000);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getRPM(fan), 4000);
#endif
#ifdef FEATURE_RDKB_THERMAL_MANAGER
        FAN_ERR reason = FAN_ERR_NONE;
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setFanSpeed(fan, FAN_SPEED_OFF, &reason), RETURN_ERR);
        UT_ASSERT_EQUAL_NOT_FATAL(reason, FAN_ERR_MAX_OVERRIDE_SET);
#endif
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setFanMaxOverride(FALSE, fan), RETURN_OK);
#ifdef BUILD_LINUX
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getFanSpeed(fan), saved);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getRPM(fan), saved_rpm);
#else
        (void)saved; (void)saved_rpm;
#endif
    }
}
static void test_l2_macsec_admin_sequence(void)
{
    UT_LOG("L2 MACsec admin sequencing; operational is an independent Boolean");
    for (int port = 0; port < MaxEthPort; ++port) {
        BOOLEAN saved, actual = FALSE, operational = FALSE;
        UT_ASSERT_EQUAL(platform_hal_GetMACsecEnable(port, &saved), RETURN_OK);
        for (int enabled = FALSE; enabled <= TRUE; ++enabled) {
            UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetMACsecEnable(port, (BOOLEAN)enabled), RETURN_OK);
            UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetMACsecEnable(port, &actual), RETURN_OK);
            UT_ASSERT_EQUAL_NOT_FATAL(actual, enabled);
            UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_StartMACsec(port, 0), RETURN_OK);
            UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetMACsecOperationalStatus(port, &operational), RETURN_OK);
            UT_ASSERT_TRUE_NOT_FATAL(operational == FALSE || operational == TRUE);
#ifdef BUILD_LINUX
            UT_ASSERT_EQUAL_NOT_FATAL(operational, FALSE); /* no physical driver */
#endif
            UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_StopMACsec(port), RETURN_OK);
        }
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetMACsecEnable(port, saved), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetMACsecEnable(port, &actual), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(actual, saved);
    }
}
static void test_l2_reset_count(void)
{
    ULONG saved = 0, actual = 0;
    UT_LOG("L2 FALSE preserves reset count; TRUE clears irreversibly");
    UT_ASSERT_EQUAL(platform_hal_GetFactoryResetCount(&saved), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_ClearResetCount(FALSE), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetFactoryResetCount(&actual), RETURN_OK);
    UT_ASSERT_EQUAL(actual, saved);
#ifndef BUILD_LINUX
    if (!getenv("PLATFORM_ALLOW_RESET_COUNT_CLEAR")) {
        UT_LOG("SKIP destructive TRUE clear: PLATFORM_ALLOW_RESET_COUNT_CLEAR not set");
        return;
    }
#endif
    /* No setter exists to restore the count. Never claim snapshot restoration. */
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_ClearResetCount(TRUE), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetFactoryResetCount(&actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual, 0);
}
static int list_csv(const DSCP_list_t *list, char csv[196])
{
    size_t used = 0;
    csv[0] = 0;
    if (list->numElements > 64) return -1;
    for (UINT i = 0; i < list->numElements; ++i) {
        int n = snprintf(csv + used, 196 - used, "%s%u", i ? "," : "",
                         list->DSCP_Element[i].dscp_value);
        if (n < 0 || (size_t)n >= 196 - used) return -1;
        used += (size_t)n;
    }
    return 0;
}
static void test_l2_dscp_wan_isolation(void)
{
    DSCP_list_t *saved = calloc(WAN_INTERFACE_MAX, sizeof(*saved));
    DSCP_list_t *actual = calloc(1, sizeof(*actual));
    DSCP_list_t *other = calloc(1, sizeof(*other));
    char csv[WAN_INTERFACE_MAX][196];
    int ready = saved && actual && other;
    UT_LOG("L2 per-WAN snapshot -> start/list/reset/stop -> restore");
    UT_ASSERT_TRUE_NOT_FATAL(ready);
    if (!ready) goto done;
    /* Validate all snapshots BEFORE the first mutation. */
    for (int iface = DOCSIS; iface < WAN_INTERFACE_MAX; ++iface) {
        int status = platform_hal_getDscpClientList((WAN_INTERFACE)iface, &saved[iface]);
        UT_ASSERT_EQUAL_NOT_FATAL(status, RETURN_OK);
        if (status || list_csv(&saved[iface], csv[iface])) ready = 0;
    }
    UT_ASSERT_TRUE_NOT_FATAL(ready);
    if (!ready) goto done;
    for (int iface = DOCSIS; iface < WAN_INTERFACE_MAX; ++iface) {
        int peer = iface == XGSPON ? DOCSIS : iface + 1;
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getDscpClientList((WAN_INTERFACE)peer, other), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setDscp((WAN_INTERFACE)iface, TRAFFIC_CNT_START, "0,10"), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getDscpClientList((WAN_INTERFACE)iface, actual), RETURN_OK);
#ifdef BUILD_LINUX
        UT_ASSERT_EQUAL_NOT_FATAL(actual->numElements, 2);
        UT_ASSERT_EQUAL_NOT_FATAL(actual->DSCP_Element[0].dscp_value, 0);
        UT_ASSERT_EQUAL_NOT_FATAL(actual->DSCP_Element[1].dscp_value, 10);
#endif
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_resetDscpCounts((WAN_INTERFACE)iface), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getDscpClientList((WAN_INTERFACE)iface, actual), RETURN_OK);
        UT_ASSERT_TRUE_NOT_FATAL(actual->numElements <= 64);
        if (actual->numElements <= 64)
            for (UINT i = 0; i < actual->numElements; ++i) {
                DSCP_Element_t *e = &actual->DSCP_Element[i];
                UT_ASSERT_TRUE_NOT_FATAL(e->numClients <= 256);
                if (e->numClients <= 256)
                    for (UINT j = 0; j < e->numClients; ++j) {
                        UT_ASSERT_EQUAL_NOT_FATAL(e->Client[j].rxBytes, 0);
                        UT_ASSERT_EQUAL_NOT_FATAL(e->Client[j].txBytes, 0);
                    }
#ifdef BUILD_LINUX
                UT_ASSERT_EQUAL_NOT_FATAL(e->numClients, 0); /* never invent clients */
#endif
            }
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getDscpClientList((WAN_INTERFACE)peer, actual), RETURN_OK);
#ifdef BUILD_LINUX
        UT_ASSERT_EQUAL_NOT_FATAL(memcmp(other, actual, sizeof(*other)), 0);
#endif
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setDscp((WAN_INTERFACE)iface, TRAFFIC_CNT_STOP, NULL), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getDscpClientList((WAN_INTERFACE)iface, actual), RETURN_OK);
#ifdef BUILD_LINUX
        UT_ASSERT_EQUAL_NOT_FATAL(actual->numElements, 0);
#endif
        if (saved[iface].numElements)
            UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setDscp((WAN_INTERFACE)iface, TRAFFIC_CNT_START, csv[iface]), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getDscpClientList((WAN_INTERFACE)iface, actual), RETURN_OK);
#ifdef BUILD_LINUX
        UT_ASSERT_EQUAL_NOT_FATAL(memcmp(&saved[iface], actual, sizeof(*actual)), 0);
#endif
    }
done:
    free(saved); free(actual); free(other);
}
static void test_l2_memory_invariants(void)
{
    ULONG total = 0, used = 0, available = 0;
    char flash[256] = {0}, flash_used[1024] = {0}, flash_free[1024] = {0};
    UT_LOG("L2 memory invariants, subtraction avoids unsigned overflow");
    UT_ASSERT_EQUAL(platform_hal_GetTotalMemorySize(&total), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetUsedMemorySize(&used), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetFreeMemorySize(&available), RETURN_OK);
    UT_ASSERT_TRUE(total > 0);
    UT_ASSERT_TRUE(used <= total);
    UT_ASSERT_TRUE(available <= total - used);
    UT_ASSERT_EQUAL(platform_hal_GetHardware(flash), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetHardware_MemUsed(flash_used), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_GetHardware_MemFree(flash_free), RETURN_OK);
    total = strtoul(flash, NULL, 10);
    used = strtoul(flash_used, NULL, 10);
    available = strtoul(flash_free, NULL, 10);
    UT_ASSERT_TRUE(total >= 1 && total <= 4096);
    UT_ASSERT_TRUE(used <= total);
    UT_ASSERT_TRUE(available <= total - used);
}
static void test_l2_identity_firmware_repeatability(void)
{
    typedef INT (*identity_getter)(CHAR *);
    identity_getter getters[] = {platform_hal_GetModelName, platform_hal_GetSerialNumber,
        platform_hal_GetHardwareVersion, platform_hal_GetBaseMacAddress,
        platform_hal_getFactoryPartnerId};
    char before[512] = {0}, after[512] = {0};
    UT_LOG("L2 repeat immutable identity and firmware metadata");
    for (size_t i = 0; i < sizeof(getters)/sizeof(*getters); ++i) {
        UT_ASSERT_EQUAL(getters[i](before), RETURN_OK);
        for (int repeat = 0; repeat < 3; ++repeat) {
            UT_ASSERT_EQUAL(getters[i](after), RETURN_OK);
            UT_ASSERT_STRING_EQUAL(before, after);
        }
    }
    for (int bank = ACTIVE_BANK; bank <= INACTIVE_BANK; ++bank) {
        FW_BANK_INFO first = {0}, next = {0};
        UT_ASSERT_EQUAL(platform_hal_GetFirmwareBankInfo((FW_BANK)bank, &first), RETURN_OK);
        for (int repeat = 0; repeat < 3; ++repeat) {
            UT_ASSERT_EQUAL(platform_hal_GetFirmwareBankInfo((FW_BANK)bank, &next), RETURN_OK);
            UT_ASSERT_STRING_EQUAL(first.fw_name, next.fw_name);
            UT_ASSERT_STRING_EQUAL(first.fw_state, next.fw_state);
        }
    }
    typedef INT (*sized_getter)(CHAR *, ULONG);
    sized_getter versions[] = {platform_hal_GetSoftwareVersion,
        platform_hal_GetBootloaderVersion, platform_hal_GetFirmwareName};
    for (size_t i = 0; i < sizeof(versions)/sizeof(*versions); ++i) {
        UT_ASSERT_EQUAL(versions[i](before, sizeof(before)), RETURN_OK);
        UT_ASSERT_EQUAL(versions[i](after, sizeof(after)), RETURN_OK);
        UT_ASSERT_STRING_EQUAL(before, after);
    }
}
int test_platform_hal_l2_register(void)
{
    UT_test_suite_t *suite = UT_add_suite("L2 platform HAL stateful modules", init_platform_hal_init, NULL);
    if (!suite) return -1;
    ADD_TEST(suite, test_l2_services_independence);
    ADD_TEST(suite, test_l2_rejected_settings_preserve_state);
    ADD_TEST(suite, test_l2_web_timeout_cm_variant);
    ADD_TEST(suite, test_l2_web_access_independence);
    ADD_TEST(suite, test_l2_led_round_trip);
    ADD_TEST(suite, test_l2_fan_override);
    ADD_TEST(suite, test_l2_macsec_admin_sequence);
    ADD_TEST(suite, test_l2_dscp_wan_isolation);
    ADD_TEST(suite, test_l2_memory_invariants);
    ADD_TEST(suite, test_l2_identity_firmware_repeatability);
    ADD_TEST(suite, test_l2_reset_count);
    return 0;
}
