/*
 * Copyright 2023 RDK Management. Licensed under the Apache License, Version 2.0.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"
#include "platform_test.h"

int MaxEthPort;
char PartnerID[512];
char **factoryCmVariant, **InterfaceNames;
int num_FactoryCmVariant, num_InterfaceNames;
RDK_CPUS *supportedCpus;
int num_SupportedCPUs;
PSM_STATE *Supported_PSM_STATE;
int num_Supported_PSM_STATE;
int *FanIndex, num_FanIndex;

static void free_strings(char ***values, int *count)
{
    for (int i = 0; i < *count; ++i)
        free((*values)[i]);
    free(*values);
    *values = NULL;
    *count = 0;
}

void free_platform_config(void)
{
    free_strings(&factoryCmVariant, &num_FactoryCmVariant);
    free_strings(&InterfaceNames, &num_InterfaceNames);
    free(supportedCpus); supportedCpus = NULL; num_SupportedCPUs = 0;
    free(Supported_PSM_STATE); Supported_PSM_STATE = NULL; num_Supported_PSM_STATE = 0;
    free(FanIndex); FanIndex = NULL; num_FanIndex = 0;
    MaxEthPort = 0;
    PartnerID[0] = '\0';
}

static int integer(const cJSON *v, int low, int high)
{
    return cJSON_IsNumber(v) && v->valuedouble >= low &&
           v->valuedouble <= high && v->valuedouble == v->valueint;
}

static int strings(cJSON *root, const char *key, char ***out, int *count,
                   int max_count, size_t capacity)
{
    cJSON *array = cJSON_GetObjectItemCaseSensitive(root, key);
    int n = cJSON_GetArraySize(array);
    if (!cJSON_IsArray(array) || n < 1 || n > max_count)
        return -1;
    *out = calloc((size_t)n, sizeof(**out));
    if (!*out) return -1;
    *count = n;
    for (int i = 0; i < n; ++i) {
        cJSON *v = cJSON_GetArrayItem(array, i);
        if (!cJSON_IsString(v) || !v->valuestring[0] ||
            strlen(v->valuestring) >= capacity) return -1;
        for (int j = 0; j < i; ++j)
            if (!strcmp((*out)[j], v->valuestring)) return -1;
        (*out)[i] = strdup(v->valuestring);
        if (!(*out)[i]) return -1;
    }
    return 0;
}

static int numbers(cJSON *root, const char *key, int **out, int *count,
                   int low, int high)
{
    cJSON *array = cJSON_GetObjectItemCaseSensitive(root, key);
    int n = cJSON_GetArraySize(array);
    if (!cJSON_IsArray(array) || n < 1 || n > high - low + 1) return -1;
    *out = calloc((size_t)n, sizeof(**out));
    if (!*out) return -1;
    *count = n;
    for (int i = 0; i < n; ++i) {
        cJSON *v = cJSON_GetArrayItem(array, i);
        if (!integer(v, low, high)) return -1;
        for (int j = 0; j < i; ++j)
            if ((*out)[j] == v->valueint) return -1;
        (*out)[i] = v->valueint;
    }
    return 0;
}

/** @brief Load one complete profile, never leave partially valid globals. */
int load_platform_config(void)
{
    const char *path = getenv("PLATFORM_CONFIG");
    FILE *file = NULL;
    char *text = NULL;
    cJSON *root = NULL, *v;
    int result = -1, *cpus = NULL, *states = NULL, ncpu = 0, nstate = 0;
    long length;
    free_platform_config();
    if (!path) path = "platform_config";
    file = fopen(path, "rb");
    if (!file) { perror(path); goto done; }
    if (fseek(file, 0, SEEK_END) || (length = ftell(file)) < 1 ||
        length > 65536 || fseek(file, 0, SEEK_SET)) goto done;
    text = calloc((size_t)length + 1, 1);
    if (!text || fread(text, 1, (size_t)length, file) != (size_t)length ||
        memchr(text, '\0', (size_t)length)) goto done;
    root = cJSON_ParseWithOpts(text, NULL, 1);
    if (!cJSON_IsObject(root)) goto done;
    v = cJSON_GetObjectItemCaseSensitive(root, "MaxEthPort");
    if (!integer(v, 1, 64)) goto done;
    MaxEthPort = v->valueint;
    v = cJSON_GetObjectItemCaseSensitive(root, "PartnerID");
    if (!cJSON_IsString(v) || !v->valuestring[0] ||
        strlen(v->valuestring) >= sizeof(PartnerID)) goto done;
    {
        const char *partners[] = {"unknown", "eUnprogrammed", "eComcast", "eCharter",
            "eCox", "eRogers", "eVodafone", "eShaw", "eVideotron"};
        int found = 0;
        for (size_t i = 0; i < sizeof(partners)/sizeof(*partners); ++i)
            found |= !strcmp(v->valuestring, partners[i]);
        if (!found) goto done;
    }
    strcpy(PartnerID, v->valuestring);
    if (strings(root, "FactoryCmVariant", &factoryCmVariant, &num_FactoryCmVariant, 5, 512) ||
        strings(root, "InterfaceNames", &InterfaceNames, &num_InterfaceNames, 64, 16) ||
        numbers(root, "Supported_CPUS", &cpus, &ncpu, HOST_CPU, PEER_CPU) ||
        numbers(root, "Supported_PSM_STATE", &states, &nstate, PSM_UNKNOWN, PSM_NOT_SUPPORTED) ||
        numbers(root, "FanIndex", &FanIndex, &num_FanIndex, 0, 1)) goto done;
    for (int i = 0; i < num_FactoryCmVariant; ++i) {
        const char *variants[] = {"unknown", "pc20", "pc20genband", "pc15sip", "pc15mgcp"};
        int found = 0;
        for (size_t j = 0; j < sizeof(variants)/sizeof(*variants); ++j)
            found |= !strcmp(factoryCmVariant[i], variants[j]);
        if (!found) goto done;
    }
    supportedCpus = calloc((size_t)ncpu, sizeof(*supportedCpus));
    Supported_PSM_STATE = calloc((size_t)nstate, sizeof(*Supported_PSM_STATE));
    if (!supportedCpus || !Supported_PSM_STATE) goto done;
    num_SupportedCPUs = ncpu;
    num_Supported_PSM_STATE = nstate;
    for (int i = 0; i < ncpu; ++i) supportedCpus[i] = (RDK_CPUS)cpus[i];
    for (int i = 0; i < nstate; ++i) Supported_PSM_STATE[i] = (PSM_STATE)states[i];
    result = 0;
done:
    free(cpus); free(states);
    cJSON_Delete(root); free(text);
    if (file) fclose(file);
    if (result) free_platform_config();
    return result;
}
