/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
/**
 * @file test_l1_platform_hal.c
 * @page platform_hal_l1 Level 1 Platform HAL contract tests
 * @brief Positive/negative function tests for every declared public API.
 *
 * Evidence: ../../include/platform_hal.h and
 * ../../docs/pages/PlatformhalSpec.md. Shared helpers deliberately retain
 * status AND output validation. Typed configuration is loaded once by main.
 * BUILD_LINUX checks labeled "reference" are local-model policies, not vendor
 * requirements. In particular, raw UINT fan measurements are NOT status codes,
 * and tagged unions cannot reveal which IP member a caller previously wrote.
 */
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "platform_test.h"

static int valid_text(const char *s, size_t capacity)
{
    return memchr(s, 0, capacity) != NULL && s[0] != 0;
}
static int mac_address(const char *s)
{
    if (strlen(s) != 17) return 0;
    for (int i = 0; i < 17; ++i)
        if (i % 3 == 2 ? s[i] != ':' : !isxdigit((unsigned char)s[i])) return 0;
    return 1;
}
static int decimal(const char *s, unsigned long low, unsigned long high)
{
    char *end;
    unsigned long value;
    if (!*s || !isdigit((unsigned char)*s)) return 0;
    errno = 0;
    value = strtoul(s, &end, 10);
    return !errno && !*end && value >= low && value <= high;
}
static int any_text(const char *s) { return *s != 0; }
static int device_status(const char *s)
{
    return !strcmp(s, "WaitForImplement") || !strcmp(s, "In Progress") || !strcmp(s, "Complete");
}
static int region(const char *s)
{
    return !strcmp(s, "REGION_UK") || !strcmp(s, "REGION_IT") ||
           !strcmp(s, "REGION_ROI") || !strcmp(s, "REGION_UNKNOWN");
}
static int snmp_value(const char *s)
{
    return !strcmp(s, "rgWan") || !strcmp(s, "rgDualIp") || !strcmp(s, "rgLanIp");
}
static int flash_total(const char *s) { return decimal(s, 1, 4096); }
static int flash_part(const char *s)
{
    char total[256];
    if (platform_hal_GetHardware(total) || !valid_text(total, sizeof(total)) ||
        !flash_total(total)) return 0;
    return decimal(s, 1, strtoul(total, NULL, 10));
}
static int offset_value(const char *s)
{
    return !strcmp(s, "-18000") || !strcmp(s, "-25200") || !strcmp(s, "+25200");
}
static int partner_value(const char *s) { return !strcmp(s, PartnerID); }
static int variant_value(const char *s)
{
    return !strcmp(s, "unknown") || !strcmp(s, "pc20") ||
           !strcmp(s, "pc20genband") || !strcmp(s, "pc15sip") || !strcmp(s, "pc15mgcp");
}
static int cpu_value(const char *s)
{
    char *end;
    long double value;
    errno = 0;
    value = strtold(s, &end);
    return end != s && !*end && !errno && isfinite(value) &&
           value >= 0 && value <= (long double)ULLONG_MAX;
}

/** @brief Lengthless getters: real header capacity, termination, domain, NULL. */
#define TEXT_TEST(api, capacity, validator) \
static void test_l1_platform_hal_positive1_##api(void) { \
    char out[capacity]; memset(out, 0xa5, sizeof(out)); \
    UT_LOG("L1 " #api " output and domain"); \
    UT_ASSERT_EQUAL(platform_hal_##api(out), RETURN_OK); \
    UT_ASSERT_TRUE(valid_text(out, sizeof(out))); \
    UT_ASSERT_TRUE(validator(out)); \
} \
static void test_l1_platform_hal_negative1_##api(void) { \
    UT_LOG("L1 " #api " NULL"); \
    UT_ASSERT_EQUAL(platform_hal_##api(NULL), RETURN_ERR); \
}
TEXT_TEST(GetDeviceConfigStatus, 128, device_status)
TEXT_TEST(GetModelName, 256, any_text)
TEXT_TEST(GetRouterRegion, 256, region)
TEXT_TEST(GetSerialNumber, 256, any_text)
TEXT_TEST(GetHardwareVersion, 256, any_text)
TEXT_TEST(GetSNMPEnable, 32, snmp_value)
TEXT_TEST(GetBaseMacAddress, 256, mac_address)
TEXT_TEST(GetHardware, 256, flash_total)
TEXT_TEST(GetHardware_MemUsed, 1024, flash_part)
TEXT_TEST(GetHardware_MemFree, 1024, flash_part)
TEXT_TEST(getTimeOffSet, 256, offset_value)
TEXT_TEST(getFactoryPartnerId, 512, partner_value)
TEXT_TEST(getFactoryCmVariant, 512, variant_value)
TEXT_TEST(getCMTSMac, 100, mac_address)
TEXT_TEST(GetCPUSpeed, 64, cpu_value)

/** @brief Explicit capacities: exact fit, undersized, zero, NULL, canaries. */
#define SIZED_TEST(api) \
static void test_l1_platform_hal_positive1_##api(void) { \
    char out[256]; memset(out, 0xa5, sizeof(out)); \
    UT_LOG("L1 " #api " valid capacity"); \
    UT_ASSERT_EQUAL(platform_hal_##api(out, sizeof(out)), RETURN_OK); \
    UT_ASSERT_TRUE(valid_text(out, sizeof(out))); \
    memset(out, 0, sizeof(out)); \
} \
static void test_l1_platform_hal_positive2_##api(void) { \
    char out[256] = {0}, exact[258]; \
    UT_ASSERT_EQUAL(platform_hal_##api(out, sizeof(out)), RETURN_OK); \
    UT_ASSERT_TRUE(valid_text(out, sizeof(out))); \
    size_t n = strlen(out) + 1; memset(exact, 0xa5, sizeof(exact)); \
    UT_ASSERT_EQUAL(platform_hal_##api(exact + 1, n), RETURN_OK); \
    UT_ASSERT_TRUE(valid_text(exact + 1, n)); \
    UT_ASSERT_EQUAL((unsigned char)exact[0], 0xa5); \
    UT_ASSERT_EQUAL((unsigned char)exact[n + 1], 0xa5); \
    UT_ASSERT_STRING_EQUAL(exact + 1, out); \
    memset(out, 0, sizeof(out)); memset(exact, 0, sizeof(exact)); \
} \
static void test_l1_platform_hal_negative1_##api(void) { \
    UT_ASSERT_EQUAL(platform_hal_##api(NULL, 256), RETURN_ERR); \
    UT_ASSERT_EQUAL(platform_hal_##api(NULL, 0), RETURN_ERR); \
} \
static void test_l1_platform_hal_negative2_##api(void) { \
    char out[256]; memset(out, 0xa5, sizeof(out)); \
    UT_ASSERT_EQUAL(platform_hal_##api(out, 0), RETURN_ERR); \
    UT_ASSERT_EQUAL((unsigned char)out[0], 0xa5); \
} \
static void test_l1_platform_hal_negative3_##api(void) { \
    char out[256] = {0}, small[258]; \
    UT_ASSERT_EQUAL(platform_hal_##api(out, sizeof(out)), RETURN_OK); \
    UT_ASSERT_TRUE(valid_text(out, sizeof(out))); \
    size_t n = strlen(out); memset(small, 0xa5, sizeof(small)); \
    UT_ASSERT_EQUAL(platform_hal_##api(small + 1, n), RETURN_ERR); \
    UT_ASSERT_EQUAL((unsigned char)small[0], 0xa5); \
    UT_ASSERT_EQUAL((unsigned char)small[n + 1], 0xa5); \
    memset(out, 0, sizeof(out)); memset(small, 0, sizeof(small)); \
}
SIZED_TEST(GetSoftwareVersion)
SIZED_TEST(GetBootloaderVersion)
SIZED_TEST(GetFirmwareName)
SIZED_TEST(GetPppUserName)
SIZED_TEST(GetPppPassword)

/** @brief Boolean input and output domains, not unsigned tautologies. */
#define BOOL_GET(api) \
static void test_l1_platform_hal_positive1_##api(void) { \
    BOOLEAN out = 0xa5; \
    UT_ASSERT_EQUAL(platform_hal_##api(&out), RETURN_OK); \
    UT_ASSERT_TRUE(out == FALSE || out == TRUE); \
} \
static void test_l1_platform_hal_negative1_##api(void) { \
    UT_ASSERT_EQUAL(platform_hal_##api(NULL), RETURN_ERR); \
}
BOOL_GET(GetSSHEnable)
BOOL_GET(GetTelnetEnable)
#define BOOL_SET(api) \
static void test_l1_platform_hal_positive1_##api(void) { \
    UT_LOG("L1 " #api " Boolean boundary values"); \
    UT_ASSERT_EQUAL(platform_hal_##api(FALSE), RETURN_OK); \
    UT_ASSERT_EQUAL(platform_hal_##api(TRUE), RETURN_OK); \
} \
static void test_l1_platform_hal_negative1_##api(void) { \
    UT_ASSERT_EQUAL(platform_hal_##api(2), RETURN_ERR); \
    UT_ASSERT_EQUAL(platform_hal_##api(255), RETURN_ERR); \
}
BOOL_SET(SetSSHEnable)
BOOL_SET(SetTelnetEnable)
BOOL_SET(SetDeviceCodeImageValid)

/** @brief Scalar output validation. A reset count may legitimately be zero. */
#define NUMBER_GET(api, condition) \
static void test_l1_platform_hal_positive1_##api(void) { \
    ULONG out = 0; \
    UT_ASSERT_EQUAL(platform_hal_##api(&out), RETURN_OK); \
    UT_ASSERT_TRUE(condition); \
} \
static void test_l1_platform_hal_negative1_##api(void) { \
    UT_ASSERT_EQUAL(platform_hal_##api(NULL), RETURN_ERR); \
}
NUMBER_GET(GetTotalMemorySize, out > 0)
NUMBER_GET(GetUsedMemorySize, out > 0)
NUMBER_GET(GetFreeMemorySize, out > 0)
NUMBER_GET(GetFactoryResetCount, platform_hal_ClearResetCount(FALSE) == RETURN_OK)
NUMBER_GET(GetWebUITimeout, out == 0 || (out >= 30 && out <= 86400))

static void test_l1_platform_hal_positive1_PandMDBInit(void)
{
    UT_ASSERT_EQUAL(platform_hal_PandMDBInit(), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_PandMDBInit(), RETURN_OK);
}
static void test_l1_platform_hal_positive1_DocsisParamsDBInit(void)
{
    UT_ASSERT_EQUAL(platform_hal_DocsisParamsDBInit(), RETURN_OK);
    UT_ASSERT_EQUAL(platform_hal_DocsisParamsDBInit(), RETURN_OK);
}
static void test_l1_platform_hal_positive1_SetSNMPEnable(void)
{
    char *values[] = {"rgWan", "rgDualIp", "rgLanIp"};
    for (size_t i = 0; i < 3; ++i)
        UT_ASSERT_EQUAL(platform_hal_SetSNMPEnable(values[i]), RETURN_OK);
}
static void test_l1_platform_hal_negative1_SetSNMPEnable(void)
{
    UT_ASSERT_EQUAL(platform_hal_SetSNMPEnable(NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_SetSNMPEnable(""), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_SetSNMPEnable("invalid"), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_SetWebUITimeout(void)
{
    ULONG values[] = {0, 30, 840, 86400};
    for (size_t i = 0; i < 4; ++i)
        UT_ASSERT_EQUAL(platform_hal_SetWebUITimeout(values[i]), RETURN_OK);
}
static void test_l1_platform_hal_negative1_SetWebUITimeout(void)
{
    ULONG values[] = {1, 29, 86401, ULONG_MAX};
    for (size_t i = 0; i < 4; ++i)
        UT_ASSERT_EQUAL(platform_hal_SetWebUITimeout(values[i]), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_GetWebAccessLevel(void)
{
    const int users[] = {1, 5, 10, INT_MIN, INT_MAX};
    const int interfaces[] = {1, 2, 16, 40, INT_MIN, INT_MAX};
    for (size_t i = 0; i < 5; ++i)
        for (size_t j = 0; j < 6; ++j) {
            ULONG out = ULONG_MAX;
            UT_ASSERT_EQUAL(platform_hal_GetWebAccessLevel(users[i], interfaces[j], &out), RETURN_OK);
            UT_ASSERT_TRUE(out <= INT_MAX);
        }
}
static void test_l1_platform_hal_negative1_GetWebAccessLevel(void)
{
    UT_ASSERT_EQUAL(platform_hal_GetWebAccessLevel(1, 1, NULL), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_SetWebAccessLevel(void)
{
    ULONG saved = 0, actual = 0;
    UT_ASSERT_EQUAL(platform_hal_GetWebAccessLevel(INT_MIN, INT_MAX, &saved), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetWebAccessLevel(INT_MIN, INT_MAX, INT_MAX), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_GetWebAccessLevel(INT_MIN, INT_MAX, &actual), RETURN_OK);
    UT_ASSERT_EQUAL_NOT_FATAL(actual, INT_MAX);
    UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetWebAccessLevel(INT_MIN, INT_MAX, saved), RETURN_OK);
}
static void test_l1_platform_hal_negative1_SetWebAccessLevel(void)
{
    UT_ASSERT_EQUAL(platform_hal_SetWebAccessLevel(1, 1, (ULONG)INT_MAX + 1), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_SetWebAccessLevel(1, 1, ULONG_MAX), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_ClearResetCount(void)
{
    UT_ASSERT_EQUAL(platform_hal_ClearResetCount(FALSE), RETURN_OK);
}
static void test_l1_platform_hal_negative1_ClearResetCount(void)
{
    UT_ASSERT_EQUAL(platform_hal_ClearResetCount(2), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_ClearResetCount(255), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_SetDeviceCodeImageTimeout(void)
{
    int values[] = {0, 1, 3599, 3600};
    for (size_t i = 0; i < 4; ++i)
        UT_ASSERT_EQUAL(platform_hal_SetDeviceCodeImageTimeout(values[i]), RETURN_OK);
}
static void test_l1_platform_hal_negative1_SetDeviceCodeImageTimeout(void)
{
    UT_ASSERT_EQUAL(platform_hal_SetDeviceCodeImageTimeout(-1), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_SetDeviceCodeImageTimeout(3601), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_SetDeviceCodeImageTimeout(INT_MAX), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_setFactoryCmVariant(void)
{
    for (int i = 0; i < num_FactoryCmVariant; ++i)
        UT_ASSERT_EQUAL(platform_hal_setFactoryCmVariant(factoryCmVariant[i]), RETURN_OK);
}
static void test_l1_platform_hal_negative1_setFactoryCmVariant(void)
{
    char long_value[513]; memset(long_value, 'x', 512); long_value[512] = 0;
    UT_ASSERT_EQUAL(platform_hal_setFactoryCmVariant(NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_setFactoryCmVariant(""), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_setFactoryCmVariant("invalid"), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_setFactoryCmVariant(long_value), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_SetSNMPOnboardRebootEnable(void)
{
    char *values[] = {"enable", "disable", "ENABLE", "Disable"};
    for (size_t i = 0; i < 4; ++i)
        UT_ASSERT_EQUAL(platform_hal_SetSNMPOnboardRebootEnable(values[i]), RETURN_OK);
}
static void test_l1_platform_hal_negative1_SetSNMPOnboardRebootEnable(void)
{
    UT_ASSERT_EQUAL(platform_hal_SetSNMPOnboardRebootEnable(NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_SetSNMPOnboardRebootEnable(""), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_SetSNMPOnboardRebootEnable("enabled"), RETURN_ERR);
}

static void test_l1_platform_hal_positive1_setLed(void)
{
    LEDMGMT_PARAMS value = {0};
    for (int color = LED_WHITE; color < NOT_SUPPORTED; ++color)
        for (int state = 0; state < 2; ++state) {
            value.LedColor = (LED_COLOR)color; value.State = state; value.Interval = state;
            UT_ASSERT_EQUAL(platform_hal_setLed(&value), RETURN_OK);
        }
}
static void test_l1_platform_hal_negative1_setLed(void)
{
    LEDMGMT_PARAMS value = {0};
    UT_ASSERT_EQUAL(platform_hal_setLed(NULL), RETURN_ERR);
    value.LedColor = (LED_COLOR)-1;
    UT_ASSERT_EQUAL(platform_hal_setLed(&value), RETURN_ERR);
    value.LedColor = NOT_SUPPORTED;
    UT_ASSERT_EQUAL(platform_hal_setLed(&value), RETURN_ERR);
    value.LedColor = LED_WHITE; value.State = 2;
    UT_ASSERT_EQUAL(platform_hal_setLed(&value), RETURN_ERR);
    value.State = -1;
    UT_ASSERT_EQUAL(platform_hal_setLed(&value), RETURN_ERR);
    value.State = 1; value.Interval = -1;
    UT_ASSERT_EQUAL(platform_hal_setLed(&value), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_getLed(void)
{
    LEDMGMT_PARAMS out = {0};
    UT_ASSERT_EQUAL(platform_hal_getLed(&out), RETURN_OK);
    UT_ASSERT_TRUE(out.LedColor >= LED_WHITE && out.LedColor < NOT_SUPPORTED);
    UT_ASSERT_TRUE(out.State == 0 || out.State == 1);
    UT_ASSERT_TRUE(out.Interval >= 0);
#ifdef FEATURE_RDKB_LED_MANAGER
    UT_ASSERT_PTR_NOT_NULL(out.led_name);
    UT_ASSERT_PTR_NOT_NULL(out.led_param);
#endif
}
static void test_l1_platform_hal_negative1_getLed(void)
{
    UT_ASSERT_EQUAL(platform_hal_getLed(NULL), RETURN_ERR);
}
#ifdef FEATURE_RDKB_LED_MANAGER
TEXT_TEST(initLed, 128, any_text)
#endif

static void test_l1_platform_hal_positive1_getFanSpeed(void)
{
    for (int i = 0; i < num_FanIndex; ++i) {
        UINT rpm = platform_hal_getFanSpeed((UINT)FanIndex[i]);
        UT_LOG("Fan speed raw measurement: %u", rpm);
#ifdef BUILD_LINUX
        UT_ASSERT_TRUE(rpm <= 4000); /* reference RPM ceiling, not public units */
#endif
    }
}
static void test_l1_platform_hal_positive1_getRPM(void)
{
    for (int i = 0; i < num_FanIndex; ++i) {
        UINT rpm = platform_hal_getRPM((UINT)FanIndex[i]);
        UT_LOG("Fan RPM raw measurement: %u", rpm);
#ifdef BUILD_LINUX
        UT_ASSERT_TRUE(rpm <= 4000);
#endif
    }
}
static void test_l1_platform_hal_positive1_getRotorLock(void)
{
    for (int i = 0; i < num_FanIndex; ++i) {
        int lock = platform_hal_getRotorLock((UINT)FanIndex[i]);
        UT_ASSERT_TRUE(lock == -1 || lock == 0 || lock == 1);
    }
}
static void test_l1_platform_hal_positive1_getFanStatus(void)
{
    for (int i = 0; i < num_FanIndex; ++i) {
        BOOLEAN out = platform_hal_getFanStatus((UINT)FanIndex[i]);
        UT_ASSERT_TRUE(out == FALSE || out == TRUE);
    }
}
static void test_l1_platform_hal_positive1_setFanMaxOverride(void)
{
    for (int i = 0; i < num_FanIndex; ++i) {
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setFanMaxOverride(TRUE, (UINT)FanIndex[i]), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setFanMaxOverride(FALSE, (UINT)FanIndex[i]), RETURN_OK);
    }
}
static void test_l1_platform_hal_negative1_setFanMaxOverride(void)
{
    UT_ASSERT_EQUAL(platform_hal_setFanMaxOverride(TRUE, 2), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_setFanMaxOverride(TRUE, UINT_MAX), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_setFanMaxOverride(2, 0), RETURN_ERR);
}

#ifdef FEATURE_RDKB_THERMAL_MANAGER
static void thermal_config(int (*api)(THERMAL_PLATFORM_CONFIG *))
{
    THERMAL_PLATFORM_CONFIG out = {0};
    UT_ASSERT_EQUAL(api(&out), RETURN_OK);
    UT_ASSERT_TRUE(out.FanCount == 1 || out.FanCount == 2);
    UT_ASSERT_TRUE(out.SlowSpeedThresh <= out.MediumSpeedThresh);
    UT_ASSERT_TRUE(out.MediumSpeedThresh <= out.FastSpeedThresh);
    UT_ASSERT_TRUE(out.FastSpeedThresh <= 100);
    UT_ASSERT_TRUE(out.MonitoringDelay > 0);
}
static void test_l1_platform_hal_positive1_initThermal(void) { thermal_config(platform_hal_initThermal); }
static void test_l1_platform_hal_negative1_initThermal(void)
{
    UT_ASSERT_EQUAL(platform_hal_initThermal(NULL), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_LoadThermalConfig(void) { thermal_config(platform_hal_LoadThermalConfig); }
static void test_l1_platform_hal_negative1_LoadThermalConfig(void)
{
    UT_ASSERT_EQUAL(platform_hal_LoadThermalConfig(NULL), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_setFanSpeed(void)
{
    for (int i = 0; i < num_FanIndex; ++i) {
        FAN_ERR reason = FAN_ERR_HW;
        UT_ASSERT_EQUAL(platform_hal_setFanMaxOverride(FALSE, (UINT)FanIndex[i]), RETURN_OK);
        for (int speed = FAN_SPEED_OFF; speed <= FAN_SPEED_MAX; ++speed) {
            int status = platform_hal_setFanSpeed((UINT)FanIndex[i], (FAN_SPEED)speed, &reason);
            UT_ASSERT_TRUE(status == RETURN_OK || status == RETURN_UNSUPPORTED);
            if (status == RETURN_OK) UT_ASSERT_EQUAL(reason, FAN_ERR_NONE);
        }
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_setFanSpeed((UINT)FanIndex[i], FAN_SPEED_SLOW, &reason), RETURN_OK);
    }
}
static void test_l1_platform_hal_negative1_setFanSpeed(void)
{
    FAN_ERR reason;
    UT_ASSERT_EQUAL(platform_hal_setFanSpeed(0, FAN_SPEED_SLOW, NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_setFanSpeed(2, FAN_SPEED_SLOW, &reason), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_setFanSpeed(0, (FAN_SPEED)-1, &reason), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_setFanSpeed(0, (FAN_SPEED)(FAN_SPEED_MAX + 1), &reason), RETURN_ERR);
}
#define READING_TEST(api, max_value) \
static void test_l1_platform_hal_positive1_##api(void) { \
    INT out = -1, status = platform_hal_##api(&out); \
    UT_ASSERT_TRUE(status == RETURN_OK || status == RETURN_UNSUPPORTED); \
    if (status == RETURN_OK) UT_ASSERT_TRUE(out >= 0 && out <= max_value); \
} \
static void test_l1_platform_hal_negative1_##api(void) { \
    UT_ASSERT_EQUAL(platform_hal_##api(NULL), RETURN_ERR); \
}
READING_TEST(getFanTemperature, 100)
READING_TEST(getInputCurrent, 20000)
READING_TEST(getInputPower, 20000)
#define RADIO_TEST(api, max_index, max_value) \
static void test_l1_platform_hal_positive1_##api(void) { \
    for (INT index = 0; index <= max_index; ++index) { \
        INT out = -1, status = platform_hal_##api(index, &out); \
        UT_ASSERT_TRUE(status == RETURN_OK || status == RETURN_UNSUPPORTED); \
        if (status == RETURN_OK) UT_ASSERT_TRUE(out >= 0 && out <= max_value); \
    } \
} \
static void test_l1_platform_hal_negative1_##api(void) { \
    INT out; \
    UT_ASSERT_EQUAL(platform_hal_##api(0, NULL), RETURN_ERR); \
    UT_ASSERT_EQUAL(platform_hal_##api(-1, &out), RETURN_ERR); \
    UT_ASSERT_EQUAL(platform_hal_##api(max_index + 1, &out), RETURN_ERR); \
}
RADIO_TEST(getRadioTemperature, 2, 100)
RADIO_TEST(getEcoModeStatus, 1, 1)
#endif

#define MAC_GET(api) \
static void test_l1_platform_hal_positive1_##api(void) { \
    for (INT port = 0; port < MaxEthPort; ++port) { \
        BOOLEAN out = 0xa5; \
        UT_ASSERT_EQUAL(platform_hal_##api(port, &out), RETURN_OK); \
        UT_ASSERT_TRUE(out == FALSE || out == TRUE); \
    } \
} \
static void test_l1_platform_hal_negative1_##api(void) { \
    BOOLEAN out; \
    UT_ASSERT_EQUAL(platform_hal_##api(0, NULL), RETURN_ERR); \
    UT_ASSERT_EQUAL(platform_hal_##api(-1, &out), RETURN_ERR); \
    UT_ASSERT_EQUAL(platform_hal_##api(MaxEthPort, &out), RETURN_ERR); \
    UT_ASSERT_EQUAL(platform_hal_##api(INT_MAX, &out), RETURN_ERR); \
}
MAC_GET(GetMACsecEnable)
MAC_GET(GetMACsecOperationalStatus)
static void test_l1_platform_hal_positive1_SetMACsecEnable(void)
{
    /* Iteration works for MaxEthPort=1; no rand() modulo zero. */
    for (INT port = 0; port < MaxEthPort; ++port) {
        BOOLEAN saved = FALSE;
        UT_ASSERT_EQUAL(platform_hal_GetMACsecEnable(port, &saved), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetMACsecEnable(port, TRUE), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetMACsecEnable(port, FALSE), RETURN_OK);
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_SetMACsecEnable(port, saved), RETURN_OK);
    }
}
static void test_l1_platform_hal_negative1_SetMACsecEnable(void)
{
    UT_ASSERT_EQUAL(platform_hal_SetMACsecEnable(-1, TRUE), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_SetMACsecEnable(MaxEthPort, TRUE), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_SetMACsecEnable(0, 2), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_StartMACsec(void)
{
    for (INT port = 0; port < MaxEthPort; ++port)
        UT_ASSERT_EQUAL(platform_hal_StartMACsec(port, 0), RETURN_OK);
}
static void test_l1_platform_hal_negative1_StartMACsec(void)
{
    UT_ASSERT_EQUAL(platform_hal_StartMACsec(-1, 0), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_StartMACsec(MaxEthPort, 0), RETURN_ERR);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(platform_hal_StartMACsec(0, -1), RETURN_ERR);
#endif
}
static void test_l1_platform_hal_positive1_StopMACsec(void)
{
    for (INT port = 0; port < MaxEthPort; ++port)
        UT_ASSERT_EQUAL(platform_hal_StopMACsec(port), RETURN_OK);
}
static void test_l1_platform_hal_negative1_StopMACsec(void)
{
    UT_ASSERT_EQUAL(platform_hal_StopMACsec(-1), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_StopMACsec(MaxEthPort), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_GetMemoryPaths(void)
{
    for (int i = 0; i < num_SupportedCPUs; ++i) {
        PPLAT_PROC_MEM_INFO info = NULL;
        int status = platform_hal_GetMemoryPaths(supportedCpus[i], &info);
        UT_ASSERT_EQUAL_NOT_FATAL(status, RETURN_OK);
        UT_ASSERT_PTR_NOT_NULL_NOT_FATAL(info);
        if (status == RETURN_OK && info) {
            UT_ASSERT_TRUE_NOT_FATAL(valid_text(info->dramPath, sizeof(info->dramPath)));
            UT_ASSERT_TRUE_NOT_FATAL(memchr(info->emmcPath1, 0, sizeof(info->emmcPath1)) != NULL);
            UT_ASSERT_TRUE_NOT_FATAL(memchr(info->emmcPath2, 0, sizeof(info->emmcPath2)) != NULL);
            UT_ASSERT_TRUE_NOT_FATAL(memchr(info->emmcPath3, 0, sizeof(info->emmcPath3)) != NULL);
        }
        /* Linux policy: one allocated record, documented in skeleton. */
        free(info);
    }
}
static void test_l1_platform_hal_negative1_GetMemoryPaths(void)
{
    PPLAT_PROC_MEM_INFO info = NULL;
    UT_ASSERT_EQUAL(platform_hal_GetMemoryPaths(HOST_CPU, NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_GetMemoryPaths((RDK_CPUS)-1, &info), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_GetMemoryPaths((RDK_CPUS)2, &info), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_GetMemoryPaths(NOT_SUPPORTED_CPU, &info), RETURN_ERR);
}
static int dhcp_code(int code, int v6)
{
    const int v4[] = {2,42,43,58,59,60,61,100,122,125,242,243,255};
    const int v6codes[] = {3,5,15,16,17,20,22,23,24,25,31,64,82,83,95};
    const int *codes = v6 ? v6codes : v4;
    size_t n = v6 ? sizeof(v6codes)/sizeof(*v6codes) : sizeof(v4)/sizeof(*v4);
    for (size_t i = 0; i < n; ++i) if (code == codes[i]) return 1;
    return 0;
}
static void check_free_options(dhcp_opt_list *head, int v6)
{
    size_t visited = 0;
    while (head && visited++ < 1024) {
        dhcp_opt_list *next = head->next;
        UT_ASSERT_TRUE_NOT_FATAL(dhcp_code(head->dhcp_opt, v6));
        UT_ASSERT_PTR_NOT_NULL_NOT_FATAL(head->dhcp_opt_val);
        free(head->dhcp_opt_val);
        free(head);
        head = next;
    }
    UT_ASSERT_PTR_NULL_NOT_FATAL(head);
}
#define DHCP_TEST(api, v6) \
static void test_l1_platform_hal_positive1_##api(void) { \
    dhcp_opt_list *req = NULL, *send = NULL; \
    int status = platform_hal_##api(&req, &send); \
    UT_ASSERT_EQUAL_NOT_FATAL(status, RETURN_OK); \
    UT_ASSERT_PTR_NOT_NULL_NOT_FATAL(req); UT_ASSERT_PTR_NOT_NULL_NOT_FATAL(send); \
    check_free_options(req, v6); check_free_options(send, v6); \
} \
static void test_l1_platform_hal_negative1_##api(void) { \
    dhcp_opt_list *out = NULL; \
    UT_ASSERT_EQUAL(platform_hal_##api(NULL, &out), RETURN_ERR); \
    UT_ASSERT_PTR_NULL(out); \
    UT_ASSERT_EQUAL(platform_hal_##api(&out, NULL), RETURN_ERR); \
    UT_ASSERT_PTR_NULL(out); \
    UT_ASSERT_EQUAL(platform_hal_##api(NULL, NULL), RETURN_ERR); \
}
DHCP_TEST(GetDhcpv4_Options, 0)
DHCP_TEST(GetDhcpv6_Options, 1)
static void test_l1_platform_hal_positive1_SetLowPowerModeState(void)
{
    for (int i = 0; i < num_Supported_PSM_STATE; ++i) {
        PSM_STATE state = Supported_PSM_STATE[i];
        UT_ASSERT_EQUAL(platform_hal_SetLowPowerModeState(&state), RETURN_OK);
    }
}
static void test_l1_platform_hal_negative1_SetLowPowerModeState(void)
{
    PSM_STATE state = (PSM_STATE)-1;
    UT_ASSERT_EQUAL(platform_hal_SetLowPowerModeState(NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_SetLowPowerModeState(&state), RETURN_ERR);
    state = (PSM_STATE)(PSM_NOT_SUPPORTED + 1);
    UT_ASSERT_EQUAL(platform_hal_SetLowPowerModeState(&state), RETURN_ERR);
}

/** @brief RDKB-66641: all four WAN types are valid, MAX is a sentinel. */
#define WAN_POSITIVE(label, iface) \
static void test_l1_platform_hal_positive_##label##_setDscp(void) { \
    UT_LOG("L1 DSCP WAN " #label); \
    UT_ASSERT_EQUAL(platform_hal_setDscp(iface, TRAFFIC_CNT_START, "10,0,65534"), RETURN_OK); \
    UT_ASSERT_EQUAL(platform_hal_setDscp(iface, TRAFFIC_CNT_STOP, NULL), RETURN_OK); \
    UT_ASSERT_EQUAL(platform_hal_setDscp(iface, TRAFFIC_CNT_START, NULL), RETURN_OK); \
    UT_ASSERT_EQUAL(platform_hal_setDscp(iface, TRAFFIC_CNT_STOP, NULL), RETURN_OK); \
}
WAN_POSITIVE(DOCSIS, DOCSIS)
WAN_POSITIVE(EWAN, EWAN)
WAN_POSITIVE(EPON, EPON)
WAN_POSITIVE(XGSPON, XGSPON)
static void test_l1_platform_hal_negative1_setDscp(void)
{
    WAN_INTERFACE invalid[] = {(WAN_INTERFACE)0, WAN_INTERFACE_MAX, (WAN_INTERFACE)(WAN_INTERFACE_MAX + 1)};
    for (size_t i = 0; i < 3; ++i)
        UT_ASSERT_EQUAL(platform_hal_setDscp(invalid[i], TRAFFIC_CNT_START, "0"), RETURN_ERR);
}
static void test_l1_platform_hal_negative2_setDscp(void)
{
    UT_ASSERT_EQUAL(platform_hal_setDscp(DOCSIS, (TRAFFIC_CNT_COMMAND)0, "0"), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_setDscp(DOCSIS, (TRAFFIC_CNT_COMMAND)3, "0"), RETURN_ERR);
}
static void test_l1_platform_hal_negative3_setDscp(void)
{
    char *invalid[] = {"", ",", "1,", "1,,2", "-1", "65535", "x", "1 2", "999999999999999999999999"};
    char too_long[197]; memset(too_long, '1', sizeof(too_long)-1); too_long[196] = 0;
    for (size_t i = 0; i < sizeof(invalid)/sizeof(*invalid); ++i)
        UT_ASSERT_EQUAL(platform_hal_setDscp(DOCSIS, TRAFFIC_CNT_START, invalid[i]), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_setDscp(DOCSIS, TRAFFIC_CNT_START, too_long), RETURN_ERR);
}
static int valid_dscp_list(const DSCP_list_t *list)
{
    if (list->numElements > sizeof(list->DSCP_Element)/sizeof(*list->DSCP_Element)) return 0;
    for (UINT i = 0; i < list->numElements; ++i) {
        const DSCP_Element_t *e = &list->DSCP_Element[i];
        if (e->dscp_value > 65534 || e->numClients > sizeof(e->Client)/sizeof(*e->Client)) return 0;
        for (UINT j = 0; j < e->numClients; ++j)
            if (!memchr(e->Client[j].mac, 0, sizeof(e->Client[j].mac)) ||
                !mac_address(e->Client[j].mac)) return 0;
    }
    return 1;
}
static void test_l1_platform_hal_positive1_getDscpClientList(void)
{
    DSCP_list_t *list = calloc(1, sizeof(*list));
    UT_ASSERT_PTR_NOT_NULL(list);
    for (int iface = DOCSIS; iface < WAN_INTERFACE_MAX; ++iface) {
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getDscpClientList((WAN_INTERFACE)iface, list), RETURN_OK);
        UT_ASSERT_TRUE_NOT_FATAL(valid_dscp_list(list));
    }
    free(list);
}
static void test_l1_platform_hal_negative1_getDscpClientList(void)
{
    DSCP_list_t *list = calloc(1, sizeof(*list));
    UT_ASSERT_PTR_NOT_NULL(list);
    WAN_INTERFACE invalid[] = {(WAN_INTERFACE)0, WAN_INTERFACE_MAX, (WAN_INTERFACE)(WAN_INTERFACE_MAX + 1)};
    for (size_t i = 0; i < 3; ++i)
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getDscpClientList(invalid[i], list), RETURN_ERR);
    for (int iface = DOCSIS; iface < WAN_INTERFACE_MAX; ++iface)
        UT_ASSERT_EQUAL_NOT_FATAL(platform_hal_getDscpClientList((WAN_INTERFACE)iface, NULL), RETURN_ERR);
    free(list);
}
static void test_l1_platform_hal_positive1_resetDscpCounts(void)
{
    for (int iface = DOCSIS; iface < WAN_INTERFACE_MAX; ++iface)
        UT_ASSERT_EQUAL(platform_hal_resetDscpCounts((WAN_INTERFACE)iface), RETURN_OK);
}
static void test_l1_platform_hal_negative1_resetDscpCounts(void)
{
    UT_ASSERT_EQUAL(platform_hal_resetDscpCounts((WAN_INTERFACE)0), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_resetDscpCounts(WAN_INTERFACE_MAX), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_resetDscpCounts((WAN_INTERFACE)(WAN_INTERFACE_MAX + 1)), RETURN_ERR);
}
static int firmware_state(const char *s)
{
    if (!strcmp(s, "confirmed")) return 1;
    if (strncmp(s, "TrialBoot#", 10) || !isdigit((unsigned char)s[10])) return 0;
    for (const char *p = s + 10; *p; ++p)
        if (!isdigit((unsigned char)*p)) return 0;
    return 1;
}
static void test_l1_platform_hal_positive1_GetFirmwareBankInfo(void)
{
    for (int bank = ACTIVE_BANK; bank <= INACTIVE_BANK; ++bank) {
        FW_BANK_INFO out; memset(&out, 0xa5, sizeof(out));
        UT_ASSERT_EQUAL(platform_hal_GetFirmwareBankInfo((FW_BANK)bank, &out), RETURN_OK);
        UT_ASSERT_TRUE(valid_text(out.fw_name, sizeof(out.fw_name)));
        UT_ASSERT_TRUE(valid_text(out.fw_state, sizeof(out.fw_state)));
        UT_ASSERT_TRUE(firmware_state(out.fw_state));
    }
}
static void test_l1_platform_hal_negative1_GetFirmwareBankInfo(void)
{
    FW_BANK_INFO out;
    UT_ASSERT_EQUAL(platform_hal_GetFirmwareBankInfo(ACTIVE_BANK, NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_GetFirmwareBankInfo((FW_BANK)-1, &out), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_GetFirmwareBankInfo((FW_BANK)2, &out), RETURN_ERR);
}
static void test_l1_platform_hal_positive1_GetInterfaceStats(void)
{
    for (int i = 0; i < num_InterfaceNames; ++i) {
        INTF_STATS out; memset(&out, 0xa5, sizeof(out));
        UT_ASSERT_EQUAL(platform_hal_GetInterfaceStats(InterfaceNames[i], &out), RETURN_OK);
#ifdef BUILD_LINUX
        UT_ASSERT_EQUAL(out.rx_packet, 0);
        UT_ASSERT_EQUAL(out.tx_packet, 0);
        UT_ASSERT_EQUAL(out.rx_bytes, 0);
        UT_ASSERT_EQUAL(out.tx_bytes, 0);
#endif
    }
}
static void test_l1_platform_hal_negative1_GetInterfaceStats(void)
{
    INTF_STATS out;
    UT_ASSERT_EQUAL(platform_hal_GetInterfaceStats(NULL, &out), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_GetInterfaceStats(InterfaceNames[0], NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_GetInterfaceStats(NULL, NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_GetInterfaceStats("", &out), RETURN_ERR);
    UT_ASSERT_EQUAL(platform_hal_GetInterfaceStats("not-an-interface", &out), RETURN_ERR);
}
static hal_network_params_t flow(int ipv6)
{
    hal_network_params_t value = {0};
    const unsigned char mac[6] = {2, 0, 0, 0, 0, 1};
    memcpy(value.src_mac, mac, sizeof(mac));
    value.ip_version = ipv6 ? IP_VERSION_IPV6 : IP_VERSION_IPV4;
    if (ipv6) {
        inet_pton(AF_INET6, "2001:db8::1", value.src_ip.ipv6);
        inet_pton(AF_INET6, "2001:db8::2", value.dest_ip.ipv6);
    } else {
        inet_pton(AF_INET, "192.0.2.1", &value.src_ip.ipv4);
        inet_pton(AF_INET, "192.0.2.2", &value.dest_ip.ipv4);
    }
    value.src_port = htons(12345); value.dest_port = htons(443);
    value.protocol = PROTOCOL_TCP; value.dscp_value = 0;
    return value;
}
static void test_l1_platform_hal_positive1_qos_apply(void)
{
    for (int ipv6 = 0; ipv6 <= 1; ++ipv6)
        for (int udp = 0; udp <= 1; ++udp) {
            hal_network_params_t value = flow(ipv6);
            value.protocol = udp ? PROTOCOL_UDP : PROTOCOL_TCP;
            UT_ASSERT_EQUAL(platform_hal_qos_apply(&value), RETURN_OK);
            value.dscp_value = 63; value.src_port = htons(0); value.dest_port = htons(65535);
            UT_ASSERT_EQUAL(platform_hal_qos_apply(&value), RETURN_OK);
            /* Port zero and identical endpoints are NOT forbidden by this API. */
            memcpy(&value.dest_ip, &value.src_ip, sizeof(value.dest_ip));
            value.dest_port = value.src_port;
            UT_ASSERT_EQUAL(platform_hal_qos_apply(&value), RETURN_OK);
        }
}
static void test_l1_platform_hal_negative1_qos_apply(void)
{
    hal_network_params_t value = flow(0);
    UT_ASSERT_EQUAL(platform_hal_qos_apply(NULL), RETURN_ERR);
    value.dscp_value = 64;
    UT_ASSERT_EQUAL(platform_hal_qos_apply(&value), RETURN_ERR);
    value.dscp_value = 255;
    UT_ASSERT_EQUAL(platform_hal_qos_apply(&value), RETURN_ERR);
    value = flow(0); value.ip_version = (ip_version_t)-1;
    UT_ASSERT_EQUAL(platform_hal_qos_apply(&value), RETURN_ERR);
    value.ip_version = (ip_version_t)2;
    UT_ASSERT_EQUAL(platform_hal_qos_apply(&value), RETURN_ERR);
    value = flow(1); value.protocol = (net_proto_t)-1;
    UT_ASSERT_EQUAL(platform_hal_qos_apply(&value), RETURN_ERR);
    value.protocol = (net_proto_t)2;
    UT_ASSERT_EQUAL(platform_hal_qos_apply(&value), RETURN_ERR);
}

/** @brief Register every case, propagating every failed registration. */
#define PAIR(api) \
    ADD_TEST(suite, test_l1_platform_hal_positive1_##api); \
    ADD_TEST(suite, test_l1_platform_hal_negative1_##api)
#define SIZED_PAIR(api) \
    PAIR(api); \
    ADD_TEST(suite, test_l1_platform_hal_positive2_##api); \
    ADD_TEST(suite, test_l1_platform_hal_negative2_##api); \
    ADD_TEST(suite, test_l1_platform_hal_negative3_##api)
int test_platform_hal_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite("L1 platform HAL contract", init_platform_hal_init, NULL);
    if (!suite) return -1;
    UT_LOG("Registering L1 contract tests");
    ADD_TEST(suite, test_l1_platform_hal_positive1_PandMDBInit);
    ADD_TEST(suite, test_l1_platform_hal_positive1_DocsisParamsDBInit);
    PAIR(GetDeviceConfigStatus); PAIR(GetModelName); PAIR(GetRouterRegion);
    PAIR(GetSerialNumber); PAIR(GetHardwareVersion); PAIR(GetSNMPEnable);
    PAIR(GetBaseMacAddress); PAIR(GetHardware); PAIR(GetHardware_MemUsed);
    PAIR(GetHardware_MemFree); PAIR(getTimeOffSet); PAIR(getFactoryPartnerId);
    PAIR(getFactoryCmVariant); PAIR(getCMTSMac); PAIR(GetCPUSpeed);
    SIZED_PAIR(GetSoftwareVersion); SIZED_PAIR(GetBootloaderVersion);
    SIZED_PAIR(GetFirmwareName); SIZED_PAIR(GetPppUserName); SIZED_PAIR(GetPppPassword);
    PAIR(GetSSHEnable); PAIR(GetTelnetEnable);
    PAIR(SetSSHEnable); PAIR(SetTelnetEnable); PAIR(SetDeviceCodeImageValid);
    PAIR(GetTotalMemorySize); PAIR(GetUsedMemorySize); PAIR(GetFreeMemorySize);
    PAIR(GetFactoryResetCount); PAIR(GetWebUITimeout);
    PAIR(SetSNMPEnable); PAIR(SetWebUITimeout);
    PAIR(GetWebAccessLevel); PAIR(SetWebAccessLevel);
    PAIR(ClearResetCount); PAIR(SetDeviceCodeImageTimeout);
    PAIR(setFactoryCmVariant); PAIR(SetSNMPOnboardRebootEnable);
    PAIR(setLed); PAIR(getLed);
#ifdef FEATURE_RDKB_LED_MANAGER
    PAIR(initLed);
#endif
    ADD_TEST(suite, test_l1_platform_hal_positive1_getFanSpeed);
    ADD_TEST(suite, test_l1_platform_hal_positive1_getRPM);
    ADD_TEST(suite, test_l1_platform_hal_positive1_getRotorLock);
    ADD_TEST(suite, test_l1_platform_hal_positive1_getFanStatus);
    PAIR(setFanMaxOverride);
#ifdef FEATURE_RDKB_THERMAL_MANAGER
    PAIR(initThermal); PAIR(LoadThermalConfig); PAIR(setFanSpeed);
    PAIR(getFanTemperature); PAIR(getInputCurrent); PAIR(getInputPower);
    PAIR(getRadioTemperature); PAIR(getEcoModeStatus);
#endif
    PAIR(GetMACsecEnable); PAIR(GetMACsecOperationalStatus);
    PAIR(SetMACsecEnable); PAIR(StartMACsec); PAIR(StopMACsec);
    PAIR(GetMemoryPaths); PAIR(GetDhcpv4_Options); PAIR(GetDhcpv6_Options);
    PAIR(SetLowPowerModeState);
    ADD_TEST(suite, test_l1_platform_hal_positive_DOCSIS_setDscp);
    ADD_TEST(suite, test_l1_platform_hal_positive_EWAN_setDscp);
    ADD_TEST(suite, test_l1_platform_hal_positive_EPON_setDscp);
    ADD_TEST(suite, test_l1_platform_hal_positive_XGSPON_setDscp);
    ADD_TEST(suite, test_l1_platform_hal_negative1_setDscp);
    ADD_TEST(suite, test_l1_platform_hal_negative2_setDscp);
    ADD_TEST(suite, test_l1_platform_hal_negative3_setDscp);
    PAIR(getDscpClientList); PAIR(resetDscpCounts);
    PAIR(GetFirmwareBankInfo); PAIR(GetInterfaceStats); PAIR(qos_apply);
    return 0;
}
