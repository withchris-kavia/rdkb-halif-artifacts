/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <stdbool.h>
#include <string.h>
#include "fwupgrade_hal.h"
#include "fwupgrade_hal_test_control.h"

/* Single-threaded test model; never performs I/O or executes external commands. */
static struct
{
    char url[FW_MODEL_URL_SIZE];
    char filename[FW_MODEL_FILENAME_SIZE];
    unsigned int interface;
    unsigned long ready;
    int status, fault;
    int progress[FW_MODEL_MAX_PROGRESS];
    size_t count, next;
    bool polling, rebooting;
    fwupgrade_model_counters_t counters;
} model = {.ready = 1};

static bool error_status(int status)
{
    return (status >= 400 && status <= 407) || status == 500;
}

/* Bound reads, reject empty, unterminated, whitespace and control-byte strings. */
static bool valid_text(const char *text, size_t capacity)
{
    size_t i;
    if (text == NULL || text[0] == '\0')
        return false;
    for (i = 0; i < capacity; ++i)
    {
        unsigned char ch = (unsigned char)text[i];
        if (ch == '\0')
            return true;
        if (ch <= 32 || ch == 127)
            return false;
    }
    return false;
}

static bool valid_url(const char *url)
{
    const char *host;
    if (!valid_text(url, FW_MODEL_URL_SIZE))
        return false;
    if (strncmp(url, "http://", 7) == 0)
        host = url + 7;
    else if (strncmp(url, "https://", 8) == 0)
        host = url + 8;
    else
        return false;
    return *host != '\0' && *host != '/' && *host != '?' && *host != '#';
}

/* PUBLIC_INTERFACE */
/** Restore initial simulation state, including ready=1 and idle status=0. */
void fwupgrade_model_reset(void)
{
    memset(&model, 0, sizeof(model));
    model.ready = 1;
}

/* PUBLIC_INTERFACE */
/** Copy a validated progress script; reject invalid scripts without side effects. */
int fwupgrade_model_script_progress(const int *values, size_t count)
{
    if (count > FW_MODEL_MAX_PROGRESS || (count != 0 && values == NULL) ||
        (count == 0 && values != NULL))
        return RETURN_ERR;
    for (size_t i = 0; i < count; ++i)
        if (values[i] < 1 || values[i] > 100 ||
            (i != 0 && values[i] <= values[i - 1]) ||
            (i + 1 == count && values[i] != 100))
            return RETURN_ERR;
    if (count != 0)
        memcpy(model.progress, values, count * sizeof(values[0]));
    model.count = count;
    model.next = 0;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Select a persistent failure status or clear it with zero. */
int fwupgrade_model_set_fault(int status)
{
    if (status != 0 && !error_status(status))
        return RETURN_ERR;
    model.fault = status;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Set the simulated readiness independently of firmware progress. */
int fwupgrade_model_set_readiness(unsigned long readiness)
{
    if (readiness != 1 && readiness != 2)
        return RETURN_ERR;
    model.ready = readiness;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Return counters by value, without exposing mutable model state. */
fwupgrade_model_counters_t fwupgrade_model_counters(void)
{
    return model.counters;
}

/* PUBLIC_INTERFACE */
/** Atomically validate and copy configured source and local filename. */
INT fwupgrade_hal_set_download_url(char *pUrl, char *pfilename)
{
    if (!valid_url(pUrl) || !valid_text(pfilename, sizeof(model.filename)))
        return RETURN_ERR;
    memmove(model.url, pUrl, strlen(pUrl) + 1);
    memmove(model.filename, pfilename, strlen(pfilename) + 1);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy configuration into the contract's >=1024/256-byte caller buffers. */
INT fwupgrade_hal_get_download_url(char *pUrl, char *pfilename)
{
    if (pUrl == NULL || pfilename == NULL)
        return RETURN_ERR;
    memcpy(pUrl, model.url, strlen(model.url) + 1);
    memcpy(pfilename, model.filename, strlen(model.filename) + 1);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Select wan0 (0) or erouter0 (1); invalid values leave configuration unchanged. */
INT fwupgrade_hal_set_download_interface(unsigned int interface)
{
    if (interface > 1)
        return RETURN_ERR;
    model.interface = interface;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Read the configured interface, returning -1 for a null destination. */
INT fwupgrade_hal_get_download_interface(unsigned int *pinterface)
{
    if (pinterface == NULL)
        return RETURN_ERR;
    *pinterface = model.interface;
    return RETURN_OK;
}

static int download_from(const char *url, bool needs_filename)
{
    if (model.rebooting)
        return RETURN_ERR;
    /* A new attempt replaces the previous observable operation, even on error. */
    model.polling = false;
    model.next = 0;
    if (!valid_url(url))
    {
        model.status = 400;
        return 400;
    }
    if (needs_filename && model.filename[0] == '\0')
    {
        model.status = 500;
        return RETURN_ERR;
    }
    ++model.counters.downloads;
    if (model.fault != 0)
    {
        model.status = model.fault;
        return model.fault == 400 ? 400 : RETURN_ERR;
    }
    ++model.counters.installations;
    /* The operation completes synchronously; scripted polling replays progress. */
    model.status = 100;
    model.polling = model.count != 0;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Simulate configured download/install; only invalid URL returns 400 directly. */
INT fwupgrade_hal_download(void)
{
    return download_from(model.url, true);
}

/* PUBLIC_INTERFACE */
/** Return idle, scripted 1..99 progress, completed 100, or a documented failure. */
INT fwupgrade_hal_get_download_status(void)
{
    if (model.polling && model.next < model.count)
    {
        model.status = model.progress[model.next++];
        if (model.next == model.count)
            model.polling = false;
    }
    return model.status;
}

/* PUBLIC_INTERFACE */
/** Write readiness (1 ready, 2 blocked), independently of download completion. */
INT fwupgrade_hal_reboot_ready(ULONG *pValue)
{
    if (pValue == NULL)
        return RETURN_ERR;
    *pValue = model.ready;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Count a simulated reboot only when ready and not already rebooting. */
INT fwupgrade_hal_download_reboot_now(void)
{
    if (model.rebooting || model.ready != 1)
        return RETURN_ERR;
    model.rebooting = true;
    ++model.counters.reboots;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Count a factory reset only after successful simulated configured update. */
INT fwupgrade_hal_update_and_factoryreset(void)
{
    if (fwupgrade_hal_download() != RETURN_OK)
        return RETURN_ERR;
    ++model.counters.factory_resets;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Simulate direct-source installation without modifying configured settings. */
INT fwupgrade_hal_download_install(const char *url)
{
    return download_from(url, false) == RETURN_OK ? RETURN_OK : RETURN_ERR;
}
