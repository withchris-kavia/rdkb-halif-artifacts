/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#ifndef FWUPGRADE_HAL_TEST_CONTROL_H
#define FWUPGRADE_HAL_TEST_CONTROL_H

#ifndef BUILD_LINUX
#error "Firmware model controls are Linux-test-only"
#endif
#include <stddef.h>

/* These capacities are model policy, NOT public setter-length guarantees. */
#define FW_MODEL_URL_SIZE 1024
#define FW_MODEL_FILENAME_SIZE 256
#define FW_MODEL_MAX_PROGRESS 32

typedef struct
{
    unsigned int downloads;     /* Accepted starts, including injected failures. */
    unsigned int installations; /* Successful update operations. */
    unsigned int reboots;       /* Simulated accepted reboot requests only. */
    unsigned int factory_resets;/* Successful update-and-reset operations only. */
} fwupgrade_model_counters_t;

/* PUBLIC_INTERFACE */
/** Reset all configuration, scripts, faults, counters and reboot state; ready=1. */
void fwupgrade_model_reset(void);
/* PUBLIC_INTERFACE */
/**
 * Copy a strictly increasing 1..99 progress script ending in 100.
 * NULL/zero clears the script. Invalid scripts fail atomically with -1.
 * Status polling consumes one entry after an accepted successful download.
 */
int fwupgrade_model_script_progress(const int *values, size_t count);
/* PUBLIC_INTERFACE */
/** Set a persistent download fault: 0 clears, 400..407/500 fail; else -1. */
int fwupgrade_model_set_fault(int status);
/* PUBLIC_INTERFACE */
/** Set readiness to 1 or 2; invalid values return -1 without changing state. */
int fwupgrade_model_set_readiness(unsigned long readiness);
/* PUBLIC_INTERFACE */
/** Return a value snapshot of the operation counters. */
fwupgrade_model_counters_t fwupgrade_model_counters(void);

#endif
