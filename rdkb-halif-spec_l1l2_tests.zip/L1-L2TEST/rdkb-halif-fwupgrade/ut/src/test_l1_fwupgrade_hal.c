/*
 * Copyright 2016 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <limits.h>
#include <string.h>
#include "fwupgrade_test_helpers.h"
#include "fwupgrade_hal.h" /* Intentional repeated inclusion: public include guard. */

static void scalar_contract(void)
{
    UT_ASSERT_EQUAL(RETURN_OK, 0);
    UT_ASSERT_EQUAL(RETURN_ERR, -1);
    UT_ASSERT_EQUAL(TRUE, 1);
    UT_ASSERT_EQUAL(FALSE, 0);
    UT_ASSERT_EQUAL(ENABLE, 1);
    UT_ASSERT_EQUAL(sizeof(CHAR), sizeof(char));
    UT_ASSERT_EQUAL(sizeof(UCHAR), sizeof(unsigned char));
    UT_ASSERT_EQUAL(sizeof(BOOLEAN), sizeof(unsigned char));
    UT_ASSERT_EQUAL(sizeof(USHORT), sizeof(unsigned short));
    UT_ASSERT_EQUAL(sizeof(UINT8), sizeof(unsigned char));
    UT_ASSERT_EQUAL(sizeof(INT), sizeof(int));
    UT_ASSERT_EQUAL(sizeof(UINT), sizeof(unsigned int));
    UT_ASSERT_EQUAL(sizeof(LONG), sizeof(long));
    UT_ASSERT_EQUAL(sizeof(ULONG), sizeof(unsigned long));
    UT_ASSERT((INT)-1 < 0 && (LONG)-1 < 0);
    UT_ASSERT((UCHAR)-1 > 0 && (UINT)-1 > 0 && (ULONG)-1 > 0);
}

static void configuration_readback(void)
{
    char url[1024] = {0}, filename[256] = {0};
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL_FATAL(fwupgrade_hal_get_download_url(url, filename), RETURN_OK);
    UT_ASSERT_FATAL(memchr(url, '\0', sizeof url) != NULL);
    UT_ASSERT_FATAL(memchr(filename, '\0', sizeof filename) != NULL);
    UT_ASSERT_STRING_EQUAL(url, fwupgrade_test_profile.url);
    UT_ASSERT_STRING_EQUAL(filename, fwupgrade_test_profile.filename);
}

static void null_url_arguments(void)
{
    char url[1024] = {0}, filename[256] = {0};
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url(NULL, filename), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url(url, NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url(NULL, NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_url(NULL, filename), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_url(url, NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_url(NULL, NULL), RETURN_ERR);
}

static void interface_readback(void)
{
    unsigned int actual = UINT_MAX;
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    for (unsigned int interface = 0; interface <= 1; ++interface)
    {
        UT_ASSERT_EQUAL(fwupgrade_hal_set_download_interface(interface), RETURN_OK);
        UT_ASSERT_EQUAL(fwupgrade_hal_get_download_interface(&actual), RETURN_OK);
        UT_ASSERT_EQUAL(actual, interface);
    }
}

static void invalid_interface_arguments(void)
{
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_interface(2), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_interface(UINT_MAX), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_interface(NULL), RETURN_ERR);
}

static void download_result(void)
{
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), RETURN_OK);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(fwupgrade_model_set_fault(400), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), 400);
    UT_ASSERT_EQUAL(fwupgrade_model_set_fault(500), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), RETURN_ERR);
#endif
}

static void download_status(void)
{
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
#ifdef BUILD_LINUX
    const int progress[] = {1, 50, 99, 100};
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 0);
    UT_ASSERT_EQUAL(fwupgrade_model_script_progress(progress, 4), RETURN_OK);
#endif
    UT_ASSERT_EQUAL_FATAL(fwupgrade_hal_download(), RETURN_OK);
#ifdef BUILD_LINUX
    for (size_t i = 0; i < 3; ++i)
    {
        int status = fwupgrade_hal_get_download_status();
        UT_ASSERT(status >= 1 && status <= 99);
        UT_ASSERT_EQUAL(status, progress[i]);
    }
#endif
    /* Public contract: 100 means complete, pending reboot. Never 200. */
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 100);
}

static void reboot_readiness(void)
{
    ULONG ready = 0;
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_reboot_ready(NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_reboot_ready(&ready), RETURN_OK);
    UT_ASSERT(ready == 1 || ready == 2);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(ready, 1);
    UT_ASSERT_EQUAL(fwupgrade_model_set_readiness(2), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_reboot_ready(&ready), RETURN_OK);
    UT_ASSERT_EQUAL(ready, 2);
#endif
}

static void simulated_reboot(void)
{
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL_FATAL(fwupgrade_hal_download(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_reboot_now(), RETURN_OK);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(fwupgrade_hal_download_reboot_now(), RETURN_ERR);
#endif
}

static void update_factory_reset(void)
{
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_update_and_factoryreset(), RETURN_OK);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(fwupgrade_model_set_fault(402), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_update_and_factoryreset(), RETURN_ERR);
#endif
}

static void direct_install(void)
{
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_install(NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_install(
                    fwupgrade_test_profile.direct_url), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Register all ten APIs and scalar constants in UT_TESTS_L1; fail on any error. */
int test_fwupgrade_hal_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L1 fwupgrade_hal]", NULL, NULL, UT_TESTS_L1);
    static const struct
    {
        const char *name;
        UT_TestFunction_t function;
    } cases[] = {
        {"scalar_contract", scalar_contract},
        {"configuration_readback", configuration_readback},
        {"null_url_arguments", null_url_arguments},
        {"interface_readback", interface_readback},
        {"invalid_interface_arguments", invalid_interface_arguments},
        {"download_result", download_result},
        {"download_status", download_status},
        {"reboot_readiness", reboot_readiness},
        {"simulated_reboot", simulated_reboot},
        {"update_factory_reset", update_factory_reset},
        {"direct_install", direct_install}
    };
    if (suite == NULL)
        return -1;
    for (size_t i = 0; i < sizeof cases / sizeof cases[0]; ++i)
        if (UT_add_test(suite, cases[i].name, cases[i].function) == NULL)
            return -1;
    return 0;
}
