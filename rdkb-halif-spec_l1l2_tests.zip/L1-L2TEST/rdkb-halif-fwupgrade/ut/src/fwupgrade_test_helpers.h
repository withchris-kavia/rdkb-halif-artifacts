/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#ifndef FWUPGRADE_TEST_HELPERS_H
#define FWUPGRADE_TEST_HELPERS_H

#include <ut.h>
#include "fwupgrade_hal.h"
#ifdef BUILD_LINUX
#include "fwupgrade_hal_test_control.h"
#endif

/* Minimum caller buffer capacities from the public getter contract. */
typedef struct
{
    char url[1024];
    char filename[256];
    char direct_url[1024];
} fwupgrade_test_profile_t;

extern fwupgrade_test_profile_t fwupgrade_test_profile;

/* Each case starts independently; vendor builds never reference model controls. */
static inline int fwupgrade_test_prepare(void)
{
#ifdef BUILD_LINUX
    fwupgrade_model_reset();
#endif
    if (fwupgrade_hal_set_download_url(fwupgrade_test_profile.url,
                                      fwupgrade_test_profile.filename) != RETURN_OK)
        return -1;
    return fwupgrade_hal_set_download_interface(0);
}

#endif
