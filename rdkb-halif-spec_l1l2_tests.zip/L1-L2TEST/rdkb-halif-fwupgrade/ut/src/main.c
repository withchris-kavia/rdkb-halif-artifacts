/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ut.h>
#include <ut_kvp_profile.h>
#include "fwupgrade_test_helpers.h"

extern int register_hal_l1_tests(void);
extern int register_hal_l2_tests(void);
extern void __real_CU_cleanup_registry(void);

typedef struct
{
    CU_pSuite suite;
    UT_groupID_t group;
} suite_entry_t;
typedef struct
{
    int group;
    bool enabled;
} group_filter_t;

fwupgrade_test_profile_t fwupgrade_test_profile;
static suite_entry_t suites[100];
static group_filter_t filters[50];
static unsigned int suite_count, filter_count;
static bool registration_failed, configuration_failed, running, captured;
static unsigned int tests_run, assertions_failed, suites_failed, tests_failed;
static CU_ErrorCode run_error;
static ut_kvp_instance_t *profile;
static bool profile_failed;

/* PUBLIC_INTERFACE */
/** Preserve failures before upstream registry cleanup resets CUnit counters. */
void __wrap_CU_cleanup_registry(void)
{
    if (running && !captured)
    {
        tests_run = CU_get_number_of_tests_run();
        assertions_failed = CU_get_number_of_failures();
        tests_failed = CU_get_number_of_tests_failed();
        suites_failed = CU_get_number_of_suites_failed();
        run_error = CU_get_error();
        captured = true;
        fprintf(stderr, "FWUPGRADE_RESULT tests=%u failed=%u assertions_failed=%u "
                "suites_failed=%u error=%d\n", tests_run, tests_failed,
                assertions_failed, suites_failed, (int)run_error);
    }
    __real_CU_cleanup_registry();
}

/* PUBLIC_INTERFACE */
/** Store ordered official group switches without upstream heap allocations. */
void __wrap_UT_Manage_Suite_Activation(int group, bool enabled)
{
    if (group < UT_TESTS_L1 || group >= UT_TESTS_MAX ||
        filter_count >= sizeof(filters) / sizeof(filters[0]))
    {
        configuration_failed = true;
        return;
    }
    filters[filter_count++] = (group_filter_t){group, enabled};
}

/* PUBLIC_INTERFACE */
/** Register a grouped suite and retain errors, including partial registration. */
UT_test_suite_t *__wrap_UT_add_suite_withGroupID(
    const char *name, UT_InitialiseFunction_t init,
    UT_CleanupFunction_t cleanup, UT_groupID_t group)
{
    CU_pSuite suite;
    if (suite_count >= sizeof(suites) / sizeof(suites[0]) ||
        group < UT_TESTS_L1 || group >= UT_TESTS_MAX)
    {
        registration_failed = true;
        return NULL;
    }
    suite = CU_add_suite(name, init, cleanup);
    if (suite == NULL || CU_get_error() != CUE_SUCCESS)
    {
        registration_failed = true;
        return NULL;
    }
    suites[suite_count++] = (suite_entry_t){suite, group};
    return (UT_test_suite_t *)suite;
}

/* PUBLIC_INTERFACE */
/** Register tests without upstream abort-on-registration-failure assertions. */
UT_test_t *__wrap_UT_add_test(UT_test_suite_t *suite, const char *name,
                            UT_TestFunction_t function)
{
    CU_pTest test = CU_add_test((CU_pSuite)suite, name, function);
    if (test == NULL || CU_get_error() != CUE_SUCCESS)
        registration_failed = true;
    return (UT_test_t *)test;
}

/* PUBLIC_INTERFACE */
/** Close the component-owned profile instance, including failed-open paths. */
void __wrap_ut_kvp_profile_close(void)
{
    if (profile != NULL)
        ut_kvp_destroyInstance(profile);
    profile = NULL;
}

/* PUBLIC_INTERFACE */
/** Expose the checked instance through the official KVP profile interface. */
ut_kvp_instance_t *__wrap_ut_kvp_profile_getInstance(void)
{
    return profile;
}

/* PUBLIC_INTERFACE */
/** Open profiles with checked statuses instead of upstream assert-on-error. */
ut_kvp_status_t __wrap_ut_kvp_profile_open(char *filename)
{
    ut_kvp_status_t status;
    __wrap_ut_kvp_profile_close();
    profile = ut_kvp_createInstance();
    status = profile == NULL ? UT_KVP_STATUS_INVALID_INSTANCE :
                              ut_kvp_open(profile, filename);
    if (status != UT_KVP_STATUS_SUCCESS)
    {
        profile_failed = true;
        __wrap_ut_kvp_profile_close();
    }
    return status;
}

static int load_inputs(void)
{
    ut_kvp_status_t url_status, filename_status, direct_status;
    bool terminated;
    if (profile == NULL || profile_failed)
        return -1;
    url_status = ut_kvp_getStringField(profile, "fwupgrade.url",
        fwupgrade_test_profile.url, sizeof fwupgrade_test_profile.url);
    filename_status = ut_kvp_getStringField(profile, "fwupgrade.filename",
        fwupgrade_test_profile.filename, sizeof fwupgrade_test_profile.filename);
    direct_status = ut_kvp_getStringField(profile, "fwupgrade.direct_url",
        fwupgrade_test_profile.direct_url, sizeof fwupgrade_test_profile.direct_url);
    /* Upstream returns success for truncated strings; detect before adding NUL. */
    terminated = memchr(fwupgrade_test_profile.url, '\0',
                        sizeof fwupgrade_test_profile.url) != NULL &&
                 memchr(fwupgrade_test_profile.filename, '\0',
                        sizeof fwupgrade_test_profile.filename) != NULL &&
                 memchr(fwupgrade_test_profile.direct_url, '\0',
                        sizeof fwupgrade_test_profile.direct_url) != NULL;
    fwupgrade_test_profile.url[sizeof fwupgrade_test_profile.url - 1] = '\0';
    fwupgrade_test_profile.filename[sizeof fwupgrade_test_profile.filename - 1] = '\0';
    fwupgrade_test_profile.direct_url[sizeof fwupgrade_test_profile.direct_url - 1] = '\0';
    return url_status == UT_KVP_STATUS_SUCCESS &&
           filename_status == UT_KVP_STATUS_SUCCESS &&
           direct_status == UT_KVP_STATUS_SUCCESS && terminated &&
           fwupgrade_test_profile.url[0] != '\0' &&
           fwupgrade_test_profile.filename[0] != '\0' &&
           fwupgrade_test_profile.direct_url[0] != '\0' ? 0 : -1;
}

/* Validate CLI errors the framework otherwise just logs (e.g. a missing -p arg). */
static int validate_options(int argc, char **argv)
{
    int opt, result = 0;
    unsigned int profiles = 0;
    opterr = 0;
    while ((opt = getopt(argc, argv, "cabhf:l:tp:d:e:")) != -1)
    {
        if (opt == '?' || opt == ':')
            result = -1;
        else if (opt == 'p' && (++profiles > 1 || optarg[0] == '\0'))
            result = -1;
        else if (opt == 'd' || opt == 'e')
        {
            char *end = NULL;
            long group = strtol(optarg, &end, 10);
            if (*optarg == '\0' || *end != '\0' ||
                group < UT_TESTS_L1 || group >= UT_TESTS_MAX)
                result = -1;
        }
    }
    if (optind != argc)
        result = -1;
    optind = 1;
    opterr = 1;
    return result;
}

/* PUBLIC_INTERFACE */
/**
 * Run the component's official UT CLI and L1/L2 groups.
 * argc/argv accept -b, -a, -p profile and ordered -d/-e group switches.
 * Return 0 only for a nonempty clean run (or framework help); else return 1.
 * Linux uses the supplied safe profile by default; vendor runs require -p.
 */
int main(int argc, char **argv)
{
    UT_status_t status;
    int l1_status, l2_status;

    if (validate_options(argc, argv) != 0)
    {
        fprintf(stderr, "Firmware invalid command-line options\n");
        return EXIT_FAILURE;
    }
    if (UT_init(argc, argv) != UT_STATUS_OK || configuration_failed)
    {
        fprintf(stderr, "Firmware framework initialization failed\n");
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }
#ifdef BUILD_LINUX
    if (profile == NULL && !profile_failed)
    {
        char default_profile[] = FWUPGRADE_DEFAULT_PROFILE;
        (void)__wrap_ut_kvp_profile_open(default_profile);
    }
#endif
    if (load_inputs() != 0)
    {
        fprintf(stderr, "Firmware missing or invalid profile\n");
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }
    CU_set_fail_on_inactive(CU_FALSE);
    l1_status = register_hal_l1_tests();
    l2_status = register_hal_l2_tests();
    if (l1_status != 0 || l2_status != 0 || registration_failed ||
        CU_get_error() != CUE_SUCCESS)
    {
        fprintf(stderr, "Firmware suite/test registration failed\n");
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }
    for (unsigned int i = 0; i < filter_count; ++i)
        for (unsigned int j = 0; j < suite_count; ++j)
            if ((int)suites[j].group == filters[i].group)
                CU_set_suite_active(suites[j].suite,
                                    filters[i].enabled ? CU_TRUE : CU_FALSE);
    running = true;
    status = UT_run_tests();
    UT_exit();
    if (status != UT_STATUS_OK || !captured || tests_run == 0 ||
        assertions_failed != 0 || tests_failed != 0 || suites_failed != 0 ||
        run_error != CUE_SUCCESS)
    {
        fprintf(stderr, "Firmware run failed or selected zero tests\n");
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
