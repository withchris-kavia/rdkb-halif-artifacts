/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
extern int test_fwupgrade_hal_l1_register(void);
extern int test_fwupgrade_hal_l2_register(void);

/* PUBLIC_INTERFACE */
/** Register the firmware-upgrade L1 contract tests; return zero on success. */
int register_hal_l1_tests(void)
{
    return test_fwupgrade_hal_l1_register();
}

/* PUBLIC_INTERFACE */
/** Register the Linux-only L2 model tests; return zero on success. */
int register_hal_l2_tests(void)
{
    return test_fwupgrade_hal_l2_register();
}
