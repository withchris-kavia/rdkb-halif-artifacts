/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include "fwupgrade_test_helpers.h"

#ifdef BUILD_LINUX
#include <limits.h>
#include <string.h>

static void assert_config(const char *expected_url, const char *expected_filename,
                          unsigned int expected_interface)
{
    char url[1024] = {0}, filename[256] = {0};
    unsigned int interface = UINT_MAX;
    UT_ASSERT_EQUAL_FATAL(fwupgrade_hal_get_download_url(url, filename), RETURN_OK);
    UT_ASSERT_FATAL(memchr(url, '\0', sizeof url) != NULL);
    UT_ASSERT_FATAL(memchr(filename, '\0', sizeof filename) != NULL);
    UT_ASSERT_STRING_EQUAL(url, expected_url);
    UT_ASSERT_STRING_EQUAL(filename, expected_filename);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_interface(&interface), RETURN_OK);
    UT_ASSERT_EQUAL(interface, expected_interface);
}

static void config_roundtrip(void)
{
    char url[] = "https://example.invalid/second/";
    char filename[] = "second-model.bin";
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url(url, filename), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_interface(1), RETURN_OK);
    /* Setter must copy rather than retain these caller-owned strings. */
    url[8] = 'X';
    filename[0] = 'X';
    assert_config("https://example.invalid/second/", "second-model.bin", 1);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url(NULL, filename), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_interface(2), RETURN_ERR);
    assert_config("https://example.invalid/second/", "second-model.bin", 1);
}

static void download_install_status_sequence(void)
{
    const int progress[] = {1, 50, 99, 100};
    fwupgrade_model_counters_t counters;
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 0);
    UT_ASSERT_EQUAL(fwupgrade_model_script_progress(progress, 4), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), RETURN_OK);
    for (size_t i = 0; i < 4; ++i)
        UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), progress[i]);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 100);
    counters = fwupgrade_model_counters();
    UT_ASSERT_EQUAL(counters.downloads, 1);
    UT_ASSERT_EQUAL(counters.installations, 1);
    UT_ASSERT_EQUAL(counters.reboots, 0);
    UT_ASSERT_EQUAL(counters.factory_resets, 0);
}

static void download_failure_matrix(void)
{
    const int failures[] = {400, 401, 402, 403, 404, 405, 406, 407, 500};
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    for (size_t i = 0; i < sizeof failures / sizeof failures[0]; ++i)
    {
        fwupgrade_model_counters_t counters;
        UT_ASSERT_EQUAL(fwupgrade_model_set_fault(failures[i]), RETURN_OK);
        UT_ASSERT_EQUAL(fwupgrade_hal_download(),
                        failures[i] == 400 ? 400 : RETURN_ERR);
        UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), failures[i]);
        UT_ASSERT_EQUAL(fwupgrade_hal_download_install(
                        fwupgrade_test_profile.direct_url), RETURN_ERR);
        UT_ASSERT_EQUAL(fwupgrade_hal_update_and_factoryreset(), RETURN_ERR);
        counters = fwupgrade_model_counters();
        UT_ASSERT_EQUAL(counters.installations, 0);
        UT_ASSERT_EQUAL(counters.factory_resets, 0);
    }
    UT_ASSERT_EQUAL(fwupgrade_model_set_fault(0), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 100);
}

static void readiness_transition(void)
{
    ULONG ready = 0;
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_model_set_readiness(2), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_reboot_ready(&ready), RETURN_OK);
    UT_ASSERT_EQUAL(ready, 2);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_reboot_now(), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().reboots, 0);
    UT_ASSERT_EQUAL(fwupgrade_model_set_readiness(1), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_reboot_ready(&ready), RETURN_OK);
    UT_ASSERT_EQUAL(ready, 1);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().downloads, 1);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_reboot_now(), RETURN_OK);
}

static void reboot_in_progress(void)
{
    fwupgrade_model_counters_t counters;
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_reboot_now(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_reboot_now(), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_update_and_factoryreset(), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_install(
                    fwupgrade_test_profile.direct_url), RETURN_ERR);
    counters = fwupgrade_model_counters();
    UT_ASSERT_EQUAL(counters.reboots, 1);
    UT_ASSERT_EQUAL(counters.downloads, 1);
    UT_ASSERT_EQUAL(counters.installations, 1);
    UT_ASSERT_EQUAL(counters.factory_resets, 0);
}

static void factory_reset_after_update(void)
{
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_model_set_fault(500), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_update_and_factoryreset(), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().factory_resets, 0);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().installations, 0);
    UT_ASSERT_EQUAL(fwupgrade_model_set_fault(0), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_update_and_factoryreset(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().factory_resets, 1);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().installations, 1);
    UT_ASSERT_EQUAL(fwupgrade_model_set_fault(407), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_update_and_factoryreset(), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().factory_resets, 1);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().reboots, 0);
}

static void direct_source_preserves_config(void)
{
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_interface(1), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_install(
                    fwupgrade_test_profile.direct_url), RETURN_OK);
    assert_config(fwupgrade_test_profile.url, fwupgrade_test_profile.filename, 1);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().installations, 1);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 100);
    /* Direct install must also work without a configured source or filename. */
    fwupgrade_model_reset();
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), 400);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_install(
                    fwupgrade_test_profile.direct_url), RETURN_OK);
    assert_config("", "", 0);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().installations, 1);
}

static void isolation_and_malformed_inputs(void)
{
    char url[FW_MODEL_URL_SIZE];
    char filename[FW_MODEL_FILENAME_SIZE];
    const int invalid_progress[] = {1, 100, 99};
    const int progress[] = {1, 100};
    ULONG ready = 0;
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 0);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().downloads, 0);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().installations, 0);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().factory_resets, 0);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().reboots, 0);
    UT_ASSERT_EQUAL(fwupgrade_hal_reboot_ready(&ready), RETURN_OK);
    UT_ASSERT_EQUAL(ready, 1);

    /* Model-only limits: the public setter does NOT document length limits. */
    memset(url, 'a', sizeof url);
    memcpy(url, "https://", 8);
    memset(filename, 'b', sizeof filename);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url(url,
                    fwupgrade_test_profile.filename), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url(fwupgrade_test_profile.url,
                    filename), RETURN_ERR);
    url[sizeof url - 1] = '\0';
    filename[sizeof filename - 1] = '\0';
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url(url, filename), RETURN_OK);
    assert_config(url, filename, 0);
    UT_ASSERT_EQUAL_FATAL(fwupgrade_test_prepare(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url("", filename), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url("http://", filename), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url("not-a-url", filename), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url("https://example.invalid/a b",
                                                filename), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_set_download_url(
                    fwupgrade_test_profile.url, ""), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_install(NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_install(""), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 400);
    assert_config(fwupgrade_test_profile.url, fwupgrade_test_profile.filename, 0);
    UT_ASSERT_EQUAL(fwupgrade_model_set_readiness(0), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_model_set_fault(200), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_model_script_progress(NULL, 1), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_model_script_progress(progress,
                    FW_MODEL_MAX_PROGRESS + 1), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_model_script_progress(invalid_progress, 3), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_model_script_progress(progress, 2), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_model_script_progress(invalid_progress, 3), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 1);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 100);
    UT_ASSERT_EQUAL(fwupgrade_hal_download(), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 1);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_install("not-a-url"), RETURN_ERR);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 400);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 400);

    /* Reset proves isolation even after every controllable state was changed. */
    UT_ASSERT_EQUAL(fwupgrade_model_set_fault(407), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_model_set_readiness(2), RETURN_OK);
    fwupgrade_model_reset();
    assert_config("", "", 0);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 0);
    UT_ASSERT_EQUAL(fwupgrade_hal_reboot_ready(&ready), RETURN_OK);
    UT_ASSERT_EQUAL(ready, 1);
    UT_ASSERT_EQUAL(fwupgrade_model_counters().downloads, 0);
    UT_ASSERT_EQUAL(fwupgrade_hal_download_install(
                    fwupgrade_test_profile.direct_url), RETURN_OK);
    UT_ASSERT_EQUAL(fwupgrade_hal_get_download_status(), 100);
}
#endif

/* PUBLIC_INTERFACE */
/** Register exactly eight Linux-private stateful L2 scenarios; vendor is a no-op. */
int test_fwupgrade_hal_l2_register(void)
{
#ifdef BUILD_LINUX
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L2 fwupgrade_hal model]", NULL, NULL, UT_TESTS_L2);
    static const struct
    {
        const char *name;
        UT_TestFunction_t function;
    } cases[] = {
        {"config_roundtrip", config_roundtrip},
        {"download_install_status_sequence", download_install_status_sequence},
        {"download_failure_matrix", download_failure_matrix},
        {"readiness_transition", readiness_transition},
        {"reboot_in_progress", reboot_in_progress},
        {"factory_reset_after_update", factory_reset_after_update},
        {"direct_source_preserves_config", direct_source_preserves_config},
        {"isolation_and_malformed_inputs", isolation_and_malformed_inputs}
    };
    if (suite == NULL)
        return -1;
    for (size_t i = 0; i < sizeof cases / sizeof cases[0]; ++i)
        if (UT_add_test(suite, cases[i].name, cases[i].function) == NULL)
            return -1;
#endif
    return 0;
}
