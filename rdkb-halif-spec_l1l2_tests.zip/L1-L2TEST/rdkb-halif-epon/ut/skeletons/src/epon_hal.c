#include <stdlib.h>
#include <string.h>
#include "epon_hal_test_control.h"

static epon_test_scenario_t data;
static epon_hal_config_t config;
static epon_hal_return_t faults[EPON_TEST_API_COUNT];
static epon_onu_status_t onu;
static bool initialized, optical_supported, oam_supported, dpoe_supported;
static unsigned int allocation_countdown, reset_phase;
static uint32_t oam_mask;
static epon_test_oam_observation_t oam_observation;

static bool text_valid(const char *text, size_t size)
{
    return text[0] != '\0' && memchr(text, '\0', size) != NULL;
}

static bool llid_valid(const epon_llid_info_t *entry)
{
    return entry->mode >= EPON_LLID_MODE_UNICAST &&
        entry->mode <= EPON_LLID_MODE_BROADCAST &&
        entry->state >= EPON_LLID_STATE_UNREGISTERED &&
        entry->state <= EPON_LLID_STATE_FAILED &&
        entry->forwarding_state >= EPON_LLID_FORWARDING_DISABLED &&
        entry->forwarding_state <= EPON_LLID_FORWARDING_LEARNING;
}

static bool cpe_valid(const dpoe_cpe_mac_entry_t *entry)
{
    return (entry->type == DPOE_CPE_MAC_STATIC && entry->age_time == 0) ||
        entry->type == DPOE_CPE_MAC_DYNAMIC;
}

static epon_hal_return_t take_fault(epon_test_api_t api)
{
    epon_hal_return_t result = faults[api];
    faults[api] = EPON_HAL_SUCCESS;
    return result;
}

static epon_hal_return_t ready(epon_test_api_t api)
{
    return initialized ? take_fault(api) : EPON_HAL_ERROR_NOT_INITIALIZED;
}

static void *snapshot(const void *source, size_t bytes)
{
    void *copy;
    if (allocation_countdown != 0 && --allocation_countdown == 0)
        return NULL;
    copy = malloc(bytes);
    if (copy != NULL)
        memcpy(copy, source, bytes);
    return copy;
}

/* PUBLIC_INTERFACE */
/** Fill defaults: two down interfaces, two unregistered LLIDs and two CPEs. */
void epon_test_default_scenario(epon_test_scenario_t *s)
{
    if (s == NULL)
        return;
    memset(s, 0, sizeof(*s));
    s->stats.struct_size = sizeof(s->stats);
    s->stats.max_bit_rate = 10000;
    s->optical = (epon_hal_transceiver_stats_t){
        sizeof(s->optical), 2.5f, -18.5f, -28.0f, -8.0f,
        -2.0f, 6.0f, 12.5f, 35.0f, 3.25f
    };
    s->manufacturer.struct_size = sizeof(s->manufacturer);
    strcpy(s->manufacturer.manufacturer, "RDK reference");
    strcpy(s->manufacturer.model_number, "EPON-model");
    strcpy(s->manufacturer.hardware_version, "1");
    strcpy(s->manufacturer.software_version, "1.0.0");
    strcpy(s->manufacturer.serial_number, "MODEL-0001");
    s->manufacturer.vendor_oui[0] = 2;
    strcpy(s->link.mode, "10G-EPON");
    s->link.encryption = EPON_ENCRYPTION_MODE_AES_128;
    s->interfaces.interface_count = 2;
    strcpy(s->interfaces.interface[0].name, "veip0");
    strcpy(s->interfaces.interface[1].name, "veip1");
    s->olt.struct_size = sizeof(s->olt);
    s->olt.mac_address[0] = 2;
    s->olt.mac_address[5] = 0x81;
    s->olt.vendor_oui[0] = 2;
    s->olt_available = true;
    s->max_llids = EPON_TEST_CAPACITY;
    s->llid_count = 2;
    s->max_cpe = EPON_TEST_CAPACITY;
    s->cpe_count = 2;
    for (unsigned int i = 0; i < 2; ++i) {
        s->llids[i].llid_value = (uint16_t)(i + 1);
        s->llids[i].local_mac_address[0] = 2;
        s->llids[i].local_mac_address[5] = (uint8_t)(i + 1);
        s->llids[i].encryption_enabled = true;
        s->cpe[i].mac_address[0] = 2;
        s->cpe[i].mac_address[5] = (uint8_t)(i + 16);
    }
    s->cpe[1].type = DPOE_CPE_MAC_DYNAMIC;
    s->cpe[1].age_time = 42;
}

/* PUBLIC_INTERFACE */
/** Restore the complete model to uninitialized factory conditions. */
void epon_test_reset(void)
{
    epon_test_default_scenario(&data);
    memset(&config, 0, sizeof(config));
    memset(faults, 0, sizeof(faults));
    memset(&oam_observation, 0, sizeof(oam_observation));
    initialized = false;
    optical_supported = oam_supported = dpoe_supported = true;
    allocation_countdown = reset_phase = oam_mask = 0;
    onu = EPON_ONU_STATUS_LOS;
}

/* PUBLIC_INTERFACE */
/** Validate the full seed first so partial or oversized scenarios are atomic. */
epon_hal_return_t epon_test_seed(const epon_test_scenario_t *s)
{
    if (s == NULL || s->stats.struct_size != sizeof(s->stats) ||
        s->optical.struct_size != sizeof(s->optical) ||
        s->manufacturer.struct_size != sizeof(s->manufacturer) ||
        s->olt.struct_size != sizeof(s->olt) ||
        s->interfaces.interface_count > EPON_HAL_MAX_INTERFACES ||
        s->max_llids > EPON_TEST_CAPACITY || s->llid_count > s->max_llids ||
        s->max_cpe > EPON_TEST_CAPACITY || s->cpe_count > s->max_cpe ||
        !text_valid(s->link.mode, sizeof(s->link.mode)) ||
        s->link.encryption < EPON_ENCRYPTION_MODE_DISABLED ||
        s->link.encryption > EPON_ENCRYPTION_MODE_AES_256)
        return EPON_HAL_ERROR_INVALID_PARAM;
#define VALID_TEXT(member) \
    if (!text_valid(s->manufacturer.member, sizeof(s->manufacturer.member))) \
        return EPON_HAL_ERROR_INVALID_PARAM;
    VALID_TEXT(manufacturer)
    VALID_TEXT(model_number)
    VALID_TEXT(hardware_version)
    VALID_TEXT(software_version)
    VALID_TEXT(serial_number)
#undef VALID_TEXT
    for (uint32_t i = 0; i < s->interfaces.interface_count; ++i) {
        const epon_onu_interface_info_t *entry = &s->interfaces.interface[i];
        if (!text_valid(entry->name, sizeof(entry->name)) ||
            (entry->status != EPON_ONU_INTF_STATUS_LINK_DOWN &&
             entry->status != EPON_ONU_INTF_STATUS_LINK_UP))
            return EPON_HAL_ERROR_INVALID_PARAM;
        for (uint32_t j = 0; j < i; ++j)
            if (strcmp(entry->name, s->interfaces.interface[j].name) == 0)
                return EPON_HAL_ERROR_INVALID_PARAM;
    }
    for (uint32_t i = 0; i < s->llid_count; ++i)
        if (!llid_valid(&s->llids[i]))
            return EPON_HAL_ERROR_INVALID_PARAM;
    for (uint32_t i = 0; i < s->cpe_count; ++i)
        if (!cpe_valid(&s->cpe[i]))
            return EPON_HAL_ERROR_INVALID_PARAM;
    data = *s;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Change model feature availability, not the copied initialization setting. */
void epon_test_capabilities(bool optical, bool oam, bool dpoe)
{
    optical_supported = optical;
    oam_supported = oam;
    dpoe_supported = dpoe;
}

/* PUBLIC_INTERFACE */
/** Configure one-shot failure for a status-returning API only. */
void epon_test_fault(epon_test_api_t api, epon_hal_return_t result)
{
    if (api >= EPON_TEST_INIT && api < EPON_TEST_API_COUNT)
        faults[api] = result;
}

/* PUBLIC_INTERFACE */
/** Arm an allocation countdown; zero disables it. */
void epon_test_fail_allocation(unsigned int nth)
{
    allocation_countdown = nth;
}

/* PUBLIC_INTERFACE */
/** Return the immutable model ABI version, with no initialization prerequisite. */
uint32_t epon_hal_get_version(void)
{
    return EPON_HAL_API_VERSION;
}

/* PUBLIC_INTERFACE */
/** Copy valid config and initialize; success is independent of ONU readiness. */
epon_hal_return_t epon_hal_init(const epon_hal_config_t *value)
{
    epon_hal_return_t result;
    if (value == NULL || value->struct_size != sizeof(*value))
        return EPON_HAL_ERROR_INVALID_PARAM;
    if (initialized)
        return EPON_HAL_ERROR_CONFIG;
    result = take_fault(EPON_TEST_INIT);
    if (result != EPON_HAL_SUCCESS)
        return result;
    config = *value;
    initialized = true;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Unregister callbacks and deregister; caller-owned arrays remain valid. */
epon_hal_return_t epon_hal_deinit(void)
{
    epon_hal_return_t result = ready(EPON_TEST_DEINIT);
    if (result != EPON_HAL_SUCCESS)
        return result;
    initialized = false;
    memset(&config, 0, sizeof(config));
    onu = EPON_ONU_STATUS_LOS;
    oam_mask = reset_phase = 0;
    for (uint32_t i = 0; i < data.interfaces.interface_count; ++i)
        data.interfaces.interface[i].status = EPON_ONU_INTF_STATUS_LINK_DOWN;
    for (uint32_t i = 0; i < data.llid_count; ++i) {
        data.llids[i].state = EPON_LLID_STATE_UNREGISTERED;
        data.llids[i].forwarding_state = EPON_LLID_FORWARDING_DISABLED;
    }
    return EPON_HAL_SUCCESS;
}

#define CHECK_OUTPUT(pointer, api) \
    if ((pointer) == NULL) return EPON_HAL_ERROR_INVALID_PARAM; \
    epon_hal_return_t result = ready(api); \
    if (result != EPON_HAL_SUCCESS) return result
#define CHECK_SIZED(pointer, api) \
    if ((pointer) == NULL || (pointer)->struct_size != sizeof(*(pointer))) \
        return EPON_HAL_ERROR_INVALID_PARAM; \
    epon_hal_return_t result = ready(api); \
    if (result != EPON_HAL_SUCCESS) return result

/* PUBLIC_INTERFACE */
/** Return a complete caller-sized link-counter snapshot. */
epon_hal_return_t epon_hal_get_link_stats(epon_hal_link_stats_t *stats)
{
    CHECK_SIZED(stats, EPON_TEST_LINK_STATS);
    *stats = data.stats;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return all nine optical readings, or NOT_SUPPORTED without output mutation. */
epon_hal_return_t epon_hal_get_transceiver_stats(epon_hal_transceiver_stats_t *stats)
{
    CHECK_SIZED(stats, EPON_TEST_OPTICAL_STATS);
    if (!optical_supported)
        return EPON_HAL_ERROR_NOT_SUPPORTED;
    *stats = data.optical;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Allocate a fresh free-compatible LLID array; caller must free it. */
epon_hal_return_t epon_hal_get_llid_info(epon_llid_list_t *list)
{
    epon_llid_info_t *copy = NULL;
    CHECK_OUTPUT(list, EPON_TEST_LLIDS);
    if (data.llid_count != 0) {
        copy = snapshot(data.llids, data.llid_count * sizeof(*copy));
        if (copy == NULL)
            return EPON_HAL_ERROR_MEMORY;
    }
    *list = (epon_llid_list_t){data.max_llids, data.llid_count, copy};
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return bounded, terminated manufacturer identity fields. */
epon_hal_return_t epon_hal_get_manufacturer_info(epon_onu_manufacturer_info_t *info)
{
    CHECK_SIZED(info, EPON_TEST_MANUFACTURER);
    *info = data.manufacturer;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Clear all 16 counters while preserving rate and optical measurements. */
epon_hal_return_t epon_hal_clear_stats(void)
{
    epon_hal_return_t result = ready(EPON_TEST_CLEAR);
    if (result != EPON_HAL_SUCCESS)
        return result;
#define ZERO(member) data.stats.member = 0;
    EPON_TEST_COUNTERS(ZERO)
#undef ZERO
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Initiate deterministic deregistration; two model steps complete discovery. */
epon_hal_return_t epon_hal_reset_onu(void)
{
    epon_hal_return_t result = ready(EPON_TEST_RESET_ONU);
    if (result != EPON_HAL_SUCCESS)
        return result;
    (void)epon_test_onu(EPON_ONU_STATUS_DEREGISTRATION);
    for (uint32_t i = 0; i < data.interfaces.interface_count; ++i)
        (void)epon_test_interface(i, EPON_ONU_INTF_STATUS_LINK_DOWN);
    for (uint32_t i = 0; i < data.llid_count; ++i) {
        data.llids[i].state = EPON_LLID_STATE_DEREGISTERING;
        data.llids[i].forwarding_state = EPON_LLID_FORWARDING_DISABLED;
    }
    reset_phase = 1;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Restore factory defaults and require reinit, including when called pre-init. */
epon_hal_return_t epon_hal_factory_reset(void)
{
    epon_hal_return_t result = take_fault(EPON_TEST_FACTORY);
    if (result != EPON_HAL_SUCCESS)
        return result;
    epon_test_reset();
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return operational mode and encryption without requiring registration. */
epon_hal_return_t epon_hal_get_link_info(epon_hal_link_info_t *info)
{
    CHECK_OUTPUT(info, EPON_TEST_LINK_INFO);
    *info = data.link;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return the bounded embedded interface snapshot. */
epon_hal_return_t epon_hal_get_interface_list(epon_interface_list_t *list)
{
    CHECK_OUTPUT(list, EPON_TEST_INTERFACES);
    *list = data.interfaces;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return OLT data only after registration and successful discovery. */
epon_hal_return_t epon_hal_get_olt_info(epon_olt_info_t *info)
{
    CHECK_SIZED(info, EPON_TEST_OLT);
    if (onu != EPON_ONU_STATUS_REGISTRATION || !data.olt_available)
        return EPON_HAL_ERROR_NOT_SUPPORTED;
    *info = data.olt;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Store the log-selection mask; processing itself is never disabled. */
epon_hal_return_t epon_hal_set_oam_log_mask(uint32_t mask)
{
    epon_hal_return_t result = ready(EPON_TEST_OAM_MASK);
    if (result != EPON_HAL_SUCCESS)
        return result;
    if (!oam_supported)
        return EPON_HAL_ERROR_NOT_SUPPORTED;
    oam_mask = mask;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Allocate a fresh static/dynamic CPE snapshot when DPoE is enabled/supported. */
epon_hal_return_t dpoe_hal_get_cpe_mac_table(dpoe_cpe_mac_table_t *table)
{
    dpoe_cpe_mac_table_t value = {0};
    CHECK_OUTPUT(table, EPON_TEST_CPE);
    if (!dpoe_supported || !config.dpoe_supported)
        return EPON_HAL_ERROR_NOT_SUPPORTED;
    value.max_cpe = data.max_cpe;
    for (uint32_t i = 0; i < data.cpe_count; ++i)
        if (data.cpe[i].type == DPOE_CPE_MAC_STATIC)
            ++value.static_cpe_count;
        else
            ++value.dynamic_cpe_count;
    if (data.cpe_count != 0) {
        value.cpe_list = snapshot(data.cpe, data.cpe_count * sizeof(*value.cpe_list));
        if (value.cpe_list == NULL)
            return EPON_HAL_ERROR_MEMORY;
    }
    *table = value;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Emit distinct ONU status synchronously, checking all-interface readiness. */
epon_hal_return_t epon_test_onu(epon_onu_status_t status)
{
    if (status < EPON_ONU_STATUS_LOS || status > EPON_ONU_STATUS_DEREGISTRATION)
        return EPON_HAL_ERROR_INVALID_PARAM;
    if (!initialized)
        return EPON_HAL_ERROR_NOT_INITIALIZED;
    if (status == EPON_ONU_STATUS_REGISTRATION) {
        if (data.interfaces.interface_count == 0)
            return EPON_HAL_ERROR_RESOURCE;
        for (uint32_t i = 0; i < data.interfaces.interface_count; ++i)
            if (data.interfaces.interface[i].status != EPON_ONU_INTF_STATUS_LINK_UP)
                return EPON_HAL_ERROR_RESOURCE;
    }
    if (onu != status) {
        onu = status;
        if (config.status_callback != NULL)
            config.status_callback(status);
    }
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Change one interface by index; duplicates do not generate callbacks. */
epon_hal_return_t epon_test_interface(uint32_t index, epon_interface_link_status_t status)
{
    if (index >= data.interfaces.interface_count ||
        (status != EPON_ONU_INTF_STATUS_LINK_DOWN && status != EPON_ONU_INTF_STATUS_LINK_UP))
        return EPON_HAL_ERROR_INVALID_PARAM;
    if (!initialized)
        return EPON_HAL_ERROR_NOT_INITIALIZED;
    if (data.interfaces.interface[index].status != status) {
        data.interfaces.interface[index].status = status;
        if (config.interface_status_callback != NULL)
            config.interface_status_callback(data.interfaces.interface[index]);
    }
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Validate and replace the LLID list atomically without retaining input pointers. */
epon_hal_return_t epon_test_llids(const epon_llid_info_t *entries, uint32_t count)
{
    if (count > data.max_llids || (count != 0 && entries == NULL))
        return EPON_HAL_ERROR_INVALID_PARAM;
    for (uint32_t i = 0; i < count; ++i)
        if (!llid_valid(&entries[i]))
            return EPON_HAL_ERROR_INVALID_PARAM;
    if (count != 0)
        memcpy(data.llids, entries, count * sizeof(*entries));
    data.llid_count = count;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy learned OLT identity and independent availability state. */
epon_hal_return_t epon_test_olt(const epon_olt_info_t *info, bool available)
{
    if (info == NULL || info->struct_size != sizeof(*info))
        return EPON_HAL_ERROR_INVALID_PARAM;
    data.olt = *info;
    data.olt_available = available;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Validate and replace CPE entries atomically without retaining input pointers. */
epon_hal_return_t epon_test_cpe(const dpoe_cpe_mac_entry_t *entries, uint32_t count)
{
    if (count > data.max_cpe || (count != 0 && entries == NULL))
        return EPON_HAL_ERROR_INVALID_PARAM;
    for (uint32_t i = 0; i < count; ++i)
        if (!cpe_valid(&entries[i]))
            return EPON_HAL_ERROR_INVALID_PARAM;
    if (count != 0)
        memcpy(data.cpe, entries, count * sizeof(*entries));
    data.cpe_count = count;
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Deliver only valid discriminator/union combinations; caller keeps ownership. */
epon_hal_return_t epon_test_alarm(const epon_alarm_info_t *alarm)
{
    if (alarm == NULL ||
        (alarm->alarm_type != EPON_ALARM_TYPE_STANDARD &&
         alarm->alarm_type != EPON_ALARM_TYPE_VENDOR_SPECIFIC))
        return EPON_HAL_ERROR_INVALID_PARAM;
    if ((alarm->alarm_type == EPON_ALARM_TYPE_STANDARD &&
         (alarm->standard_alarm < EPON_HAL_ALARM_LOFI ||
          alarm->standard_alarm >= EPON_HAL_ALARM_MAX)) ||
        (alarm->alarm_type == EPON_ALARM_TYPE_VENDOR_SPECIFIC &&
         (alarm->vendor_alarm < EPON_VENDOR_ALARM_LOS ||
          alarm->vendor_alarm >= EPON_VENDOR_ALARM_MAX)))
        return EPON_HAL_ERROR_INVALID_PARAM;
    if (!initialized)
        return EPON_HAL_ERROR_NOT_INITIALIZED;
    if (config.alarm_callback != NULL)
        config.alarm_callback(alarm);
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Advance every full-width counter with defined unsigned rollover. */
epon_hal_return_t epon_test_advance_stats(uint64_t delta)
{
    if (!initialized)
        return EPON_HAL_ERROR_NOT_INITIALIZED;
#define ADVANCE(member) data.stats.member += delta;
    EPON_TEST_COUNTERS(ADVANCE)
#undef ADVANCE
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Advance deregistration to discovery, then to all-up registered readiness. */
epon_hal_return_t epon_test_step(void)
{
    if (!initialized)
        return EPON_HAL_ERROR_NOT_INITIALIZED;
    if (reset_phase == 0)
        return EPON_HAL_ERROR_RESOURCE;
    if (reset_phase == 1) {
        (void)epon_test_onu(EPON_ONU_STATUS_DOWNSTREAM_SIGNAL_DETECTED);
        for (uint32_t i = 0; i < data.llid_count; ++i)
            data.llids[i].state = EPON_LLID_STATE_REGISTERING;
        reset_phase = 2;
        return EPON_HAL_SUCCESS;
    }
    if (data.interfaces.interface_count == 0)
        return EPON_HAL_ERROR_RESOURCE;
    for (uint32_t i = 0; i < data.interfaces.interface_count; ++i)
        (void)epon_test_interface(i, EPON_ONU_INTF_STATUS_LINK_UP);
    for (uint32_t i = 0; i < data.llid_count; ++i) {
        data.llids[i].state = EPON_LLID_STATE_REGISTERED;
        data.llids[i].forwarding_state = EPON_LLID_FORWARDING_ENABLED;
    }
    reset_phase = 0;
    return epon_test_onu(EPON_ONU_STATUS_REGISTRATION);
}

/* PUBLIC_INTERFACE */
/** Observe simulated OAM processing and selected log categories in memory only. */
epon_hal_return_t epon_test_oam(uint32_t category)
{
    if (category == 0 || (category & (category - 1)) != 0 || (category & ~127u) != 0)
        return EPON_HAL_ERROR_INVALID_PARAM;
    if (!initialized)
        return EPON_HAL_ERROR_NOT_INITIALIZED;
    ++oam_observation.processed;
    if (oam_supported && (oam_mask & category) != 0) {
        ++oam_observation.logged;
        oam_observation.last_level = HAL_LOG_LEVEL_OAM;
        oam_observation.last_category = category;
    }
    return EPON_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return in-memory OAM evidence by value. */
epon_test_oam_observation_t epon_test_oam_observation(void)
{
    return oam_observation;
}
