#ifndef EPON_HAL_TEST_CONTROL_H
#define EPON_HAL_TEST_CONTROL_H
#ifndef BUILD_LINUX
#error "EPON model controls are Linux-only, not part of the public HAL ABI"
#endif
#include "epon_hal.h"

/*
 * Reference-model policies, NOT additional vendor conformance requirements:
 * G01/G04: serialized, in-process simulation; init copies config, accepts NULL
 * callbacks, rejects repeated init with CONFIG; failed calls are atomic.
 * G02/G03/G05: synchronous callbacks, copied payloads, borrowed alarm pointer
 * valid during invocation only; no initial or duplicate callbacks; deinit
 * unregisters without notifications. Returned snapshots survive teardown.
 * G06: malloc/free snapshots, empty arrays NULL, fresh output containers required;
 * failure leaves container unchanged; capacity bounded to 32 in this model.
 * G07/G08: exact struct_size only; fixed strings seeded/returned NUL-terminated.
 * G09/G10: atomic snapshots, explicit unsigned modulo-2^64 advancement; clear
 * zeros all 16 counters, preserves max_bit_rate and all nine optical readings.
 * G11: at most 16 unique nonempty interfaces; registration requires nonempty,
 * all-up interfaces. Interface callbacks precede aggregate registration only
 * in reset progression, not as a universal vendor ordering requirement.
 * G12/G13: factory reset allowed pre-init; restores defaults and removes config;
 * ONU reset preserves init/config/mask/telemetry and needs two explicit steps.
 * G14: pointer/size validation precedes init check, fault, capability/readiness;
 * per-API faults are one-shot; allocation failure is MEMORY with no output writes.
 * Version has no error channel and always returns API_VERSION (not faultable).
 * G15: DPoE requires both model capability and config flag.
 * G16: model implements exactly API 1.0.0; no broader ABI promise.
 * G17/G18: mask defaults to zero, accepts unknown bits, persists over ONU reset,
 * clears on deinit/factory reset; simulated OAM always processes and only logs
 * selected visible categories at OAM level to an in-memory observer, never stdio.
 * GATE/REPORT have no simulated software log category. No clocks, sleeps,
 * threads, devices, real reboot, network, files, or /rdklogs are used.
 */
#define EPON_TEST_CAPACITY 32u
#define EPON_TEST_COUNTERS(X) \
    X(packets_sent) X(packets_received) X(bytes_sent) X(bytes_received) \
    X(errors_sent) X(errors_received) X(discard_packets_sent) \
    X(discard_packets_received) X(fec_corrected) X(fec_uncorrectable) \
    X(broadcast_packets_sent) X(broadcast_packets_received) \
    X(multicast_packets_sent) X(multicast_packets_received) \
    X(ranging_resyncs) X(mac_resets)
#define EPON_TEST_OPTICAL(X) \
    X(transmit_optical_level) X(optical_signal_level) \
    X(lower_optical_threshold) X(upper_optical_threshold) \
    X(lower_transmit_power_threshold) X(upper_transmit_power_threshold) \
    X(bias_current) X(temperature) X(supply_voltage)

typedef enum {
    EPON_TEST_INIT, EPON_TEST_DEINIT, EPON_TEST_LINK_STATS,
    EPON_TEST_OPTICAL_STATS, EPON_TEST_LLIDS, EPON_TEST_MANUFACTURER,
    EPON_TEST_CLEAR, EPON_TEST_RESET_ONU, EPON_TEST_FACTORY,
    EPON_TEST_LINK_INFO, EPON_TEST_INTERFACES, EPON_TEST_OLT,
    EPON_TEST_OAM_MASK, EPON_TEST_CPE, EPON_TEST_API_COUNT
} epon_test_api_t;

typedef struct {
    epon_hal_link_stats_t stats;
    epon_hal_transceiver_stats_t optical;
    epon_onu_manufacturer_info_t manufacturer;
    epon_hal_link_info_t link;
    epon_interface_list_t interfaces;
    epon_olt_info_t olt;
    bool olt_available;
    uint32_t max_llids, llid_count;
    epon_llid_info_t llids[EPON_TEST_CAPACITY];
    uint32_t max_cpe, cpe_count;
    dpoe_cpe_mac_entry_t cpe[EPON_TEST_CAPACITY];
} epon_test_scenario_t;

typedef struct {
    uint64_t processed, logged;
    hal_log_level_t last_level;
    uint32_t last_category;
} epon_test_oam_observation_t;

/* PUBLIC_INTERFACE */
/** Reset all model data, capabilities, callbacks, faults and allocation controls. */
void epon_test_reset(void);
/* PUBLIC_INTERFACE */
/** Fill a complete deterministic scenario without changing model state. */
void epon_test_default_scenario(epon_test_scenario_t *scenario);
/* PUBLIC_INTERFACE */
/** Atomically validate/copy a complete scenario; invalid seeds change nothing. */
epon_hal_return_t epon_test_seed(const epon_test_scenario_t *scenario);
/* PUBLIC_INTERFACE */
/** Select optical, OAM and DPoE runtime capabilities independently of init. */
void epon_test_capabilities(bool optical, bool oam, bool dpoe);
/* PUBLIC_INTERFACE */
/** Arm one error for one status-returning API; SUCCESS clears that fault. */
void epon_test_fault(epon_test_api_t api, epon_hal_return_t result);
/* PUBLIC_INTERFACE */
/** Fail the nth subsequent snapshot allocation (1=next, 0=disable). */
void epon_test_fail_allocation(unsigned int nth);
/* PUBLIC_INTERFACE */
/** Deliver a distinct ONU state, enforcing the model registration readiness rule. */
epon_hal_return_t epon_test_onu(epon_onu_status_t status);
/* PUBLIC_INTERFACE */
/** Change one interface and deliver its by-value callback, without auto-register. */
epon_hal_return_t epon_test_interface(uint32_t index, epon_interface_link_status_t status);
/* PUBLIC_INTERFACE */
/** Atomically replace LLID observations, with enum/count validation. */
epon_hal_return_t epon_test_llids(const epon_llid_info_t *entries, uint32_t count);
/* PUBLIC_INTERFACE */
/** Supply learned OLT data and availability independently of registration. */
epon_hal_return_t epon_test_olt(const epon_olt_info_t *info, bool available);
/* PUBLIC_INTERFACE */
/** Atomically replace static/dynamic CPE observations. */
epon_hal_return_t epon_test_cpe(const dpoe_cpe_mac_entry_t *entries, uint32_t count);
/* PUBLIC_INTERFACE */
/** Emit a validated standard/vendor alarm by borrowed pointer during callback. */
epon_hal_return_t epon_test_alarm(const epon_alarm_info_t *alarm);
/* PUBLIC_INTERFACE */
/** Advance every counter modulo 2^64 without changing optical/rate readings. */
epon_hal_return_t epon_test_advance_stats(uint64_t delta);
/* PUBLIC_INTERFACE */
/** Advance one deterministic ONU-reset phase; RESOURCE if no reset is pending. */
epon_hal_return_t epon_test_step(void);
/* PUBLIC_INTERFACE */
/** Process a software-visible OAM category; observe mask-selected in-memory logs. */
epon_hal_return_t epon_test_oam(uint32_t category);
/* PUBLIC_INTERFACE */
/** Return OAM observation counters by value, without exposing internal pointers. */
epon_test_oam_observation_t epon_test_oam_observation(void);
#endif
