#ifndef EPON_TEST_HELPERS_H
#define EPON_TEST_HELPERS_H
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <ut.h>
#include "epon_hal.h"
#ifdef BUILD_LINUX
#include "epon_hal_test_control.h"
#endif

/* Keep independent lists in fixture storage so fatal assertions cannot leak. */
static epon_llid_list_t h_llids[2];
static dpoe_cpe_mac_table_t h_cpe[2];
static unsigned int h_status_count, h_interface_count, h_alarm_count;
static epon_onu_status_t h_status[128];
static epon_onu_interface_info_t h_interfaces[128];
static epon_alarm_info_t h_alarms[128];

#define EPON_CANARY UINT64_C(0x9a71b2c3d4e5f608)
#define EPON_GUARD(type, name) \
    struct { uint64_t before; type value; uint64_t after; } name = \
        { .before = EPON_CANARY, .after = EPON_CANARY }
#define EPON_CHECK_GUARD(name) do { \
    CU_ASSERT((name).before == EPON_CANARY); \
    CU_ASSERT((name).after == EPON_CANARY); \
} while (0)
#define OK(call) CU_ASSERT_EQUAL_FATAL((call), EPON_HAL_SUCCESS)
#define ERROR_IS(call, expected) CU_ASSERT_EQUAL((call), (expected))
/* CUnit's integer equality macro can narrow values; never use it for counters. */
#define U64_EQUAL(actual, expected) \
    CU_ASSERT((uint64_t)(actual) == (uint64_t)(expected))

/* PUBLIC_INTERFACE */
/** Initialize exactly the five size-bearing public types. */
#define EPON_SIZE_INITIALIZER(type, name) \
    static inline type name(void) { \
        type value = {0}; value.struct_size = sizeof(value); return value; \
    }
EPON_SIZE_INITIALIZER(epon_hal_config_t, epon_config)
EPON_SIZE_INITIALIZER(epon_hal_link_stats_t, epon_stats)
EPON_SIZE_INITIALIZER(epon_hal_transceiver_stats_t, epon_optical)
EPON_SIZE_INITIALIZER(epon_onu_manufacturer_info_t, epon_manufacturer)
EPON_SIZE_INITIALIZER(epon_olt_info_t, epon_olt)
#undef EPON_SIZE_INITIALIZER

static inline void capture_status(epon_onu_status_t status)
{
    if (h_status_count < 128)
        h_status[h_status_count] = status;
    ++h_status_count;
}

static inline void capture_interface(epon_onu_interface_info_t info)
{
    if (h_interface_count < 128)
        h_interfaces[h_interface_count] = info;
    ++h_interface_count;
}

static inline void capture_alarm(const epon_alarm_info_t *info)
{
    CU_ASSERT_PTR_NOT_NULL(info);
    if (info != NULL && h_alarm_count < 128)
        h_alarms[h_alarm_count] = *info;
    ++h_alarm_count;
}

static inline epon_hal_config_t epon_callbacks(void)
{
    epon_hal_config_t value = epon_config();
    value.dpoe_supported = true;
    value.status_callback = capture_status;
    value.interface_status_callback = capture_interface;
    value.alarm_callback = capture_alarm;
    return value;
}

static inline bool bounded_equal(const char *a, const char *b, size_t size)
{
    return memchr(a, '\0', size) != NULL && memchr(b, '\0', size) != NULL &&
        strncmp(a, b, size) == 0;
}

static inline bool interfaces_valid(const epon_interface_list_t *list)
{
    if (list->interface_count > EPON_HAL_MAX_INTERFACES)
        return false;
    for (uint32_t i = 0; i < list->interface_count; ++i)
        if (memchr(list->interface[i].name, '\0',
                   sizeof(list->interface[i].name)) == NULL ||
            (list->interface[i].status != EPON_ONU_INTF_STATUS_LINK_DOWN &&
             list->interface[i].status != EPON_ONU_INTF_STATUS_LINK_UP))
            return false;
    return true;
}

static inline bool llid_equal(const epon_llid_info_t *a, const epon_llid_info_t *b)
{
    return a->llid_value == b->llid_value && a->mode == b->mode &&
        a->state == b->state && a->forwarding_state == b->forwarding_state &&
        a->encryption_enabled == b->encryption_enabled &&
        memcmp(a->local_mac_address, b->local_mac_address, EPON_HAL_MAC_ADDR_LEN) == 0;
}

static inline bool cpe_equal(const dpoe_cpe_mac_entry_t *a, const dpoe_cpe_mac_entry_t *b)
{
    return a->type == b->type && a->age_time == b->age_time &&
        memcmp(a->mac_address, b->mac_address, EPON_HAL_MAC_ADDR_LEN) == 0;
}

static inline bool optical_equal(const epon_hal_transceiver_stats_t *a,
                                  const epon_hal_transceiver_stats_t *b)
{
    return a->struct_size == b->struct_size &&
        a->transmit_optical_level == b->transmit_optical_level &&
        a->optical_signal_level == b->optical_signal_level &&
        a->lower_optical_threshold == b->lower_optical_threshold &&
        a->upper_optical_threshold == b->upper_optical_threshold &&
        a->lower_transmit_power_threshold == b->lower_transmit_power_threshold &&
        a->upper_transmit_power_threshold == b->upper_transmit_power_threshold &&
        a->bias_current == b->bias_current && a->temperature == b->temperature &&
        a->supply_voltage == b->supply_voltage;
}

static inline void epon_fixture_cleanup(void)
{
    for (unsigned int i = 0; i < 2; ++i) {
        free(h_llids[i].llid_list);
        free(h_cpe[i].cpe_list);
        h_llids[i] = (epon_llid_list_t){0};
        h_cpe[i] = (dpoe_cpe_mac_table_t){0};
    }
#ifdef BUILD_LINUX
    epon_test_reset();
#else
    (void)epon_hal_deinit();
#endif
}

static inline void epon_fixture_setup(void)
{
    epon_fixture_cleanup();
    h_status_count = h_interface_count = h_alarm_count = 0;
    memset(h_status, 0, sizeof(h_status));
    memset(h_interfaces, 0, sizeof(h_interfaces));
    memset(h_alarms, 0, sizeof(h_alarms));
}

static inline void epon_initialized_setup(void)
{
    epon_hal_config_t value = epon_callbacks();
    epon_fixture_setup();
    OK(epon_hal_init(&value));
}

static inline void epon_install_fixture(UT_test_suite_t *suite, bool initialize)
{
    CU_pSuite cunit_suite = (CU_pSuite)suite;
    cunit_suite->pSetUpFunc = initialize ? epon_initialized_setup : epon_fixture_setup;
    cunit_suite->pTearDownFunc = epon_fixture_cleanup;
}

#ifdef BUILD_LINUX
static inline void model_register_onu(void)
{
    epon_interface_list_t list = {0};
    OK(epon_hal_get_interface_list(&list));
    CU_ASSERT_FATAL(interfaces_valid(&list));
    for (uint32_t i = 0; i < list.interface_count; ++i)
        OK(epon_test_interface(i, EPON_ONU_INTF_STATUS_LINK_UP));
    OK(epon_test_onu(EPON_ONU_STATUS_REGISTRATION));
}
#endif
#endif
