#include "epon_test_helpers.h"

static void initialize(void)
{
    epon_hal_config_t value = epon_callbacks();
    OK(epon_hal_init(&value));
}

static void test_version(void)
{
    CU_ASSERT((epon_hal_get_version() >> 24) == EPON_HAL_VERSION_MAJOR);
#ifdef BUILD_LINUX
    CU_ASSERT(epon_hal_get_version() == EPON_HAL_API_VERSION);
#endif
}

static void test_init(void)
{
    epon_hal_config_t value = epon_callbacks();
    ERROR_IS(epon_hal_init(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_init(&value));
#ifdef BUILD_LINUX
    ERROR_IS(epon_hal_init(&value), EPON_HAL_ERROR_CONFIG);
    OK(epon_hal_deinit());
    value = epon_config(); /* NULL callbacks are a model-only policy. */
    OK(epon_hal_init(&value));
#endif
}

static void test_deinit(void)
{
    ERROR_IS(epon_hal_deinit(), EPON_HAL_ERROR_NOT_INITIALIZED);
    initialize();
    OK(epon_hal_deinit());
    ERROR_IS(epon_hal_deinit(), EPON_HAL_ERROR_NOT_INITIALIZED);
    test_version();
}

static void test_link_stats(void)
{
    EPON_GUARD(epon_hal_link_stats_t, result);
    result.value = epon_stats();
    initialize();
    ERROR_IS(epon_hal_get_link_stats(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_get_link_stats(&result.value));
    CU_ASSERT(result.value.struct_size == sizeof(result.value));
#ifdef BUILD_LINUX
    epon_test_scenario_t seed;
    uint64_t next = UINT64_C(0x1234567800000011);
    epon_test_default_scenario(&seed);
#define SEED(member) seed.stats.member = next++;
    EPON_TEST_COUNTERS(SEED)
#undef SEED
    OK(epon_test_seed(&seed));
    OK(epon_hal_get_link_stats(&result.value));
#define CHECK(member) U64_EQUAL(result.value.member, seed.stats.member);
    EPON_TEST_COUNTERS(CHECK)
#undef CHECK
    CU_ASSERT_EQUAL(result.value.max_bit_rate, seed.stats.max_bit_rate);
#endif
    EPON_CHECK_GUARD(result);
}

static void test_transceiver(void)
{
    EPON_GUARD(epon_hal_transceiver_stats_t, result);
    epon_hal_return_t status;
    result.value = epon_optical();
    initialize();
    ERROR_IS(epon_hal_get_transceiver_stats(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    status = epon_hal_get_transceiver_stats(&result.value);
    CU_ASSERT(status == EPON_HAL_SUCCESS || status == EPON_HAL_ERROR_NOT_SUPPORTED);
#ifdef BUILD_LINUX
    epon_test_scenario_t seed;
    epon_test_default_scenario(&seed);
    CU_ASSERT(optical_equal(&result.value, &seed.optical));
    epon_test_capabilities(false, true, true);
    ERROR_IS(epon_hal_get_transceiver_stats(&result.value), EPON_HAL_ERROR_NOT_SUPPORTED);
    CU_ASSERT(optical_equal(&result.value, &seed.optical));
#endif
    EPON_CHECK_GUARD(result);
}

static void test_llids(void)
{
    initialize();
    ERROR_IS(epon_hal_get_llid_info(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_get_llid_info(&h_llids[0]));
    CU_ASSERT_FATAL(h_llids[0].llid_count <= h_llids[0].max_llid_count);
    if (h_llids[0].llid_count != 0)
        CU_ASSERT_PTR_NOT_NULL_FATAL(h_llids[0].llid_list);
#ifdef BUILD_LINUX
    epon_test_scenario_t seed;
    epon_test_default_scenario(&seed);
    CU_ASSERT_EQUAL_FATAL(h_llids[0].llid_count, seed.llid_count);
    for (uint32_t i = 0; i < seed.llid_count; ++i)
        CU_ASSERT(llid_equal(&h_llids[0].llid_list[i], &seed.llids[i]));
    OK(epon_hal_get_llid_info(&h_llids[1]));
    CU_ASSERT(h_llids[0].llid_list != h_llids[1].llid_list);
    h_llids[0].llid_list[0].llid_value = 0x1234;
    CU_ASSERT(h_llids[1].llid_list[0].llid_value == seed.llids[0].llid_value);
#endif
}

static void test_manufacturer(void)
{
    EPON_GUARD(epon_onu_manufacturer_info_t, result);
    result.value = epon_manufacturer();
    initialize();
    ERROR_IS(epon_hal_get_manufacturer_info(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_get_manufacturer_info(&result.value));
#ifdef BUILD_LINUX
    epon_test_scenario_t seed;
    epon_test_default_scenario(&seed);
#define SAME(member) CU_ASSERT(bounded_equal(result.value.member, seed.manufacturer.member, sizeof(result.value.member)));
    SAME(manufacturer)
    SAME(model_number)
    SAME(hardware_version)
    SAME(software_version)
    SAME(serial_number)
#undef SAME
    CU_ASSERT(memcmp(result.value.vendor_oui, seed.manufacturer.vendor_oui,
                     EPON_HAL_VENDOR_OUI_LEN) == 0);
#endif
    EPON_CHECK_GUARD(result);
}

static void test_clear(void)
{
    epon_hal_link_stats_t result = epon_stats();
    initialize();
#ifdef BUILD_LINUX
    OK(epon_test_advance_stats(UINT64_C(0x100000003)));
#endif
    OK(epon_hal_clear_stats());
    OK(epon_hal_get_link_stats(&result));
#define ZERO(member) U64_EQUAL(result.member, 0);
    ZERO(packets_sent) ZERO(packets_received) ZERO(bytes_sent) ZERO(bytes_received)
    ZERO(errors_sent) ZERO(errors_received) ZERO(discard_packets_sent)
    ZERO(discard_packets_received) ZERO(fec_corrected) ZERO(fec_uncorrectable)
    ZERO(broadcast_packets_sent) ZERO(broadcast_packets_received)
    ZERO(multicast_packets_sent) ZERO(multicast_packets_received)
    ZERO(ranging_resyncs) ZERO(mac_resets)
#undef ZERO
}

static void test_reset(void)
{
    initialize();
    OK(epon_hal_reset_onu());
    /* Success means initiated, not immediately registered. */
#ifdef BUILD_LINUX
    epon_olt_info_t result = epon_olt();
    ERROR_IS(epon_hal_get_olt_info(&result), EPON_HAL_ERROR_NOT_SUPPORTED);
    OK(epon_test_step());
    OK(epon_test_step());
    OK(epon_hal_get_olt_info(&result));
#endif
}

static void test_factory(void)
{
    epon_hal_link_stats_t result = epon_stats();
#ifdef BUILD_LINUX
    OK(epon_hal_factory_reset()); /* Pre-init legality is model policy only. */
#endif
    initialize();
    OK(epon_hal_factory_reset());
    ERROR_IS(epon_hal_get_link_stats(&result), EPON_HAL_ERROR_NOT_INITIALIZED);
    initialize();
    OK(epon_hal_get_link_stats(&result));
}

static void test_link_info(void)
{
    EPON_GUARD(epon_hal_link_info_t, result);
    initialize();
    ERROR_IS(epon_hal_get_link_info(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_get_link_info(&result.value));
#ifdef BUILD_LINUX
    CU_ASSERT(bounded_equal(result.value.mode, "10G-EPON", sizeof(result.value.mode)));
    CU_ASSERT_EQUAL(result.value.encryption, EPON_ENCRYPTION_MODE_AES_128);
#endif
    EPON_CHECK_GUARD(result);
}

static void test_interfaces(void)
{
    EPON_GUARD(epon_interface_list_t, result);
    initialize();
    ERROR_IS(epon_hal_get_interface_list(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_get_interface_list(&result.value));
    /* Validate count before any indexing; no vendor string-termination assumption. */
    CU_ASSERT_FATAL(result.value.interface_count <= EPON_HAL_MAX_INTERFACES);
#ifdef BUILD_LINUX
    CU_ASSERT(interfaces_valid(&result.value));
    CU_ASSERT_EQUAL(result.value.interface_count, 2);
    for (uint32_t i = 0; i < result.value.interface_count; ++i)
        CU_ASSERT_EQUAL(result.value.interface[i].status, EPON_ONU_INTF_STATUS_LINK_DOWN);
#endif
    EPON_CHECK_GUARD(result);
}

static void test_olt(void)
{
    EPON_GUARD(epon_olt_info_t, result);
    result.value = epon_olt();
    initialize();
    ERROR_IS(epon_hal_get_olt_info(NULL), EPON_HAL_ERROR_INVALID_PARAM);
#ifdef BUILD_LINUX
    epon_test_scenario_t seed;
    epon_test_default_scenario(&seed);
    ERROR_IS(epon_hal_get_olt_info(&result.value), EPON_HAL_ERROR_NOT_SUPPORTED);
    model_register_onu();
    OK(epon_hal_get_olt_info(&result.value));
    CU_ASSERT(memcmp(result.value.mac_address, seed.olt.mac_address, EPON_HAL_MAC_ADDR_LEN) == 0);
    CU_ASSERT(memcmp(result.value.vendor_oui, seed.olt.vendor_oui, EPON_HAL_VENDOR_OUI_LEN) == 0);
#else
    epon_hal_return_t status = epon_hal_get_olt_info(&result.value);
    CU_ASSERT(status == EPON_HAL_SUCCESS || status == EPON_HAL_ERROR_NOT_SUPPORTED);
#endif
    EPON_CHECK_GUARD(result);
}

static void test_oam_mask(void)
{
    const uint32_t masks[] = {0, EPON_OAM_INFO | EPON_OAM_EVENT, EPON_OAM_ALL};
    initialize();
    for (size_t i = 0; i < sizeof(masks) / sizeof(masks[0]); ++i) {
        epon_hal_return_t status = epon_hal_set_oam_log_mask(masks[i]);
        CU_ASSERT(status == EPON_HAL_SUCCESS || status == EPON_HAL_ERROR_NOT_SUPPORTED);
    }
#ifdef BUILD_LINUX
    epon_test_capabilities(true, false, true);
    ERROR_IS(epon_hal_set_oam_log_mask(EPON_OAM_ALL), EPON_HAL_ERROR_NOT_SUPPORTED);
#endif
}

static void test_cpe(void)
{
    epon_hal_return_t status;
    initialize();
    ERROR_IS(dpoe_hal_get_cpe_mac_table(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    status = dpoe_hal_get_cpe_mac_table(&h_cpe[0]);
    CU_ASSERT(status == EPON_HAL_SUCCESS || status == EPON_HAL_ERROR_NOT_SUPPORTED);
    if (status == EPON_HAL_SUCCESS) {
        uint64_t count = (uint64_t)h_cpe[0].static_cpe_count + h_cpe[0].dynamic_cpe_count;
        CU_ASSERT_FATAL(count <= h_cpe[0].max_cpe);
        if (count != 0)
            CU_ASSERT_PTR_NOT_NULL_FATAL(h_cpe[0].cpe_list);
    }
#ifdef BUILD_LINUX
    epon_test_scenario_t seed;
    epon_test_default_scenario(&seed);
    CU_ASSERT_EQUAL_FATAL(h_cpe[0].static_cpe_count, 1);
    CU_ASSERT_EQUAL_FATAL(h_cpe[0].dynamic_cpe_count, 1);
    for (uint32_t i = 0; i < 2; ++i)
        CU_ASSERT(cpe_equal(&h_cpe[0].cpe_list[i], &seed.cpe[i]));
    epon_test_capabilities(true, true, false);
    ERROR_IS(dpoe_hal_get_cpe_mac_table(&h_cpe[1]), EPON_HAL_ERROR_NOT_SUPPORTED);
#endif
}

static void test_preinit(void)
{
    epon_hal_link_stats_t stats = epon_stats();
    epon_hal_transceiver_stats_t optical = epon_optical();
    epon_onu_manufacturer_info_t manufacturer = epon_manufacturer();
    epon_olt_info_t olt = epon_olt();
    epon_hal_link_info_t link = {0};
    epon_interface_list_t interfaces = {0};
#define PRE(call) ERROR_IS(call, EPON_HAL_ERROR_NOT_INITIALIZED)
    PRE(epon_hal_deinit());
    PRE(epon_hal_get_link_stats(&stats));
    PRE(epon_hal_get_transceiver_stats(&optical));
    PRE(epon_hal_get_llid_info(&h_llids[0]));
    PRE(epon_hal_get_manufacturer_info(&manufacturer));
    PRE(epon_hal_clear_stats());
    PRE(epon_hal_reset_onu());
    PRE(epon_hal_get_link_info(&link));
    PRE(epon_hal_get_interface_list(&interfaces));
    PRE(epon_hal_get_olt_info(&olt));
    PRE(epon_hal_set_oam_log_mask(0));
    PRE(dpoe_hal_get_cpe_mac_table(&h_cpe[0]));
#undef PRE
    test_version();
}

static void test_sizes(void)
{
    epon_hal_config_t config = epon_callbacks();
    const uint32_t sizes[] = {0, 1, UINT32_MAX};
    for (size_t i = 0; i < sizeof(sizes) / sizeof(sizes[0]); ++i) {
        config.struct_size = sizes[i];
        ERROR_IS(epon_hal_init(&config), EPON_HAL_ERROR_INVALID_PARAM);
    }
    config.struct_size = sizeof(config) - 1;
    ERROR_IS(epon_hal_init(&config), EPON_HAL_ERROR_INVALID_PARAM);
    config.struct_size = sizeof(config) + 1;
    ERROR_IS(epon_hal_init(&config), EPON_HAL_ERROR_INVALID_PARAM);
    initialize();
#define INVALID_SIZES(type, getter) do { \
    EPON_GUARD(type, output); \
    for (size_t i = 0; i < sizeof(sizes) / sizeof(sizes[0]); ++i) { \
        output.value.struct_size = sizes[i]; \
        ERROR_IS(getter(&output.value), EPON_HAL_ERROR_INVALID_PARAM); \
        EPON_CHECK_GUARD(output); \
    } \
    output.value.struct_size = sizeof(output.value) - 1; \
    ERROR_IS(getter(&output.value), EPON_HAL_ERROR_INVALID_PARAM); \
    output.value.struct_size = sizeof(output.value) + 1; \
    ERROR_IS(getter(&output.value), EPON_HAL_ERROR_INVALID_PARAM); \
    EPON_CHECK_GUARD(output); \
} while (0)
    INVALID_SIZES(epon_hal_link_stats_t, epon_hal_get_link_stats);
    INVALID_SIZES(epon_hal_transceiver_stats_t, epon_hal_get_transceiver_stats);
    INVALID_SIZES(epon_onu_manufacturer_info_t, epon_hal_get_manufacturer_info);
    INVALID_SIZES(epon_olt_info_t, epon_hal_get_olt_info);
#undef INVALID_SIZES
}

#ifdef BUILD_LINUX
static void test_documented_errors(void)
{
    const epon_hal_return_t init_errors[] = {
        EPON_HAL_ERROR_WRONG_PON_MODE, EPON_HAL_ERROR_HW_FAILURE,
        EPON_HAL_ERROR_CALLBACK_REG, EPON_HAL_ERROR_TIMEOUT
    };
    epon_hal_config_t value = epon_callbacks();
    for (size_t i = 0; i < sizeof(init_errors) / sizeof(init_errors[0]); ++i) {
        epon_test_fault(EPON_TEST_INIT, init_errors[i]);
        ERROR_IS(epon_hal_init(&value), init_errors[i]);
        epon_hal_link_stats_t stats = epon_stats();
        ERROR_IS(epon_hal_get_link_stats(&stats), EPON_HAL_ERROR_NOT_INITIALIZED);
    }
    initialize();
    epon_test_fault(EPON_TEST_DEINIT, EPON_HAL_ERROR_HW_FAILURE);
    ERROR_IS(epon_hal_deinit(), EPON_HAL_ERROR_HW_FAILURE);
    epon_test_fault(EPON_TEST_CLEAR, EPON_HAL_ERROR_HW_FAILURE);
    ERROR_IS(epon_hal_clear_stats(), EPON_HAL_ERROR_HW_FAILURE);
    epon_test_fault(EPON_TEST_RESET_ONU, EPON_HAL_ERROR_HW_FAILURE);
    ERROR_IS(epon_hal_reset_onu(), EPON_HAL_ERROR_HW_FAILURE);
    epon_test_fault(EPON_TEST_FACTORY, EPON_HAL_ERROR_HW_FAILURE);
    ERROR_IS(epon_hal_factory_reset(), EPON_HAL_ERROR_HW_FAILURE);
    epon_test_fault(EPON_TEST_FACTORY, EPON_HAL_ERROR_CONFIG);
    ERROR_IS(epon_hal_factory_reset(), EPON_HAL_ERROR_CONFIG);
    epon_test_fail_allocation(1);
    ERROR_IS(epon_hal_get_llid_info(&h_llids[0]), EPON_HAL_ERROR_MEMORY);
    CU_ASSERT_PTR_NULL(h_llids[0].llid_list);
    OK(epon_hal_get_llid_info(&h_llids[0]));
    epon_test_fail_allocation(1);
    ERROR_IS(dpoe_hal_get_cpe_mac_table(&h_cpe[0]), EPON_HAL_ERROR_MEMORY);
    CU_ASSERT_PTR_NULL(h_cpe[0].cpe_list);
    OK(dpoe_hal_get_cpe_mac_table(&h_cpe[0]));
}

static void test_boundaries(void)
{
    epon_test_scenario_t seed, invalid;
    EPON_GUARD(epon_interface_list_t, interfaces);
    EPON_GUARD(epon_onu_manufacturer_info_t, manufacturer);
    manufacturer.value = epon_manufacturer();
    epon_test_default_scenario(&seed);
    seed.interfaces.interface_count = EPON_HAL_MAX_INTERFACES;
    seed.llid_count = seed.max_llids;
    seed.cpe_count = seed.max_cpe;
    for (uint32_t i = 0; i < EPON_HAL_MAX_INTERFACES; ++i) {
        memset(seed.interfaces.interface[i].name, 'x', EPON_HAL_INTERFACE_NAME_LEN - 1);
        seed.interfaces.interface[i].name[0] = (char)('A' + i);
        seed.interfaces.interface[i].name[EPON_HAL_INTERFACE_NAME_LEN - 1] = '\0';
    }
#define MAX_STRING(member) do { \
    memset(seed.manufacturer.member, 'M', sizeof(seed.manufacturer.member) - 1); \
    seed.manufacturer.member[sizeof(seed.manufacturer.member) - 1] = '\0'; \
} while (0)
    MAX_STRING(manufacturer); MAX_STRING(model_number); MAX_STRING(hardware_version);
    MAX_STRING(software_version); MAX_STRING(serial_number);
#undef MAX_STRING
    for (uint32_t i = 0; i < EPON_TEST_CAPACITY; ++i) {
        seed.llids[i].llid_value = (uint16_t)i;
        seed.cpe[i].type = i % 2 ? DPOE_CPE_MAC_DYNAMIC : DPOE_CPE_MAC_STATIC;
        seed.cpe[i].age_time = i % 2 ? UINT32_MAX : 0;
    }
    OK(epon_test_seed(&seed));
    initialize();
    OK(epon_hal_get_interface_list(&interfaces.value));
    CU_ASSERT_EQUAL(interfaces.value.interface_count, EPON_HAL_MAX_INTERFACES);
    CU_ASSERT(interfaces_valid(&interfaces.value));
    EPON_CHECK_GUARD(interfaces);
    OK(epon_hal_get_manufacturer_info(&manufacturer.value));
#define SAME(member) CU_ASSERT(bounded_equal(manufacturer.value.member, seed.manufacturer.member, sizeof(manufacturer.value.member)));
    SAME(manufacturer) SAME(model_number) SAME(hardware_version)
    SAME(software_version) SAME(serial_number)
#undef SAME
    EPON_CHECK_GUARD(manufacturer);
    OK(epon_hal_get_llid_info(&h_llids[0]));
    OK(dpoe_hal_get_cpe_mac_table(&h_cpe[0]));
    CU_ASSERT_EQUAL(h_llids[0].llid_count, EPON_TEST_CAPACITY);
    CU_ASSERT_EQUAL(h_cpe[0].static_cpe_count + h_cpe[0].dynamic_cpe_count, EPON_TEST_CAPACITY);
    invalid = seed;
    invalid.interfaces.interface_count++;
    ERROR_IS(epon_test_seed(&invalid), EPON_HAL_ERROR_INVALID_PARAM);
    invalid = seed;
    invalid.llid_count++;
    ERROR_IS(epon_test_seed(&invalid), EPON_HAL_ERROR_INVALID_PARAM);
    invalid = seed;
    invalid.cpe_count++;
    ERROR_IS(epon_test_seed(&invalid), EPON_HAL_ERROR_INVALID_PARAM);
    seed.interfaces.interface_count = seed.llid_count = seed.cpe_count = 0;
    OK(epon_test_seed(&seed));
    OK(epon_hal_get_interface_list(&interfaces.value));
    OK(epon_hal_get_llid_info(&h_llids[1]));
    OK(dpoe_hal_get_cpe_mac_table(&h_cpe[1]));
    CU_ASSERT_EQUAL(interfaces.value.interface_count, 0);
    CU_ASSERT_EQUAL(h_llids[1].llid_count, 0);
    CU_ASSERT_PTR_NULL(h_llids[1].llid_list);
    CU_ASSERT_EQUAL(h_cpe[1].static_cpe_count + h_cpe[1].dynamic_cpe_count, 0);
    CU_ASSERT_PTR_NULL(h_cpe[1].cpe_list);
    ERROR_IS(epon_test_onu(EPON_ONU_STATUS_REGISTRATION), EPON_HAL_ERROR_RESOURCE);
}
#endif

/* PUBLIC_INTERFACE */
/** Register 17 common API cases and two Linux-only fault/boundary cases. */
int test_epon_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID("[L1 EPON APIs]", NULL, NULL, UT_TESTS_L1);
    if (suite == NULL)
        return -1;
    epon_install_fixture(suite, false);
#define ADD(name) if (UT_add_test(suite, #name, test_##name) == NULL) return -1
    ADD(version); ADD(init); ADD(deinit); ADD(link_stats); ADD(transceiver);
    ADD(llids); ADD(manufacturer); ADD(clear); ADD(reset); ADD(factory);
    ADD(link_info); ADD(interfaces); ADD(olt); ADD(oam_mask); ADD(cpe);
    ADD(preinit); ADD(sizes);
#ifdef BUILD_LINUX
    ADD(documented_errors); ADD(boundaries);
#endif
#undef ADD
    return 0;
}
