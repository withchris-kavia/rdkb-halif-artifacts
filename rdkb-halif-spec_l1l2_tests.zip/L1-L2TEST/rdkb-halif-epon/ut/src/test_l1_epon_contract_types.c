#include <stddef.h>
#include <stdint.h>
#include <ut.h>
#include "epon_hal.h"

#define VALUE(name, expected) _Static_assert((name) == (expected), #name)
#define FIELD(type, member, expected) \
    _Static_assert(_Generic(((type *)0)->member, expected: 1, default: 0), #type "." #member)
#define ARRAY(type, member, count, element) \
    _Static_assert(sizeof(((type *)0)->member) == (count) * sizeof(element), #type "." #member); \
    _Static_assert(_Generic(&((type *)0)->member[0], element *: 1, default: 0), #member " element")
#define SIZE_FIELD(type) \
    FIELD(type, struct_size, uint32_t); \
    _Static_assert(offsetof(type, struct_size) == 0, #type " size prefix")

VALUE(HAL_LOG_LEVEL_FATAL, 0); VALUE(HAL_LOG_LEVEL_ERROR, 1);
VALUE(HAL_LOG_LEVEL_WARN, 2); VALUE(HAL_LOG_LEVEL_NOTICE, 3);
VALUE(HAL_LOG_LEVEL_INFO, 4); VALUE(HAL_LOG_LEVEL_OAM, 5);
VALUE(HAL_LOG_LEVEL_DEBUG, 6); VALUE(HAL_LOG_LEVEL_TRACE, 7);
VALUE(EPON_HAL_SUCCESS, 0); VALUE(EPON_HAL_ERROR_INVALID_PARAM, -1);
VALUE(EPON_HAL_ERROR_NOT_INITIALIZED, -2); VALUE(EPON_HAL_ERROR_HW_FAILURE, -3);
VALUE(EPON_HAL_ERROR_NOT_SUPPORTED, -4); VALUE(EPON_HAL_ERROR_TIMEOUT, -5);
VALUE(EPON_HAL_ERROR_MEMORY, -6); VALUE(EPON_HAL_ERROR_RESOURCE, -7);
VALUE(EPON_HAL_ERROR_CALLBACK_REG, -8); VALUE(EPON_HAL_ERROR_CONFIG, -9);
VALUE(EPON_HAL_ERROR_WRONG_PON_MODE, -10); VALUE(EPON_HAL_ERROR, -11);
VALUE(EPON_ONU_STATUS_LOS, 0); VALUE(EPON_ONU_STATUS_DOWNSTREAM_SIGNAL_DETECTED, 1);
VALUE(EPON_ONU_STATUS_REGISTRATION, 2); VALUE(EPON_ONU_STATUS_DEREGISTRATION, 3);
VALUE(EPON_ONU_INTF_STATUS_LINK_DOWN, 0); VALUE(EPON_ONU_INTF_STATUS_LINK_UP, 1);
VALUE(EPON_HAL_ALARM_LOFI, 0); VALUE(EPON_HAL_ALARM_ERROR_SYMBOL_PERIOD, 1);
VALUE(EPON_HAL_ALARM_ERROR_FRAME, 2); VALUE(EPON_HAL_ALARM_ERROR_FRAME_PERIOD, 3);
VALUE(EPON_HAL_ALARM_ERROR_FRAME_SECONDS, 4); VALUE(EPON_HAL_ALARM_OAM_SESSION_LOST, 5);
VALUE(EPON_HAL_ALARM_EQUIPMENT_FAILURE, 6); VALUE(EPON_HAL_ALARM_MAX, 7);
VALUE(EPON_VENDOR_ALARM_LOS, 0); VALUE(EPON_VENDOR_ALARM_DYING_GASP, 1);
VALUE(EPON_VENDOR_ALARM_POWER_LOW, 2); VALUE(EPON_VENDOR_ALARM_POWER_HIGH, 3);
VALUE(EPON_VENDOR_ALARM_TEMPERATURE, 4); VALUE(EPON_VENDOR_ALARM_FEC_THRESHOLD, 5);
VALUE(EPON_VENDOR_ALARM_LASER_BIAS_CURRENT, 6); VALUE(EPON_VENDOR_ALARM_SUPPLY_VOLTAGE, 7);
VALUE(EPON_VENDOR_ALARM_MAX, 8);
VALUE(EPON_ALARM_TYPE_STANDARD, 0); VALUE(EPON_ALARM_TYPE_VENDOR_SPECIFIC, 1);
VALUE(EPON_OAM_INFO, 1u << 0); VALUE(EPON_OAM_EVENT, 1u << 1);
VALUE(EPON_OAM_VAR_REQUEST, 1u << 2); VALUE(EPON_OAM_VAR_RESPONSE, 1u << 3);
VALUE(EPON_OAM_LOOPBACK, 1u << 4); VALUE(EPON_OAM_MPCP_REGISTER, 1u << 5);
VALUE(EPON_OAM_MPCP_REGISTER_ACK, 1u << 6); VALUE(EPON_OAM_ALL, UINT32_MAX);
VALUE(EPON_LLID_MODE_UNICAST, 0); VALUE(EPON_LLID_MODE_BROADCAST, 1);
VALUE(EPON_LLID_STATE_UNREGISTERED, 0); VALUE(EPON_LLID_STATE_REGISTERING, 1);
VALUE(EPON_LLID_STATE_REGISTERED, 2); VALUE(EPON_LLID_STATE_DEREGISTERING, 3);
VALUE(EPON_LLID_STATE_FAILED, 4);
VALUE(EPON_LLID_FORWARDING_DISABLED, 0); VALUE(EPON_LLID_FORWARDING_ENABLED, 1);
VALUE(EPON_LLID_FORWARDING_LEARNING, 2);
VALUE(EPON_ENCRYPTION_MODE_DISABLED, 0); VALUE(EPON_ENCRYPTION_MODE_AES_128, 1);
VALUE(EPON_ENCRYPTION_MODE_TRIPLE_CHURNING, 2); VALUE(EPON_ENCRYPTION_MODE_AES_256, 3);
VALUE(DPOE_CPE_MAC_STATIC, 0); VALUE(DPOE_CPE_MAC_DYNAMIC, 1);

VALUE(EPON_HAL_VERSION_MAJOR, 1); VALUE(EPON_HAL_VERSION_MINOR, 0);
VALUE(EPON_HAL_VERSION_PATCH, 0); VALUE(EPON_HAL_API_VERSION, UINT32_C(0x01000000));
VALUE(EPON_HAL_MAKE_VERSION(0x12u, 0x34u, 0x5678u), UINT32_C(0x12345678));
VALUE(EPON_HAL_MAC_ADDR_LEN, 6); VALUE(EPON_HAL_VENDOR_OUI_LEN, 3);
VALUE(EPON_HAL_MANUFACTURER_LEN, 32); VALUE(EPON_HAL_MODEL_NUMBER_LEN, 16);
VALUE(EPON_HAL_HW_VERSION_LEN, 16); VALUE(EPON_HAL_SW_VERSION_LEN, 16);
VALUE(EPON_HAL_SERIAL_NUMBER_LEN, 32); VALUE(EPON_HAL_MODE_LEN, 16);
VALUE(EPON_HAL_MAX_INTERFACES, 16); VALUE(EPON_HAL_INTERFACE_NAME_LEN, 32);
VALUE(EPON_HAL_OLT_VENDOR_INFO_LEN, 64); VALUE(EPON_LLID_NOT_APPLICABLE, 0xffff);
#ifndef HAL_LOG
#error "HAL_LOG must be declared (behavior verified by logger_probe.c)"
#endif
#ifndef HAL_LOG_FUNCTION
#error "HAL_LOG_FUNCTION must be declared"
#endif

ARRAY(epon_onu_interface_info_t, name, EPON_HAL_INTERFACE_NAME_LEN, char);
FIELD(epon_onu_interface_info_t, status, epon_interface_link_status_t);
FIELD(epon_alarm_info_t, alarm_type, epon_alarm_type_t);
FIELD(epon_alarm_info_t, standard_alarm, epon_hal_alarm_t);
FIELD(epon_alarm_info_t, vendor_alarm, epon_vendor_alarm_t);
FIELD(epon_alarm_info_t, llid, uint16_t);
FIELD(epon_alarm_info_t, is_active, bool);
_Static_assert(offsetof(epon_alarm_info_t, standard_alarm) ==
               offsetof(epon_alarm_info_t, vendor_alarm), "anonymous alarm union");

SIZE_FIELD(epon_hal_link_stats_t);
#define COUNTER(member) FIELD(epon_hal_link_stats_t, member, uint64_t); \
    _Static_assert(sizeof(((epon_hal_link_stats_t *)0)->member) == 8, #member " width")
COUNTER(packets_sent); COUNTER(packets_received); COUNTER(bytes_sent);
COUNTER(bytes_received); COUNTER(errors_sent); COUNTER(errors_received);
COUNTER(discard_packets_sent); COUNTER(discard_packets_received);
COUNTER(fec_corrected); COUNTER(fec_uncorrectable);
COUNTER(broadcast_packets_sent); COUNTER(broadcast_packets_received);
COUNTER(multicast_packets_sent); COUNTER(multicast_packets_received);
COUNTER(ranging_resyncs); COUNTER(mac_resets);
FIELD(epon_hal_link_stats_t, max_bit_rate, uint32_t);

SIZE_FIELD(epon_hal_transceiver_stats_t);
#define OPTICAL(member) FIELD(epon_hal_transceiver_stats_t, member, float)
OPTICAL(transmit_optical_level); OPTICAL(optical_signal_level);
OPTICAL(lower_optical_threshold); OPTICAL(upper_optical_threshold);
OPTICAL(lower_transmit_power_threshold); OPTICAL(upper_transmit_power_threshold);
OPTICAL(bias_current); OPTICAL(temperature); OPTICAL(supply_voltage);

FIELD(epon_llid_info_t, llid_value, uint16_t);
FIELD(epon_llid_info_t, mode, epon_llid_mode_t);
FIELD(epon_llid_info_t, state, epon_llid_state_t);
FIELD(epon_llid_info_t, forwarding_state, epon_llid_forwarding_state_t);
FIELD(epon_llid_info_t, encryption_enabled, bool);
ARRAY(epon_llid_info_t, local_mac_address, EPON_HAL_MAC_ADDR_LEN, uint8_t);
FIELD(epon_llid_list_t, max_llid_count, uint32_t);
FIELD(epon_llid_list_t, llid_count, uint32_t);
FIELD(epon_llid_list_t, llid_list, epon_llid_info_t *);

SIZE_FIELD(epon_onu_manufacturer_info_t);
ARRAY(epon_onu_manufacturer_info_t, manufacturer, EPON_HAL_MANUFACTURER_LEN, char);
ARRAY(epon_onu_manufacturer_info_t, model_number, EPON_HAL_MODEL_NUMBER_LEN, char);
ARRAY(epon_onu_manufacturer_info_t, hardware_version, EPON_HAL_HW_VERSION_LEN, char);
ARRAY(epon_onu_manufacturer_info_t, software_version, EPON_HAL_SW_VERSION_LEN, char);
ARRAY(epon_onu_manufacturer_info_t, serial_number, EPON_HAL_SERIAL_NUMBER_LEN, char);
ARRAY(epon_onu_manufacturer_info_t, vendor_oui, EPON_HAL_VENDOR_OUI_LEN, uint8_t);
ARRAY(epon_hal_link_info_t, mode, EPON_HAL_MODE_LEN, char);
FIELD(epon_hal_link_info_t, encryption, epon_encryption_mode_t);
FIELD(epon_interface_list_t, interface_count, uint32_t);
ARRAY(epon_interface_list_t, interface, EPON_HAL_MAX_INTERFACES, epon_onu_interface_info_t);
SIZE_FIELD(epon_olt_info_t);
ARRAY(epon_olt_info_t, mac_address, EPON_HAL_MAC_ADDR_LEN, uint8_t);
ARRAY(epon_olt_info_t, vendor_oui, EPON_HAL_VENDOR_OUI_LEN, uint8_t);
SIZE_FIELD(epon_hal_config_t);
FIELD(epon_hal_config_t, dpoe_supported, bool);
FIELD(epon_hal_config_t, status_callback, void (*)(epon_onu_status_t));
FIELD(epon_hal_config_t, alarm_callback, void (*)(const epon_alarm_info_t *));
FIELD(epon_hal_config_t, interface_status_callback, void (*)(epon_onu_interface_info_t));
ARRAY(dpoe_cpe_mac_entry_t, mac_address, EPON_HAL_MAC_ADDR_LEN, uint8_t);
FIELD(dpoe_cpe_mac_entry_t, type, dpoe_cpe_mac_type_t);
FIELD(dpoe_cpe_mac_entry_t, age_time, uint32_t);
FIELD(dpoe_cpe_mac_table_t, max_cpe, uint32_t);
FIELD(dpoe_cpe_mac_table_t, static_cpe_count, uint32_t);
FIELD(dpoe_cpe_mac_table_t, dynamic_cpe_count, uint32_t);
FIELD(dpoe_cpe_mac_table_t, cpe_list, dpoe_cpe_mac_entry_t *);

#define SIGNATURE(function, type) \
    _Static_assert(_Generic(&(function), type: 1, default: 0), #function " signature")
SIGNATURE(epon_hal_get_version, uint32_t (*)(void));
SIGNATURE(epon_hal_init, epon_hal_return_t (*)(const epon_hal_config_t *));
SIGNATURE(epon_hal_deinit, epon_hal_return_t (*)(void));
SIGNATURE(epon_hal_get_link_stats, epon_hal_return_t (*)(epon_hal_link_stats_t *));
SIGNATURE(epon_hal_get_transceiver_stats, epon_hal_return_t (*)(epon_hal_transceiver_stats_t *));
SIGNATURE(epon_hal_get_llid_info, epon_hal_return_t (*)(epon_llid_list_t *));
SIGNATURE(epon_hal_get_manufacturer_info, epon_hal_return_t (*)(epon_onu_manufacturer_info_t *));
SIGNATURE(epon_hal_clear_stats, epon_hal_return_t (*)(void));
SIGNATURE(epon_hal_reset_onu, epon_hal_return_t (*)(void));
SIGNATURE(epon_hal_factory_reset, epon_hal_return_t (*)(void));
SIGNATURE(epon_hal_get_link_info, epon_hal_return_t (*)(epon_hal_link_info_t *));
SIGNATURE(epon_hal_get_interface_list, epon_hal_return_t (*)(epon_interface_list_t *));
SIGNATURE(epon_hal_get_olt_info, epon_hal_return_t (*)(epon_olt_info_t *));
SIGNATURE(epon_hal_set_oam_log_mask, epon_hal_return_t (*)(uint32_t));
SIGNATURE(dpoe_hal_get_cpe_mac_table, epon_hal_return_t (*)(dpoe_cpe_mac_table_t *));

static void test_enums_and_macros(void)
{
    /* Compile assertions above cover all 13 enums and 19 non-guard macros. */
    CU_ASSERT(EPON_HAL_API_VERSION == EPON_HAL_MAKE_VERSION(1u, 0u, 0u));
    CU_ASSERT((uint32_t)EPON_OAM_ALL == UINT32_MAX);
}

static void test_structures(void)
{
    epon_alarm_info_t alarm = { .alarm_type = EPON_ALARM_TYPE_STANDARD,
        .standard_alarm = EPON_HAL_ALARM_LOFI, .llid = EPON_LLID_NOT_APPLICABLE,
        .is_active = true };
    CU_ASSERT_EQUAL(alarm.standard_alarm, EPON_HAL_ALARM_LOFI);
    alarm.alarm_type = EPON_ALARM_TYPE_VENDOR_SPECIFIC;
    alarm.vendor_alarm = EPON_VENDOR_ALARM_DYING_GASP;
    CU_ASSERT_EQUAL(alarm.vendor_alarm, EPON_VENDOR_ALARM_DYING_GASP);
    CU_ASSERT_EQUAL(alarm.llid, EPON_LLID_NOT_APPLICABLE);
    CU_ASSERT(alarm.is_active);
}

static void test_function_declarations(void)
{
    /* Link references ensure the compile-checked declarations have C symbols. */
    uint32_t (*version)(void) = epon_hal_get_version;
    epon_hal_return_t (*dpoe)(dpoe_cpe_mac_table_t *) = dpoe_hal_get_cpe_mac_table;
    CU_ASSERT_PTR_NOT_NULL(version);
    CU_ASSERT_PTR_NOT_NULL(dpoe);
}

/* PUBLIC_INTERFACE */
/** Register declaration-only checks; no model controls or hardware assumptions. */
int test_epon_contract_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID("[L1 EPON contract types]", NULL, NULL, UT_TESTS_L1);
    if (suite == NULL)
        return -1;
    if (UT_add_test(suite, "enums_and_macros", test_enums_and_macros) == NULL ||
        UT_add_test(suite, "structures", test_structures) == NULL ||
        UT_add_test(suite, "function_declarations", test_function_declarations) == NULL)
        return -1;
    return 0;
}
