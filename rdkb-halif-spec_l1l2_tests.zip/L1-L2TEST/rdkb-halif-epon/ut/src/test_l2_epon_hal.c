#include "epon_test_helpers.h"

static void test_null_recovery(void);

/* Contract-backed sequences shared by model and vendor builds. */
static void test_lifecycle_reinitialize(void)
{
    epon_hal_link_stats_t stats = epon_stats();
    epon_hal_config_t config = epon_callbacks();
    OK(epon_hal_get_link_stats(&stats));
    OK(epon_hal_deinit());
    ERROR_IS(epon_hal_get_link_stats(&stats), EPON_HAL_ERROR_NOT_INITIALIZED);
    OK(epon_hal_init(&config));
    OK(epon_hal_get_link_stats(&stats));
    CU_ASSERT((epon_hal_get_version() >> 24) == EPON_HAL_VERSION_MAJOR);
    test_null_recovery();
}

static void test_clear_preserves_optical(void)
{
    epon_hal_link_stats_t stats = epon_stats();
    epon_hal_transceiver_stats_t before = epon_optical(), after = epon_optical();
    epon_hal_return_t optical_status = epon_hal_get_transceiver_stats(&before);
    CU_ASSERT(optical_status == EPON_HAL_SUCCESS || optical_status == EPON_HAL_ERROR_NOT_SUPPORTED);
#ifdef BUILD_LINUX
    OK(epon_test_advance_stats(UINT64_C(0xf123456700000011)));
#endif
    OK(epon_hal_clear_stats());
    OK(epon_hal_get_link_stats(&stats));
#define ZERO(member) U64_EQUAL(stats.member, 0);
    ZERO(packets_sent) ZERO(packets_received) ZERO(bytes_sent) ZERO(bytes_received)
    ZERO(errors_sent) ZERO(errors_received) ZERO(discard_packets_sent)
    ZERO(discard_packets_received) ZERO(fec_corrected) ZERO(fec_uncorrectable)
    ZERO(broadcast_packets_sent) ZERO(broadcast_packets_received)
    ZERO(multicast_packets_sent) ZERO(multicast_packets_received)
    ZERO(ranging_resyncs) ZERO(mac_resets)
#undef ZERO
    if (optical_status == EPON_HAL_SUCCESS) {
        OK(epon_hal_get_transceiver_stats(&after));
#ifdef BUILD_LINUX
        /* Vendor hardware may legitimately resample optical measurements. */
        CU_ASSERT(optical_equal(&before, &after));
        CU_ASSERT_EQUAL(stats.max_bit_rate, 10000);
#endif
    }
}

static void test_null_recovery(void)
{
    EPON_GUARD(epon_interface_list_t, interfaces);
    epon_onu_manufacturer_info_t manufacturer = epon_manufacturer();
    ERROR_IS(epon_hal_get_link_stats(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_get_interface_list(&interfaces.value));
    ERROR_IS(epon_hal_get_interface_list(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_get_manufacturer_info(&manufacturer));
    CU_ASSERT(interfaces.value.interface_count <= EPON_HAL_MAX_INTERFACES);
    EPON_CHECK_GUARD(interfaces);
}

#ifdef BUILD_LINUX
/* Remaining cases exercise explicitly declared reference-model policies only. */
static void test_registration_readiness(void)
{
    epon_olt_info_t olt = epon_olt();
    epon_interface_list_t interfaces = {0};
    CU_ASSERT_EQUAL(h_status_count, 0);
    ERROR_IS(epon_hal_get_olt_info(&olt), EPON_HAL_ERROR_NOT_SUPPORTED);
    OK(epon_test_onu(EPON_ONU_STATUS_DOWNSTREAM_SIGNAL_DETECTED));
    ERROR_IS(epon_test_onu(EPON_ONU_STATUS_REGISTRATION), EPON_HAL_ERROR_RESOURCE);
    CU_ASSERT_EQUAL(h_status_count, 1);
    OK(epon_test_interface(0, EPON_ONU_INTF_STATUS_LINK_UP));
    ERROR_IS(epon_test_onu(EPON_ONU_STATUS_REGISTRATION), EPON_HAL_ERROR_RESOURCE);
    OK(epon_test_interface(1, EPON_ONU_INTF_STATUS_LINK_UP));
    OK(epon_test_onu(EPON_ONU_STATUS_REGISTRATION));
    OK(epon_hal_get_interface_list(&interfaces));
    CU_ASSERT_FATAL(interfaces_valid(&interfaces));
    for (uint32_t i = 0; i < interfaces.interface_count; ++i)
        CU_ASSERT_EQUAL(interfaces.interface[i].status, EPON_ONU_INTF_STATUS_LINK_UP);
    CU_ASSERT_EQUAL(h_status_count, 2);
    CU_ASSERT_EQUAL(h_status[1], EPON_ONU_STATUS_REGISTRATION);
    OK(epon_hal_get_olt_info(&olt));
}

static void test_multi_interface_callbacks(void)
{
    epon_interface_list_t interfaces = {0};
    OK(epon_test_interface(1, EPON_ONU_INTF_STATUS_LINK_UP));
    OK(epon_test_interface(1, EPON_ONU_INTF_STATUS_LINK_UP));
    CU_ASSERT_EQUAL(h_interface_count, 1);
    CU_ASSERT(bounded_equal(h_interfaces[0].name, "veip1", sizeof(h_interfaces[0].name)));
    OK(epon_test_interface(0, EPON_ONU_INTF_STATUS_LINK_UP));
    OK(epon_test_interface(1, EPON_ONU_INTF_STATUS_LINK_DOWN));
    CU_ASSERT_EQUAL(h_interface_count, 3);
    OK(epon_hal_get_interface_list(&interfaces));
    CU_ASSERT_EQUAL(interfaces.interface[0].status, EPON_ONU_INTF_STATUS_LINK_UP);
    CU_ASSERT_EQUAL(interfaces.interface[1].status, EPON_ONU_INTF_STATUS_LINK_DOWN);
    /* Captured by value: first callback remains up after subsequent changes. */
    CU_ASSERT_EQUAL(h_interfaces[0].status, EPON_ONU_INTF_STATUS_LINK_UP);
    ERROR_IS(epon_test_interface(16, EPON_ONU_INTF_STATUS_LINK_UP), EPON_HAL_ERROR_INVALID_PARAM);
    ERROR_IS(epon_test_interface(0, (epon_interface_link_status_t)9), EPON_HAL_ERROR_INVALID_PARAM);
}

static void test_llid_transitions(void)
{
    epon_test_scenario_t seed;
    epon_test_default_scenario(&seed);
    for (int state = EPON_LLID_STATE_UNREGISTERED; state <= EPON_LLID_STATE_FAILED; ++state) {
        free(h_llids[0].llid_list);
        h_llids[0] = (epon_llid_list_t){0};
        seed.llids[0].state = (epon_llid_state_t)state;
        seed.llids[0].mode = state % 2 ? EPON_LLID_MODE_BROADCAST : EPON_LLID_MODE_UNICAST;
        seed.llids[0].forwarding_state = (epon_llid_forwarding_state_t)(state % 3);
        seed.llids[0].encryption_enabled = state % 2 != 0;
        OK(epon_test_llids(seed.llids, 2));
        OK(epon_hal_get_llid_info(&h_llids[0]));
        CU_ASSERT_EQUAL_FATAL(h_llids[0].llid_count, 2);
        CU_ASSERT(llid_equal(&seed.llids[0], &h_llids[0].llid_list[0]));
    }
    seed.llids[0].state = (epon_llid_state_t)99;
    ERROR_IS(epon_test_llids(seed.llids, 2), EPON_HAL_ERROR_INVALID_PARAM);
    ERROR_IS(epon_test_llids(NULL, 1), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_get_llid_info(&h_llids[1]));
    CU_ASSERT(llid_equal(&h_llids[0].llid_list[0], &h_llids[1].llid_list[0]));
}

static void test_olt_discovery_lifetime(void)
{
    epon_olt_info_t old = epon_olt(), current = epon_olt(), learned = epon_olt();
    model_register_onu();
    OK(epon_hal_get_olt_info(&old));
    learned.mac_address[0] = 0x02;
    learned.mac_address[5] = 0xfe;
    learned.vendor_oui[2] = 0xab;
    OK(epon_test_olt(&learned, false));
    ERROR_IS(epon_hal_get_olt_info(&current), EPON_HAL_ERROR_NOT_SUPPORTED);
    OK(epon_test_olt(&learned, true));
    OK(epon_hal_get_olt_info(&current));
    CU_ASSERT(memcmp(current.mac_address, learned.mac_address, EPON_HAL_MAC_ADDR_LEN) == 0);
    CU_ASSERT(memcmp(current.vendor_oui, learned.vendor_oui, EPON_HAL_VENDOR_OUI_LEN) == 0);
    CU_ASSERT(old.mac_address[5] != current.mac_address[5]);
    OK(epon_test_onu(EPON_ONU_STATUS_LOS));
    ERROR_IS(epon_hal_get_olt_info(&current), EPON_HAL_ERROR_NOT_SUPPORTED);
    OK(epon_test_onu(EPON_ONU_STATUS_DEREGISTRATION));
    ERROR_IS(epon_hal_get_olt_info(&current), EPON_HAL_ERROR_NOT_SUPPORTED);
}

static void test_full_width_rollover(void)
{
    epon_test_scenario_t seed;
    epon_hal_link_stats_t stats = epon_stats();
    epon_test_default_scenario(&seed);
#define MAX(member) seed.stats.member = UINT64_MAX - 3;
    EPON_TEST_COUNTERS(MAX)
#undef MAX
    OK(epon_test_seed(&seed));
    OK(epon_test_advance_stats(2));
    OK(epon_hal_get_link_stats(&stats));
#define NEAR(member) U64_EQUAL(stats.member, UINT64_MAX - 1);
    EPON_TEST_COUNTERS(NEAR)
#undef NEAR
    OK(epon_test_advance_stats(3));
    OK(epon_hal_get_link_stats(&stats));
#define WRAPPED(member) U64_EQUAL(stats.member, 1);
    EPON_TEST_COUNTERS(WRAPPED)
#undef WRAPPED
    CU_ASSERT_EQUAL(stats.max_bit_rate, seed.stats.max_bit_rate);
}

static void test_optional_capabilities(void)
{
    epon_hal_transceiver_stats_t stats = epon_optical();
    epon_hal_config_t config = epon_callbacks();
    epon_test_capabilities(false, false, false);
    ERROR_IS(epon_hal_get_transceiver_stats(&stats), EPON_HAL_ERROR_NOT_SUPPORTED);
    ERROR_IS(epon_hal_set_oam_log_mask(0), EPON_HAL_ERROR_NOT_SUPPORTED);
    ERROR_IS(dpoe_hal_get_cpe_mac_table(&h_cpe[0]), EPON_HAL_ERROR_NOT_SUPPORTED);
    epon_test_capabilities(true, true, true);
    OK(epon_hal_get_transceiver_stats(&stats));
    OK(epon_hal_set_oam_log_mask(EPON_OAM_ALL));
    OK(epon_hal_deinit());
    config.dpoe_supported = false;
    OK(epon_hal_init(&config));
    ERROR_IS(dpoe_hal_get_cpe_mac_table(&h_cpe[0]), EPON_HAL_ERROR_NOT_SUPPORTED);
}

static void test_snapshot_ownership(void)
{
    epon_test_scenario_t seed;
    epon_test_default_scenario(&seed);
    OK(epon_hal_get_llid_info(&h_llids[0]));
    OK(dpoe_hal_get_cpe_mac_table(&h_cpe[0]));
    CU_ASSERT_PTR_NOT_NULL_FATAL(h_llids[0].llid_list);
    CU_ASSERT_PTR_NOT_NULL_FATAL(h_cpe[0].cpe_list);
    seed.llids[0].llid_value = 0xabcd;
    seed.cpe[0].mac_address[5] = 0xa1;
    OK(epon_test_llids(seed.llids, 2));
    OK(epon_test_cpe(seed.cpe, 2));
    OK(epon_hal_get_llid_info(&h_llids[1]));
    OK(dpoe_hal_get_cpe_mac_table(&h_cpe[1]));
    CU_ASSERT_PTR_NOT_NULL_FATAL(h_llids[1].llid_list);
    CU_ASSERT_PTR_NOT_NULL_FATAL(h_cpe[1].cpe_list);
    CU_ASSERT(h_llids[0].llid_list != h_llids[1].llid_list);
    CU_ASSERT(h_cpe[0].cpe_list != h_cpe[1].cpe_list);
    CU_ASSERT(llid_equal(&h_llids[1].llid_list[0], &seed.llids[0]));
    CU_ASSERT(cpe_equal(&h_cpe[1].cpe_list[0], &seed.cpe[0]));
    OK(epon_hal_deinit());
    CU_ASSERT_EQUAL(h_llids[0].llid_list[0].llid_value, 1);
    CU_ASSERT_EQUAL(h_cpe[0].cpe_list[0].mac_address[5], 16);
    OK(epon_hal_factory_reset());
    CU_ASSERT_EQUAL(h_llids[1].llid_list[0].llid_value, 0xabcd);
    CU_ASSERT_EQUAL(h_cpe[1].cpe_list[0].mac_address[5], 0xa1);
    /* Fixture teardown frees all four arrays after HAL destruction. */
}

static void test_alarm_discriminators(void)
{
    epon_alarm_info_t alarm = {0};
    for (int type = 0; type < 2; ++type) {
        int limit = type == 0 ? EPON_HAL_ALARM_MAX : EPON_VENDOR_ALARM_MAX;
        alarm.alarm_type = (epon_alarm_type_t)type;
        for (int number = 0; number < limit; ++number) {
            if (type == 0)
                alarm.standard_alarm = (epon_hal_alarm_t)number;
            else
                alarm.vendor_alarm = (epon_vendor_alarm_t)number;
            alarm.llid = number % 2 ? 23 : EPON_LLID_NOT_APPLICABLE;
            for (int active = 1; active >= 0; --active) {
                alarm.is_active = active != 0;
                OK(epon_test_alarm(&alarm));
                CU_ASSERT_FATAL(h_alarm_count <= 128);
                const epon_alarm_info_t *copy = &h_alarms[h_alarm_count - 1];
                CU_ASSERT_EQUAL(copy->alarm_type, alarm.alarm_type);
                CU_ASSERT_EQUAL(copy->llid, alarm.llid);
                CU_ASSERT(copy->is_active == alarm.is_active);
                if (type == 0) {
                    CU_ASSERT_EQUAL(copy->standard_alarm, (epon_hal_alarm_t)number);
                } else {
                    CU_ASSERT_EQUAL(copy->vendor_alarm, (epon_vendor_alarm_t)number);
                }
            }
        }
    }
    CU_ASSERT_EQUAL(h_alarm_count, 30);
    memset(&alarm, 0, sizeof(alarm));
    CU_ASSERT_EQUAL(h_alarms[0].llid, EPON_LLID_NOT_APPLICABLE);
    CU_ASSERT(h_alarms[0].is_active);
    alarm.alarm_type = (epon_alarm_type_t)9;
    ERROR_IS(epon_test_alarm(&alarm), EPON_HAL_ERROR_INVALID_PARAM);
    alarm.alarm_type = EPON_ALARM_TYPE_STANDARD;
    alarm.standard_alarm = EPON_HAL_ALARM_MAX;
    ERROR_IS(epon_test_alarm(&alarm), EPON_HAL_ERROR_INVALID_PARAM);
    alarm.alarm_type = EPON_ALARM_TYPE_VENDOR_SPECIFIC;
    alarm.vendor_alarm = EPON_VENDOR_ALARM_MAX;
    ERROR_IS(epon_test_alarm(&alarm), EPON_HAL_ERROR_INVALID_PARAM);
    ERROR_IS(epon_test_alarm(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    CU_ASSERT_EQUAL(h_alarm_count, 30);
}

static void test_onu_reset_progression(void)
{
    epon_olt_info_t olt = epon_olt();
    epon_hal_link_stats_t stats = epon_stats();
    model_register_onu();
    OK(epon_test_advance_stats(99));
    OK(epon_hal_set_oam_log_mask(EPON_OAM_INFO));
    OK(epon_hal_reset_onu());
    CU_ASSERT_EQUAL(h_status[h_status_count - 1], EPON_ONU_STATUS_DEREGISTRATION);
    ERROR_IS(epon_hal_get_olt_info(&olt), EPON_HAL_ERROR_NOT_SUPPORTED);
    OK(epon_hal_get_llid_info(&h_llids[0]));
    CU_ASSERT_EQUAL_FATAL(h_llids[0].llid_count, 2);
    CU_ASSERT_EQUAL(h_llids[0].llid_list[0].state, EPON_LLID_STATE_DEREGISTERING);
    OK(epon_test_step());
    CU_ASSERT_EQUAL(h_status[h_status_count - 1], EPON_ONU_STATUS_DOWNSTREAM_SIGNAL_DETECTED);
    OK(epon_hal_get_llid_info(&h_llids[1]));
    CU_ASSERT_EQUAL_FATAL(h_llids[1].llid_count, 2);
    CU_ASSERT_EQUAL(h_llids[1].llid_list[0].state, EPON_LLID_STATE_REGISTERING);
    OK(epon_test_step());
    CU_ASSERT_EQUAL(h_status[h_status_count - 1], EPON_ONU_STATUS_REGISTRATION);
    OK(epon_hal_get_olt_info(&olt));
    OK(epon_hal_get_link_stats(&stats));
    U64_EQUAL(stats.packets_sent, 99);
    OK(epon_test_oam(EPON_OAM_INFO));
    U64_EQUAL(epon_test_oam_observation().logged, 1);
    ERROR_IS(epon_test_step(), EPON_HAL_ERROR_RESOURCE);
}

static void test_factory_reset_reconfigure(void)
{
    epon_hal_config_t config = epon_callbacks();
    epon_hal_link_stats_t stats = epon_stats();
    OK(epon_test_advance_stats(101));
    OK(epon_hal_set_oam_log_mask(EPON_OAM_ALL));
    OK(epon_hal_factory_reset());
    unsigned int previous = h_status_count;
    ERROR_IS(epon_test_onu(EPON_ONU_STATUS_DOWNSTREAM_SIGNAL_DETECTED), EPON_HAL_ERROR_NOT_INITIALIZED);
    CU_ASSERT_EQUAL(h_status_count, previous);
    ERROR_IS(epon_hal_get_link_stats(&stats), EPON_HAL_ERROR_NOT_INITIALIZED);
    OK(epon_hal_init(&config));
    OK(epon_hal_get_link_stats(&stats));
#define ZERO(member) U64_EQUAL(stats.member, 0);
    EPON_TEST_COUNTERS(ZERO)
#undef ZERO
    OK(epon_test_oam(EPON_OAM_INFO));
    U64_EQUAL(epon_test_oam_observation().logged, 0);
    U64_EQUAL(epon_test_oam_observation().processed, 1);
}

static void test_callback_config_lifetime(void)
{
    epon_hal_config_t config = epon_callbacks();
    epon_alarm_info_t alarm = { .alarm_type = EPON_ALARM_TYPE_STANDARD,
        .standard_alarm = EPON_HAL_ALARM_LOFI, .llid = 9, .is_active = true };
    OK(epon_hal_deinit());
    OK(epon_hal_init(&config));
    memset(&config, 0, sizeof(config)); /* Model copies, never retains config. */
    OK(epon_test_onu(EPON_ONU_STATUS_DOWNSTREAM_SIGNAL_DETECTED));
    OK(epon_test_alarm(&alarm));
    OK(epon_test_interface(0, EPON_ONU_INTF_STATUS_LINK_UP));
    CU_ASSERT_EQUAL(h_status_count, 1);
    CU_ASSERT_EQUAL(h_alarm_count, 1);
    CU_ASSERT_EQUAL(h_interface_count, 1);
    OK(epon_hal_deinit());
    ERROR_IS(epon_test_alarm(&alarm), EPON_HAL_ERROR_NOT_INITIALIZED);
    ERROR_IS(epon_test_interface(0, EPON_ONU_INTF_STATUS_LINK_UP), EPON_HAL_ERROR_NOT_INITIALIZED);
    CU_ASSERT_EQUAL(h_alarm_count, 1);
    config = epon_config(); /* NULL callbacks supported only by model policy. */
    OK(epon_hal_init(&config));
    OK(epon_test_alarm(&alarm));
    OK(epon_test_onu(EPON_ONU_STATUS_DOWNSTREAM_SIGNAL_DETECTED));
    CU_ASSERT_EQUAL(h_status_count, 1);
    CU_ASSERT_EQUAL(h_alarm_count, 1);
}

static void test_fault_atomicity(void)
{
    EPON_GUARD(epon_hal_link_stats_t, stats);
    epon_hal_transceiver_stats_t optical = epon_optical();
    epon_onu_manufacturer_info_t manufacturer = epon_manufacturer();
    epon_hal_link_info_t link = {0};
    epon_interface_list_t interfaces = {0};
    epon_olt_info_t olt = epon_olt();
    stats.value = epon_stats();
    stats.value.packets_sent = UINT64_C(0xfedcba9876543210);
    epon_test_fault(EPON_TEST_LINK_STATS, EPON_HAL_ERROR_RESOURCE);
    ERROR_IS(epon_hal_get_link_stats(NULL), EPON_HAL_ERROR_INVALID_PARAM);
    ERROR_IS(epon_hal_get_link_stats(&stats.value), EPON_HAL_ERROR_RESOURCE);
    U64_EQUAL(stats.value.packets_sent, UINT64_C(0xfedcba9876543210));
    EPON_CHECK_GUARD(stats);
    OK(epon_hal_get_link_stats(&stats.value));
#define FAULT(api, call) do { \
    epon_test_fault(api, EPON_HAL_ERROR); \
    ERROR_IS(call, EPON_HAL_ERROR); \
} while (0)
    FAULT(EPON_TEST_OPTICAL_STATS, epon_hal_get_transceiver_stats(&optical));
    FAULT(EPON_TEST_LLIDS, epon_hal_get_llid_info(&h_llids[0]));
    FAULT(EPON_TEST_MANUFACTURER, epon_hal_get_manufacturer_info(&manufacturer));
    FAULT(EPON_TEST_LINK_INFO, epon_hal_get_link_info(&link));
    FAULT(EPON_TEST_INTERFACES, epon_hal_get_interface_list(&interfaces));
    FAULT(EPON_TEST_OLT, epon_hal_get_olt_info(&olt));
    FAULT(EPON_TEST_OAM_MASK, epon_hal_set_oam_log_mask(EPON_OAM_ALL));
    FAULT(EPON_TEST_CPE, dpoe_hal_get_cpe_mac_table(&h_cpe[0]));
#undef FAULT
    OK(epon_test_advance_stats(17));
    epon_test_fault(EPON_TEST_CLEAR, EPON_HAL_ERROR_HW_FAILURE);
    ERROR_IS(epon_hal_clear_stats(), EPON_HAL_ERROR_HW_FAILURE);
    OK(epon_hal_get_link_stats(&stats.value));
    U64_EQUAL(stats.value.packets_sent, 17);
    epon_test_fail_allocation(2);
    OK(epon_hal_get_llid_info(&h_llids[0]));
    ERROR_IS(dpoe_hal_get_cpe_mac_table(&h_cpe[0]), EPON_HAL_ERROR_MEMORY);
    OK(dpoe_hal_get_cpe_mac_table(&h_cpe[0]));
    epon_test_scenario_t seed;
    epon_test_default_scenario(&seed);
    seed.stats.packets_sent = 200;
    seed.cpe_count = EPON_TEST_CAPACITY + 1;
    ERROR_IS(epon_test_seed(&seed), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_get_link_stats(&stats.value));
    U64_EQUAL(stats.value.packets_sent, 17);
}

static void test_oam_processing_masks(void)
{
    const uint32_t masks[] = {0, EPON_OAM_INFO | EPON_OAM_VAR_REQUEST,
        EPON_OAM_ALL, UINT32_C(0x80000000)};
    uint64_t processed = 0, logged = 0;
    for (size_t i = 0; i < sizeof(masks) / sizeof(masks[0]); ++i) {
        OK(epon_hal_set_oam_log_mask(masks[i]));
        for (uint32_t category = 1; category <= EPON_OAM_MPCP_REGISTER_ACK; category <<= 1) {
            OK(epon_test_oam(category));
            ++processed;
            if ((category & masks[i]) != 0) {
                ++logged;
                CU_ASSERT_EQUAL(epon_test_oam_observation().last_level, HAL_LOG_LEVEL_OAM);
                CU_ASSERT_EQUAL(epon_test_oam_observation().last_category, category);
            }
            U64_EQUAL(epon_test_oam_observation().processed, processed);
            U64_EQUAL(epon_test_oam_observation().logged, logged);
        }
    }
    ERROR_IS(epon_test_oam(0), EPON_HAL_ERROR_INVALID_PARAM);
    ERROR_IS(epon_test_oam(128), EPON_HAL_ERROR_INVALID_PARAM);
    ERROR_IS(epon_test_oam(3), EPON_HAL_ERROR_INVALID_PARAM);
    OK(epon_hal_deinit());
    epon_hal_config_t config = epon_callbacks();
    OK(epon_hal_init(&config));
    OK(epon_test_oam(EPON_OAM_EVENT));
    U64_EQUAL(epon_test_oam_observation().logged, logged); /* mask cleared */
}
#endif

/* PUBLIC_INTERFACE */
/** Register 15 isolated L2 scenarios, excluding 13 synthetic scenarios on vendor. */
int test_epon_l2_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID("[L2 EPON sequences]", NULL, NULL, UT_TESTS_L2);
    if (suite == NULL)
        return -1;
    epon_install_fixture(suite, true);
#define ADD(name) if (UT_add_test(suite, #name, test_##name) == NULL) return -1
    ADD(lifecycle_reinitialize); ADD(clear_preserves_optical);
#ifdef BUILD_LINUX
    ADD(registration_readiness); ADD(multi_interface_callbacks); ADD(llid_transitions);
    ADD(olt_discovery_lifetime); ADD(full_width_rollover); ADD(optional_capabilities);
    ADD(snapshot_ownership); ADD(alarm_discriminators); ADD(onu_reset_progression);
    ADD(factory_reset_reconfigure); ADD(callback_config_lifetime);
    ADD(fault_atomicity); ADD(oam_processing_masks);
#endif
#undef ADD
    return 0;
}
