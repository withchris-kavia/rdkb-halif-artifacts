extern int test_epon_l1_register(void);
extern int test_epon_contract_register(void);
extern int test_epon_l2_register(void);

/* PUBLIC_INTERFACE */
/** Register API and declaration checks; propagate either registration error. */
int register_hal_l1_tests(void)
{
    int api = test_epon_l1_register();
    int types = test_epon_contract_register();
    return api != 0 || types != 0;
}

/* PUBLIC_INTERFACE */
/** Register common sequences and Linux-only model scenarios when enabled. */
int register_hal_l2_tests(void)
{
    return test_epon_l2_register();
}
