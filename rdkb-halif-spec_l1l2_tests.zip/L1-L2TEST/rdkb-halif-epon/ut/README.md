# EPON ut-core C test suite

This component suite tests the declarations in [epon_hal.h](../epon_hal.h)
using the official RDK ut-core/CUnit framework. It does not alter that header,
the root README symlink, or the existing EPON specifications.

## Dependencies and provisioning

The provisioned `ut-core/` tree was reused from an already bootstrapped,
clean copy of these exact revisions:

| Dependency | Tag/version | Revision |
|---|---|---|
| rdkcentral/ut-core | 3.2.4 | `f76ba6f328a761aa536c12cd8dacb4c3c12bc147` |
| rdkcentral/ut-control | 1.5.1 | `4dae1ba2380bb5df39bed6e86fea9b90330a6fa9` |
| CUnit | 2.1-3 | Official ut-core setup output, including its supplied build-warning patch |

No component patch is applied to any dependency source. The component Makefile
compiles unchanged framework sources into component-owned object directories
and links the prebuilt `ut-control` shared library. It never invokes dependency
setup or dependency clean. The harness hashes the entire provisioned tree,
including metadata, to detect changes.

A fresh environment needs GNU make, GCC-compatible C11 and C++17 compilers,
Git, binutils, Python 3, and the dependencies required by the official
[ut-core setup](ut-core/build.sh). Host sanitizer verification additionally needs
compiler/runtime ASan and UBSan support. For fresh provisioning only, clone
ut-core tag `3.2.4` into `ut/ut-core`, run its official `build.sh TARGET=linux`,
and build `framework/ut-control` with `make TARGET=linux`. Verify the revisions
above before using the component. If SSH access is unavailable, use HTTPS for
the initial clone and a **process-local** Git URL rewrite for setup's nested
clone, rather than editing upstream scripts or global Git configuration:

```bash
git clone --branch 3.2.4 --depth 1 https://github.com/rdkcentral/ut-core.git ut/ut-core
(
    cd ut/ut-core
    GIT_CONFIG_COUNT=1 \
    GIT_CONFIG_KEY_0=url.https://github.com/.insteadOf \
    GIT_CONFIG_VALUE_0=git@github.com: \
        ./build.sh TARGET=linux
    make -C framework/ut-control TARGET=linux
)
```

Do not run setup again on the preserved, already provisioned dependency tree.
An exact clean, bootstrapped copy can instead be reused, as done here. Dependency
trees and build outputs are local inputs/artifacts, not vendored component
sources.

## Build and run

From the component root:

```bash
./build_ut.sh -j4
./ut/bin/run.sh -b
./ut/bin/run.sh -b -d 2       # L1 only: 22 Linux cases
./ut/bin/run.sh -b -d 1       # L2 only: 15 Linux cases
./ut/bin/run.sh -b -d 1 -e 1  # Last switch wins: all 37 Linux cases
./ut/bin/run.sh -b -d 1 -d 2  # No tests: deliberately exits 1
```

Both build scripts and the runner work from a foreign working directory and
preserve argument boundaries and child exit status using `exec`. The runner
enters its binary directory and prepends that directory to `LD_LIBRARY_PATH`,
preserving a nonempty caller value. Unset/empty caller values do not introduce
an empty search-path element.

Unset or empty `TARGET` means `linux`; explicit `TARGET=linux` is equivalent.
Linux builds define `BUILD_LINUX`, include the root header via `-I..`, and add
both skeleton include directories. All component C files, including the model
and opt-in fault fixture, compile with `-Wall -Wextra -Werror`. Unmodified
third-party framework files have a separate warning policy.

Objects live under `build/<target>/component/`. A flags/source-list stamp
invalidates objects when compiler options or opt-in fixtures change; selecting
a different target always relinks the selected objects into
`bin/epon_hal_test`. `./build_ut.sh clean` removes only component objects,
the executable and its copied `libut_control.so`; it preserves `bin/run.sh`,
vendor libraries, tests, source files, and all of `ut-core/`.

### Vendor/ARM builds

`TARGET=vendor` and `TARGET=arm` exclude all skeleton paths, the Linux model,
its control symbols, and the 15 model-only test cases. The resulting suite has
20 common L1 cases and two common L2 cases. For example, with compatible vendor
and control libraries already provisioned:

```bash
./build_ut.sh TARGET=vendor \
    VENDOR_CPPFLAGS=-I/path/to/vendor/includes \
    'VENDOR_LIBS=-L/path/to/vendor/libs -lepon_hal'
./build_ut.sh TARGET=arm CC=arm-linux-gnueabihf-gcc \
    'VENDOR_LIBS=-L/path/to/arm/libs -lepon_hal'
```

The default vendor link flags are `-Llibs -lepon_hal`. `CONTROL_TARGET` selects
`ut-core/framework/ut-control/build/<target>/lib/libut_control.so`; it defaults
to `linux` for `vendor` and `arm` for `arm`. A real target requires matching
toolchain, sysroot and target-built dependencies; this suite does not silently
substitute the Linux model for a missing vendor library. Deploy the executable,
copied control library and the vendor library's runtime dependencies together.

**Do not run the vendor suite on a live service without authorization.** Common
tests include disruptive clear-statistics, ONU-reset and factory-reset calls.
The host harness's vendor link stand-in is solely an isolation check, not
evidence of vendor conformance, protocol correctness or successful cross-build.

## Coverage and source layout

| Source | Coverage |
|---|---|
| [test_l1_epon_hal.c](src/test_l1_epon_hal.c) | All 15 public APIs; normal calls, NULL pointers, valid pre-init calls, five size-bearing types with zero/short/long/extreme sizes, optional features, documented errors, all 16 full-width counters and nine optical fields, bounded interfaces/strings, snapshot ownership and allocation failures |
| [test_l1_epon_contract_types.c](src/test_l1_epon_contract_types.c) | All 13 enums, 19 non-guard macros, 13 structs and their members/array lengths, five size prefixes, anonymous alarm union, 15 function signatures and three callback fields |
| [test_l2_epon_hal.c](src/test_l2_epon_hal.c) | Fifteen isolated stateful scenarios listed below |
| [epon_test_helpers.h](src/epon_test_helpers.h) | Guarded outputs, exact size initializers, bounded inspection, member-wise comparisons, non-narrowing counter assertions, callback copies and per-test cleanup |
| [header_cpp17.cpp](tests/fixtures/header_cpp17.cpp) | Repeated inclusion, unconditional DPoE declarations, C++17 types and linkage to C-compiled HAL symbols |
| [logger_probe.c](tests/fixtures/logger_probe.c) | Override forwarding and metadata; default append path/mode, formatting, open/write/close behavior and silent failures through intercepted stdio |
| [harness_faults.c](tests/fixtures/harness_faults.c) | Opt-in framework/registration/assertion/suite-init/suite-cleanup/execution faults and exact runner argv/environment checks |

Linux L1 contains 19 API cases plus three declaration cases. The two API
fault/boundary cases are Linux-only. All runtime L1 API and L2 cases have
per-test setup/teardown; declaration-only cases have no HAL-owned state.
Tracked snapshots are freed even when a fatal CUnit assertion terminates a case.

### The 15 L2 scenarios

| Case | Sequence and observable |
|---|---|
| `lifecycle_reinitialize` | Get, deinit, reject operational call, reinit, recover after NULL requests |
| `clear_preserves_optical` | Clear all counters; keep model rate and all nine optical measurements |
| `registration_readiness` | Init is not readiness; require nonempty all-up interfaces before registration/OLT availability |
| `multi_interface_callbacks` | Independent interface changes, per-interface payload copies, duplicate suppression |
| `llid_transitions` | All five LLID states, both modes, forwarding/encryption observations and invalid update rollback |
| `olt_discovery_lifetime` | Discovery availability, changed MAC/OUI and unavailability after LOS/deregistration |
| `full_width_rollover` | Every 64-bit counter near `UINT64_MAX`, explicit modulo rollover |
| `optional_capabilities` | Independent optical/OAM/DPoE availability and copied DPoE config flag |
| `snapshot_ownership` | Independent LLID/CPE allocations remain valid after mutation, deinit and factory reset |
| `alarm_discriminators` | Raise/clear all seven standard and eight vendor alarms, discriminator/union, LLID sentinel, payload copies |
| `onu_reset_progression` | Deregister, discovering/registering, all-up/registered, preserved stats/config/mask |
| `factory_reset_reconfigure` | Remove config/callbacks, clear counters/mask, require reinit |
| `callback_config_lifetime` | Copied config, all three callback types, unregister on deinit, model NULL callback policy |
| `fault_atomicity` | One-shot per-API errors, validation precedence, failed clear/seed and allocation-failure recovery |
| `oam_processing_masks` | Zero/selective/all/unknown masks never suppress processing; selected categories recorded at OAM level |

Only the first two sequences are common vendor cases. Real optical readings
may resample, so exact optical equality is asserted only against the model.
Synthetic model behavior is never imposed as an undocumented vendor requirement.

## Reference model and unresolved contracts

[skeletons/include/epon_hal_test_control.h](skeletons/include/epon_hal_test_control.h)
documents the choices for gaps G01–G18 from the preserved
[contract-gap inventory](../docs/epon-hal-contract-gaps.md). Its compile guard
rejects use without `BUILD_LINUX`. Controls are not additions to the public ABI.

The model is serialized, synchronous, deterministic and in-process. It copies
configuration and seeds atomically, separates initialized state from ONU/OLT
readiness, validates exact `struct_size`, uses `malloc`/`free`-compatible caller
snapshots, and bounds LLID/CPE data to 32 and interfaces to 16. Empty snapshots
have NULL arrays. Pass a fresh output container or free the previous snapshot
before reuse. Returned strings are terminated as a model policy; tests never
perform unbounded reads of vendor strings.

Callbacks run synchronously: interface and ONU data are captured by value;
the alarm pointer is borrowed only for the invocation. Repeated identical
ONU/interface observations do not generate duplicate notifications. Deinit
unregisters callbacks but does not release caller-owned arrays. ONU reset
requires two explicit `epon_test_step()` calls; factory reset removes config and
requires reinit. Version has no error channel and is not fault-injected.

Faults are one-shot per status-returning API. Pointer/size validation precedes
initialization, fault consumption and feature/readiness checks. Failed model
calls leave output/state unchanged. The nth snapshot allocation can fail
deterministically, after which normal allocation resumes.

Simulated OAM records processed/logged counts, category and OAM level in memory.
It never calls the default file logger. The separate logger fixtures replace
stdio or the backend before including the unmodified header. There are no
device-node, hardware, network, reboot, sleep, thread or `/rdklogs` side effects
in the reference model.

## Result handling and independent host verification

`src/main.c` uses official ut-core initialization, L1/L2 registration and test
execution. Component-side linker wrappers capture CUnit counters **before**
registry cleanup, retain registration errors across subsequent successes,
apply ordered group filters and use `CU_set_fail_on_inactive(CU_FALSE)`.
No framework source modification is needed.

A run succeeds only if it executed at least one test, registration/execution
succeeded, and every captured failure/error counter is zero:

```text
EPON_RESULT tests=37 failed=0 assertions_failed=0 suites_failed=0 records=0 error=0
```

Framework init or registration failures exit 1 before a run marker is produced.
Failed assertions, suite init/cleanup errors, execution failures and empty
selections also exit 1. Use `-b` for non-interactive CI; official `-a` XML mode
can execute the cases, but the pinned ut-core 3.2.4 reporter produces malformed
XML with incorrect root totals. In merged automated-mode output the result
marker may also follow the last framework message on the same line. Do not use
that XML as a CI result artifact; use `-b` and check both exit status and counters.
See the [independent verification report](verification-results.md) for individual
case results, reproductions, limitations and the preserved final build state.
Help/list-only modes are not substitutes for a test run.

Run the host verifier from any directory:

```bash
./ut/tests/test_linux_harness.sh
```

The verifier was run successfully for this implementation. It independently
checks exact result markers/counts and exit statuses, not just matching text
such as “PASS”. It covers:

- Unset and explicit Linux target builds from a foreign CWD.
- Full, L1-only, L2-only, both filter orders and zero-test runs, direct and runner.
- Invalid target and compiler/make failures with propagated exit codes.
- All nine deliberate harness faults, direct and runner; every failure exits 1.
- ASan/UBSan with leak detection for all rebuilt component/framework objects,
  normal/filter/empty selections and deliberate failure paths. The prebuilt
  `ut-control` library itself is not reinstrumented.
- C++17 linkage and both logger probe configurations under sanitizers.
- A linked vendor-mode executable and all vendor component objects with no
  `epon_test_*` symbols; ARM/vendor configuration excludes model flags/paths.
- Runner arguments containing spaces and library paths that are set, empty or unset.
- All protected files, symlink modes/targets, and the entire dependency tree.

Logs, commands, statuses and before/after digests remain under the printed
temporary evidence directory. An EXIT trap restores and executes a normal,
noninstrumented, fault-free Linux binary, then checks preservation even if a
probe fails. The root `README.md` remains a mode-120000 symlink. No contract
parser or generated VTS-output tooling is used, and no commit/push is performed.

Hardware callback timing, optical accuracy, real OLT registration and vendor
runtime conformance still require the vendor implementation and authorized DUT
testing; a passing reference suite does not establish them.
