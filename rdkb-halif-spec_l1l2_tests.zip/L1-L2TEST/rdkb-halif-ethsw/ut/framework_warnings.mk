# SPDX-License-Identifier: Apache-2.0
# Loaded by recursive GNU make. Keep component and other dependency objects
# strict; only these two legacy upstream translation units need exceptions.
ifneq ($(strip $(BUILD_DIR)),)
$(BUILD_DIR)/ut-core/framework/CUnit-2.1-3/CUnit/Sources/Framework/TestDB.o: override XCFLAGS += -Wno-unused-parameter
$(BUILD_DIR)/ut-core/src/cJSON.o: override XCFLAGS += -Wno-cpp
endif
# Several upstream makefiles derive their root from the first MAKEFILE_LIST
# entry. This prelude must not become that entry.
MAKEFILE_LIST := $(filter-out %/framework_warnings.mk,$(MAKEFILE_LIST))
