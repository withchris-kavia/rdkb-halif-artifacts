/* SPDX-License-Identifier: Apache-2.0
 * Linux-reference L2 policy tests. G12/G15/G17 in the canonical specification
 * do not promise reset/idempotency/rollback/stability on arbitrary hardware.
 */
#include "ethsw_test_fixture.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef ETHSW_LINUX_MODEL
#define START() UT_ASSERT_EQUAL_FATAL(ethsw_prepare(), 0)
#define OK(call) UT_ASSERT_EQUAL_FATAL((call), RETURN_OK)
#define ERR(call) UT_ASSERT_EQUAL((call), RETURN_ERR)

static CCSP_HAL_ETHSW_PORT first_port(void)
{
    for (int p = 1; p <= 8; ++p)
        if (ethsw_port_supported(p))
            return (CCSP_HAL_ETHSW_PORT)p;
    return CCSP_HAL_ETHSW_PortMax;
}

static void l2_config_roundtrip(void)
{
    START();
    for (int p = 1; p <= 8; ++p) {
        if (!ethsw_port_supported(p))
            continue;
        for (int r = 0; r <= CCSP_HAL_ETHSW_LINK_Auto; ++r)
            for (int d = 0; d <= CCSP_HAL_ETHSW_DUPLEX_Full; ++d) {
                if (!(ethsw_profile.rate_mask & (1U << (unsigned int)r)) ||
                    !(ethsw_profile.duplex_mask & (1U << (unsigned int)d)))
                    continue;
                CCSP_HAL_ETHSW_LINK_RATE actual_rate = CCSP_HAL_ETHSW_LINK_NULL;
                CCSP_HAL_ETHSW_DUPLEX_MODE actual_duplex = CCSP_HAL_ETHSW_DUPLEX_Auto;
                OK(CcspHalEthSwSetPortCfg((CCSP_HAL_ETHSW_PORT)p,
                    (CCSP_HAL_ETHSW_LINK_RATE)r, (CCSP_HAL_ETHSW_DUPLEX_MODE)d));
                OK(CcspHalEthSwGetPortCfg((CCSP_HAL_ETHSW_PORT)p,
                                         &actual_rate, &actual_duplex));
                UT_ASSERT_EQUAL(actual_rate, r);
                UT_ASSERT_EQUAL(actual_duplex, d);
            }
    }
}

static void l2_admin_roundtrip(void)
{
    START();
    const CCSP_HAL_ETHSW_ADMIN_STATUS sequence[] = {
        CCSP_HAL_ETHSW_AdminUp, CCSP_HAL_ETHSW_AdminDown,
        CCSP_HAL_ETHSW_AdminTest, CCSP_HAL_ETHSW_AdminUp};
    for (int p = 1; p <= 8; ++p) {
        if (!ethsw_port_supported(p))
            continue;
        for (size_t i = 0; i < sizeof(sequence)/sizeof(sequence[0]); ++i) {
            CCSP_HAL_ETHSW_ADMIN_STATUS actual = CCSP_HAL_ETHSW_AdminTest;
            OK(CcspHalEthSwSetPortAdminStatus((CCSP_HAL_ETHSW_PORT)p, sequence[i]));
            OK(CcspHalEthSwGetPortAdminStatus((CCSP_HAL_ETHSW_PORT)p, &actual));
            UT_ASSERT_EQUAL(actual, sequence[i]);
        }
    }
}

static void l2_port_isolation(void)
{
    START();
    CCSP_HAL_ETHSW_LINK_RATE changed_rate = ethsw_profile.initial_rate;
    CCSP_HAL_ETHSW_DUPLEX_MODE changed_duplex = ethsw_profile.initial_duplex;
    for (int r = 0; r <= CCSP_HAL_ETHSW_LINK_Auto; ++r)
        if ((ethsw_profile.rate_mask & (1U << (unsigned int)r)) != 0 &&
            r != (int)ethsw_profile.initial_rate)
            changed_rate = (CCSP_HAL_ETHSW_LINK_RATE)r;
    for (int d = 0; d <= CCSP_HAL_ETHSW_DUPLEX_Full; ++d)
        if ((ethsw_profile.duplex_mask & (1U << (unsigned int)d)) != 0 &&
            d != (int)ethsw_profile.initial_duplex)
            changed_duplex = (CCSP_HAL_ETHSW_DUPLEX_MODE)d;
    for (int p = 1; p <= 8; ++p) {
        if (!ethsw_port_supported(p))
            continue;
        const CCSP_HAL_ETHSW_ADMIN_STATUS changed =
            ethsw_profile.initial_admin == CCSP_HAL_ETHSW_AdminTest ?
            CCSP_HAL_ETHSW_AdminDown : CCSP_HAL_ETHSW_AdminTest;
        OK(CcspHalEthSwSetPortAdminStatus((CCSP_HAL_ETHSW_PORT)p, changed));
        OK(CcspHalEthSwSetAgingSpeed((CCSP_HAL_ETHSW_PORT)p, ethsw_profile.aging_min));
        OK(CcspHalEthSwSetPortCfg((CCSP_HAL_ETHSW_PORT)p,
                                 changed_rate, changed_duplex));
        for (int q = 1; q <= 8; ++q) {
            if (!ethsw_port_supported(q))
                continue;
            CCSP_HAL_ETHSW_ADMIN_STATUS admin = CCSP_HAL_ETHSW_AdminUp;
            CCSP_HAL_ETHSW_LINK_RATE rate = CCSP_HAL_ETHSW_LINK_NULL;
            CCSP_HAL_ETHSW_DUPLEX_MODE duplex = CCSP_HAL_ETHSW_DUPLEX_Full;
            OK(CcspHalEthSwGetPortAdminStatus((CCSP_HAL_ETHSW_PORT)q, &admin));
            OK(CcspHalEthSwGetPortCfg((CCSP_HAL_ETHSW_PORT)q, &rate, &duplex));
            UT_ASSERT_EQUAL(admin, q == p ? changed : ethsw_profile.initial_admin);
            UT_ASSERT_EQUAL(rate, q == p ? changed_rate : ethsw_profile.initial_rate);
            UT_ASSERT_EQUAL(duplex, q == p ? changed_duplex : ethsw_profile.initial_duplex);
            UT_ASSERT_EQUAL(ethsw_model_aging((CCSP_HAL_ETHSW_PORT)q),
                            q == p ? ethsw_profile.aging_min : ethsw_profile.aging_default);
        }
        ethsw_model_reset();
    }
}

static void l2_rejected_invariants(void)
{
    START();
    CCSP_HAL_ETHSW_PORT p = first_port();
    CCSP_HAL_ETHSW_LINK_RATE rate = CCSP_HAL_ETHSW_LINK_NULL;
    CCSP_HAL_ETHSW_DUPLEX_MODE duplex = CCSP_HAL_ETHSW_DUPLEX_Full;
    CCSP_HAL_ETHSW_ADMIN_STATUS admin = CCSP_HAL_ETHSW_AdminTest;
    BOOLEAN enable = 42;
    UINT wan = UINT_MAX;
    ERR(CcspHalEthSwSetPortCfg(p, (CCSP_HAL_ETHSW_LINK_RATE)8,
                               ethsw_profile.initial_duplex));
    ERR(CcspHalEthSwSetPortCfg(p, ethsw_profile.initial_rate,
                               (CCSP_HAL_ETHSW_DUPLEX_MODE)3));
    ERR(CcspHalEthSwSetPortCfg(CCSP_HAL_ETHSW_PortMax,
                               ethsw_profile.initial_rate,
                               ethsw_profile.initial_duplex));
    ERR(CcspHalEthSwSetPortAdminStatus(p, (CCSP_HAL_ETHSW_ADMIN_STATUS)3));
    ERR(CcspHalExtSw_setEthWanEnable((BOOLEAN)2));
    ERR(CcspHalExtSw_setEthWanPort(ethsw_profile.wan_count));
    OK(CcspHalEthSwGetPortCfg(p, &rate, &duplex));
    OK(CcspHalEthSwGetPortAdminStatus(p, &admin));
    OK(CcspHalExtSw_getEthWanEnable(&enable));
    OK(CcspHalExtSw_getEthWanPort(&wan));
    UT_ASSERT_EQUAL(rate, ethsw_profile.initial_rate);
    UT_ASSERT_EQUAL(duplex, ethsw_profile.initial_duplex);
    UT_ASSERT_EQUAL(admin, ethsw_profile.initial_admin);
    UT_ASSERT_EQUAL(enable, ethsw_profile.initial_wan_enable);
    UT_ASSERT_EQUAL(wan, ETHWAN_DEF_INTF_NUM);
}

static void l2_aging_policy(void)
{
    START();
    const CCSP_HAL_ETHSW_PORT p = first_port();
    OK(CcspHalEthSwSetAgingSpeed(p, ethsw_profile.aging_min));
    UT_ASSERT_EQUAL(ethsw_model_aging(p), ethsw_profile.aging_min);
    OK(CcspHalEthSwSetAgingSpeed(p, ethsw_profile.aging_max));
    ERR(CcspHalEthSwSetAgingSpeed(p, ethsw_profile.aging_min - 1));
    ERR(CcspHalEthSwSetAgingSpeed(p, ethsw_profile.aging_max + 1));
    ERR(CcspHalEthSwSetAgingSpeed(CCSP_HAL_ETHSW_PortMax,
                                 ethsw_profile.aging_default));
    UT_ASSERT_EQUAL(ethsw_model_aging(p), ethsw_profile.aging_max);
    /* Private observation only: the public contract has no aging getter. */
}

static void l2_wan_roundtrip(void)
{
    START();
    UINT actual = UINT_MAX;
    OK(CcspHalExtSw_getEthWanPort(&actual));
    UT_ASSERT_EQUAL(actual, ETHWAN_DEF_INTF_NUM);
    for (UINT p = 0; p < ethsw_profile.wan_count; ++p) {
        OK(CcspHalExtSw_setEthWanPort(p));
        for (unsigned int flag = 0; flag <= 1; ++flag) {
            BOOLEAN enabled = 42;
            unsigned char name[64] = {0};
            char expected[64];
            OK(CcspHalExtSw_setEthWanEnable((BOOLEAN)flag));
            OK(CcspHalExtSw_getEthWanEnable(&enabled));
            OK(CcspHalExtSw_getEthWanPort(&actual));
            UT_ASSERT_EQUAL(enabled, flag);
            UT_ASSERT_EQUAL(actual, p);
            OK(GWP_GetEthWanInterfaceName(name, sizeof(name)));
            (void)snprintf(expected, sizeof(expected), "%s%u",
                           ethsw_profile.interface_prefix, p);
            UT_ASSERT_STRING_EQUAL((char *)name, expected);
            /* WAN config is not evidence of physical link-up. */
            UT_ASSERT_EQUAL(GWP_GetEthWanLinkStatus(), 0);
        }
    }
}

static void l2_snapshot_ownership(void)
{
    START();
    ULONG na = 0, nb = 0;
    eth_device_t *a = NULL, *b = NULL;
    const int ra = CcspHalExtSw_getAssociatedDevice(&na, &a);
    const int rb = CcspHalExtSw_getAssociatedDevice(&nb, &b);
    UT_ASSERT_EQUAL(ra, RETURN_OK);
    UT_ASSERT_EQUAL(rb, RETURN_OK);
    UT_ASSERT_EQUAL(na, 1);
    UT_ASSERT_EQUAL(nb, 1);
    UT_ASSERT_PTR_NOT_NULL(a);
    UT_ASSERT_PTR_NOT_NULL(b);
    if (a != NULL && b != NULL && na == 1 && nb == 1) {
        UT_ASSERT_PTR_NOT_EQUAL(a, b);
        a[0].eth_vlanid = 4094;
        a[0].eth_devMacAddress[0] ^= 0x80U;
        UT_ASSERT_EQUAL(b[0].eth_vlanid, ethsw_profile.device.eth_vlanid);
        UT_ASSERT_EQUAL(memcmp(b[0].eth_devMacAddress, ethsw_profile.known_mac, 6), 0);
    }
    free(a);
    free(b);
    a = NULL;
    ethsw_model_fail_allocation(true);
    ERR(CcspHalExtSw_getAssociatedDevice(&na, &a));
    UT_ASSERT_PTR_NULL(a);
    UT_ASSERT_EQUAL(na, 0);
    free(a);
    ethsw_model_fail_allocation(false);
    a = NULL;
    int recovered = CcspHalExtSw_getAssociatedDevice(&na, &a);
    UT_ASSERT_EQUAL(recovered, RETURN_OK);
    UT_ASSERT_EQUAL(na, 1);
    free(a);
}

static void l2_stable_observations(void)
{
    START();
    const CCSP_HAL_ETHSW_PORT p = first_port();
    for (unsigned int i = 0; i < 32; ++i) {
        CCSP_HAL_ETHSW_LINK_RATE rate = CCSP_HAL_ETHSW_LINK_Auto;
        CCSP_HAL_ETHSW_DUPLEX_MODE duplex = CCSP_HAL_ETHSW_DUPLEX_Full;
        CCSP_HAL_ETHSW_LINK_STATUS status = CCSP_HAL_ETHSW_LINK_Up;
        CCSP_HAL_ETH_STATS stats;
        INT port = -1;
        memset(&stats, 0xa5, sizeof(stats));
        OK(CcspHalEthSwGetPortStatus(p, &rate, &duplex, &status));
        OK(CcspHalEthSwGetEthPortStats(p, &stats));
        OK(CcspHalEthSwLocatePortByMacAddress(ethsw_profile.known_mac, &port));
        UT_ASSERT_EQUAL(rate, CCSP_HAL_ETHSW_LINK_NULL);
        UT_ASSERT_EQUAL(duplex, CCSP_HAL_ETHSW_DUPLEX_Auto);
        UT_ASSERT_EQUAL(status, CCSP_HAL_ETHSW_LINK_Disconnected);
        UT_ASSERT_EQUAL(stats.BytesReceived, 0);
        UT_ASSERT_EQUAL(stats.BytesSent, 0);
        UT_ASSERT_EQUAL(port, ethsw_profile.lookup_port);
        UT_ASSERT_EQUAL(GWP_GetEthWanLinkStatus(), 0);
    }
}

static void l2_feature_wan(void)
{
    START();
    UINT port = UINT_MAX;
    BOOLEAN enabled = 42;
    OK(CcspHalExtSw_setEthWanEnable(TRUE));
#ifdef FEATURE_RDKB_AUTO_PORT_SWITCH
    UT_ASSERT_EQUAL(CcspHalExtSw_getCurrentWanHWConf(), TRUE);
#endif
#if defined(FEATURE_RDKB_AUTO_PORT_SWITCH) && defined(FEATURE_RDKB_WAN_MANAGER)
    char name[64];
    UINT selected = ethsw_profile.wan_count - 1U;
    (void)snprintf(name, sizeof(name), "%s%u", ethsw_profile.interface_prefix, selected);
    OK(CcspHalExtSw_ethPortConfigure(name, TRUE));
    OK(CcspHalExtSw_getEthWanPort(&port));
    UT_ASSERT_EQUAL(port, selected);
    ERR(CcspHalExtSw_ethPortConfigure("invalid", FALSE));
    ERR(CcspHalExtSw_ethPortConfigure(name, (BOOLEAN)2));
    OK(CcspHalExtSw_getEthWanPort(&port));
    OK(CcspHalExtSw_getEthWanEnable(&enabled));
    UT_ASSERT_EQUAL(port, selected);
    UT_ASSERT_EQUAL(enabled, TRUE);
    OK(CcspHalExtSw_ethPortConfigure(name, FALSE));
#else
    OK(CcspHalExtSw_getEthWanPort(&port));
    UT_ASSERT_EQUAL(port, ETHWAN_DEF_INTF_NUM);
#endif
    OK(CcspHalExtSw_setEthWanEnable(FALSE));
    OK(CcspHalExtSw_getEthWanEnable(&enabled));
    UT_ASSERT_EQUAL(enabled, FALSE);
#ifdef FEATURE_RDKB_AUTO_PORT_SWITCH
    UT_ASSERT_EQUAL(CcspHalExtSw_getCurrentWanHWConf(), FALSE);
#endif
}

static void register_from_scope(void)
{
    appCallBack local = ethsw_callbacks;
    GWP_RegisterEthWan_Callback(&local);
    memset(&local, 0, sizeof(local));
    CcspHalExtSw_ethAssociatedDevice_callback_register(ethsw_association_callback);
}

static void l2_callback_lifetime(void)
{
    START();
    register_from_scope();
    for (unsigned int i = 1; i <= 8; ++i) {
        ethsw_model_events();
        UT_ASSERT_EQUAL(ethsw_up_calls, i);
        UT_ASSERT_EQUAL(ethsw_down_calls, i);
        UT_ASSERT_EQUAL(ethsw_association_calls, i);
        UT_ASSERT_EQUAL(memcmp(ethsw_callback_device.eth_devMacAddress,
                              ethsw_profile.device.eth_devMacAddress, 6), 0);
        UT_ASSERT_EQUAL(ethsw_callback_device.eth_port, ethsw_profile.device.eth_port);
        UT_ASSERT_EQUAL(ethsw_callback_device.eth_vlanid, ethsw_profile.device.eth_vlanid);
    }
    /* Copied callback payload remains valid after the borrowed event returns. */
    UT_ASSERT_EQUAL(ethsw_callback_device.eth_Active, ethsw_profile.device.eth_Active);
}
#endif

int test_l2_ethsw_hal_register(void);
int test_l2_ethsw_hal_register(void)
{
#ifdef ETHSW_LINUX_MODEL
    static const char *const names[] = {
        "L2.01 config roundtrip", "L2.02 admin roundtrip", "L2.03 per-port isolation",
        "L2.04 rejected-operation invariants", "L2.05 aging model policy",
        "L2.06 WAN roundtrip", "L2.07 snapshot ownership",
        "L2.08 stable observations", "L2.09 feature-gated WAN",
        "L2.10 callback lifetime"};
    static const UT_TestFunction_t functions[] = {
        l2_config_roundtrip, l2_admin_roundtrip, l2_port_isolation,
        l2_rejected_invariants, l2_aging_policy, l2_wan_roundtrip,
        l2_snapshot_ownership, l2_stable_observations, l2_feature_wan,
        l2_callback_lifetime};
    return ethsw_add_cases(UT_add_suite_withGroupID("EthSW Linux model L2",
              ethsw_suite_init, NULL, UT_TESTS_L2), names, functions, 10);
#else
    /* These policies are not a vendor hardware conformance claim. */
    return 0;
#endif
}
