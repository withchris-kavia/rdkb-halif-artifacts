/* SPDX-License-Identifier: Apache-2.0 */
#ifndef ETHSW_TEST_FIXTURE_H
#define ETHSW_TEST_FIXTURE_H
#include <stdbool.h>
#include <ut.h>
#include <ccsp_hal_ethsw.h>

typedef struct {
    unsigned int port_mask, rate_mask, duplex_mask, wan_count;
    CCSP_HAL_ETHSW_LINK_RATE initial_rate;
    CCSP_HAL_ETHSW_DUPLEX_MODE initial_duplex;
    CCSP_HAL_ETHSW_ADMIN_STATUS initial_admin;
    int aging_min, aging_max, aging_default;
    BOOLEAN initial_wan_enable;
    char interface_prefix[16];
    unsigned char known_mac[6], moca_mac[6];
    int lookup_port;
    eth_device_t device;
} ethsw_profile_t;

extern ethsw_profile_t ethsw_profile;
extern bool ethsw_setup_probe;
extern bool ethsw_registration_probe;
extern unsigned int ethsw_up_calls, ethsw_down_calls, ethsw_association_calls;
extern eth_device_t ethsw_callback_device;
extern appCallBack ethsw_callbacks;

int ethsw_fixture_load(const char *path);
int ethsw_suite_init(void);
int ethsw_prepare(void);
bool ethsw_port_supported(int port);
void ethsw_reset_callback_counts(void);
INT ethsw_association_callback(eth_device_t *device);
int ethsw_add_cases(UT_test_suite_t *suite, const char *const *names,
                   const UT_TestFunction_t *functions, unsigned int count);

#ifdef ETHSW_LINUX_MODEL
/* Test controls, never exported by a vendor library or declared in HAL header. */
void ethsw_model_reset(void);
int ethsw_model_aging(CCSP_HAL_ETHSW_PORT port);
void ethsw_model_events(void);
void ethsw_model_fail_allocation(bool fail);
#endif
#endif
