/* SPDX-License-Identifier: Apache-2.0
 * L1: public header API contracts, parameter validation and profile capabilities.
 * Profile-specific checks below do not advertise universal hardware behavior.
 */
#include "ethsw_test_fixture.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PREPARE() UT_ASSERT_EQUAL_FATAL(ethsw_prepare(), 0)
#define OK(call) UT_ASSERT_EQUAL((call), RETURN_OK)
#define ERR(call) UT_ASSERT_EQUAL((call), RETURN_ERR)
static const int invalid_ports[] = {-1, 0, CCSP_HAL_ETHSW_MgmtPort,
                                    CCSP_HAL_ETHSW_PortMax, 21};

static void l1_init(void)
{
    PREPARE();
    OK(CcspHalEthSwInit());
}

static void l1_status(void)
{
    PREPARE();
    CCSP_HAL_ETHSW_LINK_RATE rate = CCSP_HAL_ETHSW_LINK_Auto;
    CCSP_HAL_ETHSW_DUPLEX_MODE duplex = CCSP_HAL_ETHSW_DUPLEX_Full;
    CCSP_HAL_ETHSW_LINK_STATUS status = CCSP_HAL_ETHSW_LINK_Down;
    for (int p = 1; p <= 18; ++p) {
        int rc = CcspHalEthSwGetPortStatus((CCSP_HAL_ETHSW_PORT)p,
                                          &rate, &duplex, &status);
        if (!ethsw_port_supported(p)) {
            UT_ASSERT_EQUAL(rc, RETURN_ERR);
            continue;
        }
        UT_ASSERT_EQUAL_FATAL(rc, RETURN_OK);
        UT_ASSERT((int)rate >= 0 && rate <= CCSP_HAL_ETHSW_LINK_Auto);
        UT_ASSERT((int)duplex >= 0 && duplex <= CCSP_HAL_ETHSW_DUPLEX_Full);
        UT_ASSERT((int)status >= 0 && status <= CCSP_HAL_ETHSW_LINK_Disconnected);
        ERR(CcspHalEthSwGetPortStatus((CCSP_HAL_ETHSW_PORT)p, NULL, &duplex, &status));
        ERR(CcspHalEthSwGetPortStatus((CCSP_HAL_ETHSW_PORT)p, &rate, NULL, &status));
        ERR(CcspHalEthSwGetPortStatus((CCSP_HAL_ETHSW_PORT)p, &rate, &duplex, NULL));
    }
    for (size_t i = 0; i < sizeof(invalid_ports)/sizeof(invalid_ports[0]); ++i)
        ERR(CcspHalEthSwGetPortStatus((CCSP_HAL_ETHSW_PORT)invalid_ports[i],
                                      &rate, &duplex, &status));
}

static void l1_get_config(void)
{
    PREPARE();
    CCSP_HAL_ETHSW_LINK_RATE rate = CCSP_HAL_ETHSW_LINK_NULL;
    CCSP_HAL_ETHSW_DUPLEX_MODE duplex = CCSP_HAL_ETHSW_DUPLEX_Auto;
    for (int p = -1; p <= 21; ++p) {
        int rc = CcspHalEthSwGetPortCfg((CCSP_HAL_ETHSW_PORT)p, &rate, &duplex);
        if (!ethsw_port_supported(p)) {
            UT_ASSERT_EQUAL(rc, RETURN_ERR);
            continue;
        }
        UT_ASSERT_EQUAL_FATAL(rc, RETURN_OK);
        UT_ASSERT((int)rate >= 0 && rate <= CCSP_HAL_ETHSW_LINK_Auto);
        UT_ASSERT((int)duplex >= 0 && duplex <= CCSP_HAL_ETHSW_DUPLEX_Full);
        ERR(CcspHalEthSwGetPortCfg((CCSP_HAL_ETHSW_PORT)p, NULL, &duplex));
        ERR(CcspHalEthSwGetPortCfg((CCSP_HAL_ETHSW_PORT)p, &rate, NULL));
    }
}

static void l1_set_config(void)
{
    PREPARE();
    for (int p = -1; p <= 21; ++p) {
        CCSP_HAL_ETHSW_PORT port = (CCSP_HAL_ETHSW_PORT)p;
        if (!ethsw_port_supported(p)) {
            ERR(CcspHalEthSwSetPortCfg(port, ethsw_profile.initial_rate,
                                       ethsw_profile.initial_duplex));
            continue;
        }
        /* Includes valid 10G and LINK_NULL; support is selected by profile. */
        for (int r = 0; r <= CCSP_HAL_ETHSW_LINK_Auto; ++r)
            for (int d = 0; d <= CCSP_HAL_ETHSW_DUPLEX_Full; ++d) {
                int expected = (ethsw_profile.rate_mask & (1U << (unsigned int)r)) &&
                               (ethsw_profile.duplex_mask & (1U << (unsigned int)d))
                               ? RETURN_OK : RETURN_ERR;
                UT_ASSERT_EQUAL(CcspHalEthSwSetPortCfg(port,
                     (CCSP_HAL_ETHSW_LINK_RATE)r, (CCSP_HAL_ETHSW_DUPLEX_MODE)d),
                     expected);
            }
        ERR(CcspHalEthSwSetPortCfg(port, (CCSP_HAL_ETHSW_LINK_RATE)-1,
                                   ethsw_profile.initial_duplex));
        ERR(CcspHalEthSwSetPortCfg(port, (CCSP_HAL_ETHSW_LINK_RATE)8,
                                   ethsw_profile.initial_duplex));
        ERR(CcspHalEthSwSetPortCfg(port, ethsw_profile.initial_rate,
                                   (CCSP_HAL_ETHSW_DUPLEX_MODE)-1));
        ERR(CcspHalEthSwSetPortCfg(port, ethsw_profile.initial_rate,
                                   (CCSP_HAL_ETHSW_DUPLEX_MODE)3));
    }
}

static void l1_get_admin(void)
{
    PREPARE();
    CCSP_HAL_ETHSW_ADMIN_STATUS admin = CCSP_HAL_ETHSW_AdminTest;
    for (int p = -1; p <= 21; ++p) {
        CCSP_HAL_ETHSW_PORT port = (CCSP_HAL_ETHSW_PORT)p;
        if (!ethsw_port_supported(p)) {
            ERR(CcspHalEthSwGetPortAdminStatus(port, &admin));
            continue;
        }
        OK(CcspHalEthSwSetPortAdminStatus(port, CCSP_HAL_ETHSW_AdminDown));
        UT_ASSERT_EQUAL_FATAL(CcspHalEthSwGetPortAdminStatus(port, &admin), RETURN_OK);
        UT_ASSERT_EQUAL(admin, CCSP_HAL_ETHSW_AdminDown);
        ERR(CcspHalEthSwGetPortAdminStatus(port, NULL));
    }
}

static void l1_set_admin(void)
{
    PREPARE();
    for (int p = -1; p <= 21; ++p) {
        CCSP_HAL_ETHSW_PORT port = (CCSP_HAL_ETHSW_PORT)p;
        if (!ethsw_port_supported(p)) {
            ERR(CcspHalEthSwSetPortAdminStatus(port, CCSP_HAL_ETHSW_AdminUp));
            continue;
        }
        OK(CcspHalEthSwSetPortAdminStatus(port, CCSP_HAL_ETHSW_AdminUp));
        OK(CcspHalEthSwSetPortAdminStatus(port, CCSP_HAL_ETHSW_AdminDown));
        OK(CcspHalEthSwSetPortAdminStatus(port, CCSP_HAL_ETHSW_AdminTest));
        ERR(CcspHalEthSwSetPortAdminStatus(port, (CCSP_HAL_ETHSW_ADMIN_STATUS)-1));
        ERR(CcspHalEthSwSetPortAdminStatus(port, (CCSP_HAL_ETHSW_ADMIN_STATUS)3));
    }
}

static void l1_aging(void)
{
    PREPARE();
    for (int p = -1; p <= 21; ++p) {
        CCSP_HAL_ETHSW_PORT port = (CCSP_HAL_ETHSW_PORT)p;
        if (!ethsw_port_supported(p)) {
            ERR(CcspHalEthSwSetAgingSpeed(port, ethsw_profile.aging_default));
            continue;
        }
        OK(CcspHalEthSwSetAgingSpeed(port, ethsw_profile.aging_min));
        OK(CcspHalEthSwSetAgingSpeed(port, ethsw_profile.aging_max));
        ERR(CcspHalEthSwSetAgingSpeed(port, ethsw_profile.aging_min - 1));
        ERR(CcspHalEthSwSetAgingSpeed(port, ethsw_profile.aging_max + 1));
        ERR(CcspHalEthSwSetAgingSpeed(port, INT_MIN));
    }
}

static void l1_mac(void)
{
    PREPARE();
    INT port = -99;
    unsigned char absent[6];
    memcpy(absent, ethsw_profile.known_mac, 6);
    absent[0] ^= 0x80U;
    if (memcmp(absent, ethsw_profile.moca_mac, 6) == 0)
        absent[1] ^= 0x80U;
    UT_ASSERT_EQUAL_FATAL(CcspHalEthSwLocatePortByMacAddress(
                            ethsw_profile.known_mac, &port), RETURN_OK);
    UT_ASSERT_EQUAL(port, ethsw_profile.lookup_port);
    UT_ASSERT_EQUAL_FATAL(CcspHalEthSwLocatePortByMacAddress(
                            ethsw_profile.moca_mac, &port), RETURN_OK);
    UT_ASSERT_EQUAL(port, 0);
    ERR(CcspHalEthSwLocatePortByMacAddress(absent, &port));
    ERR(CcspHalEthSwLocatePortByMacAddress(NULL, &port));
    ERR(CcspHalEthSwLocatePortByMacAddress(ethsw_profile.known_mac, NULL));
}

static void l1_stats(void)
{
    PREPARE();
    CCSP_HAL_ETH_STATS stats = {0};
    for (int p = -1; p <= 21; ++p) {
        if (!ethsw_port_supported(p)) {
            ERR(CcspHalEthSwGetEthPortStats((CCSP_HAL_ETHSW_PORT)p, &stats));
            continue;
        }
        memset(&stats, 0xa5, sizeof(stats));
        UT_ASSERT_EQUAL_FATAL(CcspHalEthSwGetEthPortStats(
                                (CCSP_HAL_ETHSW_PORT)p, &stats), RETURN_OK);
#ifdef ETHSW_LINUX_MODEL
#define ZERO(field) UT_ASSERT_EQUAL(stats.field, 0)
        ZERO(BytesSent); ZERO(BytesReceived); ZERO(PacketsSent); ZERO(PacketsReceived);
        ZERO(ErrorsSent); ZERO(ErrorsReceived); ZERO(UnicastPacketsSent);
        ZERO(UnicastPacketsReceived); ZERO(DiscardPacketsSent);
        ZERO(DiscardPacketsReceived); ZERO(MulticastPacketsSent);
        ZERO(MulticastPacketsReceived); ZERO(BroadcastPacketsSent);
        ZERO(BroadcastPacketsReceived); ZERO(UnknownProtoPacketsReceived);
#undef ZERO
#endif
        ERR(CcspHalEthSwGetEthPortStats((CCSP_HAL_ETHSW_PORT)p, NULL));
    }
}

static void l1_associated(void)
{
    PREPARE();
    ULONG count = 0;
    eth_device_t *devices = NULL;
    int rc = CcspHalExtSw_getAssociatedDevice(&count, &devices);
    UT_ASSERT_EQUAL(rc, RETURN_OK);
    if (rc == RETURN_OK) {
        UT_ASSERT_EQUAL(count, 1);
        UT_ASSERT_PTR_NOT_NULL(devices);
        if (devices != NULL && count == 1) {
            UT_ASSERT_EQUAL(memcmp(devices[0].eth_devMacAddress,
                                  ethsw_profile.known_mac, 6), 0);
            UT_ASSERT_EQUAL(devices[0].eth_port, ethsw_profile.device.eth_port);
            UT_ASSERT_EQUAL(devices[0].eth_vlanid, ethsw_profile.device.eth_vlanid);
            UT_ASSERT_EQUAL(devices[0].eth_devTxRate, ethsw_profile.device.eth_devTxRate);
            UT_ASSERT_EQUAL(devices[0].eth_devRxRate, ethsw_profile.device.eth_devRxRate);
            UT_ASSERT_EQUAL(devices[0].eth_Active, ethsw_profile.device.eth_Active);
        }
    }
    /* This profile explicitly uses the libc allocator; not a portable HAL rule. */
    free(devices);
    devices = NULL;
    ERR(CcspHalExtSw_getAssociatedDevice(NULL, &devices));
    free(devices);
    ERR(CcspHalExtSw_getAssociatedDevice(&count, NULL));
#ifdef ETHSW_LINUX_MODEL
    devices = NULL;
    ethsw_model_fail_allocation(true);
    ERR(CcspHalExtSw_getAssociatedDevice(&count, &devices));
    UT_ASSERT_EQUAL(count, 0);
    UT_ASSERT_PTR_NULL(devices);
    free(devices);
    ethsw_model_fail_allocation(false);
#endif
}

static void l1_association_callback(void)
{
    PREPARE();
    CcspHalExtSw_ethAssociatedDevice_callback_register(ethsw_association_callback);
#ifdef ETHSW_LINUX_MODEL
    ethsw_model_events();
    UT_ASSERT_EQUAL(ethsw_association_calls, 1);
    UT_ASSERT_EQUAL(memcmp(ethsw_callback_device.eth_devMacAddress,
                          ethsw_profile.known_mac, 6), 0);
#else
    /* void registration cannot acknowledge success. Check the consumer itself. */
    UT_ASSERT_EQUAL(ethsw_association_callback(&ethsw_profile.device), RETURN_OK);
#endif
    UT_ASSERT_EQUAL(ethsw_association_callback(NULL), RETURN_ERR);
}

static void l1_get_wan_enable(void)
{
    PREPARE();
    BOOLEAN flag = 42;
    OK(CcspHalExtSw_setEthWanEnable(FALSE));
    UT_ASSERT_EQUAL_FATAL(CcspHalExtSw_getEthWanEnable(&flag), RETURN_OK);
    UT_ASSERT_EQUAL(flag, FALSE);
    ERR(CcspHalExtSw_getEthWanEnable(NULL));
}

static void l1_set_wan_enable(void)
{
    PREPARE();
    OK(CcspHalExtSw_setEthWanEnable(TRUE));
    OK(CcspHalExtSw_setEthWanEnable(FALSE));
    ERR(CcspHalExtSw_setEthWanEnable((BOOLEAN)2));
    ERR(CcspHalExtSw_setEthWanEnable((BOOLEAN)255));
}

static void l1_get_wan_port(void)
{
    PREPARE();
    UINT port = UINT_MAX;
    OK(CcspHalExtSw_setEthWanPort(ethsw_profile.wan_count - 1U));
    UT_ASSERT_EQUAL_FATAL(CcspHalExtSw_getEthWanPort(&port), RETURN_OK);
    UT_ASSERT_EQUAL(port, ethsw_profile.wan_count - 1U);
    ERR(CcspHalExtSw_getEthWanPort(NULL));
}

static void l1_set_wan_port(void)
{
    PREPARE();
    for (UINT p = 0; p < ethsw_profile.wan_count; ++p)
        OK(CcspHalExtSw_setEthWanPort(p));
    ERR(CcspHalExtSw_setEthWanPort(ethsw_profile.wan_count));
    ERR(CcspHalExtSw_setEthWanPort(UINT_MAX));
}

static void l1_wan_callback(void)
{
    PREPARE();
    GWP_RegisterEthWan_Callback(&ethsw_callbacks);
#ifdef ETHSW_LINUX_MODEL
    ethsw_model_events();
    UT_ASSERT_EQUAL(ethsw_up_calls, 1);
    UT_ASSERT_EQUAL(ethsw_down_calls, 1);
#else
    /* No return or portable event trigger: do not claim registration success. */
    UT_ASSERT_PTR_NOT_NULL(ethsw_callbacks.pGWP_act_EthWanLinkUP);
    UT_ASSERT_PTR_NOT_NULL(ethsw_callbacks.pGWP_act_EthWanLinkDown);
#endif
}

static void l1_wan_link(void)
{
    PREPARE();
    int status = GWP_GetEthWanLinkStatus();
    UT_ASSERT(status == 0 || status == 1);
#ifdef ETHSW_LINUX_MODEL
    UT_ASSERT_EQUAL(status, 0);
#endif
}

static void l1_interface(void)
{
    PREPARE();
    struct { unsigned char before; unsigned char name[262]; unsigned char after; } buf;
    char expected[64];
    UINT port = 0;
    UT_ASSERT_EQUAL_FATAL(CcspHalExtSw_getEthWanPort(&port), RETURN_OK);
    (void)snprintf(expected, sizeof(expected), "%s%u",
                   ethsw_profile.interface_prefix, port);
    for (ULONG size = 64; size <= 262; ++size) {
        memset(&buf, 0xa5, sizeof(buf));
        UT_ASSERT_EQUAL_FATAL(GWP_GetEthWanInterfaceName(buf.name, size), RETURN_OK);
        UT_ASSERT_PTR_NOT_NULL(memchr(buf.name, '\0', (size_t)size));
        if (memchr(buf.name, '\0', (size_t)size) != NULL)
            UT_ASSERT_STRING_EQUAL((char *)buf.name, expected);
        UT_ASSERT_EQUAL(buf.before, 0xa5);
        UT_ASSERT_EQUAL(buf.after, 0xa5);
        for (size_t i = (size_t)size; i < sizeof(buf.name); ++i)
            UT_ASSERT_EQUAL(buf.name[i], 0xa5);
    }
    ERR(GWP_GetEthWanInterfaceName(NULL, 64));
    /* G05 conservative policy, not an assertion that the ambiguous header was fixed. */
    for (ULONG size = 0; size < 64; ++size)
        ERR(GWP_GetEthWanInterfaceName(buf.name, size));
    ERR(GWP_GetEthWanInterfaceName(buf.name, 263));
    ERR(GWP_GetEthWanInterfaceName(buf.name, ULONG_MAX));
}

#ifdef FEATURE_RDKB_AUTO_PORT_SWITCH
static void l1_current_wan(void)
{
    PREPARE();
    OK(CcspHalExtSw_setEthWanEnable(TRUE));
    UT_ASSERT_EQUAL(CcspHalExtSw_getCurrentWanHWConf(), TRUE);
    OK(CcspHalExtSw_setEthWanEnable(FALSE));
    UT_ASSERT_EQUAL(CcspHalExtSw_getCurrentWanHWConf(), FALSE);
}
#endif

#if defined(FEATURE_RDKB_AUTO_PORT_SWITCH) && defined(FEATURE_RDKB_WAN_MANAGER)
static void l1_configure_wan(void)
{
    PREPARE();
    char name[64];
    for (UINT p = 0; p < ethsw_profile.wan_count; ++p) {
        (void)snprintf(name, sizeof(name), "%s%u", ethsw_profile.interface_prefix, p);
        OK(CcspHalExtSw_ethPortConfigure(name, TRUE));
        OK(CcspHalExtSw_ethPortConfigure(name, FALSE));
        ERR(CcspHalExtSw_ethPortConfigure(name, (BOOLEAN)2));
    }
    (void)snprintf(name, sizeof(name), "%s%u", ethsw_profile.interface_prefix,
                   ethsw_profile.wan_count);
    ERR(CcspHalExtSw_ethPortConfigure(name, TRUE));
    ERR(CcspHalExtSw_ethPortConfigure(NULL, TRUE));
    ERR(CcspHalExtSw_ethPortConfigure("", TRUE));
    ERR(CcspHalExtSw_ethPortConfigure("not-a-model-interface", TRUE));
}
#endif

int test_ethsw_hal_register(void);
int test_ethsw_hal_register(void)
{
    static const char *const names[] = {
        "Init", "GetPortStatus", "GetPortCfg", "SetPortCfg",
        "GetPortAdminStatus", "SetPortAdminStatus", "SetAgingSpeed",
        "LocatePortByMacAddress", "GetEthPortStats", "getAssociatedDevice",
        "association callback", "getEthWanEnable", "setEthWanEnable",
        "getEthWanPort", "setEthWanPort", "WAN callback", "WAN link",
        "WAN interface name",
#ifdef FEATURE_RDKB_AUTO_PORT_SWITCH
        "getCurrentWanHWConf",
#endif
#if defined(FEATURE_RDKB_AUTO_PORT_SWITCH) && defined(FEATURE_RDKB_WAN_MANAGER)
        "ethPortConfigure",
#endif
    };
    static const UT_TestFunction_t functions[] = {
        l1_init, l1_status, l1_get_config, l1_set_config, l1_get_admin,
        l1_set_admin, l1_aging, l1_mac, l1_stats, l1_associated,
        l1_association_callback, l1_get_wan_enable, l1_set_wan_enable,
        l1_get_wan_port, l1_set_wan_port, l1_wan_callback, l1_wan_link,
        l1_interface,
#ifdef FEATURE_RDKB_AUTO_PORT_SWITCH
        l1_current_wan,
#endif
#if defined(FEATURE_RDKB_AUTO_PORT_SWITCH) && defined(FEATURE_RDKB_WAN_MANAGER)
        l1_configure_wan,
#endif
    };
    return ethsw_add_cases(UT_add_suite_withGroupID("EthSW L1",
              ethsw_suite_init, NULL, UT_TESTS_L1), names, functions,
              (unsigned int)(sizeof(functions)/sizeof(functions[0])));
}
