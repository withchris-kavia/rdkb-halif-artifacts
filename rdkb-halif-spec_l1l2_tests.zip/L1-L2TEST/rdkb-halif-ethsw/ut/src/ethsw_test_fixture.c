/* SPDX-License-Identifier: Apache-2.0 */
#include "ethsw_test_fixture.h"
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ut_kvp.h>

ethsw_profile_t ethsw_profile;
bool ethsw_setup_probe;
bool ethsw_registration_probe;
unsigned int ethsw_up_calls, ethsw_down_calls, ethsw_association_calls;
eth_device_t ethsw_callback_device;

static void up_callback(void) { ++ethsw_up_calls; }
static void down_callback(void) { ++ethsw_down_calls; }
/* Static storage lasts until process exit, even if a vendor retains this object. */
appCallBack ethsw_callbacks = {up_callback, down_callback};

void ethsw_reset_callback_counts(void)
{
    ethsw_up_calls = ethsw_down_calls = ethsw_association_calls = 0;
    memset(&ethsw_callback_device, 0, sizeof(ethsw_callback_device));
}

INT ethsw_association_callback(eth_device_t *device)
{
    if (device == NULL)
        return RETURN_ERR;
    ethsw_callback_device = *device;
    ++ethsw_association_calls;
    return RETURN_OK;
}

static int text(ut_kvp_instance_t *kvp, const char *key, char *out, size_t size)
{
    memset(out, 0xa5, size);
    if (ut_kvp_getStringField(kvp, key, out, (uint32_t)size) !=
            UT_KVP_STATUS_SUCCESS || memchr(out, '\0', size) == NULL)
        return -1;
    return 0;
}

/* KVP's numeric getters return zero for errors. Validate lexical form and range
 * first, rather than accidentally accepting a malformed zero-valued setting. */
static int number(ut_kvp_instance_t *kvp, const char *key, unsigned int *out)
{
    char value[64], *end;
    unsigned long parsed;
    if (text(kvp, key, value, sizeof(value)) != 0 || value[0] == '\0')
        return -1;
    for (size_t i = 0; value[i] != '\0'; ++i)
        if (!isdigit((unsigned char)value[i]))
            return -1;
    errno = 0;
    parsed = strtoul(value, &end, 10);
    if (errno != 0 || *end != '\0' || parsed > INT_MAX ||
        ut_kvp_getUInt32Field(kvp, key) != parsed)
        return -1;
    *out = (unsigned int)parsed;
    return 0;
}

static int boolean(ut_kvp_instance_t *kvp, const char *key, BOOLEAN *out)
{
    char value[16];
    if (text(kvp, key, value, sizeof(value)) != 0 ||
        (strcmp(value, "true") != 0 && strcmp(value, "false") != 0))
        return -1;
    *out = ut_kvp_getBoolField(kvp, key) ? TRUE : FALSE;
    return 0;
}

static int mac(ut_kvp_instance_t *kvp, const char *key, unsigned char out[6])
{
    char value[32];
    if (text(kvp, key, value, sizeof(value)) != 0 || strlen(value) != 17)
        return -1;
    for (unsigned int i = 0; i < 6; ++i) {
        unsigned int byte;
        const size_t pos = 3U * i;
        if (!isxdigit((unsigned char)value[pos]) ||
            !isxdigit((unsigned char)value[pos + 1U]) ||
            (i < 5U && value[pos + 2U] != ':') ||
            sscanf(value + pos, "%2x", &byte) != 1)
            return -1;
        out[i] = (unsigned char)byte;
    }
    return 0;
}

int ethsw_fixture_load(const char *path)
{
    ut_kvp_instance_t *kvp = ut_kvp_createInstance();
    ethsw_profile_t p = {0};
    unsigned int rate, duplex, admin, amin, amax, aging, lookup;
    unsigned int dport, vlan, tx, rx;
    char kind[32];
    int result = -1;
    if (kvp == NULL)
        return -1;
    if (ut_kvp_open(kvp, (char *)path) != UT_KVP_STATUS_SUCCESS)
        goto done;
#define NUM(key, target) do { if (number(kvp, "ethsw." key, &(target)) != 0) goto done; } while (0)
    if (text(kvp, "ethsw.kind", kind, sizeof(kind)) != 0 ||
        strcmp(kind, "linux-reference-v1") != 0)
        goto done;
    NUM("port_mask", p.port_mask);
    NUM("rate_mask", p.rate_mask);
    NUM("duplex_mask", p.duplex_mask);
    NUM("wan_port_count", p.wan_count);
    NUM("initial_rate", rate);
    NUM("initial_duplex", duplex);
    NUM("initial_admin", admin);
    NUM("aging_min", amin);
    NUM("aging_max", amax);
    NUM("aging_default", aging);
    NUM("lookup_port", lookup);
    NUM("device_port", dport);
    NUM("device_vlan", vlan);
    NUM("device_tx_rate", tx);
    NUM("device_rx_rate", rx);
#undef NUM
    if (p.port_mask == 0 || p.port_mask > 255U ||
        p.rate_mask == 0 || p.rate_mask > 255U ||
        p.duplex_mask == 0 || p.duplex_mask > 7U ||
        p.wan_count < 2 || p.wan_count > 8 ||
        ETHWAN_DEF_INTF_NUM < 0 || (unsigned int)ETHWAN_DEF_INTF_NUM >= p.wan_count ||
        rate > CCSP_HAL_ETHSW_LINK_Auto ||
        duplex > CCSP_HAL_ETHSW_DUPLEX_Full || admin > CCSP_HAL_ETHSW_AdminTest ||
        (p.rate_mask & (1U << rate)) == 0 ||
        (p.duplex_mask & (1U << duplex)) == 0 ||
        amin == 0 || amin > aging || aging > amax || amax == INT_MAX ||
        lookup < 1 || lookup > 4 || dport >= p.wan_count ||
        vlan < 1 || vlan > 4094)
        goto done;
    if (boolean(kvp, "ethsw.initial_wan_enable", &p.initial_wan_enable) != 0 ||
        boolean(kvp, "ethsw.device_active", &p.device.eth_Active) != 0 ||
        text(kvp, "ethsw.interface_prefix", p.interface_prefix,
             sizeof(p.interface_prefix)) != 0 ||
        mac(kvp, "ethsw.known_mac", p.known_mac) != 0 ||
        mac(kvp, "ethsw.moca_mac", p.moca_mac) != 0 ||
        memcmp(p.known_mac, p.moca_mac, 6) == 0)
        goto done;
    if (p.interface_prefix[0] == '\0')
        goto done;
    for (size_t i = 0; p.interface_prefix[i] != '\0'; ++i)
        if (!isalpha((unsigned char)p.interface_prefix[i]) &&
            p.interface_prefix[i] != '_')
            goto done;
    p.initial_rate = (CCSP_HAL_ETHSW_LINK_RATE)rate;
    p.initial_duplex = (CCSP_HAL_ETHSW_DUPLEX_MODE)duplex;
    p.initial_admin = (CCSP_HAL_ETHSW_ADMIN_STATUS)admin;
    p.aging_min = (int)amin;
    p.aging_max = (int)amax;
    p.aging_default = (int)aging;
    p.lookup_port = (int)lookup;
    memcpy(p.device.eth_devMacAddress, p.known_mac, 6);
    p.device.eth_port = (int)dport;
    p.device.eth_vlanid = (int)vlan;
    p.device.eth_devTxRate = (int)tx;
    p.device.eth_devRxRate = (int)rx;
    ethsw_profile = p;
    result = 0;
done:
    if (result != 0)
        fprintf(stderr, "Rejected EthSW profile: %s\n", path);
    ut_kvp_destroyInstance(kvp);
    return result;
}

bool ethsw_port_supported(int port)
{
    return port >= CCSP_HAL_ETHSW_EthPort1 &&
           port <= CCSP_HAL_ETHSW_EthPort8 &&
           (ethsw_profile.port_mask & (1U << (unsigned int)(port - 1))) != 0;
}

int ethsw_suite_init(void)
{
    if (ethsw_setup_probe)
        return -1;
    return CcspHalEthSwInit() == RETURN_OK ? 0 : -1;
}

int ethsw_prepare(void)
{
#ifdef ETHSW_LINUX_MODEL
    ethsw_model_reset();
#endif
    ethsw_reset_callback_counts();
    return 0;
}

int ethsw_add_cases(UT_test_suite_t *suite, const char *const *names,
                   const UT_TestFunction_t *functions, unsigned int count)
{
    if (suite == NULL || CU_get_error() != CUE_SUCCESS)
        return -1;
    for (unsigned int i = 0; i < count; ++i) {
        UT_TestFunction_t function = ethsw_registration_probe ? NULL : functions[i];
        if (UT_add_test(suite, names[i], function) == NULL ||
            CU_get_error() != CUE_SUCCESS)
            return -1;
    }
    return 0;
}
