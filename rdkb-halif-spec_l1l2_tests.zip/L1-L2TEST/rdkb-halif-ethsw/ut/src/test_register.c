/* SPDX-License-Identifier: Apache-2.0 */
extern int test_ethsw_hal_register(void);
extern int test_l2_ethsw_hal_register(void);

int register_hal_tests(void);
int register_hal_tests(void)
{
    if (test_ethsw_hal_register() != 0)
        return -1;
    return test_l2_ethsw_hal_register();
}
