/* SPDX-License-Identifier: Apache-2.0 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ut.h>
#include <CUnit.h>
#include <TestRun.h>
#include "ethsw_test_fixture.h"

extern int register_hal_tests(void);
void __real_CU_cleanup_registry(void);
void __wrap_CU_cleanup_registry(void);

static bool running;
static unsigned int failed;
static unsigned int executed;

/* ut-core 3.2 cleans the registry before returning. The GNU ld wrapper keeps
 * result ownership in this executable without modifying framework sources. */
void __wrap_CU_cleanup_registry(void)
{
    if (running) {
        executed = CU_get_number_of_tests_run();
        failed = CU_get_number_of_tests_failed() +
                 CU_get_number_of_failures() +
                 CU_get_number_of_suites_failed() +
                 CU_get_number_of_failure_records();
        printf("ETHSW_RESULT tests=%u failed_tests=%u failed_assertions=%u "
               "failed_suites=%u\n", executed, CU_get_number_of_tests_failed(),
               CU_get_number_of_failures(), CU_get_number_of_suites_failed());
    }
    __real_CU_cleanup_registry();
}

static void deliberate_failure(void)
{
    UT_ASSERT_EQUAL(1, 0);
}

int main(int argc, char **argv)
{
    char **core_args = calloc((size_t)argc + 1U, sizeof(*core_args));
    const char *profile = NULL;
    const char *probe = NULL;
    int count = 1;
    int result = 1;
    if (core_args == NULL)
        return 1;
    core_args[0] = argv[0];
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "-p") == 0) {
            if (profile != NULL || ++i == argc || argv[i][0] == '-')
                goto invalid;
            profile = argv[i];
        } else if (strncmp(argv[i], "--probe=", 8) == 0) {
            probe = argv[i] + 8;
            if (strcmp(probe, "assertion") != 0 &&
                strcmp(probe, "registration") != 0 &&
                strcmp(probe, "setup") != 0)
                goto invalid;
        } else if (strcmp(argv[i], "-b") == 0 || strcmp(argv[i], "-a") == 0 ||
                   strcmp(argv[i], "-c") == 0 || strcmp(argv[i], "-t") == 0) {
            core_args[count++] = argv[i];
        } else if (strcmp(argv[i], "-l") == 0 || strcmp(argv[i], "-d") == 0 ||
                   strcmp(argv[i], "-e") == 0) {
            const bool group = strcmp(argv[i], "-l") != 0;
            core_args[count++] = argv[i];
            if (++i == argc || argv[i][0] == '-')
                goto invalid;
            if (group && (strlen(argv[i]) != 1U ||
                          argv[i][0] < '1' || argv[i][0] > '9'))
                goto invalid;
            core_args[count++] = argv[i];
        } else if (strcmp(argv[i], "-h") == 0) {
            puts("Usage: hal_test -p PROFILE [-b|-a|-c] [-d GROUP] [-e GROUP]\n"
                 "       [--probe=assertion|registration|setup]\n"
                 "Profile is required; probes intentionally exit 1.");
            result = 0;
            goto done;
        } else {
            goto invalid;
        }
    }
    if (profile == NULL || ethsw_fixture_load(profile) != 0)
        goto invalid;
    if (UT_init(count, core_args) != UT_STATUS_OK)
        goto done;
    ethsw_setup_probe = probe != NULL && strcmp(probe, "setup") == 0;
    ethsw_registration_probe = probe != NULL && strcmp(probe, "registration") == 0;
    if (register_hal_tests() != 0) {
        fputs("Test registration failed\n", stderr);
        CU_cleanup_registry();
        UT_exit();
        goto done;
    }
    if (probe != NULL && strcmp(probe, "assertion") == 0) {
        UT_test_suite_t *suite = UT_add_suite_withGroupID(
            "exit-code probe", NULL, NULL, UT_TESTS_L1);
        if (suite == NULL || UT_add_test(suite, "deliberate failure",
                                        deliberate_failure) == NULL) {
            CU_cleanup_registry();
            UT_exit();
            goto done;
        }
    }
    running = true;
    result = UT_run_tests() == UT_STATUS_OK ? 0 : 1;
    running = false;
    if (failed != 0U || executed == 0U)
        result = 1;
    goto done;
invalid:
    fputs("Invalid arguments or profile (use -h for usage)\n", stderr);
done:
    free(core_args);
    return result;
}
