#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
set -euo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd -- "$here"
if [[ ! -d ut-core ]]; then
    git clone -- https://github.com/rdkcentral/ut-core.git ut-core
    version=${UT_CORE_PROJECT_VERSION:-$(git -C ut-core tag --list '3.*' --sort=-v:refname | head -n 1)}
    [[ -n $version ]] || { echo 'No compatible ut-core 3.x tag found' >&2; exit 1; }
    git -C ut-core checkout "$version"
    (cd ut-core && bash ./build.sh)
fi
exec make -C "$here" "$@"
