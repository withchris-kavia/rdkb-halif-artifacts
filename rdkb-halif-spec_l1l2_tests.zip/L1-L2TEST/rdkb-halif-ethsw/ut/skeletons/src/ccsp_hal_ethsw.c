/* SPDX-License-Identifier: Apache-2.0
 * Serialized Linux reference model, NOT a switch driver.
 * Policies beyond the header are declared in config/ethsw_linux.yaml.
 */
#include "ethsw_test_fixture.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    CCSP_HAL_ETHSW_LINK_RATE rate;
    CCSP_HAL_ETHSW_DUPLEX_MODE duplex;
    CCSP_HAL_ETHSW_ADMIN_STATUS admin;
    int aging;
} port_state_t;
static port_state_t ports[8];
static bool initialized, fail_allocation;
static BOOLEAN wan_enabled;
static UINT wan_port;
static appCallBack wan_callbacks;
static CcspHalExtSw_ethAssociatedDevice_callback association_callback;

static bool valid_port(CCSP_HAL_ETHSW_PORT port)
{
    return initialized && ethsw_port_supported((int)port);
}

void ethsw_model_reset(void)
{
    for (unsigned int i = 0; i < 8; ++i) {
        ports[i].rate = ethsw_profile.initial_rate;
        ports[i].duplex = ethsw_profile.initial_duplex;
        ports[i].admin = ethsw_profile.initial_admin;
        ports[i].aging = ethsw_profile.aging_default;
    }
    wan_enabled = ethsw_profile.initial_wan_enable;
    wan_port = ETHWAN_DEF_INTF_NUM;
    memset(&wan_callbacks, 0, sizeof(wan_callbacks));
    association_callback = NULL;
    fail_allocation = false;
    initialized = true;
}

INT CcspHalEthSwInit(void)
{
    if (ethsw_profile.port_mask == 0 ||
        (unsigned int)ETHWAN_DEF_INTF_NUM >= ethsw_profile.wan_count)
        return RETURN_ERR;
    if (!initialized)
        ethsw_model_reset();
    return RETURN_OK;
}

INT CcspHalEthSwGetPortCfg(CCSP_HAL_ETHSW_PORT port,
                          PCCSP_HAL_ETHSW_LINK_RATE rate,
                          PCCSP_HAL_ETHSW_DUPLEX_MODE duplex)
{
    if (!valid_port(port) || rate == NULL || duplex == NULL)
        return RETURN_ERR;
    *rate = ports[(unsigned int)port - 1U].rate;
    *duplex = ports[(unsigned int)port - 1U].duplex;
    return RETURN_OK;
}

INT CcspHalEthSwGetPortStatus(CCSP_HAL_ETHSW_PORT port,
                             PCCSP_HAL_ETHSW_LINK_RATE rate,
                             PCCSP_HAL_ETHSW_DUPLEX_MODE duplex,
                             PCCSP_HAL_ETHSW_LINK_STATUS status)
{
    if (!valid_port(port) || rate == NULL || duplex == NULL || status == NULL)
        return RETURN_ERR;
    /* No PHY or traffic generator: configured values do not imply live link. */
    *rate = CCSP_HAL_ETHSW_LINK_NULL;
    *duplex = CCSP_HAL_ETHSW_DUPLEX_Auto;
    *status = CCSP_HAL_ETHSW_LINK_Disconnected;
    return RETURN_OK;
}

INT CcspHalEthSwSetPortCfg(CCSP_HAL_ETHSW_PORT port,
                          CCSP_HAL_ETHSW_LINK_RATE rate,
                          CCSP_HAL_ETHSW_DUPLEX_MODE duplex)
{
    if (!valid_port(port) || (int)rate < 0 ||
        rate > CCSP_HAL_ETHSW_LINK_Auto || (int)duplex < 0 ||
        duplex > CCSP_HAL_ETHSW_DUPLEX_Full ||
        (ethsw_profile.rate_mask & (1U << (unsigned int)rate)) == 0 ||
        (ethsw_profile.duplex_mask & (1U << (unsigned int)duplex)) == 0)
        return RETURN_ERR;
    ports[(unsigned int)port - 1U].rate = rate;
    ports[(unsigned int)port - 1U].duplex = duplex;
    return RETURN_OK;
}

INT CcspHalEthSwGetPortAdminStatus(CCSP_HAL_ETHSW_PORT port,
                                  PCCSP_HAL_ETHSW_ADMIN_STATUS status)
{
    if (!valid_port(port) || status == NULL)
        return RETURN_ERR;
    *status = ports[(unsigned int)port - 1U].admin;
    return RETURN_OK;
}

INT CcspHalEthSwSetPortAdminStatus(CCSP_HAL_ETHSW_PORT port,
                                  CCSP_HAL_ETHSW_ADMIN_STATUS status)
{
    if (!valid_port(port) || (int)status < 0 || status > CCSP_HAL_ETHSW_AdminTest)
        return RETURN_ERR;
    ports[(unsigned int)port - 1U].admin = status;
    return RETURN_OK;
}

INT CcspHalEthSwSetAgingSpeed(CCSP_HAL_ETHSW_PORT port, INT speed)
{
    if (!valid_port(port) || speed < ethsw_profile.aging_min ||
        speed > ethsw_profile.aging_max)
        return RETURN_ERR;
    ports[(unsigned int)port - 1U].aging = speed;
    return RETURN_OK;
}

int ethsw_model_aging(CCSP_HAL_ETHSW_PORT port)
{
    return valid_port(port) ? ports[(unsigned int)port - 1U].aging : RETURN_ERR;
}

INT CcspHalEthSwLocatePortByMacAddress(unsigned char *mac, INT *port)
{
    if (!initialized || mac == NULL || port == NULL)
        return RETURN_ERR;
    if (memcmp(mac, ethsw_profile.known_mac, 6) == 0)
        *port = ethsw_profile.lookup_port;
    else if (memcmp(mac, ethsw_profile.moca_mac, 6) == 0)
        *port = 0;
    else
        return RETURN_ERR;
    return RETURN_OK;
}

INT CcspHalEthSwGetEthPortStats(CCSP_HAL_ETHSW_PORT port,
                               PCCSP_HAL_ETH_STATS stats)
{
    if (!valid_port(port) || stats == NULL)
        return RETURN_ERR;
    /* All fifteen counters are zero: a legitimate no-traffic observation. */
    memset(stats, 0, sizeof(*stats));
    return RETURN_OK;
}

void ethsw_model_fail_allocation(bool fail)
{
    fail_allocation = fail;
}

INT CcspHalExtSw_getAssociatedDevice(ULONG *count, eth_device_t **devices)
{
    eth_device_t *snapshot;
    if (!initialized || count == NULL || devices == NULL)
        return RETURN_ERR;
    *count = 0;
    *devices = NULL;
    if (fail_allocation)
        return RETURN_ERR;
    snapshot = calloc(1, sizeof(*snapshot));
    if (snapshot == NULL)
        return RETURN_ERR;
    *snapshot = ethsw_profile.device;
    *devices = snapshot;
    *count = 1;
    return RETURN_OK;
}

void CcspHalExtSw_ethAssociatedDevice_callback_register(
    CcspHalExtSw_ethAssociatedDevice_callback callback)
{
    association_callback = callback;
}

void GWP_RegisterEthWan_Callback(appCallBack *callbacks)
{
    if (callbacks != NULL)
        wan_callbacks = *callbacks; /* Copy, do not retain caller's struct. */
}

void ethsw_model_events(void)
{
    eth_device_t device = ethsw_profile.device;
    /* Explicit synchronous test stimulus only, never a fabricated link change. */
    if (association_callback != NULL)
        (void)association_callback(&device);
    if (wan_callbacks.pGWP_act_EthWanLinkUP != NULL)
        wan_callbacks.pGWP_act_EthWanLinkUP();
    if (wan_callbacks.pGWP_act_EthWanLinkDown != NULL)
        wan_callbacks.pGWP_act_EthWanLinkDown();
}

INT CcspHalExtSw_getEthWanEnable(BOOLEAN *flag)
{
    if (!initialized || flag == NULL)
        return RETURN_ERR;
    *flag = wan_enabled;
    return RETURN_OK;
}

INT CcspHalExtSw_setEthWanEnable(BOOLEAN flag)
{
    if (!initialized || (flag != TRUE && flag != FALSE))
        return RETURN_ERR;
    wan_enabled = flag;
    return RETURN_OK;
}

INT CcspHalExtSw_getEthWanPort(UINT *port)
{
    if (!initialized || port == NULL)
        return RETURN_ERR;
    *port = wan_port;
    return RETURN_OK;
}

INT CcspHalExtSw_setEthWanPort(UINT port)
{
    if (!initialized || port >= ethsw_profile.wan_count)
        return RETURN_ERR;
    wan_port = port;
    return RETURN_OK;
}

#ifdef FEATURE_RDKB_AUTO_PORT_SWITCH
BOOLEAN CcspHalExtSw_getCurrentWanHWConf(void)
{
    return wan_enabled;
}
#endif

#if defined(FEATURE_RDKB_WAN_MANAGER) && defined(FEATURE_RDKB_AUTO_PORT_SWITCH)
int CcspHalExtSw_ethPortConfigure(char *ifname, BOOLEAN mode)
{
    char expected[64];
    if (!initialized || ifname == NULL || (mode != TRUE && mode != FALSE))
        return RETURN_ERR;
    for (UINT i = 0; i < ethsw_profile.wan_count; ++i) {
        (void)snprintf(expected, sizeof(expected), "%s%u",
                       ethsw_profile.interface_prefix, i);
        if (strcmp(ifname, expected) == 0) {
            wan_port = i;
            wan_enabled = mode;
            return RETURN_OK;
        }
    }
    return RETURN_ERR;
}
#endif

INT GWP_GetEthWanLinkStatus(void)
{
    if (!initialized) {
        errno = ENODEV;
        return RETURN_ERR;
    }
    return 0; /* No physical link is modeled, independent of WAN enable. */
}

INT GWP_GetEthWanInterfaceName(unsigned char *name, ULONG capacity)
{
    char result[64];
    int length;
    /* Conservative G05 policy; capacity is the actual caller allocation. */
    if (!initialized || name == NULL || capacity < 64 || capacity > 262)
        return RETURN_ERR;
    length = snprintf(result, sizeof(result), "%s%u",
                      ethsw_profile.interface_prefix, wan_port);
    if (length < 0 || (size_t)length >= sizeof(result) ||
        (ULONG)length >= capacity)
        return RETURN_ERR;
    memcpy(name, result, (size_t)length + 1U);
    return RETURN_OK;
}
