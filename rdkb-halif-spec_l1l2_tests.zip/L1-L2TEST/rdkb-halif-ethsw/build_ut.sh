#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Bootstrap the official component test repository; never reset an existing tree.
set -euo pipefail

root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
destination=$root
if [[ ${1:-} == -h || ${1:-} == --help ]]; then
    printf 'Usage: %s [--dir DIRECTORY] [make arguments, e.g. TARGET=linux]\n' "$0"
    exit 0
fi
if [[ ${1:-} == --dir ]]; then
    [[ $# -ge 2 && -n $2 ]] || { echo '--dir requires a directory' >&2; exit 1; }
    destination=$2
    shift 2
fi
if [[ ! -d $destination/ut ]]; then
    remote=$(git -C "$root" remote get-url origin)
    test_repo=${remote/halif/halif-test}
    test_repo=${test_repo/hal-/haltest-/}
    git clone -- "$test_repo" "$destination/ut"
    git -C "$destination/ut" checkout "${UT_PROJECT_VERSION:-main}"
fi
cd -- "$destination/ut"
exec bash ./build.sh "$@"
