#!/usr/bin/env bash
# Copyright 2023 RDK Management
# Licensed under the Apache License, Version 2.0.
# See http://www.apache.org/licenses/LICENSE-2.0

set -euo pipefail
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || exit 1
cd -- "$SCRIPT_DIR" || exit 1

if [[ ${1:-} == -h || ${1:-} == --help ]]; then
    printf '%s\n' 'Build the eMMC unit tests: build_ut.sh [clean] [TARGET=linux|arm] [make arguments...]'
    exit 0
fi

if [[ ! -d ut ]]; then
    remote=$(git remote get-url origin) || exit 1
    test_repo=${remote//halif/halif-test}
    test_repo=${test_repo//hal-/haltest-}
    git clone -- "$test_repo" ut || exit $?
    git -C ut checkout "${UT_PROJECT_VERSION:-main}" || exit $?
fi
cd -- "$SCRIPT_DIR/ut" || exit 1
exec ./build.sh "$@"
