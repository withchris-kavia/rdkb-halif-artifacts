/*
 * Copyright 2016 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include "emmc_test_helpers.h"

static void test_l1_ccsp_hal_emmc_positive1_CcspHalEmmcGetHealthInfo(void)
{
    emmc_guarded_health h = EMMC_GUARDED_INIT;
    emmc_reset_fixture();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h.value), RDK_STMGR_RETURN_SUCCESS);
    EMMC_CHECK_GUARDS(h);
    emmc_assert_healthy_health(&h.value);
}

static void test_l1_ccsp_hal_emmc_positive2_CcspHalEmmcGetHealthInfo(void)
{
    emmc_guarded_health h = EMMC_GUARDED_INIT;
    emmc_reset_fixture();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h.value), RDK_STMGR_RETURN_SUCCESS);
    EMMC_CHECK_GUARDS(h);
    /* Never call strcmp on an uninitialized or unterminated HAL output. */
    UT_ASSERT_FATAL(emmc_string_valid(h.value.m_deviceID, sizeof(h.value.m_deviceID)));
    UT_ASSERT(h.value.m_deviceID[0] != '\0');
    emmc_assert_healthy_health(&h.value);
}

static void test_l1_ccsp_hal_emmc_negative1_CcspHalEmmcGetHealthInfo(void)
{
    emmc_reset_fixture();
    UT_ASSERT_EQUAL(CcspHalEmmcGetHealthInfo(NULL), RDK_STMGR_RETURN_INVALID_INPUT);
}

static void test_l1_ccsp_hal_emmc_positive1_CcspHalEmmcGetDeviceInfo(void)
{
    emmc_guarded_device d = EMMC_GUARDED_INIT;
    emmc_reset_fixture();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d.value), RDK_STMGR_RETURN_SUCCESS);
    EMMC_CHECK_GUARDS(d);
    emmc_assert_healthy_device(&d.value);
}

static void test_l1_ccsp_hal_emmc_negative1_CcspHalEmmcGetDeviceInfo(void)
{
    emmc_reset_fixture();
    UT_ASSERT_EQUAL(CcspHalEmmcGetDeviceInfo(NULL), RDK_STMGR_RETURN_INVALID_INPUT);
}

/* PUBLIC_INTERFACE */
/** Register the five original API cases in L1, returning nonzero on any error. */
int test_emmc_hal_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID("[L1 ccsp_hal_emmc]",
                                                     NULL, NULL, UT_TESTS_L1);
    if (suite == NULL)
        return -1;
#define ADD(name) do { if (UT_add_test(suite, #name, test_##name) == NULL) return -1; } while (0)
    ADD(l1_ccsp_hal_emmc_positive1_CcspHalEmmcGetHealthInfo);
    ADD(l1_ccsp_hal_emmc_positive2_CcspHalEmmcGetHealthInfo);
    ADD(l1_ccsp_hal_emmc_negative1_CcspHalEmmcGetHealthInfo);
    ADD(l1_ccsp_hal_emmc_positive1_CcspHalEmmcGetDeviceInfo);
    ADD(l1_ccsp_hal_emmc_negative1_CcspHalEmmcGetDeviceInfo);
#undef ADD
    return 0;
}
