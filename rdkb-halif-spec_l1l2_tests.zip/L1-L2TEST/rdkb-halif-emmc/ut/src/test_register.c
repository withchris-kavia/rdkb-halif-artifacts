/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
extern int test_emmc_hal_l1_register(void);
extern int test_emmc_contract_types_register(void);
extern int test_emmc_hal_l2_register(void);

/* PUBLIC_INTERFACE */
/** Register API and declaration-only contract checks; return nonzero on error. */
int register_hal_l1_tests(void)
{
    int api_status = test_emmc_hal_l1_register();
    int type_status = test_emmc_contract_types_register();
    return api_status != 0 || type_status != 0;
}

/* PUBLIC_INTERFACE */
/** Register sequence tests; vendor builds exclude host-only controls. */
int register_hal_l2_tests(void)
{
    return test_emmc_hal_l2_register();
}
