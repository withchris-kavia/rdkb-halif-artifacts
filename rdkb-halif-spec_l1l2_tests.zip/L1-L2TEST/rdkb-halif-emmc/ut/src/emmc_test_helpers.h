#ifndef EMMC_TEST_HELPERS_H
#define EMMC_TEST_HELPERS_H

#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <ut.h>
#include "ccsp_hal_emmc.h"
#ifdef BUILD_LINUX
#include "emmc_test_control.h"
#endif

#define EMMC_CANARY UINT64_C(0x91a2b3c4d5e6f708)
#define EMMC_CHECK_U64(actual, expected) \
    UT_ASSERT((unsigned long long)(actual) == (unsigned long long)(expected))

typedef struct {
    uint64_t before;
    eSTMGRHealthInfo value;
    uint64_t after;
} emmc_guarded_health;

typedef struct {
    uint64_t before;
    eSTMGRDeviceInfo value;
    uint64_t after;
} emmc_guarded_device;

#define EMMC_GUARDED_INIT { .before = EMMC_CANARY, .after = EMMC_CANARY }
#define EMMC_CHECK_GUARDS(output) do { \
    UT_ASSERT((output).before == EMMC_CANARY); \
    UT_ASSERT((output).after == EMMC_CANARY); \
} while (0)

static inline int emmc_string_valid(const char *text, size_t size)
{
    return memchr(text, '\0', size) != NULL;
}

static inline int emmc_string_equal(const char *a, const char *b, size_t size)
{
    return emmc_string_valid(a, size) && emmc_string_valid(b, size) &&
           strncmp(a, b, size) == 0;
}

static inline int emmc_list_valid(const eSTMGRDiagAttributesList *list)
{
    if (list->m_numOfAttributes > RDK_STMGR_MAX_DIAGNOSTIC_ATTRIBUTES)
        return 0;
    for (unsigned int i = 0; i < list->m_numOfAttributes; ++i)
        if (!emmc_string_valid(list->m_diagnostics[i].m_name,
                               sizeof(list->m_diagnostics[i].m_name)) ||
            !emmc_string_valid(list->m_diagnostics[i].m_value,
                               sizeof(list->m_diagnostics[i].m_value)))
            return 0;
    return 1;
}

static inline int emmc_list_equal(const eSTMGRDiagAttributesList *a,
                                  const eSTMGRDiagAttributesList *b)
{
    if (!emmc_list_valid(a) || !emmc_list_valid(b) ||
        a->m_numOfAttributes != b->m_numOfAttributes)
        return 0;
    for (unsigned int i = 0; i < a->m_numOfAttributes; ++i)
        if (!emmc_string_equal(a->m_diagnostics[i].m_name,
                               b->m_diagnostics[i].m_name,
                               sizeof(a->m_diagnostics[i].m_name)) ||
            !emmc_string_equal(a->m_diagnostics[i].m_value,
                               b->m_diagnostics[i].m_value,
                               sizeof(a->m_diagnostics[i].m_value)))
            return 0;
    return 1;
}

static inline int emmc_health_valid(const eSTMGRHealthInfo *h)
{
    return emmc_string_valid(h->m_deviceID, sizeof(h->m_deviceID)) &&
           h->m_deviceType >= RDK_STMGR_DEVICE_TYPE_HDD &&
           h->m_deviceType < RDK_STMGR_DEVICE_TYPE_MAX &&
#ifdef BUILD_LINUX
           /* The public union is untagged. Only the host promises the list arm. */
           emmc_list_valid(&h->m_diagnostics.m_list) &&
#endif
           emmc_list_valid(&h->m_lifetimesList) &&
           emmc_list_valid(&h->m_firstExceededConfiguredLife) &&
           emmc_list_valid(&h->m_firstExceededMaxLife) &&
           emmc_list_valid(&h->m_healthStatesList);
}

static inline int emmc_device_valid(const eSTMGRDeviceInfo *d)
{
#define VALID(field) emmc_string_valid(d->field, sizeof(d->field))
    return VALID(m_deviceID) && VALID(m_partitions) && VALID(m_manufacturer) &&
           VALID(m_model) && VALID(m_serialNumber) && VALID(m_firmwareVersion) &&
           VALID(m_hwVersion) && VALID(m_ifATAstandard) &&
           d->m_type >= RDK_STMGR_DEVICE_TYPE_HDD &&
           d->m_type < RDK_STMGR_DEVICE_TYPE_MAX &&
           (((unsigned int)d->m_status & ~127U) == 0);
#undef VALID
}

static inline int emmc_health_equal(const eSTMGRHealthInfo *a,
                                    const eSTMGRHealthInfo *b)
{
    return emmc_string_equal(a->m_deviceID, b->m_deviceID, sizeof(a->m_deviceID)) &&
           a->m_deviceType == b->m_deviceType &&
           a->m_isOperational == b->m_isOperational &&
           a->m_isHealthy == b->m_isHealthy &&
#ifdef BUILD_LINUX
           emmc_list_equal(&a->m_diagnostics.m_list, &b->m_diagnostics.m_list) &&
#endif
           emmc_list_equal(&a->m_lifetimesList, &b->m_lifetimesList) &&
           emmc_list_equal(&a->m_firstExceededConfiguredLife, &b->m_firstExceededConfiguredLife) &&
           emmc_list_equal(&a->m_firstExceededMaxLife, &b->m_firstExceededMaxLife) &&
           emmc_list_equal(&a->m_healthStatesList, &b->m_healthStatesList);
}

static inline int emmc_device_equal(const eSTMGRDeviceInfo *a,
                                    const eSTMGRDeviceInfo *b)
{
#define SAME(field) emmc_string_equal(a->field, b->field, sizeof(a->field))
    return SAME(m_deviceID) && SAME(m_partitions) && SAME(m_manufacturer) &&
           SAME(m_model) && SAME(m_serialNumber) && SAME(m_firmwareVersion) &&
           SAME(m_hwVersion) && SAME(m_ifATAstandard) &&
           a->m_type == b->m_type && a->m_capacity == b->m_capacity &&
           a->m_status == b->m_status && a->m_hasSMARTSupport == b->m_hasSMARTSupport;
#undef SAME
}

static inline void emmc_reset_fixture(void)
{
#ifdef BUILD_LINUX
    emmc_test_reset();
#endif
}

static inline void emmc_assert_attribute(const eSTMGRDiagAttributesList *list,
                                         const char *name, const char *value)
{
    UT_ASSERT_FATAL(emmc_list_valid(list));
    UT_ASSERT_EQUAL_FATAL(list->m_numOfAttributes, 1);
    UT_ASSERT(emmc_string_equal(list->m_diagnostics[0].m_name, name,
                                sizeof(list->m_diagnostics[0].m_name)));
    UT_ASSERT(emmc_string_equal(list->m_diagnostics[0].m_value, value,
                                sizeof(list->m_diagnostics[0].m_value)));
}

static inline void emmc_assert_healthy_health(const eSTMGRHealthInfo *h)
{
    UT_ASSERT_FATAL(emmc_health_valid(h));
#ifdef BUILD_LINUX
    UT_ASSERT_STRING_EQUAL(h->m_deviceID, "host-emmc-0");
    UT_ASSERT_EQUAL(h->m_deviceType, RDK_STMGR_DEVICE_TYPE_EMMCCARD);
    UT_ASSERT(h->m_isOperational);
    UT_ASSERT(h->m_isHealthy);
    emmc_assert_attribute(&h->m_diagnostics.m_list, "pre_eol", "normal");
    emmc_assert_attribute(&h->m_lifetimesList, "life_used", "10");
    UT_ASSERT_EQUAL(h->m_firstExceededConfiguredLife.m_numOfAttributes, 0);
    UT_ASSERT_EQUAL(h->m_firstExceededMaxLife.m_numOfAttributes, 0);
    emmc_assert_attribute(&h->m_healthStatesList, "state", "healthy");
#endif
}

static inline void emmc_assert_healthy_device(const eSTMGRDeviceInfo *d)
{
    UT_ASSERT_FATAL(emmc_device_valid(d));
#ifdef BUILD_LINUX
    UT_ASSERT_STRING_EQUAL(d->m_deviceID, "host-emmc-0");
    UT_ASSERT_EQUAL(d->m_type, RDK_STMGR_DEVICE_TYPE_EMMCCARD);
    EMMC_CHECK_U64(d->m_capacity, 64ULL * 1024ULL * 1024ULL * 1024ULL);
    UT_ASSERT_EQUAL(d->m_status, RDK_STMGR_DEVICE_STATUS_OK);
    UT_ASSERT_STRING_EQUAL(d->m_partitions, "host-boot,host-data");
    UT_ASSERT_STRING_EQUAL(d->m_manufacturer, "Host Reference");
    UT_ASSERT_STRING_EQUAL(d->m_model, "Deterministic eMMC");
    UT_ASSERT_STRING_EQUAL(d->m_serialNumber, "HOST0001");
    UT_ASSERT_STRING_EQUAL(d->m_firmwareVersion, "1.0");
    UT_ASSERT_STRING_EQUAL(d->m_hwVersion, "host-v1");
    UT_ASSERT_STRING_EQUAL(d->m_ifATAstandard, "host-emmc");
    UT_ASSERT(d->m_hasSMARTSupport);
#endif
}

#endif
