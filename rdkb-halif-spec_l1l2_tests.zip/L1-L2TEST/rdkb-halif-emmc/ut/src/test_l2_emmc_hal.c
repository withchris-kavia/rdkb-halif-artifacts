/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <limits.h>
#include "emmc_test_helpers.h"

static void test_independent_entry_points(void)
{
    eSTMGRHealthInfo h = {0};
    eSTMGRDeviceInfo d = {0};
    emmc_reset_fixture();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h), RDK_STMGR_RETURN_SUCCESS);
    emmc_assert_healthy_health(&h);
    emmc_reset_fixture();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d), RDK_STMGR_RETURN_SUCCESS);
    emmc_assert_healthy_device(&d);
}

static void test_stable_fixture_repeatability(void)
{
    eSTMGRHealthInfo first_h = {0}, h = {0};
    eSTMGRDeviceInfo first_d = {0}, d = {0};
    emmc_reset_fixture();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&first_h), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&first_d), RDK_STMGR_RETURN_SUCCESS);
    for (unsigned int i = 0; i < 8; ++i)
    {
        UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d), RDK_STMGR_RETURN_SUCCESS);
        UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h), RDK_STMGR_RETURN_SUCCESS);
        UT_ASSERT(emmc_health_equal(&h, &first_h));
        UT_ASSERT(emmc_device_equal(&d, &first_d));
    }
}

static void test_cross_getter_consistency(void)
{
    eSTMGRHealthInfo h = {0};
    eSTMGRDeviceInfo d = {0};
    emmc_reset_fixture();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT_FATAL(emmc_health_valid(&h) && emmc_device_valid(&d));
    UT_ASSERT(emmc_string_equal(h.m_deviceID, d.m_deviceID, sizeof(h.m_deviceID)));
    UT_ASSERT_EQUAL(h.m_deviceType, d.m_type);
#ifdef BUILD_LINUX
    UT_ASSERT(h.m_isOperational == (d.m_status != RDK_STMGR_DEVICE_STATUS_NOT_PRESENT));
    UT_ASSERT(h.m_isHealthy == (d.m_status == RDK_STMGR_DEVICE_STATUS_OK));
#endif
}

static void test_caller_storage_isolation(void)
{
    eSTMGRHealthInfo h = {0}, expected_h = {0};
    eSTMGRDeviceInfo d = {0}, expected_d = {0};
    emmc_reset_fixture();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&expected_h), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&expected_d), RDK_STMGR_RETURN_SUCCESS);
    h = expected_h;
    d = expected_d;
    /* Wipe every field in caller storage, then read back into independent objects. */
    memset(&h, 0, sizeof(h));
    memset(&d, 0, sizeof(d));
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT(emmc_health_equal(&h, &expected_h));
    UT_ASSERT(emmc_device_equal(&d, &expected_d));
}

static void test_snapshot_retention(void)
{
    eSTMGRHealthInfo h = {0}, saved_h = {0}, current_h = {0};
    eSTMGRDeviceInfo d = {0}, saved_d = {0}, current_d = {0};
    emmc_reset_fixture();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d), RDK_STMGR_RETURN_SUCCESS);
    saved_h = h;
    saved_d = d;
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL_FATAL(emmc_test_set_state(EMMC_TEST_DEGRADED), 0);
#endif
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&current_h), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&current_d), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT(emmc_health_equal(&h, &saved_h));
    UT_ASSERT(emmc_device_equal(&d, &saved_d));
#ifdef BUILD_LINUX
    UT_ASSERT(!emmc_health_equal(&h, &current_h));
    UT_ASSERT(!emmc_device_equal(&d, &current_d));
#endif
}

static void test_null_recovery(void)
{
    emmc_guarded_health h = EMMC_GUARDED_INIT;
    emmc_guarded_device d = EMMC_GUARDED_INIT;
    emmc_reset_fixture();
    for (unsigned int i = 0; i < 3; ++i)
    {
        UT_ASSERT_EQUAL(CcspHalEmmcGetHealthInfo(NULL), RDK_STMGR_RETURN_INVALID_INPUT);
        UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d.value), RDK_STMGR_RETURN_SUCCESS);
        UT_ASSERT_EQUAL(CcspHalEmmcGetDeviceInfo(NULL), RDK_STMGR_RETURN_INVALID_INPUT);
        UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h.value), RDK_STMGR_RETURN_SUCCESS);
        emmc_assert_healthy_health(&h.value);
        emmc_assert_healthy_device(&d.value);
        EMMC_CHECK_GUARDS(h);
        EMMC_CHECK_GUARDS(d);
    }
}

#ifdef BUILD_LINUX
/* Scenarios 7-9 require host controls and make no vendor hardware promises. */
static void test_controlled_failure_recovery(void)
{
    const eSTMGRReturns errors[] = {
        RDK_STMGR_RETURN_GENERIC_FAILURE, RDK_STMGR_RETURN_INIT_FAILURE,
        RDK_STMGR_RETURN_INVALID_INPUT, RDK_STMGR_RETURN_UNKNOWN_FAILURE
    };
    emmc_guarded_health h = EMMC_GUARDED_INIT;
    emmc_guarded_device d = EMMC_GUARDED_INIT;
    eSTMGRHealthInfo saved_h = {0};
    eSTMGRDeviceInfo saved_d = {0};
    emmc_test_reset();
    strcpy(h.value.m_deviceID, "caller-health");
    strcpy(d.value.m_deviceID, "caller-device");
    d.value.m_capacity = 1ULL << 40;
    saved_h = h.value;
    saved_d = d.value;
    for (unsigned int i = 0; i < sizeof(errors) / sizeof(errors[0]); ++i)
    {
        eSTMGRHealthInfo good_h = {0};
        eSTMGRDeviceInfo good_d = {0};
        UT_ASSERT_EQUAL_FATAL(emmc_test_set_fault(EMMC_TEST_HEALTH_GETTER, errors[i]), 0);
        for (unsigned int repeat = 0; repeat < 2; ++repeat)
        {
            UT_ASSERT_EQUAL(CcspHalEmmcGetHealthInfo(&h.value), errors[i]);
            UT_ASSERT(emmc_health_equal(&h.value, &saved_h));
            UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&good_d), RDK_STMGR_RETURN_SUCCESS);
            emmc_assert_healthy_device(&good_d);
        }
        UT_ASSERT_EQUAL(CcspHalEmmcGetHealthInfo(NULL), RDK_STMGR_RETURN_INVALID_INPUT);
        UT_ASSERT_EQUAL_FATAL(emmc_test_set_fault(EMMC_TEST_HEALTH_GETTER, RDK_STMGR_RETURN_SUCCESS), 0);
        UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&good_h), RDK_STMGR_RETURN_SUCCESS);
        emmc_assert_healthy_health(&good_h);

        UT_ASSERT_EQUAL_FATAL(emmc_test_set_fault(EMMC_TEST_DEVICE_GETTER, errors[i]), 0);
        for (unsigned int repeat = 0; repeat < 2; ++repeat)
        {
            UT_ASSERT_EQUAL(CcspHalEmmcGetDeviceInfo(&d.value), errors[i]);
            UT_ASSERT(emmc_device_equal(&d.value, &saved_d));
            UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&good_h), RDK_STMGR_RETURN_SUCCESS);
            emmc_assert_healthy_health(&good_h);
        }
        UT_ASSERT_EQUAL(CcspHalEmmcGetDeviceInfo(NULL), RDK_STMGR_RETURN_INVALID_INPUT);
        UT_ASSERT_EQUAL_FATAL(emmc_test_set_fault(EMMC_TEST_DEVICE_GETTER, RDK_STMGR_RETURN_SUCCESS), 0);
        UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&good_d), RDK_STMGR_RETURN_SUCCESS);
        emmc_assert_healthy_device(&good_d);
        EMMC_CHECK_GUARDS(h);
        EMMC_CHECK_GUARDS(d);
    }
    UT_ASSERT_EQUAL(emmc_test_set_fault((emmc_test_getter)99, RDK_STMGR_RETURN_SUCCESS), -1);
    UT_ASSERT_EQUAL(emmc_test_set_fault(EMMC_TEST_HEALTH_GETTER, (eSTMGRReturns)99), -1);
    UT_ASSERT_EQUAL_FATAL(emmc_test_set_fault(EMMC_TEST_HEALTH_GETTER, RDK_STMGR_RETURN_INIT_FAILURE), 0);
    UT_ASSERT_EQUAL_FATAL(emmc_test_set_fault(EMMC_TEST_DEVICE_GETTER, RDK_STMGR_RETURN_UNKNOWN_FAILURE), 0);
    emmc_test_reset();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h.value), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d.value), RDK_STMGR_RETURN_SUCCESS);
    emmc_assert_healthy_health(&h.value);
    emmc_assert_healthy_device(&d.value);
}

static void test_host_state_changes(void)
{
    const emmc_test_state states[] = {
        EMMC_TEST_HEALTHY, EMMC_TEST_DEGRADED, EMMC_TEST_UNAVAILABLE, EMMC_TEST_HEALTHY
    };
    const eSTMGRDeviceStatus statuses[] = {
        RDK_STMGR_DEVICE_STATUS_OK, RDK_STMGR_DEVICE_STATUS_READ_ONLY,
        RDK_STMGR_DEVICE_STATUS_NOT_PRESENT, RDK_STMGR_DEVICE_STATUS_OK
    };
    const char *const labels[] = {"healthy", "degraded", "unavailable", "healthy"};
    emmc_test_reset();
    for (unsigned int i = 0; i < sizeof(states) / sizeof(states[0]); ++i)
    {
        emmc_guarded_health h = EMMC_GUARDED_INIT;
        emmc_guarded_device d = EMMC_GUARDED_INIT;
        UT_ASSERT_EQUAL_FATAL(emmc_test_set_state(states[i]), 0);
        UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h.value), RDK_STMGR_RETURN_SUCCESS);
        UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d.value), RDK_STMGR_RETURN_SUCCESS);
        UT_ASSERT_FATAL(emmc_health_valid(&h.value) && emmc_device_valid(&d.value));
        UT_ASSERT_EQUAL(d.value.m_status, statuses[i]);
        UT_ASSERT(h.value.m_isOperational == (states[i] != EMMC_TEST_UNAVAILABLE));
        UT_ASSERT(h.value.m_isHealthy == (states[i] == EMMC_TEST_HEALTHY));
        UT_ASSERT(emmc_string_equal(h.value.m_deviceID, d.value.m_deviceID,
                                    sizeof(h.value.m_deviceID)));
        UT_ASSERT_EQUAL(h.value.m_deviceType, d.value.m_type);
        emmc_assert_attribute(&h.value.m_healthStatesList, "state", labels[i]);
        if (states[i] == EMMC_TEST_DEGRADED)
        {
            emmc_assert_attribute(&h.value.m_diagnostics.m_list, "pre_eol", "warning");
            emmc_assert_attribute(&h.value.m_lifetimesList, "life_used", "95");
            emmc_assert_attribute(&h.value.m_firstExceededConfiguredLife, "threshold", "90");
        }
        UT_ASSERT_EQUAL(h.value.m_firstExceededMaxLife.m_numOfAttributes, 0);
        EMMC_CHECK_GUARDS(h);
        EMMC_CHECK_GUARDS(d);
    }
    UT_ASSERT_EQUAL(emmc_test_set_state((emmc_test_state)99), -1);
}

static void assert_boundary_string(const char *text, size_t size, bool maximum, char value)
{
    UT_ASSERT_FATAL(emmc_string_valid(text, size));
    UT_ASSERT(text[size - 1] == '\0');
    for (size_t i = 0; i + 1 < size; ++i)
        UT_ASSERT(text[i] == (maximum ? value : '\0'));
}

static void assert_boundary_list(const eSTMGRDiagAttributesList *list, bool maximum)
{
    UT_ASSERT_FATAL(emmc_list_valid(list));
    UT_ASSERT_EQUAL(list->m_numOfAttributes, maximum ? 20 : 0);
    /* Empty fixtures clear even inactive entries, not just their count. */
    for (unsigned int i = 0; i < RDK_STMGR_MAX_DIAGNOSTIC_ATTRIBUTES; ++i)
    {
        assert_boundary_string(list->m_diagnostics[i].m_name,
                               sizeof(list->m_diagnostics[i].m_name), maximum, 'A' + i);
        assert_boundary_string(list->m_diagnostics[i].m_value,
                               sizeof(list->m_diagnostics[i].m_value), maximum, 'a' + i);
    }
}

static void assert_boundary(const eSTMGRHealthInfo *h, const eSTMGRDeviceInfo *d,
                            bool maximum)
{
    UT_ASSERT_FATAL(emmc_health_valid(h) && emmc_device_valid(d));
#define STRING(field, value) assert_boundary_string(d->field, sizeof(d->field), maximum, value)
    STRING(m_deviceID, 'I');
    STRING(m_partitions, 'P');
    STRING(m_manufacturer, 'M');
    STRING(m_model, 'D');
    STRING(m_serialNumber, 'S');
    STRING(m_firmwareVersion, 'F');
    STRING(m_hwVersion, 'H');
    STRING(m_ifATAstandard, 'T');
#undef STRING
    assert_boundary_string(h->m_deviceID, sizeof(h->m_deviceID), maximum, 'I');
    assert_boundary_list(&h->m_diagnostics.m_list, maximum);
    assert_boundary_list(&h->m_lifetimesList, maximum);
    assert_boundary_list(&h->m_firstExceededConfiguredLife, maximum);
    assert_boundary_list(&h->m_firstExceededMaxLife, maximum);
    assert_boundary_list(&h->m_healthStatesList, maximum);
    EMMC_CHECK_U64(d->m_capacity, maximum ? ULLONG_MAX : 0);
    UT_ASSERT(d->m_hasSMARTSupport == maximum);
    UT_ASSERT_EQUAL(d->m_type, RDK_STMGR_DEVICE_TYPE_EMMCCARD);
    UT_ASSERT_EQUAL(h->m_deviceType, d->m_type);
    UT_ASSERT_EQUAL(d->m_status, RDK_STMGR_DEVICE_STATUS_OK);
    UT_ASSERT(h->m_isOperational && h->m_isHealthy);
}

static void test_boundary_isolation(void)
{
    emmc_guarded_health h = EMMC_GUARDED_INIT;
    emmc_guarded_device d = EMMC_GUARDED_INIT;
    eSTMGRHealthInfo saved_h = {0};
    eSTMGRDeviceInfo saved_d = {0};
    emmc_test_reset();
    /* Reuse the same buffers maximum -> zero -> maximum to detect stale tails. */
    for (unsigned int i = 0; i < 3; ++i)
    {
        bool maximum = i != 1;
        emmc_test_set_boundary(maximum);
        UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h.value), RDK_STMGR_RETURN_SUCCESS);
        UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d.value), RDK_STMGR_RETURN_SUCCESS);
        assert_boundary(&h.value, &d.value, maximum);
        EMMC_CHECK_GUARDS(h);
        EMMC_CHECK_GUARDS(d);
        if (i == 0)
        {
            saved_h = h.value;
            saved_d = d.value;
        }
        else
            assert_boundary(&saved_h, &saved_d, true);
    }
    emmc_test_reset();
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetHealthInfo(&h.value), RDK_STMGR_RETURN_SUCCESS);
    UT_ASSERT_EQUAL_FATAL(CcspHalEmmcGetDeviceInfo(&d.value), RDK_STMGR_RETURN_SUCCESS);
    emmc_assert_healthy_health(&h.value);
    emmc_assert_healthy_device(&d.value);
    EMMC_CHECK_GUARDS(h);
    EMMC_CHECK_GUARDS(d);
}
#endif

/* PUBLIC_INTERFACE */
/** Register six common sequences and, on Linux, three model-only scenarios. */
int test_emmc_hal_l2_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID("[L2 eMMC sequences]",
                                                     NULL, NULL, UT_TESTS_L2);
    if (suite == NULL)
        return -1;
#define ADD(name) do { if (UT_add_test(suite, #name, test_##name) == NULL) return -1; } while (0)
    ADD(independent_entry_points);
    ADD(stable_fixture_repeatability);
    ADD(cross_getter_consistency);
    ADD(caller_storage_isolation);
    ADD(snapshot_retention);
    ADD(null_recovery);
#ifdef BUILD_LINUX
    ADD(controlled_failure_recovery);
    ADD(host_state_changes);
    ADD(boundary_isolation);
#endif
#undef ADD
    return 0;
}
