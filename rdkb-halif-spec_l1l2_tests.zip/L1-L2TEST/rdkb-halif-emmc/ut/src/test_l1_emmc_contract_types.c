/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <limits.h>
#include "emmc_test_helpers.h"

#define CONTRACT_VALUES(X) \
    X(RDK_STMGR_RETURN_SUCCESS, 0) \
    X(RDK_STMGR_RETURN_GENERIC_FAILURE, -1) \
    X(RDK_STMGR_RETURN_INIT_FAILURE, -2) \
    X(RDK_STMGR_RETURN_INVALID_INPUT, -3) \
    X(RDK_STMGR_RETURN_UNKNOWN_FAILURE, -4) \
    X(RDK_STMGR_DEVICE_TYPE_HDD, 0) \
    X(RDK_STMGR_DEVICE_TYPE_SDCARD, 1) \
    X(RDK_STMGR_DEVICE_TYPE_USB, 2) \
    X(RDK_STMGR_DEVICE_TYPE_FLASH, 3) \
    X(RDK_STMGR_DEVICE_TYPE_NVRAM, 4) \
    X(RDK_STMGR_DEVICE_TYPE_EMMCCARD, 5) \
    X(RDK_STMGR_DEVICE_TYPE_MAX, 6) \
    X(RDK_STMGR_DEVICE_STATUS_OK, 0) \
    X(RDK_STMGR_DEVICE_STATUS_READ_ONLY, 1) \
    X(RDK_STMGR_DEVICE_STATUS_NOT_PRESENT, 2) \
    X(RDK_STMGR_DEVICE_STATUS_NOT_QUALIFIED, 4) \
    X(RDK_STMGR_DEVICE_STATUS_DISK_FULL, 8) \
    X(RDK_STMGR_DEVICE_STATUS_READ_FAILURE, 16) \
    X(RDK_STMGR_DEVICE_STATUS_WRITE_FAILURE, 32) \
    X(RDK_STMGR_DEVICE_STATUS_UNKNOWN, 64) \
    X(RDK_STMGR_EVENT_STATUS_CHANGED, 100) \
    X(RDK_STMGR_EVENT_HEALTH_WARNING, 101) \
    X(RDK_STMGR_EVENT_DEVICE_FAILURE, 102) \
    X(RDK_STMGR_MAX_DEVICES, 10) \
    X(RDK_STMGR_MAX_STRING_LENGTH, 128) \
    X(RDK_STMGR_PARTITION_LENGTH, 256) \
    X(RDK_STMGR_DIAGNOSTICS_LENGTH, 256) \
    X(RDK_STMGR_DIAGNOSTICS_BLOB_LENGTH, 2048) \
    X(RDK_STMGR_MAX_DIAGNOSTIC_ATTRIBUTES, 20)

#define STATIC_VALUE(name, value) _Static_assert((name) == (value), #name);
CONTRACT_VALUES(STATIC_VALUE)
#undef STATIC_VALUE

#define EXTENT(type, field, count) \
    _Static_assert(sizeof(((type *)0)->field) / sizeof(((type *)0)->field[0]) == (count), \
                   #type "." #field)
EXTENT(eSTMGRDeviceIDs, m_deviceIDs, RDK_STMGR_MAX_DEVICES);
_Static_assert(sizeof(((eSTMGRDeviceIDs *)0)->m_deviceIDs[0]) ==
               RDK_STMGR_MAX_STRING_LENGTH, "device ID row");
EXTENT(eSTMGRDeviceInfoList, m_devices, RDK_STMGR_MAX_DEVICES);
EXTENT(eSTMGRDeviceInfo, m_deviceID, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRDeviceInfo, m_partitions, RDK_STMGR_PARTITION_LENGTH);
EXTENT(eSTMGRDeviceInfo, m_manufacturer, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRDeviceInfo, m_model, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRDeviceInfo, m_serialNumber, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRDeviceInfo, m_firmwareVersion, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRDeviceInfo, m_hwVersion, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRDeviceInfo, m_ifATAstandard, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRPartitionInfo, m_partitionId, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRPartitionInfo, m_name, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRPartitionInfo, m_mountPath, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRPartitionInfo, m_format, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRDiagAttributes, m_name, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRDiagAttributes, m_value, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRDiagAttributesList, m_diagnostics, RDK_STMGR_MAX_DIAGNOSTIC_ATTRIBUTES);
EXTENT(eSTMGRHealthInfo, m_deviceID, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGRHealthInfo, m_diagnostics.m_blob, RDK_STMGR_DIAGNOSTICS_BLOB_LENGTH);
EXTENT(eSTMGREventMessage, m_deviceID, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGREventMessage, m_description, RDK_STMGR_MAX_STRING_LENGTH);
EXTENT(eSTMGREventMessage, m_diagnostics, RDK_STMGR_DIAGNOSTICS_LENGTH);
EXTENT(eSTMGRCallBackData, mountPath, 200);
#undef EXTENT

_Static_assert(sizeof(((eSTMGRHealthInfo *)0)->m_diagnostics) >=
               sizeof(eSTMGRDiagAttributesList), "union must hold list");
_Static_assert(sizeof(((eSTMGRHealthInfo *)0)->m_diagnostics) >=
               RDK_STMGR_DIAGNOSTICS_BLOB_LENGTH, "union must hold blob");
_Static_assert(sizeof(((eSTMGRDeviceInfo *)0)->m_capacity) * CHAR_BIT >= 64,
               "device capacity width");
_Static_assert(sizeof(((eSTMGRPartitionInfo *)0)->m_capacity) * CHAR_BIT >= 64,
               "partition capacity width");
_Static_assert(sizeof(((eSTMGRPartitionInfo *)0)->m_freeSpace) * CHAR_BIT >= 64,
               "free space width");

static void test_contract_values(void)
{
#define RUNTIME_VALUE(name, value) UT_ASSERT_EQUAL(name, value);
    CONTRACT_VALUES(RUNTIME_VALUE)
#undef RUNTIME_VALUE
    eSTMGRReturns returns = RDK_STMGR_RETURN_UNKNOWN_FAILURE;
    eSTMGRDeviceType type = RDK_STMGR_DEVICE_TYPE_EMMCCARD;
    eSTMGRDeviceStatus status = RDK_STMGR_DEVICE_STATUS_WRITE_FAILURE;
    eSTMGREvents event = RDK_STMGR_EVENT_DEVICE_FAILURE;
    UT_ASSERT_EQUAL(returns, -4);
    UT_ASSERT_EQUAL(type, 5);
    UT_ASSERT_EQUAL(status, 32);
    UT_ASSERT_EQUAL(event, 102);
}

static void test_declaration_only_types(void)
{
    eSTMGRDeviceIDs ids = {0};
    eSTMGRDeviceInfoList devices = {0};
    eSTMGRPartitionInfo partition = {0};
    eSTMGREventMessage event = {0};
    eSTMGRCallBackData callback = {0};
    eSTMGRHealthInfo health = {0};

    ids.m_numOfDevices = RDK_STMGR_MAX_DEVICES;
    strcpy(ids.m_deviceIDs[9], "last-id");
    devices.m_numOfDevices = ids.m_numOfDevices;
    strcpy(devices.m_devices[9].m_deviceID, ids.m_deviceIDs[9]);
    devices.m_devices[9].m_type = RDK_STMGR_DEVICE_TYPE_EMMCCARD;
    devices.m_devices[9].m_capacity = ULLONG_MAX;
    UT_ASSERT_EQUAL(devices.m_numOfDevices, 10);
    UT_ASSERT_STRING_EQUAL(devices.m_devices[9].m_deviceID, "last-id");
    UT_ASSERT_EQUAL(devices.m_devices[9].m_type, RDK_STMGR_DEVICE_TYPE_EMMCCARD);
    EMMC_CHECK_U64(devices.m_devices[9].m_capacity, ULLONG_MAX);

    strcpy(partition.m_partitionId, "p0");
    strcpy(partition.m_name, "data");
    strcpy(partition.m_mountPath, "/host/data");
    strcpy(partition.m_format, "hostfs");
    partition.m_status = RDK_STMGR_DEVICE_STATUS_READ_ONLY;
    partition.m_capacity = ULLONG_MAX;
    partition.m_freeSpace = 1ULL << 40;
    partition.m_isTSBSupported = true;
    partition.m_isDVRSupported = true;
    UT_ASSERT_STRING_EQUAL(partition.m_partitionId, "p0");
    UT_ASSERT_STRING_EQUAL(partition.m_name, "data");
    UT_ASSERT_STRING_EQUAL(partition.m_mountPath, "/host/data");
    UT_ASSERT_STRING_EQUAL(partition.m_format, "hostfs");
    UT_ASSERT_EQUAL(partition.m_status, RDK_STMGR_DEVICE_STATUS_READ_ONLY);
    EMMC_CHECK_U64(partition.m_capacity, ULLONG_MAX);
    EMMC_CHECK_U64(partition.m_freeSpace, 1ULL << 40);
    UT_ASSERT(partition.m_isTSBSupported && partition.m_isDVRSupported);

    event.m_eventType = RDK_STMGR_EVENT_HEALTH_WARNING;
    strcpy(event.m_deviceID, "last-id");
    event.m_deviceType = RDK_STMGR_DEVICE_TYPE_EMMCCARD;
    event.m_deviceStatus = RDK_STMGR_DEVICE_STATUS_READ_ONLY;
    strcpy(event.m_description, "host declaration check");
    strcpy(event.m_diagnostics, "warning");
    callback.isSDCard = true;
    strcpy(callback.mountPath, "/host/card");
    UT_ASSERT_EQUAL(event.m_eventType, 101);
    UT_ASSERT_STRING_EQUAL(event.m_deviceID, "last-id");
    UT_ASSERT_EQUAL(event.m_deviceType, 5);
    UT_ASSERT_EQUAL(event.m_deviceStatus, 1);
    UT_ASSERT_STRING_EQUAL(event.m_description, "host declaration check");
    UT_ASSERT_STRING_EQUAL(event.m_diagnostics, "warning");
    UT_ASSERT(callback.isSDCard);
    UT_ASSERT_STRING_EQUAL(callback.mountPath, "/host/card");

    /* Exercise both union arms separately, never infer a public discriminator. */
    health.m_diagnostics.m_blob[RDK_STMGR_DIAGNOSTICS_BLOB_LENGTH - 1] = 'B';
    UT_ASSERT_EQUAL(health.m_diagnostics.m_blob[2047], 'B');
    memset(&health.m_diagnostics, 0, sizeof(health.m_diagnostics));
    health.m_diagnostics.m_list.m_numOfAttributes = 20;
    strcpy(health.m_diagnostics.m_list.m_diagnostics[19].m_name, "last");
    strcpy(health.m_diagnostics.m_list.m_diagnostics[19].m_value, "value");
    UT_ASSERT(emmc_list_valid(&health.m_diagnostics.m_list));
    UT_ASSERT_STRING_EQUAL(health.m_diagnostics.m_list.m_diagnostics[19].m_name, "last");
    UT_ASSERT_STRING_EQUAL(health.m_diagnostics.m_list.m_diagnostics[19].m_value, "value");
}

static void test_bounded_helpers_and_capacity(void)
{
    eSTMGRDeviceInfo a = {0}, b = {0};
    eSTMGRDiagAttributesList list = {0};
    char unterminated[128];
    memset(unterminated, 'X', sizeof(unterminated));
    UT_ASSERT(!emmc_string_valid(unterminated, sizeof(unterminated)));
    UT_ASSERT(!emmc_string_equal(unterminated, unterminated, sizeof(unterminated)));
    UT_ASSERT(emmc_list_valid(&list));
    list.m_numOfAttributes = RDK_STMGR_MAX_DIAGNOSTIC_ATTRIBUTES + 1;
    UT_ASSERT(!emmc_list_valid(&list));
    list.m_numOfAttributes = 1;
    memset(list.m_diagnostics[0].m_name, 'X', sizeof(list.m_diagnostics[0].m_name));
    UT_ASSERT(!emmc_list_valid(&list));
    a.m_capacity = 1ULL << 40;
    b.m_capacity = a.m_capacity;
    EMMC_CHECK_U64(a.m_capacity, 1ULL << 40);
    UT_ASSERT(emmc_device_equal(&a, &b));
    b.m_capacity ^= 1ULL << 32;
    UT_ASSERT(!emmc_device_equal(&a, &b));
}

/* PUBLIC_INTERFACE */
/** Register contract/type checks without requiring any Linux model symbols. */
int test_emmc_contract_types_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID("[L1 eMMC contract types]",
                                                     NULL, NULL, UT_TESTS_L1);
    if (suite == NULL)
        return -1;
    if (UT_add_test(suite, "contract_values", test_contract_values) == NULL ||
        UT_add_test(suite, "declaration_only_types", test_declaration_only_types) == NULL ||
        UT_add_test(suite, "bounded_helpers_and_capacity", test_bounded_helpers_and_capacity) == NULL)
        return -1;
    return 0;
}
