#!/usr/bin/env bash
# Copyright 2023 RDK Management
# Licensed under the Apache License, Version 2.0.
# See http://www.apache.org/licenses/LICENSE-2.0

set -euo pipefail
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || exit 1
cd -- "$SCRIPT_DIR" || exit 1

if [[ ! -d ut-core ]]; then
    git clone -- https://github.com/rdkcentral/ut-core.git ut-core || exit $?
    if [[ -z ${UT_CORE_PROJECT_VERSION:-} ]]; then
        UT_CORE_PROJECT_VERSION=$(git -C ut-core tag --list '3.*' --sort=-version:refname | head -n 1)
    fi
    if [[ -z ${UT_CORE_PROJECT_VERSION:-} ]]; then
        printf '%s\n' 'No compatible ut-core 3.x version found' >&2
        exit 1
    fi
    git -C ut-core checkout "$UT_CORE_PROJECT_VERSION" || exit $?
fi
# Dependencies are read-only. The Makefile diagnoses missing prebootstrapped
# headers/libraries rather than running upstream rules that mutate ut-core.
exec make -C "$SCRIPT_DIR" -f Makefile "$@"
