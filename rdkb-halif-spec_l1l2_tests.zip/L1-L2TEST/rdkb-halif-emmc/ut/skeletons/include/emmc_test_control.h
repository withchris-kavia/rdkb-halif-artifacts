#ifndef EMMC_TEST_CONTROL_H
#define EMMC_TEST_CONTROL_H

#ifndef BUILD_LINUX
#error "eMMC host controls must not be included in vendor builds"
#endif

#include "ccsp_hal_emmc.h"

/* Host conventions only. No symbols from this header belong to the HAL ABI.
 * Diagnostics always use m_diagnostics.m_list, never the untagged blob arm. */
typedef enum {
    EMMC_TEST_HEALTHY,
    EMMC_TEST_DEGRADED,
    EMMC_TEST_UNAVAILABLE
} emmc_test_state;

typedef enum {
    EMMC_TEST_HEALTH_GETTER,
    EMMC_TEST_DEVICE_GETTER
} emmc_test_getter;

/* PUBLIC_INTERFACE */
/** Restore the complete healthy fixture and clear both persistent getter faults. */
void emmc_test_reset(void);

/* PUBLIC_INTERFACE */
/** Select a host state, preserving faults; return -1 for an invalid state. */
int emmc_test_set_state(emmc_test_state state);

/* PUBLIC_INTERFACE */
/** Select empty/zero or maximum-width fixtures, preserving getter faults. */
void emmc_test_set_boundary(bool maximum);

/* PUBLIC_INTERFACE */
/** Set a getter's persistent return code; reject unknown getters/codes with -1. */
int emmc_test_set_fault(emmc_test_getter getter, eSTMGRReturns status);

#endif
