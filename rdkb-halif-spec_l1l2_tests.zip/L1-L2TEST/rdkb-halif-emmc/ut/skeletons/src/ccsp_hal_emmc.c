/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include "emmc_test_control.h"

static eSTMGRHealthInfo health;
static eSTMGRDeviceInfo device;
static eSTMGRReturns faults[2];
static bool initialized;

static void set_attribute(eSTMGRDiagAttributesList *list,
                          const char *name, const char *value)
{
    list->m_numOfAttributes = 1;
    snprintf(list->m_diagnostics[0].m_name,
             sizeof(list->m_diagnostics[0].m_name), "%s", name);
    snprintf(list->m_diagnostics[0].m_value,
             sizeof(list->m_diagnostics[0].m_value), "%s", value);
}

static void healthy_fixture(void)
{
    memset(&health, 0, sizeof(health));
    memset(&device, 0, sizeof(device));
    snprintf(device.m_deviceID, sizeof(device.m_deviceID), "host-emmc-0");
    device.m_type = RDK_STMGR_DEVICE_TYPE_EMMCCARD;
    device.m_capacity = 64ULL * 1024ULL * 1024ULL * 1024ULL;
    device.m_status = RDK_STMGR_DEVICE_STATUS_OK;
    snprintf(device.m_partitions, sizeof(device.m_partitions), "host-boot,host-data");
    snprintf(device.m_manufacturer, sizeof(device.m_manufacturer), "Host Reference");
    snprintf(device.m_model, sizeof(device.m_model), "Deterministic eMMC");
    snprintf(device.m_serialNumber, sizeof(device.m_serialNumber), "HOST0001");
    snprintf(device.m_firmwareVersion, sizeof(device.m_firmwareVersion), "1.0");
    snprintf(device.m_hwVersion, sizeof(device.m_hwVersion), "host-v1");
    snprintf(device.m_ifATAstandard, sizeof(device.m_ifATAstandard), "host-emmc");
    device.m_hasSMARTSupport = true;
    snprintf(health.m_deviceID, sizeof(health.m_deviceID), "%s", device.m_deviceID);
    health.m_deviceType = device.m_type;
    health.m_isOperational = true;
    health.m_isHealthy = true;
    set_attribute(&health.m_diagnostics.m_list, "pre_eol", "normal");
    set_attribute(&health.m_lifetimesList, "life_used", "10");
    set_attribute(&health.m_healthStatesList, "state", "healthy");
    initialized = true;
}

static void ensure_fixture(void)
{
    if (!initialized)
        emmc_test_reset();
}

/* PUBLIC_INTERFACE */
/** Reset all host fixture fields and persistent fault codes. */
void emmc_test_reset(void)
{
    healthy_fixture();
    faults[EMMC_TEST_HEALTH_GETTER] = RDK_STMGR_RETURN_SUCCESS;
    faults[EMMC_TEST_DEVICE_GETTER] = RDK_STMGR_RETURN_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Select an observable host state; unavailable is a successful absent snapshot. */
int emmc_test_set_state(emmc_test_state state)
{
    if (state < EMMC_TEST_HEALTHY || state > EMMC_TEST_UNAVAILABLE)
        return -1;
    ensure_fixture();
    healthy_fixture();
    if (state == EMMC_TEST_DEGRADED)
    {
        device.m_status = RDK_STMGR_DEVICE_STATUS_READ_ONLY;
        health.m_isHealthy = false;
        set_attribute(&health.m_diagnostics.m_list, "pre_eol", "warning");
        set_attribute(&health.m_lifetimesList, "life_used", "95");
        set_attribute(&health.m_firstExceededConfiguredLife, "threshold", "90");
        set_attribute(&health.m_healthStatesList, "state", "degraded");
    }
    else if (state == EMMC_TEST_UNAVAILABLE)
    {
        device.m_status = RDK_STMGR_DEVICE_STATUS_NOT_PRESENT;
        health.m_isOperational = false;
        health.m_isHealthy = false;
        set_attribute(&health.m_diagnostics.m_list, "pre_eol", "unavailable");
        set_attribute(&health.m_healthStatesList, "state", "unavailable");
    }
    return 0;
}

static void boundary_string(char *text, size_t size, bool maximum, char value)
{
    memset(text, maximum ? value : 0, size);
    text[size - 1] = '\0';
}

static void boundary_list(eSTMGRDiagAttributesList *list, bool maximum)
{
    memset(list, 0, sizeof(*list));
    list->m_numOfAttributes = maximum ? RDK_STMGR_MAX_DIAGNOSTIC_ATTRIBUTES : 0;
    for (unsigned int i = 0; i < list->m_numOfAttributes; ++i)
    {
        boundary_string(list->m_diagnostics[i].m_name,
                        sizeof(list->m_diagnostics[i].m_name), true, 'A' + i);
        boundary_string(list->m_diagnostics[i].m_value,
                        sizeof(list->m_diagnostics[i].m_value), true, 'a' + i);
    }
}

/* PUBLIC_INTERFACE */
/** Populate all strings/lists and capacity at their empty or maximum boundary. */
void emmc_test_set_boundary(bool maximum)
{
    ensure_fixture();
    healthy_fixture();
#define BOUNDARY(field, value) \
    boundary_string(device.field, sizeof(device.field), maximum, value)
    BOUNDARY(m_deviceID, 'I');
    BOUNDARY(m_partitions, 'P');
    BOUNDARY(m_manufacturer, 'M');
    BOUNDARY(m_model, 'D');
    BOUNDARY(m_serialNumber, 'S');
    BOUNDARY(m_firmwareVersion, 'F');
    BOUNDARY(m_hwVersion, 'H');
    BOUNDARY(m_ifATAstandard, 'T');
#undef BOUNDARY
    memcpy(health.m_deviceID, device.m_deviceID, sizeof(health.m_deviceID));
    device.m_capacity = maximum ? ULLONG_MAX : 0;
    device.m_hasSMARTSupport = maximum;
    boundary_list(&health.m_diagnostics.m_list, maximum);
    boundary_list(&health.m_lifetimesList, maximum);
    boundary_list(&health.m_firstExceededConfiguredLife, maximum);
    boundary_list(&health.m_firstExceededMaxLife, maximum);
    boundary_list(&health.m_healthStatesList, maximum);
}

/* PUBLIC_INTERFACE */
/** Inject a documented return code for one getter until explicitly cleared. */
int emmc_test_set_fault(emmc_test_getter getter, eSTMGRReturns status)
{
    if ((getter != EMMC_TEST_HEALTH_GETTER && getter != EMMC_TEST_DEVICE_GETTER) ||
        status > RDK_STMGR_RETURN_SUCCESS || status < RDK_STMGR_RETURN_UNKNOWN_FAILURE)
        return -1;
    ensure_fixture();
    faults[getter] = status;
    return 0;
}

/* PUBLIC_INTERFACE */
/** Copy a complete health snapshot; reject NULL before touching state or output. */
eSTMGRReturns CcspHalEmmcGetHealthInfo(eSTMGRHealthInfo *output)
{
    if (output == NULL)
        return RDK_STMGR_RETURN_INVALID_INPUT;
    ensure_fixture();
    if (faults[EMMC_TEST_HEALTH_GETTER] != RDK_STMGR_RETURN_SUCCESS)
        return faults[EMMC_TEST_HEALTH_GETTER];
    *output = health;
    return RDK_STMGR_RETURN_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy a complete device snapshot; injected errors leave caller storage intact. */
eSTMGRReturns CcspHalEmmcGetDeviceInfo(eSTMGRDeviceInfo *output)
{
    if (output == NULL)
        return RDK_STMGR_RETURN_INVALID_INPUT;
    ensure_fixture();
    if (faults[EMMC_TEST_DEVICE_GETTER] != RDK_STMGR_RETURN_SUCCESS)
        return faults[EMMC_TEST_DEVICE_GETTER];
    *output = device;
    return RDK_STMGR_RETURN_SUCCESS;
}
