#!/usr/bin/env bash
# Dependencies are provisioned separately; never rebuild or clean ut-core here.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ ! -f ut-core/include/ut.h || ! -f lib/libut_control.so ]]; then
    echo "Missing provisioned ut-core headers or lib/libut_control.so; provision dependencies first." >&2
    exit 1
fi
exec make -f Makefile "$@"
