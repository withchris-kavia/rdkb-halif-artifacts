# Unit Testing Suite For Cellular HAL

The following documents should be referenced to provide specific information on the tests required for this module.

[Documentation can be found under "docs/pages" in this repository](docs/pages)

## Table of Contents

- [Version History](#version-history)
- [Acronyms, Terms and Abbreviations](#acronyms-terms-and-abbreviations)
- [Description](#description)
- [Reference Documents](#reference-documents)

## Version History

| Date     | Comment         | Version |
| -------- | --------------- | ------- |
| 07/25/24 | Initial Release | 1.0.0   |

## Acronyms, Terms and Abbreviations

- `L1` - Unit Tests
- `HAL`- Hardware Abstraction Layer

## Description

This repository contains native L1 API/contract tests and L2 stateful tests for
Cellular `HAL`, with a deterministic Linux reference model.

See the [Cellular HAL Linux Reference Tests](docs/pages/ReferenceModel.md) for
build/run commands, model policies, ownership rules and independent verification.

The [Independent Verification Report](docs/pages/IndependentVerification.md)
records the executed matrix, per-case results, protected-file evidence and limitations.

## Reference Documents

|SNo|Document Name|Document Description|Document Link|
|---|-------------|--------------------|-------------|
|1|`HAL` Specification Document|This document provides specific information on the APIs for which tests are written in this module|[CellularHalSpec.md](https://github.com/rdkcentral/rdkb-halif-cellular/blob/main/docs/pages/CellularHalSpec.md "CellularHalSpec.md")|
|2|`L1` Tests |`L1` Test Case File for this module |[test_l1_cellular_hal.c](src/test_l1_cellular_hal.c "test_l1_cellular_hal.c")|

