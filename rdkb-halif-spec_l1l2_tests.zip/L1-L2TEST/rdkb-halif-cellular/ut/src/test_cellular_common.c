#include "test_cellular_common.h"
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <time.h>

CellularTestProfile cellular_test_profile;
static pthread_mutex_t record_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t record_changed = PTHREAD_COND_INITIALIZER;
static CellularCallbackRecord record = {.valid = true};

/* PUBLIC_INTERFACE */
/** Check termination before any unbounded string operation. */
bool cellular_string_valid(const char *value, size_t capacity)
{
    return value && capacity && value[0] && strnlen(value, capacity) < capacity;
}

/* PUBLIC_INTERFACE */
/** Validate decimal digits with an explicit read bound. */
bool cellular_digits_valid(const char *value, size_t capacity)
{
    if (!cellular_string_valid(value, capacity))
        return false;
    for (size_t i = 0; value[i]; ++i)
        if (!isdigit((unsigned char)value[i]))
            return false;
    return true;
}

/* PUBLIC_INTERFACE */
/** Use the real destination capacity, not UT_KVP_PROFILE_GET_STRING's fixed 256. */
int cellular_profile_string(const char *key, char *output, size_t capacity)
{
    if (!key || !output || !capacity || capacity > UINT32_MAX ||
        strlen(key) >= UT_KVP_MAX_ELEMENT_SIZE)
        return RETURN_ERROR;
    memset(output, 0xa5, capacity);
    ut_kvp_status_t status = ut_kvp_getStringField(ut_kvp_profile_getInstance(), key,
                                                 output, (uint32_t)capacity);
    if (status != UT_KVP_STATUS_SUCCESS || !memchr(output, '\0', capacity)) {
        output[0] = '\0';
        fprintf(stderr, "Missing, invalid or overlong profile field: %s\n", key);
        return RETURN_ERROR;
    }
    return RETURN_OK;
}

static int number(const char *key, long minimum, long maximum, long *result)
{
    char text[64], *end = NULL;
    if (cellular_profile_string(key, text, sizeof(text)) != RETURN_OK || !text[0])
        return RETURN_ERROR;
    errno = 0;
    long value = strtol(text, &end, 10);
    if (errno || end == text || *end || value < minimum || value > maximum) {
        fprintf(stderr, "Invalid numeric profile field: %s\n", key);
        return RETURN_ERROR;
    }
    *result = value;
    return RETURN_OK;
}

static int enum_field(const char *key, const char *const *names, size_t count, int base)
{
    char text[128];
    if (cellular_profile_string(key, text, sizeof(text)) != RETURN_OK)
        return -1;
    for (size_t i = 0; i < count; ++i)
        if (!strcmp(text, names[i]))
            return (int)i + base;
    fprintf(stderr, "Invalid enum profile field: %s\n", key);
    return -1;
}

/* PUBLIC_INTERFACE */
/** Validate a complete reference profile before registering or running any test. */
int cellular_profile_load(void)
{
    static const char *const profile_types[] = {
        "CELLULAR_PROFILE_TYPE_3GPP", "CELLULAR_PROFILE_TYPE_3GPP2"};
    static const char *const pdp_types[] = {
        "CELLULAR_PDP_TYPE_IPV4", "CELLULAR_PDP_TYPE_PPP",
        "CELLULAR_PDP_TYPE_IPV6", "CELLULAR_PDP_TYPE_IPV4_OR_IPV6"};
    static const char *const auth_types[] = {
        "CELLULAR_PDP_AUTHENTICATION_NONE", "CELLULAR_PDP_AUTHENTICATION_PAP",
        "CELLULAR_PDP_AUTHENTICATION_CHAP"};
    static const char *const network_types[] = {
        "CELLULAR_PDP_NETWORK_CONFIG_NAS", "CELLULAR_PDP_NETWORK_CONFIG_DHCP"};
    CellularTestProfile profile = {0};
    CellularProfileStruct *p = &profile.input.stIfInput;
    long value;
    int parsed;
#define NUMBER(key, field, low, high) do { \
    if (number(key, low, high, &value)) return RETURN_ERROR; \
    field = value; \
} while (0)
#define ENUM(key, field, values, base) do { \
    parsed = enum_field(key, values, sizeof(values) / sizeof(values[0]), base); \
    if (parsed < 0) return RETURN_ERROR; \
    field = parsed; \
} while (0)
#define STRING(field) do { \
    if (cellular_profile_string("cellular.config.profile." #field, p->field, sizeof(p->field))) \
        return RETURN_ERROR; \
} while (0)
    NUMBER("cellular.config.slot_id", profile.slot, 1, 2);
    NUMBER("cellular.config.ip_family", profile.input.enIPFamilyPreference, 1, 4);
    NUMBER("cellular.config.access_technology", profile.input.enPreferenceTechnology, 1, 8);
    NUMBER("cellular.capabilities.allow_resets", profile.allow_resets, 0, 1);
    NUMBER("cellular.config.profile.ProfileID", p->ProfileID, -1, INT_MAX);
    NUMBER("cellular.config.profile.PDPContextNumber", p->PDPContextNumber, -1, INT_MAX);
    ENUM("cellular.config.profile.ProfileType", p->ProfileType, profile_types, 0);
    ENUM("cellular.config.profile.PDPType", p->PDPType, pdp_types, 0);
    ENUM("cellular.config.profile.PDPAuthentication", p->PDPAuthentication, auth_types, 0);
    ENUM("cellular.config.profile.PDPNetworkConfig", p->PDPNetworkConfig, network_types, 1);
    STRING(ProfileName);
    STRING(APN);
    STRING(Username);
    STRING(Password);
    STRING(Proxy);
    NUMBER("cellular.config.profile.ProxyPort", p->ProxyPort, 0, 65535);
    NUMBER("cellular.config.profile.bIsNoRoaming", p->bIsNoRoaming, 0, 1);
    NUMBER("cellular.config.profile.bIsAPNDisabled", p->bIsAPNDisabled, 0, 1);
    NUMBER("cellular.config.profile.bIsThisDefaultProfile", p->bIsThisDefaultProfile, 0, 1);
#undef NUMBER
#undef ENUM
#undef STRING
    if (!p->ProfileName[0] || !p->APN[0])
        return RETURN_ERROR;
    cellular_test_profile = profile;
    return RETURN_OK;
}

static void note(unsigned int kind, bool valid)
{
    ++record.count[kind];
    record.valid = record.valid && valid;
    if (record.events < sizeof(record.order) / sizeof(record.order[0]))
        record.order[record.events++] = kind;
    else
        record.valid = false;
    pthread_cond_broadcast(&record_changed);
}

static int open_callback(char *device, char *wan, CellularDeviceOpenStatus_t status,
                         CellularModemOperatingConfiguration_t mode)
{
    bool valid = cellular_string_valid(device, 64) && cellular_string_valid(wan, 64) &&
        status == DEVICE_OPEN_STATUS_READY && mode >= CELLULAR_MODEM_SET_ONLINE &&
        mode <= CELLULAR_MODEM_SET_FACTORY_RESET;
    /* A reentrant getter proves delivery does not hold the model state lock. */
    valid = valid && cellular_hal_IsModemControlInterfaceOpened();
    pthread_mutex_lock(&record_lock);
    note(CB_OPEN, valid);
    pthread_mutex_unlock(&record_lock);
    return RETURN_OK;
}

static int removed_callback(char *device, CellularDeviceDetectionStatus_t status)
{
    pthread_mutex_lock(&record_lock);
    note(CB_REMOVE, cellular_string_valid(device, 64) && status == DEVICE_REMOVED);
    pthread_mutex_unlock(&record_lock);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy slot information with validation and no callback-thread assertions. */
int cellular_slot_callback(char *name, char *type, int slot, CellularDeviceSlotStatus_t status)
{
    pthread_mutex_lock(&record_lock);
    record.slot = slot;
    note(CB_SLOT, cellular_string_valid(name, 64) && cellular_string_valid(type, 64) &&
         slot >= 1 && status == DEVICE_SLOT_STATUS_READY);
    pthread_mutex_unlock(&record_lock);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Capture registration/service consistency under a lock. */
int cellular_registration_callback(CellularDeviceNASStatus_t status,
    CellularDeviceNASRoamingStatus_t roaming, CellularModemRegisteredServiceType_t service)
{
    pthread_mutex_lock(&record_lock);
    record.registration = status;
    record.service = service;
    note(CB_REGISTRATION, status >= DEVICE_NAS_STATUS_NOT_REGISTERED &&
         status <= DEVICE_NAS_STATUS_REGISTERED &&
         roaming >= DEVICE_NAS_STATUS_ROAMING_OFF && roaming <= DEVICE_NAS_STATUS_ROAMING_ON &&
         service >= CELLULAR_MODEM_REGISTERED_SERVICE_NONE &&
         service <= CELLULAR_MODEM_REGISTERED_SERVICE_CS_PS);
    pthread_mutex_unlock(&record_lock);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy callback-scoped profile ID without retaining any driver-owned pointer. */
int cellular_profile_callback(char *id, CellularPDPType_t type,
                               CellularDeviceProfileSelectionStatus_t status)
{
    pthread_mutex_lock(&record_lock);
    bool valid = cellular_string_valid(id, sizeof(record.profile_id));
    if (valid)
        strcpy(record.profile_id, id);
    record.profile_status = status;
    note(CB_PROFILE, valid && type >= CELLULAR_PDP_TYPE_IPV4 &&
         type <= CELLULAR_PDP_TYPE_IPV4_OR_IPV6 && status >= DEVICE_PROFILE_STATUS_NOT_READY &&
         status <= DEVICE_PROFILE_STATUS_DELETED);
    pthread_mutex_unlock(&record_lock);
    return RETURN_OK;
}

static int packet_callback(char *device, CellularNetworkIPType_t family, CellularNetworkPacketStatus_t status)
{
    pthread_mutex_lock(&record_lock);
    bool valid = family == CELLULAR_NETWORK_IP_FAMILY_IPV4 || family == CELLULAR_NETWORK_IP_FAMILY_IPV6;
    if (valid)
        record.packet_status[family - 1] = status;
    note(CB_PACKET, valid && cellular_string_valid(device, 64) &&
         (status == DEVICE_NETWORK_STATUS_CONNECTED || status == DEVICE_NETWORK_STATUS_DISCONNECTED));
    pthread_mutex_unlock(&record_lock);
    return RETURN_OK;
}

static int ip_callback(CellularIPStruct *ip, CellularDeviceIPReadyStatus_t status)
{
    unsigned char address[16];
    pthread_mutex_lock(&record_lock);
    bool family = ip && (ip->IPType == CELLULAR_NETWORK_IP_FAMILY_IPV4 ||
                        ip->IPType == CELLULAR_NETWORK_IP_FAMILY_IPV6);
    bool valid = family && status == DEVICE_NETWORK_IP_READY &&
        cellular_string_valid(ip->WANIFName, sizeof(ip->WANIFName)) &&
        cellular_string_valid(ip->IPAddress, sizeof(ip->IPAddress)) &&
        cellular_string_valid(ip->SubnetMask, sizeof(ip->SubnetMask)) &&
        cellular_string_valid(ip->DefaultGateWay, sizeof(ip->DefaultGateWay)) &&
        cellular_string_valid(ip->DNSServer1, sizeof(ip->DNSServer1)) &&
        cellular_string_valid(ip->DNSServer2, sizeof(ip->DNSServer2)) &&
        cellular_string_valid(ip->Domains, sizeof(ip->Domains)) &&
        ip->MTUSize >= 1280 && ip->MTUSize <= 9000;
    if (valid)
        valid = inet_pton(ip->IPType == CELLULAR_NETWORK_IP_FAMILY_IPV4 ? AF_INET : AF_INET6,
                          ip->IPAddress, address) == 1;
    if (valid)
        record.ip[ip->IPType - 1] = *ip;
    note(CB_IP, valid);
    pthread_mutex_unlock(&record_lock);
    return RETURN_OK;
}

CellularDeviceContextCBStruct cellular_device_callbacks = {open_callback, removed_callback};
CellularNetworkCBStruct cellular_network_callbacks = {ip_callback, packet_callback};

/* PUBLIC_INTERFACE */
/** Return a thread-safe value snapshot of all callback observations. */
CellularCallbackRecord cellular_callbacks_snapshot(void)
{
    pthread_mutex_lock(&record_lock);
    CellularCallbackRecord snapshot = record;
    pthread_mutex_unlock(&record_lock);
    return snapshot;
}

/* PUBLIC_INTERFACE */
/** Bound callback waits; a timeout is failure, never success or a hardware oracle. */
bool cellular_callbacks_wait(unsigned int kind, unsigned int count)
{
    struct timespec deadline;
    if (kind >= CB_COUNT || clock_gettime(CLOCK_REALTIME, &deadline))
        return false;
    deadline.tv_sec += 2;
    pthread_mutex_lock(&record_lock);
    int status = 0;
    while (record.count[kind] < count && !status)
        status = pthread_cond_timedwait(&record_changed, &record_lock, &deadline);
    bool complete = record.count[kind] >= count;
    pthread_mutex_unlock(&record_lock);
    return complete;
}

/* PUBLIC_INTERFACE */
/** Quiesce model callbacks before resetting recorder storage. */
void cellular_fixture_reset(void)
{
#ifdef BUILD_LINUX
    cellular_test_reset();
#endif
    pthread_mutex_lock(&record_lock);
    memset(&record, 0, sizeof(record));
    record.valid = true;
    pthread_mutex_unlock(&record_lock);
}

/* PUBLIC_INTERFACE */
/** Arrange lifecycle state once per test, checking each mutation. */
int cellular_fixture_begin(void)
{
    cellular_fixture_reset();
    if (cellular_hal_init(&cellular_test_profile.input) != RETURN_OK ||
        cellular_hal_open_device(&cellular_device_callbacks) != RETURN_OK ||
        cellular_hal_select_device_slot(cellular_slot_callback) != RETURN_OK)
        return RETURN_ERROR;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Tear down reference state; vendor test execution requires a separate recovery policy. */
int cellular_fixture_end(void)
{
#ifdef BUILD_LINUX
    cellular_test_reset();
    if (cellular_hal_IsModemControlInterfaceOpened())
        return RETURN_ERROR;
#endif
    return RETURN_OK;
}
