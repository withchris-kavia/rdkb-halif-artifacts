#include "test_cellular_common.h"
#include <TestDB.h>
#include <stddef.h>

#ifndef CELLULAR_MGR_LITE
#ifndef QMI_SUPPORT
#error "The public non-lite contract must enable QMI_SUPPORT"
#endif
#endif

/* Every enumerator is named and checked, not merely enum sizeof(). */
#define ENUM_VALUES(type, base, ...) do { \
    const type values[] = {__VA_ARGS__}; \
    for (size_t i = 0; i < sizeof(values) / sizeof(values[0]); ++i) \
        CU_ASSERT_EQUAL((int)values[i], (int)i + (base)); \
} while (0)

static void enum_values(void)
{
    ENUM_VALUES(CellularInterfaceStatus_t, 1,
        IF_UP, IF_DOWN, IF_UNKNOWN, IF_DORMANT, IF_NOTPRESENT, IF_LOWERLAYERDOWN, IF_ERROR);
    ENUM_VALUES(CellularIpFamilyPref_t, 1,
        IP_FAMILY_UNKNOWN, IP_FAMILY_IPV4, IP_FAMILY_IPV6, IP_FAMILY_IPV4_IPV6);
    ENUM_VALUES(CellularPrefAccessTechnology_t, 1,
        PREF_GPRS, PREF_EDGE, PREF_UMTS, PREF_UMTSHSPA, PREF_CDMA2000OneX,
        PREF_CDMA2000HRPD, PREF_LTE, PREF_NR);
    ENUM_VALUES(CellularPDPType_t, 0, CELLULAR_PDP_TYPE_IPV4, CELLULAR_PDP_TYPE_PPP,
        CELLULAR_PDP_TYPE_IPV6, CELLULAR_PDP_TYPE_IPV4_OR_IPV6);
    ENUM_VALUES(CellularPDPAuthentication_t, 0, CELLULAR_PDP_AUTHENTICATION_NONE,
        CELLULAR_PDP_AUTHENTICATION_PAP, CELLULAR_PDP_AUTHENTICATION_CHAP);
    ENUM_VALUES(CellularProfileType_t, 0, CELLULAR_PROFILE_TYPE_3GPP, CELLULAR_PROFILE_TYPE_3GPP2);
    ENUM_VALUES(CellularPDPNetworkConfig_t, 1, CELLULAR_PDP_NETWORK_CONFIG_NAS, CELLULAR_PDP_NETWORK_CONFIG_DHCP);
    ENUM_VALUES(CellularModemOperatingConfiguration_t, 1,
        CELLULAR_MODEM_SET_ONLINE, CELLULAR_MODEM_SET_OFFLINE, CELLULAR_MODEM_SET_LOW_POWER_MODE,
        CELLULAR_MODEM_SET_RESET, CELLULAR_MODEM_SET_FACTORY_RESET);
    ENUM_VALUES(CellularModemRegisteredServiceType_t, 0,
        CELLULAR_MODEM_REGISTERED_SERVICE_NONE, CELLULAR_MODEM_REGISTERED_SERVICE_PS,
        CELLULAR_MODEM_REGISTERED_SERVICE_CS, CELLULAR_MODEM_REGISTERED_SERVICE_CS_PS);
    ENUM_VALUES(CellularRegistrationStatus_t, 1, DEVICE_REGISTERED, DEVICE_NOT_REGISTERED);
    ENUM_VALUES(CellularNetworkIPType_t, 0, CELLULAR_NETWORK_IP_FAMILY_UNKNOWN,
        CELLULAR_NETWORK_IP_FAMILY_IPV4, CELLULAR_NETWORK_IP_FAMILY_IPV6,
        CELLULAR_NETWORK_IP_FAMILY_UNSPECIFIED);
    ENUM_VALUES(CellularUICCFormFactor_t, 0, CELLULAR_UICC_FORM_FACTOR_1FF,
        CELLULAR_UICC_FORM_FACTOR_2FF, CELLULAR_UICC_FORM_FACTOR_3FF, CELLULAR_UICC_FORM_FACTOR_4FF);
    ENUM_VALUES(CellularUICCStatus_t, 0, CELLULAR_UICC_STATUS_VALID, CELLULAR_UICC_STATUS_BLOCKED,
        CELLULAR_UICC_STATUS_ERROR, CELLULAR_UICC_STATUS_EMPTY);
    ENUM_VALUES(CellularUICCApplication_t, 0, CELLULAR_UICC_APPLICATION_USIM,
        CELLULAR_UICC_APPLICATION_ISIM, CELLULAR_UICC_APPLICATION_ESIM);
    ENUM_VALUES(CellularDeviceDetectionStatus_t, 1, DEVICE_DETECTED, DEVICE_REMOVED);
    ENUM_VALUES(CellularDeviceOpenStatus_t, 1, DEVICE_OPEN_STATUS_NOT_READY,
        DEVICE_OPEN_STATUS_INPROGRESS, DEVICE_OPEN_STATUS_READY);
    ENUM_VALUES(CellularDeviceSlotStatus_t, 1, DEVICE_SLOT_STATUS_NOT_READY,
        DEVICE_SLOT_STATUS_SELECTING, DEVICE_SLOT_STATUS_READY);
    ENUM_VALUES(CellularDeviceNASStatus_t, 1, DEVICE_NAS_STATUS_NOT_REGISTERED,
        DEVICE_NAS_STATUS_REGISTERING, DEVICE_NAS_STATUS_REGISTERED);
    ENUM_VALUES(CellularDeviceNASRoamingStatus_t, 1,
        DEVICE_NAS_STATUS_ROAMING_OFF, DEVICE_NAS_STATUS_ROAMING_ON);
    ENUM_VALUES(CellularContextProfileStatus_t, 1, PROFILE_STATUS_INACTIVE, PROFILE_STATUS_ACTIVE);
    ENUM_VALUES(CellularDeviceProfileSelectionStatus_t, 1, DEVICE_PROFILE_STATUS_NOT_READY,
        DEVICE_PROFILE_STATUS_CONFIGURING, DEVICE_PROFILE_STATUS_READY, DEVICE_PROFILE_STATUS_DELETED);
    ENUM_VALUES(CellularDeviceIPReadyStatus_t, 1, DEVICE_NETWORK_IP_NOT_READY, DEVICE_NETWORK_IP_READY);
    ENUM_VALUES(CellularNetworkPacketStatus_t, 1,
        DEVICE_NETWORK_STATUS_DISCONNECTED, DEVICE_NETWORK_STATUS_CONNECTED);
}

static void macros_and_variants(void)
{
    CU_ASSERT_EQUAL(RETURN_OK, 0);
    CU_ASSERT_EQUAL(RETURN_ERROR, -1);
    CU_ASSERT_EQUAL(TRUE, 1);
    CU_ASSERT_EQUAL(FALSE, 0);
    CU_ASSERT_EQUAL(BUFLEN_8, 8);
    CU_ASSERT_EQUAL(BUFLEN_32, 32);
    CU_ASSERT_EQUAL(BUFLEN_64, 64);
    CU_ASSERT_EQUAL(BUFLEN_128, 128);
    CU_ASSERT_EQUAL(BUFLEN_256, 256);
    CU_ASSERT_EQUAL(CELLULAR_PROFILE_ID_UNKNOWN, -1);
    CU_ASSERT_EQUAL(CELLULAR_SLOT_ID_UNKNOWN, -1);
    CU_ASSERT_EQUAL(CELLULAR_PDP_CONTEXT_UNKNOWN, -1);
    CU_ASSERT_EQUAL(CELLULAR_PACKET_DATA_INVALID_HANDLE, UINT32_MAX);
    /* The matrix compiles this TU for every lite/QMI combination.
     * The preprocessor guard above verifies the public non-lite implication. */
}

static void structures_and_callbacks(void)
{
    CellularProfileStruct profile = {0};
    CellularContextInitInputStruct input = {0};
    CellularIPStruct ip = {0};
    CellularPacketStatsStruct stats = {0};
    CellularUICCSlotInfoStruct slot = {0};
    CellularSignalInfoStruct signal = {0};
    CellLocationInfoStruct location = {0};
    CellularCurrentPlmnInfoStruct plmn = {0};
    CellularNetworkScanResultInfoStruct scan = {0};
    CellularDeviceContextCBStruct device = cellular_device_callbacks;
    CellularNetworkCBStruct network = cellular_network_callbacks;
    cellular_device_open_status_api_callback open = device.device_open_status_cb;
    cellular_device_removed_status_api_callback remove = device.device_remove_status_cb;
    cellular_device_slot_status_api_callback select = cellular_slot_callback;
    cellular_device_registration_status_callback registration = cellular_registration_callback;
    cellular_device_profile_status_api_callback selected = cellular_profile_callback;
    cellular_network_packet_service_status_api_callback packet = network.packet_service_status_cb;
    cellular_device_network_ip_ready_api_callback ready = network.device_network_ip_ready_cb;

    CU_ASSERT(open && remove && select && registration && selected && packet && ready);
#define WIDTH(object, field, expected) CU_ASSERT_EQUAL(sizeof((object).field), expected)
    WIDTH(profile, ProfileName, 64);
    WIDTH(profile, APN, 64);
    WIDTH(profile, Username, 256);
    WIDTH(profile, Password, 256);
    WIDTH(profile, Proxy, 45);
    WIDTH(input, stIfInput, sizeof(CellularProfileStruct));
    WIDTH(ip, WANIFName, 16);
    WIDTH(ip, IPAddress, 128);
    WIDTH(ip, SubnetMask, 128);
    WIDTH(ip, DefaultGateWay, 128);
    WIDTH(ip, DNSServer1, 128);
    WIDTH(ip, DNSServer2, 128);
    WIDTH(ip, Domains, 256);
    WIDTH(stats, BytesSent, sizeof(unsigned long));
    WIDTH(stats, BytesReceived, sizeof(unsigned long));
    WIDTH(stats, PacketsSent, sizeof(unsigned long));
    WIDTH(stats, PacketsReceived, sizeof(unsigned long));
    WIDTH(stats, PacketsSentDrop, sizeof(unsigned long));
    WIDTH(stats, PacketsReceivedDrop, sizeof(unsigned long));
    WIDTH(stats, UpStreamMaxBitRate, sizeof(unsigned long));
    WIDTH(stats, DownStreamMaxBitRate, sizeof(unsigned long));
    WIDTH(slot, MnoName, 32);
    WIDTH(slot, iccid, 20);
    WIDTH(slot, msisdn, 20);
    WIDTH(signal, RSSI, sizeof(int));
    WIDTH(signal, RSRQ, sizeof(int));
    WIDTH(signal, RSRP, sizeof(int));
    WIDTH(signal, SNR, sizeof(int));
    WIDTH(signal, TXPower, sizeof(int));
    WIDTH(location, globalCellId, sizeof(unsigned int));
    WIDTH(location, bandInfo, sizeof(unsigned int));
    WIDTH(location, servingCellId, sizeof(unsigned int));
    WIDTH(plmn, plmn_name, 32);
    WIDTH(plmn, cell_id, sizeof(unsigned long));
    WIDTH(scan, network_name, 32);
    WIDTH(device, device_open_status_cb, sizeof(open));
    WIDTH(device, device_remove_status_cb, sizeof(remove));
    WIDTH(network, device_network_ip_ready_cb, sizeof(ready));
    WIDTH(network, packet_service_status_cb, sizeof(packet));
#undef WIDTH
    CU_ASSERT(offsetof(CellularProfileStruct, Password) > offsetof(CellularProfileStruct, Username));
    CU_ASSERT(offsetof(CellularContextInitInputStruct, enPreferenceTechnology) >
              offsetof(CellularContextInitInputStruct, stIfInput));
    CU_ASSERT(offsetof(CellularIPStruct, MTUSize) > offsetof(CellularIPStruct, Domains));
}

/* PUBLIC_INTERFACE */
/** Register checks for all 23 enums, 11 structures, seven callbacks and public macros. */
int test_cellular_contract_register(void)
{
    CU_pSuite suite = CU_add_suite("L1.contract", NULL, NULL);
    if (!suite || !CU_add_test(suite, "23-enum-values", enum_values) ||
        !CU_add_test(suite, "macros-and-compile-variants", macros_and_variants) ||
        !CU_add_test(suite, "11-structs-and-7-callback-typedefs", structures_and_callbacks))
        return RETURN_ERROR;
    return RETURN_OK;
}
