#ifndef TEST_CELLULAR_COMMON_H
#define TEST_CELLULAR_COMMON_H
#include "cellular_hal.h"
#include <CUnit.h>
#include <ut_kvp_profile.h>
#ifdef BUILD_LINUX
#include "cellular_hal_test_control.h"
#endif

enum { CB_OPEN, CB_REMOVE, CB_SLOT, CB_REGISTRATION, CB_PROFILE, CB_PACKET, CB_IP, CB_COUNT };
typedef struct {
    unsigned int count[CB_COUNT];
    bool valid;
    CellularDeviceNASStatus_t registration;
    CellularModemRegisteredServiceType_t service;
    CellularDeviceProfileSelectionStatus_t profile_status;
    CellularNetworkPacketStatus_t packet_status[2];
    CellularIPStruct ip[2];
    char profile_id[64];
    int slot;
    unsigned int order[64], events;
} CellularCallbackRecord;
typedef struct {
    CellularContextInitInputStruct input;
    unsigned int slot;
    bool allow_resets;
} CellularTestProfile;

extern CellularTestProfile cellular_test_profile;
extern CellularDeviceContextCBStruct cellular_device_callbacks;
extern CellularNetworkCBStruct cellular_network_callbacks;

/* PUBLIC_INTERFACE */
/** Decode all required profile inputs; return error for absent, truncated or invalid scalars. */
int cellular_profile_load(void);
/* PUBLIC_INTERFACE */
/** Safely decode a string into the supplied capacity and reject missing NUL termination. */
int cellular_profile_string(const char *key, char *output, size_t capacity);
/* PUBLIC_INTERFACE */
/** Check bounded NUL termination and non-empty output. */
bool cellular_string_valid(const char *value, size_t capacity);
/* PUBLIC_INTERFACE */
/** Check a bounded printable digit string, without examining memory beyond capacity. */
bool cellular_digits_valid(const char *value, size_t capacity);
/* PUBLIC_INTERFACE */
/** Reset/quiesce Linux model state before clearing the recorder. */
void cellular_fixture_reset(void);
/* PUBLIC_INTERFACE */
/** Arrange fresh initialized/opened/selected state; no dependency on a previous case. */
int cellular_fixture_begin(void);
/* PUBLIC_INTERFACE */
/** Tear down fixture callbacks and verify Linux open state was cleared. */
int cellular_fixture_end(void);
/* PUBLIC_INTERFACE */
/** Copy the recorder under its lock for assertions in the test thread. */
CellularCallbackRecord cellular_callbacks_snapshot(void);
/* PUBLIC_INTERFACE */
/** Wait at most two seconds for a callback count; this is a harness safety budget. */
bool cellular_callbacks_wait(unsigned int kind, unsigned int count);
/* PUBLIC_INTERFACE */
/** Record a slot notification, copying and validating callback-scoped payloads. */
int cellular_slot_callback(char *name, char *type, int slot, CellularDeviceSlotStatus_t status);
/* PUBLIC_INTERFACE */
/** Record registration and service consistency without calling CUnit from a callback. */
int cellular_registration_callback(CellularDeviceNASStatus_t status,
    CellularDeviceNASRoamingStatus_t roaming, CellularModemRegisteredServiceType_t service);
/* PUBLIC_INTERFACE */
/** Copy profile callback identifiers and status without logging credentials. */
int cellular_profile_callback(char *id, CellularPDPType_t type,
                               CellularDeviceProfileSelectionStatus_t status);
/* PUBLIC_INTERFACE */
/** Register the contract, L1 and L2 suites; return nonzero on any registration error. */
int register_cellular_tests(void);
/* PUBLIC_INTERFACE */
/** Register ABI contract coverage. */
int test_cellular_contract_register(void);
/* PUBLIC_INTERFACE */
/** Register function-level tests for every public API. */
int test_cellular_hal_l1_register(void);
/* PUBLIC_INTERFACE */
/** Register stateful Linux reference-policy scenarios. */
int test_cellular_hal_l2_register(void);
#endif
