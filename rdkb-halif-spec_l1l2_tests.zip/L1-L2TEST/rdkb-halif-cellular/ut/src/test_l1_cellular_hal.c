#include "test_cellular_common.h"
#include <TestDB.h>
#include <limits.h>

/* Each case arranges its own state; no assertions occur inside callbacks.
 * Model-only ordering/boundary expectations are guarded, not vendor requirements.
 * List ownership is unspecified in the public ABI: never blindly free outputs.
 */
#define ARRANGE() CU_ASSERT_EQUAL_FATAL(cellular_fixture_begin(), RETURN_OK)
#define OK(call) CU_ASSERT_EQUAL((call), RETURN_OK)
#define ERROR(call) CU_ASSERT_EQUAL((call), RETURN_ERROR)

static void test_present(void)
{
    ARRANGE();
    CU_ASSERT_EQUAL(cellular_hal_IsModemDevicePresent(), TRUE);
#ifdef BUILD_LINUX
    cellular_test_set_present(false);
    CU_ASSERT_EQUAL(cellular_hal_IsModemDevicePresent(), FALSE);
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().count[CB_REMOVE], 1);
#endif
}

static void test_init(void)
{
    cellular_fixture_reset();
    ERROR(cellular_hal_init(NULL));
    CellularContextInitInputStruct input = cellular_test_profile.input;
#ifdef BUILD_LINUX
    input.enIPFamilyPreference = (CellularIpFamilyPref_t)0;
    ERROR(cellular_hal_init(&input));
    input = cellular_test_profile.input;
    input.enPreferenceTechnology = (CellularPrefAccessTechnology_t)99;
    ERROR(cellular_hal_init(&input));
    input = cellular_test_profile.input;
    memset(input.stIfInput.Password, 'x', sizeof(input.stIfInput.Password));
    ERROR(cellular_hal_init(&input));
    input = cellular_test_profile.input;
#endif
    /* Unlike the legacy break-before-assert loop, this always checks init. */
    OK(cellular_hal_init(&input));
}

static void test_open(void)
{
    cellular_fixture_reset();
    OK(cellular_hal_init(&cellular_test_profile.input));
    ERROR(cellular_hal_open_device(NULL));
    CellularDeviceContextCBStruct missing = {0};
#ifdef BUILD_LINUX
    ERROR(cellular_hal_open_device(&missing));
#else
    (void)missing;
#endif
    OK(cellular_hal_open_device(&cellular_device_callbacks));
    CU_ASSERT(cellular_callbacks_wait(CB_OPEN, 1));
    CU_ASSERT(cellular_callbacks_snapshot().valid);
}

static void test_control_open(void)
{
    cellular_fixture_reset();
#ifdef BUILD_LINUX
    CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), FALSE);
#endif
    ARRANGE();
    CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), TRUE);
}

static void test_select_slot(void)
{
    ARRANGE();
    ERROR(cellular_hal_select_device_slot(NULL));
    OK(cellular_hal_select_device_slot(cellular_slot_callback));
    CU_ASSERT(cellular_callbacks_wait(CB_SLOT, 2));
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().slot, 1);
}

static void test_sim_power(void)
{
    ARRANGE();
    OK(cellular_hal_sim_power_enable(cellular_test_profile.slot, 0));
    OK(cellular_hal_sim_power_enable(cellular_test_profile.slot, 1));
#ifdef BUILD_LINUX
    ERROR(cellular_hal_sim_power_enable(0, 1));
    ERROR(cellular_hal_sim_power_enable(UINT_MAX, 1));
    ERROR(cellular_hal_sim_power_enable(1, 2));
#endif
}

static void test_slots_count(void)
{
    unsigned int count = 0;
    ARRANGE();
    ERROR(cellular_hal_get_total_no_of_uicc_slots(NULL));
    OK(cellular_hal_get_total_no_of_uicc_slots(&count));
    CU_ASSERT(count >= 1 && count <= 2);
}

static void test_slot_info(void)
{
    CellularUICCSlotInfoStruct info = {0};
    ARRANGE();
    ERROR(cellular_hal_get_uicc_slot_info(1, NULL));
    OK(cellular_hal_get_uicc_slot_info(cellular_test_profile.slot, &info));
    CU_ASSERT(info.SlotEnable <= 1 && info.IsCardPresent <= 1 && info.CardEnable <= 1);
    CU_ASSERT(cellular_string_valid(info.iccid, sizeof(info.iccid)));
    CU_ASSERT(info.Status >= CELLULAR_UICC_STATUS_VALID && info.Status <= CELLULAR_UICC_STATUS_EMPTY);
#ifdef BUILD_LINUX
    ERROR(cellular_hal_get_uicc_slot_info(0, &info));
    /* -1 converts to UINT_MAX; it is one invalid case, not contradictory tests. */
    ERROR(cellular_hal_get_uicc_slot_info(UINT_MAX, &info));
    ERROR(cellular_hal_get_uicc_slot_info(3, &info));
#endif
}

static void test_card_status(void)
{
    CellularUICCStatus_t status;
    ARRANGE();
    ERROR(cellular_hal_get_active_card_status(NULL));
    OK(cellular_hal_get_active_card_status(&status));
    CU_ASSERT(status >= CELLULAR_UICC_STATUS_VALID && status <= CELLULAR_UICC_STATUS_EMPTY);
}

static void test_registration(void)
{
    ARRANGE();
    ERROR(cellular_hal_monitor_device_registration(NULL));
    OK(cellular_hal_monitor_device_registration(cellular_registration_callback));
    CU_ASSERT(cellular_callbacks_wait(CB_REGISTRATION, 1));
    CU_ASSERT(cellular_callbacks_snapshot().valid);
}

static void test_profile_create(void)
{
    ARRANGE();
    ERROR(cellular_hal_profile_create(NULL, NULL));
    OK(cellular_hal_profile_create(NULL, cellular_profile_callback));
    CU_ASSERT(cellular_callbacks_wait(CB_PROFILE, 1));
#ifdef BUILD_LINUX
    CellularProfileStruct profile = cellular_test_profile.input.stIfInput;
    profile.ProfileID = 202;
    OK(cellular_hal_profile_create(&profile, cellular_profile_callback));
    ERROR(cellular_hal_profile_create(&profile, cellular_profile_callback));
#endif
}

static void test_profile_delete(void)
{
    ARRANGE();
    ERROR(cellular_hal_profile_delete(NULL, cellular_profile_callback));
#ifdef BUILD_LINUX
    CellularProfileStruct profile = cellular_test_profile.input.stIfInput;
    profile.ProfileID = 202;
    OK(cellular_hal_profile_create(&profile, cellular_profile_callback));
    OK(cellular_hal_profile_delete(&profile, cellular_profile_callback));
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().profile_status, DEVICE_PROFILE_STATUS_DELETED);
    ERROR(cellular_hal_profile_delete(&profile, cellular_profile_callback));
#endif
}

static void test_profile_modify(void)
{
    ARRANGE();
    ERROR(cellular_hal_profile_modify(NULL, cellular_profile_callback));
#ifdef BUILD_LINUX
    CellularProfileStruct profile = cellular_test_profile.input.stIfInput;
    strcpy(profile.APN, "modified.invalid");
    OK(cellular_hal_profile_modify(&profile, cellular_profile_callback));
    ERROR(cellular_hal_profile_modify(&profile, NULL));
    profile.ProfileID = INT_MAX;
    ERROR(cellular_hal_profile_modify(&profile, cellular_profile_callback));
#endif
}

static void test_profile_list(void)
{
    CellularProfileStruct *profiles = NULL;
    int count = -1;
    ARRANGE();
    ERROR(cellular_hal_get_profile_list(NULL, &count));
    ERROR(cellular_hal_get_profile_list(&profiles, NULL));
    OK(cellular_hal_get_profile_list(&profiles, &count));
    CU_ASSERT_FATAL(count >= 0);
    if (count) {
        CU_ASSERT_PTR_NOT_NULL_FATAL(profiles);
        CU_ASSERT(cellular_string_valid(profiles[0].ProfileName, sizeof(profiles[0].ProfileName)));
        CU_ASSERT(memchr(profiles[0].Password, 0, sizeof(profiles[0].Password)) != NULL);
    }
    /* Do not free: no allocator/release contract is published. No password logs. */
}

static void test_start_network(void)
{
    ARRANGE();
    OK(cellular_hal_set_modem_network_attach());
    ERROR(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV4, NULL, NULL));
    OK(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV4, NULL, &cellular_network_callbacks));
    CU_ASSERT(cellular_callbacks_wait(CB_IP, 1));
    CU_ASSERT(cellular_callbacks_snapshot().valid);
}

static void test_stop_network(void)
{
    ARRANGE();
    OK(cellular_hal_set_modem_network_attach());
    OK(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV4, NULL, &cellular_network_callbacks));
    OK(cellular_hal_stop_network(CELLULAR_NETWORK_IP_FAMILY_IPV4));
#ifdef BUILD_LINUX
    ERROR(cellular_hal_stop_network(CELLULAR_NETWORK_IP_FAMILY_IPV4));
    ERROR(cellular_hal_stop_network(CELLULAR_NETWORK_IP_FAMILY_UNKNOWN));
#endif
}

static void test_signal(void)
{
    CellularSignalInfoStruct info;
    ARRANGE();
    ERROR(cellular_hal_get_signal_info(NULL));
    OK(cellular_hal_get_signal_info(&info));
    CU_ASSERT(info.RSSI >= -90 && info.RSSI <= -30);
    CU_ASSERT(info.RSRQ >= -19 && info.RSRQ <= -3);
    CU_ASSERT(info.RSRP >= -140 && info.RSRP <= -44);
    CU_ASSERT(info.SNR >= -20 && info.SNR <= 30);
    CU_ASSERT(info.TXPower >= 0 && info.TXPower <= 30);
}

static void test_location(void)
{
    CellLocationInfoStruct info;
    ARRANGE();
    ERROR(cellular_hal_get_cell_location_info(NULL));
    OK(cellular_hal_get_cell_location_info(&info));
    CU_ASSERT(info.bandInfo <= 0x7fff);
    /* The documented 36-bit range cannot fit unsigned int; no invented ABI. */
}

static void test_mode(void)
{
    ARRANGE();
#ifdef BUILD_LINUX
    ERROR(cellular_hal_set_modem_operating_configuration((CellularModemOperatingConfiguration_t)0));
    ERROR(cellular_hal_set_modem_operating_configuration((CellularModemOperatingConfiguration_t)6));
#endif
    OK(cellular_hal_set_modem_operating_configuration(CELLULAR_MODEM_SET_ONLINE));
}

static void test_imei(void)
{
    char value[16];
    ARRANGE();
    ERROR(cellular_hal_get_device_imei(NULL));
    OK(cellular_hal_get_device_imei(value));
    CU_ASSERT(cellular_digits_valid(value, sizeof(value)));
}

static void test_imei_sv(void)
{
    char value[16];
    ARRANGE();
    ERROR(cellular_hal_get_device_imei_sv(NULL));
    OK(cellular_hal_get_device_imei_sv(value));
    CU_ASSERT(cellular_digits_valid(value, sizeof(value)));
}

static void test_iccid(void)
{
    char value[21];
    ARRANGE();
    ERROR(cellular_hal_get_modem_current_iccid(NULL));
    OK(cellular_hal_get_modem_current_iccid(value));
    CU_ASSERT_FATAL(cellular_string_valid(value, sizeof(value)));
    size_t length = strlen(value);
    /* Both bounds are required; the legacy OR expression accepted anything. */
    CU_ASSERT(length >= 19 && length <= 20);
}

static void test_msisdn(void)
{
    char value[20];
    ARRANGE();
    ERROR(cellular_hal_get_modem_current_msisdn(NULL));
    OK(cellular_hal_get_modem_current_msisdn(value));
    CU_ASSERT(cellular_digits_valid(value, sizeof(value)));
}

static void test_statistics(void)
{
    CellularPacketStatsStruct statistics;
    ARRANGE();
    ERROR(cellular_hal_get_packet_statistics(NULL));
    OK(cellular_hal_get_packet_statistics(&statistics));
#ifdef BUILD_LINUX
    CU_ASSERT_EQUAL(statistics.BytesSent, 0);
    CU_ASSERT_EQUAL(statistics.BytesReceived, 0);
#endif
}

static void test_interface_status(void)
{
    CellularInterfaceStatus_t status;
    ARRANGE();
    ERROR(cellular_hal_get_current_modem_interface_status(NULL));
    OK(cellular_hal_get_current_modem_interface_status(&status));
    CU_ASSERT(status >= IF_UP && status <= IF_ERROR);
}

static void test_attach(void)
{
    ARRANGE();
#ifdef BUILD_LINUX
    OK(cellular_hal_sim_power_enable(1, 0));
    ERROR(cellular_hal_set_modem_network_attach());
    OK(cellular_hal_sim_power_enable(1, 1));
    OK(cellular_hal_select_device_slot(cellular_slot_callback));
#endif
    OK(cellular_hal_set_modem_network_attach());
#ifdef BUILD_LINUX
    ERROR(cellular_hal_set_modem_network_attach());
#endif
}

static void test_detach(void)
{
    ARRANGE();
#ifdef BUILD_LINUX
    /* The negative is explicitly arranged as not attached. */
    ERROR(cellular_hal_set_modem_network_detach());
#endif
    OK(cellular_hal_set_modem_network_attach());
    OK(cellular_hal_set_modem_network_detach());
#ifdef BUILD_LINUX
    ERROR(cellular_hal_set_modem_network_detach());
#endif
}

static void test_firmware(void)
{
    char value[128];
    ARRANGE();
    ERROR(cellular_hal_get_modem_firmware_version(NULL));
    OK(cellular_hal_get_modem_firmware_version(value));
    CU_ASSERT_FATAL(cellular_string_valid(value, sizeof(value)));
    CU_ASSERT(strlen(value) >= 1 && strlen(value) < sizeof(value));
}

static void test_plmn(void)
{
    CellularCurrentPlmnInfoStruct info;
    ARRANGE();
    ERROR(cellular_hal_get_current_plmn_information(NULL));
    OK(cellular_hal_get_current_plmn_information(&info));
    CU_ASSERT(cellular_string_valid(info.plmn_name, sizeof(info.plmn_name)));
    CU_ASSERT(info.MCC <= 999 && info.MNC <= 999 && info.roaming_enabled <= 1);
}

static void test_scan(void)
{
    CellularNetworkScanResultInfoStruct *networks = NULL;
    unsigned int count = 0;
    ARRANGE();
    ERROR(cellular_hal_get_available_networks_information(NULL, &count));
    ERROR(cellular_hal_get_available_networks_information(&networks, NULL));
    OK(cellular_hal_get_available_networks_information(&networks, &count));
    CU_ASSERT(count <= 1100000);
    if (count) {
        CU_ASSERT_PTR_NOT_NULL_FATAL(networks);
        CU_ASSERT(cellular_string_valid(networks[0].network_name, sizeof(networks[0].network_name)));
        CU_ASSERT(networks[0].MCC <= 999 && networks[0].MNC <= 999);
    }
}

static void test_preferred_rat(void)
{
    char value[128];
    ARRANGE();
    ERROR(cellular_hal_get_modem_preferred_radio_technology(NULL));
    OK(cellular_hal_get_modem_preferred_radio_technology(value));
    CU_ASSERT(cellular_string_valid(value, sizeof(value)));
}

static void test_set_rat(void)
{
    char supported[] = "UMTS", value[128];
    ARRANGE();
    ERROR(cellular_hal_set_modem_preferred_radio_technology(NULL));
    /* UMTS is explicitly supported by the published contract, not a negative. */
    OK(cellular_hal_set_modem_preferred_radio_technology(supported));
    OK(cellular_hal_get_modem_preferred_radio_technology(value));
    CU_ASSERT_STRING_EQUAL(value, supported);
}

static void test_current_rat(void)
{
    char value[128];
    ARRANGE();
    ERROR(cellular_hal_get_modem_current_radio_technology(NULL));
    OK(cellular_hal_get_modem_current_radio_technology(value));
    CU_ASSERT(cellular_string_valid(value, sizeof(value)));
}

static void test_supported_rat(void)
{
    char value[128];
    ARRANGE();
    ERROR(cellular_hal_get_modem_supported_radio_technology(NULL));
    OK(cellular_hal_get_modem_supported_radio_technology(value));
    CU_ASSERT(cellular_string_valid(value, sizeof(value)));
}

static void test_factory_reset(void)
{
    ARRANGE();
#ifdef BUILD_LINUX
    if (cellular_test_profile.allow_resets) {
        OK(cellular_hal_modem_factory_reset());
        CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), FALSE);
    }
#endif
}

static void test_reset(void)
{
    ARRANGE();
#ifdef BUILD_LINUX
    if (cellular_test_profile.allow_resets) {
        OK(cellular_hal_modem_reset());
        CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), FALSE);
    }
#endif
}

typedef struct { const char *name; CU_TestFunc test; } L1Case;
/* PUBLIC_INTERFACE */
/** Register one independently reported function-level case per public API. */
int test_cellular_hal_l1_register(void)
{
    static const L1Case cases[] = {
        {"IsModemDevicePresent", test_present}, {"init", test_init},
        {"open_device", test_open}, {"IsModemControlInterfaceOpened", test_control_open},
        {"select_device_slot", test_select_slot}, {"sim_power_enable", test_sim_power},
        {"get_total_no_of_uicc_slots", test_slots_count}, {"get_uicc_slot_info", test_slot_info},
        {"get_active_card_status", test_card_status}, {"monitor_device_registration", test_registration},
        {"profile_create", test_profile_create}, {"profile_delete", test_profile_delete},
        {"profile_modify", test_profile_modify}, {"get_profile_list", test_profile_list},
        {"start_network", test_start_network}, {"stop_network", test_stop_network},
        {"get_signal_info", test_signal}, {"get_cell_location_info", test_location},
        {"set_modem_operating_configuration", test_mode}, {"get_device_imei", test_imei},
        {"get_device_imei_sv", test_imei_sv}, {"get_modem_current_iccid", test_iccid},
        {"get_modem_current_msisdn", test_msisdn}, {"get_packet_statistics", test_statistics},
        {"get_current_modem_interface_status", test_interface_status},
        {"set_modem_network_attach", test_attach}, {"set_modem_network_detach", test_detach},
        {"get_modem_firmware_version", test_firmware}, {"get_current_plmn_information", test_plmn},
        {"get_available_networks_information", test_scan},
        {"get_modem_preferred_radio_technology", test_preferred_rat},
        {"set_modem_preferred_radio_technology", test_set_rat},
        {"get_modem_current_radio_technology", test_current_rat},
        {"get_modem_supported_radio_technology", test_supported_rat},
        {"modem_factory_reset", test_factory_reset}, {"modem_reset", test_reset}
    };
    CU_pSuite suite = CU_add_suite("L1.cellular", NULL, cellular_fixture_end);
    if (!suite)
        return RETURN_ERROR;
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i)
        if (!CU_add_test(suite, cases[i].name, cases[i].test))
            return RETURN_ERROR;
    return RETURN_OK;
}
