#include "test_cellular_common.h"

/* PUBLIC_INTERFACE */
/** Register every native suite, stopping on the first failed registration. */
int register_cellular_tests(void)
{
    if (test_cellular_contract_register() != RETURN_OK ||
        test_cellular_hal_l1_register() != RETURN_OK ||
        test_cellular_hal_l2_register() != RETURN_OK)
        return RETURN_ERROR;
    return RETURN_OK;
}
