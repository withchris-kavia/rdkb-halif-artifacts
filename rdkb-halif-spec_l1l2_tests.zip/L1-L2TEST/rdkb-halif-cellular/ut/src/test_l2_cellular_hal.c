#include "test_cellular_common.h"
#include <TestDB.h>
#include <limits.h>
#include <stddef.h>

/* Model-policy checks only: not hardware acceptance or invented vendor behavior.
 * Each sequence starts fresh, checks intermediate state, and is quiesced by the
 * next fixture/reset or suite cleanup even after a fatal assertion.
 */
#ifdef BUILD_LINUX
#define OK(call) CU_ASSERT_EQUAL((call), RETURN_OK)
#define ERROR(call) CU_ASSERT_EQUAL((call), RETURN_ERROR)
#define ARRANGE() CU_ASSERT_EQUAL_FATAL(cellular_fixture_begin(), RETURN_OK)

static void assert_interface(CellularInterfaceStatus_t expected)
{
    CellularInterfaceStatus_t actual = IF_UNKNOWN;
    OK(cellular_hal_get_current_modem_interface_status(&actual));
    CU_ASSERT_EQUAL(actual, expected);
}

static void init_open(void)
{
    cellular_fixture_reset();
    CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), FALSE);
    ERROR(cellular_hal_open_device(&cellular_device_callbacks));
    OK(cellular_hal_init(&cellular_test_profile.input));
    cellular_test_defer_callbacks(true);
    CellularDeviceContextCBStruct local = cellular_device_callbacks;
    OK(cellular_hal_open_device(&local));
    memset(&local, 0, sizeof(local)); /* Registration must copy, not retain this address. */
    CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), TRUE);
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().count[CB_OPEN], 0);
    cellular_test_dispatch();
    CU_ASSERT(cellular_callbacks_wait(CB_OPEN, 1));
    CU_ASSERT(cellular_callbacks_snapshot().valid);
    ERROR(cellular_hal_open_device(&cellular_device_callbacks));
    ERROR(cellular_hal_init(&cellular_test_profile.input));
    CU_ASSERT_EQUAL(cellular_fixture_end(), RETURN_OK);
    CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), FALSE);
    OK(cellular_hal_init(&cellular_test_profile.input));
    OK(cellular_hal_open_device(&cellular_device_callbacks));
}

static void slot_sim(void)
{
    CellularUICCSlotInfoStruct first, second;
    CellularUICCStatus_t status;
    unsigned int count;
    ARRANGE();
    OK(cellular_hal_get_total_no_of_uicc_slots(&count));
    CU_ASSERT_EQUAL(count, 2);
    OK(cellular_hal_get_uicc_slot_info(1, &first));
    OK(cellular_hal_get_uicc_slot_info(2, &second));
    CU_ASSERT(first.CardEnable && second.CardEnable);
    OK(cellular_hal_set_modem_network_attach());
    OK(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV4, NULL, &cellular_network_callbacks));
    OK(cellular_hal_sim_power_enable(1, 0));
    assert_interface(IF_DOWN);
    OK(cellular_hal_get_active_card_status(&status));
    CU_ASSERT_EQUAL(status, CELLULAR_UICC_STATUS_EMPTY);
    ERROR(cellular_hal_set_modem_network_attach());
    ERROR(cellular_hal_select_device_slot(cellular_slot_callback));
    OK(cellular_hal_get_uicc_slot_info(1, &first));
    OK(cellular_hal_get_uicc_slot_info(2, &second));
    CU_ASSERT(!first.CardEnable && second.CardEnable);
    ERROR(cellular_hal_sim_power_enable(UINT_MAX, 1));
    ERROR(cellular_hal_sim_power_enable(3, 1));
    OK(cellular_hal_sim_power_enable(1, 1));
    OK(cellular_hal_select_device_slot(cellular_slot_callback));
    OK(cellular_hal_get_active_card_status(&status));
    CU_ASSERT_EQUAL(status, CELLULAR_UICC_STATUS_VALID);
    OK(cellular_hal_set_modem_network_attach());
    assert_interface(IF_DORMANT);
}

static void registration_attach_detach(void)
{
    CellularCurrentPlmnInfoStruct plmn;
    ARRANGE();
    OK(cellular_hal_monitor_device_registration(cellular_registration_callback));
    CU_ASSERT(cellular_callbacks_wait(CB_REGISTRATION, 1));
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().registration, DEVICE_NAS_STATUS_NOT_REGISTERED);
    ERROR(cellular_hal_set_modem_network_detach());
    OK(cellular_hal_set_modem_network_attach());
    CU_ASSERT(cellular_callbacks_wait(CB_REGISTRATION, 2));
    CellularCallbackRecord snapshot = cellular_callbacks_snapshot();
    CU_ASSERT_EQUAL(snapshot.registration, DEVICE_NAS_STATUS_REGISTERED);
    CU_ASSERT_EQUAL(snapshot.service, CELLULAR_MODEM_REGISTERED_SERVICE_PS);
    OK(cellular_hal_get_current_plmn_information(&plmn));
    CU_ASSERT_EQUAL(plmn.registration_status, DEVICE_REGISTERED);
    ERROR(cellular_hal_set_modem_network_attach());
    OK(cellular_hal_set_modem_network_detach());
    CU_ASSERT(cellular_callbacks_wait(CB_REGISTRATION, 3));
    snapshot = cellular_callbacks_snapshot();
    CU_ASSERT_EQUAL(snapshot.registration, DEVICE_NAS_STATUS_NOT_REGISTERED);
    CU_ASSERT_EQUAL(snapshot.service, CELLULAR_MODEM_REGISTERED_SERVICE_NONE);
    CU_ASSERT(snapshot.valid);
    OK(cellular_hal_get_current_plmn_information(&plmn));
    CU_ASSERT_EQUAL(plmn.registration_status, DEVICE_NOT_REGISTERED);
    assert_interface(IF_DOWN);
}

static void profile_crud(void)
{
    CellularProfileStruct *list = NULL;
    CellularProfileStruct created = cellular_test_profile.input.stIfInput;
    int count = 0, original;
    ARRANGE();
    OK(cellular_hal_get_profile_list(&list, &original));
    CU_ASSERT_EQUAL(original, 1);
    created.ProfileID = 202;
    strcpy(created.ProfileName, "L2 temporary");
    OK(cellular_hal_profile_create(&created, cellular_profile_callback));
    CU_ASSERT(cellular_callbacks_wait(CB_PROFILE, 1));
    CU_ASSERT_STRING_EQUAL(cellular_callbacks_snapshot().profile_id, "202");
    OK(cellular_hal_get_profile_list(&list, &count));
    CU_ASSERT_EQUAL(count, original + 1);
    CU_ASSERT_EQUAL(list[count - 1].ProfileID, 202);
    strcpy(created.APN, "updated.invalid");
    OK(cellular_hal_profile_modify(&created, cellular_profile_callback));
    OK(cellular_hal_get_profile_list(&list, &count));
    CU_ASSERT_STRING_EQUAL(list[count - 1].APN, "updated.invalid");
    CellularProfileStruct invalid = created;
    memset(invalid.Username, 'x', sizeof(invalid.Username));
    ERROR(cellular_hal_profile_modify(&invalid, cellular_profile_callback));
    ERROR(cellular_hal_profile_create(&created, cellular_profile_callback));
    OK(cellular_hal_get_profile_list(&list, &count));
    CU_ASSERT_STRING_EQUAL(list[count - 1].APN, "updated.invalid");
    OK(cellular_hal_profile_delete(&created, cellular_profile_callback));
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().profile_status, DEVICE_PROFILE_STATUS_DELETED);
    ERROR(cellular_hal_profile_delete(&created, cellular_profile_callback));
    OK(cellular_hal_get_profile_list(&list, &count));
    CU_ASSERT_EQUAL(count, original);
    OK(cellular_hal_profile_create(NULL, cellular_profile_callback));
    /* Exercise the reference capacity and unknown-ID allocation. */
    created.ProfileID = CELLULAR_PROFILE_ID_UNKNOWN;
    for (int i = 1; i < 8; ++i)
        OK(cellular_hal_profile_create(&created, cellular_profile_callback));
    ERROR(cellular_hal_profile_create(&created, cellular_profile_callback));
    OK(cellular_hal_get_profile_list(&list, &count));
    CU_ASSERT_EQUAL(count, 8);
    for (int i = 0; i < count; ++i)
        for (int j = i + 1; j < count; ++j)
            CU_ASSERT_NOT_EQUAL(list[i].ProfileID, list[j].ProfileID);
    CU_ASSERT(cellular_callbacks_snapshot().valid);
    /* The borrowed snapshot remains usable until the next list call/reset. */
    for (int i = 0; i < count; ++i) {
        CellularProfileStruct saved = list[i];
        OK(cellular_hal_profile_delete(&saved, cellular_profile_callback));
    }
    OK(cellular_hal_get_profile_list(&list, &count));
    CU_ASSERT_EQUAL(count, 0);
    CU_ASSERT_PTR_NULL(list);
    ERROR(cellular_hal_profile_create(NULL, cellular_profile_callback));
    /* Borrowed output: no free() assumption is made. */
}

static void network_dual_stack(void)
{
    ARRANGE();
    ERROR(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV4, NULL, &cellular_network_callbacks));
    OK(cellular_hal_set_modem_network_attach());
    assert_interface(IF_DORMANT);
    unsigned int before = cellular_callbacks_snapshot().events;
    OK(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV4, NULL, &cellular_network_callbacks));
    OK(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV6,
                                  &cellular_test_profile.input.stIfInput, &cellular_network_callbacks));
    CU_ASSERT(cellular_callbacks_wait(CB_IP, 2));
    CellularCallbackRecord snapshot = cellular_callbacks_snapshot();
    CU_ASSERT(snapshot.valid);
    CU_ASSERT_EQUAL(snapshot.order[before], CB_PACKET);
    CU_ASSERT_EQUAL(snapshot.order[before + 1], CB_IP);
    CU_ASSERT_EQUAL(snapshot.order[before + 2], CB_PACKET);
    CU_ASSERT_EQUAL(snapshot.order[before + 3], CB_IP);
    CU_ASSERT_EQUAL(snapshot.ip[0].IPType, CELLULAR_NETWORK_IP_FAMILY_IPV4);
    CU_ASSERT_EQUAL(snapshot.ip[1].IPType, CELLULAR_NETWORK_IP_FAMILY_IPV6);
    CU_ASSERT_STRING_EQUAL(snapshot.ip[0].IPAddress, "192.0.2.2");
    CU_ASSERT_STRING_EQUAL(snapshot.ip[1].IPAddress, "2001:db8::2");
    assert_interface(IF_UP);
    ERROR(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV4, NULL, &cellular_network_callbacks));
    ERROR(cellular_hal_stop_network(CELLULAR_NETWORK_IP_FAMILY_UNSPECIFIED));
    ERROR(cellular_hal_profile_modify(&cellular_test_profile.input.stIfInput, cellular_profile_callback));
    OK(cellular_hal_stop_network(CELLULAR_NETWORK_IP_FAMILY_IPV4));
    snapshot = cellular_callbacks_snapshot();
    CU_ASSERT_EQUAL(snapshot.packet_status[0], DEVICE_NETWORK_STATUS_DISCONNECTED);
    CU_ASSERT_EQUAL(snapshot.packet_status[1], DEVICE_NETWORK_STATUS_CONNECTED);
    assert_interface(IF_UP);
    OK(cellular_hal_stop_network(CELLULAR_NETWORK_IP_FAMILY_IPV6));
    assert_interface(IF_DORMANT);
    /* Detach also tears down an active family and reports the disconnection. */
    OK(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV6, NULL, &cellular_network_callbacks));
    OK(cellular_hal_set_modem_network_detach());
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().packet_status[1], DEVICE_NETWORK_STATUS_DISCONNECTED);
    assert_interface(IF_DOWN);
}

static void rat_fallback(void)
{
    char rat[128], current[128], supported[128], too_long[128];
    char *values[] = {"AUTO", "CDMA20001X", "EVDO", "GSM", "UMTS", "LTE"};
    ARRANGE();
    OK(cellular_hal_get_modem_supported_radio_technology(supported));
    for (size_t i = 0; i < sizeof(values) / sizeof(values[0]); ++i) {
        CU_ASSERT_PTR_NOT_NULL(strstr(supported, values[i]));
        OK(cellular_hal_set_modem_preferred_radio_technology(values[i]));
        OK(cellular_hal_get_modem_preferred_radio_technology(rat));
        CU_ASSERT_STRING_EQUAL(rat, values[i]);
        OK(cellular_hal_get_modem_current_radio_technology(current));
        CU_ASSERT_STRING_EQUAL(current, i ? values[i] : "LTE");
    }
    OK(cellular_hal_set_modem_preferred_radio_technology("unsupported-reference-RAT"));
    OK(cellular_hal_get_modem_preferred_radio_technology(rat));
    CU_ASSERT_STRING_EQUAL(rat, "AUTO");
    memset(too_long, 'x', sizeof(too_long));
    ERROR(cellular_hal_set_modem_preferred_radio_technology(too_long));
    ERROR(cellular_hal_set_modem_preferred_radio_technology(NULL));
    OK(cellular_hal_get_modem_preferred_radio_technology(rat));
    CU_ASSERT_STRING_EQUAL(rat, "AUTO");
}

static void operating_modes_reset(void)
{
    char rat[128];
    CellularProfileStruct profile = cellular_test_profile.input.stIfInput, *list;
    int count;
    ARRANGE();
    if (!cellular_test_profile.allow_resets) {
        puts("L2.07 reset/mode mutations not authorized by selected profile; not executed.");
        return;
    }
    OK(cellular_hal_set_modem_network_attach());
    OK(cellular_hal_set_modem_operating_configuration(CELLULAR_MODEM_SET_OFFLINE));
    assert_interface(IF_DOWN);
    ERROR(cellular_hal_set_modem_network_attach());
    OK(cellular_hal_set_modem_operating_configuration(CELLULAR_MODEM_SET_LOW_POWER_MODE));
    ERROR(cellular_hal_set_modem_network_attach());
    OK(cellular_hal_set_modem_operating_configuration(CELLULAR_MODEM_SET_ONLINE));
    OK(cellular_hal_set_modem_network_attach());
    profile.ProfileID = 202;
    OK(cellular_hal_profile_create(&profile, cellular_profile_callback));
    OK(cellular_hal_set_modem_preferred_radio_technology("UMTS"));
    OK(cellular_hal_modem_reset());
    CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), FALSE);
    OK(cellular_hal_open_device(&cellular_device_callbacks));
    OK(cellular_hal_get_modem_preferred_radio_technology(rat));
    CU_ASSERT_STRING_EQUAL(rat, "UMTS");
    OK(cellular_hal_get_profile_list(&list, &count));
    CU_ASSERT_EQUAL(count, 2);
    OK(cellular_hal_modem_factory_reset());
    CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), FALSE);
    OK(cellular_hal_open_device(&cellular_device_callbacks));
    OK(cellular_hal_get_modem_preferred_radio_technology(rat));
    CU_ASSERT_STRING_EQUAL(rat, "AUTO");
    OK(cellular_hal_get_profile_list(&list, &count));
    CU_ASSERT_EQUAL(count, 1);
    CU_ASSERT_EQUAL(list[0].ProfileID, cellular_test_profile.input.stIfInput.ProfileID);
    /* Exercise reset operating-configuration aliases, not just convenience APIs. */
    OK(cellular_hal_set_modem_operating_configuration(CELLULAR_MODEM_SET_RESET));
    OK(cellular_hal_open_device(&cellular_device_callbacks));
    OK(cellular_hal_set_modem_operating_configuration(CELLULAR_MODEM_SET_FACTORY_RESET));
    OK(cellular_hal_open_device(&cellular_device_callbacks));
}

static void telemetry(void)
{
    CellularPacketStatsStruct seed = {0}, actual;
    CellularSignalInfoStruct signal;
    CellLocationInfoStruct location;
    CellularCurrentPlmnInfoStruct plmn;
    struct { char value[16]; unsigned char canary[8]; } imei;
    ARRANGE();
    seed.BytesSent = ULONG_MAX;
    seed.BytesReceived = ULONG_MAX - 1;
    seed.PacketsSent = 17;
    seed.PacketsReceived = 19;
    seed.PacketsSentDrop = 1;
    seed.PacketsReceivedDrop = 2;
    seed.UpStreamMaxBitRate = 1000000;
    seed.DownStreamMaxBitRate = 2000000;
    cellular_test_seed_statistics(&seed);
    OK(cellular_hal_get_packet_statistics(&actual));
#define COUNTER(field) CU_ASSERT_EQUAL(actual.field, seed.field)
    COUNTER(BytesSent); COUNTER(BytesReceived); COUNTER(PacketsSent); COUNTER(PacketsReceived);
    COUNTER(PacketsSentDrop); COUNTER(PacketsReceivedDrop);
    COUNTER(UpStreamMaxBitRate); COUNTER(DownStreamMaxBitRate);
#undef COUNTER
    OK(cellular_hal_get_packet_statistics(&actual));
    CU_ASSERT_EQUAL(actual.BytesSent, ULONG_MAX);
    OK(cellular_hal_get_signal_info(&signal));
    CU_ASSERT(signal.RSSI >= -90 && signal.RSSI <= -30);
    CU_ASSERT(signal.RSRP >= -140 && signal.RSRP <= -44);
    OK(cellular_hal_get_cell_location_info(&location));
    OK(cellular_hal_get_current_plmn_information(&plmn));
    CU_ASSERT_EQUAL(location.globalCellId, plmn.cell_id);
    CU_ASSERT(location.bandInfo <= 0x7fff);
    memset(&imei, 0xa5, sizeof(imei));
    OK(cellular_hal_get_device_imei(imei.value));
    CU_ASSERT(cellular_digits_valid(imei.value, sizeof(imei.value)));
    for (size_t i = 0; i < sizeof(imei.canary); ++i)
        CU_ASSERT_EQUAL(imei.canary[i], 0xa5);
    char small[8];
    ERROR(cellular_profile_string("cellular.config.profile.ProfileName", small, sizeof(small)));
    CU_ASSERT_EQUAL(small[0], '\0');
}

/* Exercise the one-shot fault entry of every one of the 34 status-returning APIs. */
static int fault_call(unsigned int index, unsigned char *output, size_t capacity)
{
    CellularProfileStruct *profiles;
    CellularNetworkScanResultInfoStruct *networks;
    int profile_count;
    unsigned int count;
    (void)capacity;
    switch (index) {
    case 0: return cellular_hal_init(&cellular_test_profile.input);
    case 1: return cellular_hal_open_device(&cellular_device_callbacks);
    case 2: return cellular_hal_select_device_slot(cellular_slot_callback);
    case 3: return cellular_hal_sim_power_enable(1, 0);
    case 4: return cellular_hal_get_total_no_of_uicc_slots((unsigned int *)output);
    case 5: return cellular_hal_get_uicc_slot_info(1, (CellularUICCSlotInfoStruct *)output);
    case 6: return cellular_hal_get_active_card_status((CellularUICCStatus_t *)output);
    case 7: return cellular_hal_monitor_device_registration(cellular_registration_callback);
    case 8: return cellular_hal_profile_create(NULL, cellular_profile_callback);
    case 9: return cellular_hal_profile_delete(&cellular_test_profile.input.stIfInput, cellular_profile_callback);
    case 10: return cellular_hal_profile_modify(&cellular_test_profile.input.stIfInput, cellular_profile_callback);
    case 11:
        profiles = (CellularProfileStruct *)output;
        profile_count = -99;
        {
            int result = cellular_hal_get_profile_list(&profiles, &profile_count);
            CU_ASSERT_PTR_EQUAL(profiles, output);
            CU_ASSERT_EQUAL(profile_count, -99);
            return result;
        }
    case 12: return cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV4, NULL, &cellular_network_callbacks);
    case 13: return cellular_hal_stop_network(CELLULAR_NETWORK_IP_FAMILY_IPV4);
    case 14: return cellular_hal_get_signal_info((CellularSignalInfoStruct *)output);
    case 15: return cellular_hal_get_cell_location_info((CellLocationInfoStruct *)output);
    case 16: return cellular_hal_set_modem_operating_configuration(CELLULAR_MODEM_SET_OFFLINE);
    case 17: return cellular_hal_get_device_imei((char *)output);
    case 18: return cellular_hal_get_device_imei_sv((char *)output);
    case 19: return cellular_hal_get_modem_current_iccid((char *)output);
    case 20: return cellular_hal_get_modem_current_msisdn((char *)output);
    case 21: return cellular_hal_get_packet_statistics((CellularPacketStatsStruct *)output);
    case 22: return cellular_hal_get_current_modem_interface_status((CellularInterfaceStatus_t *)output);
    case 23: return cellular_hal_set_modem_network_attach();
    case 24: return cellular_hal_set_modem_network_detach();
    case 25: return cellular_hal_get_modem_firmware_version((char *)output);
    case 26: return cellular_hal_get_current_plmn_information((CellularCurrentPlmnInfoStruct *)output);
    case 27:
        networks = (CellularNetworkScanResultInfoStruct *)output;
        count = UINT_MAX;
        {
            int result = cellular_hal_get_available_networks_information(&networks, &count);
            CU_ASSERT_PTR_EQUAL(networks, output);
            CU_ASSERT_EQUAL(count, UINT_MAX);
            return result;
        }
    case 28: return cellular_hal_get_modem_preferred_radio_technology((char *)output);
    case 29: return cellular_hal_set_modem_preferred_radio_technology("UMTS");
    case 30: return cellular_hal_get_modem_current_radio_technology((char *)output);
    case 31: return cellular_hal_get_modem_supported_radio_technology((char *)output);
    case 32: return cellular_hal_modem_factory_reset();
    case 33: return cellular_hal_modem_reset();
    default: return RETURN_OK;
    }
}

static void errors_preserve_state(void)
{
    /* Union provides alignment for every output type; failure must not touch it. */
    union { max_align_t alignment; unsigned char bytes[2048]; } output;
    ARRANGE();
    CellularCallbackRecord before = cellular_callbacks_snapshot();
    for (unsigned int i = 0; i < 34; ++i) {
        memset(output.bytes, 0xa5, sizeof(output.bytes));
        cellular_test_fail_next();
        ERROR(fault_call(i, output.bytes, sizeof(output.bytes)));
        for (size_t j = 0; j < sizeof(output.bytes); ++j)
            CU_ASSERT_EQUAL(output.bytes[j], 0xa5);
        CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), TRUE);
        assert_interface(IF_DOWN);
        CellularCallbackRecord after = cellular_callbacks_snapshot();
        CU_ASSERT_EQUAL(after.events, before.events);
        CellularProfileStruct *list;
        int count;
        OK(cellular_hal_get_profile_list(&list, &count));
        CU_ASSERT_EQUAL(count, 1);
        CU_ASSERT_EQUAL(list[0].ProfileID, cellular_test_profile.input.stIfInput.ProfileID);
    }
    CellularProfileStruct bad = cellular_test_profile.input.stIfInput;
    bad.PDPAuthentication = (CellularPDPAuthentication_t)99;
    ERROR(cellular_hal_profile_modify(&bad, cellular_profile_callback));
    ERROR(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_UNKNOWN, NULL, &cellular_network_callbacks));
    OK(cellular_hal_set_modem_network_attach()); /* Injected failure did not attach. */
    assert_interface(IF_DORMANT);
}

static void *dispatch_worker(void *unused)
{
    (void)unused;
    cellular_test_dispatch();
    return NULL;
}

static void isolation_callback_safety(void)
{
    ARRANGE();
    cellular_test_defer_callbacks(true);
    OK(cellular_hal_monitor_device_registration(cellular_registration_callback));
    OK(cellular_hal_set_modem_network_attach());
    CellularProfileStruct created = cellular_test_profile.input.stIfInput;
    created.ProfileID = 202;
    OK(cellular_hal_profile_create(&created, cellular_profile_callback));
    created.ProfileID = 999; /* Callback ID must refer to committed event snapshot. */
    CellularNetworkCBStruct local = cellular_network_callbacks;
    OK(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV4, NULL, &local));
    OK(cellular_hal_start_network(CELLULAR_NETWORK_IP_FAMILY_IPV6, NULL, &local));
    memset(&local, 0, sizeof(local));
    pthread_t worker;
    int status = pthread_create(&worker, NULL, dispatch_worker, NULL);
    CU_ASSERT_EQUAL_FATAL(status, 0);
    CU_ASSERT_EQUAL(pthread_join(worker, NULL), 0);
    CU_ASSERT(cellular_callbacks_wait(CB_PROFILE, 1));
    CU_ASSERT_STRING_EQUAL(cellular_callbacks_snapshot().profile_id, "202");
    CU_ASSERT(cellular_callbacks_wait(CB_IP, 2));
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().count[CB_PACKET], 2);
    CU_ASSERT_STRING_EQUAL(cellular_callbacks_snapshot().ip[0].IPAddress, "192.0.2.2");
    CU_ASSERT_STRING_EQUAL(cellular_callbacks_snapshot().ip[1].IPAddress, "2001:db8::2");
    CU_ASSERT(cellular_callbacks_snapshot().valid);
    /* All seven callback kinds are exercised across the isolated scenarios. */
    cellular_test_set_present(false);
    cellular_test_dispatch();
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().count[CB_REMOVE], 1);
    CU_ASSERT_EQUAL(cellular_hal_IsModemControlInterfaceOpened(), FALSE);
    CU_ASSERT_EQUAL(cellular_hal_IsModemDevicePresent(), FALSE);
    ERROR(cellular_hal_set_modem_network_attach());
    ARRANGE();
    cellular_test_defer_callbacks(true);
    OK(cellular_hal_monitor_device_registration(cellular_registration_callback));
    unsigned int before = cellular_callbacks_snapshot().events;
    cellular_test_reset(); /* Quiesce and discard before recorder storage can be reused. */
    cellular_test_dispatch();
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().events, before);
    ARRANGE();
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().count[CB_PROFILE], 0);
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().count[CB_REGISTRATION], 0);
    /* Queue saturation is bounded and returns error before overwriting payloads. */
    cellular_test_defer_callbacks(true);
    unsigned int queued = 0;
    while (queued < 64 && cellular_hal_monitor_device_registration(cellular_registration_callback) == RETURN_OK)
        ++queued;
    CU_ASSERT(queued > 0 && queued < 64);
    cellular_test_reset();
    cellular_test_dispatch();
    CU_ASSERT_EQUAL(cellular_callbacks_snapshot().count[CB_REGISTRATION], 0);
}
#endif

/* PUBLIC_INTERFACE */
/** Register all ten model scenarios only where Linux controls are compiled in. */
int test_cellular_hal_l2_register(void)
{
#ifdef BUILD_LINUX
    static const struct { const char *name; CU_TestFunc test; } cases[] = {
        {"L2.01-init-open", init_open},
        {"L2.02-slot-SIM", slot_sim},
        {"L2.03-registration-attach-detach", registration_attach_detach},
        {"L2.04-profile-CRUD", profile_crud},
        {"L2.05-IPv4-IPv6-network", network_dual_stack},
        {"L2.06-RAT-fallback", rat_fallback},
        {"L2.07-opt-in-modes-reset", operating_modes_reset},
        {"L2.08-telemetry", telemetry},
        {"L2.09-errors-preserve-state", errors_preserve_state},
        {"L2.10-isolation-callback-safety", isolation_callback_safety}
    };
    CU_pSuite suite = CU_add_suite("L2.cellular.reference", NULL, cellular_fixture_end);
    if (!suite)
        return RETURN_ERROR;
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i)
        if (!CU_add_test(suite, cases[i].name, cases[i].test))
            return RETURN_ERROR;
#endif
    return RETURN_OK;
}
