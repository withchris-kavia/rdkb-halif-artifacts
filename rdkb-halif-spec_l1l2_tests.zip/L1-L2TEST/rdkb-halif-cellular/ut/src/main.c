#include "test_cellular_common.h"
#include <ut.h>
#include <TestDB.h>
#include <TestRun.h>
#include <CUError.h>
#include <limits.h>

static ut_kvp_instance_t *profile_instance;
static unsigned int tests_run, failures, suites_failed;
static CU_ErrorCode execution_error;
static bool captured;

/* PUBLIC_INTERFACE */
/** Safely load a profile without the assertion in ut-core's profile wrapper. */
ut_kvp_status_t __wrap_ut_kvp_profile_open(char *filename)
{
    if (profile_instance)
        ut_kvp_destroyInstance(profile_instance);
    profile_instance = ut_kvp_createInstance();
    if (!profile_instance)
        return UT_KVP_STATUS_INVALID_INSTANCE;
    ut_kvp_status_t status = ut_kvp_open(profile_instance, filename);
    if (status != UT_KVP_STATUS_SUCCESS) {
        ut_kvp_destroyInstance(profile_instance);
        profile_instance = NULL;
    }
    return status;
}

/* PUBLIC_INTERFACE */
/** Return the component-owned active profile. */
ut_kvp_instance_t *__wrap_ut_kvp_profile_getInstance(void)
{
    return profile_instance;
}

/* PUBLIC_INTERFACE */
/** Close and destroy profile storage; safe when cleanup is repeated. */
void __wrap_ut_kvp_profile_close(void)
{
    if (profile_instance)
        ut_kvp_destroyInstance(profile_instance);
    profile_instance = NULL;
}

extern void __real_CU_cleanup_registry(void);
/* PUBLIC_INTERFACE */
/** Snapshot run results before the unmodified framework erases CUnit state. */
void __wrap_CU_cleanup_registry(void)
{
    if (CU_get_registry()) {
        tests_run = CU_get_number_of_tests_run();
        failures = CU_get_number_of_failures();
        suites_failed = CU_get_number_of_suites_failed();
        execution_error = CU_get_error();
        captured = true;
    }
    __real_CU_cleanup_registry();
}

#ifdef BUILD_LINUX
static const char *fault;
static void diagnostic_test(void)
{
    CU_ASSERT(!fault || strcmp(fault, "assertion"));
}
static int diagnostic_setup(void)
{
    return fault && !strcmp(fault, "setup") ? 1 : 0;
}
static int diagnostic_cleanup(void)
{
    return fault && !strcmp(fault, "cleanup") ? 1 : 0;
}
#endif

static void usage(const char *program)
{
    printf("Usage: %s [-b|-a] [-p profile.yaml] [-l log-directory] [--suite all|L1|L2]\n",
           program);
#ifdef BUILD_LINUX
    puts("Linux harness verification: --harness-fault assertion|registration|setup|cleanup|zero");
#endif
}

/* PUBLIC_INTERFACE */
/**
 * Run the native component suite. Arguments select a validated profile, mode,
 * log directory and level. Return zero only after nonempty, failure-free execution.
 */
int main(int argc, char **argv)
{
    char default_profile[PATH_MAX];
    const char *profile = NULL, *level = "all";
    char **core_argv = calloc((size_t)argc + 3, sizeof(*core_argv));
    int core_argc = 0, result = EXIT_FAILURE;
    if (!core_argv)
        return EXIT_FAILURE;
    core_argv[core_argc++] = argv[0];
    core_argv[core_argc++] = "-b";
    for (int i = 1; i < argc; ++i) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
            usage(argv[0]);
            free(core_argv);
            return EXIT_SUCCESS;
        }
        if (!strcmp(argv[i], "-b") || !strcmp(argv[i], "-a")) {
            core_argv[core_argc++] = argv[i];
        } else if (!strcmp(argv[i], "-p") || !strcmp(argv[i], "--suite") ||
                   !strcmp(argv[i], "-l")
#ifdef BUILD_LINUX
                   || !strcmp(argv[i], "--harness-fault")
#endif
        ) {
            const char *option = argv[i++];
            if (i == argc || !argv[i][0]) {
                fprintf(stderr, "Missing argument for %s\n", option);
                goto done;
            }
            if (!strcmp(option, "-p")) {
                if (profile) {
                    fputs("Specify only one profile\n", stderr);
                    goto done;
                }
                profile = argv[i];
            } else if (!strcmp(option, "--suite")) {
                level = argv[i];
            } else if (!strcmp(option, "-l")) {
                core_argv[core_argc++] = "-l";
                core_argv[core_argc++] = argv[i];
#ifdef BUILD_LINUX
            } else {
                fault = argv[i];
#endif
            }
        } else {
            fprintf(stderr, "Unknown argument: %s\n", argv[i]);
            goto done;
        }
    }
    if (strcmp(level, "all") && strcmp(level, "L1") && strcmp(level, "L2")) {
        fprintf(stderr, "Invalid suite: %s\n", level);
        goto done;
    }
#ifdef BUILD_LINUX
    if (fault && strcmp(fault, "assertion") && strcmp(fault, "registration") &&
        strcmp(fault, "setup") && strcmp(fault, "cleanup") && strcmp(fault, "zero")) {
        fprintf(stderr, "Invalid harness fault: %s\n", fault);
        goto done;
    }
#endif
    if (!profile) {
        ssize_t size = readlink("/proc/self/exe", default_profile, sizeof(default_profile) - 1);
        if (size < 0 || (size_t)size >= sizeof(default_profile) - 1)
            goto done;
        default_profile[size] = 0;
        char *separator = strrchr(default_profile, '/');
        if (!separator)
            goto done;
        *separator = 0;
        size_t used = strlen(default_profile);
        const char suffix[] = "/../profiles/include/cellular_profile.yaml";
        if (used + sizeof(suffix) > sizeof(default_profile))
            goto done;
        memcpy(default_profile + used, suffix, sizeof(suffix));
        profile = default_profile;
    }
    if (__wrap_ut_kvp_profile_open((char *)profile) != UT_KVP_STATUS_SUCCESS ||
        cellular_profile_load() != RETURN_OK) {
        fprintf(stderr, "Profile preflight failed: %s\n", profile);
        goto done;
    }
    if (UT_init(core_argc, core_argv) != UT_STATUS_OK) {
        fputs("UT initialization failed\n", stderr);
        goto done;
    }
    if (register_cellular_tests() != RETURN_OK || CU_get_error() != CUE_SUCCESS) {
        fputs("Suite registration failed\n", stderr);
        goto cleanup;
    }
#ifdef BUILD_LINUX
    if (fault && !strcmp(fault, "registration")) {
        /* Exercise a real CUnit registration error, not a fabricated successful run. */
        if (!CU_add_test(NULL, "invalid-suite", diagnostic_test)) {
            fputs("Injected registration failure detected\n", stderr);
            goto cleanup;
        }
    }
    if (fault && strcmp(fault, "registration") && strcmp(fault, "zero")) {
        CU_pSuite diagnostic = CU_add_suite("harness.diagnostic", diagnostic_setup, diagnostic_cleanup);
        if (!diagnostic || !CU_add_test(diagnostic, "failure-exit", diagnostic_test))
            goto cleanup;
    }
#endif
    CU_set_fail_on_inactive(CU_FALSE);
    for (CU_pSuite suite = CU_get_registry()->pSuite; suite; suite = suite->pNext) {
        bool active = !strcmp(level, "all") || !strncmp(suite->pName, level, strlen(level));
#ifdef BUILD_LINUX
        if (fault)
            active = strcmp(fault, "zero") && !strcmp(suite->pName, "harness.diagnostic");
#endif
        if (CU_set_suite_active(suite, active ? CU_TRUE : CU_FALSE) != CUE_SUCCESS)
            goto cleanup;
    }
    UT_status_t status = UT_run_tests();
    fprintf(stderr, "Cellular result: tests=%u failures=%u suites_failed=%u error=%d\n",
            tests_run, failures, suites_failed, execution_error);
    if (status == UT_STATUS_OK && captured && tests_run && !failures && !suites_failed &&
        execution_error == CUE_SUCCESS)
        result = EXIT_SUCCESS;
    goto done;
cleanup:
    CU_cleanup_registry();
done:
    __wrap_ut_kvp_profile_close();
    free(core_argv);
    return result;
}
