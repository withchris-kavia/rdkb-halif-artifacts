#ifndef CELLULAR_HAL_TEST_CONTROL_H
#define CELLULAR_HAL_TEST_CONTROL_H
#ifndef BUILD_LINUX
#error "Reference-model controls must never enter a vendor build"
#endif
#include "cellular_hal.h"
/* PUBLIC_INTERFACE */
/** Quiesce callbacks, discard queued payloads and restore the reference baseline. */
void cellular_test_reset(void);
/* PUBLIC_INTERFACE */
/** Select inline delivery or explicitly deferred delivery for callback tests. */
void cellular_test_defer_callbacks(bool defer);
/* PUBLIC_INTERFACE */
/** Drain owned event payloads; callbacks may re-enter HAL getters. */
void cellular_test_dispatch(void);
/* PUBLIC_INTERFACE */
/** Fail the next status-returning HAL API before state or output mutation. */
void cellular_test_fail_next(void);
/* PUBLIC_INTERFACE */
/** Seed presence, issuing the removal callback and closing state on removal. */
void cellular_test_set_present(bool present);
/* PUBLIC_INTERFACE */
/** Copy reference telemetry counters without retaining caller storage. */
void cellular_test_seed_statistics(const CellularPacketStatsStruct *statistics);
#endif
