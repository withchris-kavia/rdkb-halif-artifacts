/*
 * Linux reference model, not a modem driver.
 * Policy: initialize -> open -> select slot -> attach -> start data.
 * Slots are 1-based. Invalid inputs/order/fault injection return RETURN_ERROR
 * without changing outputs/state. Repeated attach/detach/start/stop are errors.
 * List outputs are borrowed model-owned snapshots, never caller-freed.
 * Legacy char* outputs require the capacities documented in cellular_hal.h.
 * Callback return codes are advisory; committed operations are not rolled back.
 */
#define _GNU_SOURCE
#include "cellular_hal_test_control.h"

#define MAX_PROFILES 8
#define MAX_EVENTS 64
typedef enum { EV_OPEN, EV_REMOVE, EV_SLOT, EV_REG, EV_PROFILE, EV_PACKET, EV_IP } EventKind;
typedef struct {
    EventKind kind;
    CellularDeviceContextCBStruct device;
    cellular_device_slot_status_api_callback slot;
    cellular_device_registration_status_callback registration;
    cellular_device_profile_status_api_callback profile;
    CellularNetworkCBStruct network;
    CellularIPStruct ip;
    char text[64];
    int value;
    int auxiliary;
} Event;
typedef struct {
    bool present, initialized, opened, selected, attached, defer, fail_next;
    bool powered[2], network_up[2];
    CellularModemOperatingConfiguration_t mode;
    CellularContextInitInputStruct input;
    CellularDeviceContextCBStruct device_cb;
    cellular_device_registration_status_callback registration_cb;
    CellularNetworkCBStruct network_cb[2];
    CellularProfileStruct profiles[MAX_PROFILES], snapshot[MAX_PROFILES];
    int profile_count;
    char rat[128];
    CellularPacketStatsStruct statistics;
    Event events[MAX_EVENTS];
    unsigned int queued;
} Model;

static Model model = { .present = true };
static pthread_mutex_t state_lock = PTHREAD_MUTEX_INITIALIZER;
/* Serializes callbacks with reset; recursive to allow callback-side HAL calls. */
static pthread_mutex_t delivery_lock = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;
static bool dispatching;

static void reset_locked(void)
{
    memset(&model, 0, sizeof(model));
    model.present = true;
    model.powered[0] = model.powered[1] = true;
    model.mode = CELLULAR_MODEM_SET_ONLINE;
    strcpy(model.rat, "AUTO");
}

static bool valid_string(const char *value, size_t size)
{
    return memchr(value, '\0', size) != NULL;
}

static bool valid_profile(const CellularProfileStruct *p)
{
    return p && p->ProfileID >= CELLULAR_PROFILE_ID_UNKNOWN &&
        p->PDPContextNumber >= CELLULAR_PDP_CONTEXT_UNKNOWN &&
        p->ProfileType >= CELLULAR_PROFILE_TYPE_3GPP &&
        p->ProfileType <= CELLULAR_PROFILE_TYPE_3GPP2 &&
        p->PDPType >= CELLULAR_PDP_TYPE_IPV4 && p->PDPType <= CELLULAR_PDP_TYPE_IPV4_OR_IPV6 &&
        p->PDPAuthentication >= CELLULAR_PDP_AUTHENTICATION_NONE &&
        p->PDPAuthentication <= CELLULAR_PDP_AUTHENTICATION_CHAP &&
        p->PDPNetworkConfig >= CELLULAR_PDP_NETWORK_CONFIG_NAS &&
        p->PDPNetworkConfig <= CELLULAR_PDP_NETWORK_CONFIG_DHCP &&
        valid_string(p->ProfileName, sizeof(p->ProfileName)) &&
        valid_string(p->APN, sizeof(p->APN)) &&
        valid_string(p->Username, sizeof(p->Username)) &&
        valid_string(p->Password, sizeof(p->Password)) &&
        valid_string(p->Proxy, sizeof(p->Proxy)) &&
        p->ProxyPort <= 65535 && p->bIsNoRoaming <= 1 &&
        p->bIsAPNDisabled <= 1 && p->bIsThisDefaultProfile <= 1;
}

static bool ready(bool need_open)
{
    bool fail = model.fail_next;
    model.fail_next = false;
    return !fail && model.present && model.initialized &&
        (!need_open || model.opened) && model.queued + 4 <= MAX_EVENTS;
}

static Event *event_new(EventKind kind)
{
    Event *event = &model.events[model.queued++];
    memset(event, 0, sizeof(*event));
    event->kind = kind;
    return event;
}

static void registration_event(void)
{
    if (model.registration_cb) {
        Event *event = event_new(EV_REG);
        event->registration = model.registration_cb;
        event->value = model.attached ? DEVICE_NAS_STATUS_REGISTERED : DEVICE_NAS_STATUS_NOT_REGISTERED;
    }
}

static void packet_event(int index, bool up)
{
    Event *event;
    if (model.network_cb[index].packet_service_status_cb) {
        event = event_new(EV_PACKET);
        event->network = model.network_cb[index];
        event->value = up ? DEVICE_NETWORK_STATUS_CONNECTED : DEVICE_NETWORK_STATUS_DISCONNECTED;
        event->auxiliary = index + 1;
    }
    if (up && model.network_cb[index].device_network_ip_ready_cb) {
        event = event_new(EV_IP);
        event->network = model.network_cb[index];
        event->ip.IPType = (CellularNetworkIPType_t)(index + 1);
        strcpy(event->ip.WANIFName, "wwan0");
        strcpy(event->ip.IPAddress, index ? "2001:db8::2" : "192.0.2.2");
        strcpy(event->ip.SubnetMask, index ? "ffff:ffff:ffff:ffff::" : "255.255.255.0");
        strcpy(event->ip.DefaultGateWay, index ? "2001:db8::1" : "192.0.2.1");
        strcpy(event->ip.DNSServer1, index ? "2001:db8::53" : "192.0.2.53");
        strcpy(event->ip.DNSServer2, index ? "2001:db8::54" : "192.0.2.54");
        strcpy(event->ip.Domains, "example.invalid");
        event->ip.MTUSize = 1500;
    }
}

static void disconnect_locked(void)
{
    for (int i = 0; i < 2; ++i) {
        if (model.network_up[i]) {
            model.network_up[i] = false;
            packet_event(i, false);
        }
    }
    model.attached = false;
    registration_event();
}

static void deliver(Event *event)
{
    char device[64] = "reference-modem", wan[64] = "wwan0";
    char slot[64] = "SIM1", type[64] = "USIM";
    switch (event->kind) {
    case EV_OPEN:
        event->device.device_open_status_cb(device, wan, DEVICE_OPEN_STATUS_READY,
                                           (CellularModemOperatingConfiguration_t)event->value);
        break;
    case EV_REMOVE:
        event->device.device_remove_status_cb(device, DEVICE_REMOVED);
        break;
    case EV_SLOT:
        event->slot(slot, type, 1, DEVICE_SLOT_STATUS_READY);
        break;
    case EV_REG:
        event->registration((CellularDeviceNASStatus_t)event->value, DEVICE_NAS_STATUS_ROAMING_OFF,
            event->value == DEVICE_NAS_STATUS_REGISTERED ? CELLULAR_MODEM_REGISTERED_SERVICE_PS :
                                                         CELLULAR_MODEM_REGISTERED_SERVICE_NONE);
        break;
    case EV_PROFILE:
        event->profile(event->text, (CellularPDPType_t)event->auxiliary,
                       (CellularDeviceProfileSelectionStatus_t)event->value);
        break;
    case EV_PACKET:
        event->network.packet_service_status_cb(device, (CellularNetworkIPType_t)event->auxiliary,
                                                (CellularNetworkPacketStatus_t)event->value);
        break;
    case EV_IP:
        event->network.device_network_ip_ready_cb(&event->ip, DEVICE_NETWORK_IP_READY);
        break;
    }
}

/* PUBLIC_INTERFACE */
/** Drain owned event snapshots outside the model lock, serialized with reset. */
void cellular_test_dispatch(void)
{
    pthread_mutex_lock(&delivery_lock);
    if (!dispatching) {
        dispatching = true;
        for (;;) {
            Event event;
            pthread_mutex_lock(&state_lock);
            if (!model.queued) {
                pthread_mutex_unlock(&state_lock);
                break;
            }
            event = model.events[0];
            --model.queued;
            memmove(model.events, model.events + 1, model.queued * sizeof(Event));
            pthread_mutex_unlock(&state_lock);
            deliver(&event);
        }
        dispatching = false;
    }
    pthread_mutex_unlock(&delivery_lock);
}

static int finish(int result)
{
    bool defer = model.defer;
    pthread_mutex_unlock(&state_lock);
    if (!defer)
        cellular_test_dispatch();
    return result;
}
#define BEGIN() pthread_mutex_lock(&state_lock)
#define REQUIRE(condition) do { if (!(condition)) return finish(RETURN_ERROR); } while (0)

/* PUBLIC_INTERFACE */
/** Quiesce delivery, erase callback registrations and restore the model baseline. */
void cellular_test_reset(void)
{
    pthread_mutex_lock(&delivery_lock);
    pthread_mutex_lock(&state_lock);
    reset_locked();
    pthread_mutex_unlock(&state_lock);
    pthread_mutex_unlock(&delivery_lock);
}

/* PUBLIC_INTERFACE */
/** Change delivery mode; callers explicitly drain deferred callbacks. */
void cellular_test_defer_callbacks(bool defer)
{
    BEGIN();
    model.defer = defer;
    pthread_mutex_unlock(&state_lock);
}

/* PUBLIC_INTERFACE */
/** Inject a one-shot status API failure before mutation. */
void cellular_test_fail_next(void)
{
    BEGIN();
    model.fail_next = true;
    pthread_mutex_unlock(&state_lock);
}

/* PUBLIC_INTERFACE */
/** Seed presence; removal invalidates open state and queues removal notification. */
void cellular_test_set_present(bool present)
{
    BEGIN();
    if (!present && model.present) {
        model.queued = 0;
        if (model.device_cb.device_remove_status_cb) {
            Event *event = event_new(EV_REMOVE);
            event->device = model.device_cb;
        }
        model.opened = model.selected = model.attached = model.initialized = false;
        memset(model.network_up, 0, sizeof(model.network_up));
    }
    model.present = present;
    (void)finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Copy caller-provided packet statistics without retaining caller storage. */
void cellular_test_seed_statistics(const CellularPacketStatsStruct *statistics)
{
    BEGIN();
    if (statistics)
        model.statistics = *statistics;
    pthread_mutex_unlock(&state_lock);
}

/* PUBLIC_INTERFACE */
/** Return deterministic device presence, independent of initialization. */
unsigned int cellular_hal_IsModemDevicePresent(void)
{
    unsigned int present;
    BEGIN();
    present = model.present;
    pthread_mutex_unlock(&state_lock);
    return present;
}

/* PUBLIC_INTERFACE */
/** Validate and copy initialization input, installing its default profile. */
int cellular_hal_init(CellularContextInitInputStruct *input)
{
    BEGIN();
    bool fail = model.fail_next;
    model.fail_next = false;
    REQUIRE(!fail && model.present && input && !model.opened &&
        input->enIPFamilyPreference >= IP_FAMILY_UNKNOWN &&
        input->enIPFamilyPreference <= IP_FAMILY_IPV4_IPV6 &&
        input->enPreferenceTechnology >= PREF_GPRS && input->enPreferenceTechnology <= PREF_NR &&
        valid_profile(&input->stIfInput));
    model.input = *input;
    model.initialized = true;
    model.mode = CELLULAR_MODEM_SET_ONLINE;
    model.powered[0] = model.powered[1] = true;
    if (!model.profile_count) {
        model.profiles[0] = input->stIfInput;
        if (model.profiles[0].ProfileID == CELLULAR_PROFILE_ID_UNKNOWN)
            model.profiles[0].ProfileID = 1;
        model.profile_count = 1;
    }
    if (!model.rat[0])
        strcpy(model.rat, "AUTO");
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Open once and copy both callback pointers before notifying readiness. */
int cellular_hal_open_device(CellularDeviceContextCBStruct *callbacks)
{
    BEGIN();
    REQUIRE(ready(false) && !model.opened && callbacks && callbacks->device_open_status_cb);
    model.device_cb = *callbacks;
    model.opened = true;
    Event *event = event_new(EV_OPEN);
    event->device = *callbacks;
    event->value = model.mode;
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Return whether the model control interface is open. */
unsigned char cellular_hal_IsModemControlInterfaceOpened(void)
{
    unsigned char opened;
    BEGIN();
    opened = model.opened;
    pthread_mutex_unlock(&state_lock);
    return opened;
}

/* PUBLIC_INTERFACE */
/** Select powered slot one and notify with callback-scoped 64-byte strings. */
int cellular_hal_select_device_slot(cellular_device_slot_status_api_callback callback)
{
    BEGIN();
    REQUIRE(ready(true) && callback && model.powered[0]);
    model.selected = true;
    Event *event = event_new(EV_SLOT);
    event->slot = callback;
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Set SIM power for one-based slot IDs; powering down slot one detaches data. */
int cellular_hal_sim_power_enable(unsigned int slot, unsigned char enable)
{
    BEGIN();
    REQUIRE(ready(true) && slot >= 1 && slot <= 2 && enable <= 1);
    model.powered[slot - 1] = enable;
    if (slot == 1 && !enable) {
        model.selected = false;
        disconnect_locked();
    }
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Return two reference UICC slots. */
int cellular_hal_get_total_no_of_uicc_slots(unsigned int *count)
{
    BEGIN();
    REQUIRE(ready(true) && count);
    *count = 2;
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Return a bounded slot snapshot; both slot index and power IDs are one-based. */
int cellular_hal_get_uicc_slot_info(unsigned int slot, CellularUICCSlotInfoStruct *info)
{
    BEGIN();
    REQUIRE(ready(true) && slot >= 1 && slot <= 2 && info);
    CellularUICCSlotInfoStruct value = {0};
    value.SlotEnable = 1;
    value.IsCardPresent = 1;
    value.CardEnable = model.powered[slot - 1];
    value.FormFactor = CELLULAR_UICC_FORM_FACTOR_4FF;
    value.Application = CELLULAR_UICC_APPLICATION_USIM;
    value.Status = value.CardEnable ? CELLULAR_UICC_STATUS_VALID : CELLULAR_UICC_STATUS_EMPTY;
    strcpy(value.MnoName, "Reference Network");
    strcpy(value.iccid, "8900000000000000001");
    strcpy(value.msisdn, "15555550100");
    *info = value;
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Return active SIM validity from selected and powered state. */
int cellular_hal_get_active_card_status(CellularUICCStatus_t *status)
{
    BEGIN();
    REQUIRE(ready(true) && status);
    *status = model.selected && model.powered[0] ? CELLULAR_UICC_STATUS_VALID : CELLULAR_UICC_STATUS_EMPTY;
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Register and immediately report the current NAS state. */
int cellular_hal_monitor_device_registration(cellular_device_registration_status_callback callback)
{
    BEGIN();
    REQUIRE(ready(true) && callback);
    model.registration_cb = callback;
    registration_event();
    return finish(RETURN_OK);
}

static int profile_index(int id)
{
    for (int i = 0; i < model.profile_count; ++i)
        if (model.profiles[i].ProfileID == id)
            return i;
    return -1;
}

static void profile_event(CellularProfileStruct *profile,
                          cellular_device_profile_status_api_callback callback, bool deleted)
{
    Event *event = event_new(EV_PROFILE);
    event->profile = callback;
    snprintf(event->text, sizeof(event->text), "%d", profile->ProfileID);
    event->auxiliary = profile->PDPType;
    event->value = deleted ? DEVICE_PROFILE_STATUS_DELETED : DEVICE_PROFILE_STATUS_READY;
}

/* PUBLIC_INTERFACE */
/** Create a bounded profile, or select the initialization default for NULL input. */
int cellular_hal_profile_create(CellularProfileStruct *profile,
                                cellular_device_profile_status_api_callback callback)
{
    BEGIN();
    REQUIRE(ready(true) && callback);
    if (!profile) {
        REQUIRE(model.profile_count > 0);
        profile_event(&model.profiles[0], callback, false);
    } else {
        REQUIRE(valid_profile(profile) && model.profile_count < MAX_PROFILES);
        CellularProfileStruct value = *profile;
        if (value.ProfileID == CELLULAR_PROFILE_ID_UNKNOWN) {
            value.ProfileID = 1;
            while (profile_index(value.ProfileID) >= 0)
                ++value.ProfileID;
        }
        REQUIRE(profile_index(value.ProfileID) < 0);
        model.profiles[model.profile_count++] = value;
        profile_event(&value, callback, false);
    }
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Delete an existing profile when no data family is active. */
int cellular_hal_profile_delete(CellularProfileStruct *profile,
                                cellular_device_profile_status_api_callback callback)
{
    BEGIN();
    REQUIRE(ready(true) && callback && valid_profile(profile) &&
            !model.network_up[0] && !model.network_up[1]);
    int index = profile_index(profile->ProfileID);
    REQUIRE(index >= 0);
    CellularProfileStruct value = model.profiles[index];
    --model.profile_count;
    memmove(&model.profiles[index], &model.profiles[index + 1],
            (size_t)(model.profile_count - index) * sizeof(value));
    profile_event(&value, callback, true);
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Replace an existing valid profile atomically while data is stopped. */
int cellular_hal_profile_modify(CellularProfileStruct *profile,
                                cellular_device_profile_status_api_callback callback)
{
    BEGIN();
    REQUIRE(ready(true) && callback && valid_profile(profile) &&
            !model.network_up[0] && !model.network_up[1]);
    int index = profile_index(profile->ProfileID);
    REQUIRE(index >= 0);
    model.profiles[index] = *profile;
    profile_event(profile, callback, false);
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Return a borrowed snapshot valid until the next profile-list call or reset. */
int cellular_hal_get_profile_list(CellularProfileStruct **profiles, int *count)
{
    BEGIN();
    REQUIRE(ready(true) && profiles && count);
    memcpy(model.snapshot, model.profiles, sizeof(model.snapshot));
    *profiles = model.profile_count ? model.snapshot : NULL;
    *count = model.profile_count;
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Start one IPv4/IPv6 family after attach; NULL profile selects the default. */
int cellular_hal_start_network(CellularNetworkIPType_t family, CellularProfileStruct *profile,
                              CellularNetworkCBStruct *callbacks)
{
    BEGIN();
    REQUIRE(ready(true) && model.attached && callbacks &&
        callbacks->packet_service_status_cb && callbacks->device_network_ip_ready_cb &&
        (family == CELLULAR_NETWORK_IP_FAMILY_IPV4 || family == CELLULAR_NETWORK_IP_FAMILY_IPV6));
    int index = family - 1;
    REQUIRE(!model.network_up[index] && model.profile_count > 0 &&
        (!profile || (valid_profile(profile) && profile_index(profile->ProfileID) >= 0)));
    CellularProfileStruct *selected = profile ? profile : &model.profiles[0];
    REQUIRE(!selected->bIsAPNDisabled &&
        (selected->PDPType == CELLULAR_PDP_TYPE_IPV4_OR_IPV6 ||
         (index == 0 && selected->PDPType == CELLULAR_PDP_TYPE_IPV4) ||
         (index == 1 && selected->PDPType == CELLULAR_PDP_TYPE_IPV6)));
    model.network_cb[index] = *callbacks;
    model.network_up[index] = true;
    packet_event(index, true);
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Stop a running family, preserving the other family's connection. */
int cellular_hal_stop_network(CellularNetworkIPType_t family)
{
    BEGIN();
    REQUIRE(ready(true) &&
        (family == CELLULAR_NETWORK_IP_FAMILY_IPV4 || family == CELLULAR_NETWORK_IP_FAMILY_IPV6));
    int index = family - 1;
    REQUIRE(model.network_up[index]);
    model.network_up[index] = false;
    packet_event(index, false);
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Return reference signal measurements within documented ranges. */
int cellular_hal_get_signal_info(CellularSignalInfoStruct *info)
{
    BEGIN();
    REQUIRE(ready(true) && info);
    *info = (CellularSignalInfoStruct){-65, -10, -90, 20, 15};
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Return a representable cell ID and band (the ABI cell ID is unsigned int). */
int cellular_hal_get_cell_location_info(CellLocationInfoStruct *info)
{
    BEGIN();
    REQUIRE(ready(true) && info);
    *info = (CellLocationInfoStruct){12345, 3, 12345};
    return finish(RETURN_OK);
}

static void reset_runtime(bool factory)
{
    disconnect_locked();
    model.opened = model.selected = false;
    model.mode = CELLULAR_MODEM_SET_ONLINE;
    memset(model.network_cb, 0, sizeof(model.network_cb));
    model.registration_cb = NULL;
    memset(&model.device_cb, 0, sizeof(model.device_cb));
    if (factory) {
        model.profile_count = 1;
        model.profiles[0] = model.input.stIfInput;
        if (model.profiles[0].ProfileID < 0)
            model.profiles[0].ProfileID = 1;
        strcpy(model.rat, "AUTO");
        memset(&model.statistics, 0, sizeof(model.statistics));
    }
}

/* PUBLIC_INTERFACE */
/** Apply a mode; offline/low-power detach, reset closes, factory reset restores defaults. */
int cellular_hal_set_modem_operating_configuration(CellularModemOperatingConfiguration_t mode)
{
    BEGIN();
    REQUIRE(ready(true) && mode >= CELLULAR_MODEM_SET_ONLINE &&
            mode <= CELLULAR_MODEM_SET_FACTORY_RESET);
    if (mode >= CELLULAR_MODEM_SET_RESET)
        reset_runtime(mode == CELLULAR_MODEM_SET_FACTORY_RESET);
    else {
        model.mode = mode;
        if (mode != CELLULAR_MODEM_SET_ONLINE)
            disconnect_locked();
    }
    return finish(RETURN_OK);
}

static int string_output(char *output, const char *value)
{
    BEGIN();
    REQUIRE(ready(true) && output);
    memcpy(output, value, strlen(value) + 1);
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Write a synthetic 15-digit IMEI to the contract's minimum 16-byte buffer. */
int cellular_hal_get_device_imei(char *output)
{
    return string_output(output, "000000000000001");
}
/* PUBLIC_INTERFACE */
/** Write a synthetic software version to a minimum 16-byte buffer. */
int cellular_hal_get_device_imei_sv(char *output)
{
    return string_output(output, "01");
}
/* PUBLIC_INTERFACE */
/** Write a synthetic ICCID to a minimum 21-byte buffer. */
int cellular_hal_get_modem_current_iccid(char *output)
{
    return string_output(output, "8900000000000000001");
}
/* PUBLIC_INTERFACE */
/** Write a synthetic MSISDN to a minimum 20-byte buffer. */
int cellular_hal_get_modem_current_msisdn(char *output)
{
    return string_output(output, "15555550100");
}
/* PUBLIC_INTERFACE */
/** Write a reference firmware version to a minimum 128-byte buffer. */
int cellular_hal_get_modem_firmware_version(char *output)
{
    return string_output(output, "reference-1.0");
}

/* PUBLIC_INTERFACE */
/** Return counters without mutating them during observation. */
int cellular_hal_get_packet_statistics(CellularPacketStatsStruct *statistics)
{
    BEGIN();
    REQUIRE(ready(true) && statistics);
    *statistics = model.statistics;
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Report UP for any running data family, DORMANT when attached, otherwise DOWN. */
int cellular_hal_get_current_modem_interface_status(CellularInterfaceStatus_t *status)
{
    BEGIN();
    REQUIRE(ready(true) && status);
    *status = model.network_up[0] || model.network_up[1] ? IF_UP : model.attached ? IF_DORMANT : IF_DOWN;
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Attach once after selecting a powered SIM while online. */
int cellular_hal_set_modem_network_attach(void)
{
    BEGIN();
    REQUIRE(ready(true) && model.selected && model.powered[0] &&
            model.mode == CELLULAR_MODEM_SET_ONLINE && !model.attached);
    model.attached = true;
    registration_event();
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Detach a registered device, disconnecting both data families. */
int cellular_hal_set_modem_network_detach(void)
{
    BEGIN();
    REQUIRE(ready(true) && model.attached);
    disconnect_locked();
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Return synthetic PLMN identity with registration state consistent with attach. */
int cellular_hal_get_current_plmn_information(CellularCurrentPlmnInfoStruct *info)
{
    BEGIN();
    REQUIRE(ready(true) && info);
    CellularCurrentPlmnInfoStruct value = {0};
    strcpy(value.plmn_name, "Reference Network");
    value.MCC = 1;
    value.MNC = 1;
    value.registration_status = model.attached ? DEVICE_REGISTERED : DEVICE_NOT_REGISTERED;
    value.registered_service = model.attached ? CELLULAR_MODEM_REGISTERED_SERVICE_PS :
                                              CELLULAR_MODEM_REGISTERED_SERVICE_NONE;
    value.area_code = 1;
    value.cell_id = 12345;
    *info = value;
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Return one borrowed immutable reference scan result; callers must not free it. */
int cellular_hal_get_available_networks_information(CellularNetworkScanResultInfoStruct **info,
                                                   unsigned int *count)
{
    static CellularNetworkScanResultInfoStruct network = {"Reference Network", 1, 1, 1};
    BEGIN();
    REQUIRE(ready(true) && info && count);
    *info = &network;
    *count = 1;
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Copy the preferred RAT to a minimum 128-byte output buffer. */
int cellular_hal_get_modem_preferred_radio_technology(char *output)
{
    BEGIN();
    REQUIRE(ready(true) && output);
    strcpy(output, model.rat);
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Accept listed RATs including UMTS; unsupported strings fall back to AUTO. */
int cellular_hal_set_modem_preferred_radio_technology(char *rat)
{
    static const char *const supported[] = {"AUTO", "CDMA20001X", "EVDO", "GSM", "UMTS", "LTE"};
    BEGIN();
    REQUIRE(ready(true) && rat && strnlen(rat, 128) < 128);
    const char *selected = "AUTO";
    for (size_t i = 0; i < sizeof(supported) / sizeof(supported[0]); ++i)
        if (strcmp(rat, supported[i]) == 0)
            selected = supported[i];
    strcpy(model.rat, selected);
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Report LTE for AUTO, otherwise the selected reference technology. */
int cellular_hal_get_modem_current_radio_technology(char *output)
{
    BEGIN();
    REQUIRE(ready(true) && output);
    strcpy(output, strcmp(model.rat, "AUTO") == 0 ? "LTE" : model.rat);
    return finish(RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Write the supported reference RAT list to a minimum 128-byte buffer. */
int cellular_hal_get_modem_supported_radio_technology(char *output)
{
    return string_output(output, "AUTO,CDMA20001X,EVDO,GSM,UMTS,LTE");
}

/* PUBLIC_INTERFACE */
/** Restore initialization defaults and close the control interface. */
int cellular_hal_modem_factory_reset(void)
{
    return cellular_hal_set_modem_operating_configuration(CELLULAR_MODEM_SET_FACTORY_RESET);
}

/* PUBLIC_INTERFACE */
/** Close transient state while retaining profiles, RAT and counters. */
int cellular_hal_modem_reset(void)
{
    return cellular_hal_set_modem_operating_configuration(CELLULAR_MODEM_SET_RESET);
}
