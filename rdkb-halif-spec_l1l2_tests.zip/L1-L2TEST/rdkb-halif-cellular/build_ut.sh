#!/usr/bin/env bash
# Build the component test repository without masking child failures.
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DIR="$SCRIPT_DIR"

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
    printf '%s\n' 'Usage: build_ut.sh [--dir directory] [make arguments...]'
    exit 0
fi
if [[ "${1:-}" == "--dir" ]]; then
    [[ $# -ge 2 && -n "$2" ]] || { echo "--dir requires a directory" >&2; exit 2; }
    DIR="$2"
    shift 2
fi
if [[ ! -d "$DIR/ut" ]]; then
    REMOTE="$(git -C "$SCRIPT_DIR" remote get-url origin)"
    TEST_REPO="${TEST_REPO:-${REMOTE//halif/halif-test}}"
    TEST_REPO="${TEST_REPO//hal-/haltest-/}"
    mkdir -p -- "$DIR"
    git clone -- "$TEST_REPO" "$DIR/ut"
    git -C "$DIR/ut" checkout "${UT_PROJECT_VERSION:-main}"
fi
cd -- "$DIR/ut"
exec ./build.sh "$@"
