#!/usr/bin/env bash

# *
# * If not stated otherwise in this file or this component's LICENSE file the
# * following copyright and licenses apply:
# *
# * Copyright 2023 RDK Management
# *
# * Licensed under the Apache License, Version 2.0 (the "License");
# * you may not use this file except in compliance with the License.
# * You may obtain a copy of the License at
# *
# * http://www.apache.org/licenses/LICENSE-2.0
# *
# * Unless required by applicable law or agreed to in writing, software
# * distributed under the License is distributed on an "AS IS" BASIS,
# * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# * See the License for the specific language governing permissions and
# * limitations under the License.
# *

set -euo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
DIR="${SCRIPT_DIR}"
UT_PROJECT_VERSION="${UT_PROJECT_VERSION:-main}"

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
    echo "Script to build the unit testing suite"
    echo " build_ut.sh [--dir DIRECTORY] [make arguments...]"
    echo " clean - clean the testing"
    echo " TARGET=xxx - build linux skeletons or the target vendor library"
    echo " --dir DIRECTORY - build directory (must be first)"
    echo " No arguments - build Linux tests using skeletons"
    exit 0
fi

if [[ "${1:-}" == "--dir" ]]; then
    if [[ $# -lt 2 || -z "$2" || "$2" == -* ]]; then
        echo "--dir requires a build directory" >&2
        exit 1
    fi
    DIR="$2"
    shift 2
fi

UT_DIR="${DIR}/ut"

if [[ ! -e "${UT_DIR}" ]]; then
    # Derive the companion repository only when it actually needs cloning.
    # Every Git operation is explicitly scoped; never fall back to the parent.
    TEST_REPO=$(git -C "${SCRIPT_DIR}" remote get-url origin)
    TEST_REPO="${TEST_REPO//halif/halif-test}"
    TEST_REPO="${TEST_REPO//hal-/haltest-}"
    echo "Cloning unit test suite for this module [${DIR}]"
    mkdir -p -- "${DIR}"
    git clone -- "${TEST_REPO}" "${UT_DIR}"
    if [[ ! -e "${UT_DIR}/.git" ]]; then
        echo "Clone did not create a unit test Git repository: ${UT_DIR}" >&2
        exit 1
    fi
    git -C "${UT_DIR}" checkout "${UT_PROJECT_VERSION}"
fi

if [[ ! -d "${UT_DIR}" || ! -f "${UT_DIR}/build.sh" || ! -r "${UT_DIR}/build.sh" ]]; then
    echo "Missing or unreadable unit test build script: ${UT_DIR}/build.sh" >&2
    exit 1
fi

# No recursion or trailing popd can mask the build's status. Invoke the known
# Bash interpreter even when a newly cloned script lacks its executable bit.
cd -- "${UT_DIR}"
exec bash ./build.sh "$@"
