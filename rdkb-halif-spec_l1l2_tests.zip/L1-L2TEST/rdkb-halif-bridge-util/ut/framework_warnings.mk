# SPDX-License-Identifier: Apache-2.0
# GNU make prelude for the unmodified upstream build. Never relax diagnostics
# for bridge-util tests, fixtures, or skeleton sources.
ifneq ($(strip $(BUILD_DIR)),)
# These framework routines already check failure returns. Disable only their
# internal aborts so invalid profiles/registration produce harness status 1.
$(BUILD_DIR)/ut-core/src/ut_kvp_profile.o: override XCFLAGS += -DNDEBUG
$(BUILD_DIR)/ut-core/src/c_source/ut_cunit.o: override XCFLAGS += -DNDEBUG
endif

# Upstream makefiles locate themselves through the first MAKEFILE_LIST entry.
# A preloaded file must not change that convention.
MAKEFILE_LIST := $(filter-out %/framework_warnings.mk,$(MAKEFILE_LIST))
