/* SPDX-License-Identifier: Apache-2.0 */
#ifndef BRIDGE_UTIL_TEST_SUPPORT_H
#define BRIDGE_UTIL_TEST_SUPPORT_H

#include <stdbool.h>
#include <stddef.h>

#include "bridge_util_hal.h"

/** Profile data shared by native suites; never populated by unchecked macros. */
typedef struct {
    bridgeDetails details;
    char bridge_name[BRIDGE_NAME_SIZE];
    char iface_name[IFACE_NAME_SIZE];
    char update_iface[IFACE_NAME_SIZE];
    char remove_iface[IFACE_NAME_SIZE];
    char iface_list[TOTAL_IFLIST_SIZE];
    char expected_list[TOTAL_IFLIST_SIZE];
    char vendor_ifaces[TOTAL_IFLIST_SIZE];
    int instance;
    bool linux_reference;
    int create_operation;
    int delete_operation;
    int attach_operation;
    int detach_operation;
} bridge_util_fixture_t;

/* PUBLIC_INTERFACE */
/**
 * Load one scalar from the active KVP profile using the actual destination size.
 * Return 0 only if complete and terminated. Return -1 for missing, nonscalar,
 * truncated or invalid inputs, clearing a valid destination to an empty string.
 * The caller must provide a writable capacity-byte buffer and a terminated key.
 */
int bridge_util_profile_string(const char *key, char *destination, size_t capacity);

/* PUBLIC_INTERFACE */
/**
 * Validate/load the active profile atomically into fixture; return 0 or -1.
 * Failure leaves fixture untouched. Numeric strings are parsed strictly, Config
 * follows the compiled enum (5 is absent), and all policy fields are required.
 * Linux builds require the explicit linux-reference operation/ownership policy.
 * Vendor profiles must select vendor and supply their own operation values.
 */
int bridge_util_fixture_load(bridge_util_fixture_t *fixture);

/* PUBLIC_INTERFACE */
/**
 * Prepare isolated model state from a loaded fixture; return 0 or -1.
 * Linux resets all state before seeding the bridge and vendor list; failure
 * resets again. Vendor builds do not call test helpers or mutate device state.
 */
int bridge_util_fixture_prepare(const bridge_util_fixture_t *fixture);

#endif
