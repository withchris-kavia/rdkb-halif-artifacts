/*
 * Copyright 2023 RDK Management
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @file test_l1_bridge_util_contract.c
 * Contract sources: include/bridge_util_hal.h and include/network_interface.h.
 * Check declaration types/layout without assuming a host-specific total ABI
 * size. Hook acceptance is tested only against the isolated Linux reference.
 * Logging checks intentionally exercise the existing macro, not a replacement.
 */
#include <stddef.h>
#include <string.h>
#include <ut.h>

#include "bridge_util_test_support.h"
#include "network_interface.h"

/* ut-core and the public log macro already require the GNU C dialect. */
#define TYPE_IS(value, type) \
    _Static_assert(__builtin_types_compatible_p(__typeof__(value), type), \
                   #value " has changed type")
#define AFTER(type, first, second) \
    _Static_assert(offsetof(type, second) >= \
                   offsetof(type, first) + sizeof(((type *)0)->first), \
                   #type " member order changed")

TYPE_IS(DeviceMode, int);
TYPE_IS(MocaIsolation_Val, int);
TYPE_IS(need_wifi_gw_refresh, int);
TYPE_IS(need_switch_gw_refresh, int);
TYPE_IS(syncMembers, int);
TYPE_IS(BridgeOprInPropgress, int);
TYPE_IS(PORT2ENABLE, int);
TYPE_IS(ethWanEnabled, int);
TYPE_IS(logFp, FILE *);
TYPE_IS(log_buff, char[MAX_LOG_BUFF_SIZE]);
TYPE_IS(log_msg_wtime, char[MAX_LOG_BUFF_SIZE + TIMESTAMP]);
TYPE_IS(primaryBridgeName, char[64]);
TYPE_IS(ethWanIfaceName, char[64]);
TYPE_IS(timeinfo, struct tm *);
TYPE_IS(utc_time, time_t);

TYPE_IS(((bridgeDetails *)0)->bridgeName, char[BRIDGE_NAME_SIZE]);
TYPE_IS(((bridgeDetails *)0)->vlan_name, char[BRIDGE_NAME_SIZE]);
TYPE_IS(((bridgeDetails *)0)->VirtualParentIfname, char[BRIDGE_NAME_SIZE]);
TYPE_IS(((bridgeDetails *)0)->vlanID, int);
TYPE_IS(((bridgeDetails *)0)->ethIfList, char[IFLIST_SIZE]);
TYPE_IS(((bridgeDetails *)0)->MoCAIfList, char[IFLIST_SIZE]);
TYPE_IS(((bridgeDetails *)0)->GreIfList, char[IFLIST_SIZE]);
TYPE_IS(((bridgeDetails *)0)->WiFiIfList, char[IFLIST_SIZE]);
AFTER(bridgeDetails, bridgeName, vlan_name);
AFTER(bridgeDetails, vlan_name, VirtualParentIfname);
AFTER(bridgeDetails, VirtualParentIfname, vlanID);
AFTER(bridgeDetails, vlanID, ethIfList);
AFTER(bridgeDetails, ethIfList, MoCAIfList);
AFTER(bridgeDetails, MoCAIfList, GreIfList);
AFTER(bridgeDetails, GreIfList, WiFiIfList);

TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->if_name, char[MAX_IF_NAME_SIZE]);
TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->inet_addr, char[MAX_IP_ADDR_SIZE]);
TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->netmask, char[MAX_IP_ADDR_SIZE]);
TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->gre_remote_inet_addr,
        char[MAX_IP_ADDR_SIZE]);
TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->gre_local_inet_addr,
        char[MAX_IP_ADDR_SIZE]);
TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->parent_ifname, char[MAX_IF_NAME_SIZE]);
TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->parent_bridge,
        char[MAX_BRIDGE_NAME_SIZE]);
TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->mtu, int);
TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->vlan_id, int);
TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->if_type, IF_TYPE);
TYPE_IS(((Gateway_Config_Non_Ovs_Bridge *)0)->if_cmd, BR_CMD);
AFTER(Gateway_Config_Non_Ovs_Bridge, if_name, inet_addr);
AFTER(Gateway_Config_Non_Ovs_Bridge, inet_addr, netmask);
AFTER(Gateway_Config_Non_Ovs_Bridge, netmask, gre_remote_inet_addr);
AFTER(Gateway_Config_Non_Ovs_Bridge, gre_remote_inet_addr, gre_local_inet_addr);
AFTER(Gateway_Config_Non_Ovs_Bridge, gre_local_inet_addr, parent_ifname);
AFTER(Gateway_Config_Non_Ovs_Bridge, parent_ifname, parent_bridge);
AFTER(Gateway_Config_Non_Ovs_Bridge, parent_bridge, mtu);
AFTER(Gateway_Config_Non_Ovs_Bridge, mtu, vlan_id);
AFTER(Gateway_Config_Non_Ovs_Bridge, vlan_id, if_type);
AFTER(Gateway_Config_Non_Ovs_Bridge, if_type, if_cmd);

#undef TYPE_IS
#undef AFTER

static bridge_util_fixture_t fixture;

static const struct {
    int actual;
    int expected;
} configuration_values[] = {
    {PRIVATE_LAN, 1}, {HOME_SECURITY, 2}, {HOTSPOT_2G, 3}, {HOTSPOT_5G, 4},
    {LOST_N_FOUND, 6}, {HOTSPOT_SECURE_2G, 7}, {HOTSPOT_SECURE_5G, 8},
    {MOCA_ISOLATION, 9}, {MESH_BACKHAUL, 10}, {ETH_BACKHAUL, 11}, {MESH, 12},
    {MESH_WIFI_BACKHAUL_2G, 13}, {MESH_WIFI_BACKHAUL_5G, 14},
    {MESH_ONBOARD, 18}, {MESH_WIFI_ONBOARD_2G, 19},
#ifdef WIFI_MANAGE_SUPPORTED
    {MANAGE_WIFI_BRIDGE, 17},
#endif
#if defined(AMENITIES_NETWORK_ENABLED) && !defined(_CBR2_PRODUCT_REQ_)
    {AMENITY_BRIDGE_2G, 20}, {AMENITY_BRIDGE_5G, 21}, {AMENITY_BRIDGE_6G, 22},
#endif
};

typedef struct {
    FILE *file;
    char message[MAX_LOG_BUFF_SIZE];
    char timestamped[MAX_LOG_BUFF_SIZE + TIMESTAMP];
    struct tm *time;
    time_t utc;
} log_snapshot_t;

static void save_logging(log_snapshot_t *saved)
{
    saved->file = logFp;
    memcpy(saved->message, log_buff, sizeof(saved->message));
    memcpy(saved->timestamped, log_msg_wtime, sizeof(saved->timestamped));
    saved->time = timeinfo;
    saved->utc = utc_time;
}

static void restore_logging(const log_snapshot_t *saved)
{
    logFp = saved->file;
    memcpy(log_buff, saved->message, sizeof(saved->message));
    memcpy(log_msg_wtime, saved->timestamped, sizeof(saved->timestamped));
    timeinfo = saved->time;
    utc_time = saved->utc;
}

static int suite_init(void)
{
    return bridge_util_fixture_load(&fixture);
}

static void test_constants_and_bridge_details(void)
{
    UT_ASSERT_EQUAL(TOTAL_IFLIST_SIZE, 1024);
    UT_ASSERT_EQUAL(BRIDGE_NAME_SIZE, 64);
    UT_ASSERT_EQUAL(IFACE_NAME_SIZE, 64);
    UT_ASSERT_EQUAL(IFLIST_SIZE, 256);
    UT_ASSERT_EQUAL(MAX_LOG_BUFF_SIZE, 1024);
    UT_ASSERT_EQUAL(TIMESTAMP, 64);
    UT_ASSERT_EQUAL(INTERFACE_EXIST, 0);
    UT_ASSERT_EQUAL(INTERFACE_NOT_EXIST, -1);
    UT_ASSERT_STRING_EQUAL("/rdklogs/logs/bridgeUtils.log", BRIDGE_UTIL_LOG_FNAME);
    UT_ASSERT_STRING_EQUAL("/etc/utopia/service.d/service_multinet/handle_gre.sh",
                           GRE_HANDLER_SCRIPT);

    const int types[] = {
        IF_BRIDGE_BRIDGEUTIL, IF_VLAN_BRIDGEUTIL, IF_GRE_BRIDGEUTIL,
        IF_MOCA_BRIDGEUTIL, IF_WIFI_BRIDGEUTIL, IF_ETH_BRIDGEUTIL,
        IF_OTHER_BRIDGEUTIL
    };
    for (size_t i = 0; i < sizeof(types) / sizeof(types[0]); ++i)
        UT_ASSERT_EQUAL(types[i], (int)i + 1);
    UT_ASSERT_EQUAL(DELETE_BRIDGE, 0);
    UT_ASSERT_EQUAL(CREATE_BRIDGE, 1);

    bridgeDetails details = fixture.details;
    UT_ASSERT_STRING_EQUAL(fixture.bridge_name, details.bridgeName);
    UT_ASSERT_EQUAL(details.vlanID, fixture.details.vlanID);
    UT_ASSERT_TRUE(sizeof(details.WiFiIfList) == IFLIST_SIZE);
}

static void test_gateway_contract(void)
{
    UT_ASSERT_EQUAL(MAX_IF_NAME_SIZE, 16);
    UT_ASSERT_EQUAL(MAX_IP_ADDR_SIZE, 16);
    UT_ASSERT_EQUAL(MAX_BRIDGE_NAME_SIZE, 16);
    const IF_TYPE types[] = {
        OTHER_IF_TYPE, BRIDGE_IF_TYPE, ETH_IF_TYPE, GRE_IF_TYPE, VLAN_IF_TYPE
    };
    const BR_CMD commands[] = {IF_UP_CMD, IF_DOWN_CMD, IF_DELETE_CMD, BR_REMOVE_CMD};
    for (size_t i = 0; i < sizeof(types) / sizeof(types[0]); ++i)
        UT_ASSERT_EQUAL(types[i], (int)i);
    for (size_t i = 0; i < sizeof(commands) / sizeof(commands[0]); ++i)
        UT_ASSERT_EQUAL(commands[i], (int)i);

    Gateway_Config_Non_Ovs_Bridge gateway = {0};
    char *fields[] = {
        gateway.if_name, gateway.inet_addr, gateway.netmask,
        gateway.gre_remote_inet_addr, gateway.gre_local_inet_addr,
        gateway.parent_ifname, gateway.parent_bridge
    };
    /* Each declared capacity is 16, including its NUL. Exercise the last slot. */
    for (size_t i = 0; i < sizeof(fields) / sizeof(fields[0]); ++i) {
        memset(fields[i], 'a' + (int)i, MAX_IF_NAME_SIZE - 1U);
        fields[i][MAX_IF_NAME_SIZE - 1U] = '\0';
    }
    gateway.mtu = 1500;
    gateway.vlan_id = 10;
    gateway.if_type = VLAN_IF_TYPE;
    gateway.if_cmd = IF_UP_CMD;
    for (size_t i = 0; i < sizeof(fields) / sizeof(fields[0]); ++i) {
        UT_ASSERT_TRUE(strlen(fields[i]) == MAX_IF_NAME_SIZE - 1U);
        for (size_t j = 0; j < MAX_IF_NAME_SIZE - 1U; ++j)
            UT_ASSERT_EQUAL(fields[i][j], 'a' + (int)i);
    }
    UT_ASSERT_EQUAL(gateway.mtu, 1500);
    UT_ASSERT_EQUAL(gateway.vlan_id, 10);
    UT_ASSERT_EQUAL(gateway.if_type, VLAN_IF_TYPE);
    UT_ASSERT_EQUAL(gateway.if_cmd, IF_UP_CMD);
}

static void test_config_values(void)
{
    for (size_t i = 0; i < sizeof(configuration_values) /
                                  sizeof(configuration_values[0]); ++i)
        UT_ASSERT_EQUAL(configuration_values[i].actual,
                        configuration_values[i].expected);
    size_t count = 15U; /* 1..14 except 5, plus 18 and 19. */
#ifdef WIFI_MANAGE_SUPPORTED
    ++count;
#endif
#if defined(AMENITIES_NETWORK_ENABLED) && !defined(_CBR2_PRODUCT_REQ_)
    count += 3U;
#endif
    UT_ASSERT_TRUE(sizeof(configuration_values) /
                   sizeof(configuration_values[0]) == count);
}

static void test_feature_config_acceptance(void)
{
#ifdef BUILD_LINUX
    /* Headers determine the legal set, not a guessed numeric min/max.
     * This also rejects 17/20/21/22 when their feature guards are disabled. */
    for (int config = 0; config <= 23; ++config) {
        int expected = -1;
        for (size_t i = 0; i < sizeof(configuration_values) /
                                      sizeof(configuration_values[0]); ++i)
            if (configuration_values[i].expected == config)
                expected = 0;
        bridgeDetails details = fixture.details;
        UT_ASSERT_EQUAL(HandlePreConfigVendor(&details, config), expected);
        UT_ASSERT_EQUAL(HandlePostConfigVendor(&details, config), expected);
        UT_ASSERT_EQUAL(memcmp(&details, &fixture.details, sizeof(details)), 0);
    }
#else
    /* The compile-time table still checks the vendor header view, without
     * applying OEM settings as a side effect of a declaration test. */
    test_config_values();
#endif
}

static void test_all_global_storage(void)
{
    int *integers[] = {
        &DeviceMode, &MocaIsolation_Val, &need_wifi_gw_refresh,
        &need_switch_gw_refresh, &syncMembers, &BridgeOprInPropgress,
        &PORT2ENABLE, &ethWanEnabled
    };
    int saved_integers[sizeof(integers) / sizeof(integers[0])];
    char saved_bridge[sizeof(primaryBridgeName)];
    char saved_wan[sizeof(ethWanIfaceName)];
    log_snapshot_t saved;
    FILE *file = tmpfile();
    UT_ASSERT_PTR_NOT_NULL_FATAL(file);
    save_logging(&saved);
    memcpy(saved_bridge, primaryBridgeName, sizeof(saved_bridge));
    memcpy(saved_wan, ethWanIfaceName, sizeof(saved_wan));
    for (size_t i = 0; i < sizeof(integers) / sizeof(integers[0]); ++i)
        saved_integers[i] = *integers[i];

    /* Distinct values detect accidental aliases as well as missing symbols. */
    for (size_t i = 0; i < sizeof(integers) / sizeof(integers[0]); ++i)
        *integers[i] = 101 + (int)i;
    strcpy(primaryBridgeName, "contract-primary");
    strcpy(ethWanIfaceName, "contract-wan");
    strcpy(log_buff, "contract-message");
    strcpy(log_msg_wtime, "contract-timestamp");
    struct tm sample = {0};
    logFp = file;
    timeinfo = &sample;
    utc_time = (time_t)123456;

    /* No fatal assertions after acquiring resources/changing globals. */
    for (size_t i = 0; i < sizeof(integers) / sizeof(integers[0]); ++i)
        UT_ASSERT_EQUAL(*integers[i], 101 + (int)i);
    UT_ASSERT_PTR_EQUAL(logFp, file);
    UT_ASSERT_PTR_EQUAL(timeinfo, &sample);
    UT_ASSERT_TRUE(utc_time == (time_t)123456);
    UT_ASSERT_STRING_EQUAL("contract-primary", primaryBridgeName);
    UT_ASSERT_STRING_EQUAL("contract-wan", ethWanIfaceName);
    UT_ASSERT_STRING_EQUAL("contract-message", log_buff);
    UT_ASSERT_STRING_EQUAL("contract-timestamp", log_msg_wtime);

    for (size_t i = 0; i < sizeof(integers) / sizeof(integers[0]); ++i)
        *integers[i] = saved_integers[i];
    memcpy(primaryBridgeName, saved_bridge, sizeof(saved_bridge));
    memcpy(ethWanIfaceName, saved_wan, sizeof(saved_wan));
    restore_logging(&saved);
    UT_ASSERT_EQUAL(fclose(file), 0);
}

static void test_logging_file(void)
{
    FILE *file = tmpfile();
    UT_ASSERT_PTR_NOT_NULL_FATAL(file);
    log_snapshot_t saved;
    save_logging(&saved);
    logFp = file;

    const time_t before = time(NULL);
    bridge_util_log("bridge=%s count=%d literal=%%\n", fixture.bridge_name, 7);
    const time_t after = time(NULL);
    char expected[128];
    snprintf(expected, sizeof(expected), "bridge=%s count=7 literal=%%\n",
             fixture.bridge_name);
    UT_ASSERT_STRING_EQUAL(expected, log_buff);
    UT_ASSERT_PTR_NOT_NULL(timeinfo);
    UT_ASSERT_TRUE(utc_time >= before && utc_time <= after);
    struct tm expected_utc;
    struct tm *converted = gmtime_r(&utc_time, &expected_utc);
    UT_ASSERT_PTR_NOT_NULL(converted);
    if (timeinfo != NULL && converted != NULL) {
        char stamp[TIMESTAMP];
        const size_t stamp_length = strftime(
            stamp, sizeof(stamp), "%Y-%m-%d %H:%M:%S ::: ", &expected_utc);
        UT_ASSERT_TRUE(stamp_length == 24U);
        if (stamp_length != 0U) {
            UT_ASSERT_EQUAL(strncmp(stamp, log_msg_wtime, stamp_length), 0);
            UT_ASSERT_STRING_EQUAL(expected, log_msg_wtime + stamp_length);
        }
        UT_ASSERT_EQUAL(timeinfo->tm_year, expected_utc.tm_year);
        UT_ASSERT_EQUAL(timeinfo->tm_mon, expected_utc.tm_mon);
        UT_ASSERT_EQUAL(timeinfo->tm_mday, expected_utc.tm_mday);
        UT_ASSERT_EQUAL(timeinfo->tm_hour, expected_utc.tm_hour);
        UT_ASSERT_EQUAL(timeinfo->tm_min, expected_utc.tm_min);
        UT_ASSERT_EQUAL(timeinfo->tm_sec, expected_utc.tm_sec);
        UT_ASSERT_EQUAL(timeinfo->tm_isdst, 0);
    }

    /* fflush is part of the macro: the descriptor must already have data. */
    UT_ASSERT_TRUE(lseek(fileno(file), 0, SEEK_END) > 0);
    rewind(file);
    char contents[MAX_LOG_BUFF_SIZE + TIMESTAMP] = {0};
    const size_t count = fread(contents, 1U, sizeof(contents) - 1U, file);
    UT_ASSERT_EQUAL(ferror(file), 0);
    UT_ASSERT_TRUE(count == strlen(log_msg_wtime));
    UT_ASSERT_STRING_EQUAL(log_msg_wtime, contents);
    restore_logging(&saved);
    UT_ASSERT_EQUAL(fclose(file), 0);
}

static void test_logging_null_file(void)
{
    FILE *capture = tmpfile();
    UT_ASSERT_PTR_NOT_NULL_FATAL(capture);
    fflush(stdout);
    const int saved_stdout = dup(STDOUT_FILENO);
    if (saved_stdout < 0) {
        fclose(capture);
        UT_FAIL("Cannot save stdout for the null-log branch");
        return;
    }
    const int redirected = dup2(fileno(capture), STDOUT_FILENO);
    if (redirected < 0) {
        close(saved_stdout);
        fclose(capture);
        UT_FAIL("Cannot capture stdout for the null-log branch");
        return;
    }

    log_snapshot_t saved;
    save_logging(&saved);
    struct tm sentinel = {0};
    logFp = NULL;
    timeinfo = &sentinel;
    utc_time = (time_t)42;
    memset(log_msg_wtime, 'q', sizeof(log_msg_wtime));
    bridge_util_log("null-log=%d", 3);
    fflush(stdout);
    const int restored = dup2(saved_stdout, STDOUT_FILENO);
    close(saved_stdout);

    /* The header comment promises stdout, but the actual unchanged macro has
     * no else branch. Pin its existing expansion explicitly, not that promise. */
    UT_ASSERT_TRUE(restored >= 0);
    UT_ASSERT_TRUE(ftell(capture) == 0L);
    UT_ASSERT_STRING_EQUAL("null-log=3", log_buff);
    UT_ASSERT_PTR_EQUAL(timeinfo, &sentinel);
    UT_ASSERT_TRUE(utc_time == (time_t)42);
    for (size_t i = 0; i < sizeof(log_msg_wtime); ++i)
        UT_ASSERT_EQUAL(log_msg_wtime[i], 'q');
    restore_logging(&saved);
    UT_ASSERT_EQUAL(fclose(capture), 0);
}

static void test_logging_bounds(void)
{
    FILE *file = tmpfile();
    UT_ASSERT_PTR_NOT_NULL_FATAL(file);
    log_snapshot_t saved;
    save_logging(&saved);
    logFp = file;
    memset(log_buff, 0x5a, sizeof(log_buff));
    memset(log_msg_wtime, 0x5a, sizeof(log_msg_wtime));
    char payload[MAX_LOG_BUFF_SIZE * 2U];
    memset(payload, 'x', sizeof(payload) - 1U);
    payload[sizeof(payload) - 1U] = '\0';
    /* Runtime precision exercises intentional snprintf truncation. */
    volatile int length = (int)strlen(payload);
    bridge_util_log("%.*s", length, payload);
    const size_t message_length = strnlen(log_buff, sizeof(log_buff));
    const size_t timestamped_length = strnlen(log_msg_wtime, sizeof(log_msg_wtime));
    UT_ASSERT_TRUE(message_length == MAX_LOG_BUFF_SIZE - 2U);
    for (size_t i = 0; i < MAX_LOG_BUFF_SIZE - 2U; ++i)
        UT_ASSERT_EQUAL(log_buff[i], 'x');
    UT_ASSERT_EQUAL(log_buff[MAX_LOG_BUFF_SIZE - 1U], 0x5a);
    UT_ASSERT_EQUAL(log_msg_wtime[sizeof(log_msg_wtime) - 1U], 0x5a);
    UT_ASSERT_TRUE(timestamped_length == 24U + message_length);
    if (message_length == MAX_LOG_BUFF_SIZE - 2U &&
        timestamped_length == 24U + message_length)
        UT_ASSERT_EQUAL(memcmp(log_buff, log_msg_wtime + 24U,
                               message_length + 1U), 0);
    restore_logging(&saved);
    UT_ASSERT_EQUAL(fclose(file), 0);
}

/* PUBLIC_INTERFACE */
/** Register eight contract cases in L1 and propagate every registration error. */
int test_bridge_util_contract_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L1 bridge_util_contract]", suite_init, NULL, UT_TESTS_L1);
    if (suite == NULL)
        return -1;
    const struct {
        const char *name;
        UT_TestFunction_t test;
    } cases[] = {
        {"constants_and_bridge_details", test_constants_and_bridge_details},
        {"gateway_contract", test_gateway_contract},
        {"config_values", test_config_values},
        {"feature_config_acceptance", test_feature_config_acceptance},
        {"all_fifteen_globals", test_all_global_storage},
        {"logging_file", test_logging_file},
        {"logging_null_file", test_logging_null_file},
        {"logging_bounds", test_logging_bounds}
    };
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i)
        if (UT_add_test(suite, cases[i].name, cases[i].test) == NULL)
            return -1;
    return CU_get_error() == CUE_SUCCESS ? 0 : -1;
}
