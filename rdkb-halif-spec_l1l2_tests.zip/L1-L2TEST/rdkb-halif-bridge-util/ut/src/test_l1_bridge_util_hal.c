/*
 * Copyright 2023 RDK Management
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @file test_l1_bridge_util_hal.c
 * Native L1 API checks. Public signatures/statuses come from
 * include/bridge_util_hal.h; operation, NULL and ownership policies come from
 * skeletons/include/bridge_util_test_backend.h and the checked KVP profile.
 * OVS_CMD is NOT supplied by the public header. Neither BR_CMD nor BridgeOpr
 * defines updateBridgeInfo's operation ABI; IF_TYPE is not INTERFACE_TYPE.
 *
 * All 32 legacy test identities are retained. Every case prepares its own
 * baseline, so selecting a case or changing case order cannot inherit state.
 * These reference-policy tests are not vendor/DUT conformance evidence.
 */
#include <limits.h>
#include <string.h>
#include <ut.h>

#include "bridge_util_test_support.h"
#ifdef BUILD_LINUX
#include "bridge_util_test_backend.h"
#endif

static bridge_util_fixture_t fixture;

static const int configurations[] = {
    PRIVATE_LAN, HOME_SECURITY, HOTSPOT_2G, HOTSPOT_5G, LOST_N_FOUND,
    HOTSPOT_SECURE_2G, HOTSPOT_SECURE_5G, MOCA_ISOLATION, MESH_BACKHAUL,
    ETH_BACKHAUL, MESH, MESH_WIFI_BACKHAUL_2G, MESH_WIFI_BACKHAUL_5G,
    MESH_ONBOARD, MESH_WIFI_ONBOARD_2G,
#ifdef WIFI_MANAGE_SUPPORTED
    MANAGE_WIFI_BRIDGE,
#endif
#if defined(AMENITIES_NETWORK_ENABLED) && !defined(_CBR2_PRODUCT_REQ_)
    AMENITY_BRIDGE_2G, AMENITY_BRIDGE_5G, AMENITY_BRIDGE_6G,
#endif
};

/* PUBLIC_INTERFACE */
/** Load the checked fixture and seed only the isolated Linux reference model. */
int fetch_bridge_util_details(void)
{
    if (bridge_util_fixture_load(&fixture) != 0 ||
        bridge_util_fixture_prepare(&fixture) != 0)
        return -1;
#ifndef BUILD_LINUX
    /* No model operation/ownership assumptions may silently reach a device. */
    fputs("L1 reference-policy cases require BUILD_LINUX; "
          "vendor conformance requires vendor-specific fixtures.\n", stderr);
    return -1;
#else
    return 0;
#endif
}

static int prepare_case(bridge_util_fixture_t *next)
{
    *next = fixture;
    return bridge_util_fixture_prepare(next);
}

static int cleanup_suite(void)
{
#ifdef BUILD_LINUX
    bridge_util_test_reset();
    return checkIfExists(fixture.bridge_name) == INTERFACE_NOT_EXIST &&
           getVendorIfaces() == NULL ? 0 : -1;
#else
    return 0;
#endif
}

static void check_valid_hooks(int (*hook)(bridgeDetails *, int))
{
    for (size_t i = 0; i < sizeof(configurations) / sizeof(configurations[0]); ++i) {
        bridge_util_fixture_t f;
        UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
        const bridgeDetails before = f.details;
        UT_ASSERT_EQUAL(hook(&f.details, configurations[i]), 0);
        /* Non-mutation is specifically a reference-hook policy. */
        UT_ASSERT_EQUAL(memcmp(&before, &f.details, sizeof(before)), 0);
    }
}

static void check_invalid_hook(int (*hook)(bridgeDetails *, int), int config)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    const bridgeDetails before = f.details;
    UT_ASSERT_EQUAL(hook(&f.details, config), -1);
    UT_ASSERT_EQUAL(memcmp(&before, &f.details, sizeof(before)), 0);
}

/* PUBLIC_INTERFACE */
/** Create using the explicitly loaded operation and public interface type. */
void test_l1_bridge_util_hal_positive1_updateBridgeInfo(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, f.update_iface,
                                    f.create_operation, IF_BRIDGE_BRIDGEUTIL), 0);
}

/* PUBLIC_INTERFACE */
/** Exercise each modeled operation against an independently seeded bridge. */
void test_l1_bridge_util_hal_positive2_updateBridgeInfo(void)
{
    const int operations[] = {
        fixture.create_operation, fixture.delete_operation,
        fixture.attach_operation, fixture.detach_operation
    };
    for (size_t i = 0; i < sizeof(operations) / sizeof(operations[0]); ++i) {
        bridge_util_fixture_t f;
        UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
        UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, f.update_iface,
                                        operations[i], IF_BRIDGE_BRIDGEUTIL), 0);
    }
}

/* PUBLIC_INTERFACE */
/** Use named INTERFACE_TYPE entries, never unrelated network IF_TYPE values. */
void test_l1_bridge_util_hal_positive3_updateBridgeInfo(void)
{
    const int types[] = {
        IF_BRIDGE_BRIDGEUTIL, IF_VLAN_BRIDGEUTIL, IF_GRE_BRIDGEUTIL,
        IF_MOCA_BRIDGEUTIL, IF_WIFI_BRIDGEUTIL, IF_ETH_BRIDGEUTIL,
        IF_OTHER_BRIDGEUTIL
    };
    for (size_t i = 0; i < sizeof(types) / sizeof(types[0]); ++i) {
        bridge_util_fixture_t f;
        UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
        UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, f.update_iface,
                                        f.create_operation, types[i]), 0);
    }
}

/* PUBLIC_INTERFACE */
/** Reject NULL bridge details. */
void test_l1_bridge_util_hal_negative1_updateBridgeInfo(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    UT_ASSERT_EQUAL(updateBridgeInfo(NULL, f.update_iface,
                                    f.create_operation, IF_BRIDGE_BRIDGEUTIL), -1);
}

/* PUBLIC_INTERFACE */
/** Require a sync target only for IF_OTHER, not for configured-list updates. */
void test_l1_bridge_util_hal_negative2_updateBridgeInfo(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, NULL,
                                    f.detach_operation, IF_OTHER_BRIDGEUTIL), -1);
    char empty[] = "";
    UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, empty,
                                    f.detach_operation, IF_OTHER_BRIDGEUTIL), -1);
    /* The header calls the target sync-only; optional-ignored is model policy. */
    UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, NULL,
                                    f.create_operation, IF_BRIDGE_BRIDGEUTIL), 0);
    UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, empty,
                                    f.create_operation, IF_BRIDGE_BRIDGEUTIL), 0);
}

/* PUBLIC_INTERFACE */
/** Reject operations outside the documented reference operation table. */
void test_l1_bridge_util_hal_negative3_updateBridgeInfo(void)
{
    /* Explicit invalid model values, not inferred vendor OVS_CMD bounds. */
    const int invalid_operations[] = {INT_MIN, -1, 0, 5, INT_MAX};
    for (size_t i = 0; i < sizeof(invalid_operations) /
                                  sizeof(invalid_operations[0]); ++i) {
        bridge_util_fixture_t f;
        UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
        UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, f.update_iface,
                                        invalid_operations[i],
                                        IF_BRIDGE_BRIDGEUTIL), -1);
    }
}

/* PUBLIC_INTERFACE */
/** Reject values absent from the public INTERFACE_TYPE enumeration. */
void test_l1_bridge_util_hal_negative4_updateBridgeInfo(void)
{
    const int invalid_types[] = {INT_MIN, 0, 8, INT_MAX};
    for (size_t i = 0; i < sizeof(invalid_types) / sizeof(invalid_types[0]); ++i) {
        bridge_util_fixture_t f;
        UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
        UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, f.update_iface,
                                        f.create_operation, invalid_types[i]), -1);
    }
}

/* PUBLIC_INTERFACE */
/** Distinguish the seeded bridge and interface from an absent object. */
void test_l1_bridge_util_hal_positive1_checkIfExists(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    UT_ASSERT_EQUAL(checkIfExists(f.iface_name), INTERFACE_EXIST);
    UT_ASSERT_EQUAL(checkIfExists(f.bridge_name), INTERFACE_EXIST);
}

/* PUBLIC_INTERFACE */
/** Treat a NULL existence query as absent under reference validation policy. */
void test_l1_bridge_util_hal_negative1_checkIfExists(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    UT_ASSERT_EQUAL(checkIfExists(NULL), INTERFACE_NOT_EXIST);
}

/* PUBLIC_INTERFACE */
/** Reject an empty existence-query name. */
void test_l1_bridge_util_hal_negative2_checkIfExists(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    char empty[] = "";
    UT_ASSERT_EQUAL(checkIfExists(empty), INTERFACE_NOT_EXIST);
}

/* PUBLIC_INTERFACE */
/** An unseeded name must not acquire existence merely from being queried. */
void test_l1_bridge_util_hal_negative3_checkIfExists(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    char absent[] = "unseeded-reference-if";
    UT_ASSERT_EQUAL(checkIfExists(absent), INTERFACE_NOT_EXIST);
    UT_ASSERT_EQUAL(checkIfExists(absent), INTERFACE_NOT_EXIST);
}

/* PUBLIC_INTERFACE */
/** Recognize the fixture's actual bridge/member relationship. */
void test_l1_bridge_util_hal_positive1_checkIfExistsInBridge(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    UT_ASSERT_EQUAL(checkIfExistsInBridge(f.iface_name, f.bridge_name), 0);
}

/* PUBLIC_INTERFACE */
/** Reject an absent bridge without mutating the writable query arguments. */
void test_l1_bridge_util_hal_negative1_checkIfExistsInBridge(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    char absent[] = "unseeded-reference-br";
    UT_ASSERT_EQUAL(checkIfExistsInBridge(f.iface_name, absent), -1);
    UT_ASSERT_STRING_EQUAL("unseeded-reference-br", absent);
    UT_ASSERT_STRING_EQUAL(fixture.iface_name, f.iface_name);
}

/* PUBLIC_INTERFACE */
/** Reject NULL member names. */
void test_l1_bridge_util_hal_negative2_checkIfExistsInBridge(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    UT_ASSERT_EQUAL(checkIfExistsInBridge(NULL, f.bridge_name), -1);
}

/* PUBLIC_INTERFACE */
/** Reject NULL bridge names. */
void test_l1_bridge_util_hal_negative3_checkIfExistsInBridge(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    UT_ASSERT_EQUAL(checkIfExistsInBridge(f.iface_name, NULL), -1);
}

/* PUBLIC_INTERFACE */
/** Reject empty names; retain the legacy negative5 test identity. */
void test_l1_bridge_util_hal_negative5_checkIfExistsInBridge(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    char empty[] = "";
    UT_ASSERT_EQUAL(checkIfExistsInBridge(empty, f.bridge_name), -1);
    UT_ASSERT_EQUAL(checkIfExistsInBridge(f.iface_name, empty), -1);
}

/* PUBLIC_INTERFACE */
/** Cover all compiled Config values, including onboarding and feature entries. */
void test_l1_bridge_util_hal_positive1_HandlePreConfigVendor(void)
{
    check_valid_hooks(HandlePreConfigVendor);
}

/* PUBLIC_INTERFACE */
/** Reject NULL pre-hook details with a known valid Config. */
void test_l1_bridge_util_hal_negative1_HandlePreConfigVendor(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    UT_ASSERT_EQUAL(HandlePreConfigVendor(NULL, f.instance), -1);
}

/* PUBLIC_INTERFACE */
/** Zero is not a named Config. */
void test_l1_bridge_util_hal_negative2_HandlePreConfigVendor(void)
{
    check_invalid_hook(HandlePreConfigVendor, 0);
}

/* PUBLIC_INTERFACE */
/** Test enum holes and extremes rather than assuming Config ends at fourteen. */
void test_l1_bridge_util_hal_negative3_HandlePreConfigVendor(void)
{
    const int invalid[] = {15, 16, 23, INT_MIN, INT_MAX};
    for (size_t i = 0; i < sizeof(invalid) / sizeof(invalid[0]); ++i)
        check_invalid_hook(HandlePreConfigVendor, invalid[i]);
}

/* PUBLIC_INTERFACE */
/** Config deliberately has no value five. */
void test_l1_bridge_util_hal_negative4_HandlePreConfigVendor(void)
{
    check_invalid_hook(HandlePreConfigVendor, 5);
}

/* PUBLIC_INTERFACE */
/** Cover every compiled Config with the post-hook independently. */
void test_l1_bridge_util_hal_positive1_HandlePostConfigVendor(void)
{
    check_valid_hooks(HandlePostConfigVendor);
}

/* PUBLIC_INTERFACE */
/** Reject NULL post-hook details without depending on earlier case variables. */
void test_l1_bridge_util_hal_negative1_HandlePostConfigVendor(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    UT_ASSERT_EQUAL(HandlePostConfigVendor(NULL, f.instance), -1);
}

/* PUBLIC_INTERFACE */
/** Reject zero as a post-hook Config. */
void test_l1_bridge_util_hal_negative2_HandlePostConfigVendor(void)
{
    check_invalid_hook(HandlePostConfigVendor, 0);
}

/* PUBLIC_INTERFACE */
/** Reject post-hook holes and extremes, not valid onboarding values 18/19. */
void test_l1_bridge_util_hal_negative3_HandlePostConfigVendor(void)
{
    const int invalid[] = {15, 16, 23, INT_MIN, INT_MAX};
    for (size_t i = 0; i < sizeof(invalid) / sizeof(invalid[0]); ++i)
        check_invalid_hook(HandlePostConfigVendor, invalid[i]);
}

/* PUBLIC_INTERFACE */
/** Reject the missing Config value five in the post-hook. */
void test_l1_bridge_util_hal_negative4_HandlePostConfigVendor(void)
{
    check_invalid_hook(HandlePostConfigVendor, 5);
}

/* PUBLIC_INTERFACE */
/** Accept NULL for no vendor interfaces and verify nonempty borrowed contents. */
void test_l1_bridge_util_hal_positive1_getVendorIfaces(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    char *result = getVendorIfaces();
    if (f.vendor_ifaces[0] == '\0') {
        UT_ASSERT_PTR_NULL(result);
    } else {
        UT_ASSERT_PTR_NOT_NULL_FATAL(result);
        UT_ASSERT_STRING_EQUAL(f.vendor_ifaces, result);
    }
#ifdef BUILD_LINUX
    /* Public ABI supplies no 64-byte result limit or ownership transfer.
     * The reference setter gives this test a known NUL-terminated oracle. */
    const char names[] =
        "vendor00 vendor01 vendor02 vendor03 vendor04 "
        "vendor05 vendor06 vendor07 vendor08 vendor09";
    UT_ASSERT_TRUE(sizeof(names) > IFACE_NAME_SIZE);
    UT_ASSERT_EQUAL_FATAL(bridge_util_test_set_vendor_ifaces(names), 0);
    result = getVendorIfaces();
    UT_ASSERT_PTR_NOT_NULL_FATAL(result);
    UT_ASSERT_STRING_EQUAL(names, result);
    UT_ASSERT_STRING_EQUAL(names, getVendorIfaces());
    UT_ASSERT_EQUAL(bridge_util_test_set_vendor_ifaces(NULL), 0);
    UT_ASSERT_PTR_NULL(getVendorIfaces());
    /* Never free or modify borrowed result storage. */
#endif
}

/* PUBLIC_INTERFACE */
/** Remove a real member from the full configured list and check every survivor. */
void test_l1_bridge_util_hal_positive1_removeIfaceFromList(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    removeIfaceFromList(f.iface_list, f.remove_iface);
    UT_ASSERT_STRING_EQUAL(f.expected_list, f.iface_list);
    UT_ASSERT_STRING_EQUAL(fixture.remove_iface, f.remove_iface);
}

/* PUBLIC_INTERFACE */
/** NULL target is a reference no-op, verified over the complete input buffer. */
void test_l1_bridge_util_hal_negative1_removeIfaceFromList(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    char before[TOTAL_IFLIST_SIZE];
    memcpy(before, f.iface_list, sizeof(before));
    removeIfaceFromList(f.iface_list, NULL);
    UT_ASSERT_EQUAL(memcmp(before, f.iface_list, sizeof(before)), 0);
}

/* PUBLIC_INTERFACE */
/** NULL list must not corrupt the supplied target or seeded membership. */
void test_l1_bridge_util_hal_negative2_removeIfaceFromList(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    removeIfaceFromList(NULL, f.remove_iface);
    UT_ASSERT_STRING_EQUAL(fixture.remove_iface, f.remove_iface);
    UT_ASSERT_EQUAL(checkIfExistsInBridge(f.iface_name, f.bridge_name), 0);
}

/* PUBLIC_INTERFACE */
/** Empty removal target preserves all list bytes under reference policy. */
void test_l1_bridge_util_hal_negative3_removeIfaceFromList(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    char before[TOTAL_IFLIST_SIZE];
    memcpy(before, f.iface_list, sizeof(before));
    removeIfaceFromList(f.iface_list, "");
    UT_ASSERT_EQUAL(memcmp(before, f.iface_list, sizeof(before)), 0);
}

/* PUBLIC_INTERFACE */
/** Public absent-target no-op preserves whitespace and token order exactly. */
void test_l1_bridge_util_hal_negative4_removeIfaceFromList(void)
{
    bridge_util_fixture_t f;
    UT_ASSERT_EQUAL_FATAL(prepare_case(&f), 0);
    char list[] = "  eth0\tmoca0  wlan0 \n";
    const char before[] = "  eth0\tmoca0  wlan0 \n";
    removeIfaceFromList(list, "not-in-this-list");
    UT_ASSERT_EQUAL(memcmp(before, list, sizeof(before)), 0);
}

/* PUBLIC_INTERFACE */
/** Register all legacy identities in L1; return -1 for any registration error. */
int test_bridge_util_hal_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L1 bridge_util_hal]", fetch_bridge_util_details,
        cleanup_suite, UT_TESTS_L1);
    if (suite == NULL)
        return -1;

#define ENTRY(suffix) { "l1_bridge_util_hal_" #suffix, \
                       test_l1_bridge_util_hal_ ## suffix }
    const struct {
        const char *name;
        UT_TestFunction_t test;
    } cases[] = {
        ENTRY(positive1_updateBridgeInfo),
        ENTRY(positive2_updateBridgeInfo),
        ENTRY(positive3_updateBridgeInfo),
        ENTRY(negative1_updateBridgeInfo),
        ENTRY(negative2_updateBridgeInfo),
        ENTRY(negative3_updateBridgeInfo),
        ENTRY(negative4_updateBridgeInfo),
        ENTRY(positive1_checkIfExists),
        ENTRY(negative1_checkIfExists),
        ENTRY(negative2_checkIfExists),
        ENTRY(negative3_checkIfExists),
        ENTRY(positive1_checkIfExistsInBridge),
        ENTRY(negative1_checkIfExistsInBridge),
        ENTRY(negative2_checkIfExistsInBridge),
        ENTRY(negative3_checkIfExistsInBridge),
        ENTRY(negative5_checkIfExistsInBridge),
        ENTRY(positive1_HandlePreConfigVendor),
        ENTRY(negative1_HandlePreConfigVendor),
        ENTRY(negative2_HandlePreConfigVendor),
        ENTRY(negative3_HandlePreConfigVendor),
        ENTRY(negative4_HandlePreConfigVendor),
        ENTRY(positive1_HandlePostConfigVendor),
        ENTRY(negative1_HandlePostConfigVendor),
        ENTRY(negative2_HandlePostConfigVendor),
        ENTRY(negative3_HandlePostConfigVendor),
        ENTRY(negative4_HandlePostConfigVendor),
        ENTRY(positive1_getVendorIfaces),
        ENTRY(positive1_removeIfaceFromList),
        ENTRY(negative1_removeIfaceFromList),
        ENTRY(negative2_removeIfaceFromList),
        ENTRY(negative3_removeIfaceFromList),
        ENTRY(negative4_removeIfaceFromList)
    };
#undef ENTRY
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i)
        if (UT_add_test(suite, cases[i].name, cases[i].test) == NULL)
            return -1;
    return CU_get_error() == CUE_SUCCESS ? 0 : -1;
}
