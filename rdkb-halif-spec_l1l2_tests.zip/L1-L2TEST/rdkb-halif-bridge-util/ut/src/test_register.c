/*
 * If not stated otherwise in this file or this component's LICENSE file the
 * following copyright and licenses apply:*
 * Copyright 2023 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <ut.h>

extern int test_bridge_util_hal_l1_register(void);
#ifdef BRIDGE_UTIL_HAS_CONTRACT_SUITE
extern int test_bridge_util_contract_l1_register(void);
#endif
#ifdef BRIDGE_UTIL_HAS_L2_SUITE
extern int test_bridge_util_hal_l2_register(void);
#endif

/* PUBLIC_INTERFACE */
/** Register L1 API and available contract suites; return 0 or -1 on failure. */
int register_hal_l1_tests(void)
{
    if (test_bridge_util_hal_l1_register() != 0 || CU_get_error() != CUE_SUCCESS)
        return -1;
#ifdef BRIDGE_UTIL_HAS_CONTRACT_SUITE
    if (test_bridge_util_contract_l1_register() != 0 ||
        CU_get_error() != CUE_SUCCESS)
        return -1;
#endif
    return 0;
}

/* PUBLIC_INTERFACE */
/** Register the L2 suite when present; return 0 or -1 on failure. */
int register_hal_l2_tests(void)
{
#ifdef BRIDGE_UTIL_HAS_L2_SUITE
    if (test_bridge_util_hal_l2_register() != 0 || CU_get_error() != CUE_SUCCESS)
        return -1;
#endif
    return 0;
}
