/*
 * If not stated otherwise in this file or this component's LICENSE file the
 * following copyright and licenses apply:*
 * Copyright 2023 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <ut.h>
#include <ut_kvp_profile.h>

extern int register_hal_l1_tests(void);
extern int register_hal_l2_tests(void);

void __real_CU_cleanup_registry(void);
UT_test_suite_t *__real_UT_add_suite(
    const char *title, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup);
UT_test_suite_t *__real_UT_add_suite_withGroupID(
    const char *title, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup,
    UT_groupID_t group);
UT_test_t *__real_UT_add_test(
    UT_test_suite_t *suite, const char *title, UT_TestFunction_t test);

static bool running;
static bool captured_results;
static bool registration_failed;
static unsigned int tests_run;
static unsigned int failed_tests;
static unsigned int failed_assertions;
static unsigned int failed_suites;
static unsigned int failure_records;
static CU_ErrorCode run_error;

/* PUBLIC_INTERFACE */
/** Capture final CUnit results before ut-core destroys and resets its registry. */
void __wrap_CU_cleanup_registry(void)
{
    if (running) {
        tests_run = CU_get_number_of_tests_run();
        failed_tests = CU_get_number_of_tests_failed();
        failed_assertions = CU_get_number_of_failures();
        failed_suites = CU_get_number_of_suites_failed();
        failure_records = CU_get_number_of_failure_records();
        run_error = CU_get_error();
        captured_results = true;
        fprintf(stderr,
                "BRIDGE_UTIL_RESULT tests=%u failed_tests=%u "
                "failed_assertions=%u failed_suites=%u\n",
                tests_run, failed_tests, failed_assertions, failed_suites);
    }
    __real_CU_cleanup_registry();
}

/* PUBLIC_INTERFACE */
/** Forward suite registration, retaining failures even if the caller ignores them. */
UT_test_suite_t *__wrap_UT_add_suite(
    const char *title, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup)
{
    UT_test_suite_t *suite = __real_UT_add_suite(title, init, cleanup);
    if (suite == NULL || CU_get_error() != CUE_SUCCESS)
        registration_failed = true;
    return suite;
}

/* PUBLIC_INTERFACE */
/** Forward grouped-suite registration and retain any failure for main(). */
UT_test_suite_t *__wrap_UT_add_suite_withGroupID(
    const char *title, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup,
    UT_groupID_t group)
{
    UT_test_suite_t *suite =
        __real_UT_add_suite_withGroupID(title, init, cleanup, group);
    if (suite == NULL || CU_get_error() != CUE_SUCCESS)
        registration_failed = true;
    return suite;
}

/* PUBLIC_INTERFACE */
/** Forward test registration and retain any failure for main(). */
UT_test_t *__wrap_UT_add_test(
    UT_test_suite_t *suite, const char *title, UT_TestFunction_t test)
{
    UT_test_t *entry = __real_UT_add_test(suite, title, test);
    if (entry == NULL || CU_get_error() != CUE_SUCCESS)
        registration_failed = true;
    return entry;
}

static void usage(const char *program)
{
    fprintf(stderr,
            "Usage: %s -p PROFILE [-b|-a|-c] [-l LOG_DIRECTORY] "
            "[-d GROUP] [-e GROUP] [-t]\n"
            "A readable bridge_util profile is required. Groups: 1..9.\n",
            program);
}

/*
 * ut-core 4.7.3 logs bad arguments/profile errors but still returns success.
 * Validate here and remove -p before UT_init so the profile is opened once,
 * with an explicitly checked return value instead of decodeOptions' logging.
 */
static int validate_arguments(int argc, char **argv, char **core_args,
                              int *core_argc, char **profile)
{
    unsigned int group_options = 0U;
    *core_argc = 1;
    core_args[0] = argv[0];

    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "-p") == 0) {
            if (*profile != NULL || ++i == argc || argv[i][0] == '\0' ||
                argv[i][0] == '-')
                return -1;
            *profile = argv[i];
        } else if (strcmp(argv[i], "-b") == 0 || strcmp(argv[i], "-a") == 0 ||
                   strcmp(argv[i], "-c") == 0 || strcmp(argv[i], "-t") == 0) {
            core_args[(*core_argc)++] = argv[i];
        } else if (strcmp(argv[i], "-d") == 0 || strcmp(argv[i], "-e") == 0) {
            /* Match ut-core's fixed 50-entry option array without overflowing it. */
            if (++group_options > 50U)
                return -1;
            core_args[(*core_argc)++] = argv[i];
            if (++i == argc || strlen(argv[i]) != 1U ||
                argv[i][0] < '1' || argv[i][0] >= '0' + UT_TESTS_MAX)
                return -1;
            core_args[(*core_argc)++] = argv[i];
        } else if (strcmp(argv[i], "-l") == 0) {
            struct stat info;
            core_args[(*core_argc)++] = argv[i];
            if (++i == argc || stat(argv[i], &info) != 0 ||
                !S_ISDIR(info.st_mode) || access(argv[i], W_OK) != 0)
                return -1;
            core_args[(*core_argc)++] = argv[i];
        } else {
            return -1;
        }
    }

    struct stat info;
    return *profile != NULL && stat(*profile, &info) == 0 &&
           S_ISREG(info.st_mode) && access(*profile, R_OK) == 0 ? 0 : -1;
}

/* PUBLIC_INTERFACE */
/**
 * Run the official HAL suites with checked command-line/profile initialization.
 * @param argc Number of command-line arguments.
 * @param argv Arguments described by -h; -p selects the required KVP profile.
 * @return 0 on a successful test run (or help), 1 on configuration,
 * registration, framework, suite-setup/cleanup, or assertion failure.
 */
int main(int argc, char **argv)
{
    int result = EXIT_FAILURE;
    int core_argc = 0;
    char *profile = NULL;
    char **core_args = NULL;

    if (argc == 2 && strcmp(argv[1], "-h") == 0) {
        usage(argv[0]);
        return EXIT_SUCCESS;
    }

    core_args = calloc((size_t)argc + 1U, sizeof(*core_args));
    if (core_args == NULL)
        return EXIT_FAILURE;
    if (validate_arguments(argc, argv, core_args, &core_argc, &profile) != 0) {
        usage(argv[0]);
        goto done;
    }

    if (ut_kvp_profile_open(profile) != UT_KVP_STATUS_SUCCESS ||
        !ut_kvp_fieldPresent(ut_kvp_profile_getInstance(), "bridge_util/config")) {
        fputs("Invalid bridge_util profile\n", stderr);
        goto done;
    }

    if (UT_init(core_argc, core_args) != UT_STATUS_OK) {
        fputs("Unit test framework initialization failed\n", stderr);
        CU_cleanup_registry();
        goto done;
    }
    if (register_hal_l1_tests() != 0 || register_hal_l2_tests() != 0 ||
        registration_failed || CU_get_error() != CUE_SUCCESS ||
        CU_get_registry() == NULL || CU_get_registry()->uiNumberOfTests == 0U) {
        fputs("Bridge-util suite registration failed\n", stderr);
        CU_cleanup_registry();
        goto done;
    }

    /*
     * ut-core implements -d/-e group selection with inactive suites. Skipping
     * those suites is intentional, not a failure; retain all result checks
     * below so real failures and runs selecting no tests still fail.
     */
    CU_set_fail_on_inactive(CU_FALSE);
    running = true;
    const UT_status_t status = UT_run_tests();
    running = false;
    if (status == UT_STATUS_OK && captured_results && tests_run != 0U &&
        failed_tests == 0U && failed_assertions == 0U && failed_suites == 0U &&
        failure_records == 0U && run_error == CUE_SUCCESS)
        result = EXIT_SUCCESS;

done:
    /* UT_exit is idempotent; also cover early configuration/registration errors. */
    UT_exit();
    free(core_args);
    return result;
}
