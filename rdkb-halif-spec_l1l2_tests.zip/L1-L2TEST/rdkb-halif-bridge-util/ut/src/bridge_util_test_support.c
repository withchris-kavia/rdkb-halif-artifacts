/* SPDX-License-Identifier: Apache-2.0 */
#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <ut_kvp_profile.h>
#include "bridge_util_test_support.h"
#ifdef BUILD_LINUX
#include "bridge_util_test_backend.h"
#endif

/* PUBLIC_INTERFACE */
/** Load a complete KVP scalar or fail with an empty, terminated destination. */
int bridge_util_profile_string(const char *key, char *destination, size_t capacity)
{
    if (destination == NULL || capacity == 0U)
        return -1;
    memset(destination, 0, capacity);
    if (key == NULL || key[0] == '\0' ||
        strlen(key) >= UT_KVP_MAX_ELEMENT_SIZE || capacity > UINT32_MAX ||
        ut_kvp_profile_getInstance() == NULL)
        return -1;

    /* ut-control uses strncpy and reports success even when it truncates.
     * Check for NUL BEFORE adding one; otherwise truncation would look valid. */
    const ut_kvp_status_t status = ut_kvp_getStringField(
        ut_kvp_profile_getInstance(), key, destination, (uint32_t)capacity);
    if (status != UT_KVP_STATUS_SUCCESS ||
        memchr(destination, '\0', capacity) == NULL) {
        memset(destination, 0, capacity);
        fprintf(stderr, "Invalid or over-capacity profile scalar: %s\n", key);
        return -1;
    }
    return 0;
}

static int read_integer(const char *key, int *result)
{
    char text[32];
    if (bridge_util_profile_string(key, text, sizeof(text)) != 0 ||
        text[0] == '\0')
        return -1;
    /* No whitespace, '+', fractional values, or implicit base conversion. */
    size_t start = text[0] == '-' ? 1U : 0U;
    if (text[start] == '\0')
        return -1;
    for (size_t i = start; text[i] != '\0'; ++i)
        if (text[i] < '0' || text[i] > '9')
            return -1;
    errno = 0;
    char *end = NULL;
    const long value = strtol(text, &end, 10);
    if (errno != 0 || *end != '\0' || value < INT_MIN || value > INT_MAX)
        return -1;
    *result = (int)value;
    return 0;
}

static bool valid_config(int config)
{
    switch (config) {
    case PRIVATE_LAN:
    case HOME_SECURITY:
    case HOTSPOT_2G:
    case HOTSPOT_5G:
    case LOST_N_FOUND:
    case HOTSPOT_SECURE_2G:
    case HOTSPOT_SECURE_5G:
    case MOCA_ISOLATION:
    case MESH_BACKHAUL:
    case ETH_BACKHAUL:
    case MESH:
    case MESH_WIFI_BACKHAUL_2G:
    case MESH_WIFI_BACKHAUL_5G:
    case MESH_ONBOARD:
    case MESH_WIFI_ONBOARD_2G:
#ifdef WIFI_MANAGE_SUPPORTED
    case MANAGE_WIFI_BRIDGE:
#endif
#if defined(AMENITIES_NETWORK_ENABLED) && !defined(_CBR2_PRODUCT_REQ_)
    case AMENITY_BRIDGE_2G:
    case AMENITY_BRIDGE_5G:
    case AMENITY_BRIDGE_6G:
#endif
        return true;
    default:
        return false;
    }
}

static bool list_contains(const char *list, const char *name)
{
    const size_t length = strlen(name);
    while (*list != '\0') {
        list += strspn(list, " \t\r\n\v\f");
        const size_t size = strcspn(list, " \t\r\n\v\f");
        if (length == size && size != 0U && memcmp(list, name, size) == 0)
            return true;
        list += size;
    }
    return false;
}

static int load_policy(bridge_util_fixture_t *fixture)
{
    char backend[32];
    char ownership[32];
    char null_target[32];
    if (bridge_util_profile_string("bridge_util/policy/backend",
                                  backend, sizeof(backend)) != 0 ||
        bridge_util_profile_string("bridge_util/policy/vendor_list_ownership",
                                  ownership, sizeof(ownership)) != 0 ||
        bridge_util_profile_string("bridge_util/policy/non_sync_target",
                                  null_target, sizeof(null_target)) != 0 ||
        bridge_util_profile_string("bridge_util/policy/vendor_ifaces",
                                  fixture->vendor_ifaces,
                                  sizeof(fixture->vendor_ifaces)) != 0 ||
        read_integer("bridge_util/policy/create_operation",
                     &fixture->create_operation) != 0 ||
        read_integer("bridge_util/policy/delete_operation",
                     &fixture->delete_operation) != 0 ||
        read_integer("bridge_util/policy/attach_operation",
                     &fixture->attach_operation) != 0 ||
        read_integer("bridge_util/policy/detach_operation",
                     &fixture->detach_operation) != 0)
        return -1;

    fixture->linux_reference = strcmp(backend, "linux-reference") == 0;
#ifdef BUILD_LINUX
    if (!fixture->linux_reference || strcmp(ownership, "borrowed-until-reset") != 0 ||
        strcmp(null_target, "optional-ignored") != 0 ||
        fixture->create_operation != BRIDGE_UTIL_TEST_CREATE ||
        fixture->delete_operation != BRIDGE_UTIL_TEST_DELETE ||
        fixture->attach_operation != BRIDGE_UTIL_TEST_ATTACH ||
        fixture->detach_operation != BRIDGE_UTIL_TEST_DETACH)
        return -1;
#else
    /* Vendor operation numbers and ownership are not defined by our headers.
     * Require an explicit vendor profile, never silently apply model policy. */
    if (strcmp(backend, "vendor") != 0 || ownership[0] == '\0' ||
        null_target[0] == '\0')
        return -1;
#endif
    return 0;
}

/* PUBLIC_INTERFACE */
/** Publish fixture data only after all scalar, integer and consistency checks pass. */
int bridge_util_fixture_load(bridge_util_fixture_t *fixture)
{
    if (fixture == NULL)
        return -1;
    bridge_util_fixture_t next = {0};
    struct string_field {
        const char *key;
        char *destination;
        size_t capacity;
    };
#define FIELD(key, member) { "bridge_util/" key, next.member, sizeof(next.member) }
    const struct string_field fields[] = {
        FIELD("config/br_Name", bridge_name),
        FIELD("config/ifaceName", iface_name),
        FIELD("config/ifNameToBeUpdated", update_iface),
        FIELD("config/iface_to_remove", remove_iface),
        FIELD("config/iface_list", iface_list),
        FIELD("config/expected_list", expected_list),
        FIELD("config/bridgeDetails/bridgeName", details.bridgeName),
        FIELD("config/bridgeDetails/vlan_name", details.vlan_name),
        FIELD("config/bridgeDetails/VirtualParentIfname", details.VirtualParentIfname),
        FIELD("config/bridgeDetails/ethIfList", details.ethIfList),
        FIELD("config/bridgeDetails/MoCAIfList", details.MoCAIfList),
        FIELD("config/bridgeDetails/GreIfList", details.GreIfList),
        FIELD("config/bridgeDetails/WiFiIfList", details.WiFiIfList)
    };
#undef FIELD
    for (size_t i = 0; i < sizeof(fields) / sizeof(fields[0]); ++i)
        if (bridge_util_profile_string(fields[i].key, fields[i].destination,
                                      fields[i].capacity) != 0)
            return -1;
    if (read_integer("bridge_util/config/bridgeDetails/vlanID",
                     &next.details.vlanID) != 0 ||
        read_integer("bridge_util/config/InstanceNumber", &next.instance) != 0 ||
        !valid_config(next.instance) || load_policy(&next) != 0)
        return -1;

    if (next.bridge_name[0] == '\0' || next.iface_name[0] == '\0' ||
        next.update_iface[0] == '\0' || next.remove_iface[0] == '\0' ||
        strcmp(next.bridge_name, next.details.bridgeName) != 0 ||
        !list_contains(next.iface_list, next.remove_iface) ||
        list_contains(next.expected_list, next.remove_iface))
        return -1;
    const bool member = list_contains(next.details.ethIfList, next.iface_name) ||
        list_contains(next.details.MoCAIfList, next.iface_name) ||
        list_contains(next.details.GreIfList, next.iface_name) ||
        list_contains(next.details.WiFiIfList, next.iface_name) ||
        strcmp(next.details.vlan_name, next.iface_name) == 0;
    if (!member)
        return -1;
#ifdef BUILD_LINUX
    /* Pure validation: do not seed/reset state merely by reading a profile. */
    if (HandlePreConfigVendor(&next.details, next.instance) != 0)
        return -1;
    char remainder[TOTAL_IFLIST_SIZE];
    memcpy(remainder, next.iface_list, sizeof(remainder));
    removeIfaceFromList(remainder, next.remove_iface);
    if (strcmp(remainder, next.expected_list) != 0)
        return -1;
#endif
    *fixture = next;
    return 0;
}

/* PUBLIC_INTERFACE */
/** Reset/seed reference-only state; vendor fixtures never trigger device actions. */
int bridge_util_fixture_prepare(const bridge_util_fixture_t *fixture)
{
    if (fixture == NULL)
        return -1;
#ifdef BUILD_LINUX
    if (!fixture->linux_reference)
        return -1;
    bridge_util_test_reset();
    if (bridge_util_test_set_vendor_ifaces(fixture->vendor_ifaces) != 0 ||
        bridge_util_test_seed_bridge(&fixture->details) != 0) {
        bridge_util_test_reset();
        return -1;
    }
#endif
    return 0;
}
