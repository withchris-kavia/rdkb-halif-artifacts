/*
 * Copyright 2023 RDK Management
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @file test_l2_bridge_util_hal.c
 * Eight native L2 scenarios, not a hardware or vendor-acceptance suite.
 *
 * Public contract: include/bridge_util_hal.h documents updates, existence,
 * membership, pre/update/post ordering, absent-token removal and nullable vendor
 * lists. Reference-only expectations (operation numbers, typed selection,
 * idempotency, interface persistence, atomic failure, reset and ownership)
 * are specified in skeletons/include/bridge_util_test_backend.h and the profile.
 *
 * No OS networking, shell commands, external stimulus or inferred OVS_CMD ABI.
 * Every case resets before use and verifies cleanup. A fatal assertion may
 * interrupt a case, but the next case and suite cleanup still reset the model.
 */
#include <stddef.h>
#include <limits.h>
#include <stdbool.h>
#include <string.h>
#include <ut.h>

#include "bridge_util_test_support.h"
#ifdef BUILD_LINUX
#include "bridge_util_test_backend.h"

static bridge_util_fixture_t fixture;

static int suite_init(void)
{
    if (bridge_util_fixture_load(&fixture) != 0 || !fixture.linux_reference)
        return -1;
    bridge_util_test_reset();
    return 0;
}

static int suite_cleanup(void)
{
    bridge_util_test_reset();
    return checkIfExists(fixture.bridge_name) == INTERFACE_NOT_EXIST &&
           checkIfExists(fixture.iface_name) == INTERFACE_NOT_EXIST &&
           getVendorIfaces() == NULL ? 0 : -1;
}

static void begin_case(bridge_util_fixture_t *f)
{
    *f = fixture;
    UT_ASSERT_EQUAL_FATAL(bridge_util_fixture_prepare(f), 0);
    /* Validate seed support before intentionally starting the scenario blank. */
    UT_ASSERT_EQUAL_FATAL(checkIfExistsInBridge(f->iface_name, f->bridge_name), 0);
    bridge_util_test_reset();
    UT_ASSERT_EQUAL(checkIfExists(f->bridge_name), INTERFACE_NOT_EXIST);
    UT_ASSERT_EQUAL(checkIfExists(f->iface_name), INTERFACE_NOT_EXIST);
    UT_ASSERT_EQUAL_FATAL(bridge_util_test_set_vendor_ifaces(f->vendor_ifaces), 0);
}

static bool contains_token(const char *list, const char *name)
{
    const size_t length = strlen(name);
    while (*list != '\0') {
        list += strspn(list, " \t\r\n\v\f");
        const size_t count = strcspn(list, " \t\r\n\v\f");
        if (count == length && count != 0U && memcmp(list, name, count) == 0)
            return true;
        list += count;
    }
    return false;
}

static bool configured_member(const bridgeDetails *details, const char *name)
{
    return strcmp(details->vlan_name, name) == 0 ||
           contains_token(details->ethIfList, name) ||
           contains_token(details->MoCAIfList, name) ||
           contains_token(details->GreIfList, name) ||
           contains_token(details->WiFiIfList, name);
}

static void expect_name(const char *name, const char *bridge,
                        int existence, int membership)
{
    /* HAL query arguments are writable, so also verify they are not outputs. */
    char iface[IFACE_NAME_SIZE];
    char br[BRIDGE_NAME_SIZE];
    UT_ASSERT_TRUE_FATAL(strlen(name) < sizeof(iface));
    UT_ASSERT_TRUE_FATAL(strlen(bridge) < sizeof(br));
    strcpy(iface, name);
    strcpy(br, bridge);
    UT_ASSERT_EQUAL(checkIfExists(iface), existence);
    UT_ASSERT_EQUAL(checkIfExistsInBridge(iface, br), membership);
    UT_ASSERT_STRING_EQUAL(name, iface);
    UT_ASSERT_STRING_EQUAL(bridge, br);
}

static void expect_list(const char *list, const char *bridge,
                        int existence, int membership)
{
    while (*list != '\0') {
        list += strspn(list, " \t\r\n\v\f");
        const size_t length = strcspn(list, " \t\r\n\v\f");
        if (length == 0U)
            break;
        char name[IFACE_NAME_SIZE];
        UT_ASSERT_TRUE_FATAL(length < sizeof(name));
        memcpy(name, list, length);
        name[length] = '\0';
        expect_name(name, bridge, existence, membership);
        list += length;
    }
}

static void expect_configured(const bridgeDetails *details,
                              int existence, int membership)
{
    if (details->vlan_name[0] != '\0')
        expect_name(details->vlan_name, details->bridgeName, existence, membership);
    expect_list(details->ethIfList, details->bridgeName, existence, membership);
    expect_list(details->MoCAIfList, details->bridgeName, existence, membership);
    expect_list(details->GreIfList, details->bridgeName, existence, membership);
    expect_list(details->WiFiIfList, details->bridgeName, existence, membership);
}

static void finish_case(bridge_util_fixture_t *f)
{
    UT_ASSERT_EQUAL(updateBridgeInfo(&f->details, NULL, f->delete_operation,
                                    IF_BRIDGE_BRIDGEUTIL), 0);
    UT_ASSERT_EQUAL(checkIfExists(f->bridge_name), INTERFACE_NOT_EXIST);
    UT_ASSERT_EQUAL(checkIfExistsInBridge(f->iface_name, f->bridge_name), -1);
    bridge_util_test_reset();
    UT_ASSERT_EQUAL(checkIfExists(f->bridge_name), INTERFACE_NOT_EXIST);
    UT_ASSERT_EQUAL(checkIfExists(f->iface_name), INTERFACE_NOT_EXIST);
    UT_ASSERT_EQUAL(checkIfExists(f->update_iface), INTERFACE_NOT_EXIST);
    UT_ASSERT_PTR_NULL(getVendorIfaces());
}

/** L2-01: creating a bridge makes all configured members directly observable. */
static void test_create_existence_membership(void)
{
    bridge_util_fixture_t f;
    begin_case(&f);
    const bridgeDetails before = f.details;
    UT_ASSERT_EQUAL_FATAL(updateBridgeInfo(&f.details, NULL, f.create_operation,
                                          IF_BRIDGE_BRIDGEUTIL), 0);
    UT_ASSERT_EQUAL(checkIfExists(f.bridge_name), INTERFACE_EXIST);
    expect_configured(&f.details, INTERFACE_EXIST, 0);
    UT_ASSERT_EQUAL(memcmp(&before, &f.details, sizeof(before)), 0);

    UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, NULL, f.delete_operation,
                                    IF_BRIDGE_BRIDGEUTIL), 0);
    UT_ASSERT_EQUAL(checkIfExists(f.bridge_name), INTERFACE_NOT_EXIST);
    /* Reference policy removes membership, not the interface inventory. */
    expect_configured(&f.details, INTERFACE_EXIST, -1);
    finish_case(&f);
}

/** L2-02: sync attach/detach is idempotent and does not delete the interface. */
static void test_attach_detach_lifecycle(void)
{
    bridge_util_fixture_t f;
    begin_case(&f);
    bridgeDetails empty = {0};
    strcpy(empty.bridgeName, f.bridge_name);
    UT_ASSERT_EQUAL_FATAL(updateBridgeInfo(&empty, NULL, f.create_operation,
                                          IF_BRIDGE_BRIDGEUTIL), 0);
    expect_name(f.update_iface, f.bridge_name, INTERFACE_NOT_EXIST, -1);
    for (int repeat = 0; repeat < 2; ++repeat) {
        UT_ASSERT_EQUAL(updateBridgeInfo(&empty, f.update_iface,
                                        f.attach_operation, IF_OTHER_BRIDGEUTIL), 0);
        expect_name(f.update_iface, f.bridge_name, INTERFACE_EXIST, 0);
    }
    for (int repeat = 0; repeat < 2; ++repeat) {
        UT_ASSERT_EQUAL(updateBridgeInfo(&empty, f.update_iface,
                                        f.detach_operation, IF_OTHER_BRIDGEUTIL), 0);
        expect_name(f.update_iface, f.bridge_name, INTERFACE_EXIST, -1);
    }
    UT_ASSERT_EQUAL(updateBridgeInfo(&empty, f.update_iface,
                                    f.attach_operation, IF_OTHER_BRIDGEUTIL), 0);
    expect_name(f.update_iface, f.bridge_name, INTERFACE_EXIST, 0);
    finish_case(&f);
}

/** L2-03: unrelated bridges stay isolated, including a conflicting attachment. */
static void test_two_bridge_isolation(void)
{
    bridge_util_fixture_t f;
    begin_case(&f);
    bridgeDetails second = {
        .bridgeName = "l2-isolation-br",
        .ethIfList = "l2-isolation-if"
    };
    UT_ASSERT_STRING_NOT_EQUAL(f.bridge_name, second.bridgeName);
    UT_ASSERT_FALSE(configured_member(&f.details, second.ethIfList));
    UT_ASSERT_EQUAL_FATAL(updateBridgeInfo(&f.details, NULL, f.create_operation,
                                          IF_BRIDGE_BRIDGEUTIL), 0);
    UT_ASSERT_EQUAL_FATAL(updateBridgeInfo(&second, NULL, f.create_operation,
                                          IF_BRIDGE_BRIDGEUTIL), 0);
    expect_name(f.iface_name, f.bridge_name, INTERFACE_EXIST, 0);
    expect_name(f.iface_name, second.bridgeName, INTERFACE_EXIST, -1);
    expect_name(second.ethIfList, f.bridge_name, INTERFACE_EXIST, -1);
    expect_name(second.ethIfList, second.bridgeName, INTERFACE_EXIST, 0);

    UT_ASSERT_EQUAL(updateBridgeInfo(&second, f.iface_name, f.attach_operation,
                                    IF_OTHER_BRIDGEUTIL), -1);
    expect_configured(&f.details, INTERFACE_EXIST, 0);
    expect_name(second.ethIfList, second.bridgeName, INTERFACE_EXIST, 0);
    expect_name(f.iface_name, second.bridgeName, INTERFACE_EXIST, -1);

    UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, f.iface_name, f.detach_operation,
                                    IF_OTHER_BRIDGEUTIL), 0);
    UT_ASSERT_EQUAL(updateBridgeInfo(&second, f.iface_name, f.attach_operation,
                                    IF_OTHER_BRIDGEUTIL), 0);
    expect_name(f.iface_name, f.bridge_name, INTERFACE_EXIST, -1);
    expect_name(f.iface_name, second.bridgeName, INTERFACE_EXIST, 0);
    UT_ASSERT_EQUAL(updateBridgeInfo(&second, NULL, f.delete_operation,
                                    IF_BRIDGE_BRIDGEUTIL), 0);
    UT_ASSERT_EQUAL(checkIfExists(second.bridgeName), INTERFACE_NOT_EXIST);
    UT_ASSERT_EQUAL(checkIfExists(f.bridge_name), INTERFACE_EXIST);
    expect_name(second.ethIfList, second.bridgeName, INTERFACE_EXIST, -1);
    finish_case(&f);
    UT_ASSERT_EQUAL(checkIfExists(second.ethIfList), INTERFACE_NOT_EXIST);
}

/** L2-04: pre/update/post ordering with non-mutating reference hooks. */
static void test_pre_update_post_hooks(void)
{
    bridge_util_fixture_t f;
    begin_case(&f);
    const bridgeDetails before = f.details;
    UT_ASSERT_EQUAL(HandlePreConfigVendor(&f.details, f.instance), 0);
    UT_ASSERT_EQUAL(checkIfExists(f.bridge_name), INTERFACE_NOT_EXIST);
    UT_ASSERT_EQUAL(checkIfExists(f.iface_name), INTERFACE_NOT_EXIST);

    UT_ASSERT_EQUAL_FATAL(updateBridgeInfo(&f.details, NULL, f.create_operation,
                                          IF_BRIDGE_BRIDGEUTIL), 0);
    UT_ASSERT_EQUAL(HandlePostConfigVendor(&f.details, f.instance), 0);
    expect_configured(&f.details, INTERFACE_EXIST, 0);
    UT_ASSERT_EQUAL(memcmp(&before, &f.details, sizeof(before)), 0);

    UT_ASSERT_EQUAL(HandlePreConfigVendor(&f.details, f.instance), 0);
    UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, f.iface_name, f.detach_operation,
                                    IF_OTHER_BRIDGEUTIL), 0);
    UT_ASSERT_EQUAL(HandlePostConfigVendor(&f.details, f.instance), 0);
    expect_name(f.iface_name, f.bridge_name, INTERFACE_EXIST, -1);
    UT_ASSERT_EQUAL(HandlePreConfigVendor(&f.details, 5), -1);
    UT_ASSERT_EQUAL(HandlePostConfigVendor(NULL, f.instance), -1);
    expect_name(f.iface_name, f.bridge_name, INTERFACE_EXIST, -1);
    UT_ASSERT_EQUAL(checkIfExists(f.bridge_name), INTERFACE_EXIST);
    UT_ASSERT_EQUAL(memcmp(&before, &f.details, sizeof(before)), 0);
    finish_case(&f);
}

static void expect_selected_list(const char *candidates,
                                 const char *selected, bool select_all,
                                 bool attached, bridge_util_fixture_t *f)
{
    while (*candidates != '\0') {
        candidates += strspn(candidates, " \t\r\n\v\f");
        const size_t length = strcspn(candidates, " \t\r\n\v\f");
        if (length == 0U)
            break;
        char name[IFACE_NAME_SIZE];
        UT_ASSERT_TRUE_FATAL(length < sizeof(name));
        memcpy(name, candidates, length);
        name[length] = '\0';
        const bool included = select_all ? configured_member(&f->details, name) :
                                           contains_token(selected, name);
        expect_name(name, f->bridge_name,
                    included ? INTERFACE_EXIST : INTERFACE_NOT_EXIST,
                    included && attached ? 0 : -1);
        candidates += length;
    }
}

/** L2-05: each public type selects only its configured list (OTHER uses target). */
static void test_configured_interface_types(void)
{
    const int types[] = {
        IF_BRIDGE_BRIDGEUTIL, IF_VLAN_BRIDGEUTIL, IF_GRE_BRIDGEUTIL,
        IF_MOCA_BRIDGEUTIL, IF_WIFI_BRIDGEUTIL, IF_ETH_BRIDGEUTIL,
        IF_OTHER_BRIDGEUTIL
    };
    for (size_t i = 0; i < sizeof(types) / sizeof(types[0]); ++i) {
        bridge_util_fixture_t f;
        begin_case(&f);
        const char *selected[] = {
            "", f.details.vlan_name, f.details.GreIfList, f.details.MoCAIfList,
            f.details.WiFiIfList, f.details.ethIfList, f.update_iface
        };
        const char *candidates[] = {
            f.details.vlan_name, f.details.ethIfList, f.details.MoCAIfList,
            f.details.GreIfList, f.details.WiFiIfList, f.update_iface
        };
        const bridgeDetails before = f.details;
        UT_ASSERT_EQUAL_FATAL(updateBridgeInfo(&f.details, f.update_iface,
                                              f.create_operation, types[i]), 0);
        UT_ASSERT_EQUAL(checkIfExists(f.bridge_name), INTERFACE_EXIST);
        for (size_t j = 0; j < sizeof(candidates) / sizeof(candidates[0]); ++j)
            expect_selected_list(candidates[j], selected[i],
                                 types[i] == IF_BRIDGE_BRIDGEUTIL, true, &f);
        UT_ASSERT_EQUAL(memcmp(&before, &f.details, sizeof(before)), 0);

        UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, f.update_iface,
                                        f.detach_operation, types[i]), 0);
        for (size_t j = 0; j < sizeof(candidates) / sizeof(candidates[0]); ++j)
            expect_selected_list(candidates[j], selected[i],
                                 types[i] == IF_BRIDGE_BRIDGEUTIL, false, &f);
        UT_ASSERT_EQUAL(checkIfExists(f.bridge_name), INTERFACE_EXIST);
        finish_case(&f);
    }
}

/** L2-06: list transformations preserve survivors, token boundaries and canaries. */
static void test_list_removal_invariants(void)
{
    bridge_util_fixture_t f;
    begin_case(&f);
    UT_ASSERT_EQUAL_FATAL(updateBridgeInfo(&f.details, NULL, f.create_operation,
                                          IF_BRIDGE_BRIDGEUTIL), 0);
    const struct {
        const char *input;
        const char *target;
        const char *expected;
    } cases[] = {
        {"moca0 eth0 wlan0", "moca0", "eth0 wlan0"},
        {"eth0 moca0 wlan0", "moca0", "eth0 wlan0"},
        {"eth0 wlan0 moca0", "moca0", "eth0 wlan0"},
        {"moca0", "moca0", ""},
        {"moca0 moca0 eth0 moca0", "moca0", "eth0"},
        {"moca00 moca0 xmoca0 moca0.1", "moca0", "moca00 xmoca0 moca0.1"},
        {" \teth0\nmoca0 \r\n wlan0  ", "moca0", "eth0 wlan0"},
        {" \teth0  wlan0\n", "absent", " \teth0  wlan0\n"},
        {"", "moca0", ""},
        {"eth0 moca0", "", "eth0 moca0"},
        {"eth0 moca0", NULL, "eth0 moca0"}
    };
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
        struct {
            unsigned char before[8];
            char list[TOTAL_IFLIST_SIZE];
            unsigned char after[8];
        } guarded;
        memset(&guarded, 0xa5, sizeof(guarded));
        strcpy(guarded.list, cases[i].input);
        removeIfaceFromList(guarded.list, cases[i].target);
        UT_ASSERT_PTR_NOT_NULL_FATAL(memchr(guarded.list, '\0', sizeof(guarded.list)));
        UT_ASSERT_STRING_EQUAL(cases[i].expected, guarded.list);
        for (size_t j = 0; j < sizeof(guarded.before); ++j) {
            UT_ASSERT_EQUAL(guarded.before[j], 0xa5);
            UT_ASSERT_EQUAL(guarded.after[j], 0xa5);
        }
        char snapshot[TOTAL_IFLIST_SIZE];
        memcpy(snapshot, guarded.list, sizeof(snapshot));
        removeIfaceFromList(guarded.list, cases[i].target);
        UT_ASSERT_EQUAL(memcmp(snapshot, guarded.list, sizeof(snapshot)), 0);
    }
    char alias[] = "eth0 moca0";
    removeIfaceFromList(alias, alias + 5);
    UT_ASSERT_STRING_EQUAL("eth0", alias);
    char full[TOTAL_IFLIST_SIZE];
    for (size_t i = 0; i < sizeof(full) - 1U; ++i)
        full[i] = i % 2U == 0U ? 'x' : ' ';
    full[sizeof(full) - 1U] = '\0';
    removeIfaceFromList(full, "x");
    UT_ASSERT_STRING_EQUAL("", full);
    /* Local string removal must not detach actual modeled interfaces. */
    expect_configured(&f.details, INTERFACE_EXIST, 0);
    finish_case(&f);
}

/** L2-07: repeated getters are read-only; delete/recreate/reset cannot leak state. */
static void test_repeated_query_cleanup_isolation(void)
{
    bridge_util_fixture_t f;
    begin_case(&f);
    const char vendor[] = "l2-vendor0 l2-vendor1";
    UT_ASSERT_EQUAL_FATAL(bridge_util_test_set_vendor_ifaces(vendor), 0);
    for (int cycle = 0; cycle < 3; ++cycle) {
        UT_ASSERT_EQUAL_FATAL(updateBridgeInfo(&f.details, NULL, f.create_operation,
                                              IF_BRIDGE_BRIDGEUTIL), 0);
        const bridgeDetails before = f.details;
        for (int query = 0; query < 5; ++query) {
            expect_configured(&f.details, INTERFACE_EXIST, 0);
            char *names = getVendorIfaces();
            UT_ASSERT_PTR_NOT_NULL_FATAL(names);
            UT_ASSERT_STRING_EQUAL(vendor, names);
            UT_ASSERT_EQUAL(memcmp(&before, &f.details, sizeof(before)), 0);
        }
        UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, NULL, f.delete_operation,
                                        IF_BRIDGE_BRIDGEUTIL), 0);
        UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, NULL, f.delete_operation,
                                        IF_BRIDGE_BRIDGEUTIL), 0);
        UT_ASSERT_EQUAL(checkIfExists(f.bridge_name), INTERFACE_NOT_EXIST);
        expect_configured(&f.details, INTERFACE_EXIST, -1);
    }
    bridge_util_test_reset();
    bridge_util_test_reset();
    UT_ASSERT_PTR_NULL(getVendorIfaces());
    UT_ASSERT_EQUAL(checkIfExists(f.iface_name), INTERFACE_NOT_EXIST);
    UT_ASSERT_EQUAL(checkIfExists(f.bridge_name), INTERFACE_NOT_EXIST);
    UT_ASSERT_EQUAL_FATAL(bridge_util_fixture_prepare(&f), 0);
    expect_configured(&f.details, INTERFACE_EXIST, 0);
    if (f.vendor_ifaces[0] == '\0') {
        UT_ASSERT_PTR_NULL(getVendorIfaces());
    } else {
        char *names = getVendorIfaces();
        UT_ASSERT_PTR_NOT_NULL_FATAL(names);
        UT_ASSERT_STRING_EQUAL(f.vendor_ifaces, names);
    }
    finish_case(&f);
}

static void expect_baseline(bridge_util_fixture_t *f)
{
    UT_ASSERT_EQUAL(checkIfExists(f->bridge_name), INTERFACE_EXIST);
    expect_configured(&f->details, INTERFACE_EXIST, 0);
    UT_ASSERT_EQUAL(memcmp(&f->details, &fixture.details, sizeof(f->details)), 0);
}

/** L2-08: failed operations are atomic, do not create objects, and allow recovery. */
static void test_error_state_invariants(void)
{
    bridge_util_fixture_t f;
    begin_case(&f);
    UT_ASSERT_EQUAL_FATAL(updateBridgeInfo(&f.details, NULL, f.create_operation,
                                          IF_BRIDGE_BRIDGEUTIL), 0);
    const struct {
        int operation;
        int type;
        char *target;
    } invalid[] = {
        {INT_MIN, IF_BRIDGE_BRIDGEUTIL, NULL},
        {INT_MAX, IF_BRIDGE_BRIDGEUTIL, NULL},
        {0, IF_BRIDGE_BRIDGEUTIL, NULL},
        {f.attach_operation, 0, NULL},
        {f.attach_operation, 8, NULL},
        {f.detach_operation, IF_OTHER_BRIDGEUTIL, NULL},
        {f.detach_operation, IF_OTHER_BRIDGEUTIL, ""},
        {f.attach_operation, IF_OTHER_BRIDGEUTIL, "invalid/name"}
    };
    for (size_t i = 0; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
        UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, invalid[i].target,
                                        invalid[i].operation, invalid[i].type), -1);
        expect_baseline(&f);
    }
    UT_ASSERT_EQUAL(updateBridgeInfo(NULL, f.update_iface, f.attach_operation,
                                    IF_OTHER_BRIDGEUTIL), -1);
    expect_baseline(&f);

    /* Every fixed-width HAL input must terminate; no read beyond the field. */
    const struct {
        size_t offset;
        size_t capacity;
    } fields[] = {
#define FIELD(member) {offsetof(bridgeDetails, member), \
                       sizeof(((bridgeDetails *)0)->member)}
        FIELD(bridgeName), FIELD(vlan_name), FIELD(VirtualParentIfname),
        FIELD(ethIfList), FIELD(MoCAIfList), FIELD(GreIfList), FIELD(WiFiIfList)
#undef FIELD
    };
    for (size_t i = 0; i < sizeof(fields) / sizeof(fields[0]); ++i) {
        bridgeDetails malformed = f.details;
        memset((char *)&malformed + fields[i].offset, 'x', fields[i].capacity);
        UT_ASSERT_EQUAL(updateBridgeInfo(&malformed, NULL, f.attach_operation,
                                        IF_BRIDGE_BRIDGEUTIL), -1);
        expect_baseline(&f);
    }

    /* A late invalid token must not publish an earlier valid member. */
    bridgeDetails request = f.details;
    strcpy(request.ethIfList, "l2-atomic-new invalid/name");
    UT_ASSERT_EQUAL(updateBridgeInfo(&request, NULL, f.attach_operation,
                                    IF_ETH_BRIDGEUTIL), -1);
    expect_name("l2-atomic-new", f.bridge_name, INTERFACE_NOT_EXIST, -1);
    expect_baseline(&f);

    /* A membership collision must roll back both a new bridge and new member. */
    bridgeDetails second = {.bridgeName = "l2-atomic-br"};
    const int length = snprintf(second.ethIfList, sizeof(second.ethIfList),
                                "l2-atomic-new %s", f.iface_name);
    UT_ASSERT_TRUE_FATAL(length > 0 && (size_t)length < sizeof(second.ethIfList));
    UT_ASSERT_EQUAL(updateBridgeInfo(&second, NULL, f.create_operation,
                                    IF_ETH_BRIDGEUTIL), -1);
    UT_ASSERT_EQUAL(checkIfExists(second.bridgeName), INTERFACE_NOT_EXIST);
    expect_name("l2-atomic-new", second.bridgeName, INTERFACE_NOT_EXIST, -1);
    expect_baseline(&f);
    UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, f.bridge_name, f.attach_operation,
                                    IF_OTHER_BRIDGEUTIL), -1);
    expect_baseline(&f);

    UT_ASSERT_EQUAL(updateBridgeInfo(&f.details, "l2-atomic-new", f.attach_operation,
                                    IF_OTHER_BRIDGEUTIL), 0);
    expect_name("l2-atomic-new", f.bridge_name, INTERFACE_EXIST, 0);
    finish_case(&f);
    UT_ASSERT_EQUAL(checkIfExists("l2-atomic-new"), INTERFACE_NOT_EXIST);
}
#endif /* BUILD_LINUX */

/* PUBLIC_INTERFACE */
/** Register exactly eight reference L2 cases, or reject unsupported vendor use. */
int test_bridge_util_hal_l2_register(void)
{
#ifndef BUILD_LINUX
    fputs("L2 reference scenarios require BUILD_LINUX; "
          "they must not exercise a vendor library using model policies.\n", stderr);
    return -1;
#else
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L2 bridge_util_hal_reference]", suite_init, suite_cleanup, UT_TESTS_L2);
    if (suite == NULL)
        return -1;
    const struct {
        const char *name;
        UT_TestFunction_t test;
    } cases[] = {
        {"L2_01_create_existence_membership", test_create_existence_membership},
        {"L2_02_attach_detach_lifecycle", test_attach_detach_lifecycle},
        {"L2_03_two_bridge_isolation", test_two_bridge_isolation},
        {"L2_04_pre_update_post_hooks", test_pre_update_post_hooks},
        {"L2_05_configured_interface_types", test_configured_interface_types},
        {"L2_06_list_removal_invariants", test_list_removal_invariants},
        {"L2_07_repeated_query_cleanup_isolation",
         test_repeated_query_cleanup_isolation},
        {"L2_08_error_state_invariants", test_error_state_invariants}
    };
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i)
        if (UT_add_test(suite, cases[i].name, cases[i].test) == NULL)
            return -1;
    return CU_get_error() == CUE_SUCCESS ? 0 : -1;
#endif
}
