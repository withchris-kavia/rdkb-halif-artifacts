/*
 * Copyright 2023 RDK Management
 * SPDX-License-Identifier: Apache-2.0
 */
#include <stdbool.h>
#include <stddef.h>
#include <string.h>

#include "bridge_util_test_backend.h"

#define WEAK __attribute__((weak))

WEAK int DeviceMode;
WEAK int MocaIsolation_Val;
WEAK int need_wifi_gw_refresh;
WEAK int need_switch_gw_refresh;
WEAK int syncMembers;
WEAK int BridgeOprInPropgress;
WEAK FILE *logFp;
WEAK char log_buff[MAX_LOG_BUFF_SIZE];
WEAK char log_msg_wtime[MAX_LOG_BUFF_SIZE + TIMESTAMP];
WEAK char primaryBridgeName[64];
WEAK int PORT2ENABLE;
WEAK int ethWanEnabled;
WEAK char ethWanIfaceName[64];
WEAK struct tm *timeinfo;
WEAK time_t utc_time;

typedef struct {
    bool used;
    char name[BRIDGE_NAME_SIZE];
    size_t count;
    char members[BRIDGE_UTIL_TEST_MAX_MEMBERS][IFACE_NAME_SIZE];
} model_bridge_t;

typedef struct {
    model_bridge_t bridges[BRIDGE_UTIL_TEST_MAX_BRIDGES];
    size_t count;
    char interfaces[BRIDGE_UTIL_TEST_MAX_INTERFACES][IFACE_NAME_SIZE];
} model_state_t;

typedef struct {
    size_t count;
    char names[BRIDGE_UTIL_TEST_MAX_MEMBERS][IFACE_NAME_SIZE];
} selection_t;

static model_state_t model;
static char vendor_ifaces[TOTAL_IFLIST_SIZE];

static bool is_space(char value)
{
    return value == ' ' || value == '\t' || value == '\r' ||
           value == '\n' || value == '\v' || value == '\f';
}

static bool valid_name(const char *name)
{
    if (name == NULL || name[0] == '\0')
        return false;
    for (size_t i = 0; i < IFACE_NAME_SIZE; ++i) {
        const char c = name[i];
        if (c == '\0')
            return true;
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '_' || c == '.' ||
              c == ':' || c == '-'))
            return false;
    }
    return false;
}

static bool valid_details(const bridgeDetails *details)
{
    return details != NULL &&
           memchr(details->bridgeName, '\0', sizeof(details->bridgeName)) != NULL &&
           valid_name(details->bridgeName) &&
           memchr(details->vlan_name, '\0', sizeof(details->vlan_name)) != NULL &&
           (details->vlan_name[0] == '\0' || valid_name(details->vlan_name)) &&
           memchr(details->VirtualParentIfname, '\0',
                  sizeof(details->VirtualParentIfname)) != NULL &&
           (details->VirtualParentIfname[0] == '\0' ||
            valid_name(details->VirtualParentIfname)) &&
           memchr(details->ethIfList, '\0', sizeof(details->ethIfList)) != NULL &&
           memchr(details->MoCAIfList, '\0', sizeof(details->MoCAIfList)) != NULL &&
           memchr(details->GreIfList, '\0', sizeof(details->GreIfList)) != NULL &&
           memchr(details->WiFiIfList, '\0', sizeof(details->WiFiIfList)) != NULL;
}

static bool valid_config(int config)
{
    switch (config) {
    case PRIVATE_LAN:
    case HOME_SECURITY:
    case HOTSPOT_2G:
    case HOTSPOT_5G:
    case LOST_N_FOUND:
    case HOTSPOT_SECURE_2G:
    case HOTSPOT_SECURE_5G:
    case MOCA_ISOLATION:
    case MESH_BACKHAUL:
    case ETH_BACKHAUL:
    case MESH:
    case MESH_WIFI_BACKHAUL_2G:
    case MESH_WIFI_BACKHAUL_5G:
    case MESH_ONBOARD:
    case MESH_WIFI_ONBOARD_2G:
#ifdef WIFI_MANAGE_SUPPORTED
    case MANAGE_WIFI_BRIDGE:
#endif
#if defined(AMENITIES_NETWORK_ENABLED) && !defined(_CBR2_PRODUCT_REQ_)
    case AMENITY_BRIDGE_2G:
    case AMENITY_BRIDGE_5G:
    case AMENITY_BRIDGE_6G:
#endif
        return true;
    default:
        return false;
    }
}

static int bridge_index(const model_state_t *state, const char *name)
{
    for (size_t i = 0; i < BRIDGE_UTIL_TEST_MAX_BRIDGES; ++i)
        if (state->bridges[i].used && strcmp(state->bridges[i].name, name) == 0)
            return (int)i;
    return -1;
}

static int interface_index(const model_state_t *state, const char *name)
{
    for (size_t i = 0; i < state->count; ++i)
        if (strcmp(state->interfaces[i], name) == 0)
            return (int)i;
    return -1;
}

static int member_index(const model_bridge_t *bridge, const char *name)
{
    for (size_t i = 0; i < bridge->count; ++i)
        if (strcmp(bridge->members[i], name) == 0)
            return (int)i;
    return -1;
}

static int add_interface(model_state_t *state, const char *name)
{
    if (interface_index(state, name) >= 0)
        return 0;
    if (state->count == BRIDGE_UTIL_TEST_MAX_INTERFACES ||
        bridge_index(state, name) >= 0)
        return -1;
    strcpy(state->interfaces[state->count++], name);
    return 0;
}

static int select_name(selection_t *selected, const char *name)
{
    if (!valid_name(name))
        return -1;
    for (size_t i = 0; i < selected->count; ++i)
        if (strcmp(selected->names[i], name) == 0)
            return 0;
    if (selected->count == BRIDGE_UTIL_TEST_MAX_MEMBERS)
        return -1;
    strcpy(selected->names[selected->count++], name);
    return 0;
}

static int select_list(selection_t *selected, const char *list)
{
    const char *cursor = list;
    while (*cursor != '\0') {
        char name[IFACE_NAME_SIZE];
        size_t length = 0U;
        while (is_space(*cursor))
            ++cursor;
        while (*cursor != '\0' && !is_space(*cursor)) {
            if (length == sizeof(name) - 1U)
                return -1;
            name[length++] = *cursor++;
        }
        if (length != 0U) {
            name[length] = '\0';
            if (select_name(selected, name) != 0)
                return -1;
        }
    }
    return 0;
}

static int select_members(const bridgeDetails *details, const char *target,
                          int type, selection_t *selected)
{
    switch (type) {
    case IF_BRIDGE_BRIDGEUTIL:
        if (details->vlan_name[0] != '\0' &&
            select_name(selected, details->vlan_name) != 0)
            return -1;
        return select_list(selected, details->ethIfList) != 0 ||
               select_list(selected, details->MoCAIfList) != 0 ||
               select_list(selected, details->GreIfList) != 0 ||
               select_list(selected, details->WiFiIfList) != 0 ? -1 : 0;
    case IF_VLAN_BRIDGEUTIL:
        return details->vlan_name[0] == '\0' ? 0 :
               select_name(selected, details->vlan_name);
    case IF_GRE_BRIDGEUTIL:
        return select_list(selected, details->GreIfList);
    case IF_MOCA_BRIDGEUTIL:
        return select_list(selected, details->MoCAIfList);
    case IF_WIFI_BRIDGEUTIL:
        return select_list(selected, details->WiFiIfList);
    case IF_ETH_BRIDGEUTIL:
        return select_list(selected, details->ethIfList);
    case IF_OTHER_BRIDGEUTIL:
        return select_name(selected, target);
    default:
        return -1;
    }
}

static int attach_members(model_state_t *state, int index,
                          const selection_t *selected)
{
    model_bridge_t *bridge = &state->bridges[index];
    for (size_t i = 0; i < selected->count; ++i) {
        const char *name = selected->names[i];
        if (bridge_index(state, name) >= 0)
            return -1;
        for (size_t j = 0; j < BRIDGE_UTIL_TEST_MAX_BRIDGES; ++j)
            if ((int)j != index && state->bridges[j].used &&
                member_index(&state->bridges[j], name) >= 0)
                return -1;
        if (member_index(bridge, name) >= 0)
            continue;
        if (bridge->count == BRIDGE_UTIL_TEST_MAX_MEMBERS ||
            add_interface(state, name) != 0)
            return -1;
        strcpy(bridge->members[bridge->count++], name);
    }
    return 0;
}

/* PUBLIC_INTERFACE */
/** Apply the reference-only operation/type policy; return 0 or atomic failure -1. */
WEAK int updateBridgeInfo(bridgeDetails *bridgeInfo, char *ifNameToBeUpdated,
                          int Opr, int type)
{
    selection_t selected = {0};
    if (!valid_details(bridgeInfo) ||
        Opr < BRIDGE_UTIL_TEST_CREATE || Opr > BRIDGE_UTIL_TEST_DETACH ||
        select_members(bridgeInfo, ifNameToBeUpdated, type, &selected) != 0)
        return -1;

    /* Commit only after every name, membership and capacity check succeeds. */
    model_state_t next = model;
    int index = bridge_index(&next, bridgeInfo->bridgeName);
    if (Opr == BRIDGE_UTIL_TEST_DELETE) {
        if (index >= 0)
            memset(&next.bridges[index], 0, sizeof(next.bridges[index]));
    } else {
        if (index < 0) {
            if (Opr != BRIDGE_UTIL_TEST_CREATE ||
                interface_index(&next, bridgeInfo->bridgeName) >= 0)
                return -1;
            for (size_t i = 0; i < BRIDGE_UTIL_TEST_MAX_BRIDGES; ++i) {
                if (!next.bridges[i].used) {
                    index = (int)i;
                    next.bridges[i].used = true;
                    strcpy(next.bridges[i].name, bridgeInfo->bridgeName);
                    break;
                }
            }
            if (index < 0)
                return -1;
        }
        if (Opr == BRIDGE_UTIL_TEST_DETACH) {
            model_bridge_t *bridge = &next.bridges[index];
            for (size_t i = 0; i < selected.count; ++i) {
                const int member = member_index(bridge, selected.names[i]);
                if (member >= 0) {
                    const size_t tail = bridge->count - (size_t)member - 1U;
                    if (tail != 0U)
                        memmove(bridge->members[member], bridge->members[member + 1],
                                tail * sizeof(bridge->members[0]));
                    --bridge->count;
                    memset(bridge->members[bridge->count], 0,
                           sizeof(bridge->members[0]));
                }
            }
        } else if (attach_members(&next, index, &selected) != 0) {
            return -1;
        }
    }
    model = next;
    return 0;
}

/* PUBLIC_INTERFACE */
/** Return INTERFACE_EXIST only for a modeled bridge or persistent interface. */
WEAK int checkIfExists(char *iface_name)
{
    return valid_name(iface_name) &&
           (bridge_index(&model, iface_name) >= 0 ||
            interface_index(&model, iface_name) >= 0) ?
           INTERFACE_EXIST : INTERFACE_NOT_EXIST;
}

/* PUBLIC_INTERFACE */
/**
 * Remove all exact whitespace-delimited tokens equal to sub, in place.
 * NULL/empty/invalid sub or NULL str is a no-op. Absent sub preserves bytes.
 * After removal survivors keep order and are separated by one space.
 * str must be writable and NUL-terminated; no allocation/ownership transfer.
 */
WEAK void removeIfaceFromList(char *str, const char *sub)
{
    char name[IFACE_NAME_SIZE];
    if (str == NULL || !valid_name(sub))
        return;
    /* Copy first so sub may alias a token in str. */
    strcpy(name, sub);
    const size_t length = strlen(name);
    const char *read = str;
    bool found = false;
    while (*read != '\0') {
        while (is_space(*read))
            ++read;
        const char *start = read;
        while (*read != '\0' && !is_space(*read))
            ++read;
        if ((size_t)(read - start) == length && memcmp(start, name, length) == 0)
            found = true;
    }
    if (!found)
        return;
    read = str;
    char *write = str;
    while (*read != '\0') {
        while (is_space(*read))
            ++read;
        const char *start = read;
        while (*read != '\0' && !is_space(*read))
            ++read;
        const size_t size = (size_t)(read - start);
        if (size == 0U || (size == length && memcmp(start, name, length) == 0))
            continue;
        if (write != str)
            *write++ = ' ';
        memmove(write, start, size);
        write += size;
    }
    *write = '\0';
}

/* PUBLIC_INTERFACE */
/** Return 0 only for an exact modeled membership; invalid/absent names return -1. */
WEAK int checkIfExistsInBridge(char *iface_name, char *bridge_name)
{
    if (!valid_name(iface_name) || !valid_name(bridge_name))
        return -1;
    const int index = bridge_index(&model, bridge_name);
    return index >= 0 && member_index(&model.bridges[index], iface_name) >= 0 ?
           0 : -1;
}

/* PUBLIC_INTERFACE */
/** Validate bounded bridge details and a compiled enum Config value; no mutation. */
WEAK int HandlePreConfigVendor(bridgeDetails *bridgeInfo, int InstanceNumber)
{
    return valid_details(bridgeInfo) && valid_config(InstanceNumber) ? 0 : -1;
}

/* PUBLIC_INTERFACE */
/** Validate bounded bridge details and a compiled enum Config value; no mutation. */
WEAK int HandlePostConfigVendor(bridgeDetails *bridgeInfo, int Config)
{
    return valid_details(bridgeInfo) && valid_config(Config) ? 0 : -1;
}

/* PUBLIC_INTERFACE */
/** Return NULL or borrowed model-owned list storage; never free/modify the result. */
WEAK char *getVendorIfaces(void)
{
    return vendor_ifaces[0] == '\0' ? NULL : vendor_ifaces;
}

/* PUBLIC_INTERFACE */
/** Reset all model state/globals; do not close a caller-owned logFp. */
void bridge_util_test_reset(void)
{
    memset(&model, 0, sizeof(model));
    memset(vendor_ifaces, 0, sizeof(vendor_ifaces));
    DeviceMode = 0;
    MocaIsolation_Val = 0;
    need_wifi_gw_refresh = 0;
    need_switch_gw_refresh = 0;
    syncMembers = 0;
    BridgeOprInPropgress = 0;
    logFp = NULL;
    memset(log_buff, 0, sizeof(log_buff));
    memset(log_msg_wtime, 0, sizeof(log_msg_wtime));
    memset(primaryBridgeName, 0, sizeof(primaryBridgeName));
    PORT2ENABLE = 0;
    ethWanEnabled = 0;
    memset(ethWanIfaceName, 0, sizeof(ethWanIfaceName));
    timeinfo = NULL;
    utc_time = 0;
}

/* PUBLIC_INTERFACE */
/** Add an unattached persistent interface; invalid/colliding/full requests fail. */
int bridge_util_test_seed_interface(const char *name)
{
    if (!valid_name(name))
        return -1;
    return add_interface(&model, name);
}

/* PUBLIC_INTERFACE */
/** Seed all configured members using a private copy, never modifying the input. */
int bridge_util_test_seed_bridge(const bridgeDetails *details)
{
    if (details == NULL)
        return -1;
    bridgeDetails copy = *details;
    return updateBridgeInfo(&copy, NULL, BRIDGE_UTIL_TEST_CREATE,
                            IF_BRIDGE_BRIDGEUTIL);
}

/* PUBLIC_INTERFACE */
/** Replace borrowed vendor-list storage after validating its length and tokens. */
int bridge_util_test_set_vendor_ifaces(const char *names)
{
    char next[TOTAL_IFLIST_SIZE] = {0};
    if (names != NULL) {
        size_t length = 0U;
        while (length < sizeof(next) && names[length] != '\0')
            ++length;
        if (length == sizeof(next))
            return -1;
        /* Validate tokens without imposing the per-bridge member limit. */
        const char *cursor = names;
        while (*cursor != '\0') {
            char name[IFACE_NAME_SIZE];
            size_t size = 0U;
            while (is_space(*cursor))
                ++cursor;
            while (*cursor != '\0' && !is_space(*cursor)) {
                if (size == sizeof(name) - 1U)
                    return -1;
                name[size++] = *cursor++;
            }
            name[size] = '\0';
            if (size != 0U && !valid_name(name))
                return -1;
        }
        memcpy(next, names, length + 1U);
    }
    memcpy(vendor_ifaces, next, sizeof(vendor_ifaces));
    return 0;
}
