/* SPDX-License-Identifier: Apache-2.0 */
#ifndef BRIDGE_UTIL_TEST_BACKEND_H
#define BRIDGE_UTIL_TEST_BACKEND_H

#include "bridge_util_hal.h"

/**
 * Linux reference-model policy, NOT a definition of the vendor's OVS_CMD ABI.
 * The public header names OVS_CMD but does not supply its definition.
 *
 * CREATE ensures a bridge exists and attaches the selected configured members.
 * DELETE removes the bridge and all memberships (idempotent if absent).
 * ATTACH/DETACH require an existing bridge and add/remove selected members.
 * All operations accept INTERFACE_TYPE, never network_interface.h's IF_TYPE.
 * IF_BRIDGE selects vlan_name and all four interface lists; IF_VLAN selects
 * vlan_name; GRE/MOCA/WIFI/ETH select their corresponding lists. IF_OTHER
 * selects ifNameToBeUpdated (sync deletion uses DETACH + IF_OTHER).
 * For other types that argument is optional/ignored (NULL or empty is valid).
 *
 * Names are 1..63 ASCII letters/digits/_.:-; lists are whitespace-separated.
 * Every bridgeDetails character array must terminate within its declared size.
 * Empty optional fields/lists are valid. vlanID is opaque to this model.
 * Failed requests, including resource exhaustion, do not change any state.
 * Duplicate creates/attachments and absent-member detaches succeed.
 * A member has at most one bridge; bridges cannot themselves be members.
 * Interfaces persist after detach/bridge deletion until reset. Queries never
 * consult the host OS. Hooks validate only, and do not mutate state or inputs.
 *
 * All helpers and storage are process-local, single-threaded test facilities.
 * They are linked only in skeleton mode, outside the public vendor HAL ABI.
 */
enum bridge_util_test_operation {
    BRIDGE_UTIL_TEST_CREATE = 1,
    BRIDGE_UTIL_TEST_DELETE = 2,
    BRIDGE_UTIL_TEST_ATTACH = 3,
    BRIDGE_UTIL_TEST_DETACH = 4
};

#define BRIDGE_UTIL_TEST_MAX_BRIDGES 16
#define BRIDGE_UTIL_TEST_MAX_INTERFACES 128
#define BRIDGE_UTIL_TEST_MAX_MEMBERS 64

/* PUBLIC_INTERFACE */
/**
 * Clear model state, vendor list and all 15 public globals.
 * logFp is borrowed: reset forgets it but never closes the caller's FILE.
 */
void bridge_util_test_reset(void);

/* PUBLIC_INTERFACE */
/** Seed an unattached interface; return 0, or -1 without mutation on error. */
int bridge_util_test_seed_interface(const char *name);

/* PUBLIC_INTERFACE */
/** Ensure a bridge with all configured members; return 0 or atomic failure -1. */
int bridge_util_test_seed_bridge(const bridgeDetails *details);

/* PUBLIC_INTERFACE */
/**
 * Copy a whitespace-separated vendor list (NULL/empty clears it).
 * Return 0 or -1 without mutation for invalid/over-capacity input.
 * getVendorIfaces returns NULL for an empty list, otherwise borrowed storage
 * valid until this setter/reset. Callers must not modify or free that storage.
 */
int bridge_util_test_set_vendor_ifaces(const char *names);

#endif
