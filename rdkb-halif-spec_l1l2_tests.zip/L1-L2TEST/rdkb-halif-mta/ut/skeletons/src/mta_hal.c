/* Copyright 2023 RDK Management. Apache-2.0.
 * Serialized Linux reference ONLY, not hardware/vendor conformance evidence.
 * MTA-GAP-01: ready count=8, uninitialized/fault count=0 (not a status code).
 * MTA-GAP-02: lists/nested data are borrowed COPY snapshots, never caller-freed;
 * valid until next same-list getter/reset. Empty lists => count=0,pointer=NULL.
 * MTA-GAP-03: PIN API buffers=128; accept 1..63 digits fitting 64-byte struct.
 * MTA-GAP-04: battery len=capacity IN/required including NUL OUT; short buffers
 * untouched except len. Absent telemetry ERR except Installed=false, AC/Missing.
 * Power-saving=1 enabled (2 disabled), never Boolean zero; model capacity units.
 * MTA-GAP-05: one replaceable callback; NULL cancels in this model ONLY. Explicit
 * synchronous dispatch of transient copy, last update wins; callback return
 * propagated by private dispatch and cannot change polling through its array.
 * MTA-GAP-06: table index 0..7, instance 101..108, line number 1..8.
 * MTA-GAP-07: InitDB idempotent; start=START, controlled completion=COMPLETE
 * (disabled IP=INIT). Public reset defaults/counters+1/+8, retains battery and
 * callback; private reset clears counters/callback. No vendor reset guarantee.
 * MTA-GAP-08: serialized/no timing; errors preserve outputs/state except short
 * buffer len; counters saturate. Option122 copied as binary octets, not strings.
 * IPv4 Dot uses network order; Value remains native union representation.
 */
#include "mta_test_control.h"
#include <limits.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    bool ready, fault, battery, pending;
    BOOLEAN dect, registration, dsx_enable, log_enable;
    char pin[64];
    ULONG resets, line_resets, nhandsets, ndsx, nlogs;
    MTAMGMT_MTA_STATUS ipv4, ipv6, config, operational, status[MTA_LINENUMBER];
    MTAMGMT_MTA_PROVISION_STATUS provision;
    MTAMGMT_PROVISIONING_PARAMS parameters;
    MTAMGMT_MTA_LINETABLE_INFO lines[MTA_LINENUMBER];
    MTAMGMT_MTA_CALLS calls[MTA_LINENUMBER];
    MTAMGMT_MTA_HANDSETS_INFO handsets[DECT_MAX_HANDSETS];
    MTAMGMT_MTA_DSXLOG dsx;
    MTAMGMT_MTA_MTALOG_FULL log;
    mta_hal_getLineRegisterStatus_callback callback;
} model_t;
static model_t m;
static MTAMGMT_MTA_CALLS calls_copy[MTA_LINENUMBER], nested_call;
static MTAMGMT_MTA_HANDSETS_INFO handsets_copy[DECT_MAX_HANDSETS];
static MTAMGMT_MTA_SERVICE_FLOW flow_copy;
static MTAMGMT_MTA_DSXLOG dsx_copy;
static MTAMGMT_MTA_MTALOG_FULL log_copy;
static char description_copy[128];

static bool ready(void)
{
    if (m.fault) { m.fault = false; return false; }
    return m.ready;
}
static bool valid_bool(BOOLEAN v) { return v == TRUE || v == FALSE; }
static int instance_index(ULONG id)
{
    return id >= 101 && id < 101 + MTA_LINENUMBER ? (int)(id - 101) : -1;
}
static ULONG add(ULONG v, ULONG n) { return v > ULONG_MAX - n ? ULONG_MAX : v + n; }
static void clear_stats(MTAMGMT_MTA_CALLS *c)
{
    memset(c, 0, sizeof(*c));
    strcpy(c->Codec, "G.711");
    strcpy(c->RemoteCodec, "G.711");
    strcpy(c->TxPackets, "0");
    strcpy(c->RxPackets, "0");
    strcpy(c->TxOctets, "0");
    strcpy(c->RxOctets, "0");
    strcpy(c->PacketLoss, "0");
}
/* PUBLIC_INTERFACE */
/** Clear fixture/counters; public InitDB is required afterward. */
void mta_test_reset(bool present)
{
    memset(&m, 0, sizeof(m));
    m.battery = present;
    m.provision = MTA_NON_PROVISIONED;
    m.dect = m.dsx_enable = m.log_enable = TRUE;
    strcpy(m.pin, "1234");
    for (ULONG i = 0; i < MTA_LINENUMBER; ++i) {
        m.lines[i].InstanceNumber = 101 + i;
        m.lines[i].LineNumber = 1 + i;
        m.lines[i].Status = m.lines[i].OverCurrentFault = 1;
        strcpy(m.lines[i].HazardousPotential, "Not Started");
        strcpy(m.lines[i].ForeignEMF, "Not Started");
        strcpy(m.lines[i].ResistiveFaults, "Not Started");
        strcpy(m.lines[i].ReceiverOffHook, "Not Started");
        strcpy(m.lines[i].RingerEquivalency, "1");
        strcpy(m.lines[i].CAName, "reference");
    }
    memset(calls_copy, 0, sizeof(calls_copy));
    memset(handsets_copy, 0, sizeof(handsets_copy));
    memset(&nested_call, 0, sizeof(nested_call));
    memset(&flow_copy, 0, sizeof(flow_copy));
    memset(&dsx_copy, 0, sizeof(dsx_copy));
    memset(&log_copy, 0, sizeof(log_copy));
    memset(description_copy, 0, sizeof(description_copy));
}
/* PUBLIC_INTERFACE */
/** Seed distinct per-line statistics. */
void mta_test_seed_calls(void)
{
    for (ULONG i = 0; i < MTA_LINENUMBER; ++i) {
        clear_stats(&m.calls[i]);
        m.calls[i].CallDuration = i + 10;
        snprintf(m.calls[i].TxPackets, sizeof(m.calls[i].TxPackets), "%lu", i + 100);
        snprintf(m.calls[i].RxPackets, sizeof(m.calls[i].RxPackets), "%lu", i + 200);
        m.lines[i].CallsNumber = 1;
    }
}
/* PUBLIC_INTERFACE */
/** Seed bounded stable handset IDs. */
int mta_test_seed_handsets(ULONG count)
{
    if (count > DECT_MAX_HANDSETS) return RETURN_ERR;
    memset(m.handsets, 0, sizeof(m.handsets));
    m.nhandsets = count;
    for (ULONG i = 0; i < count; ++i) {
        m.handsets[i].InstanceNumber = 201 + i;
        m.handsets[i].Status = TRUE;
        strcpy(m.handsets[i].HandsetName, "reference");
        strcpy(m.handsets[i].HandsetFirmware, "1");
        strcpy(m.handsets[i].OperatingTN, "TN1");
        strcpy(m.handsets[i].SupportedTN, "TN1");
    }
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Seed one enabled log of each kind. */
void mta_test_seed_logs(void)
{
    if (m.dsx_enable) {
        memset(&m.dsx, 0, sizeof(m.dsx));
        m.dsx.ID = m.dsx.Level = 1;
        strcpy(m.dsx.Time, "2000-01-01");
        strcpy(m.dsx.Description, "reference DSX event");
        m.ndsx = 1;
    }
    if (m.log_enable) {
        memset(&m.log, 0, sizeof(m.log));
        m.log.Index = m.log.EventID = 1;
        strcpy(m.log.EventLevel, "1");
        strcpy(m.log.Time, "2000-01-01");
        m.nlogs = 1;
    }
}
/* PUBLIC_INTERFACE */
/** Change battery installation only. */
void mta_test_seed_battery(bool present) { m.battery = present; }
/* PUBLIC_INTERFACE */
/** Copy retained provisioning input into caller storage. */
int mta_test_get_provisioning(PMTAMGMT_MTA_PROVISIONING_PARAMS p)
{
    if (!m.ready || p == NULL) return RETURN_ERR;
    *p = m.parameters;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Fail next HAL operation before mutation. */
void mta_test_fail_next(void) { m.fault = true; }
/* PUBLIC_INTERFACE */
/** Initialize once; repeated calls preserve state. */
INT mta_hal_InitDB(void)
{
    if (m.fault) { m.fault = false; return RETURN_ERR; }
    if (!m.ready) {
        bool battery = m.battery;
        mta_test_reset(battery);
        m.ready = true;
    }
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy DHCPv4 data; inactive IPv4 is zero. */
INT mta_hal_GetDHCPInfo(PMTAMGMT_MTA_DHCP_INFO p)
{
    if (!ready() || p == NULL) return RETURN_ERR;
    memset(p, 0, sizeof(*p));
    strcpy(p->FQDN, "mta.reference.invalid");
    strcpy(p->BootFileName, "mta.cfg");
    if (m.ipv4 == MTA_COMPLETE) {
        const UCHAR ip[4] = {192, 0, 2, 10}, gw[4] = {192, 0, 2, 1};
        memcpy(p->IPAddress.Dot, ip, 4);
        memcpy(p->Gateway.Dot, gw, 4);
        memset(p->SubnetMask.Dot, 255, 3);
        memcpy(p->PrimaryDNS.Dot, gw, 4);
        memcpy(p->PrimaryDHCPServer.Dot, gw, 4);
        p->LeaseTimeRemaining = 3600;
    }
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Copy bounded DHCPv6 fields. */
INT mta_hal_GetDHCPV6Info(PMTAMGMT_MTA_DHCPv6_INFO p)
{
    if (!ready() || p == NULL) return RETURN_ERR;
    memset(p, 0, sizeof(*p));
    strcpy(p->IPV6Address, m.ipv6 == MTA_COMPLETE ? "2001:db8::10" : "::");
    strcpy(p->FQDN, "mta.reference.invalid");
    strcpy(p->BootFileName, "mta.cfg");
    strcpy(p->Prefix, "2001:db8::");
    strcpy(p->Gateway, "2001:db8::1");
    strcpy(p->PrimaryDNS, "2001:db8::1");
    if (m.ipv6 == MTA_COMPLETE) p->LeaseTimeRemaining = 3600;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy binary input and enter START, without implicit completion. */
INT mta_hal_start_provisioning(PMTAMGMT_MTA_PROVISIONING_PARAMS p)
{
    if (!ready() || p == NULL || p->MtaIPMode < MTA_IPV4 ||
        p->MtaIPMode > MTA_DUAL_STACK || p->DhcpOption2171CccV6DssID1Len < 0 ||
        p->DhcpOption2171CccV6DssID1Len > MTA_DHCPOPTION122CCCV6DSSID1_MAX ||
        p->DhcpOption2171CccV6DssID2Len < 0 ||
        p->DhcpOption2171CccV6DssID2Len > MTA_DHCPOPTION122CCCV6DSSID2_MAX)
        return RETURN_ERR;
    m.parameters = *p;
    m.ipv4 = p->MtaIPMode == MTA_IPV6 ? MTA_INIT : MTA_START;
    m.ipv6 = p->MtaIPMode == MTA_IPV4 ? MTA_INIT : MTA_START;
    m.config = m.operational = MTA_START;
    m.provision = MTA_NON_PROVISIONED;
    for (int i = 0; i < MTA_LINENUMBER; ++i) m.status[i] = MTA_START;
    m.pending = true;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Complete one started request, leaving disabled IP families in INIT. */
int mta_test_complete_provisioning(void)
{
    if (!m.ready || m.operational != MTA_START) return RETURN_ERR;
    m.ipv4 = m.parameters.MtaIPMode == MTA_IPV6 ? MTA_INIT : MTA_COMPLETE;
    m.ipv6 = m.parameters.MtaIPMode == MTA_IPV4 ? MTA_INIT : MTA_COMPLETE;
    m.config = m.operational = MTA_COMPLETE;
    m.provision = MTA_PROVISIONED;
    for (int i = 0; i < MTA_LINENUMBER; ++i) m.status[i] = MTA_COMPLETE;
    m.pending = true;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Validate both outputs before copying initialized DHCP statuses. */
INT mta_hal_getDhcpStatus(MTAMGMT_MTA_STATUS *a, MTAMGMT_MTA_STATUS *b)
{
    if (!ready() || a == NULL || b == NULL) return RETURN_ERR;
    *a = m.ipv4;
    *b = m.ipv6;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Copy every line status only into sufficient caller storage. */
INT mta_hal_getLineRegisterStatus(MTAMGMT_MTA_STATUS *p, int n)
{
    if (!ready() || p == NULL || n < MTA_LINENUMBER) return RETURN_ERR;
    memcpy(p, m.status, sizeof(m.status));
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Retain/replace callback; NULL cancellation is model-only. */
void mta_hal_LineRegisterStatus_callback_register(mta_hal_getLineRegisterStatus_callback cb)
{
    if (!ready()) return;
    m.callback = cb;
    if (cb == NULL) m.pending = false;
}
/* PUBLIC_INTERFACE */
/** Deliver transient copy, returning callback result without altering polling. */
int mta_test_dispatch_callback(void)
{
    MTAMGMT_MTA_STATUS copy[MTA_LINENUMBER];
    mta_hal_getLineRegisterStatus_callback cb = m.callback;
    if (!m.ready || !m.pending || cb == NULL) return RETURN_ERR;
    memcpy(copy, m.status, sizeof(copy));
    m.pending = false;
    return cb(copy, MTA_LINENUMBER);
}
/* PUBLIC_INTERFACE */
/** Restore defaults, retain battery/callback, increment saturating counters. */
INT mta_hal_devResetNow(BOOLEAN v)
{
    if (!ready() || !valid_bool(v)) return RETURN_ERR;
    if (v) {
        ULONG resets = add(m.resets, 1), lines = add(m.line_resets, MTA_LINENUMBER);
        bool battery = m.battery;
        mta_hal_getLineRegisterStatus_callback cb = m.callback;
        mta_test_reset(battery);
        m.ready = true;
        m.resets = resets;
        m.line_resets = lines;
        m.callback = cb;
        m.pending = true;
    }
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Generate readiness/pointer-checked scalar getters. */
#define GET_SCALAR(name, type, field) \
    INT name(type *v) { \
        if (!ready() || v == NULL) return RETURN_ERR; \
        *v = m.field; return RETURN_OK; \
    }
GET_SCALAR(mta_hal_DectGetEnable, BOOLEAN, dect)
GET_SCALAR(mta_hal_DectGetRegistrationMode, BOOLEAN, registration)
GET_SCALAR(mta_hal_GetDSXLogEnable, BOOLEAN, dsx_enable)
GET_SCALAR(mta_hal_GetCallSignallingLogEnable, BOOLEAN, log_enable)
GET_SCALAR(mta_hal_Get_MTAResetCount, ULONG, resets)
GET_SCALAR(mta_hal_Get_LineResetCount, ULONG, line_resets)
GET_SCALAR(mta_hal_getConfigFileStatus, MTAMGMT_MTA_STATUS, config)
GET_SCALAR(mta_hal_getMtaOperationalStatus, MTAMGMT_MTA_STATUS, operational)
GET_SCALAR(mta_hal_getMtaProvisioningStatus, MTAMGMT_MTA_PROVISION_STATUS, provision)

/* PUBLIC_INTERFACE */
/** Return count rather than a generic success code. */
ULONG mta_hal_LineTableGetNumberOfEntries(void) { return ready() ? MTA_LINENUMBER : 0; }
/* PUBLIC_INTERFACE */
/** Copy one indexed entry and its optional nested call. */
INT mta_hal_LineTableGetEntry(ULONG i, PMTAMGMT_MTA_LINETABLE_INFO p)
{
    if (!ready() || p == NULL || i >= MTA_LINENUMBER) return RETURN_ERR;
    *p = m.lines[i];
    p->pCalls = NULL;
    if (p->CallsNumber) {
        nested_call = m.calls[i];
        p->pCalls = &nested_call;
    }
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Complete diagnostics for exactly one table index. */
INT mta_hal_TriggerDiagnostics(ULONG i)
{
    if (!ready() || i >= MTA_LINENUMBER) return RETURN_ERR;
    strcpy(m.lines[i].HazardousPotential, "Passed");
    strcpy(m.lines[i].ForeignEMF, "Passed");
    strcpy(m.lines[i].ResistiveFaults, "Passed");
    strcpy(m.lines[i].ReceiverOffHook, "Passed");
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy calls selected by line instance identifier. */
INT mta_hal_GetCalls(ULONG id, ULONG *n, PMTAMGMT_MTA_CALLS *p)
{
    int i = instance_index(id);
    if (!ready() || i < 0 || n == NULL || p == NULL) return RETURN_ERR;
    *n = m.lines[i].CallsNumber;
    calls_copy[i] = m.calls[i];
    *p = *n ? &calls_copy[i] : NULL;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Clear per-instance statistics without clearing call identity/count. */
INT mta_hal_ClearCalls(ULONG id)
{
    int i = instance_index(id);
    if (!ready() || i < 0) return RETURN_ERR;
    clear_stats(&m.calls[i]);
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Copy call-processing status selected by one-based line number. */
INT mta_hal_GetCALLP(ULONG number, PMTAMGMT_MTA_CALLP p)
{
    if (!ready() || number == 0 || number > MTA_LINENUMBER || p == NULL)
        return RETURN_ERR;
    memset(p, 0, sizeof(*p));
    strcpy(p->LCState, m.lines[number - 1].Status == 1 ? "Idle" : "In Use");
    strcpy(p->CallPState, m.operational == MTA_COMPLETE ?
           "In Service" : "OOS (Out of Service)");
    strcpy(p->LoopCurrent, "Normal");
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Return a borrowed flow copy after completion, otherwise 0/NULL. */
INT mta_hal_GetServiceFlow(ULONG *n, PMTAMGMT_MTA_SERVICE_FLOW *p)
{
    if (!ready() || n == NULL || p == NULL) return RETURN_ERR;
    *n = m.operational == MTA_COMPLETE ? 1 : 0;
    *p = NULL;
    if (*n) {
        memset(&flow_copy, 0, sizeof(flow_copy));
        flow_copy.SFID = 1;
        flow_copy.DefaultFlow = TRUE;
        strcpy(flow_copy.ServiceClassName, "reference");
        strcpy(flow_copy.Direction, "Upstream");
        strcpy(flow_copy.TrafficType, "RTP");
        *p = &flow_copy;
    }
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Disable registration when DECT is disabled. */
INT mta_hal_DectSetEnable(BOOLEAN v)
{
    if (!ready() || !valid_bool(v)) return RETURN_ERR;
    m.dect = v;
    if (!v) m.registration = FALSE;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Enter registration mode only while DECT is enabled. */
INT mta_hal_DectSetRegistrationMode(BOOLEAN v)
{
    if (!ready() || !valid_bool(v) || (v && !m.dect)) return RETURN_ERR;
    m.registration = v;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Copy bounded DECT information without logging PINs. */
INT mta_hal_GetDect(PMTAMGMT_MTA_DECT p)
{
    if (!ready() || p == NULL) return RETURN_ERR;
    memset(p, 0, sizeof(*p));
    strcpy(p->HardwareVersion, "reference");
    strcpy(p->SoftwareVersion, "1");
    strcpy(p->RFPI, "reference");
    memcpy(p->PIN, m.pin, sizeof(p->PIN));
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Copy into the caller's documented 128-byte API buffer. */
INT mta_hal_GetDectPIN(char *p)
{
    if (!ready() || p == NULL) return RETURN_ERR;
    strcpy(p, m.pin);
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Accept 1..63 digits fitting both API and struct, never log secrets. */
INT mta_hal_SetDectPIN(char *p)
{
    size_t n;
    if (!ready() || p == NULL) return RETURN_ERR;
    n = strnlen(p, 128);
    if (n == 0 || n >= sizeof(m.pin)) return RETURN_ERR;
    for (size_t i = 0; i < n; ++i)
        if (p[i] < '0' || p[i] > '9') return RETURN_ERR;
    memset(m.pin, 0, sizeof(m.pin));
    memcpy(m.pin, p, n);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Remove one handset by its stable identifier. */
INT mta_hal_DectDeregisterDectHandset(ULONG id)
{
    if (!ready()) return RETURN_ERR;
    for (ULONG i = 0; i < m.nhandsets; ++i) {
        if (m.handsets[i].InstanceNumber == id) {
            memmove(&m.handsets[i], &m.handsets[i + 1],
                    (m.nhandsets - i - 1) * sizeof(m.handsets[0]));
            --m.nhandsets;
            return RETURN_OK;
        }
    }
    return RETURN_ERR;
}
/* PUBLIC_INTERFACE */
/** Return a borrowed handset snapshot or 0/NULL. */
INT mta_hal_GetHandsets(ULONG *n, PMTAMGMT_MTA_HANDSETS_INFO *p)
{
    if (!ready() || n == NULL || p == NULL) return RETURN_ERR;
    *n = m.nhandsets;
    memcpy(handsets_copy, m.handsets, sizeof(handsets_copy));
    *p = *n ? handsets_copy : NULL;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Return a borrowed DSX snapshot. */
INT mta_hal_GetDSXLogs(ULONG *n, PMTAMGMT_MTA_DSXLOG *p)
{
    if (!ready() || n == NULL || p == NULL) return RETURN_ERR;
    *n = m.ndsx;
    dsx_copy = m.dsx;
    *p = *n ? &dsx_copy : NULL;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Return a borrowed MTA snapshot with copied nested description. */
INT mta_hal_GetMtaLog(ULONG *n, PMTAMGMT_MTA_MTALOG_FULL *p)
{
    if (!ready() || n == NULL || p == NULL) return RETURN_ERR;
    *n = m.nlogs;
    log_copy = m.log;
    strcpy(description_copy, "reference MTA event");
    log_copy.pDescription = description_copy;
    *p = *n ? &log_copy : NULL;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Generate strict Boolean log setters retaining existing records. */
#define SET_FLAG(name, field) \
    INT name(BOOLEAN v) { \
        if (!ready() || !valid_bool(v)) return RETURN_ERR; \
        m.field = v; return RETURN_OK; \
    }
SET_FLAG(mta_hal_SetDSXLogEnable, dsx_enable)
SET_FLAG(mta_hal_SetCallSignallingLogEnable, log_enable)
/* PUBLIC_INTERFACE */
/** Generate strict Boolean clear operations; FALSE preserves records. */
#define CLEAR_LOG(name, field) \
    INT name(BOOLEAN v) { \
        if (!ready() || !valid_bool(v)) return RETURN_ERR; \
        if (v) { m.field = 0; } \
        return RETURN_OK; \
    }
CLEAR_LOG(mta_hal_ClearDSXLog, ndsx)
CLEAR_LOG(mta_hal_ClearCallSignallingLog, nlogs)

static int battery_number(ULONG *v, ULONG number)
{
    if (!ready() || v == NULL || !m.battery) return RETURN_ERR;
    *v = number;
    return RETURN_OK;
}
static int battery_string(CHAR *v, ULONG *n, const char *text, bool available)
{
    size_t required = strlen(text) + 1;
    if (!ready() || v == NULL || n == NULL || !available) return RETURN_ERR;
    if (*n < required) { *n = (ULONG)required; return RETURN_ERR; }
    memcpy(v, text, required);
    *n = (ULONG)required;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Return installation regardless of battery telemetry availability. */
INT mta_hal_BatteryGetInstalled(BOOLEAN *v)
{
    if (!ready() || v == NULL) return RETURN_ERR;
    *v = m.battery ? TRUE : FALSE;
    return RETURN_OK;
}
/* PUBLIC_INTERFACE */
/** Return model total capacity. */
INT mta_hal_BatteryGetTotalCapacity(ULONG *v) { return battery_number(v, 1000); }
/* PUBLIC_INTERFACE */
/** Return model actual capacity. */
INT mta_hal_BatteryGetActualCapacity(ULONG *v) { return battery_number(v, 900); }
/* PUBLIC_INTERFACE */
/** Return model remaining charge. */
INT mta_hal_BatteryGetRemainingCharge(ULONG *v) { return battery_number(v, 600); }
/* PUBLIC_INTERFACE */
/** Return remaining minutes. */
INT mta_hal_BatteryGetRemainingTime(ULONG *v) { return battery_number(v, 120); }
/* PUBLIC_INTERFACE */
/** Return model cycle count. */
INT mta_hal_BatteryGetNumberofCycles(ULONG *v) { return battery_number(v, 10); }
/* PUBLIC_INTERFACE */
/** Return 1=enabled, not a Boolean zero. */
INT mta_hal_BatteryGetPowerSavingModeStatus(ULONG *v) { return battery_number(v, 1); }

/* PUBLIC_INTERFACE */
/** Copy power source with capacity-in/required-length-out semantics. */
INT mta_hal_BatteryGetPowerStatus(CHAR *v, ULONG *n)
{ return battery_string(v, n, "AC", true); }
/* PUBLIC_INTERFACE */
/** Copy condition only while installed. */
INT mta_hal_BatteryGetCondition(CHAR *v, ULONG *n)
{ return battery_string(v, n, "Good", m.battery); }
/* PUBLIC_INTERFACE */
/** Copy status, including Missing when absent. */
INT mta_hal_BatteryGetStatus(CHAR *v, ULONG *n)
{ return battery_string(v, n, m.battery ? "Charging" : "Missing", true); }
/* PUBLIC_INTERFACE */
/** Copy life status only while installed. */
INT mta_hal_BatteryGetLife(CHAR *v, ULONG *n)
{ return battery_string(v, n, "Good", m.battery); }
/* PUBLIC_INTERFACE */
/** Copy bounded hardware identifiers only for an installed battery. */
INT mta_hal_BatteryGetInfo(PMTAMGMT_MTA_BATTERY_INFO p)
{
    if (!ready() || p == NULL || !m.battery) return RETURN_ERR;
    memset(p, 0, sizeof(*p));
    strcpy(p->ModelNumber, "reference");
    strcpy(p->SerialNumber, "reference");
    strcpy(p->PartNumber, "reference");
    strcpy(p->ChargerFirmwareRevision, "1");
    return RETURN_OK;
}
