/* Copyright 2023 RDK Management. Apache-2.0. */
#ifndef MTA_TEST_CONTROL_H
#define MTA_TEST_CONTROL_H
#ifndef BUILD_LINUX
#error "MTA test controls are Linux-reference-only"
#endif
#include <stdbool.h>
#include "mta_hal.h"
/* PUBLIC_INTERFACE */
/** Reset model/counters; InitDB is required afterward. */
void mta_test_reset(bool battery_present);
/* PUBLIC_INTERFACE */
/** Seed one isolated call per line with distinct statistics. */
void mta_test_seed_calls(void);
/* PUBLIC_INTERFACE */
/** Seed stable handset IDs; reject counts above DECT_MAX_HANDSETS. */
int mta_test_seed_handsets(ULONG count);
/* PUBLIC_INTERFACE */
/** Seed one DSX/MTA event only for enabled logs. */
void mta_test_seed_logs(void);
/* PUBLIC_INTERFACE */
/** Select installed/absent battery telemetry. */
void mta_test_seed_battery(bool present);
/* PUBLIC_INTERFACE */
/** Complete a started provisioning request. */
int mta_test_complete_provisioning(void);
/* PUBLIC_INTERFACE */
/** Copy retained binary provisioning parameters into caller storage. */
int mta_test_get_provisioning(PMTAMGMT_MTA_PROVISIONING_PARAMS parameters);
/* PUBLIC_INTERFACE */
/** Synchronously deliver one pending copied line snapshot. */
int mta_test_dispatch_callback(void);
/* PUBLIC_INTERFACE */
/** Fail the next HAL operation before output/state mutation. */
void mta_test_fail_next(void);
#endif
