/* Copyright 2023 RDK Management. Apache-2.0. */
#include "mta_test_helpers.h"
#include <libfyaml.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static bool battery_supported;

static int validate_profile(const char *path)
{
    struct fy_document *doc = fy_document_build_from_file(NULL, path);
    struct fy_node *node;
    const char *value, *tag;
    size_t length = 0, tag_length = 0;
    int result = -1;
    if (doc == NULL)
        return -1;
    node = fy_node_by_path(fy_document_root(doc), "/mta/batterySupported",
                           (size_t)-1, FYNWF_DONT_FOLLOW);
    if (node != NULL && fy_node_get_style(node) == FYNS_PLAIN) {
        value = fy_node_get_scalar(node, &length);
        tag = fy_node_get_tag(node, &tag_length);
        /* Quoted strings, !!str, null, numbers, collections and aliases fail. */
        if (tag != NULL &&
            !(tag_length == strlen("tag:yaml.org,2002:bool") &&
              memcmp(tag, "tag:yaml.org,2002:bool", tag_length) == 0))
            goto done;
        if (value != NULL && length == 4 && memcmp(value, "true", 4) == 0) {
            battery_supported = true;
            result = 0;
        } else if (value != NULL && length == 5 && memcmp(value, "false", 5) == 0) {
            battery_supported = false;
            result = 0;
        }
    }
done:
    fy_document_destroy(doc);
    return result;
}

/* PUBLIC_INTERFACE */
/** Require one readable, typed profile and reject unknown/malformed CLI options. */
int mta_validate_options(int argc, char **argv)
{
    int option, profiles = 0;
    const char *profile = NULL;
    opterr = 0;
    while ((option = getopt(argc, argv, "cabhf:l:tp:d:e:")) != -1) {
        switch (option) {
        case 'h':
            puts("Usage: mta_hal_test -b|-a|-c -p profile.yaml [-d group] [-e group]");
            exit(EXIT_SUCCESS);
        case 'p': profile = optarg; ++profiles; break;
        case 'd':
        case 'e': {
            char *end;
            long group = strtol(optarg, &end, 10);
            if (*optarg == '\0' || *end != '\0' ||
                group < UT_TESTS_L1 || group >= UT_TESTS_MAX)
                return -1;
            break;
        }
        case 'c': case 'a': case 'b': case 't': case 'l': case 'f': break;
        default: return -1;
        }
    }
    if (optind != argc || profiles != 1 || validate_profile(profile) != 0) {
        fprintf(stderr, "MTA requires one valid profile with explicit boolean mta.batterySupported\n");
        return -1;
    }
    optind = 1;
    return 0;
}

/* PUBLIC_INTERFACE */
/** Return battery capability only after mta_validate_options succeeds. */
bool mta_battery_supported(void)
{
    return battery_supported;
}

/* PUBLIC_INTERFACE */
/** Prepare an isolated Linux fixture, or initialize the actual vendor database. */
int init_mta_hal_init(void)
{
#ifdef BUILD_LINUX
    mta_test_reset(battery_supported);
#endif
    return mta_hal_InitDB();
}
