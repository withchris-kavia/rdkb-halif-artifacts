/* Copyright 2023 RDK Management. Apache-2.0.
 * L1 expectations derive from include/mta_hal.h. Model-only gap policies are
 * asserted under BUILD_LINUX; they are not extra vendor ABI requirements.
 * Each case initializes independently; borrowed lists are never freed.
 */
#include "mta_test_helpers.h"
#include <limits.h>
#include <string.h>

#define PREP() UT_ASSERT_EQUAL_FATAL(init_mta_hal_init(), RETURN_OK)
#define OK(call) UT_ASSERT_EQUAL_FATAL((call), RETURN_OK)
#define BAD(call) UT_ASSERT_EQUAL((call), RETURN_ERR)
#define NUL(field) UT_ASSERT_PTR_NOT_NULL(memchr((field), '\0', sizeof(field)))
#define SCALAR(fn, type, condition) \
    static void test_##fn(void) { \
        type value = 0; PREP(); OK(fn(&value)); \
        UT_ASSERT(condition); BAD(fn(NULL)); \
    }
#define FLAG(fn) SCALAR(fn, BOOLEAN, value == TRUE || value == FALSE)
#define STATUS(fn) SCALAR(fn, MTAMGMT_MTA_STATUS, value >= MTA_INIT && value <= MTA_REJECTED)
FLAG(mta_hal_DectGetEnable)
FLAG(mta_hal_DectGetRegistrationMode)
FLAG(mta_hal_GetDSXLogEnable)
FLAG(mta_hal_GetCallSignallingLogEnable)
FLAG(mta_hal_BatteryGetInstalled)
STATUS(mta_hal_getConfigFileStatus)
STATUS(mta_hal_getMtaOperationalStatus)
SCALAR(mta_hal_getMtaProvisioningStatus, MTAMGMT_MTA_PROVISION_STATUS,
       value == MTA_PROVISIONED || value == MTA_NON_PROVISIONED)
SCALAR(mta_hal_Get_MTAResetCount, ULONG, value <= ULONG_MAX)
SCALAR(mta_hal_Get_LineResetCount, ULONG, value <= ULONG_MAX)

static void test_mta_hal_InitDB(void) { PREP(); OK(mta_hal_InitDB()); }
static void test_mta_hal_GetDHCPInfo(void)
{
    MTAMGMT_MTA_DHCP_INFO p = {0};
    PREP(); OK(mta_hal_GetDHCPInfo(&p));
    NUL(p.FQDN); NUL(p.BootFileName); NUL(p.MACAddress);
    UT_ASSERT_EQUAL(sizeof(p.IPAddress.Dot), IPV4_ADDRESS_SIZE);
    BAD(mta_hal_GetDHCPInfo(NULL));
}
static void test_mta_hal_GetDHCPV6Info(void)
{
    MTAMGMT_MTA_DHCPv6_INFO p = {0};
    PREP(); OK(mta_hal_GetDHCPV6Info(&p));
    NUL(p.IPV6Address); NUL(p.Gateway); NUL(p.FQDN); NUL(p.BootFileName);
    BAD(mta_hal_GetDHCPV6Info(NULL));
}
static void test_mta_hal_LineTableGetNumberOfEntries(void)
{
    PREP();
    UT_ASSERT(mta_hal_LineTableGetNumberOfEntries() > 0);
}
static void test_mta_hal_LineTableGetEntry(void)
{
    MTAMGMT_MTA_LINETABLE_INFO p = {0};
    PREP(); OK(mta_hal_LineTableGetEntry(0, &p));
    NUL(p.CAName); NUL(p.HazardousPotential);
    UT_ASSERT(p.Status == 1 || p.Status == 2);
    BAD(mta_hal_LineTableGetEntry(0, NULL));
    BAD(mta_hal_LineTableGetEntry(ULONG_MAX, &p));
}

#define BOOL_OP(fn) \
    static void test_##fn(void) { \
        PREP(); OK(fn(FALSE)); OK(fn(TRUE)); \
        BAD(fn((BOOLEAN)2)); \
    }
BOOL_OP(mta_hal_DectSetEnable)
BOOL_OP(mta_hal_DectSetRegistrationMode)
BOOL_OP(mta_hal_SetDSXLogEnable)
BOOL_OP(mta_hal_SetCallSignallingLogEnable)
BOOL_OP(mta_hal_ClearDSXLog)
BOOL_OP(mta_hal_ClearCallSignallingLog)
BOOL_OP(mta_hal_devResetNow)

static void test_mta_hal_GetDect(void)
{
    MTAMGMT_MTA_DECT p = {0};
    PREP(); OK(mta_hal_GetDect(&p));
    NUL(p.HardwareVersion); NUL(p.SoftwareVersion); NUL(p.RFPI); NUL(p.PIN);
    BAD(mta_hal_GetDect(NULL));
}
static void test_mta_hal_GetDectPIN(void)
{
    char pin[128] = {0};
    PREP(); OK(mta_hal_GetDectPIN(pin)); NUL(pin);
    BAD(mta_hal_GetDectPIN(NULL));
}
static void test_mta_hal_SetDectPIN(void)
{
    char pin[128] = "1234";
    PREP(); OK(mta_hal_SetDectPIN(pin)); BAD(mta_hal_SetDectPIN(NULL));
}
static void test_mta_hal_DectDeregisterDectHandset(void)
{
    ULONG n = 0;
    PMTAMGMT_MTA_HANDSETS_INFO p = NULL;
    PREP();
#ifdef BUILD_LINUX
    OK(mta_test_seed_handsets(1));
#endif
    OK(mta_hal_GetHandsets(&n, &p));
    if (n) {
        UT_ASSERT_PTR_NOT_NULL_FATAL(p);
        OK(mta_hal_DectDeregisterDectHandset(p[0].InstanceNumber));
    }
    BAD(mta_hal_DectDeregisterDectHandset(ULONG_MAX));
}
static void test_mta_hal_TriggerDiagnostics(void)
{
    PREP(); OK(mta_hal_TriggerDiagnostics(0));
    BAD(mta_hal_TriggerDiagnostics(ULONG_MAX));
}

#define LIST_CASE(fn, type, limit, field) \
    static void test_##fn(void) { \
        ULONG n = 0; type *p = NULL; PREP(); \
        SEED_LISTS(); OK(fn(&n, &p)); UT_ASSERT(n <= (limit)); \
        if (n) { UT_ASSERT_PTR_NOT_NULL_FATAL(p); NUL(p[0].field); } \
        BAD(fn(NULL, &p)); BAD(fn(&n, NULL)); \
    }
#ifdef BUILD_LINUX
#define SEED_LISTS() do { mta_test_seed_logs(); \
    OK(mta_test_seed_handsets(DECT_MAX_HANDSETS)); } while (0)
#else
#define SEED_LISTS() ((void)0)
#endif
LIST_CASE(mta_hal_GetHandsets, MTAMGMT_MTA_HANDSETS_INFO, DECT_MAX_HANDSETS, HandsetName)
LIST_CASE(mta_hal_GetDSXLogs, MTAMGMT_MTA_DSXLOG, ULONG_MAX, Description)
LIST_CASE(mta_hal_GetMtaLog, MTAMGMT_MTA_MTALOG_FULL, ULONG_MAX, EventLevel)
LIST_CASE(mta_hal_GetServiceFlow, MTAMGMT_MTA_SERVICE_FLOW, ULONG_MAX, Direction)

static void test_mta_hal_GetCalls(void)
{
    MTAMGMT_MTA_LINETABLE_INFO line = {0};
    PMTAMGMT_MTA_CALLS calls = NULL;
    ULONG n = 0;
    PREP();
#ifdef BUILD_LINUX
    mta_test_seed_calls();
#endif
    OK(mta_hal_LineTableGetEntry(0, &line));
    OK(mta_hal_GetCalls(line.InstanceNumber, &n, &calls));
    if (n) { UT_ASSERT_PTR_NOT_NULL_FATAL(calls); NUL(calls[0].Codec); }
    BAD(mta_hal_GetCalls(line.InstanceNumber, NULL, &calls));
    BAD(mta_hal_GetCalls(line.InstanceNumber, &n, NULL));
    BAD(mta_hal_GetCalls(ULONG_MAX, &n, &calls));
}
static void test_mta_hal_ClearCalls(void)
{
    MTAMGMT_MTA_LINETABLE_INFO line = {0};
    PREP(); OK(mta_hal_LineTableGetEntry(0, &line));
    OK(mta_hal_ClearCalls(line.InstanceNumber));
    BAD(mta_hal_ClearCalls(ULONG_MAX));
}
static void test_mta_hal_GetCALLP(void)
{
    MTAMGMT_MTA_CALLP p = {0};
    MTAMGMT_MTA_LINETABLE_INFO line = {0};
    PREP(); OK(mta_hal_LineTableGetEntry(0, &line));
    OK(mta_hal_GetCALLP(line.LineNumber, &p));
    NUL(p.LCState); NUL(p.CallPState); NUL(p.LoopCurrent);
    BAD(mta_hal_GetCALLP(line.LineNumber, NULL));
    BAD(mta_hal_GetCALLP(ULONG_MAX, &p));
}
static int battery_expected(bool normally_available)
{
#ifdef BUILD_LINUX
    return normally_available || mta_battery_supported() ? RETURN_OK : RETURN_ERR;
#else
    (void)normally_available;
    return RETURN_OK;
#endif
}
#define BAT_NUMBER(fn, condition) \
    static void test_##fn(void) { \
        ULONG value = ULONG_MAX; int rc; PREP(); rc = fn(&value); \
        UT_ASSERT_EQUAL_FATAL(rc, battery_expected(false)); \
        if (rc == RETURN_OK) { UT_ASSERT(condition); } \
        BAD(fn(NULL)); \
    }
BAT_NUMBER(mta_hal_BatteryGetTotalCapacity, value <= ULONG_MAX)
BAT_NUMBER(mta_hal_BatteryGetActualCapacity, value <= ULONG_MAX)
BAT_NUMBER(mta_hal_BatteryGetRemainingCharge, value <= ULONG_MAX)
BAT_NUMBER(mta_hal_BatteryGetRemainingTime, value <= ULONG_MAX)
BAT_NUMBER(mta_hal_BatteryGetNumberofCycles, value <= ULONG_MAX)
BAT_NUMBER(mta_hal_BatteryGetPowerSavingModeStatus, value == 1 || value == 2)
#define BAT_STRING(fn, available) \
    static void test_##fn(void) { \
        CHAR value[128] = {0}; ULONG len = sizeof(value); int rc; \
        PREP(); rc = fn(value, &len); \
        UT_ASSERT_EQUAL_FATAL(rc, battery_expected(available)); \
        if (rc == RETURN_OK) { NUL(value); UT_ASSERT(len <= sizeof(value)); } \
        BAD(fn(NULL, &len)); BAD(fn(value, NULL)); \
    }
BAT_STRING(mta_hal_BatteryGetPowerStatus, true)
BAT_STRING(mta_hal_BatteryGetCondition, false)
BAT_STRING(mta_hal_BatteryGetStatus, true)
BAT_STRING(mta_hal_BatteryGetLife, false)
static void test_mta_hal_BatteryGetInfo(void)
{
    MTAMGMT_MTA_BATTERY_INFO p = {0};
    int rc;
    PREP(); rc = mta_hal_BatteryGetInfo(&p);
    UT_ASSERT_EQUAL_FATAL(rc, battery_expected(false));
    if (rc == RETURN_OK) {
        NUL(p.ModelNumber); NUL(p.SerialNumber);
        NUL(p.PartNumber); NUL(p.ChargerFirmwareRevision);
    }
    BAD(mta_hal_BatteryGetInfo(NULL));
}
static void test_mta_hal_getDhcpStatus(void)
{
    MTAMGMT_MTA_STATUS a = MTA_REJECTED, b = MTA_REJECTED;
    PREP(); OK(mta_hal_getDhcpStatus(&a, &b));
    UT_ASSERT(a >= MTA_INIT && a <= MTA_REJECTED);
    UT_ASSERT(b >= MTA_INIT && b <= MTA_REJECTED);
    BAD(mta_hal_getDhcpStatus(NULL, &b));
    BAD(mta_hal_getDhcpStatus(&a, NULL));
}
static void test_mta_hal_getLineRegisterStatus(void)
{
    MTAMGMT_MTA_STATUS values[MTA_LINENUMBER] = {MTA_INIT};
    PREP(); OK(mta_hal_getLineRegisterStatus(values, MTA_LINENUMBER));
    for (int i = 0; i < MTA_LINENUMBER; ++i)
        UT_ASSERT(values[i] >= MTA_INIT && values[i] <= MTA_REJECTED);
    BAD(mta_hal_getLineRegisterStatus(NULL, MTA_LINENUMBER));
    BAD(mta_hal_getLineRegisterStatus(values, -1));
}
static void test_mta_hal_start_provisioning(void)
{
    MTAMGMT_PROVISIONING_PARAMS p = {.MtaIPMode = MTA_DUAL_STACK};
    PREP(); OK(mta_hal_start_provisioning(&p));
    BAD(mta_hal_start_provisioning(NULL));
    p.MtaIPMode = 3; BAD(mta_hal_start_provisioning(&p));
}
static INT registration_callback(MTAMGMT_MTA_STATUS *values, int n)
{
    return values != NULL && n > 0 ? RETURN_OK : RETURN_ERR;
}
static void test_mta_hal_LineRegisterStatus_callback_register(void)
{
    PREP();
    mta_hal_LineRegisterStatus_callback_register(registration_callback);
#ifdef BUILD_LINUX
    mta_hal_LineRegisterStatus_callback_register(NULL);
#endif
}
static void test_types(void)
{
    ANSC_IPV4_ADDRESS ip = {.Dot = {192, 0, 2, 1}};
    uint32_t copy = 0;
    MTAMGMT_MTA_PROV_IP_MODE mode = MTA_DUAL_STACK;
    MTAMGMT_PROVISIONING_PARAMS p = {0};
    PREP(); memcpy(&copy, ip.Dot, sizeof(copy));
    UT_ASSERT_EQUAL(ip.Value, copy);
    UT_ASSERT_EQUAL(IPV4_ADDRESS_SIZE, 4);
    UT_ASSERT_EQUAL(MTA_HAL_SHORT_VALUE_LEN, 16);
    UT_ASSERT_EQUAL(MTA_HAL_LONG_VALUE_LEN, 64);
    UT_ASSERT_EQUAL(DECT_MAX_HANDSETS, 5); UT_ASSERT_EQUAL(MTA_LINENUMBER, 8);
    UT_ASSERT_EQUAL(sizeof(p.DhcpOption122Suboption1), MTA_DHCPOPTION122SUBOPTION1_MAX + 1);
    UT_ASSERT_EQUAL(sizeof(p.DhcpOption122Suboption2), MTA_DHCPOPTION122SUBOPTION2_MAX + 1);
    UT_ASSERT_EQUAL(sizeof(p.DhcpOption2171CccV6DssID1), MTA_DHCPOPTION122CCCV6DSSID1_MAX + 1);
    UT_ASSERT_EQUAL(sizeof(p.DhcpOption2171CccV6DssID2), MTA_DHCPOPTION122CCCV6DSSID2_MAX + 1);
    UT_ASSERT_EQUAL(mode, 2);
    UT_ASSERT(RETURN_OK == 0 && RETURN_ERR == -1 && TRUE == 1 && FALSE == 0 && ENABLE == 1);
    UT_ASSERT(MTA_INIT == 0 && MTA_START == 1 && MTA_COMPLETE == 2 &&
              MTA_ERROR == 3 && MTA_REJECTED == 4);
    UT_ASSERT(MTA_IPV4 == 0 && MTA_IPV6 == 1);
}
/* PUBLIC_INTERFACE */
/** Register checked L1 cases under the official L1 group. */
int test_mta_hal_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID("MTA L1", NULL, NULL, UT_TESTS_L1);
    if (suite == NULL) return -1;
#define ADD(fn) if (UT_add_test(suite, #fn, test_##fn) == NULL) return -1
    ADD(mta_hal_InitDB);
    ADD(mta_hal_GetDHCPInfo);
    ADD(mta_hal_GetDHCPV6Info);
    ADD(mta_hal_LineTableGetNumberOfEntries);
    ADD(mta_hal_LineTableGetEntry);
    ADD(mta_hal_DectGetEnable);
    ADD(mta_hal_DectGetRegistrationMode);
    ADD(mta_hal_GetDSXLogEnable);
    ADD(mta_hal_GetCallSignallingLogEnable);
    ADD(mta_hal_BatteryGetInstalled);
    ADD(mta_hal_getConfigFileStatus);
    ADD(mta_hal_getMtaOperationalStatus);
    ADD(mta_hal_getMtaProvisioningStatus);
    ADD(mta_hal_Get_MTAResetCount);
    ADD(mta_hal_Get_LineResetCount);
    ADD(mta_hal_DectSetEnable);
    ADD(mta_hal_DectSetRegistrationMode);
    ADD(mta_hal_SetDSXLogEnable);
    ADD(mta_hal_SetCallSignallingLogEnable);
    ADD(mta_hal_ClearDSXLog);
    ADD(mta_hal_ClearCallSignallingLog);
    ADD(mta_hal_devResetNow);
    ADD(mta_hal_GetDect);
    ADD(mta_hal_GetDectPIN);
    ADD(mta_hal_SetDectPIN);
    ADD(mta_hal_DectDeregisterDectHandset);
    ADD(mta_hal_TriggerDiagnostics);
    ADD(mta_hal_GetHandsets);
    ADD(mta_hal_GetDSXLogs);
    ADD(mta_hal_GetMtaLog);
    ADD(mta_hal_GetServiceFlow);
    ADD(mta_hal_GetCalls);
    ADD(mta_hal_ClearCalls);
    ADD(mta_hal_GetCALLP);
    ADD(mta_hal_BatteryGetTotalCapacity);
    ADD(mta_hal_BatteryGetActualCapacity);
    ADD(mta_hal_BatteryGetRemainingCharge);
    ADD(mta_hal_BatteryGetRemainingTime);
    ADD(mta_hal_BatteryGetNumberofCycles);
    ADD(mta_hal_BatteryGetPowerSavingModeStatus);
    ADD(mta_hal_BatteryGetPowerStatus);
    ADD(mta_hal_BatteryGetCondition);
    ADD(mta_hal_BatteryGetStatus);
    ADD(mta_hal_BatteryGetLife);
    ADD(mta_hal_BatteryGetInfo);
    ADD(mta_hal_getDhcpStatus);
    ADD(mta_hal_getLineRegisterStatus);
    ADD(mta_hal_start_provisioning);
    ADD(mta_hal_LineRegisterStatus_callback_register);
    ADD(types);
#undef ADD
    return 0;
}
