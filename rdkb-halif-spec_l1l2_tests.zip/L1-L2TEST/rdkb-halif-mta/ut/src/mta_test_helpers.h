/* Copyright 2023 RDK Management. Apache-2.0. */
#ifndef MTA_TEST_HELPERS_H
#define MTA_TEST_HELPERS_H
#include <stdbool.h>
#include <ut.h>
#include "mta_hal.h"
#ifdef BUILD_LINUX
#include "mta_test_control.h"
#endif

/* PUBLIC_INTERFACE */
/** Validate CLI/profile before framework initialization; return zero on success. */
int mta_validate_options(int argc, char **argv);
/* PUBLIC_INTERFACE */
/** Return the explicitly validated battery capability. */
bool mta_battery_supported(void);
/* PUBLIC_INTERFACE */
/** Initialize the HAL and reset the Linux fixture to the selected profile. */
int init_mta_hal_init(void);
/* PUBLIC_INTERFACE */
/** Register the checked L1 API cases. */
int test_mta_hal_l1_register(void);
/* PUBLIC_INTERFACE */
/** Register the ten Linux-only L2 sequences (no model cases on vendor builds). */
int test_mta_hal_l2_register(void);
/* PUBLIC_INTERFACE */
/** Register both levels, propagating every failure. */
int register_hal_tests(void);
#endif
