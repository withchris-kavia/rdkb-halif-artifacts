/* Copyright 2023 RDK Management. Apache-2.0.
 * Linux-reference sequences, not vendor conformance. Header contracts provide
 * API relationships; exact transitions/lifetimes follow MTA-GAP-01..08 in the
 * model. Each case resets independently, with no timing or external stimulus.
 */
#include "mta_test_helpers.h"
#ifdef BUILD_LINUX
#include <limits.h>
#include <string.h>
#define OK(call) UT_ASSERT_EQUAL_FATAL((call), RETURN_OK)
#define BAD(call) UT_ASSERT_EQUAL((call), RETURN_ERR)
#define PREP() OK(init_mta_hal_init())

static void provisioning(void)
{
    for (int mode = MTA_IPV4; mode <= MTA_DUAL_STACK; ++mode) {
        MTAMGMT_PROVISIONING_PARAMS p = {.MtaIPMode = mode};
        MTAMGMT_MTA_STATUS a = MTA_REJECTED, b = MTA_REJECTED, state = MTA_REJECTED;
        MTAMGMT_MTA_PROVISION_STATUS provision = MTA_PROVISIONED;
        MTAMGMT_MTA_DHCP_INFO v4;
        MTAMGMT_MTA_DHCPv6_INFO v6;
        MTAMGMT_MTA_STATUS lines[MTA_LINENUMBER];
        PREP();
        OK(mta_hal_getMtaProvisioningStatus(&provision));
        UT_ASSERT_EQUAL(provision, MTA_NON_PROVISIONED);
        OK(mta_hal_GetDHCPInfo(&v4)); UT_ASSERT_EQUAL(v4.IPAddress.Value, 0);
        BAD(mta_test_complete_provisioning());
        OK(mta_hal_start_provisioning(&p));
        OK(mta_hal_getDhcpStatus(&a, &b));
        UT_ASSERT_EQUAL(a, mode == MTA_IPV6 ? MTA_INIT : MTA_START);
        UT_ASSERT_EQUAL(b, mode == MTA_IPV4 ? MTA_INIT : MTA_START);
        OK(mta_hal_getConfigFileStatus(&state)); UT_ASSERT_EQUAL(state, MTA_START);
        OK(mta_hal_getMtaOperationalStatus(&state)); UT_ASSERT_EQUAL(state, MTA_START);
        OK(mta_test_complete_provisioning());
        OK(mta_hal_getDhcpStatus(&a, &b));
        UT_ASSERT_EQUAL(a, mode == MTA_IPV6 ? MTA_INIT : MTA_COMPLETE);
        UT_ASSERT_EQUAL(b, mode == MTA_IPV4 ? MTA_INIT : MTA_COMPLETE);
        OK(mta_hal_getConfigFileStatus(&state)); UT_ASSERT_EQUAL(state, MTA_COMPLETE);
        OK(mta_hal_getMtaOperationalStatus(&state)); UT_ASSERT_EQUAL(state, MTA_COMPLETE);
        OK(mta_hal_getMtaProvisioningStatus(&provision));
        UT_ASSERT_EQUAL(provision, MTA_PROVISIONED);
        OK(mta_hal_getLineRegisterStatus(lines, MTA_LINENUMBER));
        for (int i = 0; i < MTA_LINENUMBER; ++i) UT_ASSERT_EQUAL(lines[i], MTA_COMPLETE);
        OK(mta_hal_GetDHCPInfo(&v4)); OK(mta_hal_GetDHCPV6Info(&v6));
        UT_ASSERT_EQUAL(v4.IPAddress.Dot[0], mode == MTA_IPV6 ? 0 : 192);
        UT_ASSERT_EQUAL(strcmp(v6.IPV6Address, mode == MTA_IPV4 ? "::" : "2001:db8::10"), 0);
    }
}

static void binary_parameters(void)
{
    MTAMGMT_PROVISIONING_PARAMS p = {.MtaIPMode = MTA_DUAL_STACK}, expected, got;
    PREP();
    memset(p.DhcpOption122Suboption1, 0xff, MTA_DHCPOPTION122SUBOPTION1_MAX);
    p.DhcpOption122Suboption1[1] = 0;
    p.DhcpOption122Suboption2[0] = (char)192;
    p.DhcpOption122Suboption2[2] = 2;
    p.DhcpOption122Suboption2[3] = 1;
    p.DhcpOption2171CccV6DssID1Len = MTA_DHCPOPTION122CCCV6DSSID1_MAX;
    p.DhcpOption2171CccV6DssID2Len = MTA_DHCPOPTION122CCCV6DSSID2_MAX;
    memset(p.DhcpOption2171CccV6DssID1, 0xab, p.DhcpOption2171CccV6DssID1Len);
    memset(p.DhcpOption2171CccV6DssID2, 0xcd, p.DhcpOption2171CccV6DssID2Len);
    expected = p;
    OK(mta_hal_start_provisioning(&p));
    memset(&p, 0, sizeof(p));
    OK(mta_test_get_provisioning(&got));
    UT_ASSERT_EQUAL(memcmp(&got, &expected, sizeof(got)), 0);
    got.MtaIPMode = MTA_IPV4;
    OK(mta_test_get_provisioning(&got));
    UT_ASSERT_EQUAL(got.MtaIPMode, expected.MtaIPMode);
    p = expected; p.DhcpOption2171CccV6DssID1Len = -1;
    BAD(mta_hal_start_provisioning(&p));
    p = expected; p.DhcpOption2171CccV6DssID2Len = 33;
    BAD(mta_hal_start_provisioning(&p));
    mta_test_fail_next(); BAD(mta_hal_start_provisioning(&p));
    OK(mta_test_get_provisioning(&got));
    UT_ASSERT_EQUAL(memcmp(&got, &expected, sizeof(got)), 0);
}
static void line_calls(void)
{
    MTAMGMT_MTA_LINETABLE_INFO line;
    MTAMGMT_MTA_CALLP callp;
    PMTAMGMT_MTA_CALLS calls = NULL;
    PMTAMGMT_MTA_SERVICE_FLOW flows = NULL;
    MTAMGMT_PROVISIONING_PARAMS p = {.MtaIPMode = MTA_DUAL_STACK};
    ULONG n = ULONG_MAX;
    PREP(); OK(mta_hal_GetServiceFlow(&n, &flows));
    UT_ASSERT_EQUAL(n, 0); UT_ASSERT_PTR_NULL(flows);
    mta_test_seed_calls();
    OK(mta_hal_start_provisioning(&p)); OK(mta_test_complete_provisioning());
    OK(mta_hal_GetServiceFlow(&n, &flows));
    UT_ASSERT_EQUAL_FATAL(n, 1); UT_ASSERT_PTR_NOT_NULL_FATAL(flows);
    UT_ASSERT_EQUAL(flows->DefaultFlow, TRUE);
    flows->SFID = 999;
    OK(mta_hal_GetServiceFlow(&n, &flows)); UT_ASSERT_EQUAL(flows->SFID, 1);
    UT_ASSERT_EQUAL(mta_hal_LineTableGetNumberOfEntries(), MTA_LINENUMBER);
    for (ULONG i = 0; i < MTA_LINENUMBER; ++i) {
        OK(mta_hal_LineTableGetEntry(i, &line));
        UT_ASSERT_EQUAL(line.InstanceNumber, i + 101);
        UT_ASSERT_EQUAL(line.LineNumber, i + 1);
        UT_ASSERT_EQUAL_FATAL(line.CallsNumber, 1);
        UT_ASSERT_PTR_NOT_NULL_FATAL(line.pCalls);
        OK(mta_hal_GetCalls(line.InstanceNumber, &n, &calls));
        UT_ASSERT_EQUAL_FATAL(n, line.CallsNumber);
        UT_ASSERT_PTR_NOT_NULL_FATAL(calls);
        UT_ASSERT_EQUAL(memcmp(line.pCalls, calls, sizeof(*calls)), 0);
        calls->CallDuration = 999;
        OK(mta_hal_GetCalls(line.InstanceNumber, &n, &calls));
        UT_ASSERT_EQUAL(calls->CallDuration, i + 10);
        OK(mta_hal_GetCALLP(line.LineNumber, &callp));
        UT_ASSERT_EQUAL(strcmp(callp.LCState, line.Status == 1 ? "Idle" : "In Use"), 0);
        UT_ASSERT_EQUAL(strcmp(callp.CallPState, "In Service"), 0);
        BAD(mta_hal_GetCalls(i, &n, &calls));
        BAD(mta_hal_GetCALLP(line.InstanceNumber, &callp));
    }
}
static void diagnostics(void)
{
    MTAMGMT_MTA_LINETABLE_INFO before[MTA_LINENUMBER], after;
    PREP();
    for (ULONG i = 0; i < MTA_LINENUMBER; ++i)
        OK(mta_hal_LineTableGetEntry(i, &before[i]));
    OK(mta_hal_TriggerDiagnostics(3));
    for (ULONG i = 0; i < MTA_LINENUMBER; ++i) {
        OK(mta_hal_LineTableGetEntry(i, &after));
        if (i == 3) {
            UT_ASSERT_EQUAL(strcmp(after.HazardousPotential, "Passed"), 0);
            UT_ASSERT_EQUAL(strcmp(after.ForeignEMF, "Passed"), 0);
            UT_ASSERT_EQUAL(strcmp(after.ResistiveFaults, "Passed"), 0);
            UT_ASSERT_EQUAL(strcmp(after.ReceiverOffHook, "Passed"), 0);
        } else UT_ASSERT_EQUAL(memcmp(&after, &before[i], sizeof(after)), 0);
    }
    mta_test_fail_next(); BAD(mta_hal_TriggerDiagnostics(0));
    OK(mta_hal_LineTableGetEntry(0, &after));
    UT_ASSERT_EQUAL(memcmp(&after, &before[0], sizeof(after)), 0);
}
static void dect_lifecycle(void)
{
    BOOLEAN flag = FALSE;
    char pin[128], got[128];
    MTAMGMT_MTA_DECT dect;
    PMTAMGMT_MTA_HANDSETS_INFO handsets = NULL;
    ULONG n = 0, removed = 0;
    PREP();
    OK(mta_hal_DectSetRegistrationMode(TRUE));
    OK(mta_hal_DectSetEnable(FALSE));
    OK(mta_hal_DectGetRegistrationMode(&flag)); UT_ASSERT_EQUAL(flag, FALSE);
    BAD(mta_hal_DectSetRegistrationMode(TRUE));
    OK(mta_hal_DectSetEnable(TRUE)); OK(mta_hal_DectSetRegistrationMode(TRUE));
    OK(mta_hal_DectGetRegistrationMode(&flag)); UT_ASSERT_EQUAL(flag, TRUE);
    memset(pin, '7', sizeof(pin)); pin[63] = '\0';
    OK(mta_hal_SetDectPIN(pin)); OK(mta_hal_GetDectPIN(got));
    UT_ASSERT_EQUAL(memcmp(pin, got, 64), 0);
    OK(mta_hal_GetDect(&dect)); UT_ASSERT_EQUAL(memcmp(dect.PIN, got, 64), 0);
    pin[63] = '7'; pin[64] = '\0'; BAD(mta_hal_SetDectPIN(pin));
    memset(pin, '7', sizeof(pin)); BAD(mta_hal_SetDectPIN(pin));
    pin[0] = '\0'; BAD(mta_hal_SetDectPIN(pin));
    strcpy(pin, "12x"); BAD(mta_hal_SetDectPIN(pin));
    OK(mta_hal_GetDectPIN(pin)); UT_ASSERT_EQUAL(memcmp(pin, got, 64), 0);
    OK(mta_test_seed_handsets(DECT_MAX_HANDSETS));
    BAD(mta_test_seed_handsets(DECT_MAX_HANDSETS + 1));
    OK(mta_hal_GetHandsets(&n, &handsets));
    UT_ASSERT_EQUAL_FATAL(n, DECT_MAX_HANDSETS);
    UT_ASSERT_PTR_NOT_NULL_FATAL(handsets);
    removed = handsets[2].InstanceNumber;
    handsets[0].InstanceNumber = 999;
    OK(mta_hal_GetHandsets(&n, &handsets)); UT_ASSERT_EQUAL(handsets[0].InstanceNumber, 201);
    OK(mta_hal_DectDeregisterDectHandset(removed));
    BAD(mta_hal_DectDeregisterDectHandset(removed));
    OK(mta_hal_GetHandsets(&n, &handsets)); UT_ASSERT_EQUAL(n, DECT_MAX_HANDSETS - 1);
    for (ULONG i = 0; i < n; ++i) UT_ASSERT_NOT_EQUAL(handsets[i].InstanceNumber, removed);
    OK(mta_hal_DectSetRegistrationMode(FALSE));
    OK(mta_hal_DectGetEnable(&flag)); UT_ASSERT_EQUAL(flag, TRUE);
}
static void statistics(void)
{
    MTAMGMT_MTA_LINETABLE_INFO first, second;
    MTAMGMT_MTA_CALLS neighbor;
    PMTAMGMT_MTA_CALLS calls = NULL;
    ULONG n = 0;
    PREP(); mta_test_seed_calls();
    OK(mta_hal_LineTableGetEntry(0, &first));
    OK(mta_hal_LineTableGetEntry(1, &second));
    OK(mta_hal_GetCalls(second.InstanceNumber, &n, &calls));
    UT_ASSERT_EQUAL_FATAL(n, 1); UT_ASSERT_PTR_NOT_NULL_FATAL(calls);
    neighbor = *calls;
    OK(mta_hal_ClearCalls(first.InstanceNumber));
    OK(mta_hal_GetCalls(first.InstanceNumber, &n, &calls));
    UT_ASSERT_EQUAL_FATAL(n, 1); UT_ASSERT_PTR_NOT_NULL_FATAL(calls);
    UT_ASSERT_EQUAL(calls->CallDuration, 0);
    UT_ASSERT_EQUAL(strcmp(calls->TxPackets, "0"), 0);
    UT_ASSERT_EQUAL(strcmp(calls->RxPackets, "0"), 0);
    UT_ASSERT_EQUAL(strcmp(calls->TxOctets, "0"), 0);
    UT_ASSERT_EQUAL(strcmp(calls->RxOctets, "0"), 0);
    UT_ASSERT_EQUAL(strcmp(calls->PacketLoss, "0"), 0);
    OK(mta_hal_GetCalls(second.InstanceNumber, &n, &calls));
    UT_ASSERT_EQUAL(memcmp(calls, &neighbor, sizeof(neighbor)), 0);
    mta_test_fail_next(); BAD(mta_hal_ClearCalls(second.InstanceNumber));
    OK(mta_hal_GetCalls(second.InstanceNumber, &n, &calls));
    UT_ASSERT_EQUAL(memcmp(calls, &neighbor, sizeof(neighbor)), 0);
}
static void logging_lifecycle(void)
{
    BOOLEAN dsx_flag, mta_flag, flag;
    ULONG n = 0;
    PMTAMGMT_MTA_DSXLOG dsx = NULL;
    PMTAMGMT_MTA_MTALOG_FULL log = NULL;
    PREP();
    OK(mta_hal_GetDSXLogEnable(&dsx_flag));
    OK(mta_hal_GetCallSignallingLogEnable(&mta_flag));
    OK(mta_hal_SetDSXLogEnable(TRUE)); OK(mta_hal_SetCallSignallingLogEnable(TRUE));
    mta_test_seed_logs();
    OK(mta_hal_ClearDSXLog(FALSE)); OK(mta_hal_ClearCallSignallingLog(FALSE));
    OK(mta_hal_GetDSXLogs(&n, &dsx)); UT_ASSERT_EQUAL_FATAL(n, 1);
    UT_ASSERT_PTR_NOT_NULL_FATAL(dsx); dsx->ID = 999;
    OK(mta_hal_GetDSXLogs(&n, &dsx)); UT_ASSERT_EQUAL(dsx->ID, 1);
    OK(mta_hal_GetMtaLog(&n, &log)); UT_ASSERT_EQUAL_FATAL(n, 1);
    UT_ASSERT_PTR_NOT_NULL_FATAL(log); UT_ASSERT_PTR_NOT_NULL_FATAL(log->pDescription);
    log->pDescription[0] = 'X';
    OK(mta_hal_GetMtaLog(&n, &log)); UT_ASSERT_EQUAL(log->pDescription[0], 'r');
    OK(mta_hal_SetDSXLogEnable(FALSE)); OK(mta_hal_SetCallSignallingLogEnable(FALSE));
    OK(mta_hal_ClearDSXLog(TRUE)); OK(mta_hal_ClearCallSignallingLog(TRUE));
    mta_test_seed_logs();
    OK(mta_hal_GetDSXLogs(&n, &dsx)); UT_ASSERT_EQUAL(n, 0); UT_ASSERT_PTR_NULL(dsx);
    OK(mta_hal_GetMtaLog(&n, &log)); UT_ASSERT_EQUAL(n, 0); UT_ASSERT_PTR_NULL(log);
    OK(mta_hal_SetDSXLogEnable(TRUE)); OK(mta_hal_SetCallSignallingLogEnable(TRUE));
    mta_test_seed_logs();
    OK(mta_hal_GetDSXLogs(&n, &dsx)); UT_ASSERT_EQUAL(n, 1);
    OK(mta_hal_GetMtaLog(&n, &log)); UT_ASSERT_EQUAL(n, 1);
    OK(mta_hal_SetDSXLogEnable(dsx_flag));
    OK(mta_hal_SetCallSignallingLogEnable(mta_flag));
    OK(mta_hal_GetDSXLogEnable(&flag)); UT_ASSERT_EQUAL(flag, dsx_flag);
    OK(mta_hal_GetCallSignallingLogEnable(&flag)); UT_ASSERT_EQUAL(flag, mta_flag);
}
static void battery_telemetry(void)
{
    INT (*numbers[])(ULONG *) = {
        mta_hal_BatteryGetTotalCapacity, mta_hal_BatteryGetActualCapacity,
        mta_hal_BatteryGetRemainingCharge, mta_hal_BatteryGetRemainingTime,
        mta_hal_BatteryGetNumberofCycles, mta_hal_BatteryGetPowerSavingModeStatus
    };
    INT (*strings[])(CHAR *, ULONG *) = {
        mta_hal_BatteryGetPowerStatus, mta_hal_BatteryGetCondition,
        mta_hal_BatteryGetStatus, mta_hal_BatteryGetLife
    };
    const ULONG expected[] = {1000, 900, 600, 120, 10, 1};
    BOOLEAN installed = FALSE;
    PREP();
    OK(mta_hal_BatteryGetInstalled(&installed));
    UT_ASSERT_EQUAL(installed, mta_battery_supported() ? TRUE : FALSE);
    for (int present = 0; present <= 1; ++present) {
        MTAMGMT_MTA_BATTERY_INFO info, sentinel;
        mta_test_seed_battery(present != 0);
        OK(mta_hal_BatteryGetInstalled(&installed));
        UT_ASSERT_EQUAL(installed, present);
        for (unsigned int i = 0; i < sizeof(numbers) / sizeof(numbers[0]); ++i) {
            ULONG value = ULONG_MAX;
            int rc = numbers[i](&value);
            UT_ASSERT_EQUAL(rc, present ? RETURN_OK : RETURN_ERR);
            UT_ASSERT_EQUAL(value, present ? expected[i] : ULONG_MAX);
        }
        for (unsigned int i = 0; i < sizeof(strings) / sizeof(strings[0]); ++i) {
            char text[128], saved[128];
            ULONG len = 0;
            bool available = present || i == 0 || i == 2;
            memset(text, 'X', sizeof(text)); memcpy(saved, text, sizeof(text));
            BAD(strings[i](text, &len));
            UT_ASSERT_EQUAL(memcmp(text, saved, sizeof(text)), 0);
            if (available) {
                UT_ASSERT(len > 1 && len <= sizeof(text));
                OK(strings[i](text, &len));
                UT_ASSERT_EQUAL(strlen(text) + 1, len);
            } else {
                UT_ASSERT_EQUAL(len, 0);
                len = sizeof(text); BAD(strings[i](text, &len));
                UT_ASSERT_EQUAL(memcmp(text, saved, sizeof(text)), 0);
            }
        }
        memset(&info, 0xa5, sizeof(info)); sentinel = info;
        UT_ASSERT_EQUAL(mta_hal_BatteryGetInfo(&info), present ? RETURN_OK : RETURN_ERR);
        if (!present) UT_ASSERT_EQUAL(memcmp(&info, &sentinel, sizeof(info)), 0);
    }
    mta_test_seed_battery(mta_battery_supported());
}
static void reset_behavior(void)
{
    MTAMGMT_PROVISIONING_PARAMS p = {.MtaIPMode = MTA_DUAL_STACK};
    MTAMGMT_MTA_STATUS state = MTA_REJECTED;
    MTAMGMT_MTA_PROVISION_STATUS provision = MTA_PROVISIONED;
    MTAMGMT_MTA_DHCP_INFO dhcp;
    PMTAMGMT_MTA_CALLS calls = NULL;
    ULONG count = ULONG_MAX, resets = ULONG_MAX;
    BOOLEAN installed = FALSE;
    PREP(); mta_test_seed_calls(); mta_test_seed_logs();
    OK(mta_hal_start_provisioning(&p)); OK(mta_test_complete_provisioning());
    OK(mta_hal_InitDB());
    OK(mta_hal_getMtaOperationalStatus(&state)); UT_ASSERT_EQUAL(state, MTA_COMPLETE);
    OK(mta_hal_devResetNow(FALSE));
    OK(mta_hal_Get_MTAResetCount(&resets)); UT_ASSERT_EQUAL(resets, 0);
    mta_test_fail_next(); BAD(mta_hal_devResetNow(TRUE));
    OK(mta_hal_Get_MTAResetCount(&resets)); UT_ASSERT_EQUAL(resets, 0);
    for (ULONG i = 1; i <= 2; ++i) {
        OK(mta_hal_devResetNow(TRUE));
        OK(mta_hal_Get_MTAResetCount(&resets)); UT_ASSERT_EQUAL(resets, i);
        OK(mta_hal_Get_LineResetCount(&resets)); UT_ASSERT_EQUAL(resets, i * MTA_LINENUMBER);
        OK(mta_hal_getMtaOperationalStatus(&state)); UT_ASSERT_EQUAL(state, MTA_INIT);
        OK(mta_hal_getMtaProvisioningStatus(&provision));
        UT_ASSERT_EQUAL(provision, MTA_NON_PROVISIONED);
        OK(mta_hal_GetDHCPInfo(&dhcp)); UT_ASSERT_EQUAL(dhcp.IPAddress.Value, 0);
        OK(mta_hal_GetCalls(101, &count, &calls));
        UT_ASSERT_EQUAL(count, 0); UT_ASSERT_PTR_NULL(calls);
        OK(mta_hal_BatteryGetInstalled(&installed));
        UT_ASSERT_EQUAL(installed, mta_battery_supported() ? TRUE : FALSE);
    }
    mta_test_reset(mta_battery_supported());
    UT_ASSERT_EQUAL(mta_hal_LineTableGetNumberOfEntries(), 0);
    state = MTA_REJECTED;
    BAD(mta_hal_getMtaOperationalStatus(&state)); UT_ASSERT_EQUAL(state, MTA_REJECTED);
    OK(mta_hal_InitDB());
    OK(mta_hal_Get_MTAResetCount(&resets)); UT_ASSERT_EQUAL(resets, 0);
}
static MTAMGMT_MTA_STATUS callback_values[MTA_LINENUMBER];
static int first_calls, second_calls;
static INT first_callback(MTAMGMT_MTA_STATUS *values, int n)
{
    ++first_calls;
    if (values == NULL || n != MTA_LINENUMBER) return RETURN_ERR;
    memcpy(callback_values, values, sizeof(callback_values));
    values[0] = MTA_ERROR;
    return 17;
}
static INT second_callback(MTAMGMT_MTA_STATUS *values, int n)
{
    ++second_calls;
    if (values == NULL || n != MTA_LINENUMBER) return RETURN_ERR;
    memcpy(callback_values, values, sizeof(callback_values));
    values[0] = MTA_REJECTED;
    return 23;
}
static void callback_polling(void)
{
    MTAMGMT_PROVISIONING_PARAMS p = {.MtaIPMode = MTA_IPV4};
    MTAMGMT_MTA_STATUS polled[MTA_LINENUMBER], saved[MTA_LINENUMBER];
    PREP(); first_calls = second_calls = 0;
    mta_hal_LineRegisterStatus_callback_register(first_callback);
    BAD(mta_test_dispatch_callback());
    OK(mta_hal_start_provisioning(&p));
    UT_ASSERT_EQUAL(mta_test_dispatch_callback(), 17);
    UT_ASSERT_EQUAL(first_calls, 1);
    OK(mta_hal_getLineRegisterStatus(polled, MTA_LINENUMBER));
    UT_ASSERT_EQUAL(memcmp(polled, callback_values, sizeof(polled)), 0);
    UT_ASSERT_EQUAL(polled[0], MTA_START);
    memcpy(saved, polled, sizeof(saved));
    BAD(mta_hal_getLineRegisterStatus(polled, MTA_LINENUMBER - 1));
    UT_ASSERT_EQUAL(memcmp(polled, saved, sizeof(saved)), 0);
    mta_test_fail_next(); BAD(mta_hal_getLineRegisterStatus(polled, MTA_LINENUMBER));
    UT_ASSERT_EQUAL(memcmp(polled, saved, sizeof(saved)), 0);
    mta_hal_LineRegisterStatus_callback_register(second_callback);
    OK(mta_test_complete_provisioning());
    UT_ASSERT_EQUAL(mta_test_dispatch_callback(), 23);
    UT_ASSERT_EQUAL(first_calls, 1); UT_ASSERT_EQUAL(second_calls, 1);
    OK(mta_hal_getLineRegisterStatus(polled, MTA_LINENUMBER));
    UT_ASSERT_EQUAL(memcmp(polled, callback_values, sizeof(polled)), 0);
    UT_ASSERT_EQUAL(polled[0], MTA_COMPLETE);
    BAD(mta_test_dispatch_callback());
    OK(mta_hal_devResetNow(TRUE));
    UT_ASSERT_EQUAL(mta_test_dispatch_callback(), 23);
    UT_ASSERT_EQUAL(callback_values[0], MTA_INIT);
    OK(mta_hal_start_provisioning(&p));
    mta_hal_LineRegisterStatus_callback_register(NULL);
    BAD(mta_test_dispatch_callback());
    mta_hal_LineRegisterStatus_callback_register(first_callback);
    OK(mta_hal_start_provisioning(&p)); OK(mta_test_complete_provisioning());
    UT_ASSERT_EQUAL(mta_test_dispatch_callback(), 17);
    UT_ASSERT_EQUAL(callback_values[0], MTA_COMPLETE);
    mta_hal_LineRegisterStatus_callback_register(NULL);
}
#endif

/* PUBLIC_INTERFACE */
/** Register reference-only stateful sequences, excluded from vendor builds. */
int test_mta_hal_l2_register(void)
{
#ifdef BUILD_LINUX
    UT_test_suite_t *suite = UT_add_suite_withGroupID("MTA L2", NULL, NULL, UT_TESTS_L2);
    if (suite == NULL) return -1;
#define ADD(name) if (UT_add_test(suite, #name, name) == NULL) return -1
    ADD(provisioning);
    ADD(binary_parameters);
    ADD(line_calls);
    ADD(diagnostics);
    ADD(dect_lifecycle);
    ADD(statistics);
    ADD(logging_lifecycle);
    ADD(battery_telemetry);
    ADD(reset_behavior);
    ADD(callback_polling);
#undef ADD
#endif
    return 0;
}
