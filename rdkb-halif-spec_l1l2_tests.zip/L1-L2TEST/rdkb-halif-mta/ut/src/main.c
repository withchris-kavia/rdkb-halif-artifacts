/* Copyright 2023 RDK Management. Apache-2.0. */
#include "mta_test_helpers.h"
#include <stdio.h>
#include <stdlib.h>

extern void __real_CU_cleanup_registry(void);
typedef struct { CU_pSuite suite; UT_groupID_t group; } suite_entry_t;
typedef struct { int group; bool enabled; } group_filter_t;
static suite_entry_t suites[100];
static group_filter_t filters[50];
static unsigned int suite_count, filter_count;
static bool registration_failed, configuration_failed, running, captured;
static unsigned int tests_run, assertions_failed, suites_failed, tests_failed;
static CU_ErrorCode run_error;

/* PUBLIC_INTERFACE */
/** Snapshot results while valid, then always release the real CUnit registry. */
void __wrap_CU_cleanup_registry(void)
{
    if (running && !captured) {
        tests_run = CU_get_number_of_tests_run();
        assertions_failed = CU_get_number_of_failures();
        tests_failed = CU_get_number_of_tests_failed();
        suites_failed = CU_get_number_of_suites_failed();
        run_error = CU_get_error();
        captured = true;
        fprintf(stderr, "MTA_RESULT tests=%u failed=%u assertions_failed=%u "
                "suites_failed=%u error=%d\n", tests_run, tests_failed,
                assertions_failed, suites_failed, (int)run_error);
    }
    __real_CU_cleanup_registry();
}

/* PUBLIC_INTERFACE */
/** Preserve official ordered -d/-e switches with bounded component storage. */
void __wrap_UT_Manage_Suite_Activation(int group, bool enabled)
{
    if (group < UT_TESTS_L1 || group >= UT_TESTS_MAX ||
        filter_count >= sizeof(filters) / sizeof(filters[0])) {
        configuration_failed = true;
        return;
    }
    filters[filter_count++] = (group_filter_t){group, enabled};
}

/* PUBLIC_INTERFACE */
/** Register a suite and group, retaining failures without framework allocations. */
UT_test_suite_t *__wrap_UT_add_suite_withGroupID(
    const char *name, UT_InitialiseFunction_t init,
    UT_CleanupFunction_t cleanup, UT_groupID_t group)
{
    CU_pSuite suite;
    if (suite_count >= sizeof(suites) / sizeof(suites[0]) ||
        group < UT_TESTS_L1 || group >= UT_TESTS_MAX) {
        registration_failed = true;
        return NULL;
    }
    suite = CU_add_suite(name, init, cleanup);
    if (suite == NULL || CU_get_error() != CUE_SUCCESS) {
        registration_failed = true;
        return NULL;
    }
    suites[suite_count++] = (suite_entry_t){suite, group};
    return (UT_test_suite_t *)suite;
}

/* PUBLIC_INTERFACE */
/** Avoid upstream's aborting assert and retain individual registration failures. */
UT_test_t *__wrap_UT_add_test(UT_test_suite_t *suite, const char *name,
                            UT_TestFunction_t function)
{
    CU_pTest test = CU_add_test((CU_pSuite)suite, name, function);
    if (test == NULL || CU_get_error() != CUE_SUCCESS)
        registration_failed = true;
    return (UT_test_t *)test;
}

/* PUBLIC_INTERFACE */
/** Run the official UT CLI; return zero only for a nonempty successful run. */
int main(int argc, char **argv)
{
    UT_status_t status;
    if (mta_validate_options(argc, argv) != 0)
        return EXIT_FAILURE;
    if (UT_init(argc, argv) != UT_STATUS_OK || configuration_failed) {
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }
    CU_set_fail_on_inactive(CU_FALSE);
    if (register_hal_tests() != 0 || registration_failed ||
        CU_get_error() != CUE_SUCCESS) {
        fprintf(stderr, "MTA registration failed\n");
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }
    for (unsigned int i = 0; i < filter_count; ++i)
        for (unsigned int j = 0; j < suite_count; ++j)
            if ((int)suites[j].group == filters[i].group)
                CU_set_suite_active(suites[j].suite,
                                    filters[i].enabled ? CU_TRUE : CU_FALSE);
    running = true;
    status = UT_run_tests();
    UT_exit();
    if (status != UT_STATUS_OK || !captured || tests_run == 0 ||
        assertions_failed != 0 || tests_failed != 0 || suites_failed != 0 ||
        run_error != CUE_SUCCESS) {
        fprintf(stderr, "MTA run failed or selected zero tests\n");
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
