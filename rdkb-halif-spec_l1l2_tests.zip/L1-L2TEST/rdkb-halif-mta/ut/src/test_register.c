/* Copyright 2023 RDK Management. Apache-2.0. */
#include "mta_test_helpers.h"

/* PUBLIC_INTERFACE */
/** Register both test levels, returning failure if either registration fails. */
int register_hal_tests(void)
{
    int l1 = test_mta_hal_l1_register();
    int l2 = test_mta_hal_l2_register();
    return l1 != 0 || l2 != 0 ? -1 : 0;
}
