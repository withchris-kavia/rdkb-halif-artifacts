# Unit Testing Suite for mta HAL

The following documents should be referenced to provide specific information on the tests required for this module.

[Documentation can be found under "docs/pages" in this repository](docs/pages)

## Table of Contents

- [Version History](#version-history)
- [Acronyms, Terms and Abbreviations](#acronyms-terms-and-abbreviations)
- [Description](#description)
- [Reference Documents](#reference-documents)

## Version History

| Date | Comment | Version |
| --- | --- | --- |
| 02/08/24 | Initial Release | 1.0.0 |

## Acronyms, Terms and Abbreviations

- `L1` - Unit Tests
- `HAL`- Hardware Abstraction Layer

## Description

This repository contains the Unit Test Suites (L1) for mta `HAL`.

## Reference Documents

|SNo|Document Name|Document Description|Document Link|
|---|-------------|--------------------|-------------|
|1|`HAL` Specification Document|This document provides specific information on the APIs for which tests are written in this module|[MTAhalSpec.md](https://github.com/rdkcentral/rdkb-halif-mta/blob/main/docs/pages/MTAhalSpec.md "MTAhalSpec.md")|
|2|`L1` Tests |`L1` Test Case File for this module |[test_l1_mta_hal.c](src/test_l1_mta_hal.c "test_l1_mta_hal.c")|

## Independent Verification

See [independent verification results](tests/VERIFICATION_RESULTS.md) for the host acceptance matrix, individual L1/L2 results, deliberate failure probes, protected-file checks, and remaining coverage limits.
