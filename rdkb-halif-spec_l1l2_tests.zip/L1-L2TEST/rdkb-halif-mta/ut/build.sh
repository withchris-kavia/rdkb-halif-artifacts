#!/usr/bin/env bash
# Copyright 2023 RDK Management. Licensed under the Apache License, Version 2.0.
set -u
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || exit 1
cd -- "$SCRIPT_DIR" || exit 1
if [[ ! -d ut-core ]]; then
    git clone -- https://github.com/rdkcentral/ut-core.git ut-core || exit "$?"
    if [[ -z ${UT_CORE_PROJECT_VERSION:-} ]]; then
        UT_CORE_PROJECT_VERSION=$(git -C ut-core tag --list '3.*' --sort=-version:refname) || exit 1
        UT_CORE_PROJECT_VERSION=${UT_CORE_PROJECT_VERSION%%$'\n'*}
        [[ -n $UT_CORE_PROJECT_VERSION ]] || {
            printf '%s\n' 'No compatible tag; set UT_CORE_PROJECT_VERSION.' >&2
            exit 1
        }
    fi
    git -C ut-core checkout "$UT_CORE_PROJECT_VERSION" || exit "$?"
fi
# Dependencies must be bootstrapped separately; never build/clean inside ut-core.
exec make -C "$SCRIPT_DIR" -f Makefile "$@"
