#!/usr/bin/env bash
# Copyright 2023 RDK Management. Licensed under the Apache License, Version 2.0.
set -u
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || exit 1
if [[ ${1:-} == -h || ${1:-} == --help ]]; then
    printf '%s\n' 'Usage: build_ut.sh [clean] [TARGET=linux|arm] [make assignments]'
    exit 0
fi
if [[ ! -d "$SCRIPT_DIR/ut" ]]; then
    git clone -- https://github.com/rdkcentral/rdkb-halif-test-mta.git "$SCRIPT_DIR/ut" || exit "$?"
    git -C "$SCRIPT_DIR/ut" checkout "${UT_PROJECT_VERSION:-main}" || exit "$?"
fi
cd -- "$SCRIPT_DIR/ut" || exit 1
exec ./build.sh "$@"
