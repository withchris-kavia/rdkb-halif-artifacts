#!/usr/bin/env bash
# Copyright 2023 RDK Management. Licensed under the Apache License, Version 2.0.
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [[ ${1:-} == -h || ${1:-} == --help ]]; then
    printf '%s\n' 'Usage: build_ut.sh [clean] [TARGET=linux|arm] [make assignments...]'
    exit 0
fi
if [[ ! -d "$SCRIPT_DIR/ut" ]]; then
    remote=$(git -C "$SCRIPT_DIR" remote get-url origin)
    case "$remote" in
        *rdkb-halif-wifi*) repo=${remote/rdkb-halif-wifi/rdkb-halif-test-wifi} ;;
        *) printf '%s\n' "Cannot derive Wi-Fi test repository from $remote" >&2; exit 1 ;;
    esac
    git clone -- "$repo" "$SCRIPT_DIR/ut"
    git -C "$SCRIPT_DIR/ut" checkout "${UT_PROJECT_VERSION:-master}"
fi
cd -- "$SCRIPT_DIR/ut"
exec ./build.sh "$@"
