#!/usr/bin/env bash
# Copyright 2023 RDK Management. Licensed under the Apache License, Version 2.0.
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd -- "$SCRIPT_DIR"
if [[ ! -d ut-core ]]; then
    git clone -- https://github.com/rdkcentral/ut-core.git ut-core
    git -C ut-core checkout "${UT_CORE_VERSION:-1.6.0}"
fi
exec make -C "$SCRIPT_DIR" "$@"
