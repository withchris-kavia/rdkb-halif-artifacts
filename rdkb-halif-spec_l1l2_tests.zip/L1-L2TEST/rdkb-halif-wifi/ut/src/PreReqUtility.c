#include "PreReqUtility.h"
#include "config_parser.h"

/* PUBLIC_INTERFACE */
/** Initialize and provision every configured radio/VAP, failing at the first error. */
int WiFiPreReq(void)
{
    UINT r, radios;
    wifi_radio_operationParam_t radio;
    wifi_vap_info_map_t map;
    if (wifi_init() || test_utils_getMaxNumberOfRadio(&radios) || validate_wifi_config(radios))
        return -1;
    for (r = 0; r < radios; ++r) {
        if (get_radio_config((INT)r, &radio) || wifi_setRadioOperatingParameters(r, &radio) ||
            get_vap_map_config((INT)r, &map) || wifi_createVAP(r, &map)) return -1;
    }
    return 0;
}
/* PUBLIC_INTERFACE */
/** Apply one role-selected VAP into its existing radio map without dropping peers. */
int createVAP(int radio, int ap, APTYPE type)
{
    wifi_vap_info_t vap;
    wifi_vap_info_map_t map;
    UINT i;
    int result;
    switch (type) {
    case PRIVATE: result = get_private_vap_config(ap, &vap); break;
    case STA: result = get_mesh_sta_vap_config(ap, &vap); break;
    case IOT: result = get_iot_vap_config(ap, &vap); break;
    case BACKHAUL: result = get_mesh_backhaul_vap_config(ap, &vap); break;
    case LNF_PSK: result = get_lnf_psk_vap_config(ap, &vap); break;
    case LNF_RADIUS: result = get_lnf_radius_vap_config(ap, &vap); break;
    case HOTSPOT_OPEN: result = get_hotspot_open_vap_config(ap, &vap); break;
    case HOTSPOT_SECURE: result = get_hotspot_secure_vap_config(ap, &vap); break;
    default: return -1;
    }
    if (result || radio < 0 || vap.radio_index != (UINT)radio ||
        wifi_getRadioVapInfoMap((UINT)radio, &map) || map.num_vaps > MAX_NUM_VAP_PER_RADIO) return -1;
    for (i = 0; i < map.num_vaps; ++i) if (map.vap_array[i].vap_index == (UINT)ap) break;
    if (i == map.num_vaps) {
        if (i == MAX_NUM_VAP_PER_RADIO) return -1;
        ++map.num_vaps;
    }
    map.vap_array[i] = vap;
    return wifi_createVAP((UINT)radio, &map);
}
