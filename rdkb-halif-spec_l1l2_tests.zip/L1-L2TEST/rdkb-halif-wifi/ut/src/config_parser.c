#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <arpa/inet.h>
#include "cJSON.h"
#include "config_parser.h"

#ifndef WIFI_TEST_CONFIG_DIR
#error "WIFI_TEST_CONFIG_DIR must identify the component configuration directory"
#endif
#define CONFIG_LIMIT (1024 * 1024)

static cJSON *load(const char *file, const char *key, cJSON **root)
{
    char path[4096], *text;
    long length;
    size_t read_count;
    FILE *stream;
    cJSON *array;
    /* Optional test invocation override; not a required deployment environment variable. */
    const char *directory = getenv("WIFI_TEST_CONFIG_DIR");
    if (!directory) directory = WIFI_TEST_CONFIG_DIR;
    *root = NULL;
    if (snprintf(path, sizeof(path), "%s/%s", directory, file) >= (int)sizeof(path)) return NULL;
    stream = fopen(path, "rb");
    if (!stream) return NULL;
    if (fseek(stream, 0, SEEK_END) || (length = ftell(stream)) < 1 || length > CONFIG_LIMIT ||
        fseek(stream, 0, SEEK_SET)) { fclose(stream); return NULL; }
    text = malloc((size_t)length + 1);
    if (!text) { fclose(stream); return NULL; }
    read_count = fread(text, 1, (size_t)length, stream);
    fclose(stream);
    text[read_count] = '\0';
    if (read_count == (size_t)length) *root = cJSON_ParseWithOpts(text, NULL, 1);
    free(text);
    if (!cJSON_IsObject(*root)) { cJSON_Delete(*root); *root = NULL; return NULL; }
    array = cJSON_GetObjectItemCaseSensitive(*root, key);
    return cJSON_IsArray(array) ? array : NULL;
}

static int number(cJSON *object, const char *key, UINT min, UINT max, UINT *output)
{
    cJSON *item = cJSON_GetObjectItemCaseSensitive(object, key);
    double value;
    if (!cJSON_IsNumber(item)) return -1;
    value = item->valuedouble;
    if (!(value >= min && value <= max) || value != (double)(UINT)value) return -1;
    *output = (UINT)value;
    return 0;
}
static int boolean(cJSON *object, const char *key, BOOL *output)
{
    cJSON *item = cJSON_GetObjectItemCaseSensitive(object, key);
    if (!cJSON_IsBool(item)) return -1;
    *output = cJSON_IsTrue(item) ? TRUE : FALSE;
    return 0;
}
static int string(cJSON *object, const char *key, char *output, size_t capacity, int empty)
{
    cJSON *item = cJSON_GetObjectItemCaseSensitive(object, key);
    size_t length;
    if (!cJSON_IsString(item) || !item->valuestring) return -1;
    length = strlen(item->valuestring);
    if (length >= capacity || (!length && !empty)) return -1;
    memcpy(output, item->valuestring, length + 1);
    return 0;
}
static int mac(cJSON *object, const char *key, unsigned char output[6])
{
    char value[18], tail;
    unsigned int bytes[6], i;
    if (string(object, key, value, sizeof(value), 0) || strlen(value) != 17 ||
        sscanf(value, "%2x:%2x:%2x:%2x:%2x:%2x%c", &bytes[0], &bytes[1], &bytes[2],
               &bytes[3], &bytes[4], &bytes[5], &tail) != 6) return -1;
    for (i = 0; i < 6; ++i) {
        if (bytes[i] > 255) return -1;
        output[i] = (unsigned char)bytes[i];
    }
    return 0;
}
static int country(cJSON *object, wifi_countrycode_type_t *code)
{
    char value[3];
    if (string(object, "Country", value, sizeof(value), 0)) return -1;
    if (!strcmp(value, "US")) *code = wifi_countrycode_US;
    else if (!strcmp(value, "GB")) *code = wifi_countrycode_GB;
    else if (!strcmp(value, "CA")) *code = wifi_countrycode_CA;
    else if (!strcmp(value, "DE")) *code = wifi_countrycode_DE;
    else return -1; /* Never silently substitute a country. */
    return 0;
}

static int decode_radio(cJSON *item, wifi_radio_operationParam_t *radio, UINT *index)
{
    UINT value, i, count;
    BOOL enabled, automatic;
    wifi_countrycode_type_t code;
    cJSON *secondary;
    memset(radio, 0, sizeof(*radio));
    if (number(item, "RadioIndex", 0, MAX_NUM_RADIOS - 1, index) ||
        boolean(item, "Enabled", &enabled) || boolean(item, "AutoChannelEnabled", &automatic) ||
        country(item, &code)) return -1;
    radio->enable = enabled;
    radio->autoChannelEnabled = automatic;
    radio->countryCode = code;
#define RADIO_NUMBER(Key, Field, Min, Max) do { \
    if (number(item, Key, Min, Max, &value)) return -1; \
    radio->Field = value; \
} while (0)
    RADIO_NUMBER("FreqBand", band, 1, WIFI_FREQUENCY_6_BAND);
    if (radio->band != WIFI_FREQUENCY_2_4_BAND && radio->band != WIFI_FREQUENCY_5_BAND &&
        radio->band != WIFI_FREQUENCY_6_BAND) return -1;
    RADIO_NUMBER("Channel", channel, 1, 233);
    RADIO_NUMBER("ChannelWidth", channelWidth, 1, WIFI_CHANNELBANDWIDTH_320MHZ);
    value = (UINT)radio->channelWidth;
    if ((value & (value - 1)) || (radio->band == WIFI_FREQUENCY_2_4_BAND && value > 2)) return -1;
    RADIO_NUMBER("HwMode", variant, 1, 0x3ff);
    RADIO_NUMBER("TransmitPower", transmitPower, 0, 100);
    RADIO_NUMBER("BeaconInterval", beaconInterval, 1, 65535);
    RADIO_NUMBER("DtimPeriod", dtimPeriod, 1, 255);
    RADIO_NUMBER("GuardInterval", guardInterval, 1, 16);
    if (((UINT)radio->guardInterval & ((UINT)radio->guardInterval - 1)) != 0) return -1;
    RADIO_NUMBER("RadioStatsMeasuringRate", radioStatsMeasuringRate, 1, 86400);
    RADIO_NUMBER("RadioStatsMeasuringInterval", radioStatsMeasuringInterval, 1, 86400);
    if (radio->radioStatsMeasuringRate > radio->radioStatsMeasuringInterval) return -1;
    RADIO_NUMBER("NumSecondaryChannels", numSecondaryChannels, 0, MAXNUMSECONDARYCHANNELS);
#undef RADIO_NUMBER
    secondary = cJSON_GetObjectItemCaseSensitive(item, "SecondaryChannelsList");
    if (!cJSON_IsArray(secondary)) return -1;
    count = (UINT)cJSON_GetArraySize(secondary);
    if (count != radio->numSecondaryChannels) return -1;
    for (i = 0; i < count; ++i) {
        cJSON *channel = cJSON_GetArrayItem(secondary, (int)i);
        if (!cJSON_IsNumber(channel) || !(channel->valuedouble >= 1 && channel->valuedouble <= 233) ||
            channel->valuedouble != (UINT)channel->valuedouble) return -1;
        radio->channelSecondary[i] = (UINT)channel->valuedouble;
    }
    return 0;
}

static int decode_security(cJSON *item, wifi_vap_security_t *security)
{
    char mode[32], encryption[16], mfp[16];
    cJSON *radius;
    UINT port;
    memset(security, 0, sizeof(*security));
    if (!cJSON_IsObject(item) || string(item, "Mode", mode, sizeof(mode), 0) ||
        string(item, "EncryptionMethod", encryption, sizeof(encryption), 0) ||
        string(item, "MFPConfig", mfp, sizeof(mfp), 0)) return -1;
#ifdef WIFI_HAL_VERSION_3
    if (!strcmp(mfp, "Disabled")) security->mfp = wifi_mfp_cfg_disabled;
    else if (!strcmp(mfp, "Optional")) security->mfp = wifi_mfp_cfg_optional;
    else if (!strcmp(mfp, "Required")) security->mfp = wifi_mfp_cfg_required;
    else return -1;
#else
    if (strcmp(mfp, "Disabled") && strcmp(mfp, "Optional") && strcmp(mfp, "Required")) return -1;
    strcpy(security->mfpConfig, mfp);
#endif
    if (!strcmp(mode, "None")) {
        if (strcmp(encryption, "None")) return -1;
        security->mode = wifi_security_mode_none;
        return 0;
    }
    if (strcmp(encryption, "AES")) return -1;
    security->encr = wifi_encryption_aes;
    if (!strcmp(mode, "WPA2-Personal") || !strcmp(mode, "WPA3-Personal")) {
        security->mode = !strcmp(mode, "WPA2-Personal") ?
                         wifi_security_mode_wpa2_personal : wifi_security_mode_wpa3_personal;
        security->u.key.type = wifi_security_key_type_pass;
        if (string(item, "Passphrase", security->u.key.key, 64, 0) ||
            strlen(security->u.key.key) < 8) return -1;
    } else if (!strcmp(mode, "WPA2-Enterprise")) {
        char ip[46];
        struct in_addr address;
        security->mode = wifi_security_mode_wpa2_enterprise;
        radius = cJSON_GetObjectItemCaseSensitive(item, "RadiusSettings");
        if (!cJSON_IsObject(radius) || string(radius, "RadiusServerIPAddr", ip, sizeof(ip), 0) ||
            inet_pton(AF_INET, ip, &address) != 1 ||
            number(radius, "RadiusServerPort", 1, 65535, &port) ||
            string(radius, "RadiusSecret", security->u.radius.key, sizeof(security->u.radius.key), 0))
            return -1;
        security->u.radius.port = (USHORT)port;
#ifdef WIFI_HAL_VERSION_3_PHASE2
        security->u.radius.ip.family = wifi_ip_family_ipv4;
        security->u.radius.ip.u.IPv4addr = address.s_addr;
#else
        strcpy((char *)security->u.radius.ip, ip);
#endif
    } else return -1;
    return 0;
}

static int decode_vap(cJSON *item, wifi_vap_info_t *vap)
{
    UINT index, radio, mode, value;
    BOOL enabled;
    unsigned char bssid[6];
    wifi_vap_security_t security;
    memset(vap, 0, sizeof(*vap));
    if (number(item, "VapIndex", 0, MAX_NUM_RADIOS * MAX_NUM_VAP_PER_RADIO - 1, &index) ||
        number(item, "RadioIndex", 0, MAX_NUM_RADIOS - 1, &radio) ||
        number(item, "VapMode", 0, 1, &mode) ||
        string(item, "VapName", vap->vap_name, sizeof(vap->vap_name), 0) ||
        string(item, "BridgeName", vap->bridge_name, sizeof(vap->bridge_name), 1) ||
        boolean(item, "Enabled", &enabled) || mac(item, "BSSID", bssid) ||
        decode_security(cJSON_GetObjectItemCaseSensitive(item, "Security"), &security)) return -1;
    vap->vap_index = index;
    vap->radio_index = radio;
    vap->vap_mode = (wifi_vap_mode_t)mode;
    if (mode == wifi_vap_mode_sta) {
        if (string(item, "SSID", vap->u.sta_info.ssid, sizeof(vap->u.sta_info.ssid), 0)) return -1;
        vap->u.sta_info.enabled = enabled;
        vap->u.sta_info.conn_status = enabled ? wifi_connection_status_disconnected : wifi_connection_status_disabled;
        memcpy(vap->u.sta_info.bssid, bssid, 6);
        vap->u.sta_info.security = security;
    } else {
        wifi_front_haul_bss_t *bss = &vap->u.bss_info;
        BOOL show, isolation, wps;
        if (string(item, "SSID", bss->ssid, sizeof(bss->ssid), 0) ||
            boolean(item, "SSIDAdvertisementEnabled", &show) ||
            boolean(item, "IsolationEnable", &isolation) ||
            boolean(item, "WpsEnable", &wps) ||
            number(item, "BssMaxNumSta", 1, 1024, &value)) return -1;
        bss->enabled = enabled;
        bss->showSsid = show;
        bss->isolation = isolation;
        bss->bssMaxSta = value;
        bss->wps.enable = wps;
        if (number(item, "WpsConfigMethodsEnabled", 0, 0x3fff, &value) ||
            string(item, "WpsPin", bss->wps.pin, sizeof(bss->wps.pin), 1)) return -1;
        bss->wps.methods = (wifi_onboarding_methods_t)value;
        if (bss->wps.pin[0]) {
            size_t n = strlen(bss->wps.pin);
            size_t i;
            if (n != 4 && n != 8) return -1;
            for (i = 0; i < n; ++i)
                if (bss->wps.pin[i] < '0' || bss->wps.pin[i] > '9') return -1;
        }
        memcpy(bss->bssid, bssid, 6);
        bss->security = security;
    }
    return 0;
}

/* PUBLIC_INTERFACE */
/** Decode all radio entries, rejecting duplicates/malformed peers before output commit. */
int get_radio_config(int index, wifi_radio_operationParam_t *radio)
{
    cJSON *root, *array, *item;
    wifi_radio_operationParam_t decoded, selected;
    UINT id, seen = 0;
    int found = 0, result = -1;
    if (!radio || index < 0 || index >= MAX_NUM_RADIOS) return -1;
    array = load("radio_config", "WifiRadioConfig", &root);
    if (!array || cJSON_GetArraySize(array) < 1 || cJSON_GetArraySize(array) > MAX_NUM_RADIOS) goto done;
    cJSON_ArrayForEach(item, array) {
        if (decode_radio(item, &decoded, &id) || (seen & (1u << id))) goto done;
        seen |= 1u << id;
        if (id == (UINT)index) { selected = decoded; found = 1; }
    }
    if (found) { *radio = selected; result = 0; }
done:
    cJSON_Delete(root);
    return result;
}

/* PUBLIC_INTERFACE */
/** Decode an entire VAP array safely and return only the requested radio map. */
int get_vap_map_config(int radio, wifi_vap_info_map_t *map)
{
    cJSON *root, *array, *item;
    wifi_vap_info_map_t decoded = {0};
    wifi_vap_info_t vap;
    unsigned int seen = 0;
    int result = -1;
    if (!map || radio < 0 || radio >= MAX_NUM_RADIOS) return -1;
    array = load("vap_config", "WifiVapConfig", &root);
    if (!array || cJSON_GetArraySize(array) < 1 ||
        cJSON_GetArraySize(array) > MAX_NUM_RADIOS * MAX_NUM_VAP_PER_RADIO) goto done;
    cJSON_ArrayForEach(item, array) {
        if (decode_vap(item, &vap) || (seen & (1u << vap.vap_index))) goto done;
        seen |= 1u << vap.vap_index;
        if (vap.radio_index == (UINT)radio) {
            if (decoded.num_vaps >= MAX_NUM_VAP_PER_RADIO) goto done;
            decoded.vap_array[decoded.num_vaps++] = vap;
        }
    }
    if (decoded.num_vaps) { *map = decoded; result = 0; }
done:
    cJSON_Delete(root);
    return result;
}

/* PUBLIC_INTERFACE */
/** Require contiguous configured radios and at least one AP and STA on every live radio. */
int validate_wifi_config(UINT radios)
{
    UINT r, v;
    wifi_radio_operationParam_t op;
    wifi_vap_info_map_t map;
    cJSON *root, *array;
    int count;
    if (!radios || radios > MAX_NUM_RADIOS) return -1;
    array = load("radio_config", "WifiRadioConfig", &root);
    count = array ? cJSON_GetArraySize(array) : 0;
    cJSON_Delete(root);
    if (count != (int)radios) return -1;
    for (r = 0; r < radios; ++r) {
        BOOL ap = FALSE, sta = FALSE;
        if (get_radio_config((INT)r, &op) || get_vap_map_config((INT)r, &map)) return -1;
        for (v = 0; v < map.num_vaps; ++v) {
            ap |= map.vap_array[v].vap_mode == wifi_vap_mode_ap;
            sta |= map.vap_array[v].vap_mode == wifi_vap_mode_sta;
        }
        if (!ap || !sta) return -1;
    }
    for (r = radios; r < MAX_NUM_RADIOS; ++r)
        if (!get_vap_map_config((INT)r, &map)) return -1;
    return 0;
}

static int role(int index, wifi_vap_info_t *vap, const char *prefix)
{
    UINT r, v;
    wifi_vap_info_map_t map;
    if (!vap || index < 0) return -1;
    for (r = 0; r < MAX_NUM_RADIOS; ++r) {
        if (get_vap_map_config((int)r, &map)) continue;
        for (v = 0; v < map.num_vaps; ++v)
            if (map.vap_array[v].vap_index == (UINT)index &&
                !strncmp(map.vap_array[v].vap_name, prefix, strlen(prefix))) {
                *vap = map.vap_array[v];
                return 0;
            }
    }
    return -1;
}
/* PUBLIC_INTERFACE */
/** Generate role-specific readers; missing or mismatched roles always fail. */
#define ROLE_READER(Name, Prefix) \
int get_##Name##_vap_config(int index, wifi_vap_info_t *vap) { return role(index, vap, Prefix); }
ROLE_READER(private, "private")
ROLE_READER(mesh_sta, "mesh_sta")
ROLE_READER(iot, "iot")
ROLE_READER(mesh_backhaul, "mesh_backhaul")
ROLE_READER(lnf_psk, "lnf_psk")
ROLE_READER(lnf_radius, "lnf_radius")
ROLE_READER(hotspot_open, "hotspot_open")
ROLE_READER(hotspot_secure, "hotspot_secure")
#undef ROLE_READER
