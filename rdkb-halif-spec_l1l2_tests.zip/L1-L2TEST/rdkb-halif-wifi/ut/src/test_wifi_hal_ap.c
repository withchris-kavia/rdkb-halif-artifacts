#include "test_support.h"

static void vap_security_wps(void)
{
    wifi_vap_info_map_t map, original, actual;
    wifi_vap_security_t security, saved;
    wifi_wps_t wps, saved_wps;
    UINT i;
    INT ap, sta;
    WIFI_PREPARE();
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    sta = wifi_test_index(wifi_vap_mode_sta, 0);
    CU_ASSERT(ap >= 0 && sta >= 0);
    CU_ASSERT_EQUAL_FATAL(wifi_getRadioVapInfoMap(0, &original), 0);
    map = original;
    strcpy(map.vap_array[0].u.bss_info.ssid, "updated-ap");
    CU_ASSERT_EQUAL(wifi_createVAP(0, &map), 0);
    CU_ASSERT_EQUAL(wifi_getRadioVapInfoMap(0, &actual), 0);
    CU_ASSERT_STRING_EQUAL(actual.vap_array[0].u.bss_info.ssid, "updated-ap");
    map.num_vaps = MAX_NUM_VAP_PER_RADIO + 1;
    CU_ASSERT_NOT_EQUAL(wifi_createVAP(0, &map), 0);
    CU_ASSERT_EQUAL(wifi_getApSecurity(ap, &saved), 0);
    security = saved;
    security.mode = wifi_security_mode_wpa2_personal;
    security.encr = wifi_encryption_aes;
    strcpy(security.u.key.key, "bounded-test-key");
    CU_ASSERT_EQUAL(wifi_setApSecurity(ap, &security), 0);
    strcpy(security.u.key.key, "short");
    CU_ASSERT_NOT_EQUAL(wifi_setApSecurity(ap, &security), 0);
    CU_ASSERT_NOT_EQUAL(wifi_getApSecurity(sta, &security), 0);
    CU_ASSERT_EQUAL(wifi_setApSecurity(ap, &saved), 0);
    CU_ASSERT_EQUAL(wifi_getApWpsConfiguration(ap, &saved_wps), 0);
    wps = saved_wps;
    strcpy(wps.pin, "12345670");
    CU_ASSERT_EQUAL(wifi_setApWpsConfiguration(ap, &wps), 0);
    CU_ASSERT_EQUAL(wifi_getRadioVapInfoMap(0, &actual), 0);
    strcpy(wps.pin, "abcd");
    CU_ASSERT_NOT_EQUAL(wifi_setApWpsConfiguration(ap, &wps), 0);
    map = actual;
    for (i = 0; i < map.num_vaps; ++i)
        if (map.vap_array[i].vap_index == (UINT)ap) map.vap_array[i].u.bss_info.wps = wps;
    CU_ASSERT_NOT_EQUAL(wifi_createVAP(0, &map), 0);
    CU_ASSERT_EQUAL(wifi_getRadioVapInfoMap(0, &map), 0);
    CU_ASSERT_EQUAL(memcmp(&map, &actual, sizeof(map)), 0);
    CU_ASSERT_EQUAL(wifi_setApWpsConfiguration(ap, &saved_wps), 0);
    CU_ASSERT_EQUAL(wifi_createVAP(0, &original), 0);
}

#ifdef BUILD_LINUX
static UINT associated, disassociated;
#ifdef WIFI_HAL_VERSION_3_PHASE2
static INT on_associated(INT ap, wifi_associated_dev3_t *device)
#else
static INT on_associated(INT ap, wifi_associated_dev_t *device)
#endif
{
    CU_ASSERT(ap >= 0);
    CU_ASSERT_PTR_NOT_NULL(device);
    if (device) { CU_ASSERT_TRUE(device->cli_Active); CU_ASSERT_EQUAL(device->cli_MACAddress[0], 2); }
    ++associated;
    return 0;
}
static INT on_disassociated(INT ap, char *mac, INT event)
{
    CU_ASSERT(ap >= 0);
    CU_ASSERT_STRING_EQUAL(mac, "02:00:00:00:00:01");
    CU_ASSERT_EQUAL(event, 1);
    ++disassociated;
    return 0;
}
static INT on_deauth(INT ap, char *mac, INT reason)
{ (void)ap; (void)mac; (void)reason; return 0; }
#ifdef WIFI_HAL_VERSION_3_PHASE2
static INT on_management(INT ap, wifi_frame_t *frame)
{ (void)ap; (void)frame; return 0; }
#else
static INT on_management(INT ap, UCHAR *mac, UCHAR *frame, UINT length,
                         wifi_mgmtFrameType_t type, wifi_direction_t dir, unsigned int freq)
{ (void)ap; (void)mac; (void)frame; (void)length; (void)type; (void)dir; (void)freq; return 0; }
#endif
static void ap_callbacks_and_clients(void)
{
    mac_address_t mac = {2, 0, 0, 0, 0, 1};
    INT ap;
#ifdef WIFI_HAL_VERSION_3_PHASE2
    mac_address_t clients[1];
    UINT count;
#else
    char clients[18];
#endif
    WIFI_PREPARE();
    associated = disassociated = 0;
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    wifi_newApAssociatedDevice_callback_register(on_associated);
    wifi_apDisassociatedDevice_callback_register(on_disassociated);
    wifi_apDeAuthEvent_callback_register(on_deauth);
    CU_ASSERT_EQUAL(wifi_mgmt_frame_callbacks_register(on_management), 0);
    CU_ASSERT_EQUAL(wifi_test_client_event(ap, TRUE), 0);
    CU_ASSERT_EQUAL(associated, 1);
#ifdef WIFI_HAL_VERSION_3_PHASE2
    CU_ASSERT_NOT_EQUAL(wifi_getApAssociatedDevice(ap, NULL, 0, &count), 0);
    CU_ASSERT_EQUAL(wifi_getApAssociatedDevice(ap, clients, 1, &count), 0);
    CU_ASSERT_EQUAL(count, 1);
    CU_ASSERT_EQUAL(memcmp(clients[0], mac, 6), 0);
    CU_ASSERT_EQUAL(wifi_kickApAssociatedDevice(ap, mac), 0);
#else
    CU_ASSERT_NOT_EQUAL(wifi_getApAssociatedDevice(ap, clients, 1), 0);
    CU_ASSERT_EQUAL(wifi_getApAssociatedDevice(ap, clients, sizeof(clients)), 0);
    CU_ASSERT_STRING_EQUAL(clients, "02:00:00:00:00:01");
    CU_ASSERT_NOT_EQUAL(wifi_kickApAssociatedDevice(ap, "bad-mac"), 0);
    CU_ASSERT_EQUAL(wifi_kickApAssociatedDevice(ap, clients), 0);
#endif
    CU_ASSERT_EQUAL(disassociated, 1);
    CU_ASSERT_EQUAL(wifi_enableCSIEngine(ap, NULL, FALSE), 0);
    CU_ASSERT_EQUAL(wifi_enableCSIEngine(ap, mac, FALSE), 0);
    CU_ASSERT_EQUAL(wifi_enableCSIEngine(ap, mac, TRUE), WIFI_HAL_UNSUPPORTED);
    CU_ASSERT_NOT_EQUAL(wifi_enableCSIEngine(ap, NULL, TRUE), 0);
    CU_ASSERT_NOT_EQUAL(wifi_enableCSIEngine(ap, mac, 2), 0);
    CU_ASSERT_NOT_EQUAL(wifi_enableCSIEngine(-1, NULL, FALSE), 0);
    wifi_newApAssociatedDevice_callback_register(NULL);
    wifi_apDisassociatedDevice_callback_register(NULL);
    wifi_apDeAuthEvent_callback_register(NULL);
    CU_ASSERT_EQUAL(wifi_mgmt_frame_callbacks_register(NULL), 0);
    CU_ASSERT_EQUAL(wifi_test_client_event(ap, TRUE), 0);
    CU_ASSERT_EQUAL(associated, 1);
}
#endif

/* PUBLIC_INTERFACE */
/** Register AP maps, security/WPS and selected-ABI callback checks. */
int test_wifi_ap_register(void)
{
    static const wifi_test_case_t cases[] = {
        WIFI_CASE(vap_security_wps),
#ifdef BUILD_LINUX
        WIFI_CASE(ap_callbacks_and_clients),
#endif
    };
    return WIFI_REGISTER("[L1 wifi-ap]", cases);
}
