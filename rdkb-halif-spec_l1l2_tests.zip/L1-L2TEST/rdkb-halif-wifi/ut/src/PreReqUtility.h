#ifndef WIFI_TEST_PREREQUISITES_H
#define WIFI_TEST_PREREQUISITES_H
#include "test_utils.h"
/* PUBLIC_INTERFACE */
/** Initialize HAL and provision validated nonzero topology; return zero on success. */
int WiFiPreReq(void);
/* PUBLIC_INTERFACE */
/** Apply one configured VAP by role/index, retaining every peer in its radio map. */
int createVAP(int radio, int ap, APTYPE type);
#endif
