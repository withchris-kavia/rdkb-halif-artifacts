#ifndef WIFI_TEST_CONFIG_PARSER_H
#define WIFI_TEST_CONFIG_PARSER_H
#include "wifi_hal.h"
/* PUBLIC_INTERFACE */
/** Decode one radio transactionally from the configured JSON directory. */
int get_radio_config(int index, wifi_radio_operationParam_t *radio);
/* PUBLIC_INTERFACE */
/** Decode and validate a complete per-radio VAP map. */
int get_vap_map_config(int radio, wifi_vap_info_map_t *map);
/* PUBLIC_INTERFACE */
/** Validate radio/VAP counts and membership against nonzero HAL capabilities. */
int validate_wifi_config(UINT radios);
/* PUBLIC_INTERFACE */
/** Read a private VAP selected by its public index. */
int get_private_vap_config(int index, wifi_vap_info_t *vap);
/* PUBLIC_INTERFACE */
/** Read a mesh station VAP selected by its public index. */
int get_mesh_sta_vap_config(int index, wifi_vap_info_t *vap);
/* PUBLIC_INTERFACE */
/** Read an IoT VAP selected by its public index. */
int get_iot_vap_config(int index, wifi_vap_info_t *vap);
/* PUBLIC_INTERFACE */
/** Read a backhaul VAP selected by its public index. */
int get_mesh_backhaul_vap_config(int index, wifi_vap_info_t *vap);
/* PUBLIC_INTERFACE */
/** Read a personal lost-and-found VAP. */
int get_lnf_psk_vap_config(int index, wifi_vap_info_t *vap);
/* PUBLIC_INTERFACE */
/** Read an enterprise lost-and-found VAP. */
int get_lnf_radius_vap_config(int index, wifi_vap_info_t *vap);
/* PUBLIC_INTERFACE */
/** Read an open hotspot VAP. */
int get_hotspot_open_vap_config(int index, wifi_vap_info_t *vap);
/* PUBLIC_INTERFACE */
/** Read a secure hotspot VAP. */
int get_hotspot_secure_vap_config(int index, wifi_vap_info_t *vap);
#endif
