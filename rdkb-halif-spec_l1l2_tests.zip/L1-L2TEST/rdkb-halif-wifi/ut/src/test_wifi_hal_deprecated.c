#include "test_support.h"

static void legacy_roundtrips(void)
{
    char country[3], original_country[3], width[16], original_width[16];
    wifi_radio_operationParam_t modern;
    wifi_radioTrafficStatsMeasure_t measure = {0};
    INT ap;
    WIFI_PREPARE();
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    CU_ASSERT_TRUE(wifi_steering_supported());
    CU_ASSERT_EQUAL(wifi_getRadioCountryCode(0, original_country), 0);
    CU_ASSERT_EQUAL(wifi_setRadioCountryCode(0, "GB"), 0);
    CU_ASSERT_EQUAL(wifi_getRadioCountryCode(0, country), 0);
    CU_ASSERT_STRING_EQUAL(country, "GB");
    CU_ASSERT_NOT_EQUAL(wifi_setRadioCountryCode(0, "XX"), 0);
    CU_ASSERT_EQUAL(wifi_getRadioOperatingChannelBandwidth(0, original_width), 0);
    CU_ASSERT_EQUAL(wifi_setRadioOperatingChannelBandwidth(0, "40MHz"), 0);
    CU_ASSERT_EQUAL(wifi_getRadioOperatingChannelBandwidth(0, width), 0);
    CU_ASSERT_STRING_EQUAL(width, "40MHz");
    CU_ASSERT_EQUAL(wifi_getRadioOperatingParameters(0, &modern), 0);
    CU_ASSERT_EQUAL(modern.channelWidth, WIFI_CHANNELBANDWIDTH_40MHZ);
    CU_ASSERT_NOT_EQUAL(wifi_setRadioOperatingChannelBandwidth(0, "40"), 0);
    CU_ASSERT_EQUAL(test_utils_setValidSSID(0, ap, 0), 0);
    CU_ASSERT_EQUAL(test_utils_setInValidIndexSSID(0, ap, 0), 0);
    CU_ASSERT_EQUAL(test_utils_setNULLSSID(0, ap, 0), 0);
    measure.radio_RadioStatisticsMeasuringRate = 5;
    measure.radio_RadioStatisticsMeasuringInterval = 30;
    CU_ASSERT_EQUAL(wifi_setRadioTrafficStatsMeasure(0, &measure), 0);
    measure.radio_RadioStatisticsMeasuringRate = 0;
    CU_ASSERT_NOT_EQUAL(wifi_setRadioTrafficStatsMeasure(0, &measure), 0);
    CU_ASSERT_EQUAL(wifi_setRadioTrafficStatsRadioStatisticsEnable(0, TRUE), 0);
    CU_ASSERT_EQUAL(wifi_setRadioCountryCode(0, original_country), 0);
    CU_ASSERT_EQUAL(wifi_setRadioOperatingChannelBandwidth(0, original_width), 0);
}

/* PUBLIC_INTERFACE */
/** Register legacy public-symbol checks without translator redirects. */
int test_wifi_deprecated_register(void)
{
    static const wifi_test_case_t cases[] = { WIFI_CASE(legacy_roundtrips) };
    return WIFI_REGISTER("[L1 wifi-deprecated]", cases);
}
