#include "test_support.h"

static void telemetry_snapshots(void)
{
    wifi_radioTrafficStats2_t stats;
    wifi_ssidTrafficStats2_t ssid;
    wifi_associated_dev3_t *devices = NULL;
    wifi_VAPTelemetry_t vap;
    UINT count = 0;
    INT utilization = -1, ap;
    BOOL enabled;
    WIFI_PREPARE();
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &stats), 0);
#ifdef BUILD_LINUX
    CU_ASSERT_EQUAL(stats.radio_ChannelUtilization, (ULONG)-1);
    CU_ASSERT_EQUAL(stats.radio_ActivityFactor, -1);
    CU_ASSERT_EQUAL(stats.radio_CarrierSenseThreshold_Exceeded, -1);
    CU_ASSERT_EQUAL(stats.radio_RetransmissionMetirc, -1);
    CU_ASSERT_EQUAL(stats.radio_MaximumNoiseFloorOnChannel, -1);
    CU_ASSERT_EQUAL(stats.radio_MinimumNoiseFloorOnChannel, -1);
    CU_ASSERT_EQUAL(stats.radio_MedianNoiseFloorOnChannel, -1);
#endif
    /* Zero traffic is valid; an uncalculated interval is distinct from zero traffic. */
    CU_ASSERT_EQUAL(wifi_getSSIDTrafficStats2(ap, &ssid), 0);
    CU_ASSERT_EQUAL(wifi_getRadioBandUtilization(0, &utilization), 0);
    CU_ASSERT(utilization >= 0 && utilization <= 100);
    CU_ASSERT_EQUAL(wifi_getVAPTelemetry((UINT)ap, &vap), 0);
    CU_ASSERT_EQUAL(wifi_setRadioStatsEnable(0, FALSE), 0);
    CU_ASSERT_EQUAL(wifi_getRadioStatsEnable(0, &enabled), 0);
    CU_ASSERT_FALSE(enabled);
    CU_ASSERT_EQUAL(wifi_setClientDetailedStatisticsEnable(0, TRUE), 0);
    CU_ASSERT_EQUAL(wifi_getRadioStatsEnable(0, &enabled), 0);
    CU_ASSERT_FALSE(enabled);
    CU_ASSERT_EQUAL(wifi_setRadioStatsEnable(0, TRUE), 0);
    CU_ASSERT_EQUAL(wifi_setClientDetailedStatisticsEnable(0, FALSE), 0);
    CU_ASSERT_EQUAL(wifi_getRadioStatsEnable(0, &enabled), 0);
    CU_ASSERT_TRUE(enabled);
    CU_ASSERT_NOT_EQUAL(wifi_setClientDetailedStatisticsEnable(-1, TRUE), 0);
    CU_ASSERT_NOT_EQUAL(wifi_setClientDetailedStatisticsEnable(0, 2), 0);
    CU_ASSERT_EQUAL(wifi_getRadioStatsEnable(0, &enabled), 0);
    CU_ASSERT_TRUE(enabled);
    CU_ASSERT_EQUAL(wifi_getApAssociatedDeviceDiagnosticResult3(ap, &devices, &count), 0);
    CU_ASSERT(count == 0 || devices != NULL);
    free(devices);
    CU_ASSERT_NOT_EQUAL(wifi_getRadioTrafficStats2(-1, &stats), 0);
    CU_ASSERT_NOT_EQUAL(wifi_getRadioTrafficStats2(0, NULL), 0);
}
#ifdef BUILD_LINUX
static void client_diagnostics(void)
{
    wifi_associated_dev3_t *devices = NULL, device;
    UINT count = 0;
    INT ap;
    WIFI_PREPARE();
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    CU_ASSERT_EQUAL(wifi_test_client_event(ap, TRUE), 0);
    CU_ASSERT_EQUAL(wifi_getApAssociatedDeviceDiagnosticResult3(ap, &devices, &count), 0);
    CU_ASSERT_EQUAL(count, 1);
    if (devices) {
        CU_ASSERT_TRUE(devices[0].cli_Active);
        CU_ASSERT_PTR_NULL(devices[0].cli_CsiData);
        free(devices);
    }
#ifdef WIFI_HAL_VERSION_3_PHASE2
    {
        mac_address_t mac = {2, 0, 0, 0, 0, 1};
        CU_ASSERT_EQUAL(wifi_getApAssociatedClientDiagnosticResult(ap, mac, &device), 0);
    }
#else
    CU_ASSERT_EQUAL(wifi_getApAssociatedClientDiagnosticResult(ap, "02:00:00:00:00:01", &device), 0);
#endif
    CU_ASSERT_EQUAL(device.cli_MACAddress[0], 2);
    wifi_test_fail_allocation();
    devices = NULL;
    count = 99;
    CU_ASSERT_NOT_EQUAL(wifi_getApAssociatedDeviceDiagnosticResult3(ap, &devices, &count), 0);
    CU_ASSERT_PTR_NULL(devices);
    CU_ASSERT_EQUAL(count, 0);
}
#endif

/* PUBLIC_INTERFACE */
/** Register safe zero-counter and diagnostic ownership checks. */
int test_wifi_telemetry_register(void)
{
    static const wifi_test_case_t cases[] = {
        WIFI_CASE(telemetry_snapshots),
#ifdef BUILD_LINUX
        WIFI_CASE(client_diagnostics),
#endif
    };
    return WIFI_REGISTER("[L1 wifi-telemetry]", cases);
}
