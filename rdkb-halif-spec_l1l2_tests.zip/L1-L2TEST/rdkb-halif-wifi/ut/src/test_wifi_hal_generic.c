#include "test_support.h"

static void capabilities_and_init(void)
{
    wifi_hal_capability_t cap;
    UINT radios, r;
    WIFI_PREPARE();
    CU_ASSERT_EQUAL_FATAL(wifi_init(), 0);
    CU_ASSERT_EQUAL_FATAL(wifi_getHalCapability(&cap), 0);
    CU_ASSERT_EQUAL_FATAL(test_utils_getMaxNumberOfRadio(&radios), 0);
    CU_ASSERT(radios > 0 && radios <= MAX_NUM_RADIOS);
    CU_ASSERT_EQUAL(cap.version.major, WIFI_HAL_MAJOR_VERSION);
    for (r = 0; r < radios; ++r) {
        CU_ASSERT(cap.wifi_prop.radio_presence[r]);
        CU_ASSERT(cap.wifi_prop.radiocap[r].maxNumberVAPs > 0);
        CU_ASSERT(cap.wifi_prop.radiocap[r].numSupportedFreqBand > 0);
    }
    CU_ASSERT_NOT_EQUAL(wifi_getHalCapability(NULL), 0);
    CU_ASSERT_NOT_EQUAL(test_utils_getMaxNumberOfRadio(NULL), 0);
}

#ifdef BUILD_LINUX
static void reset_topologies(void)
{
    UINT count, radios;
    wifi_hal_capability_t cap;
    for (radios = 1; radios <= MAX_NUM_RADIOS; ++radios) {
        CU_ASSERT_EQUAL_FATAL(wifi_test_reset(radios), 0);
        CU_ASSERT_NOT_EQUAL(wifi_getHalCapability(&cap), 0);
        CU_ASSERT_EQUAL_FATAL(wifi_init(), 0);
        CU_ASSERT_EQUAL_FATAL(test_utils_getMaxNumberOfRadio(&count), 0);
        CU_ASSERT_EQUAL(count, radios);
        CU_ASSERT_EQUAL(wifi_init(), 0);
    }
    CU_ASSERT_NOT_EQUAL(wifi_test_reset(0), 0);
    CU_ASSERT_NOT_EQUAL(wifi_test_reset(MAX_NUM_RADIOS + 1), 0);
    WIFI_PREPARE();
}
#endif

/* PUBLIC_INTERFACE */
/** Register executable generic contract checks. */
int test_wifi_generic_register(void)
{
    static const wifi_test_case_t cases[] = {
        WIFI_CASE(capabilities_and_init),
#ifdef BUILD_LINUX
        WIFI_CASE(reset_topologies),
#endif
    };
    return WIFI_REGISTER("[L1 wifi-generic]", cases);
}
