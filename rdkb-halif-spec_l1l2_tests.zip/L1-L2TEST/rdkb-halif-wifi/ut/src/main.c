#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ut.h>
#include <TestDB.h>
#include "PreReqUtility.h"

extern int register_hal_l1_tests(void);
extern int register_hal_l2_tests(void);
extern void __real_CU_cleanup_registry(void);
static unsigned int failures, suites, tests, errors, suite_failures, records;

static int select_tests(void)
{
    const char *l1 = getenv("UT_TESTS_L1"), *l2 = getenv("UT_TESTS_L2");
    const char *filter = getenv("WIFI_TEST_CASE");
    CU_pTestRegistry registry = CU_get_registry();
    CU_pSuite suite;
    unsigned int selected = 0;
    int explicit_level = l1 || l2;
    if ((l1 && strcmp(l1, "0") && strcmp(l1, "1")) ||
        (l2 && strcmp(l2, "0") && strcmp(l2, "1")) || !registry) return -1;
    for (suite = registry->pSuite; suite; suite = suite->pNext) {
        CU_pTest test;
        int level = !explicit_level ||
                    (l1 && !strcmp(l1, "1") && !strncmp(suite->pName, "[L1 ", 4)) ||
                    (l2 && !strcmp(l2, "1") && !strncmp(suite->pName, "[L2 ", 4));
        unsigned int active = 0;
        for (test = suite->pTest; test; test = test->pNext) {
            int match = level && (!filter || strstr(test->pName, filter));
            if (CU_set_test_active(test, match ? CU_TRUE : CU_FALSE) != CUE_SUCCESS) return -1;
            active += match ? 1u : 0u;
        }
        if (CU_set_suite_active(suite, active ? CU_TRUE : CU_FALSE) != CUE_SUCCESS) return -1;
        selected += active;
    }
    return selected ? 0 : -1;
}

/* PUBLIC_INTERFACE */
/** Capture results before the framework destroys its registry and run summary. */
void __wrap_CU_cleanup_registry(void)
{
    failures = CU_get_number_of_tests_failed();
    suite_failures = CU_get_number_of_suites_failed();
    records = CU_get_number_of_failure_records();
    suites = CU_get_number_of_suites_run();
    tests = CU_get_number_of_tests_run();
    errors = CU_get_error();
    __real_CU_cleanup_registry();
}

#ifdef BUILD_LINUX
static int probe_is(const char *name)
{
    const char *probe = getenv("WIFI_TEST_PROBE");
    return probe && strcmp(probe, name) == 0;
}
static int probe_setup(void) { return probe_is("setup") ? -1 : 0; }
static int probe_cleanup(void) { return probe_is("cleanup") ? -1 : 0; }
static void probe_assertion(void) { CU_ASSERT_FALSE(probe_is("assertion")); }
#endif

/* PUBLIC_INTERFACE */
/** Run native HAL tests; return failure for initialization, selection or test errors. */
int main(int argc, char **argv)
{
    UT_status_t status;
#ifdef BUILD_LINUX
    if (probe_is("init")) {
        fputs("Injected initialization failure\n", stderr);
        return EXIT_FAILURE;
    }
#endif
    if (UT_init(argc, argv) != UT_STATUS_OK) {
        fputs("UT_init failed\n", stderr);
        return EXIT_FAILURE;
    }
    CU_set_fail_on_inactive(CU_FALSE);
    if (register_hal_l1_tests() || register_hal_l2_tests() ||
        CU_get_error() != CUE_SUCCESS) {
        fputs("Test registration failed\n", stderr);
        CU_cleanup_registry();
        return EXIT_FAILURE;
    }
#ifdef BUILD_LINUX
    if (probe_is("registration")) {
        if (UT_add_test(NULL, "invalid registration", probe_assertion) == NULL) {
            CU_cleanup_registry();
            return EXIT_FAILURE;
        }
    }
    if (probe_is("prerequisite") || WiFiPreReq() || l2_test_prerequisite()) {
#else
    if (WiFiPreReq() || l2_test_prerequisite()) {
#endif
        fputs("Wi-Fi prerequisites failed\n", stderr);
        CU_cleanup_registry();
        return EXIT_FAILURE;
    }
#ifdef BUILD_LINUX
    if (getenv("WIFI_TEST_PROBE")) {
        UT_test_suite_t *suite = UT_add_suite("[L1 harness-probe]", probe_setup, probe_cleanup);
        if (!suite || !UT_add_test(suite, "injected probe", probe_assertion)) {
            CU_cleanup_registry();
            return EXIT_FAILURE;
        }
    }
#endif
    if (select_tests()) {
        fputs("Invalid or zero-test selection\n", stderr);
        CU_cleanup_registry();
        return EXIT_FAILURE;
    }
    status = UT_run_tests();
    printf("Wi-Fi result: suites=%u tests=%u failed=%u suite_failures=%u records=%u error=%u\n",
           suites, tests, failures, suite_failures, records, errors);
    return status == UT_STATUS_OK && suites && tests && !failures &&
           !suite_failures && !records && !errors ? EXIT_SUCCESS : EXIT_FAILURE;
}
