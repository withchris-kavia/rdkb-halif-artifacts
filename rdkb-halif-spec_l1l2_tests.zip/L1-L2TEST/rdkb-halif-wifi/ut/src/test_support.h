#ifndef WIFI_TEST_SUPPORT_H
#define WIFI_TEST_SUPPORT_H
#include <stdlib.h>
#include <string.h>
#include <ut.h>
#include "PreReqUtility.h"
#ifdef BUILD_LINUX
#include "wifi_hal_test_backend.h"
#endif

typedef struct {
    const char *name;
    UT_TestFunction_t function;
} wifi_test_case_t;

/* PUBLIC_INTERFACE */
/** Reset Linux model state (including callbacks/faults), then provision checked fixtures. */
int wifi_test_prepare(void);
/* PUBLIC_INTERFACE */
/** Register every case and propagate any suite/test registration failure. */
int wifi_test_register_cases(const char *name, const wifi_test_case_t *cases, size_t count);
/* PUBLIC_INTERFACE */
/** Resolve an AP/STA index from live topology; return -1 if no matching role exists. */
INT wifi_test_index(wifi_vap_mode_t mode, UINT radio);

#define WIFI_CASE(Function) {#Function, Function}
#define WIFI_REGISTER(Name, Cases) \
    wifi_test_register_cases(Name, Cases, sizeof(Cases) / sizeof((Cases)[0]))
#define WIFI_PREPARE() CU_ASSERT_EQUAL_FATAL(wifi_test_prepare(), 0)
#endif
