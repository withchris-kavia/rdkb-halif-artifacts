#include "test_support.h"
#include "config_parser.h"

#ifdef BUILD_LINUX
static UINT scan_events, station_events, steering_events, query_events, response_events, beacon_events;
static UINT event_ap, event_radio, disconnect_reason;
static UCHAR response_token, beacon_token;
static wifi_connection_status_t station_status;
static UINT station_channel;
static wifi_steering_eventType_t steering_type;

static INT scan_complete(wifi_radio_index_t radio, wifi_bss_info_t **bss, UINT *count)
{
    CU_ASSERT_PTR_NOT_NULL_FATAL(bss);
    CU_ASSERT_PTR_NOT_NULL_FATAL(count);
    CU_ASSERT_EQUAL(*count, 1);
    CU_ASSERT_PTR_NOT_NULL(*bss);
    if (*bss) CU_ASSERT_STRING_EQUAL((*bss)->ssid, "reference-neighbor");
    event_radio = radio;
    ++scan_events;
    return 0;
}
static INT station_changed(INT ap, wifi_bss_info_t *bss, wifi_station_stats_t *stats)
{
    CU_ASSERT_PTR_NOT_NULL(bss);
    CU_ASSERT_PTR_NOT_NULL(stats);
    if (stats) {
        station_status = stats->connect_status;
        station_channel = stats->channel;
        CU_ASSERT_EQUAL(stats->vap_index, (UINT)ap);
    }
    event_ap = (UINT)ap;
    ++station_events;
    return 0;
}
static void steering_changed(UINT group, wifi_steering_event_t *event)
{
    CU_ASSERT_EQUAL(group, 0);
    CU_ASSERT_PTR_NOT_NULL_FATAL(event);
    event_ap = event->apIndex;
    steering_type = event->type;
    if (event->type == WIFI_STEERING_EVENT_CLIENT_DISCONNECT)
        disconnect_reason = event->data.disconnect.reason;
    ++steering_events;
}
#ifdef WIFI_HAL_VERSION_3_PHASE2
static INT btm_query(UINT ap, mac_address_t peer, wifi_BTMQuery_t *query,
                     UINT capacity, wifi_BTMRequest_t *request)
#else
static INT btm_query(UINT ap, CHAR *peer, wifi_BTMQuery_t *query,
                     UINT capacity, wifi_BTMRequest_t *request)
#endif
{
    CU_ASSERT_PTR_NOT_NULL(peer);
    CU_ASSERT(capacity >= sizeof(*request));
    CU_ASSERT_PTR_NOT_NULL(query);
    CU_ASSERT_PTR_NOT_NULL(request);
    if (!query || !request || capacity < sizeof(*request)) return -1;
    memset(request, 0, sizeof(*request));
    request->token = query->token;
    event_ap = ap;
    ++query_events;
    return 0;
}
#ifdef WIFI_HAL_VERSION_3_PHASE2
static INT btm_response(UINT ap, mac_address_t peer, wifi_BTMResponse_t *response)
#else
static INT btm_response(UINT ap, CHAR *peer, wifi_BTMResponse_t *response)
#endif
{
    CU_ASSERT_PTR_NOT_NULL(peer);
    CU_ASSERT_PTR_NOT_NULL(response);
    if (!response) return -1;
    event_ap = ap;
    response_token = response->token;
    ++response_events;
    return 0;
}
static INT beacon_report(UINT ap, wifi_BeaconReport_t *report, UINT *count, UCHAR *token)
{
    CU_ASSERT_PTR_NOT_NULL(report);
    CU_ASSERT_PTR_NOT_NULL(count);
    CU_ASSERT_PTR_NOT_NULL(token);
    if (!report || !count || !token) return -1;
    CU_ASSERT_EQUAL(*count, 1);
    CU_ASSERT(report->channel > 0);
    CU_ASSERT_EQUAL(report->rcpi, 90);
    event_ap = ap;
    beacon_token = *token;
    ++beacon_events;
    return 0;
}

static void init_and_topology(void)
{
    UINT r, v, radios, seen = 0;
    wifi_hal_capability_t cap;
    wifi_vap_info_map_t map;
    INT indices[MAX_NUM_RADIOS], type;
    WIFI_PREPARE();
    CU_ASSERT_EQUAL_FATAL(wifi_getHalCapability(&cap), 0);
    radios = cap.wifi_prop.numRadios;
    CU_ASSERT(radios > 0 && radios <= MAX_NUM_RADIOS);
    CU_ASSERT_EQUAL(wifi_init(), 0);
    CU_ASSERT_EQUAL(validate_wifi_config(radios), 0);
    for (r = 0; r < radios; ++r) {
        BOOL ap = FALSE, sta = FALSE;
        CU_ASSERT_EQUAL_FATAL(wifi_getRadioVapInfoMap(r, &map), 0);
        CU_ASSERT_EQUAL(map.num_vaps, MAX_NUM_VAP_PER_RADIO);
        for (v = 0; v < map.num_vaps; ++v) {
            wifi_vap_info_t *vap = &map.vap_array[v];
            CU_ASSERT_EQUAL(vap->radio_index, r);
            CU_ASSERT_FATAL(vap->vap_index < 32);
            CU_ASSERT_EQUAL(seen & (1u << vap->vap_index), 0);
            seen |= 1u << vap->vap_index;
            ap |= vap->vap_mode == wifi_vap_mode_ap;
            sta |= vap->vap_mode == wifi_vap_mode_sta;
        }
        CU_ASSERT_TRUE(ap && sta);
    }
    for (type = PRIVATE; type <= HOTSPOT_SECURE; ++type) {
        CU_ASSERT_EQUAL(test_utils_getApIndices(radios, indices, (APTYPE)type), 0);
        for (r = 0; r < radios; ++r) CU_ASSERT(indices[r] >= 0);
    }
    CU_ASSERT_NOT_EQUAL(validate_wifi_config(0), 0);
}

static void radio_roundtrips_and_restore(void)
{
    UINT r, radios;
    wifi_radio_operationParam_t original, changed, actual;
    WIFI_PREPARE();
    CU_ASSERT_EQUAL_FATAL(test_utils_getMaxNumberOfRadio(&radios), 0);
    for (r = 0; r < radios; ++r) {
        CU_ASSERT_EQUAL_FATAL(wifi_getRadioOperatingParameters(r, &original), 0);
        changed = original;
        changed.enable = FALSE;
        changed.channelWidth = WIFI_CHANNELBANDWIDTH_40MHZ;
        changed.transmitPower = 42;
        changed.countryCode = wifi_countrycode_CA;
        CU_ASSERT_EQUAL(wifi_setRadioOperatingParameters(r, &changed), 0);
        CU_ASSERT_EQUAL(wifi_getRadioOperatingParameters(r, &actual), 0);
        CU_ASSERT_EQUAL(memcmp(&changed, &actual, sizeof(actual)), 0);
        changed.channel = 999;
        CU_ASSERT_NOT_EQUAL(wifi_setRadioOperatingParameters(r, &changed), 0);
        CU_ASSERT_EQUAL(wifi_getRadioOperatingParameters(r, &changed), 0);
        CU_ASSERT_EQUAL(memcmp(&changed, &actual, sizeof(actual)), 0);
        CU_ASSERT_EQUAL(wifi_setRadioOperatingParameters(r, &original), 0);
        CU_ASSERT_EQUAL(wifi_getRadioOperatingParameters(r, &actual), 0);
        CU_ASSERT_EQUAL(memcmp(&original, &actual, sizeof(actual)), 0);
    }
}

static void assert_client_count(INT ap, UINT expected)
{
    wifi_associated_dev3_t *devices = NULL;
    UINT count = 99;
    CU_ASSERT_EQUAL(wifi_getApAssociatedDeviceDiagnosticResult3(ap, &devices, &count), 0);
    CU_ASSERT_EQUAL(count, expected);
    if (expected) {
        CU_ASSERT_PTR_NOT_NULL(devices);
    } else {
        CU_ASSERT_PTR_NULL(devices);
    }
    free(devices);
#ifdef WIFI_HAL_VERSION_3_PHASE2
    {
        mac_address_t clients[1];
        CU_ASSERT_EQUAL(wifi_getApAssociatedDevice(ap, clients, 1, &count), 0);
        CU_ASSERT_EQUAL(count, expected);
    }
#else
    {
        char clients[18];
        CU_ASSERT_EQUAL(wifi_getApAssociatedDevice(ap, clients, sizeof(clients)), 0);
        CU_ASSERT_STRING_EQUAL(clients, expected ? "02:00:00:00:00:01" : "");
    }
#endif
}

static void vap_runtime_lifecycle(void)
{
    /* Maps are about 1 MiB each; refresh these snapshots without nesting large frames. */
    static wifi_vap_info_map_t original, changed, reduced;
    wifi_station_stats_t stats;
    wifi_bss_info_t bss = {0};
    UINT i, ap_slot = 0, sta_slot = 0;
    INT ap, retained = -1, peer, participants[3];
#ifdef WIFI_HAL_VERSION_3_PHASE2
    wifi_BeaconRequest_t request = {0};
    mac_address_t mac = {2, 0, 0, 0, 0, 1};
    UCHAR removed_token = 0, retained_token = 0;
#endif
    WIFI_PREPARE();
    CU_ASSERT_EQUAL_FATAL(wifi_getRadioVapInfoMap(0, &original), 0);
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    peer = wifi_test_index(wifi_vap_mode_ap, 1);
    for (i = 0; i < original.num_vaps; ++i) {
        if (original.vap_array[i].vap_index == (UINT)ap) ap_slot = i;
        else if (original.vap_array[i].vap_mode == wifi_vap_mode_ap)
            retained = (INT)original.vap_array[i].vap_index;
        if (original.vap_array[i].vap_mode == wifi_vap_mode_sta) sta_slot = i;
    }
    CU_ASSERT_FATAL(ap >= 0 && retained >= 0 && peer >= 0);
    CU_ASSERT_EQUAL_FATAL(original.vap_array[sta_slot].vap_mode, wifi_vap_mode_sta);
    participants[0] = ap;
    participants[1] = retained;
    participants[2] = peer;
    for (i = 0; i < 3; ++i) {
        CU_ASSERT_EQUAL(wifi_test_client_event(participants[i], TRUE), 0);
        CU_ASSERT_EQUAL(wifi_BTMQueryRequest_callback_register(
            (UINT)participants[i], btm_query, btm_response), 0);
        CU_ASSERT_EQUAL(wifi_RMBeaconRequestCallbackRegister(
            (UINT)participants[i], beacon_report), 0);
    }
#ifdef WIFI_HAL_VERSION_3_PHASE2
    request.channel = 6;
    CU_ASSERT_EQUAL(wifi_setRMBeaconRequest((UINT)ap, mac, &request, &removed_token), 0);
    CU_ASSERT_EQUAL(wifi_setRMBeaconRequest((UINT)retained, mac, &request, &retained_token), 0);
#endif
    query_events = response_events = beacon_events = 0;
    /* Reordering the map is not a new lifecycle for any retained VAP. */
    changed = original;
    changed.vap_array[0] = original.vap_array[original.num_vaps - 1];
    changed.vap_array[original.num_vaps - 1] = original.vap_array[0];
    CU_ASSERT_EQUAL(wifi_createVAP(0, &changed), 0);
    for (i = 0; i < 3; ++i) assert_client_count(participants[i], 1);

    reduced = original;
    reduced.num_vaps = 0;
    for (i = 0; i < original.num_vaps; ++i)
        if (original.vap_array[i].vap_index != (UINT)ap)
            reduced.vap_array[reduced.num_vaps++] = original.vap_array[i];
    changed = reduced;
    changed.vap_array[0].radio_index = MAX_NUM_RADIOS;
    CU_ASSERT_NOT_EQUAL(wifi_createVAP(0, &changed), 0);
    assert_client_count(ap, 1);
    CU_ASSERT_EQUAL(wifi_test_management_event(ap), 0);
    CU_ASSERT_EQUAL(query_events, 1);
    CU_ASSERT_EQUAL(response_events, 1);
    CU_ASSERT_EQUAL(beacon_events, 1);

    CU_ASSERT_EQUAL(wifi_createVAP(0, &reduced), 0);
    CU_ASSERT_NOT_EQUAL(wifi_test_management_event(ap), 0);
    CU_ASSERT_EQUAL(wifi_createVAP(0, &original), 0);
    assert_client_count(ap, 0);
    assert_client_count(retained, 1);
    assert_client_count(peer, 1);
    CU_ASSERT_EQUAL(wifi_test_management_event(ap), 0);
    CU_ASSERT_EQUAL(query_events, 1);
    CU_ASSERT_EQUAL(response_events, 1);
    CU_ASSERT_EQUAL(beacon_events, 1);
    CU_ASSERT_EQUAL(wifi_test_management_event(retained), 0);
    CU_ASSERT_EQUAL(wifi_test_management_event(peer), 0);
    CU_ASSERT_EQUAL(query_events, 3);
    CU_ASSERT_EQUAL(response_events, 3);
    CU_ASSERT_EQUAL(beacon_events, 3);
#ifdef WIFI_HAL_VERSION_3_PHASE2
    CU_ASSERT_NOT_EQUAL(wifi_cancelRMBeaconRequest((UINT)ap, removed_token), 0);
    CU_ASSERT_EQUAL(wifi_cancelRMBeaconRequest((UINT)retained, retained_token), 0);
#endif
    /* AP -> STA -> AP -> STA must not resurrect client or station runtime. */
    CU_ASSERT_EQUAL(wifi_test_client_event(ap, TRUE), 0);
    changed = original;
    changed.vap_array[ap_slot] = original.vap_array[sta_slot];
    changed.vap_array[ap_slot].vap_index = (UINT)ap;
    CU_ASSERT_EQUAL(wifi_createVAP(0, &changed), 0);
    strcpy(bss.ssid, "lifecycle-bss");
    bss.freq = 2437;
    bss.oper_freq_band = WIFI_FREQUENCY_2_4_BAND;
    bss.oper_chan_bw = WIFI_CHANNELBANDWIDTH_20MHZ;
    CU_ASSERT_EQUAL(wifi_connect(ap, &bss), 0);
    CU_ASSERT_EQUAL(wifi_getStationStats(ap, &stats), 0);
    CU_ASSERT_EQUAL(stats.channel, 6);
    CU_ASSERT_EQUAL(wifi_createVAP(0, &original), 0);
    assert_client_count(ap, 0);
    CU_ASSERT_EQUAL(wifi_createVAP(0, &changed), 0);
    CU_ASSERT_EQUAL(wifi_getStationStats(ap, &stats), 0);
    CU_ASSERT_EQUAL(stats.connect_status, wifi_connection_status_disconnected);
    CU_ASSERT_EQUAL(stats.channel, 0);
    CU_ASSERT_EQUAL(stats.channelWidth, 0);
    CU_ASSERT_EQUAL(wifi_createVAP(0, &original), 0);
    assert_client_count(retained, 1);
    assert_client_count(peer, 1);
}

static void vap_configuration_security_wps(void)
{
    wifi_vap_info_map_t original, changed, actual;
    wifi_vap_security_t security, readback;
    wifi_wps_t wps, result;
    UINT i;
    INT ap;
    WIFI_PREPARE();
    CU_ASSERT_EQUAL_FATAL(wifi_getRadioVapInfoMap(0, &original), 0);
    changed = original;
    for (i = 0; i < changed.num_vaps; ++i) {
        wifi_vap_info_t *vap = &changed.vap_array[i];
        if (vap->vap_mode == wifi_vap_mode_sta) strcpy(vap->u.sta_info.ssid, "changed-station");
        else strcpy(vap->u.bss_info.ssid, "changed-ap");
    }
    CU_ASSERT_EQUAL(wifi_createVAP(0, &changed), 0);
    CU_ASSERT_EQUAL(wifi_getRadioVapInfoMap(0, &actual), 0);
    CU_ASSERT_EQUAL(memcmp(&changed, &actual, sizeof(actual)), 0);
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    CU_ASSERT_EQUAL(wifi_getApSecurity(ap, &security), 0);
    strcpy(security.u.key.key, "changed-security-key");
    CU_ASSERT_EQUAL(wifi_setApSecurity(ap, &security), 0);
    CU_ASSERT_EQUAL(wifi_getApSecurity(ap, &readback), 0);
    CU_ASSERT_EQUAL(memcmp(&security, &readback, sizeof(security)), 0);
    memset(security.u.key.key, 'x', sizeof(security.u.key.key));
    CU_ASSERT_NOT_EQUAL(wifi_setApSecurity(ap, &security), 0);
    CU_ASSERT_EQUAL(wifi_getApWpsConfiguration(ap, &wps), 0);
    wps.enable = TRUE;
    strcpy(wps.pin, "1234");
    CU_ASSERT_EQUAL(wifi_setApWpsConfiguration(ap, &wps), 0);
    CU_ASSERT_EQUAL(wifi_getApWpsConfiguration(ap, &result), 0);
    CU_ASSERT_STRING_EQUAL(result.pin, "1234");
    strcpy(wps.pin, "123");
    CU_ASSERT_NOT_EQUAL(wifi_setApWpsConfiguration(ap, &wps), 0);
    changed.vap_array[1].vap_index = changed.vap_array[0].vap_index;
    CU_ASSERT_NOT_EQUAL(wifi_createVAP(0, &changed), 0);
    CU_ASSERT_EQUAL(wifi_createVAP(0, &original), 0);
    CU_ASSERT_EQUAL(wifi_getRadioVapInfoMap(0, &actual), 0);
    CU_ASSERT_EQUAL(memcmp(&original, &actual, sizeof(actual)), 0);
    vap_runtime_lifecycle();
}

static void station_discover_connect_stats_disconnect(void)
{
    wifi_bss_info_t *bss = NULL;
    wifi_station_stats_t stats;
    wifi_channel_t channel = {.channel = 6, .band = WIFI_FREQUENCY_2_4_BAND};
    UINT count = 0;
    INT sta;
    WIFI_PREPARE();
    sta = wifi_test_index(wifi_vap_mode_sta, 0);
    station_events = 0;
    wifi_staConnectionStatus_callback_register(station_changed);
    CU_ASSERT_EQUAL(wifi_getStationStats(sta, &stats), 0);
    CU_ASSERT_EQUAL(stats.connect_status, wifi_connection_status_disconnected);
    CU_ASSERT_EQUAL(wifi_findNetworks(sta, &channel, &bss, &count), 0);
    CU_ASSERT_EQUAL(count, 1);
    CU_ASSERT_PTR_NOT_NULL(bss);
    if (!bss) return;
    CU_ASSERT_EQUAL(bss->freq, 2437);
    CU_ASSERT_EQUAL(wifi_connect(sta, bss), 0);
    CU_ASSERT_EQUAL(station_events, 1);
    CU_ASSERT_EQUAL(event_ap, (UINT)sta);
    CU_ASSERT_EQUAL(station_status, wifi_connection_status_connected);
    CU_ASSERT_EQUAL(station_channel, 6);
    CU_ASSERT_EQUAL(wifi_getStationStats(sta, &stats), 0);
    CU_ASSERT_EQUAL(stats.channel, 6);
    CU_ASSERT_EQUAL(stats.channelWidth, (UINT)bss->oper_chan_bw);
    CU_ASSERT_EQUAL(stats.connect_status, wifi_connection_status_connected);
    {
        const UINT invalid_freq[] = {0, 2407, 2438, 5220};
        wifi_station_stats_t connected = stats;
        wifi_bss_info_t invalid = *bss;
        size_t i;
        for (i = 0; i < sizeof(invalid_freq) / sizeof(invalid_freq[0]); ++i) {
            invalid.freq = invalid_freq[i];
            CU_ASSERT_NOT_EQUAL(wifi_connect(sta, &invalid), 0);
            CU_ASSERT_EQUAL(station_events, 1);
            CU_ASSERT_EQUAL(wifi_getStationStats(sta, &stats), 0);
            CU_ASSERT_EQUAL(memcmp(&connected, &stats, sizeof(stats)), 0);
        }
    }
    free(bss);
    CU_ASSERT_EQUAL(wifi_disconnect(sta), 0);
    CU_ASSERT_EQUAL(station_events, 2);
    CU_ASSERT_EQUAL(station_status, wifi_connection_status_disconnected);
    CU_ASSERT_EQUAL(wifi_getStationStats(sta, &stats), 0);
    CU_ASSERT_EQUAL(stats.connect_status, wifi_connection_status_disconnected);
    wifi_staConnectionStatus_callback_register(NULL);
    CU_ASSERT_EQUAL(wifi_disconnect(sta), 0);
    CU_ASSERT_EQUAL(station_events, 2);
    {
        const struct { UINT radio; wifi_channel_t channel; UINT frequency; } cases[] = {
            {0, {.channel = 14, .band = WIFI_FREQUENCY_2_4_BAND}, 2484},
            {1, {.channel = 44, .band = WIFI_FREQUENCY_5_BAND}, 5220}
        };
        size_t i;
        for (i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
            wifi_channel_t selected = cases[i].channel;
            sta = wifi_test_index(wifi_vap_mode_sta, cases[i].radio);
            bss = NULL;
            CU_ASSERT_EQUAL(wifi_findNetworks(sta, &selected, &bss, &count), 0);
            CU_ASSERT_EQUAL(count, 1);
            CU_ASSERT_PTR_NOT_NULL(bss);
            if (!bss) continue;
            CU_ASSERT_EQUAL(bss->freq, cases[i].frequency);
            CU_ASSERT_EQUAL(wifi_connect(sta, bss), 0);
            CU_ASSERT_EQUAL(wifi_getStationStats(sta, &stats), 0);
            CU_ASSERT_EQUAL(stats.channel, (UINT)selected.channel);
            CU_ASSERT_EQUAL(wifi_disconnect(sta), 0);
            free(bss);
        }
        CU_ASSERT_EQUAL(station_events, 2);
    }
}

static void declared_scan_callback_completion(void)
{
    UINT channels[] = {1, 6};
    INT ap;
    WIFI_PREPARE();
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    scan_events = 0;
    wifi_scanResults_callback_register(scan_complete);
    CU_ASSERT_NOT_EQUAL(wifi_startNeighborScan(ap, (wifi_neighborScanMode_t)0, 10, 0, channels), 0);
    CU_ASSERT_EQUAL(wifi_startNeighborScan(ap, (wifi_neighborScanMode_t)0, 10, 2, channels), 0);
    CU_ASSERT_EQUAL(scan_events, 0);
    CU_ASSERT_NOT_EQUAL(wifi_startNeighborScan(ap, (wifi_neighborScanMode_t)0, 10, 2, channels), 0);
    CU_ASSERT_EQUAL(wifi_test_dispatch(), 0);
    CU_ASSERT_EQUAL(scan_events, 1);
    CU_ASSERT_EQUAL(event_radio, 0);
    CU_ASSERT_EQUAL(wifi_test_dispatch(), 0);
    CU_ASSERT_EQUAL(scan_events, 1);
    wifi_scanResults_callback_register(NULL);
    CU_ASSERT_EQUAL(wifi_startNeighborScan(ap, (wifi_neighborScanMode_t)0, 10, 2, channels), 0);
    CU_ASSERT_EQUAL(wifi_test_dispatch(), 0);
    CU_ASSERT_EQUAL(scan_events, 1);
}

static void client_steering_btm_rrm_events(void)
{
    wifi_steering_clientConfig_t config = {0};
    mac_address_t peer = {2, 0, 0, 0, 0, 1};
    BOOL active = FALSE;
    INT ap;
    WIFI_PREPARE();
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    steering_events = query_events = response_events = beacon_events = 0;
    CU_ASSERT_EQUAL(wifi_setBandSteeringEnable(TRUE), 0);
    CU_ASSERT_EQUAL(wifi_getBandSteeringEnable(&active), 0);
    CU_ASSERT_TRUE(active);
    CU_ASSERT_EQUAL(wifi_setBSSTransitionActivation((UINT)ap, TRUE), 0);
    CU_ASSERT_EQUAL(wifi_setNeighborReportActivation((UINT)ap, TRUE), 0);
    CU_ASSERT_EQUAL(wifi_steering_eventRegister(steering_changed), 0);
    CU_ASSERT_EQUAL(wifi_steering_clientSet(0, ap, peer, &config), 0);
    assert_client_count(ap, 0);
    CU_ASSERT_EQUAL(wifi_steering_clientMeasure(0, ap, peer), 0);
    CU_ASSERT_EQUAL(steering_events, 1);
    CU_ASSERT_EQUAL(steering_type, WIFI_STEERING_EVENT_RSSI);
    CU_ASSERT_EQUAL(event_ap, (UINT)ap);
    CU_ASSERT_EQUAL(wifi_test_client_event(ap, TRUE), 0);
    CU_ASSERT_EQUAL(wifi_steering_clientRemove(0, ap, peer), 0);
    assert_client_count(ap, 1);
    CU_ASSERT_NOT_EQUAL(wifi_steering_clientMeasure(0, ap, peer), 0);
    CU_ASSERT_EQUAL(wifi_steering_clientSet(0, ap, peer, &config), 0);
    assert_client_count(ap, 1);
    CU_ASSERT_EQUAL(wifi_BTMQueryRequest_callback_register((UINT)ap, btm_query, btm_response), 0);
    CU_ASSERT_EQUAL(wifi_RMBeaconRequestCallbackRegister((UINT)ap, beacon_report), 0);
    CU_ASSERT_EQUAL(wifi_test_management_event(ap), 0);
    CU_ASSERT_EQUAL(query_events, 1);
    CU_ASSERT_EQUAL(response_events, 1);
    CU_ASSERT_EQUAL(response_token, 7);
    CU_ASSERT_EQUAL(beacon_events, 1);
    CU_ASSERT_EQUAL(beacon_token, 0);
#ifdef WIFI_HAL_VERSION_3_PHASE2
    {
        wifi_BTMRequest_t btm = {0};
        wifi_BeaconRequest_t beacon = {0};
        UCHAR token = 0, capabilities[5] = {0};
        btm.token = 21;
        beacon.channel = 1;
        CU_ASSERT_EQUAL(wifi_setBTMRequest((UINT)ap, peer, &btm), 0);
        CU_ASSERT_EQUAL(response_token, 21);
        CU_ASSERT_EQUAL(wifi_setRMBeaconRequest((UINT)ap, peer, &beacon, &token), 0);
        CU_ASSERT(token != 0);
        CU_ASSERT_EQUAL(beacon_token, token);
        CU_ASSERT_EQUAL(wifi_cancelRMBeaconRequest((UINT)ap, token), 0);
        CU_ASSERT_NOT_EQUAL(wifi_cancelRMBeaconRequest((UINT)ap, token), 0);
        CU_ASSERT_EQUAL(wifi_getRMCapabilities(peer, capabilities), 0);
        CU_ASSERT_EQUAL(capabilities[0], 0x70);
    }
#endif
    CU_ASSERT_EQUAL(wifi_steering_clientDisconnect(0, ap, peer, DISCONNECT_TYPE_DEAUTH, 8), 0);
    CU_ASSERT_EQUAL(steering_events, 2);
    CU_ASSERT_EQUAL(steering_type, WIFI_STEERING_EVENT_CLIENT_DISCONNECT);
    CU_ASSERT_EQUAL(disconnect_reason, 8);
    CU_ASSERT_NOT_EQUAL(wifi_steering_clientMeasure(0, ap, peer), 0);
    assert_client_count(ap, 0);
    CU_ASSERT_EQUAL(wifi_steering_eventUnregister(), 0);
    CU_ASSERT_EQUAL(wifi_BTMQueryRequest_callback_register((UINT)ap, NULL, NULL), 0);
    CU_ASSERT_EQUAL(wifi_RMBeaconRequestCallbackUnregister((UINT)ap, beacon_report), 0);
    CU_ASSERT_EQUAL(wifi_test_management_event(ap), 0);
    CU_ASSERT_EQUAL(query_events, 1);
#ifdef WIFI_HAL_VERSION_3_PHASE2
    CU_ASSERT_EQUAL(response_events, 2);
    CU_ASSERT_EQUAL(beacon_events, 2);
#else
    CU_ASSERT_EQUAL(response_events, 1);
    CU_ASSERT_EQUAL(beacon_events, 1);
#endif
}

static void assert_interval_metrics(const wifi_radioTrafficStats2_t *stats, BOOL ready)
{
    if (!ready) {
        CU_ASSERT_EQUAL(stats->radio_ChannelUtilization, (ULONG)-1);
        CU_ASSERT_EQUAL(stats->radio_ActivityFactor, -1);
        CU_ASSERT_EQUAL(stats->radio_CarrierSenseThreshold_Exceeded, -1);
        CU_ASSERT_EQUAL(stats->radio_RetransmissionMetirc, -1);
        CU_ASSERT_EQUAL(stats->radio_MaximumNoiseFloorOnChannel, -1);
        CU_ASSERT_EQUAL(stats->radio_MinimumNoiseFloorOnChannel, -1);
        CU_ASSERT_EQUAL(stats->radio_MedianNoiseFloorOnChannel, -1);
        return;
    }
    CU_ASSERT(stats->radio_ChannelUtilization <= 100);
    CU_ASSERT(stats->radio_ActivityFactor >= 0 && stats->radio_ActivityFactor <= 100);
    CU_ASSERT(stats->radio_CarrierSenseThreshold_Exceeded >= 0 &&
              stats->radio_CarrierSenseThreshold_Exceeded <= 100);
    CU_ASSERT(stats->radio_RetransmissionMetirc >= 0 && stats->radio_RetransmissionMetirc <= 100);
    CU_ASSERT(stats->radio_MinimumNoiseFloorOnChannel >= -110);
    CU_ASSERT(stats->radio_MaximumNoiseFloorOnChannel <= 0);
    CU_ASSERT(stats->radio_MinimumNoiseFloorOnChannel <= stats->radio_MedianNoiseFloorOnChannel);
    CU_ASSERT(stats->radio_MedianNoiseFloorOnChannel <= stats->radio_MaximumNoiseFloorOnChannel);
    CU_ASSERT_NOT_EQUAL(stats->radio_MaximumNoiseFloorOnChannel, -1);
    CU_ASSERT_NOT_EQUAL(stats->radio_MinimumNoiseFloorOnChannel, -1);
    CU_ASSERT_NOT_EQUAL(stats->radio_MedianNoiseFloorOnChannel, -1);
}

static void telemetry_sampling_intervals(void)
{
    wifi_radioTrafficStatsMeasure_t measure = {0};
    wifi_radioTrafficStats2_t initial, first, paused, rolled;
    wifi_radio_operationParam_t op;
    BOOL enabled;
    WIFI_PREPARE();
    measure.radio_RadioStatisticsMeasuringRate = 5;
    measure.radio_RadioStatisticsMeasuringInterval = 20;
    CU_ASSERT_EQUAL(wifi_setRadioTrafficStatsMeasure(0, &measure), 0);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &initial), 0);
    CU_ASSERT_EQUAL(initial.radio_BytesSent, 0);
    assert_interval_metrics(&initial, FALSE);
    wifi_test_advance(4);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &first), 0);
    CU_ASSERT_EQUAL(first.radio_BytesSent, 0);
    assert_interval_metrics(&first, FALSE);
    wifi_test_advance(1);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &first), 0);
    CU_ASSERT_EQUAL(first.radio_BytesSent, 500);
    assert_interval_metrics(&first, FALSE);
    /* Client-detail collection must neither stop nor start radio sampling. */
    CU_ASSERT_EQUAL(wifi_setClientDetailedStatisticsEnable(0, FALSE), 0);
    CU_ASSERT_EQUAL(wifi_getRadioStatsEnable(0, &enabled), 0);
    CU_ASSERT_TRUE(enabled);
    wifi_test_advance(5);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &first), 0);
    CU_ASSERT_EQUAL(first.radio_BytesSent, 1000);
    assert_interval_metrics(&first, FALSE);
    CU_ASSERT_EQUAL(wifi_setRadioStatsEnable(0, FALSE), 0);
    CU_ASSERT_EQUAL(wifi_setClientDetailedStatisticsEnable(0, TRUE), 0);
    CU_ASSERT_EQUAL(wifi_getRadioStatsEnable(0, &enabled), 0);
    CU_ASSERT_FALSE(enabled);
    wifi_test_advance(10);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &paused), 0);
    CU_ASSERT_EQUAL(paused.radio_BytesSent, first.radio_BytesSent);
    assert_interval_metrics(&paused, FALSE);
    CU_ASSERT_EQUAL(wifi_setRadioStatsEnable(0, TRUE), 0);
    wifi_test_advance(10);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &rolled), 0);
    CU_ASSERT_EQUAL(rolled.radio_BytesSent, 0);
    CU_ASSERT(rolled.radio_StatisticsStartTime > initial.radio_StatisticsStartTime);
    assert_interval_metrics(&rolled, TRUE);
    wifi_test_advance(0);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &paused), 0);
    CU_ASSERT_EQUAL(memcmp(&rolled, &paused, sizeof(rolled)), 0);
    wifi_test_advance(20);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &rolled), 0);
    CU_ASSERT_EQUAL(rolled.radio_BytesSent, 0);
    assert_interval_metrics(&rolled, TRUE);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(1, &paused), 0);
    assert_interval_metrics(&paused, FALSE);
    measure.radio_RadioStatisticsMeasuringInterval = 30;
    CU_ASSERT_EQUAL(wifi_setRadioTrafficStatsMeasure(0, &measure), 0);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &first), 0);
    CU_ASSERT_EQUAL(first.radio_BytesSent, 0);
    assert_interval_metrics(&first, FALSE);
    wifi_test_advance(5);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &first), 0);
    CU_ASSERT_EQUAL(first.radio_BytesSent, 500);
    assert_interval_metrics(&first, FALSE);
    wifi_test_advance(25);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &first), 0);
    assert_interval_metrics(&first, TRUE);
    measure.radio_RadioStatisticsMeasuringRate = 0;
    CU_ASSERT_NOT_EQUAL(wifi_setRadioTrafficStatsMeasure(0, &measure), 0);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &paused), 0);
    CU_ASSERT_EQUAL(memcmp(&first, &paused, sizeof(first)), 0);
    CU_ASSERT_EQUAL(wifi_getRadioOperatingParameters(0, &op), 0);
    op.radioStatsMeasuringRate = 6;
    CU_ASSERT_EQUAL(wifi_setRadioOperatingParameters(0, &op), 0);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &first), 0);
    CU_ASSERT_EQUAL(first.radio_BytesSent, 0);
    assert_interval_metrics(&first, FALSE);
    wifi_test_advance(30);
    CU_ASSERT_EQUAL(wifi_getRadioTrafficStats2(0, &first), 0);
    assert_interval_metrics(&first, TRUE);
}

static void isolation_and_error_recovery(void)
{
    wifi_radio_operationParam_t before, after;
    wifi_vap_info_map_t map_before, map_after;
    wifi_bss_info_t *bss = NULL;
    wifi_channel_t channel = {WIFI_FREQUENCY_2_4_BAND, 1};
    INT ap, peer, threshold;
    UINT count = 99;
    ULONG power = 0;
    char name[33], original[33];
    WIFI_PREPARE();
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    peer = wifi_test_index(wifi_vap_mode_ap, 1);
    CU_ASSERT_EQUAL(wifi_getRadioOperatingParameters(1, &before), 0);
    CU_ASSERT_EQUAL(wifi_getRadioVapInfoMap(1, &map_before), 0);
    CU_ASSERT_EQUAL(wifi_getSSIDName(peer, original), 0);
    CU_ASSERT_EQUAL(wifi_setRadioTransmitPower(0, 17), 0);
    CU_ASSERT_EQUAL(wifi_setSSIDName(ap, "isolated-ap"), 0);
    CU_ASSERT_EQUAL(wifi_setBandSteeringRSSIThreshold(0, -70), 0);
    CU_ASSERT_EQUAL(wifi_getBandSteeringRSSIThreshold(1, &threshold), 0);
    CU_ASSERT_EQUAL(threshold, 0);
    CU_ASSERT_EQUAL(wifi_getRadioOperatingParameters(1, &after), 0);
    CU_ASSERT_EQUAL(memcmp(&before, &after, sizeof(after)), 0);
    CU_ASSERT_EQUAL(wifi_getRadioVapInfoMap(1, &map_after), 0);
    CU_ASSERT_EQUAL(memcmp(&map_before, &map_after, sizeof(map_after)), 0);
    CU_ASSERT_EQUAL(wifi_getSSIDName(peer, name), 0);
    CU_ASSERT_STRING_EQUAL(name, original);
    wifi_test_fail_allocation();
    CU_ASSERT_NOT_EQUAL(wifi_getScanResults(0, &channel, &bss, &count), 0);
    CU_ASSERT_PTR_NULL(bss);
    CU_ASSERT_EQUAL(count, 0);
    CU_ASSERT_EQUAL(wifi_getScanResults(0, &channel, &bss, &count), 0);
    CU_ASSERT_EQUAL(count, 1);
    free(bss);
    CU_ASSERT_NOT_EQUAL(wifi_setSSIDName(-1, "invalid"), 0);
    CU_ASSERT_EQUAL(wifi_getSSIDName(ap, name), 0);
    CU_ASSERT_STRING_EQUAL(name, "isolated-ap");
    CU_ASSERT_EQUAL(wifi_test_reset(2), 0);
    CU_ASSERT_EQUAL(wifi_init(), 0);
    CU_ASSERT_EQUAL(wifi_getRadioTransmitPower(0, &power), 0);
    CU_ASSERT_EQUAL(power, 100);
    WIFI_PREPARE();
}
#endif

/* PUBLIC_INTERFACE */
/** Register precisely eight isolated stateful scenarios; private controls are Linux-only. */
int test_wifi_hal_l2_register(void)
{
#ifdef BUILD_LINUX
    static const wifi_test_case_t cases[] = {
        WIFI_CASE(init_and_topology),
        WIFI_CASE(radio_roundtrips_and_restore),
        WIFI_CASE(vap_configuration_security_wps),
        WIFI_CASE(station_discover_connect_stats_disconnect),
        WIFI_CASE(declared_scan_callback_completion),
        WIFI_CASE(client_steering_btm_rrm_events),
        WIFI_CASE(telemetry_sampling_intervals),
        WIFI_CASE(isolation_and_error_recovery)
    };
    return WIFI_REGISTER("[L2 wifi-stateful]", cases);
#else
    /* No fabricated model controls or mock linkage on a real vendor target. */
    return 0;
#endif
}
