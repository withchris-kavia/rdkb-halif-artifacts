#ifndef WIFI_TEST_API_TRANSLATOR_H
#define WIFI_TEST_API_TRANSLATOR_H
/* Tests always use the public HAL ABI, on Linux and on vendor targets alike. */
#include "wifi_hal.h"
#endif
