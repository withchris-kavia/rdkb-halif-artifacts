#include "test_support.h"

/* PUBLIC_INTERFACE */
/** Provision independently reproducible state for each case. */
int wifi_test_prepare(void)
{
#ifdef BUILD_LINUX
    if (wifi_test_reset(2)) return -1;
#endif
    return WiFiPreReq();
}

/* PUBLIC_INTERFACE */
/** Check the result of every individual registration operation. */
int wifi_test_register_cases(const char *name, const wifi_test_case_t *cases, size_t count)
{
    size_t i;
    UT_test_suite_t *suite;
    if (!name || !cases || !count) return -1;
    suite = UT_add_suite(name, NULL, NULL);
    if (!suite) return -1;
    for (i = 0; i < count; ++i)
        if (!UT_add_test(suite, cases[i].name, cases[i].function)) return -1;
    return 0;
}

/* PUBLIC_INTERFACE */
/** Find the first matching live VAP, rather than assuming numeric role indices. */
INT wifi_test_index(wifi_vap_mode_t mode, UINT radio)
{
    wifi_vap_info_map_t map;
    UINT i;
    if (wifi_getRadioVapInfoMap(radio, &map) || map.num_vaps > MAX_NUM_VAP_PER_RADIO)
        return -1;
    for (i = 0; i < map.num_vaps; ++i)
        if (map.vap_array[i].vap_mode == mode) return (INT)map.vap_array[i].vap_index;
    return -1;
}
