extern int test_wifi_generic_register(void);
extern int test_wifi_radio_register(void);
extern int test_wifi_ap_register(void);
extern int test_wifi_sta_register(void);
extern int test_wifi_extender_register(void);
extern int test_wifi_telemetry_register(void);
extern int test_wifi_client_mgt_register(void);
extern int test_wifi_deprecated_register(void);
extern int test_wifi_types_register(void);
extern int test_wifi_hal_l2_register(void);
extern int test_wifi_active_register(void);

/* PUBLIC_INTERFACE */
/** Register all nine L1 modules and Linux reference regressions, checking every result. */
int register_hal_l1_tests(void)
{
    int result = 0;
    result |= test_wifi_generic_register();
    result |= test_wifi_radio_register();
    result |= test_wifi_ap_register();
    result |= test_wifi_sta_register();
    result |= test_wifi_extender_register();
    result |= test_wifi_telemetry_register();
    result |= test_wifi_client_mgt_register();
    result |= test_wifi_deprecated_register();
    result |= test_wifi_types_register();
    result |= test_wifi_active_register();
    return result;
}

/* PUBLIC_INTERFACE */
/** Register the eight independent L2 scenarios. */
int register_hal_l2_tests(void)
{
    return test_wifi_hal_l2_register();
}
