#include "test_support.h"

static void channel_statistics_and_groups(void)
{
    wifi_channelStats_t stats[2] = {{0}};
    wifi_steering_apConfig_t group = {0};
    ULONG channel;
    INT radio = -1, ap, sta;
    WIFI_PREPARE();
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    sta = wifi_test_index(wifi_vap_mode_sta, 0);
    CU_ASSERT_EQUAL(wifi_getSSIDRadioIndex(ap, &radio), 0);
    CU_ASSERT_EQUAL(radio, 0);
    CU_ASSERT_EQUAL(wifi_applySSIDSettings(ap), 0);
    stats[0].ch_number = 1;
    stats[1].ch_number = 6;
    CU_ASSERT_EQUAL(wifi_getRadioChannelStats(0, stats, 2), 0);
    CU_ASSERT_EQUAL(stats[0].ch_number, 1);
    CU_ASSERT(stats[0].ch_utilization <= 100);
    CU_ASSERT_EQUAL(wifi_getRadioChannel(0, &channel), 0);
    stats[0].ch_number = 0;
    CU_ASSERT_EQUAL(wifi_getRadioChannelStats(0, stats, 0), 0);
    CU_ASSERT_EQUAL(stats[0].ch_number, (INT)channel);
    CU_ASSERT_EQUAL(stats[1].ch_number, 6);
    CU_ASSERT_NOT_EQUAL(wifi_getRadioChannelStats(0, stats, -1), 0);
    CU_ASSERT_NOT_EQUAL(wifi_getRadioChannelStats(0, NULL, 0), 0);
    CU_ASSERT_NOT_EQUAL(wifi_getRadioChannelStats(0, NULL, 2), 0);
    group.apIndex = ap;
#ifdef WIFI_HAL_VERSION_3_PHASE2
    CU_ASSERT_EQUAL(wifi_steering_setGroup(0, 1, &group), 0);
    CU_ASSERT_NOT_EQUAL(wifi_steering_setGroup(0, 1, NULL), 0);
    group.apIndex = sta;
    CU_ASSERT_NOT_EQUAL(wifi_steering_setGroup(0, 1, &group), 0);
#else
    CU_ASSERT_EQUAL(wifi_steering_setGroup(0, &group, NULL), 0);
    CU_ASSERT_EQUAL(wifi_steering_setGroup(0, NULL, NULL), 0);
    group.apIndex = sta;
    CU_ASSERT_NOT_EQUAL(wifi_steering_setGroup(0, &group, NULL), 0);
    CU_ASSERT_NOT_EQUAL(wifi_steering_setGroup(0, NULL, &group), 0);
#endif
    CU_ASSERT_NOT_EQUAL(wifi_steering_eventRegister(NULL), 0);
    CU_ASSERT_EQUAL(wifi_steering_eventUnregister(), 0);
}

/* PUBLIC_INTERFACE */
/** Register extender channel-statistics and feature-selected group checks. */
int test_wifi_extender_register(void)
{
    static const wifi_test_case_t cases[] = { WIFI_CASE(channel_statistics_and_groups) };
    return WIFI_REGISTER("[L1 wifi-extender]", cases);
}
