#ifndef WIFI_TEST_UTILS_H
#define WIFI_TEST_UTILS_H
#include <stddef.h>
#include "wifi_hal.h"
#define TEST_WIFI_HAL_VALID_SSID "test@1234"
typedef enum { PRIVATE, STA, IOT, BACKHAUL, LNF_PSK, LNF_RADIUS, HOTSPOT_OPEN, HOTSPOT_SECURE } APTYPE;
extern wifi_radio_operationParam_t g_operationParam[MAX_NUM_RADIOS];
extern wifi_vap_info_map_t g_org_map[MAX_NUM_RADIOS];
/* PUBLIC_INTERFACE */
/** Return a checked nonzero radio count. */
INT test_utils_getMaxNumberOfRadio(UINT *radios);
/* PUBLIC_INTERFACE */
/** Resolve one named-role VAP per radio using live maps; capacity is radios. */
INT test_utils_getApIndices(UINT radios, INT indices[], APTYPE type);
/* PUBLIC_INTERFACE */
/** Snapshot topology only after validating all prerequisite HAL results. */
INT l2_test_prerequisite(void);
/* PUBLIC_INTERFACE */
/** Enumerate unique channels with explicit capacity; reset count on errors. */
INT get_channel_list(int radio, size_t *count, int *channels, size_t capacity);
/* PUBLIC_INTERFACE */
/** Enumerate unique bandwidth enum values, not MHz integers, with explicit capacity. */
INT get_channel_bandwidth(int radio, size_t *count, wifi_channelBandwidth_t *widths, size_t capacity);
/* PUBLIC_INTERFACE */
/** Exercise and restore a valid SSID mutation. */
INT test_utils_setValidSSID(INT radio, INT ap, INT position);
/* PUBLIC_INTERFACE */
/** Verify that invalid VAP indices are rejected without modifying live state. */
INT test_utils_setInValidIndexSSID(INT radio, INT ap, INT position);
/* PUBLIC_INTERFACE */
/** Verify that NULL SSIDs are rejected. */
INT test_utils_setNULLSSID(INT radio, INT ap, INT position);
#endif
