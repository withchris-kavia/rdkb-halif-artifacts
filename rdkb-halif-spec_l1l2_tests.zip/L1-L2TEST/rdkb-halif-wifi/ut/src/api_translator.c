#include "api_translator.h"
/* Intentionally empty: no public HAL symbol is redirected or bypassed. */
