/* Linux reference regressions. Also compiled standalone by tests/verify_public_api.py. */
#ifdef BUILD_LINUX
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "wifi_hal_test_backend.h"
#ifdef WIFI_ACTIVE_STANDALONE
static unsigned checks, failures;
#define CHECK(Expr) do { ++checks; if (!(Expr)) { ++failures; \
    fprintf(stderr, "%s:%d: %s\n", __func__, __LINE__, #Expr); } } while (0)
#else
#include "test_support.h"
#define CHECK(Expr) CU_ASSERT(Expr)
#endif
#define OK(Call) CHECK((Call) == WIFI_HAL_SUCCESS)
#define BAD(Call) CHECK((Call) != WIFI_HAL_SUCCESS)
#define UNSUPPORTED(Call) CHECK((Call) == WIFI_HAL_UNSUPPORTED)

static void prepare(UINT radios)
{
    OK(wifi_test_reset(radios));
    OK(wifi_init());
}
static INT index_for(UINT radio, wifi_vap_mode_t role)
{
    UINT i;
    static wifi_vap_info_map_t map;
    if (wifi_getRadioVapInfoMap(radio, &map)) return -1;
    for (i = 0; i < map.num_vaps; ++i)
        if (map.vap_array[i].vap_mode == role) return (INT)map.vap_array[i].vap_index;
    return -1;
}

static void nonassociated_station_measurement(void)
{
    const UINT classes[] = {81, 115, 131}, channels[] = {11, 48, 9};
    wifi_na_sta_req_params_t request = {0}, saved;
    wifi_na_sta_info_t out, before;
    wifi_associated_dev2_t *devices = NULL;
    wifi_sta_capability_t capability;
    UINT radio, count;
    INT ap, sta;
    prepare(MAX_NUM_RADIOS);
    request.sta_mac[0] = 2;
    request.sta_mac[5] = 7;
    for (radio = 0; radio < MAX_NUM_RADIOS; ++radio) {
        ap = index_for(radio, wifi_vap_mode_ap);
        sta = index_for(radio, wifi_vap_mode_sta);
        CHECK(ap >= 0 && sta >= 0);
        OK(wifi_getStationCapability(sta, &capability));
        BAD(wifi_getStationCapability(ap, &capability));
        BAD(wifi_getStationCapability(sta, NULL));
        request.op_class = classes[radio];
        request.channel = channels[radio];
        saved = request;
        memset(&out, 0xa5, sizeof(out));
        OK(wifi_getNASta(ap, &request, &out));
        CHECK(!memcmp(request.sta_mac, out.sta_mac, 6));
        CHECK(out.op_class == request.op_class && out.channel == request.channel);
        CHECK(out.rcpi == 130 && out.rcpi <= 220);
        CHECK(!memcmp(&request, &saved, sizeof(request)));
        before = out;
        BAD(wifi_getNASta(-1, &request, &out));
        BAD(wifi_getNASta(sta, &request, &out));
        BAD(wifi_getNASta(ap, NULL, &out));
        BAD(wifi_getNASta(ap, &request, NULL));
        CHECK(!memcmp(&out, &before, sizeof(out)));
        request.channel = 0;
        UNSUPPORTED(wifi_getNASta(ap, &request, &out));
        request = saved;
        ++request.op_class;
        UNSUPPORTED(wifi_getNASta(ap, &request, &out));
        request = saved;
        request.sta_mac[0] = 3;
        BAD(wifi_getNASta(ap, &request, &out));
        memset(request.sta_mac, 0, 6);
        BAD(wifi_getNASta(ap, &request, &out));
        request = saved;
        OK(wifi_setApEnable(ap, FALSE));
        CHECK(wifi_getNASta(ap, &request, &out) == WIFI_HAL_NOT_READY);
        OK(wifi_setApEnable(ap, TRUE));
        OK(wifi_setRadioEnable((INT)radio, FALSE));
        CHECK(wifi_getNASta(ap, &request, &out) == WIFI_HAL_NOT_READY);
        OK(wifi_setRadioEnable((INT)radio, TRUE));
        CHECK(!memcmp(&out, &before, sizeof(out)));
        OK(wifi_test_client_event(ap, TRUE));
        memcpy(request.sta_mac, wifi_test_state.client[ap], 6);
        BAD(wifi_getNASta(ap, &request, &out));
        request = saved;
        /* A measurement must neither allocate nor consume a queued allocation fault. */
        wifi_test_fail_allocation();
        OK(wifi_getNASta(ap, &request, &out));
        count = 99;
        CHECK(wifi_getApAssociatedDeviceDiagnosticResult2(ap, &devices, &count) == WIFI_HAL_ERROR);
        CHECK(devices == NULL && count == 0);
        OK(wifi_getApAssociatedDeviceDiagnosticResult2(ap, &devices, &count));
        CHECK(devices != NULL && count == 1);
        free(devices);
        devices = NULL;
        OK(wifi_test_client_event(ap, FALSE));
    }
}

/* These macros check round-trip, isolation, pointer/index validation and atomic rejection. */
#define RADIO_PAIR(Get, Set, Type, Value, Invalid) do { \
    Type old, peer, got = (Type)0; \
    OK(Get(0, &old)); OK(Get(1, &peer)); \
    OK(Set(0, (Type)(Value))); OK(Get(0, &got)); CHECK(got == (Type)(Value)); \
    BAD(Set(0, (Type)(Invalid))); OK(Get(0, &got)); CHECK(got == (Type)(Value)); \
    BAD(Get(-1, &got)); BAD(Get(0, NULL)); BAD(Set(-1, (Type)(Value))); \
    OK(Get(1, &got)); CHECK(got == peer); OK(Set(0, old)); \
} while (0)
#define RADIO_FLAG(Get, Set) RADIO_PAIR(Get, Set, BOOL, TRUE, 2)

static void radio_setting_adapters(void)
{
    INT range[2], count, i;
    UCHAR colors[63];
    ULONG ticks, resets;
    BOOL enabled, precac;
    wifi_edca_t edca;
    wifi_80211ax_params_t ax;
    wifi_radioTemperature_t temperature;
    prepare(2);
    RADIO_FLAG(wifi_getRadioDfsEnable, wifi_setRadioDfsEnable);
    RADIO_FLAG(wifi_getRadioDfsAtBootUpEnable, wifi_setRadioDfsAtBootUpEnable);
    RADIO_FLAG(wifi_getRadioAMSDUEnable, wifi_setRadioAMSDUEnable);
    RADIO_FLAG(wifi_getRadioAutoBlockAckEnable, wifi_setRadioAutoBlockAckEnable);
    RADIO_FLAG(wifi_getRadioIGMPSnoopingEnable, wifi_setRadioIGMPSnoopingEnable);
    RADIO_FLAG(wifi_getRadioAutoChannelEnable, wifi_setRadioAutoChannelEnable);
    RADIO_FLAG(wifi_getRadioDCSEnable, wifi_setRadioDCSEnable);
    RADIO_FLAG(wifi_getRadioReverseDirectionGrantEnable, wifi_setRadioReverseDirectionGrantEnable);
    RADIO_FLAG(wifi_getRadioDeclineBARequestEnable, wifi_setRadioDeclineBARequestEnable);
    RADIO_FLAG(wifi_getRadio11nGreenfieldEnable, wifi_setRadio11nGreenfieldEnable);
    RADIO_FLAG(wifi_getRadioIEEE80211hEnabled, wifi_setRadioIEEE80211hEnabled);
    RADIO_FLAG(wifi_getRadioDcsScanning, wifi_setRadioDcsScanning);
    RADIO_FLAG(wifi_getBSSColorEnabled, wifi_setBSSColorEnabled);
    RADIO_PAIR(wifi_getRadioMCS, wifi_setRadioMCS, INT, 7, 12);
    RADIO_PAIR(wifi_getRadioCarrierSenseThresholdInUse, wifi_setRadioCarrierSenseThresholdInUse, INT, -80, 1);
    RADIO_PAIR(wifi_getDownlinkMuType, wifi_setDownlinkMuType, wifi_dl_mu_type_t, WIFI_DL_MU_TYPE_MIMO, 999);
    RADIO_PAIR(wifi_getUplinkMuType, wifi_setUplinkMuType, wifi_ul_mu_type_t, WIFI_UL_MU_TYPE_OFDMA, 999);
    RADIO_PAIR(wifi_getGuardInterval, wifi_setGuardInterval, wifi_guard_interval_t, wifi_guard_interval_800, 999);
    RADIO_PAIR(wifi_getBSSColor, wifi_setBSSColor, UCHAR, 3, 64);
    RADIO_PAIR(wifi_getRadioAutoChannelRefreshPeriod, wifi_setRadioAutoChannelRefreshPeriod, ULONG, 77, (ULONG)-1);
    RADIO_PAIR(wifi_getRadioBeaconPeriod, wifi_setRadioBeaconPeriod, UINT, 200, 14);
    OK(wifi_setRadioTxChainMask(0, 2));
    OK(wifi_getRadioTxChainMask(0, &i)); CHECK(i == 2);
    BAD(wifi_setRadioTxChainMask(0, 5));
    OK(wifi_setRadioRxChainMask(0, 3));
    OK(wifi_getRadioRxChainMask(0, &i)); CHECK(i == 3);
    BAD(wifi_setRadioRxChainMask(0, 0));
    OK(wifi_setRadioDcsDwelltime(0, 10));
    OK(wifi_getRadioDcsDwelltime(0, &i)); CHECK(i == 10);
    BAD(wifi_setRadioDcsDwelltime(0, 1001));
    OK(wifi_setRadioCtsProtectionEnable(0, TRUE)); BAD(wifi_setRadioCtsProtectionEnable(0, 2));
    OK(wifi_setRadioObssCoexistenceEnable(0, TRUE)); BAD(wifi_setRadioObssCoexistenceEnable(0, 2));
    OK(wifi_setRadioSTBCEnable(0, TRUE)); BAD(wifi_setRadioSTBCEnable(0, 2));
    OK(wifi_setRadioFragmentationThreshold(0, 1000)); BAD(wifi_setRadioFragmentationThreshold(0, 255));
    OK(wifi_getRadioCarrierSenseThresholdRange(0, range));
    CHECK(range[0] == -110 && range[1] == 0);
    BAD(wifi_getRadioCarrierSenseThresholdRange(0, NULL));
    OK(wifi_getRadioStatus(0, &enabled)); CHECK(enabled);
    OK(wifi_getRadioPercentageTransmitPower(0, &ticks)); CHECK(ticks == 100);
    OK(wifi_setBSSColor(0, 3));
    OK(wifi_getAvailableBSSColor(0, 63, colors, &count)); CHECK(count == 62);
    for (i = 0; i < count; ++i) CHECK(colors[i] >= 1 && colors[i] <= 63 && colors[i] != 3);
    BAD(wifi_getAvailableBSSColor(0, 64, colors, &count));
    OK(wifi_getAvailableBSSColor(0, 0, NULL, &count)); CHECK(count == 0);
    UNSUPPORTED(wifi_getMuEdca(0, (wifi_access_category_t)0, &edca));
    BAD(wifi_getMuEdca(0, (wifi_access_category_t)4, &edca));
    UNSUPPORTED(wifi_setDownlinkDataAckType(0, (wifi_dl_data_ack_type_t)0));
    OK(wifi_get80211axDefaultParameters(0, &ax));
    OK(wifi_hal_getRadioTemperature(0, &temperature)); CHECK(temperature.radio_Temperature == 40);
    BAD(wifi_hal_getRadioTemperature(99, &temperature));
    OK(wifi_setZeroDFSState(0, FALSE, FALSE));
    UNSUPPORTED(wifi_setZeroDFSState(0, TRUE, FALSE));
    OK(wifi_getZeroDFSState(0, &enabled, &precac)); CHECK(!enabled && !precac);
    OK(wifi_isZeroDFSSupported(0, &enabled)); CHECK(!enabled);
    OK(wifi_getRadioUpTime(0, &ticks)); CHECK(ticks == 0);
    wifi_test_advance(5);
    OK(wifi_getRadioUpTime(0, &ticks)); CHECK(ticks == 5);
    OK(wifi_factoryResetRadio(0));
    OK(wifi_getRadioResetCount(0, &resets)); CHECK(resets == 1);
    OK(wifi_factoryResetRadios());
    OK(wifi_getRadioResetCount(0, &resets)); CHECK(resets == 2);
    OK(wifi_getRadioResetCount(1, &resets)); CHECK(resets == 1);
}

#define TEXT_QUERY(Get) do { \
    CHAR text[512] = {0}; OK(Get(0, text)); CHECK(text[0]); \
    BAD(Get(-1, text)); BAD(Get(0, NULL)); \
} while (0)
#define TEXT_PAIR(Get, Set, Value) do { \
    CHAR text[512], large[513]; memset(large, 'x', sizeof(large) - 1); large[512] = 0; \
    OK(Set(0, Value)); OK(Get(0, text)); CHECK(!strcmp(text, Value)); \
    BAD(Set(0, large)); OK(Get(0, text)); CHECK(!strcmp(text, Value)); BAD(Set(0, NULL)); \
} while (0)
#define RADIO_CAP(Get) do { BOOL yes = FALSE; OK(Get(0, &yes)); CHECK(yes); BAD(Get(0, NULL)); } while (0)

static void radio_legacy_adapters(void)
{
    CHAR text[512];
    BOOL g, n, ac;
    ULONG count, channel;
    UINT pure;
    INT interval, dwell, signal;
    wifi_channelMap_t channels[16];
    prepare(2);
    TEXT_QUERY(wifi_getRadioIfName);
    TEXT_QUERY(wifi_getRadioMaxBitRate);
    TEXT_QUERY(wifi_getRadioSupportedStandards);
    TEXT_QUERY(wifi_getRadioTransmitPowerSupported);
    TEXT_QUERY(wifi_getRadioSupportedDataTransmitRates);
    TEXT_QUERY(wifi_getRadioSupportedFrequencyBands);
    TEXT_QUERY(wifi_getRadioOperatingFrequencyBand);
    TEXT_QUERY(wifi_getRadioPossibleChannels);
    TEXT_PAIR(wifi_getRadioDCSChannelPool, wifi_setRadioDCSChannelPool, "1,6,11");
    TEXT_PAIR(wifi_getRadioExtChannel, wifi_setRadioExtChannel, "Auto");
    TEXT_PAIR(wifi_getRadioBasicDataTransmitRates, wifi_setRadioBasicDataTransmitRates, "1,2");
    TEXT_PAIR(wifi_getRadioOperationalDataTransmitRates, wifi_setRadioOperationalDataTransmitRates, "6,12");
    RADIO_CAP(wifi_getRadioAutoChannelSupported);
    RADIO_CAP(wifi_getRadioDCSSupported);
    RADIO_CAP(wifi_getRadioDfsSupport);
    RADIO_CAP(wifi_getRadioAutoChannelRefreshPeriodSupported);
    RADIO_CAP(wifi_getRadioIEEE80211hSupported);
    RADIO_CAP(wifi_getRadio11nGreenfieldSupported);
    RADIO_CAP(wifi_getRadioReverseDirectionGrantSupported);
    OK(wifi_getHalVersion(text)); CHECK(text[0]); BAD(wifi_getHalVersion(NULL));
    OK(wifi_getRadioNumberOfEntries(&count)); CHECK(count == 2);
    OK(wifi_getSSIDNumberOfEntries(&count)); CHECK(count == 16);
    OK(wifi_pushCountryCode("GB"));
    OK(wifi_getRadioCountryCode(1, text)); CHECK(!strcmp(text, "GB"));
    BAD(wifi_pushCountryCode("ZZ"));
    OK(wifi_pushRadioChannel(0, 6));
    OK(wifi_getRadioChannel(0, &channel)); CHECK(channel == 6);
    BAD(wifi_setRadioChannel(0, 500));
    OK(wifi_pushRadioChannel2(1, 44, 80, 2));
#ifdef WIFI_HAL_VERSION_3_PHASE2
    {
        wifi_channels_list_t list;
        OK(wifi_getRadioChannelsInUse(1, &list));
        CHECK(list.num_channels == 1 && list.channels_list[0] == 44);
    }
#else
    OK(wifi_getRadioChannelsInUse(1, text)); CHECK(!strcmp(text, "44"));
#endif
    OK(wifi_setRadioMode(0, "g", 0));
    OK(wifi_getRadioStandard(0, text, &g, &n, &ac)); CHECK(g && !n && !ac && !strcmp(text, "g"));
    OK(wifi_setRadioChannelMode(0, "ax", FALSE, TRUE, FALSE));
    OK(wifi_getRadioMode(0, text, &pure)); CHECK(!strcmp(text, "n") && pure == 0);
    BAD(wifi_setRadioChannelMode(0, "n", TRUE, TRUE, FALSE));
    UNSUPPORTED(wifi_setRadioMode(0, "n", 1));
    OK(wifi_pushRadioChannelMode(0)); OK(wifi_pushRadioTxChainMask(0)); OK(wifi_pushRadioRxChainMask(0));
    OK(wifi_applyRadioSettings(0)); BAD(wifi_applyRadioSettings(-1));
    OK(wifi_setRadioGuardInterval(0, "1600nsec"));
    OK(wifi_getRadioGuardInterval(0, text)); CHECK(!strcmp(text, "1600nsec"));
    BAD(wifi_setRadioGuardInterval(0, "1600"));
    OK(wifi_setRadioDCSScanTime(0, 30, 40));
    BAD(wifi_setRadioDCSScanTime(0, 10, 1001));
    OK(wifi_getRadioDCSScanTime(0, &interval, &dwell)); CHECK(interval == 30 && dwell == 40);
    OK(wifi_getRadioStatsReceivedSignalLevel(0, 0, &signal)); CHECK(signal == -45);
    BAD(wifi_getRadioStatsReceivedSignalLevel(0, 1, &signal));
    OK(wifi_getRadioClientInactivityTimout(0, &signal)); CHECK(signal == 300);
    OK(wifi_getRadioChannels(1, channels, 16)); CHECK(channels[0].ch_number == 36);
    BAD(wifi_getRadioChannels(1, channels, 1));
}

#define AP_PAIR(Get, Set, Type, Value, Invalid) do { \
    Type peer, got = (Type)0; OK(Get(other, &peer)); \
    OK(Set(ap, (Type)(Value))); OK(Get(ap, &got)); CHECK(got == (Type)(Value)); \
    BAD(Set(ap, (Type)(Invalid))); OK(Get(ap, &got)); CHECK(got == (Type)(Value)); \
    BAD(Get(sta, &got)); BAD(Get(ap, NULL)); BAD(Set(sta, (Type)(Value))); \
    OK(Get(other, &got)); CHECK(got == peer); \
} while (0)
#define AP_FLAG(Get, Set) AP_PAIR(Get, Set, BOOL, TRUE, 2)
#define AP_CAP(Get) do { BOOL yes = FALSE; OK(Get(ap, &yes)); CHECK(yes); BAD(Get(sta, &yes)); } while (0)

static void ap_setting_adapters(void)
{
    INT ap, other, sta, radio, lookup;
    UINT number, twt_count;
    ULONG associated, pin;
    BOOL enabled;
    CHAR name[64], text[256], ip[46], mask[46];
    wifi_ap_capabilities_t caps;
    wifi_twt_params_t params = {0};
    wifi_InterworkingElement_t interworking = {0}, read_interworking;
    wifi_roamingConsortiumElement_t consortium = {0}, read_consortium;
    wifi_radius_setting_t tuning = {0}, read_tuning;
    prepare(2);
    ap = index_for(0, wifi_vap_mode_ap); other = index_for(1, wifi_vap_mode_ap);
    sta = index_for(0, wifi_vap_mode_sta);
    AP_FLAG(wifi_getApEnable, wifi_setApEnable);
    AP_FLAG(wifi_getApSsidAdvertisementEnable, wifi_setApSsidAdvertisementEnable);
    AP_FLAG(wifi_getApWmmEnable, wifi_setApWmmEnable);
    AP_FLAG(wifi_getApWmmUapsdEnable, wifi_setApWmmUapsdEnable);
    AP_FLAG(wifi_getApIsolationEnable, wifi_setApIsolationEnable);
    AP_FLAG(wifi_getApInterworkingServiceEnable, wifi_setApInterworkingServiceEnable);
    AP_FLAG(wifi_getCountryIe, wifi_setCountryIe);
    AP_FLAG(wifi_getLayer2TrafficInspectionFiltering, wifi_setLayer2TrafficInspectionFiltering);
    AP_FLAG(wifi_getDownStreamGroupAddress, wifi_setDownStreamGroupAddress);
    AP_FLAG(wifi_getBssLoad, wifi_setBssLoad);
    AP_FLAG(wifi_getProxyArp, wifi_setProxyArp);
    AP_FLAG(wifi_getApHotspotElement, wifi_pushApHotspotElement);
    AP_FLAG(wifi_getP2PCrossConnect, wifi_setP2PCrossConnect);
    AP_FLAG(wifi_getApWpsEnable, wifi_setApWpsEnable);
    AP_PAIR(wifi_getApRetryLimit, wifi_setApRetryLimit, UINT, 17, 256);
    AP_PAIR(wifi_getApMaxAssociatedDevices, wifi_setApMaxAssociatedDevices, UINT, 64, 513);
    AP_PAIR(wifi_getApManagementFramePowerControl, wifi_setApManagementFramePowerControl, INT, -10, 1);
    AP_PAIR(wifi_getApMacAddressControlMode, wifi_setApMacAddressControlMode, INT, 2, 3);
    AP_PAIR(wifi_getApAssociatedDevicesHighWatermarkThreshold,
            wifi_setApAssociatedDevicesHighWatermarkThreshold, UINT, 1, 513);
    OK(wifi_setInterworkingAccessNetworkType(ap, 14));
    OK(wifi_getInterworkingAccessNetworkType(ap, &number)); CHECK(number == 14);
    BAD(wifi_setInterworkingAccessNetworkType(ap, 13));
    AP_CAP(wifi_getApRtsThresholdSupported); AP_CAP(wifi_getApWMMCapability);
    AP_CAP(wifi_getApUAPSDCapability); AP_CAP(wifi_getApInterworkingServiceCapability);
    OK(wifi_getAPCapabilities(ap, &caps)); CHECK(caps.WMMSupported && caps.BSSTransitionImplemented);
    OK(wifi_getApName(ap, name));
    OK(wifi_getApIndexFromName(name, &lookup)); CHECK(lookup == ap);
    OK(wifi_getApRadioIndex(ap, &radio)); CHECK(radio == 0);
    OK(wifi_getApStatus(ap, text)); CHECK(!strcmp(text, "Enabled"));
    OK(wifi_setSSIDEnable(sta, FALSE)); OK(wifi_getSSIDEnable(sta, &enabled)); CHECK(!enabled);
    OK(wifi_getSSIDStatus(sta, text)); CHECK(!strcmp(text, "Down"));
    OK(wifi_getSSIDNameStatus(sta, text)); CHECK(!strcmp(text, "Down"));
    OK(wifi_getSSIDMACAddress(sta, text)); CHECK(strlen(text) == 17);
    OK(wifi_getBaseBSSID(ap, text)); CHECK(strlen(text) == 17);
    OK(wifi_pushSSID(ap, "adapter-ssid"));
    OK(wifi_getSSIDName(ap, text)); CHECK(!strcmp(text, "adapter-ssid"));
    OK(wifi_pushSsidAdvertisementEnable(ap, TRUE));
    OK(wifi_pushApSsidAdvertisementEnable(ap, FALSE));
    OK(wifi_pushApEnable(ap, FALSE)); OK(wifi_getApEnable(ap, &enabled)); CHECK(!enabled);
    OK(wifi_pushApEnable(ap, TRUE));
    OK(wifi_setApRadioIndex(ap, 0)); UNSUPPORTED(wifi_setApRadioIndex(ap, 1));
    OK(wifi_setApRtsThreshold(ap, 1000)); BAD(wifi_setApRtsThreshold(ap, 2348));
    OK(wifi_setApDTIMInterval(ap, 2)); BAD(wifi_setApDTIMInterval(ap, 0));
    OK(wifi_setApBeaconInterval(ap, 150)); BAD(wifi_setApBeaconInterval(ap, 1));
    OK(wifi_setApVlanID(ap, 100)); BAD(wifi_setApVlanID(ap, 4095));
    OK(wifi_setApVlanEnable(ap, TRUE)); OK(wifi_resetApVlanCfg(ap));
    OK(wifi_setApWmmOgAckPolicy(ap, 3, TRUE)); BAD(wifi_setApWmmOgAckPolicy(ap, 4, TRUE));
    OK(wifi_setApBeaconRate(ap, "6Mbps")); BAD(wifi_setApBeaconRate(ap, "6"));
    OK(wifi_getApBeaconRate(ap, text)); CHECK(!strcmp(text, "6Mbps"));
    OK(wifi_setApSecurityMFPConfig(ap, "Optional")); BAD(wifi_setApSecurityMFPConfig(ap, "optional"));
    OK(wifi_getApSecurityMFPConfig(ap, text)); CHECK(!strcmp(text, "Optional"));
    OK(wifi_setApSecurityRadiusSettings(ap, &tuning));
    OK(wifi_getApSecurityRadiusSettings(ap, &read_tuning));
    CHECK(!memcmp(&tuning, &read_tuning, sizeof(tuning)));
    interworking.interworkingEnabled = TRUE; interworking.accessNetworkType = 2;
    OK(wifi_pushApInterworkingElement(ap, &interworking));
    interworking.internetAvailable = 2; BAD(wifi_pushApInterworkingElement(ap, &interworking));
    OK(wifi_getApInterworkingElement(ap, &read_interworking));
    CHECK(read_interworking.internetAvailable == FALSE && read_interworking.accessNetworkType == 2);
    consortium.wifiRoamingConsortiumCount = 1; consortium.wifiRoamingConsortiumLen[0] = 3;
    OK(wifi_pushApRoamingConsortiumElement(ap, &consortium));
    consortium.wifiRoamingConsortiumCount = 4; BAD(wifi_pushApRoamingConsortiumElement(ap, &consortium));
    OK(wifi_getApRoamingConsortiumElement(ap, &read_consortium));
    CHECK(read_consortium.wifiRoamingConsortiumCount == 1);
    OK(wifi_setApBridgeInfo(ap, "br-test", "192.0.2.1", "255.255.255.0"));
    BAD(wifi_setApBridgeInfo(ap, "br-bad", "bad", "255.255.255.0"));
    OK(wifi_getApBridgeInfo(ap, name, ip, mask)); CHECK(!strcmp(name, "br-test"));
    CHECK(!strcmp(ip, "192.0.2.1") && !strcmp(mask, "255.255.255.0"));
    OK(wifi_pushBridgeInfo(ap));
    OK(wifi_setApWpsConfigMethodsEnabled(ap, "PIN"));
    OK(wifi_getApWpsConfigMethodsEnabled(ap, text)); CHECK(!strcmp(text, "PIN"));
    OK(wifi_getApWpsConfigMethodsSupported(ap, text)); CHECK(strstr(text, "PIN") != NULL);
    OK(wifi_setApWpsDevicePIN(ap, 12345670));
    OK(wifi_getApWpsDevicePIN(ap, &pin)); CHECK(pin == 12345670);
    OK(wifi_getApWpsConfigurationState(ap, text)); CHECK(!strcmp(text, "Configured"));
    UNSUPPORTED(wifi_setApWpsEnrolleePin(ap, "1234")); BAD(wifi_setApWpsEnrolleePin(ap, "abcd"));
    UNSUPPORTED(wifi_setApWpsButtonPush(ap)); OK(wifi_cancelApWPS(ap));
    OK(wifi_test_client_event(ap, TRUE));
    OK(wifi_getApNumDevicesAssociated(ap, &associated)); CHECK(associated == 1);
    OK(wifi_getApAssociatedDevicesHighWatermark(ap, &number)); CHECK(number == 1);
    OK(wifi_getApAssociatedDevicesHighWatermarkThresholdReached(ap, &number)); CHECK(number == 1);
    OK(wifi_getApAssociatedDevicesHighWatermarkDate(ap, &associated)); CHECK(associated > 0);
    OK(wifi_getTWTsessions(ap, 0, NULL, &twt_count)); CHECK(twt_count == 0);
    radio = 999;
    UNSUPPORTED(wifi_setBroadcastTWTSchedule(ap, params, TRUE, &radio)); CHECK(radio == 999);
    UNSUPPORTED(wifi_setTeardownTWTSession(ap, 0));
    OK(wifi_factoryResetAP(ap));
    OK(wifi_getApNumDevicesAssociated(ap, &associated)); CHECK(associated == 0);
    OK(wifi_getApAssociatedDevicesHighWatermark(ap, &number)); CHECK(number == 0);
    OK(wifi_deleteAp(ap)); BAD(wifi_getApName(ap, name));
    OK(wifi_createAp(ap, 0, "recreated", FALSE));
    OK(wifi_getSSIDName(ap, text)); CHECK(!strcmp(text, "recreated"));
}

static void security_and_collections(void)
{
    INT ap;
    UINT count, port, i;
    CHAR text[256], ip[46], key[64];
    struct { CHAR key[64]; UCHAR guard[8]; } bounded;
    wifi_vap_security_t security = {0}, saved;
    wifi_key_multi_psk_t keys[2] = {0}, out[2];
    mac_address_t mac = {2, 0, 0, 0, 0, 1};
    prepare(2); ap = index_for(0, wifi_vap_mode_ap);
    OK(wifi_getApSecurityModesSupported(ap, text)); CHECK(strstr(text, "WPA2-Personal") != NULL);
    OK(wifi_setApSecurityKeyPassphrase(ap, "reference-secret"));
    OK(wifi_getApSecurityKeyPassphrase(ap, text)); CHECK(!strcmp(text, "reference-secret"));
    OK(wifi_getApSecurityModeEnabled(ap, text)); CHECK(!strcmp(text, "WPA2-Personal"));
    OK(wifi_setApSecurityModeEnabled(ap, "WPA3-Personal"));
    OK(wifi_setApBeaconType(ap, "11i")); OK(wifi_getApBeaconType(ap, text)); CHECK(!strcmp(text, "11i"));
    OK(wifi_setApWpaEncryptionMode(ap, "AES")); OK(wifi_getApWpaEncryptionMode(ap, text)); CHECK(!strcmp(text, "AES"));
    BAD(wifi_setApSecurityKeyPassphrase(ap, "short"));
    UNSUPPORTED(wifi_setApSecurityModeEnabled(ap, "unknown"));
    UNSUPPORTED(wifi_setApAuthMode(ap, 0));
    OK(wifi_setApBasicAuthenticationMode(ap, "None"));
    UNSUPPORTED(wifi_setApBasicAuthenticationMode(ap, "SharedAuthentication"));
    UNSUPPORTED(wifi_setApSecurityPreSharedKey(ap, "raw"));
    UNSUPPORTED(wifi_getApSecurityPreSharedKey(ap, text));
    OK(wifi_disableApEncryption(ap)); OK(wifi_removeApSecVaribles(ap));
    OK(wifi_setApSecurityReset(ap));
    security.mode = wifi_security_mode_wpa2_enterprise;
    security.encr = wifi_encryption_aes;
#ifdef WIFI_HAL_VERSION_3_PHASE2
    security.u.radius.ip.family = wifi_ip_family_ipv4;
#else
    strcpy((CHAR *)security.u.radius.ip, "192.0.2.1");
#endif
    security.u.radius.port = 1812; strcpy(security.u.radius.key, "radius-secret");
    OK(wifi_setApSecurity(ap, &security));
    OK(wifi_setApSecurityRadiusServer(ap, "192.0.2.2", 1812, "primary-secret"));
    OK(wifi_getApSecurityRadiusServer(ap, ip, &port, key));
    CHECK(!strcmp(ip, "192.0.2.2") && port == 1812 && !strcmp(key, "primary-secret"));
    OK(wifi_setApSecuritySecondaryRadiusServer(ap, "192.0.2.3", 1813, "secondary-secret"));
    OK(wifi_getApSecuritySecondaryRadiusServer(ap, ip, &port, key));
    CHECK(!strcmp(ip, "192.0.2.3") && port == 1813);
    OK(wifi_setApDASRadiusServer(ap, "2001:db8::1", 3799, "das-secret"));
    OK(wifi_getApDASRadiusServer(ap, ip, &port, key));
    CHECK(!strcmp(ip, "2001:db8::1") && port == 3799);
    OK(wifi_getApSecurity(ap, &saved));
    BAD(wifi_setApSecurityRadiusServer(ap, "invalid", 1812, "changed"));
    BAD(wifi_setApSecuritySecondaryRadiusServer(ap, "192.0.2.1", 65536, "changed"));
    BAD(wifi_setApDASRadiusServer(ap, "192.0.2.1", 0, "changed"));
    OK(wifi_getApSecurity(ap, &security)); CHECK(!memcmp(&security, &saved, sizeof(saved)));
    memset(security.u.radius.s_key, 'x', sizeof(security.u.radius.s_key));
    BAD(wifi_setApSecurity(ap, &security));
    security = saved;
    memset(security.u.radius.daskey, 'x', sizeof(security.u.radius.daskey));
    BAD(wifi_setApSecurity(ap, &security));
    OK(wifi_getApSecurity(ap, &security)); CHECK(!memcmp(&security, &saved, sizeof(saved)));
    /* A maximum valid secret must fit the documented 64-byte output exactly. */
    memset(security.u.radius.s_key, 'x', sizeof(security.u.radius.s_key) - 1);
    security.u.radius.s_key[sizeof(security.u.radius.s_key) - 1] = '\0';
    OK(wifi_setApSecurity(ap, &security));
    memset(&bounded, 0xa5, sizeof(bounded));
    OK(wifi_getApSecuritySecondaryRadiusServer(ap, ip, &port, bounded.key));
    CHECK(!strcmp(bounded.key, security.u.radius.s_key));
    for (i = 0; i < sizeof(bounded.guard); ++i) CHECK(bounded.guard[i] == 0xa5);
    OK(wifi_setApSecurity(ap, &saved));
    UNSUPPORTED(wifi_getApSecurityKeyPassphrase(ap, text));
    UNSUPPORTED(wifi_setApSecurityKeyPassphrase(ap, "not-radius-data"));
    strcpy(keys[0].wifi_keyId, "one"); strcpy(keys[0].wifi_psk, "secondary-one");
    keys[1] = keys[0]; strcpy(keys[1].wifi_keyId, "two");
    OK(wifi_pushMultiPskKeys(ap, keys, 2));
    BAD(wifi_getMultiPskKeys(ap, out, 1));
    OK(wifi_getMultiPskKeys(ap, out, 2)); CHECK(!memcmp(out, keys, sizeof(keys)));
    keys[1] = keys[0]; BAD(wifi_pushMultiPskKeys(ap, keys, 2));
    OK(wifi_getMultiPskKeys(ap, out, 2)); CHECK(!strcmp(out[1].wifi_keyId, "two"));
    OK(wifi_test_client_event(ap, TRUE));
    OK(wifi_getMultiPskClientKey(ap, mac, out)); CHECK(out[0].wifi_keyId[0] == 0);
    OK(wifi_pushMultiPskKeys(ap, NULL, 0));
#ifdef WIFI_HAL_VERSION_3_PHASE2
    {
        mac_address_t list[2];
        OK(wifi_addApAclDevice(ap, mac)); OK(wifi_addApAclDevice(ap, mac));
        memset(list, 0xa5, sizeof(list)); count = 99;
        BAD(wifi_getApAclDevices(ap, list, 0, &count));
        CHECK(list[0][0] == 0xa5 && count == 99);
        OK(wifi_getApAclDevices(ap, list, 2, &count)); CHECK(count == 1 && !memcmp(list[0], mac, 6));
        CHECK(list[1][0] == 0xa5);
        OK(wifi_kickApAclAssociatedDevices(ap, TRUE));
        OK(wifi_delApAclDevice(ap, mac)); BAD(wifi_delApAclDevice(ap, mac));
    }
#else
    OK(wifi_addApAclDevice(ap, "02:00:00:00:00:01"));
    OK(wifi_addApAclDevice(ap, "02:00:00:00:00:01"));
    BAD(wifi_addApAclDevice(ap, "+2:00:00:00:00:01"));
    BAD(wifi_addApAclDevice(ap, " 2:00:00:00:00:01"));
    memset(text, 0xa5, sizeof(text));
    BAD(wifi_getApAclDevices(ap, text, 17)); CHECK((UCHAR)text[0] == 0xa5);
    OK(wifi_getApAclDevices(ap, text, sizeof(text))); CHECK(!strcmp(text, "02:00:00:00:00:01"));
    OK(wifi_kickApAclAssociatedDevices(ap, TRUE));
    OK(wifi_delApAclDevice(ap, "02:00:00:00:00:01")); BAD(wifi_delApAclDevice(ap, "02:00:00:00:00:01"));
#endif
    OK(wifi_getApAclDeviceNum(ap, &count)); CHECK(count == 0);
    OK(wifi_delApAclDevices(ap));
    {
        wifi_vap_info_t *vap = wifi_test_vap(ap);
        CHECK(!strcmp(get_vap_ssid(vap), vap->u.bss_info.ssid));
        CHECK(!strcmp(get_vap_bridge_name(vap), vap->bridge_name));
        CHECK(get_vap_security_mode(vap, &security) == (UINT)saved.mode);
        CHECK(get_vap_ssid(NULL) == NULL && get_vap_bridge_name(NULL) == NULL);
    }
}

static void diagnostics_and_ownership(void)
{
    INT ap, signal, later = -1;
    UINT count, i;
    static wifi_vap_info_map_t map;
    ULONG old_count;
    ULLONG handle;
    mac_t *authenticated = NULL;
    wifi_device_t *old = NULL;
    wifi_associated_dev2_t *devices = NULL;
    wifi_associated_dev_rate_info_rx_stats_t *rx = NULL;
    wifi_associated_dev_rate_info_tx_stats_t *tx = NULL;
    wifi_associated_dev_tid_stats_t tids;
    wifi_associated_dev_stats_t stats;
    wifi_ssidTrafficStats_t ssid;
    wifi_trafficStats_t traffic;
    wifi_basicTrafficStats_t basic;
    wifi_channelStats2_t channel;
    wifi_channelMetrics_t metrics[2] = {{0}}, prior[2];
    wifi_neighbor_ap2_t *neighbors = NULL;
    wifi_neighbor_ap_t *legacy = NULL;
    mac_address_t mac = {2, 0, 0, 0, 0, 1};
    prepare(2); ap = index_for(0, wifi_vap_mode_ap);
    OK(wifi_getApAuthenticatedDevices(ap, &authenticated, &count)); CHECK(!authenticated && !count);
    OK(wifi_getApAssociatedDeviceDiagnosticResult2(ap, &devices, &count)); CHECK(!devices && !count);
    OK(wifi_test_client_event(ap, TRUE));
    OK(wifi_getApAuthenticatedDevices(ap, &authenticated, &count));
    CHECK(count == 1 && authenticated != NULL);
    if (authenticated) CHECK(!memcmp(authenticated[0].byte, mac, 6));
    free(authenticated); authenticated = NULL;
    wifi_test_fail_allocation();
    BAD(wifi_getApAuthenticatedDevices(ap, &authenticated, &count)); CHECK(!authenticated && !count);
    OK(wifi_getApAssociatedDeviceDiagnosticResult2(ap, &devices, &count));
    CHECK(count == 1 && devices != NULL);
    if (devices) CHECK(devices[0].cli_Associations == 1 && devices[0].cli_Active);
    free(devices);
#ifndef WIFI_HAL_VERSION_3_PHASE2
    {
        wifi_associated_dev_t *v1 = NULL;
        OK(wifi_getApAssociatedDeviceDiagnosticResult(ap, &v1, &count)); CHECK(count == 1 && v1);
        free(v1);
    }
#endif
    OK(wifi_getAllAssociatedDeviceDetail(ap, &old_count, &old)); CHECK(old_count == 1 && old);
    if (old) CHECK(!memcmp(old->wifi_devMacAddress, mac, 6));
    free(old);
    OK(wifi_getApDeviceRSSI(ap, "02:00:00:00:00:01", &signal)); CHECK(signal == -45);
    OK(wifi_getApDeviceRxrate(ap, "02:00:00:00:00:01", &signal)); CHECK(signal == 0);
    OK(wifi_getApDeviceTxrate(ap, "02:00:00:00:00:01", &signal)); CHECK(signal == 0);
    BAD(wifi_getApDeviceRSSI(ap, "02:00:00:00:00:02", &signal));
    OK(wifi_getApAssociatedDeviceRxStatsResult(0, &mac, &rx, &count, &handle));
    CHECK(!rx && !count && handle == 1);
    OK(wifi_getApAssociatedDeviceTxStatsResult(0, &mac, &tx, &count, &handle)); CHECK(!tx && !count);
    OK(wifi_getApAssociatedDeviceTidStatsResult(0, &mac, &tids, &handle));
    CHECK(tids.tid_array[15].tid == 15);
    OK(wifi_getApAssociatedDeviceStats(0, &mac, &stats, &handle)); CHECK(handle == 1);
    BAD(wifi_getApAssociatedDeviceStats(1, &mac, &stats, &handle));
    OK(wifi_getSSIDTrafficStats(ap, &ssid)); OK(wifi_getWifiTrafficStats(ap, &traffic));
    OK(wifi_getBasicTrafficStats(ap, &basic)); CHECK(basic.wifi_Associations == 1);
    OK(wifi_getRadioChannelStats2(0, &channel)); CHECK(channel.ch_Frequency == 2412 && channel.ch_NoiseFloor == -95);
    metrics[0].channel_number = 1; metrics[1].channel_number = 0;
    memcpy(prior, metrics, sizeof(prior)); BAD(wifi_getRadioDcsChannelMetrics(0, metrics, 2));
    CHECK(!memcmp(prior, metrics, sizeof(prior)));
    metrics[1].channel_number = 6;
    OK(wifi_getRadioDcsChannelMetrics(0, metrics, 2));
    CHECK(metrics[1].channel_number == 6 && metrics[1].channel_noise == -95);
    OK(wifi_getNeighboringWiFiDiagnosticResult2(0, &neighbors, &count)); CHECK(count == 1 && neighbors);
    if (neighbors) CHECK(neighbors->ap_Channel == 1 && neighbors->ap_SignalStrength == -45);
    free(neighbors); neighbors = NULL;
#ifdef WIFI_HAL_VERSION_3_PHASE2
    OK(wifi_getNeighboringWiFiStatus(1, FALSE, &neighbors, &count));
#else
    OK(wifi_getNeighboringWiFiStatus(1, &neighbors, &count));
#endif
    CHECK(count == 1 && neighbors);
    free(neighbors); neighbors = NULL;
    OK(wifi_getNeighboringWiFiDiagnosticResult(&legacy, &count)); CHECK(count == 1 && legacy);
    free(legacy);
    wifi_test_fail_allocation();
    BAD(wifi_getNeighboringWiFiDiagnosticResult2(0, &neighbors, &count)); CHECK(!neighbors && !count);
    BAD(wifi_getNeighboringWiFiDiagnosticResult2(-1, &neighbors, &count)); CHECK(!neighbors && !count);
    OK(wifi_getRadioVapInfoMap(0, &map));
    for (i = 0; i < map.num_vaps; ++i)
        if (map.vap_array[i].vap_mode == wifi_vap_mode_ap && map.vap_array[i].vap_index >= 2) {
            later = (INT)map.vap_array[i].vap_index;
            break;
        }
    CHECK(later >= 2);
    OK(wifi_test_client_event(ap, FALSE));
    OK(wifi_test_client_event(later, TRUE));
    OK(wifi_getApAssociatedDeviceStats(later, &mac, &stats, &handle)); CHECK(handle == 1);
    /* Another VAP on the same radio cannot lend this AP its association. */
    BAD(wifi_getApAssociatedDeviceStats(ap, &mac, &stats, &handle));
    BAD(wifi_getApAssociatedDeviceStats(index_for(0, wifi_vap_mode_sta), &mac, &stats, &handle));
    OK(wifi_test_client_event(later, FALSE));
}

static void fast_transition_settings(void)
{
    INT ap;
    BOOL enabled = TRUE, got;
    UINT lifetime = 100, read_lifetime;
    UCHAR domain[2] = {0x12, 0x34}, read_domain[2], holder[64], r1[6] = {2, 3, 4, 5, 6, 7};
    wifi_FastTransitionConfig_t ft = {0};
    wifi_eap_config_t eap;
    CHAR mac[18];
    ULONG time;
    INT source, dest, reason;
    prepare(2); ap = index_for(0, wifi_vap_mode_ap);
    OK(wifi_setFastBSSTransitionActivated(ap, TRUE));
    OK(wifi_setFTOverDSActivated(ap, &enabled));
    OK(wifi_getFTOverDSActivated(ap, &got)); CHECK(got);
    enabled = 2; BAD(wifi_setFTOverDSActivated(ap, &enabled));
    enabled = TRUE; OK(wifi_setFTResourceRequestSupported(ap, &enabled));
    OK(wifi_getFTResourceRequestSupported(ap, &got)); CHECK(got);
    OK(wifi_setFTR0KeyLifetime(ap, &lifetime));
    OK(wifi_getFTR0KeyLifetime(ap, &read_lifetime)); CHECK(read_lifetime == lifetime);
    BAD(wifi_setFTR0KeyLifetime(ap, NULL));
    OK(wifi_setFTMobilityDomainID(ap, domain));
    OK(wifi_getFTMobilityDomainID(ap, read_domain)); CHECK(!memcmp(domain, read_domain, 2));
    OK(wifi_setFTR0KeyHolderID(ap, (UCHAR *)"nas-reference"));
    OK(wifi_getFTR0KeyHolderID(ap, holder)); CHECK(!strcmp((CHAR *)holder, "nas-reference"));
    OK(wifi_setFTR1KeyHolderID(ap, r1)); OK(wifi_getFTR1KeyHolderID(ap, holder)); CHECK(!memcmp(r1, holder, 6));
    ft.support = FT_SUPPORT_FULL; ft.overDS = TRUE;
    OK(wifi_pushApFastTransitionConfig(ap, &ft));
    ft.numR0KHs = MAX_KEY_HOLDERS + 1; BAD(wifi_pushApFastTransitionConfig(ap, &ft));
    OK(wifi_getFTOverDSActivated(ap, &got)); CHECK(got);
    OK(wifi_setEAP_Param((UINT)ap, 10, "eapolkeytimeout"));
    OK(wifi_setEAP_Param((UINT)ap, 11, "eapolkeyretries"));
    OK(wifi_setEAP_Param((UINT)ap, 12, "eapidentityrequesttimeout"));
    OK(wifi_setEAP_Param((UINT)ap, 13, "eapidentityrequestretries"));
    OK(wifi_setEAP_Param((UINT)ap, 14, "eaprequesttimeout"));
    OK(wifi_setEAP_Param((UINT)ap, 15, "eaprequestretries"));
    UNSUPPORTED(wifi_setEAP_Param((UINT)ap, 1, "timeout"));
    OK(wifi_getEAP_Param((UINT)ap, &eap));
    CHECK(eap.uiEAPOLKeyTimeout == 10 && eap.uiEAPOLKeyRetries == 11 &&
          eap.uiEAPIdentityRequestTimeout == 12 && eap.uiEAPIdentityRequestRetries == 13 &&
          eap.uiEAPRequestTimeout == 14 && eap.uiEAPRequestRetries == 15);
    UNSUPPORTED(wifi_getBandSteeringLog(0, &time, mac, &source, &dest, &reason));
}

static UINT management_events, beacon_events;
#ifdef WIFI_HAL_VERSION_3_PHASE2
static INT management(INT ap, wifi_frame_t *frame)
{
    CHECK(ap >= 0 && frame && frame->len == 1 && frame->data[0] == 0x42);
    ++management_events;
    return 17;
}
static INT btm_response(UINT ap, mac_address_t mac, wifi_BTMResponse_t *response)
#else
static INT management(INT ap, UCHAR *mac, UCHAR *data, UINT length,
                      wifi_mgmtFrameType_t type, wifi_direction_t direction, UINT frequency)
{
    (void)type; (void)direction; (void)frequency;
    CHECK(ap >= 0 && mac && length == 1 && data && data[0] == 0x42);
    ++management_events;
    return 17;
}
static INT btm_response(UINT ap, CHAR *mac, wifi_BTMResponse_t *response)
#endif
{
    CHECK(ap < WIFI_TEST_VAPS && mac && response && response->token == 7);
    ++management_events;
    return 0;
}
static INT beacon(UINT ap, wifi_BeaconReport_t *report, UINT *count, UCHAR *token)
{
    CHECK(ap < WIFI_TEST_VAPS && report && count && *count == 1 && token && *token);
    ++beacon_events;
    return 0;
}

static void extender_and_optional_boundaries(void)
{
    INT ap, sta;
    BOOL capable;
    UINT entries;
    UCHAR byte = 0x42, token = 0, rrm[5];
    mac_address_t mac = {2, 0, 0, 0, 0, 7};
    wifi_BTMRequest_t request = {0};
    wifi_BeaconRequest_t measurement = {0};
    wifi_BTMCapabilities_t capabilities;
    wifi_NeighborReport_t report = {0};
    wifi_twt_params_t twt;
    wifi_GASConfiguration_t gas = {0};
    wifi_anqp_node_t response = {0};
    wifi_device_dpp_context_t dpp = {0};
    CHAR name[64], list[2] = {'x', 'y'};
    prepare(2); ap = index_for(0, wifi_vap_mode_ap);
    management_events = beacon_events = 0;
    OK(wifi_getBSSTransitionImplemented((UINT)ap, &capable)); CHECK(capable);
    OK(wifi_setBSSTransitionActivation(ap, TRUE));
    OK(wifi_getBSSTransitionActivated(ap, &capable)); CHECK(capable);
    BAD(wifi_getBSSTransitionActivated(-1, &capable));
    BAD(wifi_getBSSTransitionActivated(ap, NULL));
    OK(wifi_setBSSTransitionActivation(ap, FALSE));
    OK(wifi_getBSSTransitionActivated(ap, &capable)); CHECK(!capable);
    OK(wifi_getBTMClientCapabilityList((UINT)ap, &capabilities));
    OK(wifi_setNeighborReports((UINT)ap, 1, &report));
    BAD(wifi_setNeighborReports((UINT)ap, 9, &report));
    CHECK(wifi_test_state.ap_extra[ap].neighbor_count == 1);
    OK(wifi_setNeighborReports((UINT)ap, 0, NULL));
    OK(wifi_setApCsaDeauth(ap, 2)); BAD(wifi_setApCsaDeauth(ap, 3));
    OK(wifi_setApScanFilter(ap, 1, "included")); BAD(wifi_setApScanFilter(ap, 3, "ignored"));
    CHECK(!strcmp(wifi_test_state.ap_extra[ap].scan_ssid, "included"));
    sta = index_for(0, wifi_vap_mode_sta);
    BAD(wifi_BTMQueryRequest_callback_register((UINT)sta, NULL, NULL));
    BAD(wifi_BTMQueryRequest_callback_register((UINT)sta, NULL, btm_response));
    BAD(wifi_RMBeaconRequestCallbackRegister((UINT)sta, beacon));
    BAD(wifi_RMBeaconRequestCallbackUnregister((UINT)sta, beacon));
    BAD(wifi_cancelRMBeaconRequest((UINT)sta, 1));
    OK(wifi_BTMQueryRequest_callback_register((UINT)ap, NULL, btm_response));
    request.token = 7;
#ifdef WIFI_HAL_VERSION_3_PHASE2
    BAD(wifi_setBTMRequest((UINT)sta, mac, &request));
    BAD(wifi_setRMBeaconRequest((UINT)sta, mac, &measurement, &token));
    token = 91;
    CHECK(wifi_setRMBeaconRequest((UINT)ap, mac, &measurement, &token) == WIFI_HAL_NOT_READY);
    OK(wifi_setBTMRequest((UINT)ap, mac, &request));
    OK(wifi_getRMCapabilities(mac, rrm));
#else
    BAD(wifi_setBTMRequest((UINT)sta, "02:00:00:00:00:07", &request));
    BAD(wifi_setRMBeaconRequest((UINT)sta, "02:00:00:00:00:07", &measurement, &token));
    token = 91;
    CHECK(wifi_setRMBeaconRequest((UINT)ap, "02:00:00:00:00:07", &measurement, &token) ==
          WIFI_HAL_NOT_READY);
    OK(wifi_setBTMRequest((UINT)ap, "02:00:00:00:00:07", &request));
    OK(wifi_getRMCapabilities("02:00:00:00:00:07", rrm));
#endif
    CHECK(token == 91 && wifi_test_state.token[ap] == 0 && wifi_test_state.token[sta] == 0);
    token = 0;
    CHECK(management_events == 1 && rrm[0] == 0x70);
    OK(wifi_RMBeaconRequestCallbackRegister((UINT)ap, beacon));
    measurement.channel = 1;
#ifdef WIFI_HAL_VERSION_3_PHASE2
    OK(wifi_setRMBeaconRequest((UINT)ap, mac, &measurement, &token));
#else
    OK(wifi_setRMBeaconRequest((UINT)ap, "02:00:00:00:00:07", &measurement, &token));
#endif
    CHECK(beacon_events == 1 && token != 0);
    BAD(wifi_cancelRMBeaconRequest((UINT)ap, 0));
    BAD(wifi_cancelRMBeaconRequest((UINT)ap, (UCHAR)(token + 1)));
    CHECK(wifi_test_state.token[ap] == token);
    OK(wifi_cancelRMBeaconRequest((UINT)ap, token));
    CHECK(wifi_test_state.token[ap] == 0);
    BAD(wifi_cancelRMBeaconRequest((UINT)ap, token));
    OK(wifi_mgmt_frame_callbacks_register(management));
    CHECK(mgmt_frame_received_callback(ap, mac, &byte, 1,
          (wifi_mgmtFrameType_t)0, (wifi_direction_t)0) == 17);
    CHECK(management_events == 2);
    BAD(mgmt_frame_received_callback(ap, mac, &byte, 0, (wifi_mgmtFrameType_t)0, (wifi_direction_t)0));
    OK(wifi_getATMCapable(&capable)); CHECK(!capable);
    OK(wifi_getATMEnable(&capable)); CHECK(!capable);
    OK(wifi_setATMEnable(FALSE)); UNSUPPORTED(wifi_setATMEnable(TRUE)); BAD(wifi_setATMEnable(2));
    OK(wifi_getApATMAirTimePercent(ap, &entries)); CHECK(entries == 0);
    UNSUPPORTED(wifi_setApATMAirTimePercent(ap, 50)); BAD(wifi_setApATMAirTimePercent(ap, 101));
    UNSUPPORTED(wifi_setApATMSta(ap, mac, 50));
    OK(wifi_getApATMSta(ap, (UCHAR *)list, 1)); CHECK(list[0] == 0 && list[1] == 'y');
    BAD(wifi_getApATMSta(ap, (UCHAR *)list, 0));
    OK(wifi_getApName(ap, name)); UNSUPPORTED(wifi_getTWTParams(name, &twt));
    UNSUPPORTED(wifi_sendDataFrame(ap, NULL, &byte, 1, FALSE, 0, (wifi_data_priority_t)0));
    BAD(wifi_sendDataFrame(ap, mac, &byte, 0, FALSE, 0, (wifi_data_priority_t)0));
    UNSUPPORTED(wifi_sendActionFrame(ap, mac, 2412, &byte, 1));
    UNSUPPORTED(wifi_sendActionFrameExt(ap, mac, 2412, 1, &byte, 1));
    UNSUPPORTED(wifi_applyGASConfiguration(&gas)); BAD(wifi_applyGASConfiguration(NULL));
    UNSUPPORTED(wifi_anqpSendResponse((UINT)ap, mac, 1, &response));
    UNSUPPORTED(wifi_dppSetSTAPassphrase((UINT)ap, "02:00:00:00:00:07", "reference-secret"));
    BAD(wifi_dppSetSTAPassphrase((UINT)ap, "02:00:00:00:00:07", "short"));
    UNSUPPORTED(wifi_dppRemoveSTAPassphrase((UINT)ap, "02:00:00:00:00:07"));
    dpp.ap_index = (UINT)ap;
    UNSUPPORTED(wifi_dppInitiate(&dpp)); UNSUPPORTED(wifi_dppCancel(&dpp));
    UNSUPPORTED(wifi_dppSendAuthCnf(&dpp)); UNSUPPORTED(wifi_dppSendConfigResponse(&dpp));
    BAD(wifi_dppInitiate(NULL));
    OK(wifi_getBandSteeringCapability(&capable)); CHECK(capable);
    OK(wifi_getLibhostapd(&capable)); CHECK(!capable);
    UNSUPPORTED(wifi_updateLibHostApdConfig(ap));
}

static void callback_reset_and_lifecycle(void)
{
    INT ap;
    BOOL value;
    prepare(2); ap = index_for(0, wifi_vap_mode_ap);
    /* NULL registrations are intentional public unregistration operations. */
    wifi_radiusEapFailure_callback_register(NULL); wifi_apStatusCode_callback_register(NULL);
    wifi_ap_stamode_callback_register(NULL); wifi_handshake_callback_register(NULL);
    wifi_radiusFallback_failover_callback_register(NULL); wifi_apFrameDropUnencrypted_callback_register(NULL);
    wifi_csi_callback_register(NULL); wifi_hal_register_frame_hook(NULL);
    OK(wifi_vapstatus_callback_register(NULL)); OK(wifi_hal_analytics_callback_register(NULL));
    OK(wifi_wpsEvent_callback_register(NULL)); wifi_apAuthEvent_callback_register(NULL);
    wifi_apAuthenticatedEvent_callback_register(NULL); wifi_apAssociatedDevice_callback_register(NULL);
    OK(wifi_chan_eventRegister(NULL)); wifi_steerTriggered_callback_register(NULL, NULL);
    OK(wifi_anqp_request_callback_register(NULL));
    OK(wifi_dpp_frame_received_callbacks_register(NULL, NULL, NULL, NULL, NULL));
    OK(wifi_mgmt_frame_callbacks_register(management));
    CHECK(wifi_test_state.mgmt_cb == management);
    OK(wifi_enableGreylistAccessControl(TRUE)); BAD(wifi_enableGreylistAccessControl(2));
    OK(wifi_setLED(0, TRUE)); BAD(wifi_setLED(-1, TRUE)); BAD(wifi_setLED(0, 2));
    UNSUPPORTED(wifi_createInitialConfigFiles());
    UNSUPPORTED(wifi_createHostApdConfig(ap, TRUE));
    BAD(wifi_createHostApdConfig(-1, TRUE));
    UNSUPPORTED(wifi_startHostApd()); UNSUPPORTED(wifi_stopHostApd());
    OK(wifi_down()); OK(wifi_getRadioEnable(0, &value)); CHECK(!value);
    OK(wifi_reset()); OK(wifi_getRadioEnable(0, &value)); CHECK(value);
    CHECK(wifi_test_state.mgmt_cb == NULL && !wifi_test_state.greylist && !wifi_test_state.led[0]);
    OK(wifi_factoryReset()); CHECK(wifi_test_state.radios == 2);
}

#ifdef WIFI_ACTIVE_STANDALONE
/* PUBLIC_INTERFACE */
/** Execute the same reference-only cases without CUnit for strict ABI/sanitizer probes. */
int main(void)
{
    nonassociated_station_measurement();
    radio_setting_adapters();
    radio_legacy_adapters();
    ap_setting_adapters();
    security_and_collections();
    diagnostics_and_ownership();
    fast_transition_settings();
    extender_and_optional_boundaries();
    callback_reset_and_lifecycle();
    printf("Active contracts: cases=9 assertions=%u failures=%u\n", checks, failures);
    return failures ? EXIT_FAILURE : EXIT_SUCCESS;
}
#endif
#endif

#ifndef WIFI_ACTIVE_STANDALONE
#include "test_support.h"
/* PUBLIC_INTERFACE */
/** Register Linux reference completeness regressions; vendor builds exclude model controls. */
int test_wifi_active_register(void)
{
#ifdef BUILD_LINUX
    static const wifi_test_case_t cases[] = {
        WIFI_CASE(nonassociated_station_measurement),
        WIFI_CASE(radio_setting_adapters),
        WIFI_CASE(radio_legacy_adapters),
        WIFI_CASE(ap_setting_adapters),
        WIFI_CASE(security_and_collections),
        WIFI_CASE(diagnostics_and_ownership),
        WIFI_CASE(fast_transition_settings),
        WIFI_CASE(extender_and_optional_boundaries),
        WIFI_CASE(callback_reset_and_lifecycle),
    };
    return WIFI_REGISTER("[L1 wifi-active-contracts]", cases);
#else
    return 0;
#endif
}
#endif
