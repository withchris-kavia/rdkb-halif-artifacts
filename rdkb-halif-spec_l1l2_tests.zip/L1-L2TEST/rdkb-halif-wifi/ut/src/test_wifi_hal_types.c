#include <stdint.h>
#include "test_support.h"

_Static_assert(sizeof(mac_address_t) == 6, "MAC ABI must remain six bytes");
_Static_assert(sizeof(ssid_t) == 32, "SSID ABI capacity changed");
_Static_assert(WIFI_CHANNELBANDWIDTH_20MHZ == 1, "Bandwidth is a bitmask, not MHz");
_Static_assert(WIFI_CHANNELBANDWIDTH_320MHZ == 32, "Six bandwidth bits expected");
_Static_assert(WIFI_HAL_RSN_SELECTOR(0xff, 0x80, 0xac, 0x04) == UINT32_C(0xff80ac04),
               "RSN selector must use unsigned shifts");

static void public_types_and_masks(void)
{
    wifi_vap_info_t vap = {0};
    wifi_bss_info_t bss = {0};
    wifi_vap_security_t security = {0};
    UINT widths = WIFI_CHANNELBANDWIDTH_20MHZ | WIFI_CHANNELBANDWIDTH_80MHZ;
    CU_ASSERT_EQUAL(widths & WIFI_CHANNELBANDWIDTH_20MHZ, WIFI_CHANNELBANDWIDTH_20MHZ);
    CU_ASSERT_EQUAL(widths & WIFI_CHANNELBANDWIDTH_40MHZ, 0);
    CU_ASSERT_EQUAL(WIFI_HAL_RSN_CIPHER_SUITE_CCMP, UINT32_C(0x000fac04));
    CU_ASSERT_EQUAL(WIFI_HAL_RSN_SELECTOR(0x12, 0x34, 0x56, 0x78), UINT32_C(0x12345678));
    vap.vap_mode = wifi_vap_mode_sta;
    vap.u.sta_info.conn_status = wifi_connection_status_disconnected;
    bss.oper_freq_band = WIFI_FREQUENCY_5_BAND;
    security.mode = wifi_security_mode_wpa2_personal;
#ifdef WIFI_HAL_VERSION_3
    security.mfp = wifi_mfp_cfg_optional;
    CU_ASSERT_EQUAL(security.mfp, wifi_mfp_cfg_optional);
#else
    strcpy(security.mfpConfig, "Optional");
    CU_ASSERT_STRING_EQUAL(security.mfpConfig, "Optional");
#endif
#ifdef WIFI_HAL_VERSION_3_PHASE2
    security.u.radius.ip.family = wifi_ip_family_ipv4;
    CU_ASSERT_EQUAL(security.u.radius.ip.family, wifi_ip_family_ipv4);
#else
    strcpy((char *)security.u.radius.ip, "192.0.2.1");
    CU_ASSERT_STRING_EQUAL((char *)security.u.radius.ip, "192.0.2.1");
#endif
    CU_ASSERT_EQUAL(vap.vap_mode, wifi_vap_mode_sta);
    CU_ASSERT_EQUAL(bss.oper_freq_band, WIFI_FREQUENCY_5_BAND);
    CU_ASSERT(sizeof(wifi_hal_capability_t) > sizeof(wifi_radio_capabilities_t));
}

/* PUBLIC_INTERFACE */
/** Register public type, bitmask and feature-specific layout checks. */
int test_wifi_types_register(void)
{
    static const wifi_test_case_t cases[] = { WIFI_CASE(public_types_and_masks) };
    return WIFI_REGISTER("[L1 wifi-types]", cases);
}
