#include "test_support.h"

static void thresholds_and_activation(void)
{
    INT value, ap;
    BOOL enabled;
    char group[64];
    WIFI_PREPARE();
    ap = wifi_test_index(wifi_vap_mode_ap, 0);
    CU_ASSERT_EQUAL(wifi_setBandSteeringEnable(TRUE), 0);
    CU_ASSERT_EQUAL(wifi_getBandSteeringEnable(&enabled), 0);
    CU_ASSERT_TRUE(enabled);
    CU_ASSERT_EQUAL(wifi_setBandSteeringApGroup("1,2"), 0);
    CU_ASSERT_EQUAL(wifi_getBandSteeringApGroup(group), 0);
    CU_ASSERT_STRING_EQUAL(group, "1,2");
    CU_ASSERT_EQUAL(wifi_setBandSteeringApGroup("1,2;3,4"), 0);
    {
        char *invalid[] = {"", "0;1", "0,2", "1,0", "1", "1,2;", ";1,2",
                           "1,,2", "1,2,3", "1,2;3", "1,2;0,4", "1,2;3,4junk",
                           "-1,2", "+1,2", "1, 2", "42949672960,2"};
        char oversized[65];
        size_t i;
        for (i = 0; i < sizeof(invalid) / sizeof(invalid[0]); ++i) {
            CU_ASSERT_NOT_EQUAL(wifi_setBandSteeringApGroup(invalid[i]), 0);
            CU_ASSERT_EQUAL(wifi_getBandSteeringApGroup(group), 0);
            CU_ASSERT_STRING_EQUAL(group, "1,2;3,4");
        }
        memset(oversized, '1', sizeof(oversized) - 1);
        oversized[sizeof(oversized) - 1] = '\0';
        CU_ASSERT_NOT_EQUAL(wifi_setBandSteeringApGroup(oversized), 0);
        CU_ASSERT_NOT_EQUAL(wifi_setBandSteeringApGroup(NULL), 0);
        CU_ASSERT_EQUAL(wifi_getBandSteeringApGroup(group), 0);
        CU_ASSERT_STRING_EQUAL(group, "1,2;3,4");
    }
#define CHECK_THRESHOLD(Name, Good, Bad) do { \
    CU_ASSERT_EQUAL(wifi_setBandSteering##Name(0, Good), 0); \
    CU_ASSERT_EQUAL(wifi_getBandSteering##Name(0, &value), 0); \
    CU_ASSERT_EQUAL(value, Good); \
    CU_ASSERT_NOT_EQUAL(wifi_setBandSteering##Name(0, Bad), 0); \
    CU_ASSERT_NOT_EQUAL(wifi_getBandSteering##Name(0, NULL), 0); \
} while (0)
    CHECK_THRESHOLD(BandUtilizationThreshold, 70, 101);
    CHECK_THRESHOLD(RSSIThreshold, -65, -111);
    CHECK_THRESHOLD(PhyRateThreshold, 100, -1);
    CHECK_THRESHOLD(OverloadInactiveTime, 20, -1);
    CHECK_THRESHOLD(IdleInactiveTime, 30, -1);
#undef CHECK_THRESHOLD
    CU_ASSERT_EQUAL(wifi_setBSSTransitionActivation((UINT)ap, TRUE), 0);
    CU_ASSERT_EQUAL(wifi_getBSSTransitionActivation((UINT)ap, &enabled), 0);
    CU_ASSERT_TRUE(enabled);
    CU_ASSERT_EQUAL(wifi_setNeighborReportActivation((UINT)ap, TRUE), 0);
    CU_ASSERT_EQUAL(wifi_getNeighborReportActivation((UINT)ap, &enabled), 0);
    CU_ASSERT_TRUE(enabled);
    CU_ASSERT_NOT_EQUAL(wifi_getNeighborReportActivation((UINT)ap, NULL), 0);
    CU_ASSERT_NOT_EQUAL(wifi_setBandSteeringApGroup(NULL), 0);
}

/* PUBLIC_INTERFACE */
/** Register all five steering thresholds and AP activation state checks. */
int test_wifi_client_mgt_register(void)
{
    static const wifi_test_case_t cases[] = { WIFI_CASE(thresholds_and_activation) };
    return WIFI_REGISTER("[L1 wifi-client-mgt]", cases);
}
