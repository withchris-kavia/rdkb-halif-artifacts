#include "test_support.h"

static void radio_roundtrip(void)
{
    wifi_radio_operationParam_t original, changed, actual;
    ULONG power;
    BOOL enabled;
    WIFI_PREPARE();
    CU_ASSERT_EQUAL_FATAL(wifi_getRadioOperatingParameters(0, &original), 0);
    changed = original;
    changed.transmitPower = 0;
    CU_ASSERT_EQUAL(wifi_setRadioOperatingParameters(0, &changed), 0);
    CU_ASSERT_EQUAL(wifi_getRadioTransmitPower(0, &power), 0);
    CU_ASSERT_EQUAL(power, 0);
    CU_ASSERT_EQUAL(wifi_setRadioTransmitPower(0, 60), 0);
    CU_ASSERT_EQUAL(wifi_setRadioEnable(0, FALSE), 0);
    CU_ASSERT_EQUAL(wifi_getRadioEnable(0, &enabled), 0);
    CU_ASSERT_FALSE(enabled);
    changed = original;
    changed.numSecondaryChannels = MAXNUMSECONDARYCHANNELS + 1;
    CU_ASSERT_NOT_EQUAL(wifi_setRadioOperatingParameters(0, &changed), 0);
    CU_ASSERT_NOT_EQUAL(wifi_getRadioOperatingParameters(MAX_NUM_RADIOS, &actual), 0);
    CU_ASSERT_NOT_EQUAL(wifi_getRadioOperatingParameters(0, NULL), 0);
    CU_ASSERT_NOT_EQUAL(wifi_setRadioTransmitPower(0, 101), 0);
    CU_ASSERT_EQUAL(wifi_setRadioOperatingParameters(0, &original), 0);
    CU_ASSERT_EQUAL(wifi_getRadioOperatingParameters(0, &actual), 0);
    CU_ASSERT_EQUAL(memcmp(&original, &actual, sizeof(actual)), 0);
}

static void capability_enumeration(void)
{
    int channels[MAX_CHANNELS];
    wifi_channelBandwidth_t widths[6];
    size_t n, i;
    WIFI_PREPARE();
    CU_ASSERT_EQUAL_FATAL(get_channel_list(0, &n, channels, MAX_CHANNELS), 0);
    CU_ASSERT(n > 0 && n <= MAX_CHANNELS);
    for (i = 0; i < n; ++i) CU_ASSERT(channels[i] > 0);
    CU_ASSERT_EQUAL_FATAL(get_channel_bandwidth(0, &n, widths, 6), 0);
    CU_ASSERT(n > 0 && n <= 6);
    for (i = 0; i < n; ++i) {
        UINT width = (UINT)widths[i];
        CU_ASSERT_EQUAL(width & (width - 1), 0);
    }
    n = 99;
    CU_ASSERT_NOT_EQUAL(get_channel_list(0, &n, channels, 1), 0);
    CU_ASSERT_EQUAL(n, 0);
    CU_ASSERT_NOT_EQUAL(get_channel_bandwidth(0, &n, widths, 1), 0);
    CU_ASSERT_EQUAL(n, 0);
    CU_ASSERT_NOT_EQUAL(get_channel_list(-1, &n, channels, MAX_CHANNELS), 0);
}

static void scan_result_ownership(void)
{
    wifi_radio_operationParam_t op;
    wifi_channel_t channel;
    wifi_bss_info_t *bss = NULL;
    UINT count = 0;
    WIFI_PREPARE();
    CU_ASSERT_EQUAL_FATAL(wifi_getRadioOperatingParameters(0, &op), 0);
    channel.band = op.band;
    channel.channel = (INT)op.channel;
    CU_ASSERT_EQUAL(wifi_getScanResults(0, &channel, &bss, &count), 0);
    CU_ASSERT(count == 0 || bss != NULL);
    if (count && bss) CU_ASSERT_PTR_NOT_NULL(memchr(bss[0].ssid, '\0', sizeof(bss[0].ssid)));
    free(bss);
    bss = NULL;
    CU_ASSERT_NOT_EQUAL(wifi_getScanResults(MAX_NUM_RADIOS, &channel, &bss, &count), 0);
    CU_ASSERT_PTR_NULL(bss);
    CU_ASSERT_EQUAL(count, 0);
    channel.channel = 234;
    CU_ASSERT_NOT_EQUAL(wifi_getScanResults(0, &channel, &bss, &count), 0);
    CU_ASSERT_PTR_NULL(bss);
    CU_ASSERT_EQUAL(count, 0);
}

/* PUBLIC_INTERFACE */
/** Register radio boundary, round-trip and result-ownership cases. */
int test_wifi_radio_register(void)
{
    static const wifi_test_case_t cases[] = {
        WIFI_CASE(radio_roundtrip), WIFI_CASE(capability_enumeration), WIFI_CASE(scan_result_ownership)
    };
    return WIFI_REGISTER("[L1 wifi-radio]", cases);
}
