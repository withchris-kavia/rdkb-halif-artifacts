#include <string.h>
#include "test_utils.h"

wifi_radio_operationParam_t g_operationParam[MAX_NUM_RADIOS];
wifi_vap_info_map_t g_org_map[MAX_NUM_RADIOS];

/* PUBLIC_INTERFACE */
/** Reject NULL, failed capability calls, zero radios and oversized topology. */
INT test_utils_getMaxNumberOfRadio(UINT *radios)
{
    wifi_hal_capability_t cap;
    if (!radios) return -1;
    *radios = 0;
    if (wifi_getHalCapability(&cap) || !cap.wifi_prop.numRadios ||
        cap.wifi_prop.numRadios > MAX_NUM_RADIOS) return -1;
    *radios = cap.wifi_prop.numRadios;
    return 0;
}
/* PUBLIC_INTERFACE */
/** Find role membership dynamically; never assume two or three radios. */
INT test_utils_getApIndices(UINT radios, INT indices[], APTYPE type)
{
    static const char *roles[] = {"private", "mesh_sta", "iot", "mesh_backhaul",
                                  "lnf_psk", "lnf_radius", "hotspot_open", "hotspot_secure"};
    wifi_vap_info_map_t map;
    UINT actual, r, v;
    if (!indices || type < PRIVATE || type > HOTSPOT_SECURE ||
        test_utils_getMaxNumberOfRadio(&actual) || radios != actual) return -1;
    for (r = 0; r < radios; ++r) indices[r] = -1;
    for (r = 0; r < radios; ++r) {
        if (wifi_getRadioVapInfoMap(r, &map) || !map.num_vaps ||
            map.num_vaps > MAX_NUM_VAP_PER_RADIO) return -1;
        for (v = 0; v < map.num_vaps; ++v) {
            if (!memchr(map.vap_array[v].vap_name, '\0', sizeof(map.vap_array[v].vap_name)))
                return -1;
            if (!strncmp(map.vap_array[v].vap_name, roles[type], strlen(roles[type])))
                indices[r] = (INT)map.vap_array[v].vap_index;
        }
        if (indices[r] < 0) return -1;
    }
    return 0;
}
/* PUBLIC_INTERFACE */
/** Capture every live radio/map with bounds and nonempty-map checks. */
INT l2_test_prerequisite(void)
{
    UINT r, radios;
    if (test_utils_getMaxNumberOfRadio(&radios)) return -1;
    for (r = 0; r < radios; ++r)
        if (wifi_getRadioOperatingParameters(r, &g_operationParam[r]) ||
            wifi_getRadioVapInfoMap(r, &g_org_map[r]) || !g_org_map[r].num_vaps ||
            g_org_map[r].num_vaps > MAX_NUM_VAP_PER_RADIO) return -1;
    return 0;
}
/* PUBLIC_INTERFACE */
/** Enumerate unique channels from all bands with checked caller capacity. */
INT get_channel_list(int radio, size_t *count, int *channels, size_t capacity)
{
    wifi_hal_capability_t cap;
    UINT b;
    INT n;
    size_t used = 0, j;
    if (count) *count = 0;
    if (!count || !channels || !capacity || radio < 0 || wifi_getHalCapability(&cap) ||
        !cap.wifi_prop.numRadios || cap.wifi_prop.numRadios > MAX_NUM_RADIOS ||
        (UINT)radio >= cap.wifi_prop.numRadios ||
        cap.wifi_prop.radiocap[radio].numSupportedFreqBand > MAX_NUM_FREQ_BAND) return -1;
    for (b = 0; b < cap.wifi_prop.radiocap[radio].numSupportedFreqBand; ++b) {
        wifi_channels_list_t *list = &cap.wifi_prop.radiocap[radio].channel_list[b];
        if (list->num_channels < 0 || list->num_channels > MAX_CHANNELS) return -1;
        for (n = 0; n < list->num_channels; ++n) {
            for (j = 0; j < used && channels[j] != list->channels_list[n]; ++j) {}
            if (j != used) continue;
            if (used == capacity) return -1;
            channels[used++] = list->channels_list[n];
        }
    }
    *count = used;
    return used ? 0 : -1;
}
/* PUBLIC_INTERFACE */
/** Convert capability bitmasks into at most six distinct public bandwidth enums. */
INT get_channel_bandwidth(int radio, size_t *count, wifi_channelBandwidth_t *widths, size_t capacity)
{
    wifi_hal_capability_t cap;
    UINT b, bit, mask = 0;
    size_t used = 0;
    if (count) *count = 0;
    if (!count || !widths || !capacity || radio < 0 || wifi_getHalCapability(&cap) ||
        !cap.wifi_prop.numRadios || cap.wifi_prop.numRadios > MAX_NUM_RADIOS ||
        (UINT)radio >= cap.wifi_prop.numRadios ||
        cap.wifi_prop.radiocap[radio].numSupportedFreqBand > MAX_NUM_FREQ_BAND) return -1;
    for (b = 0; b < cap.wifi_prop.radiocap[radio].numSupportedFreqBand; ++b)
        mask |= (UINT)cap.wifi_prop.radiocap[radio].channelWidth[b];
    if (mask & ~0x3fu) return -1;
    for (bit = 1; bit <= WIFI_CHANNELBANDWIDTH_320MHZ; bit <<= 1)
        if (mask & bit) {
            if (used == capacity) return -1;
            widths[used++] = (wifi_channelBandwidth_t)bit;
        }
    *count = used;
    return used ? 0 : -1;
}
/* PUBLIC_INTERFACE */
/** Round-trip a legacy SSID, restoring it even when verification fails. */
INT test_utils_setValidSSID(INT radio, INT ap, INT position)
{
    char original[33], actual[33];
    int result, restored;
    (void)radio;
    (void)position;
    if (wifi_getSSIDName(ap, original)) return -1;
    result = wifi_setSSIDName(ap, TEST_WIFI_HAL_VALID_SSID);
    if (!result) result = wifi_getSSIDName(ap, actual) || strcmp(actual, TEST_WIFI_HAL_VALID_SSID);
    restored = wifi_setSSIDName(ap, original);
    return result || restored ? -1 : 0;
}
/* PUBLIC_INTERFACE */
/** Reject a clearly out-of-range VAP through the real public symbol. */
INT test_utils_setInValidIndexSSID(INT radio, INT ap, INT position)
{
    (void)radio; (void)ap; (void)position;
    return wifi_setSSIDName(MAX_NUM_RADIOS * MAX_NUM_VAP_PER_RADIO, TEST_WIFI_HAL_VALID_SSID) == 0 ? -1 : 0;
}
/* PUBLIC_INTERFACE */
/** Reject NULL string input through the real public symbol. */
INT test_utils_setNULLSSID(INT radio, INT ap, INT position)
{
    (void)radio; (void)position;
    return wifi_setSSIDName(ap, NULL) == 0 ? -1 : 0;
}
