#include "test_support.h"

static UINT notifications;
static INT on_station(INT ap, wifi_bss_info_t *bss, wifi_station_stats_t *stats)
{
    CU_ASSERT(ap >= 0);
    CU_ASSERT_PTR_NOT_NULL(bss);
    CU_ASSERT_PTR_NOT_NULL(stats);
    ++notifications;
    return 0;
}
static void station_lifecycle(void)
{
    wifi_station_stats_t stats;
    wifi_bss_info_t *bss = NULL;
    wifi_radio_operationParam_t op;
    wifi_channel_t channel;
    UINT count = 0;
    INT sta;
    WIFI_PREPARE();
    sta = wifi_test_index(wifi_vap_mode_sta, 0);
    CU_ASSERT_FATAL(sta >= 0);
    CU_ASSERT_EQUAL_FATAL(wifi_getRadioOperatingParameters(0, &op), 0);
    channel.band = op.band;
    channel.channel = (INT)op.channel;
    notifications = 0;
    wifi_staConnectionStatus_callback_register(on_station);
    CU_ASSERT_EQUAL_FATAL(wifi_findNetworks(sta, &channel, &bss, &count), 0);
    CU_ASSERT(count == 0 || bss != NULL);
    if (count && bss) {
        CU_ASSERT_EQUAL(wifi_connect(sta, bss), 0);
        CU_ASSERT_EQUAL(wifi_getStationStats(sta, &stats), 0);
        CU_ASSERT_EQUAL(stats.connect_status, wifi_connection_status_connected);
#ifdef BUILD_LINUX
        CU_ASSERT_EQUAL(notifications, 1);
#endif
    }
    free(bss);
    CU_ASSERT_EQUAL(wifi_disconnect(sta), 0);
    CU_ASSERT_EQUAL(wifi_getStationStats(sta, &stats), 0);
    CU_ASSERT_EQUAL(stats.connect_status, wifi_connection_status_disconnected);
    CU_ASSERT_NOT_EQUAL(wifi_connect(sta, NULL), 0);
    CU_ASSERT_NOT_EQUAL(wifi_getStationStats(sta, NULL), 0);
    CU_ASSERT_NOT_EQUAL(wifi_disconnect(-1), 0);
    wifi_staConnectionStatus_callback_register(NULL);
}

/* PUBLIC_INTERFACE */
/** Register station lifecycle and invalid-input checks against public symbols. */
int test_wifi_sta_register(void)
{
    static const wifi_test_case_t cases[] = { WIFI_CASE(station_lifecycle) };
    return WIFI_REGISTER("[L1 wifi-sta]", cases);
}
