#ifndef WIFI_HAL_TEST_BACKEND_H
#define WIFI_HAL_TEST_BACKEND_H
#ifndef BUILD_LINUX
#error "Linux reference controls must not enter vendor builds"
#endif
#include "wifi_hal.h"
#include <stddef.h>

#define WIFI_TEST_VAPS (MAX_NUM_RADIOS * MAX_NUM_VAP_PER_RADIO)
/* Bounded reference storage, not platform configuration or an advertised HAL limit. */
#define WIFI_TEST_ACL 16
typedef struct {
    ULONG resets;
    INT carrier, tx_chain, rx_chain;
    BOOL auto_ack, igmp, reverse, decline, color_enabled;
    UCHAR color;
    wifi_dl_mu_type_t downlink;
    wifi_ul_mu_type_t uplink;
    wifi_dl_data_ack_type_t ack;
    BOOL ieee80211h, dcs_scanning;
    INT dcs_interval, dcs_dwell;
    CHAR dcs_pool[256], ext_channel[32], basic_rates[128], operational_rates[128];
} wifi_test_radio_extra_t;
typedef struct {
    UINT retry, high_threshold, high_watermark, high_reached;
    ULONG high_date;
    ULLONG associations;
    INT vlan;
    BOOL vlan_enabled, country_ie, layer2, downstream, bss_load, proxy_arp, p2p;
    BOOL ft_resource;
    INT csa_deauth;
    INT filter_mode, scan_filter;
    CHAR scan_ssid[33];
    CHAR bridge_ip[46], bridge_subnet[46];
    wifi_key_multi_psk_t keys[8];
    UINT key_count;
    mac_address_t acl[WIFI_TEST_ACL];
    UINT acl_count;
    wifi_radius_setting_t radius;
    wifi_FastTransitionConfig_t ft;
    UINT neighbor_count;
    wifi_NeighborReport_t neighbors[8];
} wifi_test_ap_extra_t;
typedef struct {
    BOOL initialized;
    UINT radios;
    wifi_radio_operationParam_t radio[MAX_NUM_RADIOS];
    wifi_vap_info_map_t map[MAX_NUM_RADIOS];
    wifi_station_stats_t station[WIFI_TEST_VAPS];
    BOOL stats_enabled[MAX_NUM_RADIOS];
    BOOL detailed_stats_enabled[MAX_NUM_RADIOS];
    BOOL interval_ready[MAX_NUM_RADIOS];
    ULONG clock, bytes[MAX_NUM_RADIOS], start[MAX_NUM_RADIOS];
    ULONG elapsed[MAX_NUM_RADIOS];
    BOOL steering;
    char group[64];
    INT thresholds[MAX_NUM_RADIOS][5];
    BOOL managed[WIFI_TEST_VAPS];
    mac_address_t client[WIFI_TEST_VAPS];
    /* Configuring steering is not an association event. */
    BOOL client_configured[WIFI_TEST_VAPS];
    mac_address_t steering_client[WIFI_TEST_VAPS];
    wifi_steering_clientConfig_t client_config[WIFI_TEST_VAPS];
    wifi_scanResults_callback scan_cb;
    wifi_staConnectionStatus_callback sta_cb;
    wifi_newApAssociatedDevice_callback assoc_cb;
    wifi_apDisassociatedDevice_callback disassoc_cb;
    wifi_apDeAuthEvent_callback deauth_cb;
    wifi_receivedMgmtFrame_callback mgmt_cb;
    wifi_steering_eventCB_t steering_cb;
    wifi_BTMQueryRequest_callback query_cb[WIFI_TEST_VAPS];
    wifi_BTMResponse_callback response_cb[WIFI_TEST_VAPS];
    wifi_RMBeaconReport_callback beacon_cb[WIFI_TEST_VAPS];
    UCHAR token[WIFI_TEST_VAPS];
    BOOL scan_pending[MAX_NUM_RADIOS];
    wifi_bss_info_t scan_result[MAX_NUM_RADIOS];
    wifi_test_radio_extra_t radio_extra[MAX_NUM_RADIOS];
    wifi_test_ap_extra_t ap_extra[WIFI_TEST_VAPS];
    wifi_radio_operationParam_t factory_radio[MAX_NUM_RADIOS];
    BOOL greylist, led[MAX_NUM_RADIOS];
    wifi_radiusEapFailure_callback radius_cb;
    wifi_apStatusCode_callback status_cb;
    wifi_stamode_callback stamode_cb;
    wifi_handshake_callback handshake_cb;
    wifi_radiusFallback_failover_callback fallback_cb;
    wifi_apFrameDropUnencrypted_callback drop_cb;
    wifi_csi_callback csi_cb;
    wifi_hal_frame_hook_fn_t frame_hook;
    wifi_vapstatus_callback vapstatus_cb;
    wifi_analytics_callback analytics_cb;
    wifi_wpsEvent_callback wps_cb;
    wifi_apAuthEvent_callback auth_cb, authenticated_cb;
    wifi_apAssociatedDevice_callback associated_cb;
    wifi_chan_eventCB_t channel_cb;
    wifi_steerTriggered_callback trigger_cb;
    wifi_anqp_request_callback_t anqp_cb;
    wifi_dppAuthResponse_callback_t dpp_auth_cb;
    wifi_dppConfigRequest_callback_t dpp_config_cb;
    wifi_dppConfigResult_callback_t dpp_result_cb;
    wifi_dppReconfigAnnounce_callback_t dpp_announce_cb;
    wifi_dppReconfigAuthResponse_callback_t dpp_reauth_cb;
} wifi_test_state_t;
extern wifi_test_state_t wifi_test_state;

/* PUBLIC_INTERFACE */
/** Clear model state and callbacks, selecting 1..MAX_NUM_RADIOS radios. */
int wifi_test_reset(UINT radios);
/* PUBLIC_INTERFACE */
/** Advance virtual time and deterministic counters; no sleeping or worker threads. */
void wifi_test_advance(UINT seconds);
/* PUBLIC_INTERFACE */
/** Fail the next model-owned allocation once, then automatically recover. */
void wifi_test_fail_allocation(void);
/* PUBLIC_INTERFACE */
/** Allocate zero-filled caller-owned result memory, honoring one-shot failures. */
void *wifi_test_allocate(size_t count, size_t size);
/* PUBLIC_INTERFACE */
/** Return whether a signed radio index belongs to initialized topology. */
int wifi_test_radio_valid(INT index);
/* PUBLIC_INTERFACE */
/** Look up a VAP by public index in initialized topology; NULL if absent. */
wifi_vap_info_t *wifi_test_vap(INT index);
/* PUBLIC_INTERFACE */
/** Complete pending scans and dispatch borrowed callback results synchronously. */
int wifi_test_dispatch(void);
/* PUBLIC_INTERFACE */
/** Inject association/disassociation and dispatch matching public AP callbacks. */
int wifi_test_client_event(INT ap, BOOL connected);
/* PUBLIC_INTERFACE */
/** Inject one BTM query/response and one autonomous RRM report through registered ABIs. */
int wifi_test_management_event(INT ap);
/* PUBLIC_INTERFACE */
/** Validate a security structure without mutating model state. */
int wifi_test_security_valid(const wifi_vap_security_t *security);
/* PUBLIC_INTERFACE */
/** Clear per-VAP callbacks, clients and compatibility settings on removal/reset. */
void wifi_test_clear_vap_runtime(UINT ap);
#endif
