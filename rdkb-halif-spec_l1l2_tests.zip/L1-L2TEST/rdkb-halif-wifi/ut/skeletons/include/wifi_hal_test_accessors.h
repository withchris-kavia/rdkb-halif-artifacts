#ifndef WIFI_HAL_TEST_ACCESSORS_H
#define WIFI_HAL_TEST_ACCESSORS_H
#include <string.h>
#include <stdio.h>
#include "wifi_hal_test_backend.h"

static inline int ref_mac(const CHAR *text, mac_address_t mac)
{
    UINT i;
    if (!text || strlen(text) != 17) return 0;
    for (i = 0; i < 6; ++i) {
        UINT digit, value = 0;
        if (i && text[i * 3 - 1] != ':') return 0;
        for (digit = 0; digit < 2; ++digit) {
            unsigned char c = (unsigned char)text[i * 3 + digit];
            if (c >= '0' && c <= '9') value = value * 16 + c - '0';
            else if (c >= 'a' && c <= 'f') value = value * 16 + c - 'a' + 10;
            else if (c >= 'A' && c <= 'F') value = value * 16 + c - 'A' + 10;
            else return 0;
        }
        mac[i] = (UCHAR)value;
    }
    return 1;
}

static inline void ref_mac_text(const UCHAR *mac, CHAR *text)
{
    sprintf(text, "%02x:%02x:%02x:%02x:%02x:%02x",
            mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

static inline int ref_ap(INT ap)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    return vap && vap->vap_mode == wifi_vap_mode_ap;
}

/* Each accessor uses an explicit typed field, never an untyped property bag.
 * Setters validate before changing state; getters leave output untouched on error.
 */
#define RADIO_GET(Name, Type, Field) \
    /* PUBLIC_INTERFACE */ \
    /** Read a radio setting from initialized model state. */ \
    INT Name(INT radio, Type *out) { \
        if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS; \
        *out = (Type)(Field); return WIFI_HAL_SUCCESS; \
    }
#define RADIO_SET(Name, Type, Field, Valid) \
    /* PUBLIC_INTERFACE */ \
    /** Validate and update one radio setting without affecting other radios. */ \
    INT Name(INT radio, Type value) { \
        if (!wifi_test_radio_valid(radio)) return WIFI_HAL_INVALID_ARGUMENTS; \
        if (!(Valid)) return WIFI_HAL_INVALID_VALUE; \
        Field = value; return WIFI_HAL_SUCCESS; \
    }
#define AP_GET(Name, Type, Field) \
    /* PUBLIC_INTERFACE */ \
    /** Read an AP setting; STA-role and absent indices are rejected. */ \
    INT Name(INT ap, Type *out) { \
        wifi_vap_info_t *vap = wifi_test_vap(ap); \
        if (!vap || vap->vap_mode != wifi_vap_mode_ap || !out) return WIFI_HAL_INVALID_ARGUMENTS; \
        *out = (Type)(Field); return WIFI_HAL_SUCCESS; \
    }
#define AP_SET(Name, Type, Field, Valid) \
    /* PUBLIC_INTERFACE */ \
    /** Validate and atomically update one AP setting in the shared VAP state. */ \
    INT Name(INT ap, Type value) { \
        wifi_vap_info_t *vap = wifi_test_vap(ap); \
        if (!vap || vap->vap_mode != wifi_vap_mode_ap) return WIFI_HAL_INVALID_ARGUMENTS; \
        if (!(Valid)) return WIFI_HAL_INVALID_VALUE; \
        Field = value; return WIFI_HAL_SUCCESS; \
    }
#define RADIO_BOOL(Get, Set, Field) \
    RADIO_GET(Get, BOOL, Field) \
    RADIO_SET(Set, BOOL, Field, value <= TRUE)
#define AP_BOOL(Get, Set, Field) \
    AP_GET(Get, BOOL, Field) \
    AP_SET(Set, BOOL, Field, value <= TRUE)
#define R wifi_test_state.radio[radio]
#define RX wifi_test_state.radio_extra[radio]
#define B vap->u.bss_info
#define AX wifi_test_state.ap_extra[ap]
#endif
