#include <limits.h>
#include <stdio.h>
#include <string.h>
#include "wifi_hal_test_accessors.h"

#define RADIO_TEXT(Name, Value) \
    /* PUBLIC_INTERFACE */ \
    /** Copy a reference capability string into the HAL-sized caller buffer. */ \
    INT Name(INT radio, CHAR *out) { \
        if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS; \
        strcpy(out, Value); return WIFI_HAL_SUCCESS; \
    }
#define RADIO_TRUE(Name) \
    /* PUBLIC_INTERFACE */ \
    /** Report a supported reference configuration capability. */ \
    INT Name(INT radio, BOOL *out) { \
        if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS; \
        *out = TRUE; return WIFI_HAL_SUCCESS; \
    }
RADIO_GET(wifi_getRadioChannel, ULONG, R.channel)
RADIO_BOOL(wifi_getRadioAutoChannelEnable, wifi_setRadioAutoChannelEnable, R.autoChannelEnabled)
RADIO_BOOL(wifi_getRadioDCSEnable, wifi_setRadioDCSEnable, R.DCSEnabled)
RADIO_BOOL(wifi_getRadioReverseDirectionGrantEnable, wifi_setRadioReverseDirectionGrantEnable, RX.reverse)
RADIO_BOOL(wifi_getRadioDeclineBARequestEnable, wifi_setRadioDeclineBARequestEnable, RX.decline)
RADIO_BOOL(wifi_getRadio11nGreenfieldEnable, wifi_setRadio11nGreenfieldEnable, R.greenFieldEnable)
RADIO_BOOL(wifi_getRadioIEEE80211hEnabled, wifi_setRadioIEEE80211hEnabled, RX.ieee80211h)
RADIO_BOOL(wifi_getRadioDcsScanning, wifi_setRadioDcsScanning, RX.dcs_scanning)
RADIO_GET(wifi_getRadioAutoChannelRefreshPeriod, ULONG, R.autoChanRefreshPeriod)
RADIO_SET(wifi_setRadioAutoChannelRefreshPeriod, ULONG, R.autoChanRefreshPeriod, value <= UINT_MAX)
RADIO_GET(wifi_getRadioBeaconPeriod, UINT, R.beaconInterval)
RADIO_SET(wifi_setRadioBeaconPeriod, UINT, R.beaconInterval, value >= 15 && value <= 65535)
RADIO_GET(wifi_getRadioTxChainMask, INT, RX.tx_chain)
RADIO_SET(wifi_setRadioTxChainMask, INT, RX.tx_chain, value >= 1 && value <= 4)
RADIO_GET(wifi_getRadioRxChainMask, INT, RX.rx_chain)
RADIO_SET(wifi_setRadioRxChainMask, INT, RX.rx_chain, value >= 1 && value <= 4)
RADIO_GET(wifi_getRadioDcsDwelltime, INT, RX.dcs_dwell)
RADIO_SET(wifi_setRadioDcsDwelltime, INT, RX.dcs_dwell, value > 0 && value <= 1000)
RADIO_TEXT(wifi_getRadioMaxBitRate, "600")
RADIO_TEXT(wifi_getRadioSupportedStandards, "a,b,g,n,ac,ax")
RADIO_TEXT(wifi_getRadioTransmitPowerSupported, "0,25,50,75,100")
RADIO_TEXT(wifi_getRadioSupportedDataTransmitRates, "1,2,5.5,6,9,11,12,18,24,36,48,54")
RADIO_TEXT(wifi_getRadioSupportedFrequencyBands,
           R.band == WIFI_FREQUENCY_2_4_BAND ? "2.4GHz" :
           R.band == WIFI_FREQUENCY_5_BAND ? "5GHz" : "6GHz")
RADIO_TRUE(wifi_getRadioAutoChannelSupported)
RADIO_TRUE(wifi_getRadioDCSSupported)
RADIO_TRUE(wifi_getRadioDfsSupport)
RADIO_TRUE(wifi_getRadioAutoChannelRefreshPeriodSupported)
RADIO_TRUE(wifi_getRadioIEEE80211hSupported)
RADIO_TRUE(wifi_getRadio11nGreenfieldSupported)

/* PUBLIC_INTERFACE */
/** Report the compile-time public HAL version, independent of host libraries. */
INT wifi_getHalVersion(CHAR *out)
{
    if (!out) return WIFI_HAL_INVALID_ARGUMENTS;
    sprintf(out, "%d.%d", WIFI_HAL_MAJOR_VERSION, WIFI_HAL_MINOR_VERSION);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Count live initialized radios. */
INT wifi_getRadioNumberOfEntries(ULONG *out)
{
    if (!out) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.initialized) return WIFI_HAL_NOT_READY;
    *out = wifi_test_state.radios;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Count current membership rather than maximum VAP capacity. */
INT wifi_getSSIDNumberOfEntries(ULONG *out)
{
    UINT radio;
    if (!out) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.initialized) return WIFI_HAL_NOT_READY;
    *out = 0;
    for (radio = 0; radio < wifi_test_state.radios; ++radio) *out += wifi_test_state.map[radio].num_vaps;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Apply a recognized country to every live radio after validating it on the first. */
INT wifi_pushCountryCode(CHAR *value)
{
    UINT radio;
    INT status;
    if (!wifi_test_state.initialized) return WIFI_HAL_NOT_READY;
    status = wifi_setRadioCountryCode(0, value);
    if (status) return status;
    for (radio = 1; radio < wifi_test_state.radios; ++radio)
        wifi_test_state.radio[radio].countryCode = wifi_test_state.radio[0].countryCode;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return the selected radio's frequency band. */
INT wifi_getRadioOperatingFrequencyBand(INT radio, CHAR *out)
{ return wifi_getRadioSupportedFrequencyBands(radio, out); }
/* PUBLIC_INTERFACE */
/** Validate channel updates through the canonical radio operation setter. */
INT wifi_setRadioChannel(INT radio, ULONG channel)
{
    wifi_radio_operationParam_t op;
    if (!wifi_test_radio_valid(radio)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (channel > UINT_MAX) return WIFI_HAL_INVALID_VALUE;
    op = R;
    op.channel = (UINT)channel;
    return wifi_setRadioOperatingParameters((UINT)radio, &op);
}
/* PUBLIC_INTERFACE */
/** Push the same validated channel immediately. */
INT wifi_pushRadioChannel(INT radio, UINT channel) { return wifi_setRadioChannel(radio, channel); }
/* PUBLIC_INTERFACE */
/** Atomically change channel, width and CSA count through shared validation. */
INT wifi_pushRadioChannel2(INT radio, UINT channel, UINT width, UINT beacons)
{
    wifi_radio_operationParam_t op;
    if (!wifi_test_radio_valid(radio)) return WIFI_HAL_INVALID_ARGUMENTS;
    op = R;
    if (width != 20 && width != 40 && width != 80) return WIFI_HAL_UNSUPPORTED;
    op.channel = channel;
    op.channelWidth = width == 20 ? WIFI_CHANNELBANDWIDTH_20MHZ :
                      width == 40 ? WIFI_CHANNELBANDWIDTH_40MHZ : WIFI_CHANNELBANDWIDTH_80MHZ;
    op.csa_beacon_count = beacons;
    return wifi_setRadioOperatingParameters((UINT)radio, &op);
}
/* PUBLIC_INTERFACE */
/** Enumerate the channel subset also advertised by wifi_getHalCapability. */
INT wifi_getRadioPossibleChannels(INT radio, CHAR *out)
{
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, radio == 1 ? "36,40,44,48" : "1,2,3,4,5,6,7,8,9,10,11");
    return WIFI_HAL_SUCCESS;
}
#ifdef WIFI_HAL_VERSION_3_PHASE2
/* PUBLIC_INTERFACE */
/** Initialize the caller-owned list with the active primary channel. */
INT wifi_getRadioChannelsInUse(wifi_radio_index_t index, wifi_channels_list_t *out)
{
    INT radio = (INT)index;
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(out, 0, sizeof(*out));
    out->num_channels = 1;
    out->channels_list[0] = (INT)R.channel;
    return WIFI_HAL_SUCCESS;
}
#else
/* PUBLIC_INTERFACE */
/** Format the single active primary channel. */
INT wifi_getRadioChannelsInUse(INT radio, CHAR *out)
{
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    sprintf(out, "%u", R.channel);
    return WIFI_HAL_SUCCESS;
}
#endif
/* PUBLIC_INTERFACE */
/** Return the current legacy standard string and mode flags. */
INT wifi_getRadioStandard(INT radio, CHAR *out, BOOL *g, BOOL *n, BOOL *ac)
{
    if (!wifi_test_radio_valid(radio) || !out || !g || !n || !ac) return WIFI_HAL_INVALID_ARGUMENTS;
    *g = R.variant == WIFI_80211_VARIANT_G;
    *n = R.variant == WIFI_80211_VARIANT_N;
    *ac = R.variant == WIFI_80211_VARIANT_AC;
    strcpy(out, *g ? "g" : *n ? "n" : *ac ? "ac" : R.variant == WIFI_80211_VARIANT_AX ? "ax" : "auto");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Read the modeled operating standard with a non-pure default. */
INT wifi_getRadioMode(INT radio, CHAR *out, UINT *pure)
{
    BOOL g, n, ac;
    INT status;
    if (!pure) return WIFI_HAL_INVALID_ARGUMENTS;
    status = wifi_getRadioStandard(radio, out, &g, &n, &ac);
    if (!status) *pure = 0;
    return status;
}
/* PUBLIC_INTERFACE */
/** Accept exact common mode strings without modifying state on an unsupported mode. */
INT wifi_setRadioMode(INT radio, CHAR *mode, UINT pure)
{
    if (!wifi_test_radio_valid(radio) || !mode) return WIFI_HAL_INVALID_ARGUMENTS;
    if (pure) return WIFI_HAL_UNSUPPORTED;
    if (!strcmp(mode, "g")) R.variant = WIFI_80211_VARIANT_G;
    else if (!strcmp(mode, "n")) R.variant = WIFI_80211_VARIANT_N;
    else if (!strcmp(mode, "ac")) R.variant = WIFI_80211_VARIANT_AC;
    else if (!strcmp(mode, "ax")) R.variant = WIFI_80211_VARIANT_AX;
    else return WIFI_HAL_UNSUPPORTED;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Honor explicit legacy only-flags, rejecting contradictory combinations. */
INT wifi_setRadioChannelMode(INT radio, CHAR *mode, BOOL g, BOOL n, BOOL ac)
{
    if (!mode || g > TRUE || n > TRUE || ac > TRUE || (UINT)g + n + ac > 1)
        return WIFI_HAL_INVALID_ARGUMENTS;
    return wifi_setRadioMode(radio, g ? "g" : n ? "n" : ac ? "ac" : mode, 0);
}
/* PUBLIC_INTERFACE */
/** Validate synchronous radio apply adapters. */
INT wifi_pushRadioChannelMode(INT radio) { return wifi_applyRadioSettings(radio); }
/* PUBLIC_INTERFACE */
/** Apply the already validated TX chain setting. */
INT wifi_pushRadioTxChainMask(INT radio) { return wifi_applyRadioSettings(radio); }
/* PUBLIC_INTERFACE */
/** Apply the already validated RX chain setting. */
INT wifi_pushRadioRxChainMask(INT radio) { return wifi_applyRadioSettings(radio); }

#define RADIO_STRING(Get, Set, Field, Default) \
    /* PUBLIC_INTERFACE */ \
    /** Copy a bounded compatibility string to a caller's HAL-sized buffer. */ \
    INT Get(INT radio, CHAR *out) { \
        if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS; \
        strcpy(out, Field[0] ? Field : Default); return WIFI_HAL_SUCCESS; \
    } \
    /* PUBLIC_INTERFACE */ \
    /** Reject overlong strings before updating isolated compatibility state. */ \
    INT Set(INT radio, CHAR *value) { \
        if (!wifi_test_radio_valid(radio) || !value) return WIFI_HAL_INVALID_ARGUMENTS; \
        if (!value[0] || strlen(value) >= sizeof(Field)) return WIFI_HAL_INVALID_VALUE; \
        strcpy(Field, value); return WIFI_HAL_SUCCESS; \
    }
RADIO_STRING(wifi_getRadioDCSChannelPool, wifi_setRadioDCSChannelPool, RX.dcs_pool, "")
RADIO_STRING(wifi_getRadioExtChannel, wifi_setRadioExtChannel, RX.ext_channel, "Auto")
RADIO_STRING(wifi_getRadioBasicDataTransmitRates, wifi_setRadioBasicDataTransmitRates, RX.basic_rates, "1,2")
RADIO_STRING(wifi_getRadioOperationalDataTransmitRates, wifi_setRadioOperationalDataTransmitRates,
             RX.operational_rates, "1,2,5.5,6,9,11,12,18,24,36,48,54")
/* PUBLIC_INTERFACE */
/** Read legacy textual guard interval. */
INT wifi_getRadioGuardInterval(INT radio, CHAR *out)
{
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, R.guardInterval == wifi_guard_interval_400 ? "400nsec" :
                R.guardInterval == wifi_guard_interval_800 ? "800nsec" :
                R.guardInterval == wifi_guard_interval_1600 ? "1600nsec" :
                R.guardInterval == wifi_guard_interval_3200 ? "3200nsec" : "Auto");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Map exact guard strings onto the typed radio setter. */
INT wifi_setRadioGuardInterval(INT radio, CHAR *value)
{
    if (!value) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!strcmp(value, "Auto")) return wifi_setGuardInterval(radio, wifi_guard_interval_auto);
    if (!strcmp(value, "400nsec")) return wifi_setGuardInterval(radio, wifi_guard_interval_400);
    if (!strcmp(value, "800nsec")) return wifi_setGuardInterval(radio, wifi_guard_interval_800);
    if (!strcmp(value, "1600nsec")) return wifi_setGuardInterval(radio, wifi_guard_interval_1600);
    if (!strcmp(value, "3200nsec")) return wifi_setGuardInterval(radio, wifi_guard_interval_3200);
    return WIFI_HAL_INVALID_VALUE;
}
/* PUBLIC_INTERFACE */
/** Read both DCS scan timing values after validating every output. */
INT wifi_getRadioDCSScanTime(INT radio, INT *interval, INT *dwell)
{
    if (!wifi_test_radio_valid(radio) || !interval || !dwell) return WIFI_HAL_INVALID_ARGUMENTS;
    *interval = RX.dcs_interval;
    *dwell = RX.dcs_dwell;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Validate scan timing atomically; no background host scan is launched. */
INT wifi_setRadioDCSScanTime(INT radio, INT interval, INT dwell)
{
    if (!wifi_test_radio_valid(radio)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (interval <= 0 || dwell <= 0 || dwell > 1000) return WIFI_HAL_INVALID_VALUE;
    RX.dcs_interval = interval;
    RX.dcs_dwell = dwell;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Reference signal-level history has one deterministic sample. */
INT wifi_getRadioStatsReceivedSignalLevel(INT radio, INT index, INT *out)
{
    if (!wifi_test_radio_valid(radio) || !out || index != 0) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = -45;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Read the reference client inactivity timeout in seconds. */
INT wifi_getRadioClientInactivityTimout(INT radio, INT *out)
{
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = 300;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Enumerate live capability channels into a bounded caller-owned map. */
INT wifi_getRadioChannels(INT radio, wifi_channelMap_t *out, INT capacity)
{
    INT i, count;
    if (!wifi_test_radio_valid(radio) || !out || capacity < 0) return WIFI_HAL_INVALID_ARGUMENTS;
    count = radio == 1 ? 4 : 11;
    if (capacity < count) return WIFI_HAL_INVALID_VALUE;
    for (i = 0; i < count; ++i) {
        memset(&out[i], 0, sizeof(out[i]));
        out[i].ch_number = radio == 1 ? 36 + 4 * i : i + 1;
    }
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Zero-wait DFS is not advertised by the in-memory reference backend. */
INT wifi_isZeroDFSSupported(UINT radio, BOOL *out)
{
    if (!wifi_test_radio_valid((INT)radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = FALSE;
    return WIFI_HAL_SUCCESS;
}
