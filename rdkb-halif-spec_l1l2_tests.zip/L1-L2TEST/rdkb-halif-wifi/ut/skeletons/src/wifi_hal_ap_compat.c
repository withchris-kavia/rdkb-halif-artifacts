#include <stdio.h>
#include <string.h>
#include "wifi_hal_test_accessors.h"

static wifi_vap_info_t *ap_vap(INT ap)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    return vap && vap->vap_mode == wifi_vap_mode_ap ? vap : NULL;
}

AP_BOOL(wifi_getApEnable, wifi_setApEnable, B.enabled)
AP_BOOL(wifi_getApSsidAdvertisementEnable, wifi_setApSsidAdvertisementEnable, B.showSsid)
AP_BOOL(wifi_getApWmmEnable, wifi_setApWmmEnable, B.wmm_enabled)
AP_BOOL(wifi_getApWmmUapsdEnable, wifi_setApWmmUapsdEnable, B.UAPSDEnabled)
AP_BOOL(wifi_getApIsolationEnable, wifi_setApIsolationEnable, B.isolation)
AP_GET(wifi_getApRetryLimit, UINT, AX.retry)
AP_SET(wifi_setApRetryLimit, UINT, AX.retry, value <= 255)
AP_GET(wifi_getApMaxAssociatedDevices, UINT, B.bssMaxSta)
AP_SET(wifi_setApMaxAssociatedDevices, UINT, B.bssMaxSta, value <= 512)
AP_GET(wifi_getApManagementFramePowerControl, INT, B.mgmtPowerControl)
AP_SET(wifi_setApManagementFramePowerControl, INT, B.mgmtPowerControl, value >= -20 && value <= 0)
AP_GET(wifi_getApMacAddressControlMode, INT, AX.filter_mode)
AP_SET(wifi_setApMacAddressControlMode, INT, AX.filter_mode, value >= 0 && value <= 2)
AP_SET(wifi_setApVlanID, INT, AX.vlan, value >= 1 && value <= 4094)
AP_GET(wifi_getInterworkingAccessNetworkType, UINT, B.interworking.interworking.accessNetworkType)
AP_SET(wifi_setInterworkingAccessNetworkType, INT, B.interworking.interworking.accessNetworkType,
       (value >= 0 && value <= 5) || value == 14 || value == 15)
AP_BOOL(wifi_getApInterworkingServiceEnable, wifi_setApInterworkingServiceEnable,
        B.interworking.interworking.interworkingEnabled)
AP_BOOL(wifi_getCountryIe, wifi_setCountryIe, B.interworking.passpoint.countryIE)
AP_BOOL(wifi_getLayer2TrafficInspectionFiltering, wifi_setLayer2TrafficInspectionFiltering,
        B.interworking.passpoint.l2tif)
AP_BOOL(wifi_getDownStreamGroupAddress, wifi_setDownStreamGroupAddress,
        B.interworking.passpoint.gafDisable)
AP_BOOL(wifi_getBssLoad, wifi_setBssLoad, B.interworking.passpoint.bssLoad)
AP_BOOL(wifi_getProxyArp, wifi_setProxyArp, B.interworking.passpoint.proxyArp)
AP_BOOL(wifi_getApHotspotElement, wifi_pushApHotspotElement, B.bssHotspot)
AP_BOOL(wifi_getP2PCrossConnect, wifi_setP2PCrossConnect,
        B.interworking.passpoint.p2pDisable)
AP_GET(wifi_getApAclDeviceNum, UINT, AX.acl_count)

/* PUBLIC_INTERFACE */
/** Read only AP-role traffic; the deterministic model has no packet errors. */
INT wifi_getWifiTrafficStats(INT ap, wifi_trafficStats_t *out)
{
    if (!ap_vap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(out, 0, sizeof(*out));
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Reset an AP's settings/runtime while retaining its membership and interface identity. */
INT wifi_factoryResetAP(INT ap)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap) return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_clear_vap_runtime((UINT)ap);
    memset(&vap->u.bss_info, 0, sizeof(vap->u.bss_info));
    strcpy(vap->u.bss_info.ssid, "reference-ap");
    vap->u.bss_info.enabled = TRUE;
    vap->u.bss_info.bssMaxSta = 75;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Remove an AP from its live map and clear callbacks/clients before index reuse. */
INT wifi_deleteAp(INT ap)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    wifi_vap_info_map_t *map;
    UINT slot;
    if (!vap) return WIFI_HAL_INVALID_ARGUMENTS;
    map = &wifi_test_state.map[vap->radio_index];
    slot = (UINT)(vap - map->vap_array);
    wifi_test_clear_vap_runtime((UINT)ap);
    memmove(&map->vap_array[slot], &map->vap_array[slot + 1],
            (map->num_vaps - slot - 1) * sizeof(*vap));
    memset(&map->vap_array[--map->num_vaps], 0, sizeof(*vap));
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return the live AP interface name into the caller's HAL-sized buffer. */
INT wifi_getApName(INT ap, CHAR *out)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, vap->vap_name);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Resolve AP radio membership without assuming an index arithmetic formula. */
INT wifi_getApRadioIndex(INT ap, INT *out)
{
    if (!ap_vap(ap)) return WIFI_HAL_INVALID_ARGUMENTS;
    return wifi_getSSIDRadioIndex(ap, out);
}
/* PUBLIC_INTERFACE */
/** AP RTS configuration uses its owning radio's threshold. */
INT wifi_setApRtsThreshold(INT ap, UINT value)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap) return WIFI_HAL_INVALID_ARGUMENTS;
    if (value > 2347) return WIFI_HAL_INVALID_VALUE;
    wifi_test_state.radio[vap->radio_index].rtsThreshold = value;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Clear all AP security fields, including secrets, to open-network defaults. */
INT wifi_setApSecurityReset(INT ap)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(&vap->u.bss_info.security, 0, sizeof(vap->u.bss_info.security));
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Remove security variables through the same reset operation. */
INT wifi_removeApSecVaribles(INT ap) { return wifi_setApSecurityReset(ap); }
/* PUBLIC_INTERFACE */
/** Disable encryption and discard stale keys rather than leaving an inconsistent mode. */
INT wifi_disableApEncryption(INT ap) { return wifi_setApSecurityReset(ap); }
/* PUBLIC_INTERFACE */
/** Report the reference association count for the selected AP. */
INT wifi_getApNumDevicesAssociated(INT ap, ULONG *out)
{
    if (!ap_vap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = wifi_test_state.managed[ap] ? 1 : 0;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return Enabled/Disabled based on both the AP and its radio. */
INT wifi_getApStatus(INT ap, CHAR *out)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, vap->u.bss_info.enabled && wifi_test_state.radio[vap->radio_index].enable ?
           "Enabled" : "Disabled");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Clear the AP VLAN settings atomically. */
INT wifi_resetApVlanCfg(INT ap)
{
    if (!ap_vap(ap)) return WIFI_HAL_INVALID_ARGUMENTS;
    AX.vlan = 0;
    AX.vlan_enabled = FALSE;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Store one of four access-category no-ack bits. */
INT wifi_setApWmmOgAckPolicy(INT ap, INT category, BOOL no_ack)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap || category < 0 || category > 3 || no_ack > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    vap->u.bss_info.wmmNoAck = (vap->u.bss_info.wmmNoAck & ~(1U << category)) |
                              ((UINT)no_ack << category);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Store a bounded textual beacon rate; unsupported rates do not alter state. */
INT wifi_setApBeaconRate(INT ap, char *rate)
{
    static const char *rates[] = {"Default", "1Mbps", "2Mbps", "5.5Mbps", "6Mbps",
                                 "9Mbps", "11Mbps", "12Mbps", "18Mbps", "24Mbps",
                                 "36Mbps", "48Mbps", "54Mbps"};
    wifi_vap_info_t *vap = ap_vap(ap);
    size_t i;
    if (!vap || !rate) return WIFI_HAL_INVALID_ARGUMENTS;
    for (i = 0; i < sizeof(rates) / sizeof(*rates); ++i)
        if (!strcmp(rate, rates[i])) {
            strcpy(vap->u.bss_info.beaconRateCtl, rate);
            return WIFI_HAL_SUCCESS;
        }
    return WIFI_HAL_INVALID_VALUE;
}
/* PUBLIC_INTERFACE */
/** Read the stored beacon rate into a buffer of at least 32 bytes. */
INT wifi_getApBeaconRate(INT ap, char *out)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, vap->u.bss_info.beaconRateCtl[0] ? vap->u.bss_info.beaconRateCtl : "Default");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return selected-view MFP state in legacy textual form. */
INT wifi_getApSecurityMFPConfig(INT ap, CHAR *out)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap || !out) return WIFI_HAL_INVALID_ARGUMENTS;
#ifdef WIFI_HAL_VERSION_3
    strcpy(out, vap->u.bss_info.security.mfp == wifi_mfp_cfg_required ? "Required" :
                vap->u.bss_info.security.mfp == wifi_mfp_cfg_optional ? "Optional" : "Disabled");
#else
    strcpy(out, vap->u.bss_info.security.mfpConfig[0] ?
                vap->u.bss_info.security.mfpConfig : "Disabled");
#endif
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Accept only exact Disabled/Optional/Required strings in either security ABI. */
INT wifi_setApSecurityMFPConfig(INT ap, CHAR *value)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    if (strcmp(value, "Disabled") && strcmp(value, "Optional") && strcmp(value, "Required"))
        return WIFI_HAL_INVALID_VALUE;
#ifdef WIFI_HAL_VERSION_3
    vap->u.bss_info.security.mfp = !strcmp(value, "Required") ? wifi_mfp_cfg_required :
                                  !strcmp(value, "Optional") ? wifi_mfp_cfg_optional : wifi_mfp_cfg_disabled;
#else
    strcpy(vap->u.bss_info.security.mfpConfig, value);
#endif
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Copy complete RADIUS tuning values without exposing partially updated state. */
INT wifi_getApSecurityRadiusSettings(INT ap, wifi_radius_setting_t *out)
{
    if (!ap_vap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = AX.radius;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Store the typed RADIUS tuning structure for this AP only. */
INT wifi_setApSecurityRadiusSettings(INT ap, wifi_radius_setting_t *value)
{
    if (!ap_vap(ap) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    AX.radius = *value;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Set global greylist configuration with boolean validation. */
INT wifi_enableGreylistAccessControl(BOOL value)
{
    if (value > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.greylist = value;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Copy a validated interworking element into live VAP configuration. */
INT wifi_pushApInterworkingElement(INT ap, wifi_InterworkingElement_t *value)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    if (value->accessNetworkType > 15 || value->interworkingEnabled > TRUE ||
        value->internetAvailable > TRUE || value->asra > TRUE || value->esr > TRUE ||
        value->uesa > TRUE || value->venueOptionPresent > TRUE || value->hessOptionPresent > TRUE ||
        !memchr(value->hessid, 0, sizeof(value->hessid))) return WIFI_HAL_INVALID_VALUE;
    vap->u.bss_info.interworking.interworking = *value;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Read the complete stored interworking element. */
INT wifi_getApInterworkingElement(INT ap, wifi_InterworkingElement_t *out)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = vap->u.bss_info.interworking.interworking;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Validate consortium element counts/lengths before replacing the old element. */
INT wifi_pushApRoamingConsortiumElement(INT ap, wifi_roamingConsortiumElement_t *value)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    UINT i;
    if (!vap || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    if (value->wifiRoamingConsortiumCount > 3) return WIFI_HAL_INVALID_VALUE;
    for (i = 0; i < value->wifiRoamingConsortiumCount; ++i)
        if (value->wifiRoamingConsortiumLen[i] < 3 || value->wifiRoamingConsortiumLen[i] > 15)
            return WIFI_HAL_INVALID_VALUE;
    vap->u.bss_info.interworking.roamingConsortium = *value;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Copy the stored bounded roaming consortium element. */
INT wifi_getApRoamingConsortiumElement(INT ap, wifi_roamingConsortiumElement_t *out)
{
    wifi_vap_info_t *vap = ap_vap(ap);
    if (!vap || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = vap->u.bss_info.interworking.roamingConsortium;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Enumerate up to caller capacity; the model does not negotiate TWT sessions. */
INT wifi_getTWTsessions(INT ap, UINT capacity, wifi_twt_sessions_t *out, UINT *count)
{
    if (!ap_vap(ap) || !count || (capacity && !out)) return WIFI_HAL_INVALID_ARGUMENTS;
    *count = 0;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** TWT RF scheduling is not implemented; preserve the caller's session identifier. */
INT wifi_setBroadcastTWTSchedule(INT ap, wifi_twt_params_t params, BOOL create, INT *id)
{
    (void)params;
    if (!ap_vap(ap) || !id || create > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** No TWT sessions exist in the model. */
INT wifi_setTeardownTWTSession(INT ap, INT id)
{
    if (!ap_vap(ap) || id < 0) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Atomically replace at most eight uniquely identified secondary PSKs. */
INT wifi_pushMultiPskKeys(INT ap, wifi_key_multi_psk_t *keys, INT count)
{
    INT i, j;
    if (!ap_vap(ap) || count < 0 || count > 8 || (count && !keys)) return WIFI_HAL_INVALID_ARGUMENTS;
    for (i = 0; i < count; ++i) {
        if (!memchr(keys[i].wifi_keyId, 0, sizeof(keys[i].wifi_keyId)) || !keys[i].wifi_keyId[0] ||
            !memchr(keys[i].wifi_psk, 0, sizeof(keys[i].wifi_psk)) ||
            strlen(keys[i].wifi_psk) < 8 || strlen(keys[i].wifi_psk) > 63) return WIFI_HAL_INVALID_VALUE;
        for (j = 0; j < i; ++j)
            if (!strcmp(keys[i].wifi_keyId, keys[j].wifi_keyId)) return WIFI_HAL_INVALID_VALUE;
    }
    memset(AX.keys, 0, sizeof(AX.keys));
    if (count) memcpy(AX.keys, keys, (size_t)count * sizeof(*keys));
    AX.key_count = (UINT)count;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Copy secondary PSKs only when capacity holds the complete stored collection. */
INT wifi_getMultiPskKeys(INT ap, wifi_key_multi_psk_t *out, INT capacity)
{
    if (!ap_vap(ap) || capacity < 0 || (capacity && !out)) return WIFI_HAL_INVALID_ARGUMENTS;
    if ((UINT)capacity < AX.key_count) return WIFI_HAL_INVALID_VALUE;
    if (AX.key_count) memcpy(out, AX.keys, AX.key_count * sizeof(*out));
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** The reference client uses the primary key, identified by an empty secondary key ID. */
INT wifi_getMultiPskClientKey(INT ap, mac_address_t mac, wifi_key_multi_psk_t *out)
{
    if (!ap_vap(ap) || !mac || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.managed[ap] || memcmp(mac, wifi_test_state.client[ap], 6))
        return WIFI_HAL_INVALID_VALUE;
    memset(out, 0, sizeof(*out));
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return the SSID associated with a typed VAP, or NULL for invalid input. */
const char *get_vap_ssid(wifi_vap_info_t *vap)
{
    if (!vap) return NULL;
    return vap->vap_mode == wifi_vap_mode_ap ? vap->u.bss_info.ssid :
           vap->vap_mode == wifi_vap_mode_sta ? vap->u.sta_info.ssid : NULL;
}
/* PUBLIC_INTERFACE */
/** Return a borrowed bridge name from the supplied VAP. */
const char *get_vap_bridge_name(wifi_vap_info_t *vap) { return vap ? vap->bridge_name : NULL; }
/* PUBLIC_INTERFACE */
/** Copy role-selected security if requested and return its mode, zero on invalid input. */
unsigned int get_vap_security_mode(wifi_vap_info_t *vap, wifi_vap_security_t *out)
{
    const wifi_vap_security_t *security;
    if (!vap || (vap->vap_mode != wifi_vap_mode_ap && vap->vap_mode != wifi_vap_mode_sta)) return 0;
    security = vap->vap_mode == wifi_vap_mode_ap ? &vap->u.bss_info.security : &vap->u.sta_info.security;
    if (out) *out = *security;
    return (unsigned int)security->mode;
}
/* PUBLIC_INTERFACE */
/** Advertise only implemented model AP settings, not RF/WPS provisioning. */
INT wifi_getAPCapabilities(INT ap, wifi_ap_capabilities_t *out)
{
    if (!ap_vap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(out, 0, sizeof(*out));
    out->rtsThresholdSupported = TRUE;
    out->securityModesSupported = wifi_security_mode_none | wifi_security_mode_wpa2_personal |
                                 wifi_security_mode_wpa3_personal | wifi_security_mode_wpa3_transition |
                                 wifi_security_mode_wpa2_enterprise;
    out->WMMSupported = TRUE;
    out->UAPSDSupported = TRUE;
    out->interworkingServiceSupported = TRUE;
    out->BSSTransitionImplemented = TRUE;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** The Linux model is not linked with libhostapd. */
INT wifi_getLibhostapd(BOOL *out)
{
    if (!out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = FALSE;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Do not claim to update an absent libhostapd instance. */
INT wifi_updateLibHostApdConfig(int ap)
{
    return ap_vap(ap) ? WIFI_HAL_UNSUPPORTED : WIFI_HAL_INVALID_ARGUMENTS;
}

/* Registration is resettable and accepts NULL to unregister, like existing HAL callbacks. */
#define REGISTER_VOID(Name, Type, Field) \
    /* PUBLIC_INTERFACE */ \
    /** Register or clear a borrowed callback; no asynchronous thread is created. */ \
    void Name(Type callback) { wifi_test_state.Field = callback; }
#define REGISTER_INT(Name, Type, Field) \
    /* PUBLIC_INTERFACE */ \
    /** Register or clear a callback in resettable model state. */ \
    INT Name(Type callback) { wifi_test_state.Field = callback; return WIFI_HAL_SUCCESS; }
REGISTER_VOID(wifi_radiusEapFailure_callback_register, wifi_radiusEapFailure_callback, radius_cb)
REGISTER_VOID(wifi_apStatusCode_callback_register, wifi_apStatusCode_callback, status_cb)
REGISTER_VOID(wifi_ap_stamode_callback_register, wifi_stamode_callback, stamode_cb)
REGISTER_VOID(wifi_handshake_callback_register, wifi_handshake_callback, handshake_cb)
REGISTER_VOID(wifi_radiusFallback_failover_callback_register, wifi_radiusFallback_failover_callback, fallback_cb)
REGISTER_VOID(wifi_apFrameDropUnencrypted_callback_register, wifi_apFrameDropUnencrypted_callback, drop_cb)
REGISTER_VOID(wifi_csi_callback_register, wifi_csi_callback, csi_cb)
REGISTER_VOID(wifi_hal_register_frame_hook, wifi_hal_frame_hook_fn_t, frame_hook)
REGISTER_INT(wifi_vapstatus_callback_register, wifi_vapstatus_callback, vapstatus_cb)
REGISTER_INT(wifi_hal_analytics_callback_register, wifi_analytics_callback, analytics_cb)
REGISTER_INT(wifi_wpsEvent_callback_register, wifi_wpsEvent_callback, wps_cb)
REGISTER_VOID(wifi_apAuthEvent_callback_register, wifi_apAuthEvent_callback, auth_cb)
REGISTER_VOID(wifi_apAuthenticatedEvent_callback_register, wifi_apAuthEvent_callback, authenticated_cb)
REGISTER_VOID(wifi_apAssociatedDevice_callback_register, wifi_apAssociatedDevice_callback, associated_cb)
REGISTER_INT(wifi_chan_eventRegister, wifi_chan_eventCB_t, channel_cb)
