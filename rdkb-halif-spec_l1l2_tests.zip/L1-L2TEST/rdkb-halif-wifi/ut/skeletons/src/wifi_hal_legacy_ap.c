#include <arpa/inet.h>
#include "wifi_hal_test_accessors.h"

/* PUBLIC_INTERFACE */
/** Read role-selected SSID enablement, including station VAPs. */
INT wifi_getSSIDEnable(INT ap, BOOL *out)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = vap->vap_mode == wifi_vap_mode_ap ? B.enabled : vap->u.sta_info.enabled;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Change role-selected SSID enablement without altering topology. */
INT wifi_setSSIDEnable(INT ap, BOOL enabled)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || enabled > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    if (vap->vap_mode == wifi_vap_mode_ap) B.enabled = enabled;
    else vap->u.sta_info.enabled = enabled;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return SSID operational status, accounting for the parent radio. */
INT wifi_getSSIDStatus(INT ap, CHAR *out)
{
    BOOL enabled;
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!out || wifi_getSSIDEnable(ap, &enabled)) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, enabled && wifi_test_state.radio[vap->radio_index].enable ? "Up" : "Down");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Compatibility status query using the same operational state. */
INT wifi_getSSIDNameStatus(INT ap, CHAR *out) { return wifi_getSSIDStatus(ap, out); }
/* PUBLIC_INTERFACE */
/** Format the live AP BSSID into an 18-byte caller buffer. */
INT wifi_getBaseBSSID(INT ap, CHAR *out)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    ref_mac_text(B.bssid, out);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return the configured interface MAC for either AP or station role. */
INT wifi_getSSIDMACAddress(INT ap, CHAR *out)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    ref_mac_text(vap->vap_mode == wifi_vap_mode_ap ? B.bssid : vap->u.sta_info.mac, out);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Push an SSID through the same bounded setter as immediate configuration. */
INT wifi_pushSSID(INT ap, CHAR *value) { return wifi_setSSIDName(ap, value); }
/* PUBLIC_INTERFACE */
/** Set legacy SSID advertisement for AP VAPs. */
INT wifi_pushSsidAdvertisementEnable(INT ap, BOOL value) { return wifi_setApSsidAdvertisementEnable(ap, value); }
/* PUBLIC_INTERFACE */
/** Push AP advertisement using the canonical setter. */
INT wifi_pushApSsidAdvertisementEnable(INT ap, BOOL value) { return wifi_setApSsidAdvertisementEnable(ap, value); }
/* PUBLIC_INTERFACE */
/** Push AP enablement using the canonical setter. */
INT wifi_pushApEnable(INT ap, BOOL value) { return wifi_setApEnable(ap, value); }
/* PUBLIC_INTERFACE */
/** Look up current AP names rather than deriving an index arithmetically. */
INT wifi_getApIndexFromName(CHAR *name, INT *out)
{
    UINT r, i;
    if (!name || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    for (r = 0; r < wifi_test_state.radios; ++r)
        for (i = 0; i < wifi_test_state.map[r].num_vaps; ++i) {
            wifi_vap_info_t *vap = &wifi_test_state.map[r].vap_array[i];
            if (vap->vap_mode == wifi_vap_mode_ap && !strcmp(vap->vap_name, name)) {
                *out = (INT)vap->vap_index;
                return WIFI_HAL_SUCCESS;
            }
        }
    return WIFI_HAL_INVALID_VALUE;
}
/* PUBLIC_INTERFACE */
/** Create or replace one AP atomically through the canonical map validator. */
INT wifi_createAp(INT ap, INT radio, CHAR *ssid, BOOL hidden)
{
    wifi_vap_info_map_t map;
    wifi_vap_info_t *old;
    UINT i;
    if (!wifi_test_radio_valid(radio) || ap < 0 || ap >= WIFI_TEST_VAPS || !ssid || hidden > TRUE)
        return WIFI_HAL_INVALID_ARGUMENTS;
    if (!ssid[0] || strlen(ssid) > 32) return WIFI_HAL_INVALID_VALUE;
    map = wifi_test_state.map[radio];
    old = wifi_test_vap(ap);
    if (old && old->radio_index != (UINT)radio) return WIFI_HAL_INVALID_VALUE;
    for (i = 0; i < map.num_vaps; ++i)
        if (map.vap_array[i].vap_index == (UINT)ap) break;
    if (i == MAX_NUM_VAP_PER_RADIO) return WIFI_HAL_ERROR;
    if (i == map.num_vaps) ++map.num_vaps;
    memset(&map.vap_array[i], 0, sizeof(map.vap_array[i]));
    map.vap_array[i].vap_index = (UINT)ap;
    map.vap_array[i].radio_index = (UINT)radio;
    map.vap_array[i].vap_mode = wifi_vap_mode_ap;
    sprintf(map.vap_array[i].vap_name, "wlan%d", ap);
    strcpy(map.vap_array[i].u.bss_info.ssid, ssid);
    map.vap_array[i].u.bss_info.enabled = TRUE;
    map.vap_array[i].u.bss_info.showSsid = !hidden;
    map.vap_array[i].u.bss_info.security.mode = wifi_security_mode_none;
    return wifi_createVAP((UINT)radio, &map);
}
/* PUBLIC_INTERFACE */
/** Moving a VAP across radio maps is not atomic in the public legacy API and is unsupported. */
INT wifi_setApRadioIndex(INT ap, INT radio)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!ref_ap(ap) || !wifi_test_radio_valid(radio)) return WIFI_HAL_INVALID_ARGUMENTS;
    return vap->radio_index == (UINT)radio ? WIFI_HAL_SUCCESS : WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Set AP DTIM on its owning radio, honoring the typed radio validation. */
INT wifi_setApDTIMInterval(INT ap, INT interval)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    wifi_radio_operationParam_t op;
    if (!ref_ap(ap) || interval < 1 || interval > 255) return WIFI_HAL_INVALID_ARGUMENTS;
    op = wifi_test_state.radio[vap->radio_index];
    op.dtimPeriod = (UINT)interval;
    return wifi_setRadioOperatingParameters(vap->radio_index, &op);
}
/* PUBLIC_INTERFACE */
/** Set AP beacon period on its owning radio. */
INT wifi_setApBeaconInterval(INT ap, INT interval)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!ref_ap(ap) || interval < 0) return WIFI_HAL_INVALID_ARGUMENTS;
    return wifi_setRadioBeaconPeriod((INT)vap->radio_index, (UINT)interval);
}
AP_GET(wifi_getApRtsThresholdSupported, BOOL, TRUE)
AP_GET(wifi_getApWMMCapability, BOOL, TRUE)
AP_GET(wifi_getApUAPSDCapability, BOOL, TRUE)
AP_GET(wifi_getApInterworkingServiceCapability, BOOL, TRUE)
AP_BOOL(wifi_getApWpsEnable, wifi_setApWpsEnable, B.wps.enable)
AP_SET(wifi_setApVlanEnable, BOOL, AX.vlan_enabled, value <= TRUE)

/* PUBLIC_INTERFACE */
/** Return the supported reference security mode strings. */
INT wifi_getApSecurityModesSupported(INT ap, CHAR *out)
{
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, "None,WPA2-Personal,WPA3-Personal,WPA3-Personal-Transition,WPA2-Enterprise");
    return WIFI_HAL_SUCCESS;
}
static const struct { const CHAR *name; wifi_security_modes_t mode; } modes[] = {
    {"None", wifi_security_mode_none}, {"WPA2-Personal", wifi_security_mode_wpa2_personal},
    {"WPA3-Personal", wifi_security_mode_wpa3_personal},
    {"WPA3-Personal-Transition", wifi_security_mode_wpa3_transition},
    {"WPA2-Enterprise", wifi_security_mode_wpa2_enterprise}
};
/* PUBLIC_INTERFACE */
/** Return the selected typed security mode as an exact legacy name. */
INT wifi_getApSecurityModeEnabled(INT ap, CHAR *out)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    UINT i;
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    for (i = 0; i < sizeof(modes) / sizeof(modes[0]); ++i)
        if (B.security.mode == modes[i].mode) { strcpy(out, modes[i].name); return WIFI_HAL_SUCCESS; }
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Change mode only when existing credentials are valid for it; never synthesize a secret. */
INT wifi_setApSecurityModeEnabled(INT ap, CHAR *name)
{
    wifi_vap_security_t security;
    UINT i;
    if (!name || wifi_getApSecurity(ap, &security)) return WIFI_HAL_INVALID_ARGUMENTS;
    for (i = 0; i < sizeof(modes) / sizeof(modes[0]); ++i) {
        if (strcmp(name, modes[i].name)) continue;
        if ((security.mode == wifi_security_mode_wpa2_enterprise) !=
            (modes[i].mode == wifi_security_mode_wpa2_enterprise) &&
            modes[i].mode != wifi_security_mode_none) return WIFI_HAL_UNSUPPORTED;
        security.mode = modes[i].mode;
        security.encr = modes[i].mode == wifi_security_mode_none ? wifi_encryption_none : wifi_encryption_aes;
        return wifi_setApSecurity(ap, &security);
    }
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Return the legacy beacon security family. */
INT wifi_getApBeaconType(INT ap, CHAR *out)
{
    wifi_vap_security_t security;
    if (!out || wifi_getApSecurity(ap, &security)) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, security.mode == wifi_security_mode_none ? "None" : "11i");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Select open or WPA2-Personal beaconing using validated existing credentials. */
INT wifi_setApBeaconType(INT ap, CHAR *value)
{
    if (!value) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!strcmp(value, "None")) return wifi_setApSecurityModeEnabled(ap, "None");
    if (!strcmp(value, "11i")) return wifi_setApSecurityModeEnabled(ap, "WPA2-Personal");
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Read the encryption mode from typed security. */
INT wifi_getApWpaEncryptionMode(INT ap, CHAR *out)
{
    wifi_vap_security_t security;
    if (!out || wifi_getApSecurity(ap, &security)) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, security.encr == wifi_encryption_aes ? "AES" : "None");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Only AES and open security are modeled; validate the resulting complete configuration. */
INT wifi_setApWpaEncryptionMode(INT ap, CHAR *value)
{
    wifi_vap_security_t security;
    if (!value || wifi_getApSecurity(ap, &security)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!strcmp(value, "AES")) security.encr = wifi_encryption_aes;
    else if (!strcmp(value, "None")) security.encr = wifi_encryption_none;
    else return WIFI_HAL_UNSUPPORTED;
    return wifi_setApSecurity(ap, &security);
}
/* PUBLIC_INTERFACE */
/** Driver-specific integer authentication modes have no portable mapping. */
INT wifi_setApAuthMode(INT ap, INT mode)
{ return !ref_ap(ap) || mode < 0 ? WIFI_HAL_INVALID_ARGUMENTS : WIFI_HAL_UNSUPPORTED; }
/* PUBLIC_INTERFACE */
/** Only open-system basic authentication is supported; shared-key WEP is not. */
INT wifi_setApBasicAuthenticationMode(INT ap, CHAR *mode)
{
    if (!ref_ap(ap) || !mode) return WIFI_HAL_INVALID_ARGUMENTS;
    return !strcmp(mode, "None") ? WIFI_HAL_SUCCESS : WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Copy a configured personal passphrase; never reinterpret the RADIUS union. */
INT wifi_getApSecurityKeyPassphrase(INT ap, CHAR *out)
{
    wifi_vap_security_t security;
    if (!out || wifi_getApSecurity(ap, &security)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (security.mode != wifi_security_mode_wpa2_personal &&
        security.mode != wifi_security_mode_wpa3_personal &&
        security.mode != wifi_security_mode_wpa3_transition) return WIFI_HAL_UNSUPPORTED;
    strcpy(out, security.u.key.key);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Update personal credentials atomically; open APs become WPA2-Personal. */
INT wifi_setApSecurityKeyPassphrase(INT ap, CHAR *value)
{
    wifi_vap_security_t security;
    if (!value || wifi_getApSecurity(ap, &security)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (strlen(value) < 8 || strlen(value) > 63) return WIFI_HAL_INVALID_VALUE;
    if (security.mode == wifi_security_mode_wpa2_enterprise) return WIFI_HAL_UNSUPPORTED;
    if (security.mode == wifi_security_mode_none) security.mode = wifi_security_mode_wpa2_personal;
    security.encr = wifi_encryption_aes;
    strcpy(security.u.key.key, value);
    return wifi_setApSecurity(ap, &security);
}
/* PUBLIC_INTERFACE */
/** Raw 256-bit PSKs are not accepted by the reference passphrase-only security model. */
INT wifi_setApSecurityPreSharedKey(INT ap, CHAR *value)
{
    if (!ref_ap(ap) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** The model stores passphrases, not a derived raw PSK. */
INT wifi_getApSecurityPreSharedKey(INT ap, CHAR *out)
{ return !ref_ap(ap) || !out ? WIFI_HAL_INVALID_ARGUMENTS : WIFI_HAL_UNSUPPORTED; }

/* PUBLIC_INTERFACE */
/** Read resettable bridge metadata; no host bridge is created or inspected. */
INT wifi_getApBridgeInfo(INT ap, CHAR *name, CHAR *ip, CHAR *subnet)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!ref_ap(ap) || !name || !ip || !subnet) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(name, vap->bridge_name);
    strcpy(ip, AX.bridge_ip);
    strcpy(subnet, AX.bridge_subnet);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Validate bridge names and IPv4 metadata before committing all fields. */
INT wifi_setApBridgeInfo(INT ap, CHAR *name, CHAR *ip, CHAR *subnet)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    struct in_addr address;
    if (!ref_ap(ap) || !name || !ip || !subnet) return WIFI_HAL_INVALID_ARGUMENTS;
    if (strlen(name) >= sizeof(vap->bridge_name) ||
        inet_pton(AF_INET, ip, &address) != 1 || inet_pton(AF_INET, subnet, &address) != 1)
        return WIFI_HAL_INVALID_VALUE;
    strcpy(vap->bridge_name, name);
    strcpy(AX.bridge_ip, ip);
    strcpy(AX.bridge_subnet, subnet);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Bridge configuration is synchronous metadata only. */
INT wifi_pushBridgeInfo(INT ap)
{ return ref_ap(ap) ? WIFI_HAL_SUCCESS : WIFI_HAL_INVALID_ARGUMENTS; }

/* PUBLIC_INTERFACE */
/** Return modeled WPS configuration methods; RF enrollment remains unsupported. */
INT wifi_getApWpsConfigMethodsSupported(INT ap, CHAR *out)
{
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, "PushButton,PIN");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return the two legacy method names, rejecting unrepresentable method bits. */
INT wifi_getApWpsConfigMethodsEnabled(INT ap, CHAR *out)
{
    wifi_wps_t wps;
    if (!out || wifi_getApWpsConfiguration(ap, &wps)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (wps.methods & ~(WIFI_ONBOARDINGMETHODS_PUSHBUTTON | WIFI_ONBOARDINGMETHODS_PIN))
        return WIFI_HAL_UNSUPPORTED;
    strcpy(out, wps.methods == (WIFI_ONBOARDINGMETHODS_PUSHBUTTON | WIFI_ONBOARDINGMETHODS_PIN) ?
                "PushButton,PIN" : wps.methods == WIFI_ONBOARDINGMETHODS_PUSHBUTTON ?
                "PushButton" : wps.methods == WIFI_ONBOARDINGMETHODS_PIN ? "PIN" : "");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Set exact legacy method names through typed WPS validation. */
INT wifi_setApWpsConfigMethodsEnabled(INT ap, CHAR *value)
{
    wifi_wps_t wps;
    if (!value || wifi_getApWpsConfiguration(ap, &wps)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!strcmp(value, "PushButton")) wps.methods = WIFI_ONBOARDINGMETHODS_PUSHBUTTON;
    else if (!strcmp(value, "PIN")) wps.methods = WIFI_ONBOARDINGMETHODS_PIN;
    else if (!strcmp(value, "PushButton,PIN") || !strcmp(value, "PIN,PushButton"))
        wps.methods = WIFI_ONBOARDINGMETHODS_PUSHBUTTON | WIFI_ONBOARDINGMETHODS_PIN;
    else if (!value[0]) wps.methods = (wifi_onboarding_methods_t)0;
    else return WIFI_HAL_UNSUPPORTED;
    return wifi_setApWpsConfiguration(ap, &wps);
}
/* PUBLIC_INTERFACE */
/** Return the configured numeric PIN; leading zeros are retained only by the typed API. */
INT wifi_getApWpsDevicePIN(INT ap, ULONG *out)
{
    wifi_wps_t wps;
    const CHAR *p;
    if (!out || wifi_getApWpsConfiguration(ap, &wps)) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = 0;
    for (p = wps.pin; *p; ++p) *out = *out * 10 + (ULONG)(*p - '0');
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Store a bounded numeric PIN as eight digits through typed WPS validation. */
INT wifi_setApWpsDevicePIN(INT ap, ULONG value)
{
    wifi_wps_t wps;
    if (wifi_getApWpsConfiguration(ap, &wps)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (value > 99999999) return WIFI_HAL_INVALID_VALUE;
    sprintf(wps.pin, "%08lu", value);
    return wifi_setApWpsConfiguration(ap, &wps);
}
