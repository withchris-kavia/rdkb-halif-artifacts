#include <string.h>
#include "wifi_hal_test_backend.h"

/* PUBLIC_INTERFACE */
/** Copy current parameters; invalid indices/pointers never modify caller storage. */
INT wifi_getRadioOperatingParameters(wifi_radio_index_t index, wifi_radio_operationParam_t *op)
{
    if (!wifi_test_radio_valid((INT)index) || !op) return WIFI_HAL_INVALID_ARGUMENTS;
    *op = wifi_test_state.radio[index];
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Validate a complete update before committing it; preserve state on any error. */
INT wifi_setRadioOperatingParameters(wifi_radio_index_t index, wifi_radio_operationParam_t *op)
{
    UINT n;
    BOOL channel_ok = FALSE;
    if (!wifi_test_radio_valid((INT)index) || !op) return WIFI_HAL_INVALID_ARGUMENTS;
    if (op->enable > TRUE || op->band != wifi_test_state.radio[index].band ||
        op->transmitPower > 100 || op->countryCode >= wifi_countrycode_max ||
        op->numSecondaryChannels > MAXNUMSECONDARYCHANNELS ||
        !op->beaconInterval || !op->dtimPeriod ||
        (op->channelWidth != WIFI_CHANNELBANDWIDTH_20MHZ &&
         op->channelWidth != WIFI_CHANNELBANDWIDTH_40MHZ &&
         (index == 0 || op->channelWidth != WIFI_CHANNELBANDWIDTH_80MHZ)))
        return WIFI_HAL_INVALID_VALUE;
    for (n = 0; n < (index == 1 ? 4u : 11u); ++n)
        if (op->channel == (index == 1 ? 36 + 4 * n : n + 1)) channel_ok = TRUE;
    if (!channel_ok) return WIFI_HAL_INVALID_VALUE;
    for (n = 0; n < op->numSecondaryChannels; ++n)
        if (!op->channelSecondary[n] || op->channelSecondary[n] > 233)
            return WIFI_HAL_INVALID_VALUE;
    if (!op->radioStatsMeasuringInterval || !op->radioStatsMeasuringRate ||
        op->radioStatsMeasuringRate > op->radioStatsMeasuringInterval)
        return WIFI_HAL_INVALID_VALUE;
    if (op->radioStatsMeasuringInterval != wifi_test_state.radio[index].radioStatsMeasuringInterval ||
        op->radioStatsMeasuringRate != wifi_test_state.radio[index].radioStatsMeasuringRate) {
        wifi_test_state.bytes[index] = 0;
        wifi_test_state.elapsed[index] = 0;
        wifi_test_state.start[index] = wifi_test_state.clock;
        wifi_test_state.interval_ready[index] = FALSE;
    }
    wifi_test_state.radio[index] = *op;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return configured transmit power percentage, including a valid zero value. */
INT wifi_getRadioTransmitPower(INT index, ULONG *value)
{
    if (!wifi_test_radio_valid(index) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    *value = wifi_test_state.radio[index].transmitPower;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Change transmit power without changing another radio. */
INT wifi_setRadioTransmitPower(INT index, ULONG value)
{
    if (!wifi_test_radio_valid(index)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (value > 100) return WIFI_HAL_INVALID_VALUE;
    wifi_test_state.radio[index].transmitPower = (UINT)value;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return enable state. */
INT wifi_getRadioEnable(INT index, BOOL *value)
{
    if (!wifi_test_radio_valid(index) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    *value = wifi_test_state.radio[index].enable;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Change enable state after boolean validation. */
INT wifi_setRadioEnable(INT index, BOOL value)
{
    if (!wifi_test_radio_valid(index) || value > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.radio[index].enable = value;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Replace or clear the scan completion callback. */
void wifi_scanResults_callback_register(wifi_scanResults_callback callback)
{
    wifi_test_state.scan_cb = callback;
}

/* PUBLIC_INTERFACE */
/** Return an allocated scan snapshot; caller frees it; empty/failure outputs are safe. */
INT wifi_getScanResults(wifi_radio_index_t index, wifi_channel_t *channel,
                       wifi_bss_info_t **bss, UINT *count)
{
    wifi_bss_info_t *result;
    if (!bss || !count) return WIFI_HAL_INVALID_ARGUMENTS;
    *bss = NULL;
    *count = 0;
    if (!wifi_test_radio_valid((INT)index) || !channel) return WIFI_HAL_INVALID_ARGUMENTS;
    if (channel->band != wifi_test_state.radio[index].band ||
        channel->channel < 0 || channel->channel > 233)
        return WIFI_HAL_INVALID_VALUE;
    result = wifi_test_allocate(1, sizeof(*result));
    if (!result) return WIFI_HAL_ERROR;
    strcpy(result->ssid, "reference-neighbor");
    memcpy(result->bssid, "\x02\x00\x00\x00\x00\x01", 6);
    result->rssi = -45;
    result->noise = -95;
    result->snr = 50;
    {
        UINT selected = channel->channel ? (UINT)channel->channel : wifi_test_state.radio[index].channel;
        result->freq = channel->band == WIFI_FREQUENCY_2_4_BAND ?
                       (selected == 14 ? 2484 : 2407 + 5 * selected) :
                       (channel->band == WIFI_FREQUENCY_6_BAND ? 5950 : 5000) + 5 * selected;
    }
    result->oper_freq_band = channel->band;
    result->oper_chan_bw = WIFI_CHANNELBANDWIDTH_20MHZ;
    result->ie_len = 0;
    *bss = result;
    *count = 1;
    return WIFI_HAL_SUCCESS;
}
