#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "wifi_hal_test_backend.h"

wifi_test_state_t wifi_test_state;
static BOOL fail_allocation;

/* PUBLIC_INTERFACE */
/** Reset all state, including callbacks, faults and pending work. */
int wifi_test_reset(UINT radios)
{
    if (!radios || radios > MAX_NUM_RADIOS) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(&wifi_test_state, 0, sizeof(wifi_test_state));
    wifi_test_state.radios = radios;
    wifi_test_state.clock = 1;
    fail_allocation = FALSE;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return true only for a live radio. */
int wifi_test_radio_valid(INT index)
{
    return wifi_test_state.initialized && index >= 0 && (UINT)index < wifi_test_state.radios;
}

/* PUBLIC_INTERFACE */
/** Find a VAP without deriving membership from a hardcoded index formula. */
wifi_vap_info_t *wifi_test_vap(INT index)
{
    UINT r, v;
    if (!wifi_test_state.initialized || index < 0 || index >= WIFI_TEST_VAPS) return NULL;
    for (r = 0; r < wifi_test_state.radios; ++r)
        for (v = 0; v < wifi_test_state.map[r].num_vaps; ++v)
            if (wifi_test_state.map[r].vap_array[v].vap_index == (UINT)index)
                return &wifi_test_state.map[r].vap_array[v];
    return NULL;
}

/* PUBLIC_INTERFACE */
/** Fail only the next model-owned allocation, never libc/framework allocation. */
void wifi_test_fail_allocation(void) { fail_allocation = TRUE; }

/* PUBLIC_INTERFACE */
/** Allocate a zero-filled result that the HAL caller must free. */
void *wifi_test_allocate(size_t count, size_t size)
{
    if (fail_allocation) { fail_allocation = FALSE; return NULL; }
    if (!size || count > SIZE_MAX / size) return NULL;
    return calloc(count, size);
}

/* PUBLIC_INTERFACE */
/** Publish whole sample periods; retention rollover starts a new counter interval. */
void wifi_test_advance(UINT seconds)
{
    UINT r;
    wifi_test_state.clock += seconds;
    for (r = 0; r < wifi_test_state.radios; ++r) {
        ULONG rate = wifi_test_state.radio[r].radioStatsMeasuringRate;
        ULONG interval = wifi_test_state.radio[r].radioStatsMeasuringInterval;
        ULONG before = wifi_test_state.elapsed[r], after = before + seconds;
        if (!wifi_test_state.initialized || !wifi_test_state.radio[r].enable ||
            !wifi_test_state.stats_enabled[r] || !rate || !interval) continue;
        if (after >= interval) {
            wifi_test_state.interval_ready[r] = TRUE;
            after %= interval;
            wifi_test_state.bytes[r] = 0;
            before = 0;
            wifi_test_state.start[r] = wifi_test_state.clock - after;
        }
        wifi_test_state.bytes[r] += (after / rate - before / rate) * rate * 100;
        wifi_test_state.elapsed[r] = after;
    }
}

/* PUBLIC_INTERFACE */
/** Reject unterminated or unsupported security data before state changes. */
int wifi_test_security_valid(const wifi_vap_security_t *s)
{
    if (!s) return 0;
    switch (s->mode) {
    case wifi_security_mode_none: return 1;
    case wifi_security_mode_wpa2_personal:
    case wifi_security_mode_wpa3_personal:
    case wifi_security_mode_wpa3_transition:
        return s->encr == wifi_encryption_aes &&
               memchr(s->u.key.key, '\0', sizeof(s->u.key.key)) &&
               strlen(s->u.key.key) >= 8 && strlen(s->u.key.key) <= 63;
    case wifi_security_mode_wpa2_enterprise:
        return s->encr == wifi_encryption_aes && s->u.radius.port &&
               memchr(s->u.radius.key, '\0', sizeof(s->u.radius.key)) && s->u.radius.key[0] &&
               memchr(s->u.radius.s_key, '\0', sizeof(s->u.radius.s_key)) &&
               memchr(s->u.radius.daskey, '\0', sizeof(s->u.radius.daskey));
    default: return 0;
    }
}

/* PUBLIC_INTERFACE */
/** Dispatch scan completion with borrowed storage valid only during the callback. */
int wifi_test_dispatch(void)
{
    UINT r;
    if (!wifi_test_state.initialized) return WIFI_HAL_NOT_READY;
    for (r = 0; r < wifi_test_state.radios; ++r) {
        if (wifi_test_state.scan_pending[r]) {
            wifi_bss_info_t *result = &wifi_test_state.scan_result[r];
            UINT count = 1;
            wifi_test_state.scan_pending[r] = FALSE;
            if (wifi_test_state.scan_cb) wifi_test_state.scan_cb(r, &result, &count);
        }
    }
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Inject a bounded AP association event using the feature-selected callback ABI. */
int wifi_test_client_event(INT ap, BOOL connected)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    char mac[18] = "02:00:00:00:00:01";
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || connected > TRUE)
        return WIFI_HAL_INVALID_ARGUMENTS;
    if (connected) {
        wifi_test_ap_extra_t *extra = &wifi_test_state.ap_extra[ap];
        ++extra->associations;
        if (!extra->high_watermark) {
            extra->high_watermark = 1;
            extra->high_date = wifi_test_state.clock;
        }
        if (extra->high_threshold && extra->high_threshold <= 1) ++extra->high_reached;
    }
    wifi_test_state.managed[ap] = connected;
    memcpy(wifi_test_state.client[ap], "\x02\x00\x00\x00\x00\x01", 6);
    if (connected && wifi_test_state.assoc_cb) {
#ifdef WIFI_HAL_VERSION_3_PHASE2
        wifi_associated_dev3_t dev = {0};
#else
        wifi_associated_dev_t dev = {0};
#endif
        memcpy(dev.cli_MACAddress, wifi_test_state.client[ap], 6);
        dev.cli_Active = TRUE;
        wifi_test_state.assoc_cb(ap, &dev);
    }
    if (!connected && wifi_test_state.disassoc_cb) wifi_test_state.disassoc_cb(ap, mac, 1);
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Deliver borrowed BTM and autonomous beacon data without callback ABI casts. */
int wifi_test_management_event(INT ap)
{
    wifi_BTMQuery_t query = {0};
    wifi_BTMRequest_t request = {0};
    wifi_BTMResponse_t response = {0};
    wifi_BeaconReport_t beacon = {0};
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    UINT count = 1;
    UCHAR token = 0; /* Autonomous RRM reports have dialog token zero. */
#ifdef WIFI_HAL_VERSION_3_PHASE2
    mac_address_t peer = {2, 0, 0, 0, 0, 1};
#else
    char peer[] = "02:00:00:00:00:01";
#endif
    if (!vap || vap->vap_mode != wifi_vap_mode_ap) return WIFI_HAL_INVALID_ARGUMENTS;
    query.token = 7;
    request.token = query.token;
    if (wifi_test_state.query_cb[ap] &&
        wifi_test_state.query_cb[ap]((UINT)ap, peer, &query, sizeof(request), &request))
        return WIFI_HAL_ERROR;
    response.token = request.token;
    if (wifi_test_state.response_cb[ap])
        wifi_test_state.response_cb[ap]((UINT)ap, peer, &response);
    beacon.channel = (UCHAR)wifi_test_state.radio[vap->radio_index].channel;
    beacon.rcpi = 90;
    if (wifi_test_state.beacon_cb[ap])
        wifi_test_state.beacon_cb[ap]((UINT)ap, &beacon, &count, &token);
    return WIFI_HAL_SUCCESS;
}
