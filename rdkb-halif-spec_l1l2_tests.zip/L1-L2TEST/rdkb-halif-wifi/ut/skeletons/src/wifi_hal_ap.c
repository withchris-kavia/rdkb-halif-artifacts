#include <string.h>
#include <stdio.h>
#include "wifi_hal_test_backend.h"

static int bounded(const char *s, size_t n) { return memchr(s, '\0', n) != NULL; }

/* Bulk VAP replacement and direct WPS updates must accept the same values. */
static int wps_valid(const wifi_wps_t *wps)
{
    size_t n, i;
    if (wps->enable > TRUE || !bounded(wps->pin, sizeof(wps->pin)) ||
        ((UINT)wps->methods & ~0x3fffu)) return 0;
    n = strlen(wps->pin);
    if (n && n != 4 && n != 8) return 0;
    for (i = 0; i < n; ++i)
        if (wps->pin[i] < '0' || wps->pin[i] > '9') return 0;
    return 1;
}

/* PUBLIC_INTERFACE */
/** A removed or role-changed VAP must not lend runtime state to its next incarnation. */
void wifi_test_clear_vap_runtime(UINT ap)
{
    if (ap >= WIFI_TEST_VAPS) return;
    memset(&wifi_test_state.ap_extra[ap], 0, sizeof(wifi_test_state.ap_extra[ap]));
    memset(&wifi_test_state.station[ap], 0, sizeof(wifi_test_state.station[ap]));
    wifi_test_state.managed[ap] = FALSE;
    memset(wifi_test_state.client[ap], 0, sizeof(wifi_test_state.client[ap]));
    wifi_test_state.client_configured[ap] = FALSE;
    memset(wifi_test_state.steering_client[ap], 0, sizeof(wifi_test_state.steering_client[ap]));
    memset(&wifi_test_state.client_config[ap], 0, sizeof(wifi_test_state.client_config[ap]));
    wifi_test_state.query_cb[ap] = NULL;
    wifi_test_state.response_cb[ap] = NULL;
    wifi_test_state.beacon_cb[ap] = NULL;
    wifi_test_state.token[ap] = 0;
}

/* PUBLIC_INTERFACE */
/** Validate all entries and global index uniqueness before atomically replacing a map. */
INT wifi_createVAP(wifi_radio_index_t index, wifi_vap_info_map_t *map)
{
    UINT i, j, r;
    if (!wifi_test_radio_valid((INT)index) || !map) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!map->num_vaps || map->num_vaps > MAX_NUM_VAP_PER_RADIO) return WIFI_HAL_INVALID_VALUE;
    for (i = 0; i < map->num_vaps; ++i) {
        const wifi_vap_info_t *vap = &map->vap_array[i];
        const char *ssid;
        const wifi_vap_security_t *security;
        if (vap->vap_index >= WIFI_TEST_VAPS || vap->radio_index != index ||
            (vap->vap_mode != wifi_vap_mode_ap && vap->vap_mode != wifi_vap_mode_sta) ||
            !bounded(vap->vap_name, sizeof(vap->vap_name)) || !vap->vap_name[0] ||
            !bounded(vap->bridge_name, sizeof(vap->bridge_name)))
            return WIFI_HAL_INVALID_VALUE;
        ssid = vap->vap_mode == wifi_vap_mode_ap ? vap->u.bss_info.ssid : vap->u.sta_info.ssid;
        security = vap->vap_mode == wifi_vap_mode_ap ? &vap->u.bss_info.security : &vap->u.sta_info.security;
        if (!bounded(ssid, vap->vap_mode == wifi_vap_mode_ap ?
                     sizeof(vap->u.bss_info.ssid) : sizeof(vap->u.sta_info.ssid)) ||
            !ssid[0] || !wifi_test_security_valid(security))
            return WIFI_HAL_INVALID_VALUE;
        if (vap->vap_mode == wifi_vap_mode_ap &&
            (vap->u.bss_info.enabled > TRUE || !wps_valid(&vap->u.bss_info.wps)))
            return WIFI_HAL_INVALID_VALUE;
        if (vap->vap_mode == wifi_vap_mode_sta && vap->u.sta_info.enabled > TRUE)
            return WIFI_HAL_INVALID_VALUE;
        for (j = 0; j < i; ++j)
            if (map->vap_array[j].vap_index == vap->vap_index) return WIFI_HAL_INVALID_VALUE;
        for (r = 0; r < wifi_test_state.radios; ++r)
            if (r != index)
                for (j = 0; j < wifi_test_state.map[r].num_vaps; ++j)
                    if (wifi_test_state.map[r].vap_array[j].vap_index == vap->vap_index)
                        return WIFI_HAL_INVALID_VALUE;
    }
    /* Preserve runtime for retained same-role entries, independent of their map order. */
    for (i = 0; i < wifi_test_state.map[index].num_vaps; ++i) {
        const wifi_vap_info_t *old = &wifi_test_state.map[index].vap_array[i];
        for (j = 0; j < map->num_vaps; ++j)
            if (map->vap_array[j].vap_index == old->vap_index &&
                map->vap_array[j].vap_mode == old->vap_mode) break;
        if (j == map->num_vaps) wifi_test_clear_vap_runtime(old->vap_index);
    }
    wifi_test_state.map[index] = *map;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return a map snapshot with no allocation or shared caller-owned pointers. */
INT wifi_getRadioVapInfoMap(wifi_radio_index_t index, wifi_vap_info_map_t *map)
{
    if (!wifi_test_radio_valid((INT)index) || !map) return WIFI_HAL_INVALID_ARGUMENTS;
    *map = wifi_test_state.map[index];
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return AP security (STA indices are not APs). */
INT wifi_getApSecurity(INT ap, wifi_vap_security_t *security)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || !security) return WIFI_HAL_INVALID_ARGUMENTS;
    *security = vap->u.bss_info.security;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Commit only supported, well-formed AP security. */
INT wifi_setApSecurity(INT ap, wifi_vap_security_t *security)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || !security) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_security_valid(security)) return WIFI_HAL_INVALID_VALUE;
    vap->u.bss_info.security = *security;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Retrieve WPS settings. */
INT wifi_getApWpsConfiguration(INT ap, wifi_wps_t *wps)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || !wps) return WIFI_HAL_INVALID_ARGUMENTS;
    *wps = vap->u.bss_info.wps;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Validate booleans, supported methods and optional four/eight digit PINs. */
INT wifi_setApWpsConfiguration(INT ap, wifi_wps_t *wps)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || !wps) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wps_valid(wps)) return WIFI_HAL_INVALID_VALUE;
    vap->u.bss_info.wps = *wps;
    return WIFI_HAL_SUCCESS;
}

#ifdef WIFI_HAL_VERSION_3_PHASE2
/* PUBLIC_INTERFACE */
/** Return up to capacity binary client MACs; never write beyond caller capacity. */
INT wifi_getApAssociatedDevice(INT ap, mac_address_t *macs, UINT capacity, UINT *count)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!count) return WIFI_HAL_INVALID_ARGUMENTS;
    *count = 0;
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || (!macs && capacity)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (wifi_test_state.managed[ap]) {
        if (!capacity) return WIFI_HAL_INVALID_VALUE;
        memcpy(macs[0], wifi_test_state.client[ap], 6);
        *count = 1;
    }
    return WIFI_HAL_SUCCESS;
}
#else
/* PUBLIC_INTERFACE */
/** Return a bounded textual client list using the baseline ABI. */
INT wifi_getApAssociatedDevice(INT ap, CHAR *output, INT size)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || !output || size < 1)
        return WIFI_HAL_INVALID_ARGUMENTS;
    output[0] = '\0';
    if (wifi_test_state.managed[ap]) {
        if (size < 18) return WIFI_HAL_INVALID_VALUE;
        snprintf(output, (size_t)size, "02:00:00:00:00:01");
    }
    return WIFI_HAL_SUCCESS;
}
#endif

/* PUBLIC_INTERFACE */
/** Replace/clear association callback using the header-selected ABI. */
void wifi_newApAssociatedDevice_callback_register(wifi_newApAssociatedDevice_callback cb)
{ wifi_test_state.assoc_cb = cb; }
/* PUBLIC_INTERFACE */
/** Replace/clear disassociation callback. */
void wifi_apDisassociatedDevice_callback_register(wifi_apDisassociatedDevice_callback cb)
{ wifi_test_state.disassoc_cb = cb; }
/* PUBLIC_INTERFACE */
/** Replace/clear deauthentication callback. */
void wifi_apDeAuthEvent_callback_register(wifi_apDeAuthEvent_callback cb)
{ wifi_test_state.deauth_cb = cb; }
/* PUBLIC_INTERFACE */
/** Register a management callback (NULL unregisters). */
INT wifi_mgmt_frame_callbacks_register(wifi_receivedMgmtFrame_callback cb)
{ wifi_test_state.mgmt_cb = cb; return WIFI_HAL_SUCCESS; }

/* PUBLIC_INTERFACE */
/** Disable CSI idempotently (NULL selects all clients); real CSI capture is unsupported. */
INT wifi_enableCSIEngine(INT ap, mac_address_t mac, BOOL enable)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || enable > TRUE || (enable && !mac))
        return WIFI_HAL_INVALID_ARGUMENTS;
    return enable ? WIFI_HAL_UNSUPPORTED : WIFI_HAL_SUCCESS;
}

#ifdef WIFI_HAL_VERSION_3_PHASE2
/* PUBLIC_INTERFACE */
/** Remove the matching binary client; deliver disassociation once. */
INT wifi_kickApAssociatedDevice(INT ap, mac_address_t mac)
{
    if (!wifi_test_vap(ap) || !mac) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.managed[ap] || memcmp(mac, wifi_test_state.client[ap], 6))
        return WIFI_HAL_INVALID_VALUE;
    return wifi_test_client_event(ap, FALSE);
}
#else
/* PUBLIC_INTERFACE */
/** Parse the complete textual MAC for baseline kick requests. */
INT wifi_kickApAssociatedDevice(INT ap, CHAR *mac)
{
    unsigned int octet[6];
    char extra;
    unsigned int i;
    if (!wifi_test_vap(ap) || !mac) return WIFI_HAL_INVALID_ARGUMENTS;
    if (strlen(mac) != 17 || sscanf(mac, "%2x:%2x:%2x:%2x:%2x:%2x%c",
        &octet[0], &octet[1], &octet[2], &octet[3], &octet[4], &octet[5], &extra) != 6)
        return WIFI_HAL_INVALID_VALUE;
    for (i = 0; i < 6; ++i)
        if (octet[i] != wifi_test_state.client[ap][i]) return WIFI_HAL_INVALID_VALUE;
    if (!wifi_test_state.managed[ap]) return WIFI_HAL_INVALID_VALUE;
    return wifi_test_client_event(ap, FALSE);
}
#endif
