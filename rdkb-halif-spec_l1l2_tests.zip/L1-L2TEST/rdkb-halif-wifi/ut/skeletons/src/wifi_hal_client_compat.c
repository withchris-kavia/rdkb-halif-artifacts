#include <limits.h>
#include "wifi_hal_test_accessors.h"

AP_GET(wifi_getApAssociatedDevicesHighWatermarkThreshold, UINT, AX.high_threshold)
AP_SET(wifi_setApAssociatedDevicesHighWatermarkThreshold, UINT, AX.high_threshold, value <= 512)
AP_GET(wifi_getApAssociatedDevicesHighWatermarkThresholdReached, UINT, AX.high_reached)
AP_GET(wifi_getApAssociatedDevicesHighWatermark, UINT, AX.high_watermark)
AP_GET(wifi_getApAssociatedDevicesHighWatermarkDate, ULONG, AX.high_date)
AP_GET(wifi_getFTOverDSActivated, BOOL, AX.ft.overDS)
AP_GET(wifi_getFTResourceRequestSupported, BOOL, AX.ft_resource)
AP_GET(wifi_getFTR0KeyLifetime, UINT, AX.ft.r0KeyLifeTime)

#define FT_POINTER_SET(Name, Type, Field, Valid) \
    /* PUBLIC_INTERFACE */ \
    /** Validate pointer and range before updating one FT setting. */ \
    INT Name(INT ap, Type *value) { \
        if (!ref_ap(ap) || !value) return WIFI_HAL_INVALID_ARGUMENTS; \
        if (!(Valid)) return WIFI_HAL_INVALID_VALUE; \
        Field = *value; return WIFI_HAL_SUCCESS; \
    }
FT_POINTER_SET(wifi_setFTOverDSActivated, BOOL, AX.ft.overDS, *value <= TRUE)
FT_POINTER_SET(wifi_setFTResourceRequestSupported, BOOL, AX.ft_resource, *value <= TRUE)
FT_POINTER_SET(wifi_setFTR0KeyLifetime, UINT, AX.ft.r0KeyLifeTime, *value <= USHRT_MAX)

/* PUBLIC_INTERFACE */
/** Enable full FT support independently of the BTM activation setting. */
INT wifi_setFastBSSTransitionActivated(INT ap, BOOL enabled)
{
    if (!ref_ap(ap) || enabled > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    AX.ft.support = enabled ? FT_SUPPORT_FULL : FT_SUPPORT_DISABLED;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return the two-byte mobility domain in network byte order. */
INT wifi_getFTMobilityDomainID(INT ap, UCHAR out[2])
{
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    out[0] = (UCHAR)(AX.ft.mobilityDomain >> 8);
    out[1] = (UCHAR)AX.ft.mobilityDomain;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Store a two-byte network-order mobility domain. */
INT wifi_setFTMobilityDomainID(INT ap, UCHAR value[2])
{
    if (!ref_ap(ap) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    AX.ft.mobilityDomain = (USHORT)(((UINT)value[0] << 8) | value[1]);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Copy an R0 NAS identifier to a caller buffer sized for nas_id_t. */
INT wifi_getFTR0KeyHolderID(INT ap, UCHAR *out)
{
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy((CHAR *)out, AX.ft.r0KeyHolder);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Validate a bounded R0 NAS identifier before replacing it. */
INT wifi_setFTR0KeyHolderID(INT ap, UCHAR *value)
{
    if (!ref_ap(ap) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!memchr(value, 0, sizeof(AX.ft.r0KeyHolder))) return WIFI_HAL_INVALID_VALUE;
    strcpy(AX.ft.r0KeyHolder, (CHAR *)value);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Copy the six-byte R1 key-holder identifier. */
INT wifi_getFTR1KeyHolderID(INT ap, UCHAR *out)
{
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memcpy(out, AX.ft.r1KeyHolder, 6);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Store the six-byte R1 key-holder identifier. */
INT wifi_setFTR1KeyHolderID(INT ap, UCHAR *value)
{
    if (!ref_ap(ap) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    memcpy(AX.ft.r1KeyHolder, value, 6);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Validate support, booleans, holder counts and NAS strings before replacing FT configuration. */
INT wifi_pushApFastTransitionConfig(INT ap, wifi_FastTransitionConfig_t *value)
{
    UINT i;
    if (!ref_ap(ap) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    if (value->support < FT_SUPPORT_DISABLED || value->support > FT_SUPPORT_ADAPTIVE ||
        value->overDS > TRUE || value->pmkR1Push > TRUE ||
        value->numR0KHs > MAX_KEY_HOLDERS || value->numR1KHs > MAX_KEY_HOLDERS ||
        !memchr(value->r0KeyHolder, 0, sizeof(value->r0KeyHolder))) return WIFI_HAL_INVALID_VALUE;
    for (i = 0; i < value->numR0KHs; ++i)
        if (!memchr(value->r0KH[i].nasId, 0, sizeof(value->r0KH[i].nasId)))
            return WIFI_HAL_INVALID_VALUE;
    AX.ft = *value;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Read all EAP settings from the same security structure used by wifi_getApSecurity. */
INT wifi_getEAP_Param(UINT ap, wifi_eap_config_t *out)
{
    wifi_vap_info_t *vap = wifi_test_vap((INT)ap);
    if (!ref_ap((INT)ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    out->uiEAPOLKeyTimeout = B.security.eapol_key_timeout;
    out->uiEAPOLKeyRetries = B.security.eapol_key_retries;
    out->uiEAPIdentityRequestTimeout = B.security.eap_identity_req_timeout;
    out->uiEAPIdentityRequestRetries = B.security.eap_identity_req_retries;
    out->uiEAPRequestTimeout = B.security.eap_req_timeout;
    out->uiEAPRequestRetries = B.security.eap_req_retries;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Set one named timeout/retry parameter; ambiguous bare names are rejected, not guessed. */
INT wifi_setEAP_Param(UINT ap, UINT value, CHAR *param)
{
    wifi_vap_info_t *vap = wifi_test_vap((INT)ap);
    if (!ref_ap((INT)ap) || !param) return WIFI_HAL_INVALID_ARGUMENTS;
    if (value > 65535) return WIFI_HAL_INVALID_VALUE;
    if (!strcmp(param, "eapolkeytimeout")) B.security.eapol_key_timeout = value;
    else if (!strcmp(param, "eapolkeyretries")) B.security.eapol_key_retries = value;
    else if (!strcmp(param, "eapidentityrequesttimeout")) B.security.eap_identity_req_timeout = value;
    else if (!strcmp(param, "eapidentityrequestretries")) B.security.eap_identity_req_retries = value;
    else if (!strcmp(param, "eaprequesttimeout")) B.security.eap_req_timeout = value;
    else if (!strcmp(param, "eaprequestretries")) B.security.eap_req_retries = value;
    else return WIFI_HAL_UNSUPPORTED;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** No autonomous steering events occur in this model; report an explicitly unsupported log. */
INT wifi_getBandSteeringLog(INT index, ULONG *time, CHAR *mac, INT *source, INT *dest, INT *reason)
{
    if (index < 0 || !time || !mac || !source || !dest || !reason) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
