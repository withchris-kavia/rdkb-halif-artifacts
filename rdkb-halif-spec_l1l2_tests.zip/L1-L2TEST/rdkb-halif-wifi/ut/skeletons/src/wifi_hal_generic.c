#include <string.h>
#include <stdio.h>
#include "wifi_hal_test_backend.h"

/* PUBLIC_INTERFACE */
/** Initialize once without destroying existing radio/VAP state on repeated calls. */
INT wifi_init(void)
{
    UINT r, v;
    static const char *roles[] = {"private", "iot", "hotspot_open", "lnf_psk",
                                 "hotspot_secure", "lnf_radius", "mesh_backhaul", "mesh_sta"};
    if (wifi_test_state.initialized) return WIFI_HAL_SUCCESS;
    if (!wifi_test_state.radios && wifi_test_reset(2)) return WIFI_HAL_ERROR;
    wifi_test_state.initialized = TRUE;
    for (r = 0; r < wifi_test_state.radios; ++r) {
        wifi_radio_operationParam_t *op = &wifi_test_state.radio[r];
        op->enable = TRUE;
        op->band = r == 0 ? WIFI_FREQUENCY_2_4_BAND :
                   r == 1 ? WIFI_FREQUENCY_5_BAND : WIFI_FREQUENCY_6_BAND;
        op->channel = r == 1 ? 36 : 1;
        op->channelWidth = WIFI_CHANNELBANDWIDTH_20MHZ;
        op->variant = WIFI_80211_VARIANT_N;
        op->countryCode = wifi_countrycode_US;
        op->transmitPower = 100;
        op->guardInterval = wifi_guard_interval_auto;
        op->beaconInterval = 100;
        op->dtimPeriod = 1;
        op->radioStatsMeasuringRate = 30;
        op->radioStatsMeasuringInterval = 1800;
        wifi_test_state.factory_radio[r] = *op;
        wifi_test_state.start[r] = wifi_test_state.clock;
        wifi_test_state.stats_enabled[r] = TRUE;
        wifi_test_state.map[r].num_vaps = MAX_NUM_VAP_PER_RADIO;
        for (v = 0; v < MAX_NUM_VAP_PER_RADIO; ++v) {
            wifi_vap_info_t *vap = &wifi_test_state.map[r].vap_array[v];
            vap->vap_index = v * wifi_test_state.radios + r;
            vap->radio_index = r;
            vap->vap_mode = v == 7 ? wifi_vap_mode_sta : wifi_vap_mode_ap;
            snprintf(vap->vap_name, sizeof(vap->vap_name), "%s_%u", roles[v], r);
            snprintf(vap->bridge_name, sizeof(vap->bridge_name), "brlan%u", v);
            if (vap->vap_mode == wifi_vap_mode_sta) {
                strcpy(vap->u.sta_info.ssid, "reference-sta");
                vap->u.sta_info.enabled = TRUE;
                vap->u.sta_info.conn_status = wifi_connection_status_disconnected;
                vap->u.sta_info.security.mode = wifi_security_mode_none;
            } else {
                strcpy(vap->u.bss_info.ssid, "reference-ap");
                vap->u.bss_info.enabled = TRUE;
                vap->u.bss_info.bssMaxSta = 75;
                vap->u.bss_info.security.mode = wifi_security_mode_none;
            }
        }
    }
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy deterministic capability and interface maps into a caller-provided buffer. */
INT wifi_getHalCapability(wifi_hal_capability_t *cap)
{
    UINT r, v;
    if (!cap) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.initialized) return WIFI_HAL_NOT_READY;
    memset(cap, 0, sizeof(*cap));
    cap->version.major = WIFI_HAL_MAJOR_VERSION;
    cap->version.minor = WIFI_HAL_MINOR_VERSION;
    cap->wifi_prop.numRadios = wifi_test_state.radios;
    cap->BandSteeringSupported = TRUE;
    for (r = 0; r < wifi_test_state.radios; ++r) {
        wifi_radio_capabilities_t *radio = &cap->wifi_prop.radiocap[r];
        radio->index = r;
        radio->rdk_radio_index = r;
        radio->numSupportedFreqBand = 1;
        radio->band[0] = wifi_test_state.radio[r].band;
        radio->maxNumberVAPs = MAX_NUM_VAP_PER_RADIO;
        radio->channelWidth[0] = WIFI_CHANNELBANDWIDTH_20MHZ | WIFI_CHANNELBANDWIDTH_40MHZ;
        if (r) radio->channelWidth[0] |= WIFI_CHANNELBANDWIDTH_80MHZ;
        radio->channel_list[0].num_channels = r == 1 ? 4 : 11;
        for (v = 0; v < (UINT)radio->channel_list[0].num_channels; ++v)
            radio->channel_list[0].channels_list[v] = r == 1 ? 36 + 4 * (INT)v : (INT)v + 1;
        snprintf(radio->ifaceName, sizeof(radio->ifaceName), "radio%u", r);
        cap->wifi_prop.radio_presence[r] = TRUE;
        cap->wifi_prop.radio_interface_map[r].radio_index = r;
        for (v = 0; v < MAX_NUM_VAP_PER_RADIO; ++v) {
            UINT n = r * MAX_NUM_VAP_PER_RADIO + v;
            const wifi_vap_info_t *vap = &wifi_test_state.map[r].vap_array[v];
            cap->wifi_prop.interface_map[n].index = vap->vap_index;
            cap->wifi_prop.interface_map[n].rdk_radio_index = r;
            strcpy(cap->wifi_prop.interface_map[n].vap_name, vap->vap_name);
        }
    }
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Restore factory topology/configuration and clear callbacks, queued work and faults. */
INT wifi_factoryReset(void)
{
    UINT radios = wifi_test_state.radios ? wifi_test_state.radios : 2;
    INT status = wifi_test_reset(radios);
    return status ? status : wifi_init();
}
/* PUBLIC_INTERFACE */
/** Reinitialize all in-memory radio and AP variables. */
INT wifi_reset(void) { return wifi_factoryReset(); }
/* PUBLIC_INTERFACE */
/** Turn off transmission without removing topology or resetting configuration. */
INT wifi_down(void)
{
    UINT radio;
    if (!wifi_test_state.initialized) return WIFI_HAL_NOT_READY;
    for (radio = 0; radio < wifi_test_state.radios; ++radio) {
        wifi_test_state.radio[radio].enable = FALSE;
        wifi_test_state.scan_pending[radio] = FALSE;
    }
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Store an indexed model LED state; reject absent radios and invalid booleans. */
INT wifi_setLED(INT radio, BOOL enabled)
{
    if (!wifi_test_radio_valid(radio) || enabled > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.led[radio] = enabled;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** File-based provisioning is not implemented by the in-memory backend. */
INT wifi_createInitialConfigFiles(void) { return WIFI_HAL_UNSUPPORTED; }
/* PUBLIC_INTERFACE */
/** Validate the AP, but never claim that hostapd files have been written. */
INT wifi_createHostApdConfig(INT ap, BOOL create)
{
    if (!wifi_test_vap(ap) || create > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Hostapd process management is outside the in-memory backend. */
INT wifi_startHostApd(void) { return WIFI_HAL_UNSUPPORTED; }
/* PUBLIC_INTERFACE */
/** Hostapd process management is outside the in-memory backend. */
INT wifi_stopHostApd(void) { return WIFI_HAL_UNSUPPORTED; }
