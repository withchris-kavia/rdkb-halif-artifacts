#include <string.h>
#include <stdio.h>
#include "wifi_hal_test_backend.h"

/* PUBLIC_INTERFACE */
/** Return current counters without requiring traffic to have occurred. */
INT wifi_getRadioTrafficStats2(INT radio, wifi_radioTrafficStats2_t *stats)
{
    if (!wifi_test_radio_valid(radio) || !stats) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(stats, 0, sizeof(*stats));
    stats->radio_BytesSent = wifi_test_state.bytes[radio];
    stats->radio_BytesReceived = wifi_test_state.bytes[radio] * 2;
    stats->radio_PacketsSent = wifi_test_state.bytes[radio] / 100;
    stats->radio_PacketsReceived = wifi_test_state.bytes[radio] / 50;
    stats->radio_NoiseFloor = -95;
    /* Interval metrics are unavailable until the first complete measuring interval. */
    stats->radio_ChannelUtilization = wifi_test_state.interval_ready[radio] ? 20 : (ULONG)-1;
    stats->radio_ActivityFactor = wifi_test_state.interval_ready[radio] ? 10 : -1;
    stats->radio_CarrierSenseThreshold_Exceeded = wifi_test_state.interval_ready[radio] ? 5 : -1;
    stats->radio_RetransmissionMetirc = wifi_test_state.interval_ready[radio] ? 0 : -1;
    stats->radio_MaximumNoiseFloorOnChannel = wifi_test_state.interval_ready[radio] ? -90 : -1;
    stats->radio_MinimumNoiseFloorOnChannel = wifi_test_state.interval_ready[radio] ? -100 : -1;
    stats->radio_MedianNoiseFloorOnChannel = wifi_test_state.interval_ready[radio] ? -95 : -1;
    stats->radio_StatisticsStartTime = wifi_test_state.start[radio];
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return VAP counters from its owning radio. */
INT wifi_getSSIDTrafficStats2(INT ap, wifi_ssidTrafficStats2_t *stats)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || !stats) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(stats, 0, sizeof(*stats));
    stats->ssid_BytesSent = wifi_test_state.bytes[vap->radio_index];
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return utilization in the documented percentage range. */
INT wifi_getRadioBandUtilization(INT radio, INT *value)
{
    if (!wifi_test_radio_valid(radio) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    *value = wifi_test_state.radio[radio].enable ? 20 : 0;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Retrieve statistics collection enable state. */
INT wifi_getRadioStatsEnable(INT radio, BOOL *enabled)
{
    if (!wifi_test_radio_valid(radio) || !enabled) return WIFI_HAL_INVALID_ARGUMENTS;
    *enabled = wifi_test_state.stats_enabled[radio];
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Enable/disable deterministic sampling without clearing existing counters. */
INT wifi_setRadioStatsEnable(INT radio, BOOL enabled)
{
    if (!wifi_test_radio_valid(radio) || enabled > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.stats_enabled[radio] = enabled;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Change client-detail collection without changing radio-wide sampling or counters. */
INT wifi_setClientDetailedStatisticsEnable(INT radio, BOOL enabled)
{
    if (!wifi_test_radio_valid(radio) || enabled > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.detailed_stats_enabled[radio] = enabled;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return caller-owned diagnostics; zero associated clients is valid and allocates nothing. */
INT wifi_getApAssociatedDeviceDiagnosticResult3(INT ap, wifi_associated_dev3_t **devices, UINT *count)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!devices || !count) return WIFI_HAL_INVALID_ARGUMENTS;
    *devices = NULL;
    *count = 0;
    if (!vap || vap->vap_mode != wifi_vap_mode_ap) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.managed[ap]) return WIFI_HAL_SUCCESS;
    *devices = wifi_test_allocate(1, sizeof(**devices));
    if (!*devices) return WIFI_HAL_ERROR;
    memcpy((*devices)->cli_MACAddress, wifi_test_state.client[ap], 6);
    (*devices)->cli_Active = TRUE;
    (*devices)->cli_RSSI = -45;
    (*devices)->cli_SignalStrength = -45;
    (*devices)->cli_BytesSent = wifi_test_state.bytes[vap->radio_index];
    /* No CSI is fabricated: cli_CsiData remains NULL. */
    *count = 1;
    return WIFI_HAL_SUCCESS;
}
#ifdef WIFI_HAL_VERSION_3_PHASE2
/* PUBLIC_INTERFACE */
/** Return one matching binary-MAC diagnostic record without aliases. */
INT wifi_getApAssociatedClientDiagnosticResult(INT ap, mac_address_t mac, wifi_associated_dev3_t *device)
#else
/* PUBLIC_INTERFACE */
/** Return one matching textual-MAC diagnostic record using the baseline signature. */
INT wifi_getApAssociatedClientDiagnosticResult(INT ap, char *mac, wifi_associated_dev3_t *device)
#endif
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
#ifndef WIFI_HAL_VERSION_3_PHASE2
    char expected[18];
    unsigned char *m;
#endif
    if (!vap || !mac || !device) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.managed[ap]) return WIFI_HAL_INVALID_VALUE;
#ifdef WIFI_HAL_VERSION_3_PHASE2
    if (memcmp(mac, wifi_test_state.client[ap], 6)) return WIFI_HAL_INVALID_VALUE;
#else
    m = wifi_test_state.client[ap];
    snprintf(expected, sizeof(expected), "%02x:%02x:%02x:%02x:%02x:%02x",
             m[0], m[1], m[2], m[3], m[4], m[5]);
    if (strcmp(mac, expected)) return WIFI_HAL_INVALID_VALUE;
#endif
    memset(device, 0, sizeof(*device));
    memcpy(device->cli_MACAddress, wifi_test_state.client[ap], 6);
    device->cli_Active = TRUE;
    device->cli_RSSI = -45;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return initialized overflow telemetry. */
INT wifi_getVAPTelemetry(UINT ap, wifi_VAPTelemetry_t *telemetry)
{
    if (!wifi_test_vap((INT)ap) || !telemetry) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(telemetry, 0, sizeof(*telemetry));
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Measure an unassociated unicast peer in the reference model's 20 MHz channel subset.
 * params supplies MAC/class/channel; output receives echoed identifiers and RCPI.
 * Errors leave output untouched. No allocation, blocking call or real RF is involved.
 */
INT wifi_getNASta(INT ap, const wifi_na_sta_req_params_t *params, wifi_na_sta_info_t *output)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    wifi_na_sta_info_t result = {0};
    wifi_freq_bands_t band;
    static const UCHAR zero[6] = {0};
    BOOL supported;
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || !params || !output)
        return WIFI_HAL_INVALID_ARGUMENTS;
    if ((params->sta_mac[0] & 1) || !memcmp(params->sta_mac, zero, sizeof(zero)))
        return WIFI_HAL_INVALID_VALUE;
    if (!vap->u.bss_info.enabled || !wifi_test_state.radio[vap->radio_index].enable)
        return WIFI_HAL_NOT_READY;
    if (wifi_test_state.managed[ap] &&
        !memcmp(params->sta_mac, wifi_test_state.client[ap], sizeof(params->sta_mac)))
        return WIFI_HAL_INVALID_VALUE;
    band = wifi_test_state.radio[vap->radio_index].band;
    supported = (band == WIFI_FREQUENCY_2_4_BAND && params->op_class == 81 &&
                 params->channel >= 1 && params->channel <= 11) ||
                (band == WIFI_FREQUENCY_5_BAND && params->op_class == 115 &&
                 params->channel >= 36 && params->channel <= 48 && !(params->channel % 4)) ||
                (band == WIFI_FREQUENCY_6_BAND && params->op_class == 131 &&
                 params->channel >= 1 && params->channel <= 9 && params->channel % 4 == 1);
    if (!supported) return WIFI_HAL_UNSUPPORTED;
    memcpy(result.sta_mac, params->sta_mac, sizeof(result.sta_mac));
    result.channel = params->channel;
    result.op_class = params->op_class;
    result.rcpi = (UINT)((-45 + 110) * 2); /* Fixed model RSSI, IEEE RCPI [0,220]. */
    *output = result;
    return WIFI_HAL_SUCCESS;
}
