#include "wifi_hal_test_accessors.h"

/* PUBLIC_INTERFACE */
/** No hardware airtime scheduler is advertised by the Linux reference model. */
INT wifi_getATMCapable(BOOL *out)
{
    if (!out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = FALSE;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Read disabled airtime management. */
INT wifi_getATMEnable(BOOL *out) { return wifi_getATMCapable(out); }
/* PUBLIC_INTERFACE */
/** Disabling absent airtime scheduling is idempotent; enabling it is unsupported. */
INT wifi_setATMEnable(BOOL value)
{
    if (value > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    return value ? WIFI_HAL_UNSUPPORTED : WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Hardware airtime allocation is unsupported and does not mutate AP configuration. */
INT wifi_setApATMAirTimePercent(INT ap, UINT percent)
{
    if (!ref_ap(ap) || percent > 100) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** No AP airtime reservation exists in the reference model. */
INT wifi_getApATMAirTimePercent(INT ap, UINT *out)
{
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = 0;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Per-client hardware scheduling is unsupported after validating its bounded inputs. */
INT wifi_setApATMSta(INT ap, UCHAR *mac, UINT percent)
{
    if (!ref_ap(ap) || !mac || percent > 100) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Return a terminated empty airtime reservation list into a nonempty caller buffer. */
INT wifi_getApATMSta(INT ap, UCHAR *out, UINT capacity)
{
    if (!ref_ap(ap) || !out || !capacity) return WIFI_HAL_INVALID_ARGUMENTS;
    out[0] = '\0';
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** TWT requires real firmware scheduling; do not fabricate a parameter result. */
INT wifi_getTWTParams(CHAR *name, wifi_twt_params_t *out)
{
    INT ap;
    if (!name || !out || wifi_getApIndexFromName(name, &ap)) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Validate a data-send request; over-the-air transmission is unsupported (NULL peer means broadcast). */
INT wifi_sendDataFrame(INT ap, mac_address_t mac, UCHAR *data, UINT len,
                       BOOL llc, UINT protocol, wifi_data_priority_t priority)
{
    (void)mac;
    if (!ref_ap(ap) || !data || !len || len > 65535 || llc > TRUE ||
        protocol > 65535 || (INT)priority < 0 || (INT)priority > 7)
        return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Validate action-frame buffers without claiming an RF transmission occurred. */
INT wifi_sendActionFrame(INT ap, mac_address_t mac, UINT frequency, UCHAR *frame, UINT len)
{
    if (!ref_ap(ap) || !mac || !frame || !len || len > 65535 || !frequency)
        return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Extended action transmission has the same unsupported RF boundary. */
INT wifi_sendActionFrameExt(INT ap, mac_address_t mac, UINT frequency, UINT wait,
                            UCHAR *frame, UINT len)
{
    (void)wait;
    return wifi_sendActionFrame(ap, mac, frequency, frame, len);
}
/* PUBLIC_INTERFACE */
/** GAS exchange requires an external peer/server; validate configuration but preserve all state. */
INT wifi_applyGASConfiguration(wifi_GASConfiguration_t *config)
{
    if (!config) return WIFI_HAL_INVALID_ARGUMENTS;
    if (config->PauseForServerResponse > TRUE) return WIFI_HAL_INVALID_VALUE;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Forward a borrowed management frame through the selected public callback ABI. */
INT mgmt_frame_received_callback(INT ap, mac_address_t mac, UCHAR *data, UINT len,
                                 wifi_mgmtFrameType_t type, wifi_direction_t dir)
{
    if (!ref_ap(ap) || !mac || !data || !len) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.mgmt_cb) return WIFI_HAL_NOT_READY;
#ifdef WIFI_HAL_VERSION_3_PHASE2
    wifi_frame_t frame = {0};
    frame.ap_index = ap;
    memcpy(frame.sta_mac, mac, 6);
    frame.type = type;
    frame.dir = dir;
    frame.len = len;
    frame.data = data;
    return wifi_test_state.mgmt_cb(ap, &frame);
#else
    return wifi_test_state.mgmt_cb(ap, mac, data, len, type, dir, 0);
#endif
}
/* PUBLIC_INTERFACE */
/** Register/clear an ANQP callback without inventing an incoming query. */
INT wifi_anqp_request_callback_register(wifi_anqp_request_callback_t cb)
{
    wifi_test_state.anqp_cb = cb;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** ANQP response transmission requires an external peer and is unsupported. */
INT wifi_anqpSendResponse(UINT ap, mac_address_t mac, UCHAR token, wifi_anqp_node_t *response)
{
    (void)token;
    if (!ref_ap((INT)ap) || !mac || !response) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** DPP peer-specific passphrases require a provisioning engine and are unsupported. */
INT wifi_dppSetSTAPassphrase(UINT ap, CHAR *peer, CHAR *passphrase)
{
    mac_address_t mac;
    if (!ref_ap((INT)ap) || !ref_mac(peer, mac) || !passphrase)
        return WIFI_HAL_INVALID_ARGUMENTS;
    if (strlen(passphrase) < 8 || strlen(passphrase) > 63) return WIFI_HAL_INVALID_VALUE;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Removing a DPP credential is unsupported; never alter the AP's security union. */
INT wifi_dppRemoveSTAPassphrase(UINT ap, CHAR *peer)
{
    mac_address_t mac;
    if (!ref_ap((INT)ap) || !ref_mac(peer, mac)) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
#define DPP_OPERATION(Name) \
    /* PUBLIC_INTERFACE */ \
    /** Validate a DPP context and explicitly reject unsupported provisioning/RF work. */ \
    INT Name(wifi_device_dpp_context_t *context) { \
        if (!context || !ref_ap((INT)context->ap_index)) return WIFI_HAL_INVALID_ARGUMENTS; \
        return WIFI_HAL_UNSUPPORTED; \
    }
DPP_OPERATION(wifi_dppInitiate)
DPP_OPERATION(wifi_dppCancel)
DPP_OPERATION(wifi_dppSendAuthCnf)
DPP_OPERATION(wifi_dppSendConfigResponse)
/* PUBLIC_INTERFACE */
/** Register or clear typed DPP callbacks, all of which are reset with the model. */
INT wifi_dpp_frame_received_callbacks_register(wifi_dppAuthResponse_callback_t auth,
        wifi_dppConfigRequest_callback_t config, wifi_dppConfigResult_callback_t result,
        wifi_dppReconfigAnnounce_callback_t announce, wifi_dppReconfigAuthResponse_callback_t reauth)
{
    wifi_test_state.dpp_auth_cb = auth;
    wifi_test_state.dpp_config_cb = config;
    wifi_test_state.dpp_result_cb = result;
    wifi_test_state.dpp_announce_cb = announce;
    wifi_test_state.dpp_reauth_cb = reauth;
    return WIFI_HAL_SUCCESS;
}
