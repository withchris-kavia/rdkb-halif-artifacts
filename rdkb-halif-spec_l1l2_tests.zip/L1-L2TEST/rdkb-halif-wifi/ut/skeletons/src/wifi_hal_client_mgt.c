#include <limits.h>
#include <string.h>
#include "wifi_hal_test_backend.h"

/* PUBLIC_INTERFACE */
/** Retrieve global band steering enable state. */
INT wifi_getBandSteeringEnable(BOOL *enabled)
{
    if (!enabled) return WIFI_HAL_INVALID_ARGUMENTS;
    *enabled = wifi_test_state.steering;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Set global steering enable after validating the boolean. */
INT wifi_setBandSteeringEnable(BOOL enabled)
{
    if (enabled > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.steering = enabled;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Copy the configured group into a caller buffer of at least 64 bytes. */
INT wifi_getBandSteeringApGroup(char *group)
{
    if (!group) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(group, wifi_test_state.group);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Store one or more positive-index AP pairs, leaving the previous group on error. */
INT wifi_setBandSteeringApGroup(char *group)
{
    const char *cursor;
    size_t length;
    UINT member;
    if (!group) return WIFI_HAL_INVALID_ARGUMENTS;
    for (length = 0; length < sizeof(wifi_test_state.group) && group[length]; ++length) {}
    if (!length || length == sizeof(wifi_test_state.group)) return WIFI_HAL_INVALID_VALUE;
    cursor = group;
    for (;;) {
        for (member = 0; member < 2; ++member) {
            UINT value = 0;
            if (*cursor < '0' || *cursor > '9') return WIFI_HAL_INVALID_VALUE;
            do {
                UINT digit = (UINT)(*cursor - '0');
                if (value > (UINT_MAX - digit) / 10) return WIFI_HAL_INVALID_VALUE;
                value = value * 10 + digit;
                ++cursor;
            } while (*cursor >= '0' && *cursor <= '9');
            if (!value) return WIFI_HAL_INVALID_VALUE;
            if (!member) {
                if (*cursor != ',') return WIFI_HAL_INVALID_VALUE;
                ++cursor;
            }
        }
        if (!*cursor) break;
        if (*cursor != ';') return WIFI_HAL_INVALID_VALUE;
        ++cursor;
    }
    /* Validate every pair before replacing a previously valid configuration. */
    memcpy(wifi_test_state.group, group, length + 1);
    return WIFI_HAL_SUCCESS;
}

/* Each generated public accessor has identical documented range/error semantics. */
/* PUBLIC_INTERFACE */
/** Generate per-radio threshold getters and validated setters, with isolated slots. */
#define THRESHOLD(Name, Slot, Min, Max) \
INT wifi_getBandSteering##Name(INT radio, INT *value) \
{ \
    if (!wifi_test_radio_valid(radio) || !value) return WIFI_HAL_INVALID_ARGUMENTS; \
    *value = wifi_test_state.thresholds[radio][Slot]; \
    return WIFI_HAL_SUCCESS; \
} \
INT wifi_setBandSteering##Name(INT radio, INT value) \
{ \
    if (!wifi_test_radio_valid(radio)) return WIFI_HAL_INVALID_ARGUMENTS; \
    if (value < (Min) || value > (Max)) return WIFI_HAL_INVALID_VALUE; \
    wifi_test_state.thresholds[radio][Slot] = value; \
    return WIFI_HAL_SUCCESS; \
}
THRESHOLD(BandUtilizationThreshold, 0, 0, 100)
THRESHOLD(RSSIThreshold, 1, -110, 0)
THRESHOLD(PhyRateThreshold, 2, 0, 1000000)
THRESHOLD(OverloadInactiveTime, 3, 0, 86400)
THRESHOLD(IdleInactiveTime, 4, 0, 86400)
#undef THRESHOLD

/* PUBLIC_INTERFACE */
/** Change AP BSS transition state in the shared VAP configuration. */
INT wifi_setBSSTransitionActivation(UINT ap, BOOL enabled)
{
    wifi_vap_info_t *vap = wifi_test_vap((INT)ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || enabled > TRUE)
        return WIFI_HAL_INVALID_ARGUMENTS;
    vap->u.bss_info.bssTransitionActivated = enabled;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return AP BSS transition activation. */
INT wifi_getBSSTransitionActivation(UINT ap, BOOL *enabled)
{
    wifi_vap_info_t *vap = wifi_test_vap((INT)ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || !enabled) return WIFI_HAL_INVALID_ARGUMENTS;
    *enabled = vap->u.bss_info.bssTransitionActivated;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Compatibility getter for BSS transition activation. */
INT wifi_getBSSTransitionActivated(INT ap, BOOL *enabled)
{ return wifi_getBSSTransitionActivation((UINT)ap, enabled); }
/* PUBLIC_INTERFACE */
/** Set neighbor report activation only on AP VAPs. */
INT wifi_setNeighborReportActivation(UINT ap, BOOL enabled)
{
    wifi_vap_info_t *vap = wifi_test_vap((INT)ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || enabled > TRUE)
        return WIFI_HAL_INVALID_ARGUMENTS;
    vap->u.bss_info.nbrReportActivated = enabled;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return neighbor report activation. */
INT wifi_getNeighborReportActivation(UINT ap, BOOL *enabled)
{
    wifi_vap_info_t *vap = wifi_test_vap((INT)ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_ap || !enabled) return WIFI_HAL_INVALID_ARGUMENTS;
    *enabled = vap->u.bss_info.nbrReportActivated;
    return WIFI_HAL_SUCCESS;
}
