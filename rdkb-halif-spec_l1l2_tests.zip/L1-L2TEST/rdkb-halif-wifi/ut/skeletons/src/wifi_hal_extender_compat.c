#include "wifi_hal_test_accessors.h"

RADIO_BOOL(wifi_getBSSColorEnabled, wifi_setBSSColorEnabled, RX.color_enabled)
AP_SET(wifi_setApCsaDeauth, INT, AX.csa_deauth, value >= 0 && value <= 2)

/* PUBLIC_INTERFACE */
/** Report the model's BSS transition implementation for a live AP. */
INT wifi_getBSSTransitionImplemented(UINT ap, BOOL *out)
{
    if (!ref_ap((INT)ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = TRUE;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Configure a bounded scan filter atomically (0=none, 1=include, 2=exclude). */
INT wifi_setApScanFilter(INT ap, INT mode, CHAR *ssid)
{
    if (!ref_ap(ap) || !ssid) return WIFI_HAL_INVALID_ARGUMENTS;
    if (mode < 0 || mode > 2 || strlen(ssid) > 32) return WIFI_HAL_INVALID_VALUE;
    AX.scan_filter = mode;
    strcpy(AX.scan_ssid, ssid);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Register/clear the typed trigger callback; module is borrowed only during registration. */
void wifi_steerTriggered_callback_register(wifi_steerTriggered_callback cb, CHAR *module)
{
    (void)module;
    wifi_test_state.trigger_cb = cb;
}
/* PUBLIC_INTERFACE */
/** Report only capabilities actually observed; the model has no peer Extended Capabilities IE. */
INT wifi_getBTMClientCapabilityList(UINT ap, wifi_BTMCapabilities_t *out)
{
    if (!ref_ap((INT)ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(out, 0, sizeof(*out));
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Replace at most eight neighbor reports, clearing the list with count zero. */
INT wifi_setNeighborReports(UINT ap, UINT count, wifi_NeighborReport_t *reports)
{
    if (!ref_ap((INT)ap) || count > 8 || (count && !reports)) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(AX.neighbors, 0, sizeof(AX.neighbors));
    if (count) memcpy(AX.neighbors, reports, count * sizeof(*reports));
    AX.neighbor_count = count;
    return WIFI_HAL_SUCCESS;
}

#ifndef WIFI_HAL_VERSION_3_PHASE2
/* PUBLIC_INTERFACE */
/** Deliver a deterministic BTM response using the baseline textual peer ABI. */
INT wifi_setBTMRequest(UINT ap, CHAR *text, wifi_BTMRequest_t *request)
{
    mac_address_t mac;
    wifi_BTMResponse_t response = {0};
    if (!ref_ap((INT)ap) || !ref_mac(text, mac) || !request) return WIFI_HAL_INVALID_ARGUMENTS;
    if (request->numCandidates > MAX_CANDIDATES || request->urlLen > MAX_URL_LEN)
        return WIFI_HAL_INVALID_VALUE;
    response.token = request->token;
    if (wifi_test_state.response_cb[ap]) wifi_test_state.response_cb[ap](ap, text, &response);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Allocate a dialog token and synchronously deliver a borrowed baseline beacon report. */
INT wifi_setRMBeaconRequest(UINT ap, CHAR *text, wifi_BeaconRequest_t *request, UCHAR *token)
{
    mac_address_t mac;
    wifi_BeaconReport_t report = {0};
    UINT count = 1;
    if (!ref_ap((INT)ap) || !ref_mac(text, mac) || !request || !token)
        return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.beacon_cb[ap]) return WIFI_HAL_NOT_READY;
    wifi_test_state.token[ap] = wifi_test_state.token[ap] == 255 ? 1 : wifi_test_state.token[ap] + 1;
    *token = wifi_test_state.token[ap];
    report.channel = request->channel;
    report.rcpi = 90;
    wifi_test_state.beacon_cb[ap](ap, &report, &count, token);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return the reference model's five-byte RRM capability vector for a valid peer. */
INT wifi_getRMCapabilities(CHAR *text, UCHAR out[5])
{
    mac_address_t mac;
    if (!ref_mac(text, mac) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(out, 0, 5);
    out[0] = 0x70;
    return WIFI_HAL_SUCCESS;
}
#endif
