#include <string.h>
#include "wifi_hal_test_backend.h"

/* Convert MHz to a channel without accepting an off-grid or cross-band frequency. */
static UINT bss_channel(const wifi_bss_info_t *bss)
{
    UINT base, maximum;
    switch (bss->oper_freq_band) {
    case WIFI_FREQUENCY_2_4_BAND:
        if (bss->freq == 2484) return 14;
        base = 2407;
        maximum = 2472;
        break;
    case WIFI_FREQUENCY_5_BAND:
    case WIFI_FREQUENCY_5L_BAND:
    case WIFI_FREQUENCY_5H_BAND:
        base = 5000;
        maximum = 5895;
        break;
    case WIFI_FREQUENCY_6_BAND:
        if (bss->freq == 5935) return 2;
        base = 5950;
        maximum = 7115;
        break;
    default: return 0;
    }
    if (bss->freq <= base || bss->freq > maximum || (bss->freq - base) % 5) return 0;
    return (bss->freq - base) / 5;
}

/* PUBLIC_INTERFACE */
/** Replace/clear station connection callback. */
void wifi_staConnectionStatus_callback_register(wifi_staConnectionStatus_callback cb)
{ wifi_test_state.sta_cb = cb; }

/* PUBLIC_INTERFACE */
/** Discover networks through the declared radio scan result API; caller frees results. */
INT wifi_findNetworks(INT ap, wifi_channel_t *channel, wifi_bss_info_t **bss, UINT *count)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (bss) *bss = NULL;
    if (count) *count = 0;
    if (!vap || vap->vap_mode != wifi_vap_mode_sta) return WIFI_HAL_INVALID_ARGUMENTS;
    return wifi_getScanResults(vap->radio_index, channel, bss, count);
}

/* PUBLIC_INTERFACE */
/** Connect an enabled STA to a well-formed discovered BSS and publish stats. */
INT wifi_connect(INT ap, wifi_bss_info_t *bss)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    wifi_station_stats_t *stats;
    UINT channel;
    if (!vap || vap->vap_mode != wifi_vap_mode_sta || !bss) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!vap->u.sta_info.enabled || !wifi_test_state.radio[vap->radio_index].enable)
        return WIFI_HAL_NOT_READY;
    if (!memchr(bss->ssid, '\0', sizeof(bss->ssid)) || !bss->ssid[0] ||
        bss->ie_len > MAX_IE_ELEMENT_LEN ||
        bss->oper_freq_band != wifi_test_state.radio[vap->radio_index].band)
        return WIFI_HAL_INVALID_VALUE;
    channel = bss_channel(bss);
    if (!channel) return WIFI_HAL_INVALID_VALUE;
    stats = &wifi_test_state.station[ap];
    memset(stats, 0, sizeof(*stats));
    stats->vap_index = (UINT)ap;
    stats->connect_status = wifi_connection_status_connected;
    stats->channel = channel;
    stats->channelWidth = (UINT)bss->oper_chan_bw;
    vap->u.sta_info.conn_status = stats->connect_status;
    memcpy(vap->u.sta_info.bssid, bss->bssid, 6);
    if (wifi_test_state.sta_cb) wifi_test_state.sta_cb(ap, bss, stats);
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Disconnect a STA and deliver initialized callback data without busy waits. */
INT wifi_disconnect(INT ap)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    wifi_bss_info_t bss = {0};
    wifi_station_stats_t *stats;
    if (!vap || vap->vap_mode != wifi_vap_mode_sta) return WIFI_HAL_INVALID_ARGUMENTS;
    stats = &wifi_test_state.station[ap];
    memset(stats, 0, sizeof(*stats));
    stats->vap_index = (UINT)ap;
    stats->connect_status = wifi_connection_status_disconnected;
    vap->u.sta_info.conn_status = stats->connect_status;
    if (wifi_test_state.sta_cb) wifi_test_state.sta_cb(ap, &bss, stats);
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy station statistics, including legitimate zero counters when disconnected. */
INT wifi_getStationStats(INT ap, wifi_station_stats_t *stats)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || vap->vap_mode != wifi_vap_mode_sta || !stats) return WIFI_HAL_INVALID_ARGUMENTS;
    *stats = wifi_test_state.station[ap];
    stats->vap_index = (UINT)ap;
    stats->connect_status = vap->u.sta_info.conn_status;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Validate an existing STA capability request; current public structure is empty. */
INT wifi_getStationCapability(INT ap, wifi_sta_capability_t *cap)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    return vap && vap->vap_mode == wifi_vap_mode_sta && cap ?
           WIFI_HAL_SUCCESS : WIFI_HAL_INVALID_ARGUMENTS;
}
