#include <arpa/inet.h>
#include "wifi_hal_test_accessors.h"

static INT acl_add(INT ap, const UCHAR *mac)
{
    UINT i;
    static const UCHAR zero[6] = {0};
    if (!ref_ap(ap) || !mac) return WIFI_HAL_INVALID_ARGUMENTS;
    if ((mac[0] & 1) || !memcmp(mac, zero, 6)) return WIFI_HAL_INVALID_VALUE;
    for (i = 0; i < AX.acl_count; ++i)
        if (!memcmp(AX.acl[i], mac, 6)) return WIFI_HAL_SUCCESS;
    if (AX.acl_count == WIFI_TEST_ACL) return WIFI_HAL_ERROR;
    memcpy(AX.acl[AX.acl_count++], mac, 6);
    return WIFI_HAL_SUCCESS;
}
static INT acl_del(INT ap, const UCHAR *mac)
{
    UINT i;
    if (!ref_ap(ap) || !mac) return WIFI_HAL_INVALID_ARGUMENTS;
    for (i = 0; i < AX.acl_count; ++i) {
        if (memcmp(AX.acl[i], mac, 6)) continue;
        --AX.acl_count;
        memmove(AX.acl[i], AX.acl[i + 1], (AX.acl_count - i) * sizeof(mac_address_t));
        memset(AX.acl[AX.acl_count], 0, sizeof(mac_address_t));
        return WIFI_HAL_SUCCESS;
    }
    return WIFI_HAL_INVALID_VALUE;
}
#ifdef WIFI_HAL_VERSION_3_PHASE2
/* PUBLIC_INTERFACE */
/** Add one binary unicast ACL entry, idempotently, up to the model capacity. */
INT wifi_addApAclDevice(INT ap, mac_address_t mac) { return acl_add(ap, mac); }
/* PUBLIC_INTERFACE */
/** Delete a matching binary entry without modifying other entries. */
INT wifi_delApAclDevice(INT ap, mac_address_t mac) { return acl_del(ap, mac); }
/* PUBLIC_INTERFACE */
/** Copy the complete ACL to caller storage; insufficient capacity leaves outputs untouched. */
INT wifi_getApAclDevices(INT ap, mac_address_t *out, UINT capacity, UINT *count)
{
    if (!ref_ap(ap) || !out || !count) return WIFI_HAL_INVALID_ARGUMENTS;
    if (capacity < AX.acl_count) return WIFI_HAL_INVALID_VALUE;
    if (AX.acl_count) memcpy(out, AX.acl, AX.acl_count * sizeof(*out));
    *count = AX.acl_count;
    return WIFI_HAL_SUCCESS;
}
#else
/* PUBLIC_INTERFACE */
/** Parse an exact textual MAC before adding an ACL entry. */
INT wifi_addApAclDevice(INT ap, CHAR *text)
{
    mac_address_t mac;
    return ref_mac(text, mac) ? acl_add(ap, mac) : WIFI_HAL_INVALID_ARGUMENTS;
}
/* PUBLIC_INTERFACE */
/** Parse an exact textual MAC before deleting an ACL entry. */
INT wifi_delApAclDevice(INT ap, CHAR *text)
{
    mac_address_t mac;
    return ref_mac(text, mac) ? acl_del(ap, mac) : WIFI_HAL_INVALID_ARGUMENTS;
}
/* PUBLIC_INTERFACE */
/** Copy comma-separated ACL MACs only if the complete list fits the byte capacity. */
INT wifi_getApAclDevices(INT ap, CHAR *out, UINT capacity)
{
    UINT i;
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    if (capacity < (AX.acl_count ? AX.acl_count * 18 : 1)) return WIFI_HAL_INVALID_VALUE;
    out[0] = '\0';
    for (i = 0; i < AX.acl_count; ++i) {
        ref_mac_text(AX.acl[i], out + i * 18);
        if (i + 1 < AX.acl_count) out[i * 18 + 17] = ',';
    }
    return WIFI_HAL_SUCCESS;
}
#endif
/* PUBLIC_INTERFACE */
/** Clear all entries for one AP only. */
INT wifi_delApAclDevices(INT ap)
{
    if (!ref_ap(ap)) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(AX.acl, 0, sizeof(AX.acl));
    AX.acl_count = 0;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Disconnect a managed client present in the ACL when explicitly requested. */
INT wifi_kickApAclAssociatedDevices(INT ap, BOOL kick)
{
    UINT i;
    if (!ref_ap(ap) || kick > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
    if (kick && wifi_test_state.managed[ap])
        for (i = 0; i < AX.acl_count; ++i)
            if (!memcmp(AX.acl[i], wifi_test_state.client[ap], 6))
                return wifi_test_client_event(ap, FALSE);
    return WIFI_HAL_SUCCESS;
}

static int parse_ip(const CHAR *text, ip_addr_t *ip)
{
    unsigned char bytes[16];
    if (!text) return 0;
    memset(ip, 0, sizeof(*ip));
    if (inet_pton(AF_INET, text, bytes) == 1) {
        ip->family = wifi_ip_family_ipv4;
        memcpy(&ip->u.IPv4addr, bytes, 4);
        return 1;
    }
    if (inet_pton(AF_INET6, text, bytes) == 1) {
        ip->family = wifi_ip_family_ipv6;
        memcpy(ip->u.IPv6addr, bytes, 16);
        return 1;
    }
    return 0;
}
static void print_ip(const ip_addr_t *ip, CHAR *text)
{
    unsigned char bytes[16];
    int family = ip->family == wifi_ip_family_ipv6 ? AF_INET6 : AF_INET;
    memcpy(bytes, &ip->u, family == AF_INET6 ? 16 : 4);
    if (!inet_ntop(family, bytes, text, 46)) text[0] = '\0';
}
static INT radius_set(INT ap, CHAR *address, UINT port, CHAR *secret, UINT slot)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    wifi_vap_security_t security;
    ip_addr_t ip;
    if (!ref_ap(ap) || !address || !secret) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!port || port > 65535 || !secret[0] || strlen(secret) >= 64 || !parse_ip(address, &ip))
        return WIFI_HAL_INVALID_VALUE;
    if (B.security.mode != wifi_security_mode_wpa2_enterprise &&
        B.security.mode != wifi_security_mode_wpa3_enterprise &&
        B.security.mode != wifi_security_mode_wpa_wpa2_enterprise &&
        B.security.mode != wifi_security_mode_wpa_enterprise) return WIFI_HAL_INVALID_VALUE;
    security = B.security;
    if (slot == 2) {
        security.u.radius.dasip = ip;
        security.u.radius.dasport = (USHORT)port;
        strcpy(security.u.radius.daskey, secret);
    } else if (slot == 1) {
#ifdef WIFI_HAL_VERSION_3_PHASE2
        security.u.radius.s_ip = ip;
#else
        if (strlen(address) >= sizeof(security.u.radius.s_ip)) return WIFI_HAL_INVALID_VALUE;
        strcpy((CHAR *)security.u.radius.s_ip, address);
#endif
        security.u.radius.s_port = (USHORT)port;
        strcpy(security.u.radius.s_key, secret);
    } else {
#ifdef WIFI_HAL_VERSION_3_PHASE2
        security.u.radius.ip = ip;
#else
        if (strlen(address) >= sizeof(security.u.radius.ip)) return WIFI_HAL_INVALID_VALUE;
        strcpy((CHAR *)security.u.radius.ip, address);
#endif
        security.u.radius.port = (USHORT)port;
        strcpy(security.u.radius.key, secret);
    }
    return wifi_setApSecurity(ap, &security);
}
static INT radius_get(INT ap, CHAR *address, UINT *port, CHAR *secret, UINT slot)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    const CHAR *key, *end;
    ip_addr_t ip;
    if (!ref_ap(ap) || !address || !port || !secret) return WIFI_HAL_INVALID_ARGUMENTS;
    if (B.security.mode != wifi_security_mode_wpa2_enterprise &&
        B.security.mode != wifi_security_mode_wpa3_enterprise &&
        B.security.mode != wifi_security_mode_wpa_wpa2_enterprise &&
        B.security.mode != wifi_security_mode_wpa_enterprise) return WIFI_HAL_INVALID_VALUE;
    /* All three fixed secret fields and the documented caller buffer are 64 bytes. */
    key = slot == 2 ? B.security.u.radius.daskey :
          slot == 1 ? B.security.u.radius.s_key : B.security.u.radius.key;
    end = memchr(key, '\0', sizeof(B.security.u.radius.key));
    if (!end) return WIFI_HAL_INVALID_VALUE;
    if (slot == 2) {
        ip = B.security.u.radius.dasip;
        print_ip(&ip, address);
        *port = B.security.u.radius.dasport;
    } else if (slot == 1) {
#ifdef WIFI_HAL_VERSION_3_PHASE2
        ip = B.security.u.radius.s_ip;
        print_ip(&ip, address);
#else
        snprintf(address, 46, "%.*s", (int)sizeof(B.security.u.radius.s_ip),
                 (CHAR *)B.security.u.radius.s_ip);
#endif
        *port = B.security.u.radius.s_port;
    } else {
#ifdef WIFI_HAL_VERSION_3_PHASE2
        ip = B.security.u.radius.ip;
        print_ip(&ip, address);
#else
        snprintf(address, 46, "%.*s", (int)sizeof(B.security.u.radius.ip),
                 (CHAR *)B.security.u.radius.ip);
#endif
        *port = B.security.u.radius.port;
    }
    memcpy(secret, key, (size_t)(end - key) + 1);
    return WIFI_HAL_SUCCESS;
}
#define RADIUS_API(Get, Set, Slot) \
    /* PUBLIC_INTERFACE */ \
    /** Read the selected RADIUS endpoint into HAL-sized caller buffers. */ \
    INT Get(INT ap, CHAR *ip, UINT *port, CHAR *key) { return radius_get(ap, ip, port, key, Slot); } \
    /* PUBLIC_INTERFACE */ \
    /** Validate all endpoint fields before committing shared enterprise security. */ \
    INT Set(INT ap, CHAR *ip, UINT port, CHAR *key) { return radius_set(ap, ip, port, key, Slot); }
RADIUS_API(wifi_getApSecurityRadiusServer, wifi_setApSecurityRadiusServer, 0)
RADIUS_API(wifi_getApSecuritySecondaryRadiusServer, wifi_setApSecuritySecondaryRadiusServer, 1)
RADIUS_API(wifi_getApDASRadiusServer, wifi_setApDASRadiusServer, 2)

/* PUBLIC_INTERFACE */
/** Report the reference AP's configuration state without starting real WPS. */
INT wifi_getApWpsConfigurationState(INT ap, CHAR *out)
{
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(out, "Configured");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** A real enrollee exchange is unavailable; validate the request without changing stored PIN. */
INT wifi_setApWpsEnrolleePin(INT ap, CHAR *pin)
{
    size_t i, length;
    if (!ref_ap(ap) || !pin) return WIFI_HAL_INVALID_ARGUMENTS;
    length = strlen(pin);
    if (length != 4 && length != 8) return WIFI_HAL_INVALID_VALUE;
    for (i = 0; i < length; ++i)
        if (pin[i] < '0' || pin[i] > '9') return WIFI_HAL_INVALID_VALUE;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** The model cannot perform a WPS push-button radio exchange. */
INT wifi_setApWpsButtonPush(INT ap)
{ return ref_ap(ap) ? WIFI_HAL_UNSUPPORTED : WIFI_HAL_INVALID_ARGUMENTS; }
/* PUBLIC_INTERFACE */
/** Cancel is idempotent because the model never has a physical WPS session. */
INT wifi_cancelApWPS(INT ap)
{ return ref_ap(ap) ? WIFI_HAL_SUCCESS : WIFI_HAL_INVALID_ARGUMENTS; }
