#include <stdio.h>
#include <string.h>
#include "wifi_hal_test_accessors.h"

RADIO_GET(wifi_getRadioResetCount, ULONG, RX.resets)
RADIO_GET(wifi_getRadioStatus, BOOL, R.enable)
RADIO_BOOL(wifi_getRadioDfsEnable, wifi_setRadioDfsEnable, R.DfsEnabled)
RADIO_BOOL(wifi_getRadioDfsAtBootUpEnable, wifi_setRadioDfsAtBootUpEnable, R.DfsEnabledBootup)
RADIO_GET(wifi_getRadioMCS, INT, R.mcs)
RADIO_SET(wifi_setRadioMCS, INT, R.mcs, value >= -1 && value <= 11)
RADIO_GET(wifi_getRadioPercentageTransmitPower, ULONG, R.transmitPower)
RADIO_GET(wifi_getRadioCarrierSenseThresholdInUse, INT, RX.carrier)
RADIO_SET(wifi_setRadioCarrierSenseThresholdInUse, INT, RX.carrier, value >= -110 && value <= 0)
RADIO_SET(wifi_setRadioCtsProtectionEnable, BOOL, R.ctsProtection, value <= TRUE)
RADIO_SET(wifi_setRadioObssCoexistenceEnable, BOOL, R.obssCoex, value <= TRUE)
RADIO_SET(wifi_setRadioFragmentationThreshold, UINT, R.fragmentationThreshold,
          value >= 256 && value <= 2346)
RADIO_SET(wifi_setRadioSTBCEnable, BOOL, R.stbcEnable, value <= TRUE)
RADIO_BOOL(wifi_getRadioAMSDUEnable, wifi_setRadioAMSDUEnable, R.amsduEnable)
RADIO_BOOL(wifi_getRadioAutoBlockAckEnable, wifi_setRadioAutoBlockAckEnable, RX.auto_ack)
RADIO_BOOL(wifi_getRadioIGMPSnoopingEnable, wifi_setRadioIGMPSnoopingEnable, RX.igmp)
RADIO_GET(wifi_getDownlinkMuType, wifi_dl_mu_type_t, RX.downlink)
RADIO_SET(wifi_setDownlinkMuType, wifi_dl_mu_type_t, RX.downlink,
          value >= WIFI_DL_MU_TYPE_NONE && value <= WIFI_DL_MU_TYPE_OFDMA_MIMO)
RADIO_GET(wifi_getUplinkMuType, wifi_ul_mu_type_t, RX.uplink)
RADIO_SET(wifi_setUplinkMuType, wifi_ul_mu_type_t, RX.uplink,
          value >= WIFI_UL_MU_TYPE_NONE && value <= WIFI_UL_MU_TYPE_OFDMA)
RADIO_GET(wifi_getGuardInterval, wifi_guard_interval_t, R.guardInterval)
RADIO_SET(wifi_setGuardInterval, wifi_guard_interval_t, R.guardInterval,
          value == wifi_guard_interval_auto || value == wifi_guard_interval_400 ||
          value == wifi_guard_interval_800 || value == wifi_guard_interval_1600 ||
          value == wifi_guard_interval_3200)
RADIO_GET(wifi_getBSSColor, UCHAR, RX.color)
RADIO_SET(wifi_setBSSColor, UCHAR, RX.color, value <= 63)

/* PUBLIC_INTERFACE */
/** Reset one radio's configuration and sampling interval, leaving VAPs/other radios alone. */
INT wifi_factoryResetRadio(INT radio)
{
    ULONG resets;
    if (!wifi_test_radio_valid(radio)) return WIFI_HAL_INVALID_ARGUMENTS;
    resets = RX.resets + 1;
    memset(&RX, 0, sizeof(RX));
    RX.resets = resets;
    R = wifi_test_state.factory_radio[radio];
    wifi_test_state.bytes[radio] = 0;
    wifi_test_state.elapsed[radio] = 0;
    wifi_test_state.interval_ready[radio] = FALSE;
    wifi_test_state.start[radio] = wifi_test_state.clock;
    wifi_test_state.stats_enabled[radio] = TRUE;
    wifi_test_state.detailed_stats_enabled[radio] = FALSE;
    wifi_test_state.scan_pending[radio] = FALSE;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Reset all live radio configurations without inventing or removing radios. */
INT wifi_factoryResetRadios(void)
{
    UINT radio;
    if (!wifi_test_state.initialized) return WIFI_HAL_NOT_READY;
    for (radio = 0; radio < wifi_test_state.radios; ++radio)
        if (wifi_factoryResetRadio((INT)radio)) return WIFI_HAL_ERROR;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Copy the reference interface name into the HAL caller's output buffer. */
INT wifi_getRadioIfName(INT radio, CHAR *out)
{
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    sprintf(out, "radio%d", radio);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return the inclusive reference carrier-sense range in two caller-provided slots. */
INT wifi_getRadioCarrierSenseThresholdRange(INT radio, INT *out)
{
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    out[0] = -110;
    out[1] = 0;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Settings are synchronous in the model; validate the requested live radio. */
INT wifi_applyRadioSettings(INT radio)
{
    return wifi_test_radio_valid(radio) ? WIFI_HAL_SUCCESS : WIFI_HAL_INVALID_ARGUMENTS;
}
/* PUBLIC_INTERFACE */
/** Return elapsed virtual subsystem time, not the host's uptime. */
INT wifi_getRadioUpTime(INT radio, ULONG *out)
{
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = wifi_test_state.clock - 1;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** The model accepts reverse-direction grant configuration for deterministic round-trips. */
INT wifi_getRadioReverseDirectionGrantSupported(INT radio, BOOL *out)
{
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = TRUE;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Zero-wait DFS requires real radar/CAC handling and is not advertised. */
INT wifi_setZeroDFSState(UINT radio, BOOL enable, BOOL precac)
{
    if (!wifi_test_radio_valid((INT)radio) || enable > TRUE || precac > TRUE)
        return WIFI_HAL_INVALID_ARGUMENTS;
    return enable || precac ? WIFI_HAL_UNSUPPORTED : WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Report disabled zero-wait DFS; no simulated radar success is fabricated. */
INT wifi_getZeroDFSState(UINT radio, BOOL *enable, BOOL *precac)
{
    if (!wifi_test_radio_valid((INT)radio) || !enable || !precac) return WIFI_HAL_INVALID_ARGUMENTS;
    *enable = FALSE;
    *precac = FALSE;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Enumerate bounded, deterministic available colors excluding the configured color. */
INT wifi_getAvailableBSSColor(INT radio, INT capacity, UCHAR *out, INT *count)
{
    INT color, used = 0;
    if (!wifi_test_radio_valid(radio) || capacity < 0 || capacity > 63 ||
        !count || (capacity && !out)) return WIFI_HAL_INVALID_ARGUMENTS;
    for (color = 1; color <= 63 && used < capacity; ++color)
        if (color != RX.color) out[used++] = (UCHAR)color;
    *count = used;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** MU EDCA scheduling is not implemented by the reference model. */
INT wifi_getMuEdca(INT radio, wifi_access_category_t category, wifi_edca_t *out)
{
    if (!wifi_test_radio_valid(radio) || !out || (INT)category < 0 || (INT)category > 3)
        return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Hardware-specific ACK scheduling is not simulated. */
INT wifi_setDownlinkDataAckType(INT radio, wifi_dl_data_ack_type_t type)
{
    (void)type;
    if (!wifi_test_radio_valid(radio)) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_UNSUPPORTED;
}
/* PUBLIC_INTERFACE */
/** Return initialized 802.11ax defaults; no active TWT sessions are advertised. */
INT wifi_get80211axDefaultParameters(INT radio, wifi_80211ax_params_t *out)
{
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(out, 0, sizeof(*out));
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return a deterministic reference sensor value (degrees Celsius), not host telemetry. */
INT wifi_hal_getRadioTemperature(wifi_radio_index_t radio, wifi_radioTemperature_t *out)
{
    if (!wifi_test_radio_valid((INT)radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(out, 0, sizeof(*out));
    out->radio_Temperature = 40;
    return WIFI_HAL_SUCCESS;
}
