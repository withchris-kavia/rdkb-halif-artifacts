#include <string.h>
#include <stdlib.h>
#include "wifi_hal_test_accessors.h"

/* PUBLIC_INTERFACE */
/** Fill requested channels, or one current-channel snapshot for a zero-count ONCHAN request. */
INT wifi_getRadioChannelStats(INT radio, wifi_channelStats_t *stats, INT count)
{
    INT i;
    if (!wifi_test_radio_valid(radio) || !stats || count < 0 || count > MAX_CHANNELS)
        return WIFI_HAL_INVALID_ARGUMENTS;
    if (!count) {
        stats[0].ch_number = (INT)wifi_test_state.radio[radio].channel;
        count = 1;
    }
    for (i = 0; i < count; ++i)
        if (stats[i].ch_number < 1 || stats[i].ch_number > 233) return WIFI_HAL_INVALID_VALUE;
    for (i = 0; i < count; ++i) {
        INT channel = stats[i].ch_number;
        memset(&stats[i], 0, sizeof(stats[i]));
        stats[i].ch_number = channel;
        stats[i].ch_in_pool = TRUE;
        stats[i].ch_noise = -95;
        stats[i].ch_utilization = 20;
        stats[i].ch_utilization_total = wifi_test_state.clock * 100;
        stats[i].ch_utilization_busy = wifi_test_state.clock * 20;
    }
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Resolve SSID membership using the live VAP map. */
INT wifi_getSSIDRadioIndex(INT ap, INT *radio)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || !radio) return WIFI_HAL_INVALID_ARGUMENTS;
    *radio = (INT)vap->radio_index;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Validate an existing SSID; model configuration changes are synchronous. */
INT wifi_applySSIDSettings(INT ap)
{ return wifi_test_vap(ap) ? WIFI_HAL_SUCCESS : WIFI_HAL_INVALID_ARGUMENTS; }

/* PUBLIC_INTERFACE */
/** Schedule a declared scan; completion occurs through the private event pump. */
INT wifi_startNeighborScan(INT ap, wifi_neighborScanMode_t mode, INT dwell,
                          UINT count, UINT *channels)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    wifi_bss_info_t *result = NULL;
    wifi_channel_t channel;
    UINT n, found = 0;
    int status;
    if (!vap || dwell <= 0 || !count || count > MAX_CHANNELS || !channels ||
        (INT)mode < 0 || (INT)mode > 2) return WIFI_HAL_INVALID_ARGUMENTS;
    for (n = 0; n < count; ++n)
        if (!channels[n] || channels[n] > 233) return WIFI_HAL_INVALID_VALUE;
    if (wifi_test_state.scan_pending[vap->radio_index]) return WIFI_HAL_NOT_READY;
    channel.band = wifi_test_state.radio[vap->radio_index].band;
    channel.channel = (INT)channels[0];
    status = wifi_getScanResults(vap->radio_index, &channel, &result, &found);
    if (status) return status;
    wifi_test_state.scan_result[vap->radio_index] = result[0];
    free(result);
    wifi_test_state.scan_pending[vap->radio_index] = TRUE;
    return WIFI_HAL_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Register a non-NULL steering callback. */
INT wifi_steering_eventRegister(wifi_steering_eventCB_t cb)
{
    if (!cb) return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.steering_cb = cb;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Unregister the steering callback. */
INT wifi_steering_eventUnregister(void)
{ wifi_test_state.steering_cb = NULL; return WIFI_HAL_SUCCESS; }

/* PUBLIC_INTERFACE */
/** Configure a bounded steering record in group zero without changing association state. */
INT wifi_steering_clientSet(UINT group, INT ap, mac_address_t mac, wifi_steering_clientConfig_t *config)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (group || !vap || vap->vap_mode != wifi_vap_mode_ap || !mac || !config)
        return WIFI_HAL_INVALID_ARGUMENTS;
    memcpy(wifi_test_state.steering_client[ap], mac, 6);
    wifi_test_state.client_config[ap] = *config;
    wifi_test_state.client_configured[ap] = TRUE;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Remove only matching steering configuration, preserving any live association. */
INT wifi_steering_clientRemove(UINT group, INT ap, mac_address_t mac)
{
    if (group || !ref_ap(ap) || !mac) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.client_configured[ap] || memcmp(mac, wifi_test_state.steering_client[ap], 6))
        return WIFI_HAL_INVALID_VALUE;
    wifi_test_state.client_configured[ap] = FALSE;
    memset(wifi_test_state.steering_client[ap], 0, sizeof(wifi_test_state.steering_client[ap]));
    memset(&wifi_test_state.client_config[ap], 0, sizeof(wifi_test_state.client_config[ap]));
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Publish an initialized RSSI event for a configured client. */
INT wifi_steering_clientMeasure(UINT group, INT ap, mac_address_t mac)
{
    wifi_steering_event_t event = {0};
    if (group || !ref_ap(ap) || !mac) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.client_configured[ap] || memcmp(mac, wifi_test_state.steering_client[ap], 6))
        return WIFI_HAL_INVALID_VALUE;
    event.type = WIFI_STEERING_EVENT_RSSI;
    event.apIndex = ap;
    event.timestamp_ms = wifi_test_state.clock * 1000;
    memcpy(event.data.rssi.client_mac, mac, 6);
    event.data.rssi.rssi = 45;
    if (wifi_test_state.steering_cb) wifi_test_state.steering_cb(group, &event);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Disconnect a configured client and publish the requested reason and type. */
INT wifi_steering_clientDisconnect(UINT group, INT ap, mac_address_t mac,
                                 wifi_disconnectType_t type, UINT reason)
{
    wifi_steering_event_t event = {0};
    int result;
    if (type != DISCONNECT_TYPE_DISASSOC && type != DISCONNECT_TYPE_DEAUTH)
        return WIFI_HAL_INVALID_VALUE;
    result = wifi_steering_clientRemove(group, ap, mac);
    if (result) return result;
    /* Unlike configuration removal, an explicit disconnect ends a matching association. */
    if (wifi_test_state.managed[ap] && !memcmp(mac, wifi_test_state.client[ap], 6))
        wifi_test_client_event(ap, FALSE);
    event.type = WIFI_STEERING_EVENT_CLIENT_DISCONNECT;
    event.apIndex = ap;
    event.timestamp_ms = wifi_test_state.clock * 1000;
    event.data.disconnect.reason = reason;
    event.data.disconnect.type = type;
    event.data.disconnect.source = DISCONNECT_SOURCE_LOCAL;
    memcpy(event.data.disconnect.client_mac, mac, 6);
    if (wifi_test_state.steering_cb) wifi_test_state.steering_cb(group, &event);
    return WIFI_HAL_SUCCESS;
}

#ifdef WIFI_HAL_VERSION_3_PHASE2
/* PUBLIC_INTERFACE */
/** Validate all steering group elements; group zero supports at most one per radio. */
INT wifi_steering_setGroup(UINT group, UINT count, wifi_steering_apConfig_t *config)
{
    UINT i;
    if (group || count > wifi_test_state.radios || (count && !config))
        return WIFI_HAL_INVALID_ARGUMENTS;
    for (i = 0; i < count; ++i)
        if (!ref_ap(config[i].apIndex)) return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_SUCCESS;
}
#else
/* PUBLIC_INTERFACE */
/** Validate baseline two-pointer steering group ABI; NULL/NULL removes the group. */
INT wifi_steering_setGroup(UINT group, wifi_steering_apConfig_t *a, wifi_steering_apConfig_t *b)
{
    if (group || (a && !ref_ap(a->apIndex)) || (b && !ref_ap(b->apIndex)))
        return WIFI_HAL_INVALID_ARGUMENTS;
    return WIFI_HAL_SUCCESS;
}
#endif

/* PUBLIC_INTERFACE */
/** Register/clear the feature-dependent BTM query and response callbacks. */
INT wifi_BTMQueryRequest_callback_register(UINT ap, wifi_BTMQueryRequest_callback query,
                                         wifi_BTMResponse_callback response)
{
    if (!ref_ap((INT)ap)) return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.query_cb[ap] = query;
    wifi_test_state.response_cb[ap] = response;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Register a beacon report callback for an existing AP. */
INT wifi_RMBeaconRequestCallbackRegister(UINT ap, wifi_RMBeaconReport_callback cb)
{
    if (!ref_ap((INT)ap) || !cb) return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.beacon_cb[ap] = cb;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Unregister only the currently registered callback. */
INT wifi_RMBeaconRequestCallbackUnregister(UINT ap, wifi_RMBeaconReport_callback cb)
{
    if (!ref_ap((INT)ap) || !cb || wifi_test_state.beacon_cb[ap] != cb)
        return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.beacon_cb[ap] = NULL;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Cancel a matching outstanding token. */
INT wifi_cancelRMBeaconRequest(UINT ap, UCHAR token)
{
    if (!ref_ap((INT)ap) || !token || wifi_test_state.token[ap] != token)
        return WIFI_HAL_INVALID_ARGUMENTS;
    wifi_test_state.token[ap] = 0;
    return WIFI_HAL_SUCCESS;
}
#ifdef WIFI_HAL_VERSION_3_PHASE2
/* PUBLIC_INTERFACE */
/** Deliver a deterministic BTM response through the phase-2 callback ABI. */
INT wifi_setBTMRequest(UINT ap, mac_address_t mac, wifi_BTMRequest_t *request)
{
    wifi_BTMResponse_t response = {0};
    if (!ref_ap((INT)ap) || !mac || !request) return WIFI_HAL_INVALID_ARGUMENTS;
    if (request->numCandidates > MAX_CANDIDATES || request->urlLen > MAX_URL_LEN)
        return WIFI_HAL_INVALID_VALUE;
    response.token = request->token;
    if (wifi_test_state.response_cb[ap]) wifi_test_state.response_cb[ap](ap, mac, &response);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Allocate a nonzero dialog token and deliver one borrowed beacon report. */
INT wifi_setRMBeaconRequest(UINT ap, mac_address_t mac, wifi_BeaconRequest_t *request, UCHAR *token)
{
    wifi_BeaconReport_t report = {0};
    UINT count = 1;
    if (!ref_ap((INT)ap) || !mac || !request || !token)
        return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.beacon_cb[ap]) return WIFI_HAL_NOT_READY;
    wifi_test_state.token[ap] = wifi_test_state.token[ap] == 255 ? 1 : wifi_test_state.token[ap] + 1;
    *token = wifi_test_state.token[ap];
    report.channel = request->channel;
    report.rcpi = 90;
    if (wifi_test_state.beacon_cb[ap]) wifi_test_state.beacon_cb[ap](ap, &report, &count, token);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return five initialized RRM capability bytes. */
INT wifi_getRMCapabilities(mac_address_t mac, UCHAR output[5])
{
    if (!mac || !output) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(output, 0, 5);
    output[0] = 0x70;
    return WIFI_HAL_SUCCESS;
}
#endif
