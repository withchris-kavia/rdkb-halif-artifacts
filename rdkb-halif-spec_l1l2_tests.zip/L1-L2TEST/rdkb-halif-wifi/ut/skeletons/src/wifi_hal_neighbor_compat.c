#include "wifi_hal_test_accessors.h"

static void neighbor(INT radio, wifi_neighbor_ap2_t *out)
{
    memset(out, 0, sizeof(*out));
    strcpy(out->ap_SSID, "reference-neighbor");
    strcpy(out->ap_BSSID, "02:00:00:00:00:01");
    strcpy(out->ap_Mode, "Infrastructure");
    out->ap_Channel = R.channel;
    out->ap_SignalStrength = -45;
    strcpy(out->ap_SecurityModeEnabled, "None");
    strcpy(out->ap_EncryptionMode, "None");
    strcpy(out->ap_OperatingFrequencyBand, R.band == WIFI_FREQUENCY_2_4_BAND ? "2.4GHz" :
                                         R.band == WIFI_FREQUENCY_6_BAND ? "6GHz" : "5GHz");
    strcpy(out->ap_OperatingChannelBandwidth, "20MHz");
    out->ap_BeaconPeriod = R.beaconInterval;
    out->ap_DTIMPeriod = R.dtimPeriod;
    out->ap_Noise = -95;
    out->ap_freq = R.band == WIFI_FREQUENCY_2_4_BAND ? 2407 + R.channel * 5 :
                   R.band == WIFI_FREQUENCY_6_BAND ? 5950 + R.channel * 5 : 5000 + R.channel * 5;
}
/* PUBLIC_INTERFACE */
/** Allocate one deterministic neighboring AP; caller frees it. Errors return NULL/zero. */
INT wifi_getNeighboringWiFiDiagnosticResult2(INT radio, wifi_neighbor_ap2_t **out, UINT *count)
{
    if (!out || !count) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = NULL;
    *count = 0;
    if (!wifi_test_radio_valid(radio)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!R.enable) return WIFI_HAL_NOT_READY;
    *out = wifi_test_allocate(1, sizeof(**out));
    if (!*out) return WIFI_HAL_ERROR;
    neighbor(radio, *out);
    *count = 1;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return synchronous reference scan status through the feature-selected signature. */
#ifdef WIFI_HAL_VERSION_3_PHASE2
INT wifi_getNeighboringWiFiStatus(INT radio, BOOL scan, wifi_neighbor_ap2_t **out, UINT *count)
{
    if (scan > TRUE) return WIFI_HAL_INVALID_ARGUMENTS;
#else
INT wifi_getNeighboringWiFiStatus(INT radio, wifi_neighbor_ap2_t **out, UINT *count)
{
#endif
    return wifi_getNeighboringWiFiDiagnosticResult2(radio, out, count);
}
/* PUBLIC_INTERFACE */
/** Allocate an old-layout snapshot for radio zero using explicit field conversion. */
INT wifi_getNeighboringWiFiDiagnosticResult(wifi_neighbor_ap_t **out, UINT *count)
{
    wifi_neighbor_ap2_t value;
    if (!out || !count) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = NULL;
    *count = 0;
    if (!wifi_test_radio_valid(0)) return WIFI_HAL_NOT_READY;
    if (!wifi_test_state.radio[0].enable) return WIFI_HAL_NOT_READY;
    *out = wifi_test_allocate(1, sizeof(**out));
    if (!*out) return WIFI_HAL_ERROR;
    neighbor(0, &value);
    strcpy((*out)->ap_SSID, value.ap_SSID);
    strcpy((*out)->ap_BSSID, value.ap_BSSID);
    strcpy((*out)->ap_Mode, value.ap_Mode);
    (*out)->ap_Channel = value.ap_Channel;
    (*out)->ap_SignalStrength = value.ap_SignalStrength;
    strcpy((*out)->ap_SecurityModeEnabled, value.ap_SecurityModeEnabled);
    strcpy((*out)->ap_EncryptionMode, value.ap_EncryptionMode);
    strcpy((*out)->ap_OperatingFrequencyBand, value.ap_OperatingFrequencyBand);
    strcpy((*out)->ap_OperatingChannelBandwidth, value.ap_OperatingChannelBandwidth);
    (*out)->ap_BeaconPeriod = value.ap_BeaconPeriod;
    (*out)->ap_DTIMPeriod = value.ap_DTIMPeriod;
    (*out)->ap_Noise = value.ap_Noise;
    *count = 1;
    return WIFI_HAL_SUCCESS;
}
