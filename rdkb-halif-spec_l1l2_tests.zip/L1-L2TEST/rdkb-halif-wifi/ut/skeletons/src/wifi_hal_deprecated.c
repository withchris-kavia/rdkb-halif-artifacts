#include <string.h>
#include "wifi_hal_test_backend.h"

/* PUBLIC_INTERFACE */
/** Return a legacy textual width into a caller buffer of at least 10 bytes. */
INT wifi_getRadioOperatingChannelBandwidth(INT radio, CHAR *output)
{
    wifi_channelBandwidth_t width;
    if (!wifi_test_radio_valid(radio) || !output) return WIFI_HAL_INVALID_ARGUMENTS;
    width = wifi_test_state.radio[radio].channelWidth;
    strcpy(output, width == WIFI_CHANNELBANDWIDTH_20MHZ ? "20MHz" :
                   width == WIFI_CHANNELBANDWIDTH_40MHZ ? "40MHz" : "80MHz");
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Parse an exact legacy width and validate through the public radio setter. */
INT wifi_setRadioOperatingChannelBandwidth(INT radio, CHAR *value)
{
    wifi_radio_operationParam_t op;
    if (!wifi_test_radio_valid(radio) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    op = wifi_test_state.radio[radio];
    if (!strcmp(value, "20MHz")) op.channelWidth = WIFI_CHANNELBANDWIDTH_20MHZ;
    else if (!strcmp(value, "40MHz")) op.channelWidth = WIFI_CHANNELBANDWIDTH_40MHZ;
    else if (!strcmp(value, "80MHz")) op.channelWidth = WIFI_CHANNELBANDWIDTH_80MHZ;
    else return WIFI_HAL_INVALID_VALUE;
    return wifi_setRadioOperatingParameters((UINT)radio, &op);
}
/* PUBLIC_INTERFACE */
/** Read AP or STA SSID into a caller buffer of at least 33 bytes. */
INT wifi_getSSIDName(INT ap, CHAR *output)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!vap || !output) return WIFI_HAL_INVALID_ARGUMENTS;
    strcpy(output, vap->vap_mode == wifi_vap_mode_ap ? vap->u.bss_info.ssid : vap->u.sta_info.ssid);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Bound SSIDs to the actual public AP/STA structure capacity. */
INT wifi_setSSIDName(INT ap, CHAR *value)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    size_t capacity;
    if (!vap || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    capacity = vap->vap_mode == wifi_vap_mode_ap ? sizeof(vap->u.bss_info.ssid) : sizeof(vap->u.sta_info.ssid);
    if (!value[0] || strlen(value) >= capacity) return WIFI_HAL_INVALID_VALUE;
    strcpy(vap->vap_mode == wifi_vap_mode_ap ? vap->u.bss_info.ssid : vap->u.sta_info.ssid, value);
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Report supported steering in the deterministic reference backend. */
BOOL wifi_steering_supported(void) { return TRUE; }
/* PUBLIC_INTERFACE */
/** Map supported model countries without overriding caller selection. */
INT wifi_getRadioCountryCode(INT radio, CHAR *output)
{
    wifi_countrycode_type_t code;
    if (!wifi_test_radio_valid(radio) || !output) return WIFI_HAL_INVALID_ARGUMENTS;
    code = wifi_test_state.radio[radio].countryCode;
    if (code == wifi_countrycode_US) strcpy(output, "US");
    else if (code == wifi_countrycode_GB) strcpy(output, "GB");
    else if (code == wifi_countrycode_CA) strcpy(output, "CA");
    else if (code == wifi_countrycode_DE) strcpy(output, "DE");
    else return WIFI_HAL_UNSUPPORTED;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Store a recognized two-letter country code. */
INT wifi_setRadioCountryCode(INT radio, CHAR *value)
{
    wifi_countrycode_type_t code;
    if (!wifi_test_radio_valid(radio) || !value) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!strcmp(value, "US")) code = wifi_countrycode_US;
    else if (!strcmp(value, "GB")) code = wifi_countrycode_GB;
    else if (!strcmp(value, "CA")) code = wifi_countrycode_CA;
    else if (!strcmp(value, "DE")) code = wifi_countrycode_DE;
    else return WIFI_HAL_INVALID_VALUE;
    wifi_test_state.radio[radio].countryCode = code;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Validate sample period/retention and reset interval-dependent counters on change. */
INT wifi_setRadioTrafficStatsMeasure(INT radio, wifi_radioTrafficStatsMeasure_t *measure)
{
    wifi_radio_operationParam_t op;
    if (!wifi_test_radio_valid(radio) || !measure) return WIFI_HAL_INVALID_ARGUMENTS;
    if (measure->radio_RadioStatisticsMeasuringRate <= 0 ||
        measure->radio_RadioStatisticsMeasuringInterval < measure->radio_RadioStatisticsMeasuringRate)
        return WIFI_HAL_INVALID_VALUE;
    op = wifi_test_state.radio[radio];
    op.radioStatsMeasuringRate = (UINT)measure->radio_RadioStatisticsMeasuringRate;
    op.radioStatsMeasuringInterval = (UINT)measure->radio_RadioStatisticsMeasuringInterval;
    return wifi_setRadioOperatingParameters((UINT)radio, &op);
}
/* PUBLIC_INTERFACE */
/** Compatibility enable uses the same statistics collection state. */
INT wifi_setRadioTrafficStatsRadioStatisticsEnable(INT radio, BOOL enabled)
{ return wifi_setRadioStatsEnable(radio, enabled); }
