#include <stdlib.h>
#include "wifi_hal_test_accessors.h"

#define DIAGNOSTICS(Name, Type, Extra) \
    /* PUBLIC_INTERFACE */ \
    /** Allocate a caller-owned typed client snapshot; empty and allocation failure return NULL/zero. */ \
    INT Name(INT ap, Type **out, UINT *count) { \
        wifi_vap_info_t *vap = wifi_test_vap(ap); \
        if (!ref_ap(ap) || !out || !count) return WIFI_HAL_INVALID_ARGUMENTS; \
        *out = NULL; *count = 0; \
        if (!wifi_test_state.managed[ap]) return WIFI_HAL_SUCCESS; \
        *out = wifi_test_allocate(1, sizeof(**out)); \
        if (!*out) return WIFI_HAL_ERROR; \
        memcpy((*out)->cli_MACAddress, wifi_test_state.client[ap], 6); \
        (*out)->cli_Active = TRUE; (*out)->cli_AuthenticationState = TRUE; \
        (*out)->cli_RSSI = -45; (*out)->cli_SignalStrength = -45; \
        (*out)->cli_BytesSent = wifi_test_state.bytes[vap->radio_index]; \
        Extra; *count = 1; return WIFI_HAL_SUCCESS; \
    }
#ifndef WIFI_HAL_VERSION_3_PHASE2
DIAGNOSTICS(wifi_getApAssociatedDeviceDiagnosticResult, wifi_associated_dev_t, (void)0)
#endif
DIAGNOSTICS(wifi_getApAssociatedDeviceDiagnosticResult2, wifi_associated_dev2_t,
            (*out)->cli_Associations = AX.associations)

/* PUBLIC_INTERFACE */
/** Allocate a caller-owned array containing the managed authenticated client's binary MAC. */
INT wifi_getApAuthenticatedDevices(INT ap, mac_t **out, UINT *count)
{
    if (!ref_ap(ap) || !out || !count) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = NULL;
    *count = 0;
    if (!wifi_test_state.managed[ap]) return WIFI_HAL_SUCCESS;
    *out = wifi_test_allocate(1, sizeof(**out));
    if (!*out) return WIFI_HAL_ERROR;
    memcpy((*out)->byte, wifi_test_state.client[ap], sizeof((*out)->byte));
    *count = 1;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Convert one associated client to the legacy device type without layout aliasing. */
INT wifi_getAllAssociatedDeviceDetail(INT ap, ULONG *count, wifi_device_t **out)
{
    if (!ref_ap(ap) || !out || !count) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = NULL;
    *count = 0;
    if (!wifi_test_state.managed[ap]) return WIFI_HAL_SUCCESS;
    *out = wifi_test_allocate(1, sizeof(**out));
    if (!*out) return WIFI_HAL_ERROR;
    memcpy((*out)->wifi_devMacAddress, wifi_test_state.client[ap], 6);
    (*out)->wifi_devAssociatedDeviceAuthentiationState = TRUE;
    (*out)->wifi_devSignalStrength = -45;
    *count = 1;
    return WIFI_HAL_SUCCESS;
}
static INT device_value(INT ap, CHAR *text, INT *out, INT value)
{
    mac_address_t mac;
    if (!ref_ap(ap) || !out || !ref_mac(text, mac)) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.managed[ap] || memcmp(mac, wifi_test_state.client[ap], 6))
        return WIFI_HAL_INVALID_VALUE;
    *out = value;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return modeled signal strength for a matching associated textual MAC. */
INT wifi_getApDeviceRSSI(INT ap, CHAR *mac, INT *out) { return device_value(ap, mac, out, -45); }
/* PUBLIC_INTERFACE */
/** No client traffic rate is fabricated by the reference model. */
INT wifi_getApDeviceRxrate(INT ap, CHAR *mac, INT *out) { return device_value(ap, mac, out, 0); }
/* PUBLIC_INTERFACE */
/** Return zero transmit rate for a matching idle client. */
INT wifi_getApDeviceTxrate(INT ap, CHAR *mac, INT *out) { return device_value(ap, mac, out, 0); }

static INT radio_client(INT radio, const UCHAR *mac)
{
    UINT i;
    if (!wifi_test_radio_valid(radio) || !mac) return -1;
    for (i = 0; i < wifi_test_state.map[radio].num_vaps; ++i) {
        wifi_vap_info_t *vap = &wifi_test_state.map[radio].vap_array[i];
        UINT ap = vap->vap_index;
        if (vap->vap_mode == wifi_vap_mode_ap && wifi_test_state.managed[ap] &&
            !memcmp(mac, wifi_test_state.client[ap], 6)) return (INT)ap;
    }
    return -1;
}
#define RATE_RESULT(Name, Type) \
    /* PUBLIC_INTERFACE */ \
    /** Return an empty per-rate histogram for the matching client: no rate samples are synthesized. */ \
    INT Name(INT radio, mac_address_t *mac, Type **out, UINT *count, ULLONG *handle) { \
        INT ap; \
        if (!wifi_test_radio_valid(radio) || !mac || !out || !count || !handle) \
            return WIFI_HAL_INVALID_ARGUMENTS; \
        *out = NULL; *count = 0; \
        ap = radio_client(radio, *mac); \
        if (ap < 0) return WIFI_HAL_INVALID_VALUE; \
        *handle = AX.associations; return WIFI_HAL_SUCCESS; \
    }
RATE_RESULT(wifi_getApAssociatedDeviceRxStatsResult, wifi_associated_dev_rate_info_rx_stats_t)
RATE_RESULT(wifi_getApAssociatedDeviceTxStatsResult, wifi_associated_dev_rate_info_tx_stats_t)
/* PUBLIC_INTERFACE */
/** Initialize all sixteen idle TID records and return the association-generation handle. */
INT wifi_getApAssociatedDeviceTidStatsResult(INT radio, mac_address_t *mac,
                                            wifi_associated_dev_tid_stats_t *out, ULLONG *handle)
{
    INT ap;
    UINT i;
    if (!wifi_test_radio_valid(radio) || !mac || !out || !handle) return WIFI_HAL_INVALID_ARGUMENTS;
    ap = radio_client(radio, *mac);
    if (ap < 0) return WIFI_HAL_INVALID_VALUE;
    memset(out, 0, sizeof(*out));
    for (i = 0; i < 16; ++i) out->tid_array[i].tid = (UCHAR)i;
    *handle = AX.associations;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return initialized zero-traffic statistics and reconnect handle for a client on this AP. */
INT wifi_getApAssociatedDeviceStats(INT ap, mac_address_t *mac,
                                    wifi_associated_dev_stats_t *out, ULLONG *handle)
{
    if (!ref_ap(ap) || !mac || !out || !handle) return WIFI_HAL_INVALID_ARGUMENTS;
    if (!wifi_test_state.managed[ap] || memcmp(*mac, wifi_test_state.client[ap], 6))
        return WIFI_HAL_INVALID_VALUE;
    memset(out, 0, sizeof(*out));
    *handle = AX.associations;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Legacy SSID retransmission counters are initially zero, not uninitialized. */
INT wifi_getSSIDTrafficStats(INT ap, wifi_ssidTrafficStats_t *out)
{
    if (!wifi_test_vap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(out, 0, sizeof(*out));
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return initialized legacy AP counters and modeled association count. */
INT wifi_getBasicTrafficStats(INT ap, wifi_basicTrafficStats_t *out)
{
    wifi_vap_info_t *vap = wifi_test_vap(ap);
    if (!ref_ap(ap) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(out, 0, sizeof(*out));
    out->wifi_BytesSent = wifi_test_state.bytes[vap->radio_index];
    out->wifi_Associations = (ULONG)AX.associations;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Return an initialized current-channel snapshot in the legacy structure. */
INT wifi_getRadioChannelStats2(INT radio, wifi_channelStats2_t *out)
{
    if (!wifi_test_radio_valid(radio) || !out) return WIFI_HAL_INVALID_ARGUMENTS;
    memset(out, 0, sizeof(*out));
    out->ch_Frequency = R.band == WIFI_FREQUENCY_2_4_BAND ? 2407 + R.channel * 5 :
                        R.band == WIFI_FREQUENCY_6_BAND ? 5950 + R.channel * 5 : 5000 + R.channel * 5;
    out->ch_NoiseFloor = -95;
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Initialize a bounded channel-metric array after validating all requested channels. */
INT wifi_getRadioDcsChannelMetrics(INT radio, wifi_channelMetrics_t *out, INT count)
{
    INT i;
    if (!wifi_test_radio_valid(radio) || !out || count <= 0 || count > MAX_CHANNELS)
        return WIFI_HAL_INVALID_ARGUMENTS;
    for (i = 0; i < count; ++i)
        if (out[i].channel_number < 1 || out[i].channel_number > 233) return WIFI_HAL_INVALID_VALUE;
    for (i = 0; i < count; ++i) {
        INT channel = out[i].channel_number;
        memset(&out[i], 0, sizeof(out[i]));
        out[i].channel_number = channel;
        out[i].channel_in_pool = TRUE;
        out[i].channel_noise = -95;
    }
    return WIFI_HAL_SUCCESS;
}
/* PUBLIC_INTERFACE */
/** Expose the model's global steering configuration capability. */
INT wifi_getBandSteeringCapability(BOOL *out)
{
    if (!out) return WIFI_HAL_INVALID_ARGUMENTS;
    *out = TRUE;
    return WIFI_HAL_SUCCESS;
}
