#!/usr/bin/env bash
# Copyright 2023 RDK Management
# Licensed under the Apache License, Version 2.0.
# See http://www.apache.org/licenses/LICENSE-2.0

set -u
SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || exit 1
BUILD_ROOT=$SCRIPT_DIR

if [[ ${1-} == -h || ${1-} == --help ]]; then
    printf 'Usage: %s [--dir BUILD_ROOT] [make arguments...]\n' "$0"
    exit 0
fi
if [[ ${1-} == --dir ]]; then
    if [[ $# -lt 2 || -z $2 || $2 == -* ]]; then
        printf '%s\n' '--dir requires a build root' >&2
        exit 2
    fi
    # Resolve relative paths once, before changing the working directory.
    BUILD_ROOT=$(realpath -m -- "$2") || exit 1
    shift 2
fi
if [[ -e $BUILD_ROOT && ! -d $BUILD_ROOT ]]; then
    printf '%s\n' 'Build root is not a directory' >&2
    exit 2
fi

UT_DIR=$BUILD_ROOT/ut
if [[ -e $UT_DIR && ! -d $UT_DIR ]]; then
    printf '%s\n' 'Unit-test path is not a directory' >&2
    exit 2
fi
if [[ ! -d $UT_DIR ]]; then
    TEST_REPO=$(git -C "$SCRIPT_DIR" remote get-url origin) || exit "$?"
    TEST_REPO=${TEST_REPO//halif/halif-test}
    TEST_REPO=${TEST_REPO//hal-/haltest-}
    mkdir -p -- "$BUILD_ROOT" || exit "$?"
    git clone -- "$TEST_REPO" "$UT_DIR" || exit "$?"
    git -C "$UT_DIR" checkout "${UT_PROJECT_VERSION:-main}" || exit "$?"
fi
cd -- "$UT_DIR" || exit 1
# exec preserves build failures without recursion or a trailing popd.
exec ./build.sh "$@"
