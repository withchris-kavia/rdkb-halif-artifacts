/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#ifndef LPA_TEST_CONTROL_H
#define LPA_TEST_CONTROL_H

#ifndef BUILD_LINUX
#error "LPA reference-model fixtures are Linux-host-only"
#endif

/*
 * Host fixture conventions, NOT additional requirements on vendor HALs:
 *
 * - Callers serialize access. Init and exit are idempotent. Init while ready
 *   preserves state; exit followed by init restores the two initial profiles.
 * - All operations except init/exit require initialization. EID/eUICC queries
 *   return readiness status only: the public ABI has no identifier output.
 * - ICCIDs are NUL-terminated strings of exactly 20 ASCII digits, with size 20.
 *   Enable/disable affect only the selected profile and are idempotent.
 *   Delete removes it regardless of enabled state; missing profiles fail.
 * - Enumeration returns one independent contiguous allocation, released with
 *   free(list), never individual entries. Snapshots survive mutation and exit.
 *   Empty inventory or any failure yields NULL/0 in supplied output slots.
 *   Callers must release an old snapshot before reusing its output slot.
 * - Only the exact download inputs below are accepted; no network is used.
 *   Each path adds its own disabled profile once. Duplicate downloads fail
 *   without altering state. Deleting that profile permits another download.
 * - Activation-code progress is synchronous, ordered, and borrowed only for
 *   the duration of each call. The callback may modify its temporary message.
 *   NULL callbacks are rejected; any non-RETURN_OK callback result aborts the
 *   download with FALSE and no changes. No callback or input pointer is kept.
 *   The profile is committed only after every callback succeeds.
 * - During callbacks, queries/enumeration are allowed; all mutations including
 *   init/exit and nested downloads fail. No callback can run after return.
 */

#define LPA_MODEL_ICCID_SIZE 20
#define LPA_MODEL_INITIAL_PROFILE_COUNT 2
#define LPA_MODEL_PROFILE_DISABLED 0
#define LPA_MODEL_PROFILE_ENABLED 1

#define LPA_MODEL_INITIAL_ICCID_1 "89000000000000000001"
#define LPA_MODEL_INITIAL_ICCID_2 "89000000000000000002"
#define LPA_MODEL_SMDS_ICCID      "89000000000000000003"
#define LPA_MODEL_SMDP_ICCID      "89000000000000000004"
#define LPA_MODEL_ACTIVATION_ICCID "89000000000000000005"
#define LPA_MODEL_ABSENT_ICCID    "89000000000000000099"

#define LPA_MODEL_SMDS "smds.example.invalid"
#define LPA_MODEL_SMDP "smdp.example.invalid"
#define LPA_MODEL_ACTIVATION_CODE "1$smdp.example.invalid$LPA-TEST"

#endif
