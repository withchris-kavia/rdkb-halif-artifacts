/*
* If not stated otherwise in this file or this component's LICENSE file the
* following copyright and licenses apply:*
* Copyright 2023 RDK Management
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include "lpa_hal.h"

#ifdef BUILD_LINUX
#include <stdlib.h>
#include <string.h>

#include "lpa_test_control.h"

/* The only possible downloads have fixed identities, so capacity is bounded. */
#define MODEL_PROFILE_CAPACITY (LPA_MODEL_INITIAL_PROFILE_COUNT + 3)

static const eSIMProfileStruct initial_profiles[] = {
    { LPA_MODEL_INITIAL_ICCID_1, LPA_MODEL_PROFILE_ENABLED, "Model primary" },
    { LPA_MODEL_INITIAL_ICCID_2, LPA_MODEL_PROFILE_DISABLED, "Model secondary" }
};
static const eSIMProfileStruct smds_profile = {
    LPA_MODEL_SMDS_ICCID, LPA_MODEL_PROFILE_DISABLED, "Model SMDS"
};
static const eSIMProfileStruct smdp_profile = {
    LPA_MODEL_SMDP_ICCID, LPA_MODEL_PROFILE_DISABLED, "Model SMDP"
};
static const eSIMProfileStruct activation_profile = {
    LPA_MODEL_ACTIVATION_ICCID, LPA_MODEL_PROFILE_DISABLED, "Model code"
};

static eSIMProfileStruct *profiles;
static int profile_count;
static int delivering_progress;

static int valid_iccid(const char *iccid, int iccid_size)
{
    int i;

    if (iccid == NULL || iccid_size != LPA_MODEL_ICCID_SIZE)
        return FALSE;
    for (i = 0; i < LPA_MODEL_ICCID_SIZE; ++i)
    {
        if (iccid[i] < '0' || iccid[i] > '9')
            return FALSE;
    }
    return iccid[LPA_MODEL_ICCID_SIZE] == '\0';
}

static int find_profile(const char *iccid)
{
    int i;

    for (i = 0; i < profile_count; ++i)
    {
        if (strcmp(profiles[i].iccid, iccid) == 0)
            return i;
    }
    return -1;
}

static int can_download(const eSIMProfileStruct *profile)
{
    return profiles != NULL && !delivering_progress &&
           profile_count < MODEL_PROFILE_CAPACITY &&
           find_profile(profile->iccid) < 0;
}

static int set_profile_state(char *iccid, int iccid_size, int state)
{
    int index;

    if (profiles == NULL || delivering_progress ||
        !valid_iccid(iccid, iccid_size))
        return RETURN_ERROR;
    index = find_profile(iccid);
    if (index < 0)
        return RETURN_ERROR;
    profiles[index].profileState = state;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/**
 * Download the controlled activation-code fixture, synchronously reporting
 * progress through download_progress. Return TRUE only after every callback
 * succeeds and the disabled profile is committed; otherwise return FALSE.
 * Callback text is mutable borrowed storage; no callback/input is retained.
 */
int cellular_esim_download_profile_with_activationcode(
    char *ActivationCodeStr,
    cellular_sim_download_progress_callback download_progress)
{
    static const char progress_messages[][80] = {
        "Activation Code decoded",
        "Initiate authentication done",
        "SM-DP+ address checking done",
        "Authenticate server done",
        "Authenticate client done",
        "PPR conditions check done",
        "Get Bound Profile Package done",
        "Send PIR notification to server done",
        "Clear PIR notification done",
        "Read pending notifications...",
        "<1> pending notification(s) detected",
        "Processing notification #1 <33>",
        "Notification <33> successfully sent",
        "Load Bound Profile Package done - Profile download successful",
        "download successful"
    };
    size_t i;

    if (ActivationCodeStr == NULL || download_progress == NULL ||
        strncmp(ActivationCodeStr, LPA_MODEL_ACTIVATION_CODE,
                sizeof(LPA_MODEL_ACTIVATION_CODE)) != 0 ||
        !can_download(&activation_profile))
        return FALSE;

    /* Reject reentrant mutations so rejection never needs a partial rollback. */
    delivering_progress = TRUE;
    for (i = 0; i < sizeof(progress_messages) / sizeof(progress_messages[0]); ++i)
    {
        char message[sizeof(progress_messages[0])];

        memcpy(message, progress_messages[i], sizeof(message));
        if (download_progress(message) != RETURN_OK)
        {
            delivering_progress = FALSE;
            return FALSE;
        }
    }
    delivering_progress = FALSE;
    profiles[profile_count++] = activation_profile;
    return TRUE;
}

/* PUBLIC_INTERFACE */
/**
 * Add the disabled SMDS fixture for the exact synthetic smds input.
 * Return RETURN_ERROR before init, for invalid inputs or duplicate downloads;
 * otherwise return RETURN_OK. No network or provisioning occurs.
 */
int cellular_esim_download_profile_from_smds(char *smds)
{
    if (smds == NULL ||
        strncmp(smds, LPA_MODEL_SMDS, sizeof(LPA_MODEL_SMDS)) != 0 ||
        !can_download(&smds_profile))
        return RETURN_ERROR;
    profiles[profile_count++] = smds_profile;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/**
 * Add the disabled default-SMDP fixture for the exact synthetic smdp input.
 * Return RETURN_OK on insertion, RETURN_ERROR on rejection; never use network.
 */
int cellular_esim_download_profile_from_defaultsmdp(char *smdp)
{
    if (smdp == NULL ||
        strncmp(smdp, LPA_MODEL_SMDP, sizeof(LPA_MODEL_SMDP)) != 0 ||
        !can_download(&smdp_profile))
        return RETURN_ERROR;
    profiles[profile_count++] = smdp_profile;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/**
 * Store a separately allocated contiguous profile snapshot in *profile_list
 * and its count in *nb_profiles. Caller releases it with free(*profile_list).
 * Return RETURN_OK on success; on error, clear each supplied output to NULL/0.
 * The model never owns snapshots, including after exit or profile deletion.
 */
int cellular_esim_get_profile_info(eSIMProfileStruct **profile_list,
                                   int *nb_profiles)
{
    eSIMProfileStruct *snapshot;

    if (profile_list != NULL)
        *profile_list = NULL;
    if (nb_profiles != NULL)
        *nb_profiles = 0;
    if (profile_list == NULL || nb_profiles == NULL ||
        profiles == NULL || profile_count == 0)
        return RETURN_ERROR;

    snapshot = calloc((size_t)profile_count, sizeof(*snapshot));
    if (snapshot == NULL)
        return RETURN_ERROR;
    memcpy(snapshot, profiles, (size_t)profile_count * sizeof(*snapshot));
    *profile_list = snapshot;
    *nb_profiles = profile_count;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/**
 * Enable only the profile matching the exact 20-digit terminated iccid.
 * iccid_size must be 20. Return RETURN_OK if found, RETURN_ERROR otherwise.
 */
int cellular_esim_enable_profile(char *iccid, int iccid_size)
{
    return set_profile_state(iccid, iccid_size, LPA_MODEL_PROFILE_ENABLED);
}

/* PUBLIC_INTERFACE */
/**
 * Disable only the profile matching the exact 20-digit terminated iccid.
 * iccid_size must be 20. Return RETURN_OK if found, RETURN_ERROR otherwise.
 */
int cellular_esim_disable_profile(char *iccid, int iccid_size)
{
    return set_profile_state(iccid, iccid_size, LPA_MODEL_PROFILE_DISABLED);
}

/* PUBLIC_INTERFACE */
/**
 * Remove the exact 20-digit terminated iccid, with iccid_size equal to 20.
 * Return RETURN_OK on removal, RETURN_ERROR without mutation on rejection.
 */
int cellular_esim_delete_profile(char *iccid, int iccid_size)
{
    int index;

    if (profiles == NULL || delivering_progress ||
        !valid_iccid(iccid, iccid_size))
        return RETURN_ERROR;
    index = find_profile(iccid);
    if (index < 0)
        return RETURN_ERROR;
    memmove(&profiles[index], &profiles[index + 1],
            (size_t)(profile_count - index - 1) * sizeof(*profiles));
    --profile_count;
    memset(&profiles[profile_count], 0, sizeof(*profiles));
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/**
 * Initialize the model with two synthetic profiles, or preserve ready state.
 * Return RETURN_OK on success, RETURN_ERROR on allocation failure or during
 * a progress callback. A failed initialization can be retried safely.
 */
int cellular_esim_lpa_init(void)
{
    if (delivering_progress)
        return RETURN_ERROR;
    if (profiles != NULL)
        return RETURN_OK;
    profiles = calloc(MODEL_PROFILE_CAPACITY, sizeof(*profiles));
    if (profiles == NULL)
        return RETURN_ERROR;
    memcpy(profiles, initial_profiles, sizeof(initial_profiles));
    profile_count = LPA_MODEL_INITIAL_PROFILE_COUNT;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/**
 * Release model-owned state, leaving caller-owned snapshots intact.
 * Return RETURN_OK even if already stopped; RETURN_ERROR during a callback.
 * No asynchronous work or retained callbacks exist after a successful exit.
 */
int cellular_esim_lpa_exit(void)
{
    if (delivering_progress)
        return RETURN_ERROR;
    free(profiles);
    profiles = NULL;
    profile_count = 0;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/**
 * Return RETURN_OK if the initialized model can query its synthetic eSIM,
 * RETURN_ERROR otherwise. The HAL ABI provides no textual EID output slot.
 */
int cellular_esim_get_eid(void)
{
    return profiles != NULL ? RETURN_OK : RETURN_ERROR;
}

/* PUBLIC_INTERFACE */
/**
 * Return RETURN_OK if the initialized model can query its synthetic eUICC,
 * RETURN_ERROR otherwise. This status-only query does not mutate profiles.
 */
int cellular_esim_get_euicc(void)
{
    return profiles != NULL ? RETURN_OK : RETURN_ERROR;
}
#endif /* BUILD_LINUX */
