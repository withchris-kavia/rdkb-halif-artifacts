/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#ifndef LPA_TEST_HARNESS_H
#define LPA_TEST_HARNESS_H

#include <ut.h>

/* PUBLIC_INTERFACE */
/**
 * Register tests in an explicit UT group, including legacy ungrouped suites.
 * register_tests must return zero on success; return nonzero on any error.
 */
int lpa_harness_register_group(UT_groupID_t group, int (*register_tests)(void));

#endif
