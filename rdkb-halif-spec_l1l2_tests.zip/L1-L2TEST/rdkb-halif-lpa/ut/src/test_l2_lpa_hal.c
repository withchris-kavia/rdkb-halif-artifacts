/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <stdlib.h>
#include <string.h>
#include "lpa_test_helpers.h"

/*
 * Section 4 scenarios use the documented Linux fixture conventions from
 * lpa_test_control.h. They are not vendor state-machine or timing requirements.
 */
#ifdef BUILD_LINUX
static void expect_profile(const char *identity, int state, int count)
{
    test_lpa_snapshot_t current = {0};
    if (test_lpa_snapshot(&current))
    {
        const eSIMProfileStruct *profile = test_lpa_find(&current, identity);
        CU_ASSERT_EQUAL(current.count, count);
        if (state < 0)
        {
            CU_ASSERT_PTR_NULL(profile);
        }
        else
        {
            CU_ASSERT_PTR_NOT_NULL(profile);
            if (profile != NULL)
                CU_ASSERT_EQUAL(profile->profileState, state);
        }
    }
    test_lpa_snapshot_release(&current);
}

static void expect_unchanged(const test_lpa_snapshot_t *before)
{
    test_lpa_snapshot_t after = {0};
    if (test_lpa_snapshot(&after))
        CU_ASSERT(test_lpa_same(before, &after));
    test_lpa_snapshot_release(&after);
}

static void expect_preserved(const test_lpa_snapshot_t *before, int count)
{
    test_lpa_snapshot_t after = {0};
    if (test_lpa_snapshot(&after))
    {
        CU_ASSERT_EQUAL(after.count, count);
        for (int i = 0; i < before->count; ++i)
        {
            const eSIMProfileStruct *original = &before->list[i];
            const eSIMProfileStruct *current =
                test_lpa_find(&after, original->iccid);
            CU_ASSERT_PTR_NOT_NULL(current);
            if (current != NULL)
            {
                CU_ASSERT_EQUAL(current->profileState, original->profileState);
                CU_ASSERT_EQUAL(strncmp(current->profileName,
                                        original->profileName,
                                        sizeof(current->profileName)), 0);
            }
        }
    }
    test_lpa_snapshot_release(&after);
}

/* (1) Initialize -> download -> enumerate -> enable -> disable -> delete. */
static void test_profile_lifecycle(void)
{
    char *server = test_lpa_config.smds, *identity = test_lpa_config.downloads[0];
    if (!test_lpa_begin())
        return;
    expect_profile(identity, -1, 2);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(server), RETURN_OK);
    expect_profile(identity, LPA_MODEL_PROFILE_DISABLED, 3);
    CU_ASSERT_EQUAL(cellular_esim_enable_profile(identity, 20), RETURN_OK);
    expect_profile(identity, LPA_MODEL_PROFILE_ENABLED, 3);
    CU_ASSERT_EQUAL(cellular_esim_disable_profile(identity, 20), RETURN_OK);
    expect_profile(identity, LPA_MODEL_PROFILE_DISABLED, 3);
    CU_ASSERT_EQUAL(cellular_esim_delete_profile(identity, 20), RETURN_OK);
    expect_profile(identity, -1, 2);
    CU_ASSERT_EQUAL(cellular_esim_delete_profile(identity, 20), RETURN_ERROR);
    test_lpa_end();
}

/* (2) Distinct identities, return conventions, duplicates and re-download. */
static void test_all_download_entrypoints(void)
{
    test_lpa_snapshot_t completed = {0};
    char *smds = test_lpa_config.smds, *smdp = test_lpa_config.smdp;
    char *code = test_lpa_config.activation_code;
    char *identity = test_lpa_config.downloads[1];
    if (!test_lpa_begin())
        return;
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(smds), RETURN_OK);
    expect_profile(LPA_MODEL_SMDS_ICCID, LPA_MODEL_PROFILE_DISABLED, 3);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_defaultsmdp(smdp),
                    RETURN_OK);
    expect_profile(LPA_MODEL_SMDP_ICCID, LPA_MODEL_PROFILE_DISABLED, 4);
    test_lpa_progress_reset(0);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(
                        code, test_lpa_progress), TRUE);
    expect_profile(LPA_MODEL_ACTIVATION_ICCID, LPA_MODEL_PROFILE_DISABLED, 5);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.count, 15);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.invalid, 0);
    if (!test_lpa_snapshot(&completed))
        goto done;
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(smds), RETURN_ERROR);
    expect_unchanged(&completed);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_defaultsmdp(smdp),
                    RETURN_ERROR);
    expect_unchanged(&completed);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(
                        code, test_lpa_progress), FALSE);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.count, 15);
    expect_unchanged(&completed);
    CU_ASSERT_STRING_EQUAL(smds, LPA_MODEL_SMDS);
    CU_ASSERT_STRING_EQUAL(smdp, LPA_MODEL_SMDP);
    CU_ASSERT_STRING_EQUAL(code, LPA_MODEL_ACTIVATION_CODE);
    CU_ASSERT_EQUAL(cellular_esim_delete_profile(identity, 20), RETURN_OK);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_defaultsmdp(smdp),
                    RETURN_OK);
    expect_unchanged(&completed);
done:
    test_lpa_snapshot_release(&completed);
    test_lpa_end();
}

/* (3) Every target mutation preserves all fields of unrelated profiles. */
static void test_unrelated_profile_preservation(void)
{
    test_lpa_snapshot_t originals = {0};
    char *server = test_lpa_config.smds, *identity = test_lpa_config.downloads[0];
    if (!test_lpa_begin())
        return;
    if (!test_lpa_snapshot(&originals))
        goto done;
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(server), RETURN_OK);
    expect_preserved(&originals, 3);
    CU_ASSERT_EQUAL(cellular_esim_enable_profile(identity, 20), RETURN_OK);
    expect_preserved(&originals, 3);
    CU_ASSERT_EQUAL(cellular_esim_enable_profile(identity, 20), RETURN_OK);
    expect_preserved(&originals, 3);
    CU_ASSERT_EQUAL(cellular_esim_disable_profile(identity, 20), RETURN_OK);
    expect_preserved(&originals, 3);
    CU_ASSERT_EQUAL(cellular_esim_disable_profile(identity, 20), RETURN_OK);
    expect_preserved(&originals, 3);
    CU_ASSERT_EQUAL(cellular_esim_delete_profile(identity, 20), RETURN_OK);
    expect_unchanged(&originals);
done:
    test_lpa_snapshot_release(&originals);
    test_lpa_end();
}

/* (4) Rejections must not partially change any inventory field. */
static void test_rejected_operation_invariants(void)
{
    typedef int (*action_t)(char *, int);
    static const action_t actions[] = {
        cellular_esim_enable_profile, cellular_esim_disable_profile,
        cellular_esim_delete_profile
    };
    test_lpa_snapshot_t before = {0};
    char *absent = test_lpa_config.absent, *existing = test_lpa_config.existing[0];
    char malformed[] = "8900000000000000000x", short_id[] = "123", empty[] = "";
    char server[] = "uncontrolled.example.invalid";
    char *code = test_lpa_config.activation_code;
    if (!test_lpa_begin())
        return;
    if (!test_lpa_snapshot(&before))
        goto done;
    CU_ASSERT_PTR_NULL(test_lpa_find(&before, absent));
    for (size_t i = 0; i < sizeof(actions) / sizeof(actions[0]); ++i)
    {
        char *invalid[] = {NULL, absent, malformed, short_id, empty};
        for (size_t j = 0; j < sizeof(invalid) / sizeof(invalid[0]); ++j)
        {
            CU_ASSERT_EQUAL(actions[i](invalid[j], 20), RETURN_ERROR);
            expect_unchanged(&before);
        }
        CU_ASSERT_EQUAL(actions[i](existing, 19), RETURN_ERROR);
        expect_unchanged(&before);
        CU_ASSERT_EQUAL(actions[i](existing, 21), RETURN_ERROR);
        expect_unchanged(&before);
    }
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(server), RETURN_ERROR);
    expect_unchanged(&before);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_defaultsmdp(server),
                    RETURN_ERROR);
    expect_unchanged(&before);
    test_lpa_progress_reset(0);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(
                        server, test_lpa_progress), FALSE);
    expect_unchanged(&before);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(code, NULL),
                    FALSE);
    expect_unchanged(&before);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.count, 0);
done:
    test_lpa_snapshot_release(&before);
    test_lpa_end();
}

/* (5) Distinct snapshots remain caller-owned across edits, deletion and exit. */
static void test_enumeration_ownership(void)
{
    test_lpa_snapshot_t first = {0}, second = {0}, fresh = {0};
    eSIMProfileStruct saved;
    char *identity = test_lpa_config.existing[0];
    if (!test_lpa_begin())
        return;
    if (!test_lpa_snapshot(&first) || !test_lpa_snapshot(&second))
        goto done;
    CU_ASSERT(first.list != second.list);
    if (first.list == second.list)
    {
        /* Preserve the assertion failure, but release this allocation once. */
        second.list = NULL;
        second.count = 0;
        goto done;
    }
    CU_ASSERT(test_lpa_same(&first, &second));
    if (first.count <= 0 || second.count <= 0)
        goto done;
    saved = second.list[0];
    first.list[0].profileState = !first.list[0].profileState;
    first.list[0].profileName[0] = 'X';
    CU_ASSERT_EQUAL(second.list[0].profileState, saved.profileState);
    CU_ASSERT_STRING_EQUAL(second.list[0].profileName, saved.profileName);
    if (!test_lpa_snapshot(&fresh))
        goto done;
    CU_ASSERT(fresh.list != first.list && fresh.list != second.list);
    if (fresh.list == first.list || fresh.list == second.list)
    {
        fresh.list = NULL;
        fresh.count = 0;
        goto done;
    }
    CU_ASSERT(test_lpa_same(&second, &fresh));
    CU_ASSERT(!test_lpa_same(&first, &fresh));
    CU_ASSERT_EQUAL(cellular_esim_delete_profile(identity, 20), RETURN_OK);
    CU_ASSERT_EQUAL(cellular_esim_lpa_exit(), RETURN_OK);
    /* These are still valid allocations, not pointers into freed model memory. */
    CU_ASSERT(test_lpa_same(&second, &fresh));
    CU_ASSERT_EQUAL(second.list[0].profileState, saved.profileState);
    CU_ASSERT_STRING_EQUAL(second.list[0].iccid, saved.iccid);
    test_lpa_snapshot_release(&second);
    CU_ASSERT_PTR_NULL(second.list);
    CU_ASSERT_EQUAL(second.count, 0);
    CU_ASSERT_EQUAL(fresh.list[0].profileState, saved.profileState);
    test_lpa_snapshot_release(&first);
    CU_ASSERT_EQUAL(cellular_esim_lpa_init(), RETURN_OK);
    expect_unchanged(&fresh);
done:
    test_lpa_snapshot_release(&fresh);
    test_lpa_snapshot_release(&second);
    test_lpa_snapshot_release(&first);
    test_lpa_end();
}

/* (6) The ABI exposes query status, not an invented EID/eUICC output buffer. */
static void test_eid_euicc_query_invariants(void)
{
    test_lpa_snapshot_t before = {0};
    if (!test_lpa_begin())
        return;
    if (!test_lpa_snapshot(&before))
        goto done;
    for (int i = 0; i < 3; ++i)
    {
        CU_ASSERT_EQUAL(cellular_esim_get_eid(), RETURN_OK);
        expect_unchanged(&before);
        CU_ASSERT_EQUAL(cellular_esim_get_euicc(), RETURN_OK);
        expect_unchanged(&before);
    }
    CU_ASSERT_EQUAL(cellular_esim_lpa_exit(), RETURN_OK);
    CU_ASSERT_EQUAL(cellular_esim_get_eid(), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_get_euicc(), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_lpa_init(), RETURN_OK);
    expect_unchanged(&before);
done:
    test_lpa_snapshot_release(&before);
    test_lpa_end();
}

/* (7) Idempotence, stopped-state failures, empty enumeration, clean reinit. */
static void test_exit_reinitialize_resources(void)
{
    test_lpa_snapshot_t original = {0}, changed = {0};
    eSIMProfileStruct *empty = NULL;
    int count = 123;
    char *smds = test_lpa_config.smds, *smdp = test_lpa_config.smdp;
    char *code = test_lpa_config.activation_code;
    char *first = test_lpa_config.existing[0], *second = test_lpa_config.existing[1];
    if (!test_lpa_begin())
        return;
    if (!test_lpa_snapshot(&original))
        goto done;
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(smds), RETURN_OK);
    if (!test_lpa_snapshot(&changed))
        goto done;
    CU_ASSERT_EQUAL(cellular_esim_lpa_init(), RETURN_OK);
    expect_unchanged(&changed);
    CU_ASSERT_EQUAL(cellular_esim_lpa_exit(), RETURN_OK);
    CU_ASSERT_EQUAL(cellular_esim_lpa_exit(), RETURN_OK);
    CU_ASSERT_EQUAL(cellular_esim_get_profile_info(&empty, &count), RETURN_ERROR);
    CU_ASSERT_PTR_NULL(empty);
    CU_ASSERT_EQUAL(count, 0);
    free(empty);
    empty = NULL;
    CU_ASSERT_EQUAL(cellular_esim_get_eid(), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_get_euicc(), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_enable_profile(first, 20), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_disable_profile(first, 20), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_delete_profile(first, 20), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(smds), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_defaultsmdp(smdp),
                    RETURN_ERROR);
    test_lpa_progress_reset(0);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(
                        code, test_lpa_progress), FALSE);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.count, 0);
    for (int i = 0; i < 3; ++i)
    {
        CU_ASSERT_EQUAL(cellular_esim_lpa_init(), RETURN_OK);
        expect_unchanged(&original);
        CU_ASSERT_EQUAL(cellular_esim_delete_profile(first, 20), RETURN_OK);
        CU_ASSERT_EQUAL(cellular_esim_delete_profile(second, 20), RETURN_OK);
        count = 123;
        CU_ASSERT_EQUAL(cellular_esim_get_profile_info(&empty, &count),
                        RETURN_ERROR);
        CU_ASSERT_PTR_NULL(empty);
        CU_ASSERT_EQUAL(count, 0);
        free(empty);
        empty = NULL;
        CU_ASSERT_EQUAL(cellular_esim_lpa_exit(), RETURN_OK);
    }
    CU_ASSERT_EQUAL(cellular_esim_lpa_init(), RETURN_OK);
    expect_unchanged(&original);
done:
    free(empty);
    test_lpa_snapshot_release(&changed);
    test_lpa_snapshot_release(&original);
    test_lpa_end();
}

static int reentry_observed;

/* Callback assertions never longjmp, so even a regression releases snapshots. */
static int inspecting_progress(char *message)
{
    int result = test_lpa_progress(message);
    if (test_lpa_progress_capture.count == 1)
    {
        test_lpa_snapshot_t current = {0};
        char *first = test_lpa_config.existing[0], *smds = test_lpa_config.smds;
        char *smdp = test_lpa_config.smdp, *code = test_lpa_config.activation_code;
        ++reentry_observed;
        CU_ASSERT_EQUAL(cellular_esim_get_eid(), RETURN_OK);
        CU_ASSERT_EQUAL(cellular_esim_get_euicc(), RETURN_OK);
        if (test_lpa_snapshot(&current))
        {
            CU_ASSERT_EQUAL(current.count, 2);
            CU_ASSERT_PTR_NULL(test_lpa_find(&current, LPA_MODEL_ACTIVATION_ICCID));
        }
        test_lpa_snapshot_release(&current);
        CU_ASSERT_EQUAL(cellular_esim_lpa_init(), RETURN_ERROR);
        CU_ASSERT_EQUAL(cellular_esim_lpa_exit(), RETURN_ERROR);
        CU_ASSERT_EQUAL(cellular_esim_enable_profile(first, 20), RETURN_ERROR);
        CU_ASSERT_EQUAL(cellular_esim_disable_profile(first, 20), RETURN_ERROR);
        CU_ASSERT_EQUAL(cellular_esim_delete_profile(first, 20), RETURN_ERROR);
        CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(smds),
                        RETURN_ERROR);
        CU_ASSERT_EQUAL(cellular_esim_download_profile_from_defaultsmdp(smdp),
                        RETURN_ERROR);
        CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(
                            code, test_lpa_progress), FALSE);
    }
    /* The model permits edits to its temporary text; the capture must be a copy. */
    if (message != NULL && message[0] != '\0')
        message[0] = 'X';
    return result;
}

/* (8) Ordered copied progress, aborted downloads, reentry and post-exit safety. */
static void test_callback_capture_cleanup(void)
{
    static const char *const expected[] = {
        "Activation Code decoded", "Initiate authentication done",
        "SM-DP+ address checking done", "Authenticate server done",
        "Authenticate client done", "PPR conditions check done",
        "Get Bound Profile Package done", "Send PIR notification to server done",
        "Clear PIR notification done", "Read pending notifications...",
        "<1> pending notification(s) detected", "Processing notification #1 <33>",
        "Notification <33> successfully sent",
        "Load Bound Profile Package done - Profile download successful",
        "download successful"
    };
    static const size_t abort_at[] = {1, 8, 15};
    test_lpa_snapshot_t before = {0};
    test_lpa_progress_t saved;
    char code[sizeof(test_lpa_config.activation_code)];
    /* This test later erases its input; never erase the shared fixture. */
    memcpy(code, test_lpa_config.activation_code, sizeof(code));
    if (!test_lpa_begin())
        return;
    if (!test_lpa_snapshot(&before))
        goto done;
    for (size_t i = 0; i < sizeof(abort_at) / sizeof(abort_at[0]); ++i)
    {
        test_lpa_progress_reset(abort_at[i]);
        CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(
                            code, test_lpa_progress), FALSE);
        CU_ASSERT_EQUAL(test_lpa_progress_capture.count, abort_at[i]);
        CU_ASSERT_EQUAL(test_lpa_progress_capture.invalid, 0);
        expect_unchanged(&before);
    }
    test_lpa_progress_reset(0);
    reentry_observed = 0;
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(
                        code, inspecting_progress), TRUE);
    CU_ASSERT_EQUAL(reentry_observed, 1);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.invalid, 0);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.count,
                    sizeof(expected) / sizeof(expected[0]));
    for (size_t i = 0; i < sizeof(expected) / sizeof(expected[0]); ++i)
        CU_ASSERT_STRING_EQUAL(test_lpa_progress_capture.messages[i], expected[i]);
    expect_profile(LPA_MODEL_ACTIVATION_ICCID, LPA_MODEL_PROFILE_DISABLED, 3);
    saved = test_lpa_progress_capture;
    memset(code, 0, sizeof(code));
    CU_ASSERT_EQUAL(cellular_esim_lpa_exit(), RETURN_OK);
    CU_ASSERT_EQUAL(cellular_esim_get_eid(), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_lpa_init(), RETURN_OK);
    expect_unchanged(&before);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.count, saved.count);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.invalid, saved.invalid);
    CU_ASSERT_EQUAL(memcmp(test_lpa_progress_capture.messages, saved.messages,
                            sizeof(saved.messages)), 0);
done:
    test_lpa_snapshot_release(&before);
    test_lpa_end();
}
#endif

/* PUBLIC_INTERFACE */
/** Register the eight host scenarios in L2 only; vendor builds add no placeholders. */
int test_lpa_hal_l2_register(void)
{
#ifdef BUILD_LINUX
    static const struct
    {
        const char *name;
        void (*function)(void);
    } cases[] = {
        {"profile lifecycle", test_profile_lifecycle},
        {"all download entrypoints", test_all_download_entrypoints},
        {"unrelated profile preservation", test_unrelated_profile_preservation},
        {"rejected operation invariants", test_rejected_operation_invariants},
        {"enumeration ownership and caller release", test_enumeration_ownership},
        {"EID eUICC query invariants", test_eid_euicc_query_invariants},
        {"exit reinitialize resource behavior", test_exit_reinitialize_resources},
        {"callback capture and cleanup safety", test_callback_capture_cleanup}
    };
    UT_test_suite_t *suite;
    if (!test_lpa_fixtures_valid())
        return -1;
    suite = UT_add_suite_withGroupID("[L2 LPA Linux model]", NULL,
                                     test_lpa_suite_cleanup, UT_TESTS_L2);
    if (suite == NULL)
        return -1;
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i)
        if (UT_add_test(suite, cases[i].name, cases[i].function) == NULL)
            return -1;
#endif
    return 0;
}
