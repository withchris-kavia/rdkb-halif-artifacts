/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <errno.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lpa_test_harness.h"
#include "lpa_test_helpers.h"

#ifndef LPA_DEFAULT_CONFIG
#define LPA_DEFAULT_CONFIG "../config/lpa_config"
#endif

extern int register_hal_l1_tests(void);
extern int register_hal_l2_tests(void);
extern void __real_CU_cleanup_registry(void);

typedef struct
{
    CU_pSuite suite;
    UT_groupID_t group;
} suite_entry_t;

typedef struct
{
    int group;
    bool enabled;
} group_filter_t;

typedef struct
{
    const char *config;
    bool help;
    int argc;
    char *argv[256];
} options_t;

/* Fixed storage avoids upstream group allocations leaking on early failures. */
static suite_entry_t suites[100];
static group_filter_t filters[50];
static unsigned int suite_count, filter_count;
static UT_groupID_t registering_group = UT_TESTS_UNKNOWN;
static bool registration_failed, configuration_failed, running, captured;
static unsigned int tests_run, assertions_failed, tests_failed, suites_failed;
static CU_ErrorCode run_error;

/* PUBLIC_INTERFACE */
/** Capture all CUnit result counters and errors before upstream clears them. */
void __wrap_CU_cleanup_registry(void)
{
    if (running && !captured)
    {
        tests_run = CU_get_number_of_tests_run();
        assertions_failed = CU_get_number_of_failures();
        tests_failed = CU_get_number_of_tests_failed();
        suites_failed = CU_get_number_of_suites_failed();
        run_error = CU_get_error();
        captured = true;
        fprintf(stderr, "LPA_RESULT tests=%u failed=%u assertions_failed=%u "
                "suites_failed=%u error=%d\n", tests_run, tests_failed,
                assertions_failed, suites_failed, (int)run_error);
    }
    __real_CU_cleanup_registry();
}

/* PUBLIC_INTERFACE */
/** Retain official ordered -d/-e switches without framework-private allocations. */
void __wrap_UT_Manage_Suite_Activation(int group, bool enabled)
{
    if (group < UT_TESTS_L1 || group >= UT_TESTS_MAX ||
        filter_count >= sizeof(filters) / sizeof(filters[0]))
    {
        configuration_failed = true;
        return;
    }
    filters[filter_count++] = (group_filter_t){group, enabled};
}

/* PUBLIC_INTERFACE */
/** Register a suite and group with sticky errors, including allocation errors. */
UT_test_suite_t *__wrap_UT_add_suite_withGroupID(
    const char *name, UT_InitialiseFunction_t init,
    UT_CleanupFunction_t cleanup, UT_groupID_t group)
{
    CU_pSuite suite;
    if (group < UT_TESTS_L1 || group >= UT_TESTS_MAX ||
        (registering_group != UT_TESTS_UNKNOWN && group != registering_group) ||
        suite_count >= sizeof(suites) / sizeof(suites[0]))
    {
        registration_failed = true;
        return NULL;
    }
    suite = CU_add_suite(name, init, cleanup);
    if (suite == NULL || CU_get_error() != CUE_SUCCESS)
    {
        registration_failed = true;
        return NULL;
    }
    suites[suite_count++] = (suite_entry_t){suite, group};
    return (UT_test_suite_t *)suite;
}

/* PUBLIC_INTERFACE */
/** Assign a legacy ungrouped suite to its explicit component registration group. */
UT_test_suite_t *__wrap_UT_add_suite(
    const char *name, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup)
{
    return __wrap_UT_add_suite_withGroupID(name, init, cleanup, registering_group);
}

/* PUBLIC_INTERFACE */
/** Add a test without upstream's aborting assert and retain every failure. */
UT_test_t *__wrap_UT_add_test(UT_test_suite_t *suite, const char *name,
                            UT_TestFunction_t function)
{
    CU_pTest test = CU_add_test((CU_pSuite)suite, name, function);
    if (test == NULL || CU_get_error() != CUE_SUCCESS)
        registration_failed = true;
    return (UT_test_t *)test;
}

/* PUBLIC_INTERFACE */
/** Call one level's registrar in its explicit group; retain all error statuses. */
int lpa_harness_register_group(UT_groupID_t group, int (*register_tests)(void))
{
    int status;
    if (register_tests == NULL || group < UT_TESTS_L1 || group >= UT_TESTS_MAX ||
        registering_group != UT_TESTS_UNKNOWN)
    {
        registration_failed = true;
        return -1;
    }
    registering_group = group;
    status = register_tests();
    registering_group = UT_TESTS_UNKNOWN;
    if (status != 0 || CU_get_error() != CUE_SUCCESS)
        registration_failed = true;
    return registration_failed ? -1 : 0;
}

/* Validate errors the official parser only logs. Consume -p/--config here,
 * rather than sending JSON fixture config to the framework's asserting KVP API. */
static int parse_options(int argc, char **argv, options_t *options)
{
    enum { CONFIG_OPTION = 256 };
    static const struct option long_options[] = {
        {"config", required_argument, NULL, CONFIG_OPTION},
        {"gtest_output", required_argument, NULL, 0},
        {NULL, 0, NULL, 0}
    };
    int opt, configs = 0, result = 0;

    options->config = getenv("LPA_CONFIG");
    if (options->config == NULL)
        options->config = LPA_DEFAULT_CONFIG;
    options->argv[options->argc++] = argv[0];
    opterr = 0;
    optind = 0;
    while ((opt = getopt_long(argc, argv, "cabhf:l:tp:d:e:",
                              long_options, NULL)) != -1)
    {
        char *flag = NULL;
        bool argument = false;
        switch (opt)
        {
            case 'p':
            case CONFIG_OPTION:
                if (++configs > 1 || optarg[0] == '\0')
                    result = -1;
                options->config = optarg;
                break;
            case 'h': options->help = true; break;
            case 'c': flag = "-c"; break;
            case 'a': flag = "-a"; break;
            case 'b': flag = "-b"; break;
            case 't': flag = "-t"; break;
            case 'f': flag = "-f"; argument = true; break;
            case 'l': flag = "-l"; argument = true; break;
            case 0: flag = "--gtest_output"; argument = true; break;
            case 'd':
            case 'e':
            {
                char *end;
                long group;
                errno = 0;
                group = strtol(optarg, &end, 10);
                if (errno != 0 || end == optarg || *end != '\0' ||
                    group < UT_TESTS_L1 || group >= UT_TESTS_MAX)
                    result = -1;
                flag = opt == 'd' ? "-d" : "-e";
                argument = true;
                break;
            }
            default: result = -1; break;
        }
        if (flag != NULL)
        {
            if ((size_t)options->argc + 2 >=
                sizeof(options->argv) / sizeof(options->argv[0]))
            {
                result = -1;
                break;
            }
            options->argv[options->argc++] = flag;
            if (argument)
                options->argv[options->argc++] = optarg;
        }
    }
    if (optind != argc)
        result = -1;
    optind = 0;
    opterr = 1;
    return result;
}

/* PUBLIC_INTERFACE */
/**
 * Run LPA tests with the official UT modes and ordered -d/-e group filters.
 * argc/argv accept -b/-a/-c, -l log-path, and -p/--config JSON fixture path.
 * LPA_CONFIG overrides the executable's compiled-in default fixture path.
 * Return zero only for help or a nonempty run without any CUnit/UT failure.
 */
int main(int argc, char **argv)
{
    options_t options = {0};
    UT_status_t status;
    int result = EXIT_FAILURE;
    int l1_status, l2_status;

    if (parse_options(argc, argv, &options) != 0)
    {
        fprintf(stderr, "LPA invalid command-line options\n");
        return EXIT_FAILURE;
    }
    if (options.help)
    {
        printf("Usage: %s [-b|-a|-c] [-d group] [-e group] [-l log-path]\n"
               "       [-p JSON-config | --config JSON-config]\n"
               "Groups: 1=L1, 2=L2. Default config: LPA_CONFIG or built-in path.\n",
               argv[0]);
        return EXIT_SUCCESS;
    }
    if (UT_init(options.argc, options.argv) != UT_STATUS_OK || configuration_failed)
    {
        fprintf(stderr, "LPA framework initialization failed\n");
        goto done;
    }
    if (test_lpa_config_load(options.config, &test_lpa_config) != 0)
    {
        fprintf(stderr, "LPA missing or invalid config\n");
        goto done;
    }
    CU_set_fail_on_inactive(CU_FALSE);
    l1_status = register_hal_l1_tests();
    l2_status = register_hal_l2_tests();
    if (l1_status != 0 || l2_status != 0 || registration_failed ||
        CU_get_error() != CUE_SUCCESS)
    {
        fprintf(stderr, "LPA suite/test registration failed\n");
        goto done;
    }
    for (unsigned int i = 0; i < filter_count; ++i)
        for (unsigned int j = 0; j < suite_count; ++j)
            if ((int)suites[j].group == filters[i].group)
                CU_set_suite_active(suites[j].suite,
                                    filters[i].enabled ? CU_TRUE : CU_FALSE);

    running = true;
    status = UT_run_tests();
    if (status == UT_STATUS_OK && captured && tests_run != 0 &&
        assertions_failed == 0 && tests_failed == 0 && suites_failed == 0 &&
        run_error == CUE_SUCCESS)
        result = EXIT_SUCCESS;
    else
        fprintf(stderr, "LPA run failed or selected zero tests\n");

done:
    CU_cleanup_registry();
    UT_exit();
    test_lpa_config_release(&test_lpa_config);
    return result;
}
