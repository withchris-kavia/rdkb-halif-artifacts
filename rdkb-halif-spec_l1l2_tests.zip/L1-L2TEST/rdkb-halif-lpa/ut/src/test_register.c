/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include "lpa_test_harness.h"

extern int test_lpa_hal_l1_register(void);
extern int test_lpa_hal_l2_register(void);

/* PUBLIC_INTERFACE */
/** Register L1 tests in UT_TESTS_L1; return nonzero on any registration failure. */
int register_hal_l1_tests(void)
{
    return lpa_harness_register_group(UT_TESTS_L1, test_lpa_hal_l1_register);
}

/* PUBLIC_INTERFACE */
/** Register L2 tests in UT_TESTS_L2; return nonzero on any registration failure. */
int register_hal_l2_tests(void)
{
    return lpa_harness_register_group(UT_TESTS_L2, test_lpa_hal_l2_register);
}
