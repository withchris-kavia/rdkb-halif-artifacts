/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
/*
 * Public declarations: include/lpa_hal.h.
 * Synthetic outcomes/reset/callback timing: lpa_test_control.h, Linux only.
 * No live provisioning or vendor contract completion is implied by host passes.
 */
#include <stdlib.h>
#include <string.h>
#include "lpa_test_helpers.h"

static void test_public_types_and_constants(void)
{
    CellularPreferredUICC_t preferred = CELLULAR_UICC_USIM;
    CellularDeviceSimStatus_t status = SIM_PREPARATION_PENDING;
    cellular_sim_download_progress_callback callback = NULL;
    eSIMProfileStruct profile = {{0}, 0, {0}};

    CU_ASSERT_EQUAL(preferred, 0);
    CU_ASSERT_EQUAL(CELLULAR_UICC_ESIM, 1);
    CU_ASSERT_EQUAL(status, 1);
    CU_ASSERT_EQUAL(SIM_PREPARATION_INPROGRESS, 2);
    CU_ASSERT_EQUAL(SIM_PREPARATION_DOWNLOADED, 3);
    CU_ASSERT_EQUAL(SIM_PREPARATION_DONE, 4);
    CU_ASSERT_EQUAL(RETURN_ERROR, -1);
    CU_ASSERT_EQUAL(RETURN_OK, 0);
    CU_ASSERT_EQUAL(TRUE, 1);
    CU_ASSERT_EQUAL(FALSE, 0);
    CU_ASSERT_PTR_NULL(callback);
    CU_ASSERT_EQUAL(sizeof(profile.iccid), 32);
    CU_ASSERT_EQUAL(sizeof(profile.profileName), 16);
    CU_ASSERT_EQUAL(profile.profileState, 0);
}

static void test_lpa_init(void)
{
    if (test_lpa_begin())
        test_lpa_end();
}

static void test_lpa_exit(void)
{
    if (!test_lpa_begin())
        return;
    test_lpa_end();
#ifdef BUILD_LINUX
    CU_ASSERT_EQUAL(cellular_esim_get_eid(), RETURN_ERROR);
#endif
}

static void test_get_profile_info(void)
{
    test_lpa_snapshot_t snapshot = {0};
    if (!test_lpa_begin())
        return;
    /* The output slot is eSIMProfileStruct *, so &slot is exactly **, not ***. */
    if (test_lpa_snapshot(&snapshot))
    {
#ifdef BUILD_LINUX
        CU_ASSERT_EQUAL(snapshot.count, LPA_MODEL_INITIAL_PROFILE_COUNT);
#endif
        /* No hardcoded provider-name whitelist and no raw identifier logging. */
        for (int i = 0; i < snapshot.count; ++i)
            CU_ASSERT(memchr(snapshot.list[i].profileName, '\0',
                             sizeof(snapshot.list[i].profileName)) != NULL);
    }
    test_lpa_snapshot_release(&snapshot);
    test_lpa_end();
}

static void test_get_eid(void)
{
    if (!test_lpa_begin())
        return;
    CU_ASSERT_EQUAL(cellular_esim_get_eid(), RETURN_OK);
    test_lpa_end();
}

static void test_get_euicc(void)
{
    if (!test_lpa_begin())
        return;
    CU_ASSERT_EQUAL(cellular_esim_get_euicc(), RETURN_OK);
    test_lpa_end();
}

#ifdef BUILD_LINUX
static void test_smds(void)
{
    char *input = test_lpa_config.smds;
    if (!test_lpa_begin())
        return;
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(input), RETURN_OK);
    test_lpa_end();
}

static void test_smds_invalid(void)
{
    char empty[] = "", wrong[] = "not-a-controlled-server.invalid";
    if (!test_lpa_begin())
        return;
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(NULL), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(empty), RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_smds(wrong), RETURN_ERROR);
    test_lpa_end();
}

static void test_smdp(void)
{
    char *input = test_lpa_config.smdp;
    if (!test_lpa_begin())
        return;
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_defaultsmdp(input),
                    RETURN_OK);
    test_lpa_end();
}

static void test_smdp_invalid(void)
{
    char empty[] = "", wrong[] = "not-a-controlled-server.invalid";
    if (!test_lpa_begin())
        return;
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_defaultsmdp(NULL),
                    RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_defaultsmdp(empty),
                    RETURN_ERROR);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_from_defaultsmdp(wrong),
                    RETURN_ERROR);
    test_lpa_end();
}

static void test_activationcode(void)
{
    char *code = test_lpa_config.activation_code;
    cellular_sim_download_progress_callback callback = test_lpa_progress;
    if (!test_lpa_begin())
        return;
    test_lpa_progress_reset(0);
    /* Activation uses TRUE/FALSE, not the other entrypoints' 0/-1 convention. */
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(code,
                                                                      callback),
                    TRUE);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.invalid, 0);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.count, 15);
    CU_ASSERT_STRING_EQUAL(test_lpa_progress_capture.messages[0],
                            "Activation Code decoded");
    CU_ASSERT_STRING_EQUAL(test_lpa_progress_capture.messages[14],
                            "download successful");
    test_lpa_end();
}

static void test_activationcode_invalid(void)
{
    char *code = test_lpa_config.activation_code;
    char empty[] = "", wrong[] = "invalid";
    if (!test_lpa_begin())
        return;
    test_lpa_progress_reset(0);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(
                        NULL, test_lpa_progress), FALSE);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(
                        empty, test_lpa_progress), FALSE);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(
                        wrong, test_lpa_progress), FALSE);
    CU_ASSERT_EQUAL(cellular_esim_download_profile_with_activationcode(code, NULL),
                    FALSE);
    CU_ASSERT_EQUAL(test_lpa_progress_capture.count, 0);
    test_lpa_end();
}

static void test_get_profile_info_invalid(void)
{
    eSIMProfileStruct *list = NULL;
    int count = 123;
    if (!test_lpa_begin())
        return;
    CU_ASSERT_EQUAL(cellular_esim_get_profile_info(NULL, &count), RETURN_ERROR);
    CU_ASSERT_EQUAL(count, 0);
    CU_ASSERT_EQUAL(cellular_esim_get_profile_info(&list, NULL), RETURN_ERROR);
    CU_ASSERT_PTR_NULL(list);
    free(list);
    CU_ASSERT_EQUAL(cellular_esim_get_profile_info(NULL, NULL), RETURN_ERROR);
    test_lpa_end();
}

typedef int (*profile_action_t)(char *, int);

static void valid_action(profile_action_t action)
{
    char *identity = test_lpa_config.existing[0];
    if (!test_lpa_begin())
        return;
    CU_ASSERT_EQUAL(action(identity, LPA_MODEL_ICCID_SIZE), RETURN_OK);
    test_lpa_end();
}

static void invalid_actions(profile_action_t action)
{
    char empty[] = "", short_id[] = "123", nondigit[] = "8900000000000000000x";
    char long_id[] = "890000000000000000010";
    char *existing = test_lpa_config.existing[0], *absent = test_lpa_config.absent;
    if (!test_lpa_begin())
        return;
    CU_ASSERT_EQUAL(action(NULL, LPA_MODEL_ICCID_SIZE), RETURN_ERROR);
    CU_ASSERT_EQUAL(action(empty, LPA_MODEL_ICCID_SIZE), RETURN_ERROR);
    CU_ASSERT_EQUAL(action(short_id, LPA_MODEL_ICCID_SIZE), RETURN_ERROR);
    CU_ASSERT_EQUAL(action(nondigit, LPA_MODEL_ICCID_SIZE), RETURN_ERROR);
    CU_ASSERT_EQUAL(action(long_id, LPA_MODEL_ICCID_SIZE), RETURN_ERROR);
    CU_ASSERT_EQUAL(action(existing, 0), RETURN_ERROR);
    CU_ASSERT_EQUAL(action(existing, -1), RETURN_ERROR);
    CU_ASSERT_EQUAL(action(existing, LPA_MODEL_ICCID_SIZE - 1), RETURN_ERROR);
    CU_ASSERT_EQUAL(action(existing, LPA_MODEL_ICCID_SIZE + 1), RETURN_ERROR);
    CU_ASSERT_EQUAL(action(absent, LPA_MODEL_ICCID_SIZE), RETURN_ERROR);
    test_lpa_end();
}

static void test_enable(void)
{
    valid_action(cellular_esim_enable_profile);
}

static void test_enable_invalid(void)
{
    invalid_actions(cellular_esim_enable_profile);
}

static void test_disable(void)
{
    valid_action(cellular_esim_disable_profile);
}

static void test_disable_invalid(void)
{
    invalid_actions(cellular_esim_disable_profile);
}

static void test_delete(void)
{
    valid_action(cellular_esim_delete_profile);
}

static void test_delete_invalid(void)
{
    invalid_actions(cellular_esim_delete_profile);
}
#endif

/* PUBLIC_INTERFACE */
/** Register L1 ABI/API checks explicitly; propagate all suite/test failures. */
int test_lpa_hal_l1_register(void)
{
    static const struct
    {
        const char *name;
        void (*function)(void);
    } cases[] = {
        {"public types and constants", test_public_types_and_constants},
        {"lpa_init", test_lpa_init},
        {"lpa_exit", test_lpa_exit},
        {"get_profile_info", test_get_profile_info},
        {"get_eid status", test_get_eid},
        {"get_euicc status", test_get_euicc},
#ifdef BUILD_LINUX
        {"SMDS download", test_smds},
        {"SMDS invalid inputs", test_smds_invalid},
        {"default SMDP download", test_smdp},
        {"default SMDP invalid inputs", test_smdp_invalid},
        {"activation code and progress callback", test_activationcode},
        {"activation code invalid inputs", test_activationcode_invalid},
        {"enumeration invalid outputs", test_get_profile_info_invalid},
        {"enable profile", test_enable},
        {"enable invalid inputs", test_enable_invalid},
        {"disable profile", test_disable},
        {"disable invalid inputs", test_disable_invalid},
        {"delete profile", test_delete},
        {"delete invalid inputs", test_delete_invalid},
#endif
    };
    UT_test_suite_t *suite;
#ifdef BUILD_LINUX
    if (!test_lpa_fixtures_valid())
        return -1;
#endif
    suite = UT_add_suite_withGroupID("[L1 LPA HAL]", NULL,
                                     test_lpa_suite_cleanup, UT_TESTS_L1);
    if (suite == NULL)
        return -1;
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i)
        if (UT_add_test(suite, cases[i].name, cases[i].function) == NULL)
            return -1;
    return 0;
}
