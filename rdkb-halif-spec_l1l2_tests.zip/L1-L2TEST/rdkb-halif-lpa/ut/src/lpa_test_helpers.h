/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#ifndef LPA_TEST_HELPERS_H
#define LPA_TEST_HELPERS_H

#include <stddef.h>
#include <ut.h>
#include "lpa_hal.h"

typedef struct
{
    char **existing;
    int count;
    char absent[21];
    char downloads[3][21];
    char smds[64];
    char smdp[64];
    char activation_code[96];
} test_lpa_config_t;

/* Shared helper owns storage; main loads before registration and releases last.
 * Callers borrow fields and must not free them or retain them after release. */
extern test_lpa_config_t test_lpa_config;

/* PUBLIC_INTERFACE */
/**
 * Load filename into a zero-initialized, owned config in either build mode.
 * Require all six fields, bounded nonempty strings and distinct 20-digit ICCIDs.
 * Linux additionally requires the exact synthetic reference-model fixtures.
 * Reject malformed JSON, duplicate/unknown fields, escapes and embedded NULs.
 * Release old/partial allocations on failure; return 0 on success, -1 otherwise.
 */
int test_lpa_config_load(const char *filename, test_lpa_config_t *config);

/* PUBLIC_INTERFACE */
/** Release owned config allocations, including partial construction; NULL is safe. */
void test_lpa_config_release(test_lpa_config_t *config);

typedef struct
{
    eSIMProfileStruct *list;
    int count;
} test_lpa_snapshot_t;

/* PUBLIC_INTERFACE */
/** Initialize a case, resetting only the Linux model; assert and return readiness. */
int test_lpa_begin(void);

/* PUBLIC_INTERFACE */
/** Exit after a case and record any cleanup failure without aborting the test. */
void test_lpa_end(void);

/* PUBLIC_INTERFACE */
/** Final Linux cleanup guard; return an actual suite cleanup failure to CUnit. */
int test_lpa_suite_cleanup(void);

/* PUBLIC_INTERFACE */
/** Populate a zero-initialized snapshot, checking bounded fields; free on error. */
int test_lpa_snapshot(test_lpa_snapshot_t *snapshot);

/* PUBLIC_INTERFACE */
/** Release a caller-owned contiguous snapshot and clear its slots; NULL is safe. */
void test_lpa_snapshot_release(test_lpa_snapshot_t *snapshot);

/* PUBLIC_INTERFACE */
/** Find an exact terminated ICCID in a validated snapshot, or return NULL. */
const eSIMProfileStruct *test_lpa_find(const test_lpa_snapshot_t *snapshot,
                                     const char *identity);

/* PUBLIC_INTERFACE */
/** Compare snapshots by identity, name and state, independently of list ordering. */
int test_lpa_same(const test_lpa_snapshot_t *left,
                  const test_lpa_snapshot_t *right);

#ifdef BUILD_LINUX
#include "lpa_test_control.h"

#define TEST_LPA_PROGRESS_LIMIT 16
#define TEST_LPA_PROGRESS_WIDTH 96

typedef struct
{
    size_t count;
    int invalid;
    size_t reject_after;
    char messages[TEST_LPA_PROGRESS_LIMIT][TEST_LPA_PROGRESS_WIDTH];
} test_lpa_progress_t;

extern test_lpa_progress_t test_lpa_progress_capture;

/* PUBLIC_INTERFACE */
/** Check the shared existing-profile array contains exactly the two model fixtures. */
int test_lpa_fixtures_valid(void);

/* PUBLIC_INTERFACE */
/** Clear copied progress state and set zero for success or a one-based abort index. */
void test_lpa_progress_reset(size_t reject_after);

/* PUBLIC_INTERFACE */
/** Copy borrowed synchronous model progress; reject NULL/overflow/selected index. */
int test_lpa_progress(char *message);
#endif
#endif
