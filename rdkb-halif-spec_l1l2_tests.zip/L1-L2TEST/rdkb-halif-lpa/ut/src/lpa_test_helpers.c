/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 * See http://www.apache.org/licenses/LICENSE-2.0
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cJSON.h>
#include "lpa_test_helpers.h"

test_lpa_config_t test_lpa_config;

/* PUBLIC_INTERFACE */
/** Initialize independently; repeated init/exit is a Linux convention only. */
int test_lpa_begin(void)
{
    int status;
#ifdef BUILD_LINUX
    status = cellular_esim_lpa_exit();
    CU_ASSERT_EQUAL(status, RETURN_OK);
    if (status != RETURN_OK)
        return 0;
#endif
    status = cellular_esim_lpa_init();
    CU_ASSERT_EQUAL(status, RETURN_OK);
    if (status != RETURN_OK)
    {
        (void)cellular_esim_lpa_exit();
        return 0;
    }
    return 1;
}

/* PUBLIC_INTERFACE */
/** Record cleanup errors without bypassing the caller's owned-resource release. */
void test_lpa_end(void)
{
    int status = cellular_esim_lpa_exit();
    CU_ASSERT_EQUAL(status, RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Last-chance model cleanup, with its real status propagated to CUnit. */
int test_lpa_suite_cleanup(void)
{
#ifdef BUILD_LINUX
    return cellular_esim_lpa_exit();
#else
    return 0;
#endif
}

static int profile_valid(const eSIMProfileStruct *profile)
{
    if (memchr(profile->iccid, '\0', sizeof(profile->iccid)) == NULL ||
        memchr(profile->profileName, '\0', sizeof(profile->profileName)) == NULL)
        return 0;
    if (strlen(profile->iccid) != 20)
        return 0;
    for (int i = 0; i < 20; ++i)
        if (profile->iccid[i] < '0' || profile->iccid[i] > '9')
            return 0;
    return profile->profileState == 0 || profile->profileState == 1;
}

/* PUBLIC_INTERFACE */
/** Obtain one HAL-allocated contiguous snapshot, checking status before use. */
int test_lpa_snapshot(test_lpa_snapshot_t *snapshot)
{
    int status, valid = 1;
    if (snapshot == NULL || snapshot->list != NULL || snapshot->count != 0)
    {
        CU_FAIL("snapshot output must be zero-initialized and unowned");
        return 0;
    }
    status = cellular_esim_get_profile_info(&snapshot->list, &snapshot->count);
    CU_ASSERT_EQUAL(status, RETURN_OK);
    CU_ASSERT_PTR_NOT_NULL(snapshot->list);
    CU_ASSERT(snapshot->count > 0);
    if (status != RETURN_OK || snapshot->list == NULL || snapshot->count <= 0)
        valid = 0;
    if (valid)
    {
        for (int i = 0; i < snapshot->count; ++i)
        {
            int fields_valid = profile_valid(&snapshot->list[i]);
            CU_ASSERT(fields_valid);
            if (!fields_valid)
                valid = 0;
            for (int j = 0; j < i; ++j)
            {
                int unique = strncmp(snapshot->list[i].iccid,
                                     snapshot->list[j].iccid,
                                     sizeof(snapshot->list[i].iccid)) != 0;
                CU_ASSERT(unique);
                if (!unique)
                    valid = 0;
            }
        }
    }
    if (!valid)
        test_lpa_snapshot_release(snapshot);
    return valid;
}

/* PUBLIC_INTERFACE */
/** Free only the snapshot base allocation, never individual struct entries. */
void test_lpa_snapshot_release(test_lpa_snapshot_t *snapshot)
{
    if (snapshot != NULL)
    {
        free(snapshot->list);
        snapshot->list = NULL;
        snapshot->count = 0;
    }
}

/* PUBLIC_INTERFACE */
/** Locate a profile without unbounded reads from HAL-owned fields. */
const eSIMProfileStruct *test_lpa_find(const test_lpa_snapshot_t *snapshot,
                                     const char *identity)
{
    if (snapshot == NULL || snapshot->list == NULL || identity == NULL)
        return NULL;
    for (int i = 0; i < snapshot->count; ++i)
        if (strncmp(snapshot->list[i].iccid, identity,
                    sizeof(snapshot->list[i].iccid)) == 0)
            return &snapshot->list[i];
    return NULL;
}

/* PUBLIC_INTERFACE */
/** Compare semantic fields, not padding bytes or incidental enumeration order. */
int test_lpa_same(const test_lpa_snapshot_t *left,
                  const test_lpa_snapshot_t *right)
{
    if (left == NULL || right == NULL || left->count != right->count ||
        left->list == NULL || right->list == NULL)
        return 0;
    for (int i = 0; i < left->count; ++i)
    {
        const eSIMProfileStruct *other =
            test_lpa_find(right, left->list[i].iccid);
        if (other == NULL || other->profileState != left->list[i].profileState ||
            strncmp(other->profileName, left->list[i].profileName,
                    sizeof(other->profileName)) != 0)
            return 0;
    }
    return 1;
}

static int copy_string(const cJSON *value, char *output, size_t capacity)
{
    size_t length;
    if (!cJSON_IsString(value) || value->valuestring == NULL)
        return 0;
    length = strlen(value->valuestring);
    if (length == 0 || length >= capacity)
        return 0;
    memcpy(output, value->valuestring, length + 1);
    return 1;
}

static int identity_valid(const cJSON *value)
{
    if (!cJSON_IsString(value) || value->valuestring == NULL ||
        strlen(value->valuestring) != 20)
        return 0;
    for (int i = 0; i < 20; ++i)
        if (value->valuestring[i] < '0' || value->valuestring[i] > '9')
            return 0;
    return 1;
}

static int existing_contains(const test_lpa_config_t *config, const char *identity)
{
    for (int i = 0; i < config->count; ++i)
        if (config->existing[i] != NULL &&
            strcmp(config->existing[i], identity) == 0)
            return 1;
    return 0;
}

#ifdef BUILD_LINUX
static int model_existing_valid(const test_lpa_config_t *config)
{
    return config->existing != NULL &&
           config->count == LPA_MODEL_INITIAL_PROFILE_COUNT &&
           existing_contains(config, LPA_MODEL_INITIAL_ICCID_1) &&
           existing_contains(config, LPA_MODEL_INITIAL_ICCID_2);
}

static int model_config_valid(const test_lpa_config_t *config)
{
    return model_existing_valid(config) &&
           strcmp(config->absent, LPA_MODEL_ABSENT_ICCID) == 0 &&
           strcmp(config->downloads[0], LPA_MODEL_SMDS_ICCID) == 0 &&
           strcmp(config->downloads[1], LPA_MODEL_SMDP_ICCID) == 0 &&
           strcmp(config->downloads[2], LPA_MODEL_ACTIVATION_ICCID) == 0 &&
           strcmp(config->smds, LPA_MODEL_SMDS) == 0 &&
           strcmp(config->smdp, LPA_MODEL_SMDP) == 0 &&
           strcmp(config->activation_code, LPA_MODEL_ACTIVATION_CODE) == 0;
}

/* PUBLIC_INTERFACE */
/** Validate shared existing inputs without claiming they are real subscriber IDs. */
int test_lpa_fixtures_valid(void)
{
    return model_existing_valid(&test_lpa_config);
}
#endif

/* PUBLIC_INTERFACE */
/** Release both completed and partially initialized owned fixture storage. */
void test_lpa_config_release(test_lpa_config_t *config)
{
    if (config == NULL)
        return;
    if (config->existing != NULL)
    {
        for (int i = 0; i < config->count; ++i)
            free(config->existing[i]);
        free(config->existing);
    }
    memset(config, 0, sizeof(*config));
}

/* PUBLIC_INTERFACE */
/** Strictly parse a bounded fixture file and release everything on failure. */
int test_lpa_config_load(const char *filename, test_lpa_config_t *config)
{
    static const char *const keys[] = {
        "iccid", "absent_iccid", "download_iccid",
        "smds", "smdp", "activation_code"
    };
    test_lpa_config_t pending = {0};
    FILE *file = NULL;
    char *content = NULL;
    const char *end = NULL;
    cJSON *json = NULL, *item, *values;
    unsigned int seen = 0;
    long length;
    int status = -1;

    if (config == NULL)
        return -1;
    test_lpa_config_release(config);
    if (filename == NULL || filename[0] == '\0')
        goto done;
    file = fopen(filename, "rb");
    if (file == NULL || fseek(file, 0, SEEK_END) != 0)
        goto done;
    length = ftell(file);
    if (length <= 0 || length > 1024 * 1024 || fseek(file, 0, SEEK_SET) != 0)
        goto done;
    content = malloc((size_t)length + 1);
    if (content == NULL ||
        fread(content, 1, (size_t)length, file) != (size_t)length || ferror(file))
        goto done;
    content[length] = '\0';
    /* Controlled fixture inputs need no escapes; reject hidden/truncated NULs. */
    if (memchr(content, '\0', (size_t)length) != NULL ||
        memchr(content, '\\', (size_t)length) != NULL)
        goto done;
    json = cJSON_ParseWithLengthOpts(content, (size_t)length + 1, &end, 1);
    if (!cJSON_IsObject(json) || end != content + length)
        goto done;
    cJSON_ArrayForEach(item, json)
    {
        size_t key;
        if (item->string == NULL)
            goto done;
        for (key = 0; key < sizeof(keys) / sizeof(keys[0]); ++key)
            if (strcmp(item->string, keys[key]) == 0)
                break;
        if (key == sizeof(keys) / sizeof(keys[0]) || (seen & (1U << key)))
            goto done;
        seen |= 1U << key;
    }
    if (seen != (1U << (sizeof(keys) / sizeof(keys[0]))) - 1U)
        goto done;
    values = cJSON_GetObjectItemCaseSensitive(json, "iccid");
    if (!cJSON_IsArray(values))
        goto done;
    pending.count = cJSON_GetArraySize(values);
    if (pending.count <= 0 || pending.count > 128)
        goto done;
    pending.existing = calloc((size_t)pending.count, sizeof(*pending.existing));
    if (pending.existing == NULL)
        goto done;
    for (int i = 0; i < pending.count; ++i)
    {
        item = cJSON_GetArrayItem(values, i);
        if (!identity_valid(item) || existing_contains(&pending, item->valuestring))
            goto done;
        pending.existing[i] = calloc(21, 1);
        if (pending.existing[i] == NULL)
            goto done;
        memcpy(pending.existing[i], item->valuestring, 21);
    }
    item = cJSON_GetObjectItemCaseSensitive(json, "absent_iccid");
    if (!identity_valid(item) ||
        existing_contains(&pending, item->valuestring))
        goto done;
    memcpy(pending.absent, item->valuestring, sizeof(pending.absent));
    values = cJSON_GetObjectItemCaseSensitive(json, "download_iccid");
    if (!cJSON_IsArray(values) || cJSON_GetArraySize(values) != 3)
        goto done;
    for (int i = 0; i < 3; ++i)
    {
        item = cJSON_GetArrayItem(values, i);
        if (!identity_valid(item) ||
            existing_contains(&pending, item->valuestring) ||
            strcmp(pending.absent, item->valuestring) == 0)
            goto done;
        for (int j = 0; j < i; ++j)
            if (strcmp(pending.downloads[j], item->valuestring) == 0)
                goto done;
        memcpy(pending.downloads[i], item->valuestring,
               sizeof(pending.downloads[i]));
    }
    if (!copy_string(cJSON_GetObjectItemCaseSensitive(json, "smds"),
                     pending.smds, sizeof(pending.smds)) ||
        !copy_string(cJSON_GetObjectItemCaseSensitive(json, "smdp"),
                     pending.smdp, sizeof(pending.smdp)) ||
        !copy_string(cJSON_GetObjectItemCaseSensitive(json, "activation_code"),
                     pending.activation_code, sizeof(pending.activation_code)))
        goto done;
#ifdef BUILD_LINUX
    if (!model_config_valid(&pending))
        goto done;
#endif
    status = 0;

done:
    if (file != NULL && fclose(file) != 0)
        status = -1;
    cJSON_Delete(json);
    free(content);
    if (status == 0)
    {
        *config = pending;
        memset(&pending, 0, sizeof(pending));
    }
    test_lpa_config_release(&pending);
    return status;
}

#ifdef BUILD_LINUX
test_lpa_progress_t test_lpa_progress_capture;

/* PUBLIC_INTERFACE */
/** Clear copies, not retained vendor pointers; used only for the synchronous model. */
void test_lpa_progress_reset(size_t reject_after)
{
    memset(&test_lpa_progress_capture, 0, sizeof(test_lpa_progress_capture));
    test_lpa_progress_capture.reject_after = reject_after;
}

/* PUBLIC_INTERFACE */
/** Copy each borrowed message during its valid lifetime; optionally abort. */
int test_lpa_progress(char *message)
{
    size_t length;
    if (message == NULL)
    {
        test_lpa_progress_capture.invalid = 1;
        return RETURN_ERROR;
    }
    length = strnlen(message, TEST_LPA_PROGRESS_WIDTH);
    if (length == 0 || length == TEST_LPA_PROGRESS_WIDTH ||
        test_lpa_progress_capture.count == TEST_LPA_PROGRESS_LIMIT)
    {
        test_lpa_progress_capture.invalid = 1;
        return RETURN_ERROR;
    }
    memcpy(test_lpa_progress_capture.messages[test_lpa_progress_capture.count],
           message, length + 1);
    ++test_lpa_progress_capture.count;
    return test_lpa_progress_capture.reject_after ==
           test_lpa_progress_capture.count ? RETURN_ERROR : RETURN_OK;
}
#endif
