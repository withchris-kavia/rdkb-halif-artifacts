#!/usr/bin/env bash

# *
# * If not stated otherwise in this file or this component's LICENSE file the
# * following copyright and licenses apply:
# *
# * Copyright 2023 RDK Management
# *
# * Licensed under the Apache License, Version 2.0 (the "License");
# * you may not use this file except in compliance with the License.
# * You may obtain a copy of the License at
# *
# * http://www.apache.org/licenses/LICENSE-2.0
# *
# * Unless required by applicable law or agreed to in writing, software
# * distributed under the License is distributed on an "AS IS" BASIS,
# * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# * See the License for the specific language governing permissions and
# * limitations under the License.
# *

set -euo pipefail

DIR="$PWD"
UT_PROJECT_VERSION="${UT_PROJECT_VERSION:-main}"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
    printf '%s\n' \
        'Usage: build_ut.sh [--dir DIRECTORY] [make arguments ...]' \
        'Defaults to the current directory and TARGET=linux.' \
        'Use clean to remove build outputs, or TARGET=arm for vendor linkage.'
    exit 0
fi

if [[ "${1:-}" == "--dir" ]]; then
    if [[ $# -lt 2 || -z "$2" || "$2" == -* ]]; then
        printf 'build_ut.sh: --dir requires a directory\n' >&2
        exit 2
    fi
    DIR="$2"
    shift 2
fi

if [[ ! -d "$DIR/ut" ]]; then
    # Change only the repository basename, preserving HTTPS/SSH transport.
    REMOTE="$(git -C "$SCRIPT_DIR" remote get-url origin)"
    case "$REMOTE" in
        */rdkb-halif-moca.git|*:rdkb-halif-moca.git)
            TEST_REPO="${REMOTE%rdkb-halif-moca.git}rdkb-halif-test-moca.git" ;;
        */rdkb-halif-moca|*:rdkb-halif-moca)
            TEST_REPO="${REMOTE%rdkb-halif-moca}rdkb-halif-test-moca" ;;
        *)
            printf 'build_ut.sh: unexpected MoCA origin: %s\n' "$REMOTE" >&2
            exit 2 ;;
    esac
    printf 'Cloning MoCA unit tests into [%s/ut]\n' "$DIR"
    git clone -- "$TEST_REPO" "$DIR/ut"
    git -C "$DIR/ut" checkout "$UT_PROJECT_VERSION"
fi

cd -- "$DIR/ut"
# bash does not require a checkout's build.sh to have its execute bit set.
exec bash -e ./build.sh "$@"
