/*
 * If not stated otherwise in this file or this component's LICENSE file the
 * following copyright and licenses apply:
 * Copyright 2016 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file test_l1_moca_hal.c
 * Native L1 contract checks for include/moca_hal.h.
 * Linux-only oracles cite skeletons/include/moca_hal_test_support.h G01-G18;
 * synthetic identities, traffic, ACA timing and hardware presence are NOT
 * portable vendor guarantees. No device files, sleeps or external equipment.
 */
#include <ut.h>
#include "moca_hal.h"
#include <limits.h>
#include <stdint.h>
#include <string.h>

#ifdef MOCA_LINUX_REFERENCE
#include "test_moca_hal_helpers.h"
#define RESET_MODEL() moca_test_reset()
#else
#define RESET_MODEL() ((void)0)
#endif

/** Pin public enum values and deliberate status aliases without inventing errors. */
static void test_l1_constants(void)
{
    CU_ASSERT(TRUE == 1 && FALSE == 0 && ENABLE == 1);
    CU_ASSERT(STATUS_SUCCESS == 0);
    CU_ASSERT(STATUS_FAILURE == -1);
    CU_ASSERT(STATUS_NOT_AVAILABLE == -2);
    CU_ASSERT(STATUS_INPROGRESS == -1);
    CU_ASSERT(STATUS_NO_NODE == -2);
    CU_ASSERT(STATUS_INVALID_PROBE == -3);
    CU_ASSERT(STATUS_INVALID_CHAN == -4);
    CU_ASSERT(IF_STATUS_Up == 1);
    CU_ASSERT(IF_STATUS_Down == 2);
    CU_ASSERT(IF_STATUS_Unknown == 3);
    CU_ASSERT(IF_STATUS_Dormant == 4);
    CU_ASSERT(IF_STATUS_NotPresent == 5);
    CU_ASSERT(IF_STATUS_LowerLayerDown == 6);
    CU_ASSERT(IF_STATUS_Error == 7);
    CU_ASSERT(PROBE_QUITE == 0 && PROBE_EVM == 1);
    CU_ASSERT(kMoca_MaxCpeList == 256);
    CU_ASSERT(kMoca_MaxMocaNodes == 16);
    CU_ASSERT(MAC_PADDING == 12);
}

/* Each generated case has exactly one invalid argument; valid storage is used
 * for invalid-index cases. NULL cases exercise the portable public interfaces. */
#define NULL_CASE(name, expression) \
    static void name(void) \
    { \
        RESET_MODEL(); \
        CU_ASSERT((expression) == STATUS_FAILURE); \
    }

NULL_CASE(test_l1_GetIfConfig_null, moca_GetIfConfig(0, NULL))
NULL_CASE(test_l1_SetIfConfig_null, moca_SetIfConfig(0, NULL))
NULL_CASE(test_l1_Dynamic_null, moca_IfGetDynamicInfo(0, NULL))
NULL_CASE(test_l1_Static_null, moca_IfGetStaticInfo(0, NULL))
NULL_CASE(test_l1_Stats_null, moca_IfGetStats(0, NULL))
NULL_CASE(test_l1_Count_null, moca_GetNumAssociatedDevices(0, NULL))
NULL_CASE(test_l1_MacCounters_null, moca_IfGetExtCounter(0, NULL))
NULL_CASE(test_l1_Aggregate_null, moca_IfGetExtAggrCounter(0, NULL))
NULL_CASE(test_l1_ResetCount_null, moca_GetResetCount(NULL))
NULL_CASE(test_l1_AcaConfig_null, moca_getIfAcaConfig(0, NULL))
NULL_CASE(test_l1_AcaStatus_null, moca_getIfAcaStatus(0, NULL))
NULL_CASE(test_l1_Devices_outer_null, moca_GetAssociatedDevices(0, NULL))

/** The nested pointer is an independently invalid argument, not an index test. */
static void test_l1_Devices_inner_null(void)
{
    moca_associated_device_t *pointer = NULL;
    RESET_MODEL();
    CU_ASSERT(moca_GetAssociatedDevices(0, &pointer) == STATUS_FAILURE);
    CU_ASSERT(pointer == NULL);
}

#ifdef MOCA_LINUX_REFERENCE

/** Check every seeded configuration field (G07-G10, G14). */
static void test_l1_GetIfConfig_fields(void)
{
    moca_cfg_t actual;
    moca_cfg_t expected = {
        .InstanceNumber = 0, .Alias = "moca0", .bEnabled = TRUE,
        .bPreferredNC = TRUE, .PrivacyEnabledSetting = FALSE,
        .FreqCurrentMaskSetting = "0000000000000001",
        .KeyPassphrase = "reference-key", .TxPowerLimit = 0,
        .AutoPowerControlPhyRate = 1000, .BeaconPowerLimit = 3,
        .MaxIngressBWThreshold = 1000000000UL,
        .MaxEgressBWThreshold = 1000000000UL, .Reset = FALSE,
        .MixedMode = TRUE, .ChannelScanning = TRUE,
        .AutoPowerControlEnable = TRUE, .EnableTabooBit = TRUE,
        .NodeTabooMask = "0000000000000000",
        .ChannelScanMask = "0000000000000003"
    };
    moca_test_reset();
    memset(&actual, 0xa5, sizeof(actual));
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &expected);
}

/** Set valid complete storage; the documented signed power range is INT-wide. */
static void test_l1_SetIfConfig_valid(void)
{
    moca_cfg_t config = {0}, input, actual = {0};
    moca_test_reset();
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &config) == STATUS_SUCCESS);
    config.TxPowerLimit = INT_MIN;
    config.AutoPowerControlPhyRate = UINT32_MAX;
    config.BeaconPowerLimit = UINT32_MAX;
    config.MaxIngressBWThreshold = UINT32_MAX;
    config.MaxEgressBWThreshold = UINT32_MAX;
    input = config;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    test_config_equal(&config, &input);
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &input);
    config.TxPowerLimit = INT_MAX;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    CU_ASSERT(actual.TxPowerLimit == INT_MAX);
}

/** Assert every static-info field and both binary and textual identities. */
static void test_l1_Static_fields(void)
{
    moca_static_info_t info;
    UCHAR mac[6 + MAC_PADDING] = {0x02};
    UCHAR taboo[128] = "0000000000000000";
    moca_test_reset();
    memset(&info, 0xa5, sizeof(info));
    CU_ASSERT_FATAL(moca_IfGetStaticInfo(0, &info) == STATUS_SUCCESS);
    test_text(info.Name, sizeof(info.Name), "moca0");
    CU_ASSERT(memcmp(info.MacAddress, mac, sizeof(mac)) == 0);
    test_text(info.FirmwareVersion, sizeof(info.FirmwareVersion),
              "linux-reference-1.0");
    CU_ASSERT(info.MaxBitRate == 1000);
    test_text(info.HighestVersion, sizeof(info.HighestVersion), "2.0");
    test_bytes_are(info.FreqCapabilityMask, sizeof(info.FreqCapabilityMask), 0xff);
    CU_ASSERT(memcmp(info.NetworkTabooMask, taboo, sizeof(taboo)) == 0);
    CU_ASSERT(info.TxBcastPowerReduction == 3);
    CU_ASSERT(info.QAM256Capable == TRUE);
    CU_ASSERT(info.PacketAggregationCapability == TRUE);
}

/** Assert every dynamic-info field at a known logical instant (G15/G16). */
static void test_l1_Dynamic_fields(void)
{
    moca_dynamic_info_t info;
    UCHAR mask[8] = {1};
    moca_test_reset();
    memset(&info, 0xa5, sizeof(info));
    CU_ASSERT_FATAL(moca_IfGetDynamicInfo(0, &info) == STATUS_SUCCESS);
    CU_ASSERT(info.Status == IF_STATUS_Up);
    CU_ASSERT(info.LastChange == MOCA_TEST_EPOCH);
    CU_ASSERT(info.MaxIngressBW == 900000000UL);
    CU_ASSERT(info.MaxEgressBW == 800000000UL);
    test_text(info.CurrentVersion, sizeof(info.CurrentVersion), "2.0");
    CU_ASSERT(info.NetworkCoordinator == 0);
    CU_ASSERT(info.NodeID == 0);
    CU_ASSERT(info.BackupNC == 1);
    CU_ASSERT(info.PrivacyEnabled == FALSE);
    CU_ASSERT(memcmp(info.FreqCurrentMask, mask, sizeof(mask)) == 0);
    CU_ASSERT(info.CurrentOperFreq == 1150);
    CU_ASSERT(info.LastOperFreq == 1150);
    CU_ASSERT(info.TxBcastRate == 500);
    CU_ASSERT(info.MaxIngressBWThresholdReached == FALSE);
    CU_ASSERT(info.MaxEgressBWThresholdReached == FALSE);
    CU_ASSERT(info.NumberOfConnectedClients == 2);
    test_text(info.NetworkCoordinatorMACAddress,
              sizeof(info.NetworkCoordinatorMACAddress), "02:00:00:00:00:00");
    CU_ASSERT(info.LinkUpTime == 0);
}

/** Assert every traffic statistic and verify reads do not clear counters. */
static void test_l1_Stats_fields(void)
{
    moca_stats_t info;
    unsigned int read;
    moca_test_reset();
    for (read = 0; read < 2; ++read)
    {
        memset(&info, 0xa5, sizeof(info));
        CU_ASSERT_FATAL(moca_IfGetStats(0, &info) == STATUS_SUCCESS);
        CU_ASSERT(info.BytesSent == 100000);
        CU_ASSERT(info.BytesReceived == 200000);
        CU_ASSERT(info.PacketsSent == 100);
        CU_ASSERT(info.PacketsReceived == 200);
        CU_ASSERT(info.ErrorsSent == 1);
        CU_ASSERT(info.ErrorsReceived == 2);
        CU_ASSERT(info.UnicastPacketsSent == 70);
        CU_ASSERT(info.UnicastPacketsReceived == 140);
        CU_ASSERT(info.DiscardPacketsSent == 3);
        CU_ASSERT(info.DiscardPacketsReceived == 4);
        CU_ASSERT(info.MulticastPacketsSent == 20);
        CU_ASSERT(info.MulticastPacketsReceived == 40);
        CU_ASSERT(info.BroadcastPacketsSent == 10);
        CU_ASSERT(info.BroadcastPacketsReceived == 20);
        CU_ASSERT(info.UnknownProtoPacketsReceived == 5);
        CU_ASSERT(info.ExtAggrAverageTx == 4);
        CU_ASSERT(info.ExtAggrAverageRx == 5);
    }
}

/** Assert every MAC and aggregate counter, not merely successful returns. */
static void test_l1_Counters_fields(void)
{
    moca_mac_counters_t mac;
    moca_aggregate_counters_t aggregate;
    moca_test_reset();
    memset(&mac, 0xa5, sizeof(mac));
    memset(&aggregate, 0xa5, sizeof(aggregate));
    CU_ASSERT_FATAL(moca_IfGetExtCounter(0, &mac) == STATUS_SUCCESS);
    CU_ASSERT(mac.Map == 10 && mac.Rsrv == 20);
    CU_ASSERT(mac.Lc == 30 && mac.Adm == 40);
    CU_ASSERT(mac.Probe == 50 && mac.Async == 60);
    CU_ASSERT_FATAL(moca_IfGetExtAggrCounter(0, &aggregate) == STATUS_SUCCESS);
    CU_ASSERT(aggregate.Tx == 100 && aggregate.Rx == 200);
}

/** Caller owns all storage, counts are OUT, and untouched tails are significant. */
static void test_l1_Membership_fields(void)
{
    struct
    {
        moca_associated_device_t rows[MOCA_TEST_ASSOC_CAPACITY];
        UCHAR guard[32];
    } devices;
    struct
    {
        moca_cpe_t rows[kMoca_MaxCpeList];
        UCHAR guard[32];
    } cpes;
    moca_associated_device_t *pointer = devices.rows;
    ULONG count = ULONG_MAX, node;
    INT cpe_count = -99;
    moca_test_reset();
    memset(&devices, 0xa5, sizeof(devices));
    memset(&cpes, 0xa5, sizeof(cpes));
    CU_ASSERT_FATAL(moca_GetNumAssociatedDevices(0, &count) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(count == 2);
    CU_ASSERT_FATAL(moca_GetAssociatedDevices(0, &pointer) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(pointer == devices.rows);
    CU_ASSERT_FATAL(moca_GetMocaCPEs(0, cpes.rows, &cpe_count) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(cpe_count == 2);
    for (node = 1; node <= count; ++node)
    {
        moca_associated_device_t expected = {
            .MACAddress = {0x02}, .PreferredNC = FALSE, .HighestVersion = "2.0",
            .PHYTxRate = 1000, .PHYRxRate = 900, .TxPowerControlReduction = 3,
            .RxPowerLevel = -40, .TxBcastRate = 500, .RxBcastPowerLevel = -42,
            .RxErroredAndMissedPackets = 1, .QAM256Capable = TRUE,
            .PacketAggregationCapability = TRUE, .RxSNR = 35, .Active = TRUE,
            .RxBcastRate = 450, .NumberOfClients = 1
        };
        expected.NodeID = node;
        expected.MACAddress[5] = (UCHAR)node;
        expected.TxPackets = 100 + node;
        expected.RxPackets = 200 + node;
        test_peer_equal(&devices.rows[node - 1], &expected);
        CU_ASSERT(memcmp(cpes.rows[node - 1].mac_addr, expected.MACAddress, 6) == 0);
    }
    test_bytes_are(devices.rows + count,
                   sizeof(devices.rows) - count * sizeof(devices.rows[0]), 0xa5);
    test_bytes_are(cpes.rows + cpe_count,
                   sizeof(cpes.rows) - (size_t)cpe_count * sizeof(cpes.rows[0]), 0xa5);
    test_bytes_are(devices.guard, sizeof(devices.guard), 0xa5);
    test_bytes_are(cpes.guard, sizeof(cpes.guard), 0xa5);
}

/** Assert all directed mesh and synthetic flow fields with full capacities. */
static void test_l1_MeshFlow_fields(void)
{
    struct
    {
        moca_mesh_table_t rows[MOCA_TEST_MESH_CAPACITY];
        UCHAR guard[32];
    } mesh;
    struct
    {
        moca_flow_table_t rows[MOCA_TEST_FLOW_CAPACITY];
        UCHAR guard[32];
    } flow;
    ULONG mesh_count = ULONG_MAX, flow_count = ULONG_MAX, tx, rx, row = 0;
    moca_test_reset();
    memset(&mesh, 0xa5, sizeof(mesh));
    memset(&flow, 0xa5, sizeof(flow));
    CU_ASSERT_FATAL(moca_GetFullMeshRates(0, mesh.rows, &mesh_count) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(mesh_count == 6);
    for (tx = 0; tx < 3; ++tx)
    {
        for (rx = 0; rx < 3; ++rx)
        {
            ULONG rate = tx == 0 ? 1000 : 900;
            if (tx == rx)
            {
                continue;
            }
            CU_ASSERT(mesh.rows[row].TxNodeID == tx);
            CU_ASSERT(mesh.rows[row].RxNodeID == rx);
            CU_ASSERT(mesh.rows[row].TxRate == rate);
            CU_ASSERT(mesh.rows[row].TxRateNper == rate);
            CU_ASSERT(mesh.rows[row].TxRateVlper == rate * 9 / 10);
            ++row;
        }
    }
    CU_ASSERT_FATAL(moca_GetFlowStatistics(0, flow.rows, &flow_count) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(flow_count == 2);
    for (row = 0; row < flow_count; ++row)
    {
        CU_ASSERT(flow.rows[row].FlowID == row + 1);
        CU_ASSERT(flow.rows[row].IngressNodeID == 0);
        CU_ASSERT(flow.rows[row].EgressNodeID == row + 1);
        CU_ASSERT(flow.rows[row].FlowTimeLeft == 300);
        test_text(flow.rows[row].DestinationMACAddress,
                  sizeof(flow.rows[row].DestinationMACAddress),
                  row == 0 ? "02:00:00:00:00:01" : "02:00:00:00:00:02");
        CU_ASSERT(flow.rows[row].PacketSize == 4);
        CU_ASSERT(flow.rows[row].PeakDataRate == 100000000UL);
        CU_ASSERT(flow.rows[row].BurstSize == 4096);
        CU_ASSERT(flow.rows[row].FlowTag == row + 1);
        CU_ASSERT(flow.rows[row].LeaseTime == 300);
    }
    test_bytes_are(mesh.rows + mesh_count,
                   sizeof(mesh.rows) - mesh_count * sizeof(mesh.rows[0]), 0xa5);
    test_bytes_are(flow.rows + flow_count,
                   sizeof(flow.rows) - flow_count * sizeof(flow.rows[0]), 0xa5);
    test_bytes_are(mesh.guard, sizeof(mesh.guard), 0xa5);
    test_bytes_are(flow.guard, sizeof(flow.guard), 0xa5);
}

/** Conversion reads exactly 16 bytes; no string-length/terminator assumption. */
static void test_l1_Frequency_values(void)
{
    UCHAR mask[16] = "8000000000000000";
    UCHAR extended[18] = "000000000000000A";
    moca_test_reset();
    CU_ASSERT(moca_FreqMaskToValue(mask) == 2725);
    CU_ASSERT(moca_FreqMaskToValue(extended) == 1175);
    extended[16] = '!';
    extended[17] = '!';
    CU_ASSERT(moca_FreqMaskToValue(extended) == 1175);
    memcpy(mask, "0000000100000000", 16);
    CU_ASSERT(moca_FreqMaskToValue(mask) == 1950);
}
NULL_CASE(test_l1_Frequency_null, moca_FreqMaskToValue(NULL))

/** Zero is not an operating channel mask (G08). */
static void test_l1_Frequency_zero(void)
{
    UCHAR mask[16] = "0000000000000000";
    moca_test_reset();
    CU_ASSERT(moca_FreqMaskToValue(mask) == STATUS_FAILURE);
}

/** A malformed digit is independent of NULL, length and zero tests. */
static void test_l1_Frequency_invalid(void)
{
    UCHAR mask[16] = "000000000000000g";
    moca_test_reset();
    CU_ASSERT(moca_FreqMaskToValue(mask) == STATUS_FAILURE);
}

/** A short textual value still has the public minimum 16-byte backing buffer. */
static void test_l1_Frequency_short_text(void)
{
    UCHAR mask[16] = "1234567";
    moca_test_reset();
    CU_ASSERT(moca_FreqMaskToValue(mask) == STATUS_FAILURE);
}

/** Explicit reference presence control replaces filesystem/access assumptions. */
static void test_l1_Hardware_presence(void)
{
    moca_cfg_t output;
    moca_test_reset();
    CU_ASSERT(moca_HardwareEquipped() == TRUE);
    moca_test_set_hardware_equipped(FALSE);
    CU_ASSERT(moca_HardwareEquipped() == FALSE);
    memset(&output, 0xa5, sizeof(output));
    CU_ASSERT(moca_GetIfConfig(0, &output) == STATUS_FAILURE);
    test_bytes_are(&output, sizeof(output), 0xa5);
    moca_test_set_hardware_equipped(TRUE);
    CU_ASSERT(moca_HardwareEquipped() == TRUE);
}

/** Public reset count is OUT storage and reflects a successful reset only. */
static void test_l1_ResetCount_value(void)
{
    ULONG count = ULONG_MAX;
    moca_cfg_t config = {0};
    moca_test_reset();
    CU_ASSERT_FATAL(moca_GetResetCount(&count) == STATUS_SUCCESS);
    CU_ASSERT(count == 0);
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &config) == STATUS_SUCCESS);
    config.Reset = TRUE;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_GetResetCount(&count) == STATUS_SUCCESS);
    CU_ASSERT(count == 1);
    count = ULONG_MAX;
    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_GET_RESET_COUNT, 0) == STATUS_SUCCESS);
    CU_ASSERT(moca_GetResetCount(&count) == STATUS_FAILURE);
    CU_ASSERT(count == ULONG_MAX);
    CU_ASSERT_FATAL(moca_GetResetCount(&count) == STATUS_SUCCESS);
    CU_ASSERT(count == 1);
}

/** Fill otherwise unreferenced PNC structure via the documented test-only view. */
static void test_l1_Pnc_fields(void)
{
    moca_assoc_pnc_info_t pnc;
    moca_associated_device_t peer = test_peer(3);
    const char *versions[] = {"1.0", "1.1", "2.0", "future"};
    const ULONG values[] = {10, 11, 20, 0};
    size_t i;
    moca_test_reset();
    memset(&pnc, 0xa5, sizeof(pnc));
    CU_ASSERT_FATAL(moca_test_get_pnc(0, 0, &pnc) == STATUS_SUCCESS);
    CU_ASSERT(pnc.mocaNodeIndex == 0);
    CU_ASSERT(pnc.mocaNodePreferredNC == TRUE);
    CU_ASSERT(pnc.mocaNodeMocaversion == 20);
    for (i = 0; i < sizeof(values) / sizeof(values[0]); ++i)
    {
        memset(peer.HighestVersion, 0, sizeof(peer.HighestVersion));
        memcpy(peer.HighestVersion, versions[i], strlen(versions[i]) + 1);
        CU_ASSERT_FATAL(moca_test_set_device(0, &peer) == STATUS_SUCCESS);
        CU_ASSERT_FATAL(moca_test_get_pnc(0, 3, &pnc) == STATUS_SUCCESS);
        CU_ASSERT(pnc.mocaNodeIndex == 3);
        CU_ASSERT(pnc.mocaNodePreferredNC == TRUE);
        CU_ASSERT(pnc.mocaNodeMocaversion == values[i]);
    }
}

/** ACA configuration/status and every SCMOD carrier use real caller backing. */
static void test_l1_Aca_fields(void)
{
    moca_aca_cfg_t config = {0}, expected = {0, PROBE_QUITE, 0, 3, FALSE};
    moca_aca_stat_t status;
    moca_test_reset();
    CU_ASSERT_FATAL(moca_getIfAcaConfig(0, &config) == STATUS_SUCCESS);
    test_aca_equal(&config, &expected);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &expected, MOCA_TEST_ACA_IDLE);
    test_no_scmod(0);
    config = (moca_aca_cfg_t){1, PROBE_EVM, 1, 7, TRUE};
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, config) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_test_advance_time(0, MOCA_TEST_ACA_POLLS) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &config, MOCA_TEST_ACA_SUCCESS);
    test_scmod(0, &config);
    CU_ASSERT_FATAL(moca_cancelIfAca(0) == STATUS_SUCCESS);
    config.ACAStart = FALSE;
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &config, MOCA_TEST_ACA_IDLE);
    test_no_scmod(0);
}

static unsigned int callback_count;
static moca_associated_device_t callback_event;
static ULONG callback_index;

/** Retain a value copy; the callback's payload is borrowed only during the call. */
static INT l1_callback(ULONG index, moca_associated_device_t *event)
{
    CU_ASSERT_PTR_NOT_NULL(event);
    if (event != NULL)
    {
        callback_event = *event;
        callback_index = index;
        ++callback_count;
    }
    return STATUS_SUCCESS;
}

/** Exercise registration, replacement with NULL, no replay, and actual delivery. */
static void test_l1_Callback_registration(void)
{
    moca_associated_device_t peer = test_peer(3);
    moca_test_reset();
    callback_count = 0;
    moca_associatedDevice_callback_register(l1_callback);
    CU_ASSERT(callback_count == 0);
    CU_ASSERT_FATAL(moca_test_set_device(1, &peer) == STATUS_SUCCESS);
    CU_ASSERT(callback_count == 1);
    CU_ASSERT(callback_index == 1);
    test_peer_equal(&callback_event, &peer);
    moca_associatedDevice_callback_register(NULL);
    peer.Active = FALSE;
    CU_ASSERT_FATAL(moca_test_set_device(1, &peer) == STATUS_SUCCESS);
    CU_ASSERT(callback_count == 1);
}

/* G10 invalid index with valid initialized storage; byte preservation is only
 * checked on rejection, so unspecified padding in successful structs is ignored. */
#define INDEX_CASE(name, type, call) \
    static void name(void) \
    { \
        type output; \
        moca_test_reset(); \
        memset(&output, 0xa5, sizeof(output)); \
        CU_ASSERT((call) == STATUS_FAILURE); \
        test_bytes_are(&output, sizeof(output), 0xa5); \
    }
INDEX_CASE(test_l1_GetIfConfig_index, moca_cfg_t, moca_GetIfConfig(257, &output))
INDEX_CASE(test_l1_Dynamic_index, moca_dynamic_info_t, moca_IfGetDynamicInfo(257, &output))
INDEX_CASE(test_l1_Static_index, moca_static_info_t, moca_IfGetStaticInfo(257, &output))
INDEX_CASE(test_l1_Stats_index, moca_stats_t, moca_IfGetStats(257, &output))
INDEX_CASE(test_l1_Count_index, ULONG, moca_GetNumAssociatedDevices(257, &output))
INDEX_CASE(test_l1_MacCounters_index, moca_mac_counters_t, moca_IfGetExtCounter(257, &output))
INDEX_CASE(test_l1_Aggregate_index, moca_aggregate_counters_t, moca_IfGetExtAggrCounter(257, &output))
INDEX_CASE(test_l1_AcaConfig_index, moca_aca_cfg_t, moca_getIfAcaConfig(-1, &output))
INDEX_CASE(test_l1_AcaStatus_index, moca_aca_stat_t, moca_getIfAcaStatus(-1, &output))
NULL_CASE(test_l1_AcaCancel_index, moca_cancelIfAca(-1))

/** Invalid setter index does not also pass an invalid configuration. */
static void test_l1_SetIfConfig_index(void)
{
    moca_cfg_t config = {0};
    moca_test_reset();
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &config) == STATUS_SUCCESS);
    config.InstanceNumber = 257;
    CU_ASSERT(moca_SetIfConfig(257, &config) == STATUS_FAILURE);
}

/* G07-G09: fresh valid config for EACH independent rejected field. */
#define CONFIG_BAD_CASE(name, change) \
    static void name(void) \
    { \
        moca_cfg_t config = {0}, before = {0}, after = {0}; \
        moca_test_reset(); \
        CU_ASSERT_FATAL(moca_GetIfConfig(0, &before) == STATUS_SUCCESS); \
        config = before; \
        change; \
        CU_ASSERT(moca_SetIfConfig(0, &config) == STATUS_FAILURE); \
        CU_ASSERT_FATAL(moca_GetIfConfig(0, &after) == STATUS_SUCCESS); \
        test_config_equal(&after, &before); \
    }
CONFIG_BAD_CASE(test_l1_Config_instance, config.InstanceNumber = 1)
CONFIG_BAD_CASE(test_l1_Config_alias, memset(config.Alias, 'x', sizeof(config.Alias)))
CONFIG_BAD_CASE(test_l1_Config_key, memset(config.KeyPassphrase, 'x', sizeof(config.KeyPassphrase)))
CONFIG_BAD_CASE(test_l1_Config_enabled, config.bEnabled = 2)
CONFIG_BAD_CASE(test_l1_Config_preferred, config.bPreferredNC = 2)
CONFIG_BAD_CASE(test_l1_Config_privacy, config.PrivacyEnabledSetting = 2)
CONFIG_BAD_CASE(test_l1_Config_reset, config.Reset = 2)
CONFIG_BAD_CASE(test_l1_Config_mixed, config.MixedMode = 2)
CONFIG_BAD_CASE(test_l1_Config_scan, config.ChannelScanning = 2)
CONFIG_BAD_CASE(test_l1_Config_power, config.AutoPowerControlEnable = 2)
CONFIG_BAD_CASE(test_l1_Config_taboo, config.EnableTabooBit = 2)
CONFIG_BAD_CASE(test_l1_Config_frequency, config.FreqCurrentMaskSetting[0] = 'z')
CONFIG_BAD_CASE(test_l1_Config_zero_frequency, memset(config.FreqCurrentMaskSetting, '0', 16))
#if ULONG_MAX > UINT32_MAX
CONFIG_BAD_CASE(test_l1_Config_rate_overflow, config.AutoPowerControlPhyRate = (ULONG)UINT32_MAX + 1UL)
CONFIG_BAD_CASE(test_l1_Config_beacon_overflow, config.BeaconPowerLimit = (ULONG)UINT32_MAX + 1UL)
CONFIG_BAD_CASE(test_l1_Config_ingress_overflow, config.MaxIngressBWThreshold = (ULONG)UINT32_MAX + 1UL)
CONFIG_BAD_CASE(test_l1_Config_egress_overflow, config.MaxEgressBWThreshold = (ULONG)UINT32_MAX + 1UL)
#endif

/* OUT counts are not capacities: all non-NULL table arguments are fully sized. */
#define TABLE_NEGATIVES(prefix, type, capacity, count_type, api) \
    static void prefix##_storage_null(void) \
    { \
        count_type count = 97; \
        moca_test_reset(); \
        CU_ASSERT(api(0, NULL, &count) == STATUS_FAILURE); \
        CU_ASSERT(count == 97); \
    } \
    static void prefix##_count_null(void) \
    { \
        type rows[capacity]; \
        moca_test_reset(); \
        memset(rows, 0xa5, sizeof(rows)); \
        CU_ASSERT(api(0, rows, NULL) == STATUS_FAILURE); \
        test_bytes_are(rows, sizeof(rows), 0xa5); \
    } \
    static void prefix##_index(void) \
    { \
        type rows[capacity]; \
        count_type count = 97; \
        moca_test_reset(); \
        memset(rows, 0xa5, sizeof(rows)); \
        CU_ASSERT(api(257, rows, &count) == STATUS_FAILURE); \
        CU_ASSERT(count == 97); \
        test_bytes_are(rows, sizeof(rows), 0xa5); \
    }
TABLE_NEGATIVES(test_l1_Cpes, moca_cpe_t, kMoca_MaxCpeList, INT, moca_GetMocaCPEs)
TABLE_NEGATIVES(test_l1_Mesh, moca_mesh_table_t, MOCA_TEST_MESH_CAPACITY, ULONG, moca_GetFullMeshRates)
TABLE_NEGATIVES(test_l1_Flow, moca_flow_table_t, MOCA_TEST_FLOW_CAPACITY, ULONG, moca_GetFlowStatistics)

/** Invalid associated-device index has valid outer AND inner pointers. */
static void test_l1_Devices_index(void)
{
    moca_associated_device_t rows[MOCA_TEST_ASSOC_CAPACITY], *pointer = rows;
    moca_test_reset();
    memset(rows, 0xa5, sizeof(rows));
    CU_ASSERT(moca_GetAssociatedDevices(257, &pointer) == STATUS_FAILURE);
    CU_ASSERT(pointer == rows);
    test_bytes_are(rows, sizeof(rows), 0xa5);
}

/* Complete the assessment first: each invalid SCMOD argument is isolated from
 * "results not ready", unlike the unsafe legacy tests. */
#define SCMOD_BAD_CASE(name, call) \
    static void name(void) \
    { \
        moca_aca_cfg_t config = {0, PROBE_QUITE, 0, 3, TRUE}; \
        moca_scmod_stat_t rows[MOCA_TEST_SCMOD_CAPACITY], *pointer = rows; \
        INT count = 97; \
        moca_test_reset(); \
        CU_ASSERT_FATAL(moca_setIfAcaConfig(0, config) == STATUS_SUCCESS); \
        CU_ASSERT_FATAL(moca_test_advance_time(0, MOCA_TEST_ACA_POLLS) == STATUS_SUCCESS); \
        memset(rows, 0xa5, sizeof(rows)); \
        CU_ASSERT((call) == STATUS_FAILURE); \
        CU_ASSERT(count == 97); \
        CU_ASSERT(pointer == rows); \
        test_bytes_are(rows, sizeof(rows), 0xa5); \
    }
SCMOD_BAD_CASE(test_l1_Scmod_index, moca_getIfScmod(-1, &count, &pointer))
SCMOD_BAD_CASE(test_l1_Scmod_count_null, moca_getIfScmod(0, NULL, &pointer))
SCMOD_BAD_CASE(test_l1_Scmod_outer_null, moca_getIfScmod(0, &count, NULL))

/** NULL inner storage is distinct from NULL pointer-to-pointer and idle ACA. */
static void test_l1_Scmod_inner_null(void)
{
    moca_aca_cfg_t config = {0, PROBE_QUITE, 0, 3, TRUE};
    moca_scmod_stat_t *pointer = NULL;
    INT count = 97;
    moca_test_reset();
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, config) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_test_advance_time(0, MOCA_TEST_ACA_POLLS) == STATUS_SUCCESS);
    CU_ASSERT(moca_getIfScmod(0, &count, &pointer) == STATUS_FAILURE);
    CU_ASSERT(pointer == NULL && count == 97);
}

/* Fresh valid ACA config and valid idle state isolate each rejected field. */
#define ACA_BAD_CASE(name, index, change) \
    static void name(void) \
    { \
        moca_aca_cfg_t config = {0, PROBE_QUITE, 0, 3, FALSE}; \
        moca_aca_cfg_t actual = {0}, expected = config; \
        moca_test_reset(); \
        change; \
        CU_ASSERT(moca_setIfAcaConfig(index, config) == STATUS_FAILURE); \
        CU_ASSERT_FATAL(moca_getIfAcaConfig(0, &actual) == STATUS_SUCCESS); \
        test_aca_equal(&actual, &expected); \
    }
ACA_BAD_CASE(test_l1_AcaSet_negative_index, -1, (void)0)
ACA_BAD_CASE(test_l1_AcaSet_high_index, 257, (void)0)
ACA_BAD_CASE(test_l1_AcaSet_node, 0, config.NodeID = 16)
ACA_BAD_CASE(test_l1_AcaSet_absent_node, 0, config.NodeID = 3)
ACA_BAD_CASE(test_l1_AcaSet_probe, 0, config.Type = (PROBE_TYPE)2)
ACA_BAD_CASE(test_l1_AcaSet_channel, 0, config.Channel = 2)
ACA_BAD_CASE(test_l1_AcaSet_empty_reports, 0, config.ReportNodes = 0)
ACA_BAD_CASE(test_l1_AcaSet_high_reports, 0, config.ReportNodes = 0x10000U)
ACA_BAD_CASE(test_l1_AcaSet_absent_reports, 0, config.ReportNodes = 8)
ACA_BAD_CASE(test_l1_AcaSet_start_flag, 0, config.ACAStart = 2)
#endif

/* PUBLIC_INTERFACE */
/** Register L1 in UT_TESTS_L1; return nonzero on any registration failure. */
int test_moca_hal_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L1 moca_hal]", NULL,
#ifdef MOCA_LINUX_REFERENCE
        test_model_cleanup,
#else
        NULL,
#endif
        UT_TESTS_L1);
    if (suite == NULL)
    {
        return -1;
    }
#define ADD(function) \
    do { if (UT_add_test(suite, #function, function) == NULL) return -1; } while (0)
    ADD(test_l1_constants);
    ADD(test_l1_GetIfConfig_null);
    ADD(test_l1_SetIfConfig_null);
    ADD(test_l1_Dynamic_null);
    ADD(test_l1_Static_null);
    ADD(test_l1_Stats_null);
    ADD(test_l1_Count_null);
    ADD(test_l1_MacCounters_null);
    ADD(test_l1_Aggregate_null);
    ADD(test_l1_ResetCount_null);
    ADD(test_l1_AcaConfig_null);
    ADD(test_l1_AcaStatus_null);
    ADD(test_l1_Devices_outer_null);
    ADD(test_l1_Devices_inner_null);
#ifdef MOCA_LINUX_REFERENCE
    ADD(test_l1_GetIfConfig_fields);
    ADD(test_l1_SetIfConfig_valid);
    ADD(test_l1_Static_fields);
    ADD(test_l1_Dynamic_fields);
    ADD(test_l1_Stats_fields);
    ADD(test_l1_Counters_fields);
    ADD(test_l1_Membership_fields);
    ADD(test_l1_MeshFlow_fields);
    ADD(test_l1_Frequency_values);
    ADD(test_l1_Frequency_null);
    ADD(test_l1_Frequency_zero);
    ADD(test_l1_Frequency_invalid);
    ADD(test_l1_Frequency_short_text);
    ADD(test_l1_Hardware_presence);
    ADD(test_l1_ResetCount_value);
    ADD(test_l1_Pnc_fields);
    ADD(test_l1_Aca_fields);
    ADD(test_l1_Callback_registration);
    ADD(test_l1_GetIfConfig_index);
    ADD(test_l1_SetIfConfig_index);
    ADD(test_l1_Dynamic_index);
    ADD(test_l1_Static_index);
    ADD(test_l1_Stats_index);
    ADD(test_l1_Count_index);
    ADD(test_l1_MacCounters_index);
    ADD(test_l1_Aggregate_index);
    ADD(test_l1_AcaConfig_index);
    ADD(test_l1_AcaStatus_index);
    ADD(test_l1_AcaCancel_index);
    ADD(test_l1_Config_instance);
    ADD(test_l1_Config_alias);
    ADD(test_l1_Config_key);
    ADD(test_l1_Config_enabled);
    ADD(test_l1_Config_preferred);
    ADD(test_l1_Config_privacy);
    ADD(test_l1_Config_reset);
    ADD(test_l1_Config_mixed);
    ADD(test_l1_Config_scan);
    ADD(test_l1_Config_power);
    ADD(test_l1_Config_taboo);
    ADD(test_l1_Config_frequency);
    ADD(test_l1_Config_zero_frequency);
#if ULONG_MAX > UINT32_MAX
    ADD(test_l1_Config_rate_overflow);
    ADD(test_l1_Config_beacon_overflow);
    ADD(test_l1_Config_ingress_overflow);
    ADD(test_l1_Config_egress_overflow);
#endif
    ADD(test_l1_Cpes_storage_null);
    ADD(test_l1_Cpes_count_null);
    ADD(test_l1_Cpes_index);
    ADD(test_l1_Mesh_storage_null);
    ADD(test_l1_Mesh_count_null);
    ADD(test_l1_Mesh_index);
    ADD(test_l1_Flow_storage_null);
    ADD(test_l1_Flow_count_null);
    ADD(test_l1_Flow_index);
    ADD(test_l1_Devices_index);
    ADD(test_l1_Scmod_index);
    ADD(test_l1_Scmod_count_null);
    ADD(test_l1_Scmod_outer_null);
    ADD(test_l1_Scmod_inner_null);
    ADD(test_l1_AcaSet_negative_index);
    ADD(test_l1_AcaSet_high_index);
    ADD(test_l1_AcaSet_node);
    ADD(test_l1_AcaSet_absent_node);
    ADD(test_l1_AcaSet_probe);
    ADD(test_l1_AcaSet_channel);
    ADD(test_l1_AcaSet_empty_reports);
    ADD(test_l1_AcaSet_high_reports);
    ADD(test_l1_AcaSet_absent_reports);
    ADD(test_l1_AcaSet_start_flag);
#endif
#undef ADD
    return 0;
}
