/*
* If not stated otherwise in this file or this component's LICENSE file the
* following copyright and licenses apply:*
* Copyright 2023 RDK Management
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include <ut.h>
#include <ut_log.h>
#include <ut_kvp_profile.h>
#include <errno.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

extern int register_hal_tests( void );
extern void __real_CU_cleanup_registry(void);
extern CU_pSuite __real_CU_add_suite(const char *, CU_InitializeFunc, CU_CleanupFunc);

typedef struct suite_entry
{
    CU_pSuite suite;
    UT_groupID_t group;
    struct suite_entry *next;
} suite_entry_t;

typedef struct
{
    UT_groupID_t group;
    bool enabled;
} group_filter_t;

/* Match the framework's CLI filter limit without touching its private state. */
static group_filter_t group_filters[50];
static unsigned int filter_count;
static suite_entry_t *suites;
static bool registration_failed;
static bool configuration_failed;
static bool run_started;
static bool results_captured;
static unsigned int tests_run;
static unsigned int assertions_failed;
static unsigned int suites_failed;
static CU_ErrorCode run_error;
static ut_kvp_instance_t *profile;

/* PUBLIC_INTERFACE */
/** Initialize the MoCA suite; return zero when the harness is ready. */
int init_moca_hal_init(void)
{
    UT_LOG("MoCA test suite initialized.");
    return 0;
}

/* PUBLIC_INTERFACE */
/** Preserve CUnit results before registry cleanup resets them. */
void __wrap_CU_cleanup_registry(void)
{
    if (run_started && !results_captured)
    {
        tests_run = CU_get_number_of_tests_run();
        assertions_failed = CU_get_number_of_failures();
        suites_failed = CU_get_number_of_suites_failed();
        run_error = CU_get_error();
        results_captured = true;
    }
    __real_CU_cleanup_registry();
    while (suites != NULL)
    {
        suite_entry_t *entry = suites;
        suites = entry->next;
        free(entry);
    }
}

/* PUBLIC_INTERFACE */
/** Add a suite and retain any failure even if a later CUnit call succeeds. */
CU_pSuite __wrap_CU_add_suite(const char *name, CU_InitializeFunc init,
                            CU_CleanupFunc cleanup)
{
    CU_pSuite suite = __real_CU_add_suite(name, init, cleanup);
    if (suite == NULL || CU_get_error() != CUE_SUCCESS)
    {
        registration_failed = true;
    }
    return suite;
}

/* PUBLIC_INTERFACE */
/**
 * Register a CUnit suite with its official UT group ID.
 * Component ownership permits cleanup on partial registration without invoking
 * UT_run_tests, whose error path can leak framework-private group allocations.
 */
UT_test_suite_t *__wrap_UT_add_suite_withGroupID(
    const char *name, UT_InitialiseFunction_t init,
    UT_CleanupFunction_t cleanup, UT_groupID_t group)
{
    suite_entry_t *entry = malloc(sizeof(*entry));
    CU_pSuite suite;

    if (entry == NULL || group < UT_TESTS_L1 || group >= UT_TESTS_MAX)
    {
        free(entry);
        registration_failed = true;
        return NULL;
    }
    suite = __wrap_CU_add_suite(name, init, cleanup);
    if (suite == NULL)
    {
        free(entry);
        return NULL;
    }
    entry->suite = suite;
    entry->group = group;
    entry->next = suites;
    suites = entry;
    return (UT_test_suite_t *)suite;
}

/* PUBLIC_INTERFACE */
/** Register an ungrouped suite, retaining the official UT_TESTS_UNKNOWN default. */
UT_test_suite_t *__wrap_UT_add_suite(const char *name,
                                   UT_InitialiseFunction_t init,
                                   UT_CleanupFunction_t cleanup)
{
    return __wrap_UT_add_suite_withGroupID(name, init, cleanup, UT_TESTS_UNKNOWN);
}

/* PUBLIC_INTERFACE */
/** Register a case without ut-core's abort-on-error assertion; retain failure. */
UT_test_t *__wrap_UT_add_test(UT_test_suite_t *suite, const char *name,
                            UT_TestFunction_t function)
{
    CU_pTest test = CU_add_test((CU_pSuite)suite, name, function);
    if (test == NULL || CU_get_error() != CUE_SUCCESS)
    {
        registration_failed = true;
    }
    return (UT_test_t *)test;
}

/* PUBLIC_INTERFACE */
/** Release the component-owned KVP profile; safe to call more than once. */
void __wrap_ut_kvp_profile_close(void)
{
    if (profile != NULL)
    {
        ut_kvp_destroyInstance(profile);
        profile = NULL;
    }
}

/* PUBLIC_INTERFACE */
/** Return the active profile used by the official UT_KVP_PROFILE accessors. */
ut_kvp_instance_t *__wrap_ut_kvp_profile_getInstance(void)
{
    return profile;
}

/* PUBLIC_INTERFACE */
/** Open a KVP profile and retain load errors instead of asserting or ignoring them. */
ut_kvp_status_t __wrap_ut_kvp_profile_open(char *filename)
{
    ut_kvp_status_t status;

    __wrap_ut_kvp_profile_close();
    profile = ut_kvp_createInstance();
    status = profile == NULL ? UT_KVP_STATUS_INVALID_INSTANCE
                             : ut_kvp_open(profile, filename);
    if (status != UT_KVP_STATUS_SUCCESS)
    {
        configuration_failed = true;
        __wrap_ut_kvp_profile_close();
    }
    return status;
}

static bool valid_group(const char *text)
{
    char *end;
    long group;

    if (text[0] < '0' || text[0] > '9')
    {
        return false;
    }
    errno = 0;
    group = strtol(text, &end, 10);
    return errno == 0 && *end == '\0' && group >= UT_TESTS_L1 &&
           group < UT_TESTS_MAX;
}

static bool validate_options(int argc, char **argv, bool *help)
{
    int option;
    bool valid = true;

    /* ut-core logs unknown arguments and accepts atoi conversions. Validate
     * first, and bound filter storage to its MAX_OPTIONS (50) entries. */
    opterr = 0;
    while ((option = getopt(argc, argv, ":cabhtl:p:d:e:")) != -1)
    {
        switch (option)
        {
            case 'h':
                *help = true;
                break;
            case 'c':
            case 'a':
            case 'b':
            case 't':
                break;
            case 'd':
            case 'e':
                if (!valid_group(optarg) ||
                    filter_count >= sizeof(group_filters) / sizeof(group_filters[0]))
                {
                    valid = false;
                }
                else
                {
                    group_filters[filter_count].group = (UT_groupID_t)strtol(optarg, NULL, 10);
                    group_filters[filter_count++].enabled = option == 'e';
                }
                break;
            case 'p':
                valid = valid && optarg[0] != '\0';
                break;
            case 'l':
            {
                struct stat info;
                if (stat(optarg, &info) != 0 || !S_ISDIR(info.st_mode) ||
                    access(optarg, W_OK | X_OK) != 0)
                {
                    valid = false;
                }
                break;
            }
            default:
                valid = false;
                break;
        }
    }
    valid = valid && optind == argc;
    /* Reset getopt for UT_init, including GNU getopt's internal scan state. */
    optind = 0;
    opterr = 1;
    return valid;
}

/* PUBLIC_INTERFACE */
/**
 * Run selected MoCA suites using argc/argv's official ut-core CLI options.
 * Return zero only for help or a nonempty, successful test run; otherwise fail.
 */
int main(int argc, char **argv)
{
    bool help = false;
    UT_status_t status;

    if (!validate_options(argc, argv, &help))
    {
        fprintf(stderr, "Invalid MoCA test configuration; use -h for help.\n");
        return EXIT_FAILURE;
    }
    if (help)
    {
        printf("Usage: %s [-c|-a|-b] [-d GROUP] [-e GROUP] [-p PROFILE] "
               "[-l LOG_DIRECTORY] [-t] [-h]\n", argv[0]);
        return EXIT_SUCCESS;
    }
    if (UT_init(argc, argv) != UT_STATUS_OK || configuration_failed)
    {
        fprintf(stderr, "MoCA test framework initialization failed.\n");
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }

    /* A deliberately excluded suite is not a failed suite. Zero executed cases
     * remain an error, checked from the snapshot below. */
    CU_set_fail_on_inactive(CU_FALSE);
    if (register_hal_tests() != 0 || registration_failed ||
        CU_get_error() != CUE_SUCCESS)
    {
        fprintf(stderr, "MoCA suite/test registration failed.\n");
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }

    /* Preserve official ordered -d/-e semantics. The framework's group list
     * stays empty because the adapters above own these suite/group records. */
    for (unsigned int i = 0; i < filter_count; ++i)
    {
        for (suite_entry_t *entry = suites; entry != NULL; entry = entry->next)
        {
            if (entry->group == group_filters[i].group)
            {
                CU_set_suite_active(entry->suite,
                                    group_filters[i].enabled ? CU_TRUE : CU_FALSE);
            }
        }
    }
    run_started = true;
    status = UT_run_tests();
    UT_exit();
    if (status != UT_STATUS_OK || !results_captured || tests_run == 0 ||
        assertions_failed != 0 || suites_failed != 0 || run_error != CUE_SUCCESS)
    {
        fprintf(stderr, "MoCA run failed: tests=%u assertions_failed=%u "
                "suites_failed=%u CUnit_error=%d.\n", tests_run,
                assertions_failed, suites_failed, (int)run_error);
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
