/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 */
#ifndef TEST_MOCA_HAL_HELPERS_H
#define TEST_MOCA_HAL_HELPERS_H

#include <ut.h>
#include "moca_hal_test_support.h"
#include <string.h>

/*
 * Test-only oracles for the Linux model, not vendor acceptance criteria.
 * Sources: include/moca_hal.h and skeletons/include/moca_hal_test_support.h,
 * especially G02/G03 (ownership), G05 (ACA), G06-G10 (encoding/ABI).
 * Use CUnit predicates: UT_ASSERT_EQUAL narrows native ULONG to int.
 */
#define CHECK_FIELD(actual, expected, field) \
    CU_ASSERT((actual)->field == (expected)->field)
#define CHECK_ARRAY(actual, expected, field) \
    CU_ASSERT(memcmp((actual)->field, (expected)->field, \
                     sizeof((actual)->field)) == 0)

/** Check bytes, including array tails and canaries, without typed aliasing. */
static inline void test_bytes_are(const void *storage, size_t size, UCHAR value)
{
    const UCHAR *bytes = storage;
    size_t i;
    for (i = 0; i < size; ++i)
    {
        if (bytes[i] != value)
        {
            CU_FAIL("Unexpected write outside returned entries");
            return;
        }
    }
}

/** Check fixed CHAR storage safely even when the implementation omits a NUL. */
static inline void test_text(const char *actual, size_t capacity,
                             const char *expected)
{
    size_t length = strlen(expected);
    CU_ASSERT_FATAL(length < capacity);
    CU_ASSERT(memchr(actual, '\0', capacity) != NULL);
    CU_ASSERT(memcmp(actual, expected, length + 1) == 0);
}

/** Compare every configuration field, not unspecified struct padding. */
static inline void test_config_equal(const moca_cfg_t *actual,
                                     const moca_cfg_t *expected)
{
    CHECK_FIELD(actual, expected, InstanceNumber);
    CHECK_ARRAY(actual, expected, Alias);
    CHECK_FIELD(actual, expected, bEnabled);
    CHECK_FIELD(actual, expected, bPreferredNC);
    CHECK_FIELD(actual, expected, PrivacyEnabledSetting);
    CHECK_ARRAY(actual, expected, FreqCurrentMaskSetting);
    CHECK_ARRAY(actual, expected, KeyPassphrase);
    CHECK_FIELD(actual, expected, TxPowerLimit);
    CHECK_FIELD(actual, expected, AutoPowerControlPhyRate);
    CHECK_FIELD(actual, expected, BeaconPowerLimit);
    CHECK_FIELD(actual, expected, MaxIngressBWThreshold);
    CHECK_FIELD(actual, expected, MaxEgressBWThreshold);
    CHECK_FIELD(actual, expected, Reset);
    CHECK_FIELD(actual, expected, MixedMode);
    CHECK_FIELD(actual, expected, ChannelScanning);
    CHECK_FIELD(actual, expected, AutoPowerControlEnable);
    CHECK_FIELD(actual, expected, EnableTabooBit);
    CHECK_ARRAY(actual, expected, NodeTabooMask);
    CHECK_ARRAY(actual, expected, ChannelScanMask);
}

/** Compare every associated-device field, including binary MAC padding. */
static inline void test_peer_equal(const moca_associated_device_t *actual,
                                   const moca_associated_device_t *expected)
{
    CHECK_ARRAY(actual, expected, MACAddress);
    CHECK_FIELD(actual, expected, NodeID);
    CHECK_FIELD(actual, expected, PreferredNC);
    CHECK_ARRAY(actual, expected, HighestVersion);
    CHECK_FIELD(actual, expected, PHYTxRate);
    CHECK_FIELD(actual, expected, PHYRxRate);
    CHECK_FIELD(actual, expected, TxPowerControlReduction);
    CHECK_FIELD(actual, expected, RxPowerLevel);
    CHECK_FIELD(actual, expected, TxBcastRate);
    CHECK_FIELD(actual, expected, RxBcastPowerLevel);
    CHECK_FIELD(actual, expected, TxPackets);
    CHECK_FIELD(actual, expected, RxPackets);
    CHECK_FIELD(actual, expected, RxErroredAndMissedPackets);
    CHECK_FIELD(actual, expected, QAM256Capable);
    CHECK_FIELD(actual, expected, PacketAggregationCapability);
    CHECK_FIELD(actual, expected, RxSNR);
    CHECK_FIELD(actual, expected, Active);
    CHECK_FIELD(actual, expected, RxBcastRate);
    CHECK_FIELD(actual, expected, NumberOfClients);
}

/** Construct distinct, fully initialized membership stimulus, not a HAL mock. */
static inline moca_associated_device_t test_peer(ULONG node)
{
    moca_associated_device_t peer = {0};
    peer.MACAddress[0] = 0x02;
    peer.MACAddress[4] = 0xa5;
    peer.MACAddress[5] = (UCHAR)node;
    peer.NodeID = node;
    peer.PreferredNC = TRUE;
    memcpy(peer.HighestVersion, "1.1", 4);
    peer.PHYTxRate = 700;
    peer.PHYRxRate = 600;
    peer.TxPowerControlReduction = 2;
    peer.RxPowerLevel = -35;
    peer.TxBcastRate = 400;
    peer.RxBcastPowerLevel = -38;
    peer.TxPackets = 123;
    peer.RxPackets = 456;
    peer.RxErroredAndMissedPackets = 7;
    peer.QAM256Capable = TRUE;
    peer.PacketAggregationCapability = TRUE;
    peer.RxSNR = 32;
    peer.Active = TRUE;
    peer.RxBcastRate = 350;
    peer.NumberOfClients = 2;
    return peer;
}

/** Compare all five ACA configuration fields (passed by value in the HAL). */
static inline void test_aca_equal(const moca_aca_cfg_t *actual,
                                  const moca_aca_cfg_t *expected)
{
    CHECK_FIELD(actual, expected, NodeID);
    CHECK_FIELD(actual, expected, Type);
    CHECK_FIELD(actual, expected, Channel);
    CHECK_FIELD(actual, expected, ReportNodes);
    CHECK_FIELD(actual, expected, ACAStart);
}

/** Assert complete status contents, not just the operation's return code. */
static inline void test_aca_status(const moca_aca_stat_t *status,
                                   const moca_aca_cfg_t *config, INT state)
{
    unsigned int i;
    test_aca_equal(&status->acaCfg, config);
    CU_ASSERT(status->stat == state);
    CU_ASSERT(status->RxPower == (state == MOCA_TEST_ACA_SUCCESS ? -40 : 0));
    CU_ASSERT(status->ACATrapCompleted == (state == MOCA_TEST_ACA_SUCCESS));
    for (i = 0; i < 512; ++i)
    {
        CU_ASSERT(status->ACAPowProfile[i] ==
                  (state == MOCA_TEST_ACA_SUCCESS ? -60 + (INT)(i % 20) : 0));
    }
}

/** Assert unavailable SCMOD preserves caller buffer, pointer, and OUT count. */
static inline void test_no_scmod(int index)
{
    moca_scmod_stat_t rows[MOCA_TEST_SCMOD_CAPACITY];
    moca_scmod_stat_t *pointer = rows;
    INT count = 97;
    memset(rows, 0xa5, sizeof(rows));
    CU_ASSERT(moca_getIfScmod(index, &count, &pointer) == STATUS_FAILURE);
    CU_ASSERT(pointer == rows);
    CU_ASSERT(count == 97);
    test_bytes_are(rows, sizeof(rows), 0xa5);
}

/** Check successful SCMOD contents and every unused byte of caller storage. */
static inline void test_scmod(int index, const moca_aca_cfg_t *config)
{
    struct
    {
        moca_scmod_stat_t rows[MOCA_TEST_SCMOD_CAPACITY];
        UCHAR guard[32];
    } output;
    moca_scmod_stat_t *pointer = output.rows;
    INT count = -99;
    INT row = 0;
    unsigned int node, carrier;
    memset(&output, 0xa5, sizeof(output));
    CU_ASSERT_FATAL(moca_getIfScmod(index, &count, &pointer) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(pointer == output.rows);
    CU_ASSERT_FATAL(count >= 0 && count <= MOCA_TEST_SCMOD_CAPACITY);
    for (node = 0; node < kMoca_MaxMocaNodes; ++node)
    {
        if ((config->ReportNodes & (1U << node)) == 0)
        {
            continue;
        }
        CU_ASSERT_FATAL(row < count);
        CU_ASSERT(output.rows[row].TxNode == (INT)config->NodeID);
        CU_ASSERT(output.rows[row].RxNode == (INT)node);
        CU_ASSERT(output.rows[row].Channel == (INT)config->Channel);
        for (carrier = 0; carrier < 512; ++carrier)
        {
            CU_ASSERT(output.rows[row].Mod[carrier] == carrier % 9);
            CU_ASSERT(output.rows[row].Nper[carrier] == carrier % 7);
            CU_ASSERT(output.rows[row].Vlper[carrier] == carrier % 5);
        }
        ++row;
    }
    CU_ASSERT(count == row);
    test_bytes_are(output.rows + count,
                   sizeof(output.rows) - (size_t)count * sizeof(output.rows[0]),
                   0xa5);
    test_bytes_are(output.guard, sizeof(output.guard), 0xa5);
}

/** Cleanup runs even when the final case aborts through a fatal assertion. */
static inline int test_model_cleanup(void)
{
    moca_test_reset();
    return 0;
}

#endif
