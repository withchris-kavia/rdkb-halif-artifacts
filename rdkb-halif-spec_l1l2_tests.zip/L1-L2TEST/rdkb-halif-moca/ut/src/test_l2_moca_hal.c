/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 */
/**
 * @file test_l2_moca_hal.c
 * Official stateful tests for the ordinary native moca_hal.h profile.
 * Oracles: include/moca_hal.h and the explicit Linux-only G01-G18 policies in
 * skeletons/include/moca_hal_test_support.h. Stimulus helpers drive the real
 * reference backend; they do not replace HAL observations with mocks.
 */
#include <ut.h>
#include "moca_hal.h"

#ifdef MOCA_LINUX_REFERENCE
#include "test_moca_hal_helpers.h"
#include <limits.h>
#include <stdio.h>

/**
 * Cross-check related public views of the same membership (G02/G03/G06).
 * Expected peers must be ascending by NodeID. Always allocate maximum backing
 * storage: counts are outputs, never capacities, even for an empty membership.
 */
static void l2_check_tables(ULONG index,
                            const moca_associated_device_t *expected, ULONG count)
{
    struct { moca_associated_device_t rows[MOCA_TEST_ASSOC_CAPACITY]; UCHAR guard[32]; } devices;
    struct { moca_cpe_t rows[MOCA_TEST_CPE_CAPACITY]; UCHAR guard[32]; } cpes;
    struct { moca_mesh_table_t rows[MOCA_TEST_MESH_CAPACITY]; UCHAR guard[32]; } mesh;
    struct { moca_flow_table_t rows[MOCA_TEST_FLOW_CAPACITY]; UCHAR guard[32]; } flows;
    moca_associated_device_t *pointer = devices.rows;
    ULONG device_count = ULONG_MAX, mesh_count = ULONG_MAX, flow_count = ULONG_MAX;
    ULONG row, tx, rx, pair = 0;
    INT cpe_count = -97;

    CU_ASSERT_FATAL(count < kMoca_MaxMocaNodes);
    memset(&devices, 0xa5, sizeof(devices));
    memset(&cpes, 0xa5, sizeof(cpes));
    memset(&mesh, 0xa5, sizeof(mesh));
    memset(&flows, 0xa5, sizeof(flows));
    CU_ASSERT_FATAL(moca_GetNumAssociatedDevices(index, &device_count) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(device_count == count);
    CU_ASSERT_FATAL(moca_GetAssociatedDevices(index, &pointer) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(pointer == devices.rows);
    CU_ASSERT_FATAL(moca_GetMocaCPEs(index, cpes.rows, &cpe_count) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(cpe_count == (INT)count);
    CU_ASSERT_FATAL(moca_GetFullMeshRates(index, mesh.rows, &mesh_count) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(mesh_count == count * (count + 1));
    CU_ASSERT_FATAL(moca_GetFlowStatistics(index, flows.rows, &flow_count) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(flow_count == count);
    for (row = 0; row < count; ++row)
    {
        char mac[18];
        const UCHAR *bytes = expected[row].MACAddress;
        if (row != 0)
        {
            CU_ASSERT(expected[row - 1].NodeID < expected[row].NodeID);
        }
        test_peer_equal(&devices.rows[row], &expected[row]);
        CU_ASSERT(memcmp(cpes.rows[row].mac_addr, bytes, 6) == 0);
        (void)snprintf(mac, sizeof(mac), "%02x:%02x:%02x:%02x:%02x:%02x",
                       (unsigned int)bytes[0], (unsigned int)bytes[1],
                       (unsigned int)bytes[2], (unsigned int)bytes[3],
                       (unsigned int)bytes[4], (unsigned int)bytes[5]);
        CU_ASSERT(flows.rows[row].FlowID == expected[row].NodeID);
        CU_ASSERT(flows.rows[row].IngressNodeID == 0);
        CU_ASSERT(flows.rows[row].EgressNodeID == expected[row].NodeID);
        CU_ASSERT(flows.rows[row].FlowTimeLeft == 300);
        test_text(flows.rows[row].DestinationMACAddress,
                  sizeof(flows.rows[row].DestinationMACAddress), mac);
        CU_ASSERT(flows.rows[row].PacketSize == 4);
        CU_ASSERT(flows.rows[row].PeakDataRate == 100000000UL);
        CU_ASSERT(flows.rows[row].BurstSize == 4096);
        CU_ASSERT(flows.rows[row].FlowTag == expected[row].NodeID);
        CU_ASSERT(flows.rows[row].LeaseTime == 300);
    }
    /* Positions 1..count are the expected peers; position zero is local. */
    for (tx = 0; tx <= count; ++tx)
    {
        for (rx = 0; rx <= count; ++rx)
        {
            ULONG rate;
            if (tx == rx)
            {
                continue;
            }
            rate = tx == 0 ? expected[rx - 1].PHYTxRate : expected[tx - 1].PHYRxRate;
            CU_ASSERT(mesh.rows[pair].TxNodeID == (tx == 0 ? 0 : expected[tx - 1].NodeID));
            CU_ASSERT(mesh.rows[pair].RxNodeID == (rx == 0 ? 0 : expected[rx - 1].NodeID));
            CU_ASSERT(mesh.rows[pair].TxRate == rate);
            CU_ASSERT(mesh.rows[pair].TxRateNper == rate);
            CU_ASSERT(mesh.rows[pair].TxRateVlper == (rate / 10) * 9 + (rate % 10) * 9 / 10);
            ++pair;
        }
    }
    CU_ASSERT(pair == mesh_count);
    test_bytes_are(devices.rows + count, sizeof(devices.rows) - count * sizeof(devices.rows[0]), 0xa5);
    test_bytes_are(cpes.rows + count, sizeof(cpes.rows) - count * sizeof(cpes.rows[0]), 0xa5);
    test_bytes_are(mesh.rows + mesh_count, sizeof(mesh.rows) - mesh_count * sizeof(mesh.rows[0]), 0xa5);
    test_bytes_are(flows.rows + count, sizeof(flows.rows) - count * sizeof(flows.rows[0]), 0xa5);
    test_bytes_are(devices.guard, sizeof(devices.guard), 0xa5);
    test_bytes_are(cpes.guard, sizeof(cpes.guard), 0xa5);
    test_bytes_are(mesh.guard, sizeof(mesh.guard), 0xa5);
    test_bytes_are(flows.guard, sizeof(flows.guard), 0xa5);
}

/** L2-01: complete atomic copy, independent input ownership, related views. */
static void test_l2_config_round_trip(void)
{
    moca_cfg_t config = {0}, submitted, original, actual = {0};
    moca_dynamic_info_t dynamic = {0};
    moca_static_info_t info = {0};
    const UCHAR mask[8] = {4, 0, 0, 0, 0, 0, 0, 0x80};

    moca_test_reset();
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &config) == STATUS_SUCCESS);
    original = config;
    memset(config.Alias, 'a', sizeof(config.Alias) - 1);
    config.Alias[sizeof(config.Alias) - 1] = '\0';
    memset(config.KeyPassphrase, 'k', sizeof(config.KeyPassphrase) - 1);
    config.KeyPassphrase[sizeof(config.KeyPassphrase) - 1] = '\0';
    config.bPreferredNC = FALSE;
    config.PrivacyEnabledSetting = TRUE;
    memset(config.FreqCurrentMaskSetting, 0x6a, sizeof(config.FreqCurrentMaskSetting));
    memcpy(config.FreqCurrentMaskSetting, "8000000000000004", 16);
    config.TxPowerLimit = -17;
    config.AutoPowerControlPhyRate = 640;
    config.BeaconPowerLimit = 12;
    config.MaxIngressBWThreshold = 900000000UL;
    config.MaxEgressBWThreshold = 800000000UL;
    config.MixedMode = FALSE;
    config.ChannelScanning = FALSE;
    config.AutoPowerControlEnable = FALSE;
    config.EnableTabooBit = FALSE;
    memset(config.NodeTabooMask, 0x3c, sizeof(config.NodeTabooMask));
    memset(config.ChannelScanMask, 0x7e, sizeof(config.ChannelScanMask));
    submitted = config;
    CU_ASSERT_FATAL(moca_test_advance_time(0, 5) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    test_config_equal(&config, &submitted);
    memset(&config, 0, sizeof(config)); /* No retained pointer to the input. */
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &submitted);
    CU_ASSERT_FATAL(moca_IfGetDynamicInfo(0, &dynamic) == STATUS_SUCCESS);
    CU_ASSERT(dynamic.Status == IF_STATUS_Up);
    CU_ASSERT(dynamic.LastChange == MOCA_TEST_EPOCH);
    CU_ASSERT(dynamic.LinkUpTime == 5);
    CU_ASSERT(dynamic.PrivacyEnabled == TRUE);
    CU_ASSERT(dynamic.CurrentOperFreq == 1200);
    CU_ASSERT(dynamic.LastOperFreq == 1150);
    CU_ASSERT(memcmp(dynamic.FreqCurrentMask, mask, sizeof(mask)) == 0);
    CU_ASSERT(dynamic.MaxIngressBWThresholdReached == TRUE);
    CU_ASSERT(dynamic.MaxEgressBWThresholdReached == TRUE);
    CU_ASSERT(moca_FreqMaskToValue(actual.FreqCurrentMaskSetting) == 1200);
    CU_ASSERT_FATAL(moca_IfGetStaticInfo(0, &info) == STATUS_SUCCESS);
    test_text(info.Name, sizeof(info.Name), "moca0"); /* Alias is not Name. */
    CU_ASSERT(memcmp(info.NetworkTabooMask, submitted.NodeTabooMask,
                     sizeof(info.NetworkTabooMask)) == 0);
    memcpy(actual.FreqCurrentMaskSetting, "0000000100000000", 16);
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &actual) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_IfGetDynamicInfo(0, &dynamic) == STATUS_SUCCESS);
    CU_ASSERT(dynamic.CurrentOperFreq == 1950);
    CU_ASSERT(dynamic.LastOperFreq == 1200);
    CU_ASSERT(dynamic.LastChange == MOCA_TEST_EPOCH);

    /* Restore the snapshot through the HAL, not just through fixture reset. */
    config = original;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    test_config_equal(&config, &original);
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &original);
    CU_ASSERT_FATAL(moca_IfGetDynamicInfo(0, &dynamic) == STATUS_SUCCESS);
    CU_ASSERT(dynamic.CurrentOperFreq == 1150);
    CU_ASSERT(dynamic.LastOperFreq == 1950);
    CU_ASSERT(dynamic.PrivacyEnabled == FALSE);
    CU_ASSERT_FATAL(moca_IfGetStaticInfo(0, &info) == STATUS_SUCCESS);
    CU_ASSERT(memcmp(info.NetworkTabooMask, original.NodeTabooMask,
                     sizeof(info.NetworkTabooMask)) == 0);
}

/** L2-02: interfaces 0/1 are distinct; the inclusive upper boundary is usable. */
static void test_l2_interface_isolation(void)
{
    const ULONG indices[] = {0, 1, 256};
    moca_cfg_t before[3], actual = {0}, changed;
    moca_static_info_t info = {0};
    moca_dynamic_info_t dynamic = {0};
    moca_associated_device_t peer = test_peer(3);
    moca_aca_cfg_t aca = {1, PROBE_EVM, 1, 7, TRUE};
    moca_aca_stat_t status = {0};
    ULONG count;
    size_t i;

    moca_test_reset();
    for (i = 0; i < 3; ++i)
    {
        memset(&before[i], 0, sizeof(before[i]));
        CU_ASSERT_FATAL(moca_GetIfConfig(indices[i], &before[i]) == STATUS_SUCCESS);
        CU_ASSERT(before[i].InstanceNumber == indices[i]);
        CU_ASSERT_FATAL(moca_IfGetStaticInfo(indices[i], &info) == STATUS_SUCCESS);
        CU_ASSERT(info.MacAddress[3] == (UCHAR)(indices[i] >> 8));
        CU_ASSERT(info.MacAddress[4] == (UCHAR)indices[i]);
    }
    changed = before[1];
    memcpy(changed.Alias, "isolated-one", sizeof("isolated-one"));
    changed.bEnabled = FALSE;
    CU_ASSERT_FATAL(moca_SetIfConfig(1, &changed) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_test_advance_time(1, 23) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_test_set_device(256, &peer) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_setIfAcaConfig(256, aca) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &before[0]);
    CU_ASSERT_FATAL(moca_GetIfConfig(1, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &changed);
    CU_ASSERT_FATAL(moca_GetIfConfig(256, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &before[2]);
    for (i = 0; i < 3; ++i)
    {
        CU_ASSERT_FATAL(moca_GetNumAssociatedDevices(indices[i], &count) == STATUS_SUCCESS);
        CU_ASSERT(count == (i == 0 ? 2UL : i == 1 ? 0UL : 3UL));
        CU_ASSERT_FATAL(moca_IfGetDynamicInfo(indices[i], &dynamic) == STATUS_SUCCESS);
        CU_ASSERT(dynamic.Status == (i == 1 ? IF_STATUS_Down : IF_STATUS_Up));
        CU_ASSERT(dynamic.LastChange == MOCA_TEST_EPOCH);
        CU_ASSERT(dynamic.LinkUpTime == 0);
    }
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    CU_ASSERT(status.stat == MOCA_TEST_ACA_IDLE);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(1, &status) == STATUS_SUCCESS);
    CU_ASSERT(status.stat == MOCA_TEST_ACA_IDLE);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(256, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &aca, MOCA_TEST_ACA_RUNNING);
}

/** L2-03: disable hides membership/cancels ACA; enable restores; reset reseeds. */
static void test_l2_enable_disable_reset_lifecycle(void)
{
    moca_cfg_t defaults = {0}, config = {0}, actual = {0};
    moca_associated_device_t peers[MOCA_TEST_ASSOC_CAPACITY] = {0}, *pointer = peers;
    moca_associated_device_t added = test_peer(3);
    moca_aca_cfg_t aca = {1, PROBE_EVM, 1, 7, TRUE};
    const moca_aca_cfg_t idle = {0, PROBE_QUITE, 0, 3, FALSE};
    moca_aca_stat_t status = {0};
    moca_dynamic_info_t dynamic = {0};
    moca_stats_t stats = {0};
    ULONG resets = ULONG_MAX;

    moca_test_reset();
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &defaults) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_GetAssociatedDevices(0, &pointer) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(pointer == peers);
    peers[2] = added;
    CU_ASSERT_FATAL(moca_test_set_device(0, &added) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_test_advance_time(0, 10) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_IfGetDynamicInfo(0, &dynamic) == STATUS_SUCCESS);
    CU_ASSERT(dynamic.LinkUpTime == 10);
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, aca) == STATUS_SUCCESS);
    config = defaults;
    config.bEnabled = FALSE;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    l2_check_tables(0, NULL, 0);
    aca.ACAStart = FALSE;
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &aca, MOCA_TEST_ACA_IDLE);
    test_no_scmod(0);
    CU_ASSERT(moca_test_set_device(0, &added) == STATUS_FAILURE);
    CU_ASSERT_FATAL(moca_test_advance_time(0, 7) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_IfGetDynamicInfo(0, &dynamic) == STATUS_SUCCESS);
    CU_ASSERT(dynamic.Status == IF_STATUS_Down);
    CU_ASSERT(dynamic.LastChange == MOCA_TEST_EPOCH + 10);
    CU_ASSERT(dynamic.LinkUpTime == 0);
    CU_ASSERT(dynamic.MaxIngressBW == 0 && dynamic.MaxEgressBW == 0);
    CU_ASSERT(dynamic.CurrentOperFreq == 0 && dynamic.LastOperFreq == 1150);
    CU_ASSERT(dynamic.TxBcastRate == 0 && dynamic.NumberOfConnectedClients == 0);
    CU_ASSERT(dynamic.PrivacyEnabled == FALSE && dynamic.BackupNC == 0);
    test_bytes_are(dynamic.FreqCurrentMask, sizeof(dynamic.FreqCurrentMask), 0);

    config.bEnabled = TRUE;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    l2_check_tables(0, peers, 3);
    CU_ASSERT_FATAL(moca_IfGetDynamicInfo(0, &dynamic) == STATUS_SUCCESS);
    CU_ASSERT(dynamic.Status == IF_STATUS_Up);
    CU_ASSERT(dynamic.LastChange == MOCA_TEST_EPOCH + 17);
    CU_ASSERT(dynamic.LinkUpTime == 0);
    CU_ASSERT_FATAL(moca_test_advance_time(0, 5) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_IfGetDynamicInfo(0, &dynamic) == STATUS_SUCCESS);
    CU_ASSERT(dynamic.LinkUpTime == 5);
    config.Reset = TRUE;
    config.bEnabled = FALSE; /* Reset ignores other valid settings. */
    memcpy(config.Alias, "ignored-on-reset", sizeof("ignored-on-reset"));
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    CU_ASSERT(config.Reset == TRUE && config.bEnabled == FALSE);
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &defaults);
    l2_check_tables(0, peers, 2);
    CU_ASSERT_FATAL(moca_GetResetCount(&resets) == STATUS_SUCCESS);
    CU_ASSERT(resets == 1);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &idle, MOCA_TEST_ACA_IDLE);
    test_no_scmod(0);
    CU_ASSERT_FATAL(moca_IfGetDynamicInfo(0, &dynamic) == STATUS_SUCCESS);
    CU_ASSERT(dynamic.Status == IF_STATUS_Up);
    CU_ASSERT(dynamic.LastChange == MOCA_TEST_EPOCH + 22);
    CU_ASSERT(dynamic.LinkUpTime == 0);
    CU_ASSERT_FATAL(moca_IfGetStats(0, &stats) == STATUS_SUCCESS);
    CU_ASSERT(stats.BytesSent == 100000 && stats.BytesReceived == 200000);
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_GetResetCount(&resets) == STATUS_SUCCESS);
    CU_ASSERT(resets == 2); /* A reset is an action, not a retained TRUE flag. */
}

/** L2-04: configure-only never starts, including while administratively down. */
static void test_l2_aca_configure_only(void)
{
    moca_aca_cfg_t config = {1, PROBE_QUITE, 0, 7, FALSE}, actual = {0};
    moca_aca_stat_t status = {0};
    moca_cfg_t interface = {0};
    unsigned int probe, channel;

    moca_test_reset();
    for (probe = 0; probe <= 1; ++probe)
    {
        for (channel = 0; channel <= 1; ++channel)
        {
            config.Type = (PROBE_TYPE)probe;
            config.Channel = channel;
            CU_ASSERT_FATAL(moca_setIfAcaConfig(0, config) == STATUS_SUCCESS);
            CU_ASSERT_FATAL(moca_getIfAcaConfig(0, &actual) == STATUS_SUCCESS);
            test_aca_equal(&actual, &config);
            CU_ASSERT_FATAL(moca_test_advance_time(0, 100) == STATUS_SUCCESS);
            CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
            test_aca_status(&status, &config, MOCA_TEST_ACA_IDLE);
            test_no_scmod(0);
        }
    }
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &interface) == STATUS_SUCCESS);
    interface.bEnabled = FALSE;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &interface) == STATUS_SUCCESS);
    config.NodeID = 0;
    config.ReportNodes = 1;
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, config) == STATUS_SUCCESS);
    actual = config;
    config.ACAStart = TRUE;
    CU_ASSERT(moca_setIfAcaConfig(0, config) == STATUS_FAILURE);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &actual, MOCA_TEST_ACA_IDLE);
    interface.bEnabled = TRUE;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &interface) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &actual, MOCA_TEST_ACA_IDLE);
    test_no_scmod(0);
}

/** L2-05: all overlapping setters reject atomically; cancel is idempotent. */
static void test_l2_aca_start_overlap_cancel(void)
{
    moca_aca_cfg_t config = {1, PROBE_EVM, 1, 7, TRUE}, other, actual = {0};
    moca_aca_stat_t status = {0};
    moca_cfg_t interface = {0};
    unsigned int read;

    moca_test_reset();
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, config) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &config, MOCA_TEST_ACA_RUNNING);
    other = config;
    other.NodeID = 2;
    CU_ASSERT(moca_setIfAcaConfig(0, other) == STATUS_INPROGRESS);
    other.ACAStart = FALSE;
    CU_ASSERT(moca_setIfAcaConfig(0, other) == STATUS_INPROGRESS);
    for (read = 0; read < 5; ++read)
    {
        CU_ASSERT_FATAL(moca_getIfAcaConfig(0, &actual) == STATUS_SUCCESS);
        test_aca_equal(&actual, &config);
        CU_ASSERT_FATAL(moca_GetIfConfig(0, &interface) == STATUS_SUCCESS);
        test_no_scmod(0); /* No getter except successful status advances ACA. */
    }
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &config, MOCA_TEST_ACA_RUNNING);
    CU_ASSERT_FATAL(moca_cancelIfAca(0) == STATUS_SUCCESS);
    config.ACAStart = FALSE;
    CU_ASSERT_FATAL(moca_getIfAcaConfig(0, &actual) == STATUS_SUCCESS);
    test_aca_equal(&actual, &config);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &config, MOCA_TEST_ACA_IDLE);
    CU_ASSERT_FATAL(moca_cancelIfAca(0) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_test_advance_time(0, 20) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &config, MOCA_TEST_ACA_IDLE);
    test_no_scmod(0);
    config.ACAStart = TRUE;
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, config) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_cancelIfAca(0) == STATUS_SUCCESS);
    config.ACAStart = FALSE;
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &config, MOCA_TEST_ACA_IDLE);
}

/** L2-06: deterministic polling/time completion, full profiles, no stale SCMOD. */
static void test_l2_aca_completion_scmod(void)
{
    moca_aca_cfg_t config = {1, PROBE_EVM, 1, 7, TRUE}, actual = {0};
    moca_aca_stat_t status = {0};
    unsigned int read;

    moca_test_reset();
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, config) == STATUS_SUCCESS);
    test_no_scmod(0);
    for (read = 0; read < MOCA_TEST_ACA_POLLS; ++read)
    {
        CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
        test_aca_status(&status, &config, MOCA_TEST_ACA_RUNNING);
        test_no_scmod(0);
    }
    for (read = 0; read < 2; ++read)
    {
        CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
        test_aca_status(&status, &config, MOCA_TEST_ACA_SUCCESS);
        CU_ASSERT_FATAL(moca_getIfAcaConfig(0, &actual) == STATUS_SUCCESS);
        test_aca_equal(&actual, &config);
        test_scmod(0, &config);
    }
    config = (moca_aca_cfg_t){2, PROBE_QUITE, 0, 5, TRUE};
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, config) == STATUS_SUCCESS);
    test_no_scmod(0); /* Start invalidated the previous assessment's results. */
    CU_ASSERT_FATAL(moca_test_advance_time(0, MOCA_TEST_ACA_POLLS - 1) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_getIfAcaConfig(0, &actual) == STATUS_SUCCESS);
    test_aca_equal(&actual, &config);
    test_no_scmod(0);
    /* No status read may advance the assessment in this time-only path. */
    CU_ASSERT_FATAL(moca_test_advance_time(0, 1) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &config, MOCA_TEST_ACA_SUCCESS);
    CU_ASSERT_FATAL(moca_getIfAcaConfig(0, &actual) == STATUS_SUCCESS);
    test_aca_equal(&actual, &config);
    test_scmod(0, &config);
    config.ACAStart = FALSE;
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, config) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &config, MOCA_TEST_ACA_IDLE);
    test_no_scmod(0);
}

static unsigned int l2_callback_calls[2];
static unsigned int l2_callback_action;
static ULONG l2_expected_index, l2_expected_count;
static moca_associated_device_t l2_expected_event, l2_last_event;

static INT l2_callback_b(ULONG index, moca_associated_device_t *event);

/** Shared callback checks post-commit queryability, then poisons borrowed data. */
static INT l2_callback_observe(unsigned int callback, ULONG index,
                                moca_associated_device_t *event)
{
    moca_associated_device_t rows[MOCA_TEST_ASSOC_CAPACITY] = {0}, *pointer = rows;
    ULONG count = ULONG_MAX, row;
    BOOL found = FALSE;
    ++l2_callback_calls[callback];
    CU_ASSERT(index == l2_expected_index);
    CU_ASSERT_PTR_NOT_NULL(event);
    if (event == NULL)
    {
        return STATUS_FAILURE;
    }
    l2_last_event = *event;
    test_peer_equal(event, &l2_expected_event);
    CU_ASSERT(moca_GetNumAssociatedDevices(index, &count) == STATUS_SUCCESS);
    CU_ASSERT(count == l2_expected_count);
    CU_ASSERT(moca_GetAssociatedDevices(index, &pointer) == STATUS_SUCCESS);
    CU_ASSERT(pointer == rows);
    if (count < MOCA_TEST_ASSOC_CAPACITY)
    {
        for (row = 0; row < count; ++row)
        {
            if (rows[row].NodeID == event->NodeID)
            {
                found = TRUE;
                test_peer_equal(&rows[row], &l2_expected_event);
            }
        }
        CU_ASSERT(found == event->Active);
    }
    /* The backend must never retain this mutable stack payload as its peer. */
    event->NodeID = 15;
    event->MACAddress[0] = 0xff;
    event->PHYTxRate = 1;
    if (l2_callback_action == 1)
    {
        moca_associatedDevice_callback_register(l2_callback_b);
    }
    else if (l2_callback_action == 2)
    {
        moca_associatedDevice_callback_register(NULL);
    }
    return STATUS_FAILURE; /* The return value does not undo a committed event. */
}

/** First observer may replace itself without recursive delivery/replay. */
static INT l2_callback_a(ULONG index, moca_associated_device_t *event)
{
    return l2_callback_observe(0, index, event);
}

/** Replacement observer may unregister itself synchronously. */
static INT l2_callback_b(ULONG index, moca_associated_device_t *event)
{
    return l2_callback_observe(1, index, event);
}

/** L2-07: event cardinality/identity, coherent tables, capacity and Dormant link. */
static void test_l2_membership_callbacks_tables(void)
{
    moca_associated_device_t peers[MOCA_TEST_ASSOC_CAPACITY] = {0}, *pointer = peers;
    moca_associated_device_t peer = test_peer(3), other = test_peer(4), removal;
    moca_cfg_t config = {0};
    moca_dynamic_info_t dynamic = {0};
    moca_aca_cfg_t aca = {1, PROBE_EVM, 1, 7, TRUE};
    moca_aca_stat_t status = {0};
    ULONG node;

    moca_test_reset();
    memset(l2_callback_calls, 0, sizeof(l2_callback_calls));
    l2_callback_action = 0;
    CU_ASSERT_FATAL(moca_GetAssociatedDevices(0, &pointer) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(pointer == peers);
    moca_associatedDevice_callback_register(l2_callback_a);
    CU_ASSERT(l2_callback_calls[0] == 0 && l2_callback_calls[1] == 0);
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, aca) == STATUS_SUCCESS);
    l2_expected_index = 0;
    l2_expected_count = 3;
    l2_expected_event = peer;
    CU_ASSERT_FATAL(moca_test_set_device(0, &peer) == STATUS_SUCCESS);
    CU_ASSERT(l2_callback_calls[0] == 1);
    test_peer_equal(&peer, &l2_expected_event); /* Stimulus also remains caller-owned. */
    peers[2] = peer;
    l2_check_tables(0, peers, 3);
    aca.ACAStart = FALSE;
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &aca, MOCA_TEST_ACA_IDLE);
    test_no_scmod(0); /* Membership change cancels an in-flight assessment. */
    CU_ASSERT_FATAL(moca_test_set_device(0, &peer) == STATUS_SUCCESS);
    CU_ASSERT(l2_callback_calls[0] == 1); /* Identical update is not an event. */

    ++peer.TxPackets;
    peer.PHYTxRate = 777;
    l2_expected_event = peer;
    l2_callback_action = 1;
    CU_ASSERT_FATAL(moca_test_set_device(0, &peer) == STATUS_SUCCESS);
    CU_ASSERT(l2_callback_calls[0] == 2 && l2_callback_calls[1] == 0);
    peers[2] = peer;
    l2_check_tables(0, peers, 3); /* Payload poisoning did not alter stored fields. */
    l2_expected_index = 1;
    l2_expected_count = 3;
    l2_expected_event = other;
    l2_callback_action = 2;
    CU_ASSERT_FATAL(moca_test_set_device(1, &other) == STATUS_SUCCESS);
    CU_ASSERT(l2_callback_calls[0] == 2 && l2_callback_calls[1] == 1);
    ++other.RxPackets;
    CU_ASSERT_FATAL(moca_test_set_device(1, &other) == STATUS_SUCCESS);
    CU_ASSERT(l2_callback_calls[1] == 1); /* Unregistered during prior callback. */

    moca_associatedDevice_callback_register(l2_callback_a);
    l2_callback_action = 0;
    l2_expected_index = 0;
    l2_expected_count = 2;
    l2_expected_event = peer;
    l2_expected_event.Active = FALSE;
    removal = test_peer(3);
    removal.Active = FALSE;
    removal.PHYTxRate = 999; /* Removal event must use retained peer identity/data. */
    CU_ASSERT_FATAL(moca_test_set_device(0, &removal) == STATUS_SUCCESS);
    CU_ASSERT(l2_callback_calls[0] == 3);
    test_peer_equal(&l2_last_event, &l2_expected_event);
    l2_check_tables(0, peers, 2);
    CU_ASSERT_FATAL(moca_test_set_device(0, &removal) == STATUS_SUCCESS);
    CU_ASSERT(l2_callback_calls[0] == 3);

    CU_ASSERT_FATAL(moca_GetIfConfig(0, &config) == STATUS_SUCCESS);
    config.bEnabled = FALSE;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    config.bEnabled = TRUE;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    config.Reset = TRUE;
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &config) == STATUS_SUCCESS);
    CU_ASSERT(l2_callback_calls[0] == 3 && l2_callback_calls[1] == 1);
    l2_expected_count = 3;
    l2_expected_event = peer;
    CU_ASSERT_FATAL(moca_test_set_device(0, &peer) == STATUS_SUCCESS);
    CU_ASSERT(l2_callback_calls[0] == 4); /* Interface reset retained registration. */
    moca_associatedDevice_callback_register(NULL);

    for (node = 3; node < kMoca_MaxMocaNodes; ++node)
    {
        peers[node - 1] = test_peer(node);
        CU_ASSERT_FATAL(moca_test_set_device(0, &peers[node - 1]) == STATUS_SUCCESS);
    }
    l2_check_tables(0, peers, kMoca_MaxMocaNodes - 1);
    CU_ASSERT(l2_callback_calls[0] == 4 && l2_callback_calls[1] == 1);
    CU_ASSERT_FATAL(moca_test_advance_time(0, 3) == STATUS_SUCCESS);
    for (node = 1; node < kMoca_MaxMocaNodes; ++node)
    {
        removal = peers[node - 1];
        removal.Active = FALSE;
        CU_ASSERT_FATAL(moca_test_set_device(0, &removal) == STATUS_SUCCESS);
    }
    l2_check_tables(0, NULL, 0);
    CU_ASSERT_FATAL(moca_IfGetDynamicInfo(0, &dynamic) == STATUS_SUCCESS);
    CU_ASSERT(dynamic.Status == IF_STATUS_Dormant);
    CU_ASSERT(dynamic.LastChange == MOCA_TEST_EPOCH + 3);
    CU_ASSERT(dynamic.LinkUpTime == 0 && dynamic.NumberOfConnectedClients == 0);
}

/** L2-08: failure atomicity, valid-call consumption, recovery and isolation. */
static void test_l2_isolation_failure_invariants(void)
{
    moca_cfg_t before = {0}, changed, actual = {0}, other = {0};
    moca_aca_cfg_t aca = {1, PROBE_EVM, 1, 7, TRUE}, replacement;
    moca_aca_stat_t status = {0};
    moca_associated_device_t peer = test_peer(3);
    moca_associated_device_t devices[MOCA_TEST_ASSOC_CAPACITY], *device_pointer = devices;
    moca_cpe_t cpes[MOCA_TEST_CPE_CAPACITY];
    moca_scmod_stat_t scmod[MOCA_TEST_SCMOD_CAPACITY], *scmod_pointer = scmod;
    INT count = 97;
    ULONG resets = ULONG_MAX;
    UCHAR frequency[16] = "0000000000000001";
    unsigned int read;

    moca_test_reset();
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &before) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_GetIfConfig(1, &other) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, aca) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_setIfAcaConfig(1, aca) == STATUS_SUCCESS);
    changed = before;
    memcpy(changed.Alias, "atomic-change", sizeof("atomic-change"));
    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_SET_CONFIG, 0) == STATUS_SUCCESS);
    changed.bEnabled = 2;
    CU_ASSERT(moca_SetIfConfig(0, &changed) == STATUS_FAILURE);
    changed.bEnabled = TRUE;
    memcpy(other.Alias, "unaffected-one", sizeof("unaffected-one"));
    CU_ASSERT_FATAL(moca_SetIfConfig(1, &other) == STATUS_SUCCESS);
    CU_ASSERT(moca_SetIfConfig(0, &changed) == STATUS_FAILURE);
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &before);
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &changed) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &changed);

    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_GET_ACA_STATUS, 0) == STATUS_SUCCESS);
    CU_ASSERT(moca_getIfAcaStatus(0, NULL) == STATUS_FAILURE);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(1, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &aca, MOCA_TEST_ACA_RUNNING);
    memset(&status, 0xa5, sizeof(status));
    CU_ASSERT(moca_getIfAcaStatus(0, &status) == STATUS_FAILURE);
    test_bytes_are(&status, sizeof(status), 0xa5);
    for (read = 0; read < MOCA_TEST_ACA_POLLS; ++read)
    {
        CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
        test_aca_status(&status, &aca, MOCA_TEST_ACA_RUNNING);
    }
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &aca, MOCA_TEST_ACA_SUCCESS);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(1, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &aca, MOCA_TEST_ACA_RUNNING);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(1, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &aca, MOCA_TEST_ACA_SUCCESS);

    memset(cpes, 0xa5, sizeof(cpes));
    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_GET_CPES, 0) == STATUS_SUCCESS);
    CU_ASSERT(moca_GetMocaCPEs(0, cpes, NULL) == STATUS_FAILURE);
    test_bytes_are(cpes, sizeof(cpes), 0xa5);
    CU_ASSERT_FATAL(moca_GetMocaCPEs(1, cpes, &count) == STATUS_SUCCESS);
    CU_ASSERT(count == 2);
    memset(cpes, 0xa5, sizeof(cpes));
    count = 97;
    CU_ASSERT(moca_GetMocaCPEs(0, cpes, &count) == STATUS_FAILURE);
    CU_ASSERT(count == 97);
    test_bytes_are(cpes, sizeof(cpes), 0xa5);
    CU_ASSERT_FATAL(moca_GetMocaCPEs(0, cpes, &count) == STATUS_SUCCESS);
    CU_ASSERT(count == 2);
    memset(devices, 0xa5, sizeof(devices));
    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_GET_DEVICES, 0) == STATUS_SUCCESS);
    CU_ASSERT(moca_GetAssociatedDevices(0, &device_pointer) == STATUS_FAILURE);
    CU_ASSERT(device_pointer == devices);
    test_bytes_are(devices, sizeof(devices), 0xa5);
    CU_ASSERT_FATAL(moca_GetAssociatedDevices(0, &device_pointer) == STATUS_SUCCESS);
    CU_ASSERT(device_pointer == devices && devices[0].NodeID == 1 && devices[1].NodeID == 2);

    memset(scmod, 0xa5, sizeof(scmod));
    count = 97;
    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_GET_SCMOD, 0) == STATUS_SUCCESS);
    CU_ASSERT(moca_getIfScmod(0, &count, &scmod_pointer) == STATUS_FAILURE);
    CU_ASSERT(scmod_pointer == scmod && count == 97);
    test_bytes_are(scmod, sizeof(scmod), 0xa5);
    test_scmod(0, &aca);
    CU_ASSERT_FATAL(moca_test_set_device(1, &peer) == STATUS_SUCCESS);
    test_no_scmod(1); /* Other interface's membership did not invalidate ours. */
    test_scmod(0, &aca);

    moca_test_set_hardware_equipped(FALSE);
    memset(&actual, 0xa5, sizeof(actual));
    CU_ASSERT(moca_HardwareEquipped() == FALSE);
    CU_ASSERT(moca_GetIfConfig(0, &actual) == STATUS_FAILURE);
    test_bytes_are(&actual, sizeof(actual), 0xa5);
    before = changed;
    before.bEnabled = FALSE;
    CU_ASSERT(moca_SetIfConfig(0, &before) == STATUS_FAILURE);
    CU_ASSERT(moca_FreqMaskToValue(frequency) == 1150);
    moca_test_set_hardware_equipped(TRUE);
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &changed);
    test_scmod(0, &aca);

    replacement = (moca_aca_cfg_t){2, PROBE_QUITE, 0, 5, TRUE};
    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_SET_ACA, 0) == STATUS_SUCCESS);
    CU_ASSERT(moca_setIfAcaConfig(0, replacement) == STATUS_FAILURE);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &aca, MOCA_TEST_ACA_SUCCESS);
    test_scmod(0, &aca);
    CU_ASSERT_FATAL(moca_setIfAcaConfig(0, replacement) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_CANCEL_ACA, 0) == STATUS_SUCCESS);
    CU_ASSERT(moca_cancelIfAca(0) == STATUS_FAILURE);
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &replacement, MOCA_TEST_ACA_RUNNING);
    CU_ASSERT_FATAL(moca_cancelIfAca(0) == STATUS_SUCCESS);
    replacement.ACAStart = FALSE;
    CU_ASSERT_FATAL(moca_getIfAcaStatus(0, &status) == STATUS_SUCCESS);
    test_aca_status(&status, &replacement, MOCA_TEST_ACA_IDLE);
    test_no_scmod(0);

    changed.Reset = TRUE;
    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_SET_CONFIG, 0) == STATUS_SUCCESS);
    CU_ASSERT(moca_SetIfConfig(0, &changed) == STATUS_FAILURE);
    CU_ASSERT_FATAL(moca_GetResetCount(&resets) == STATUS_SUCCESS);
    CU_ASSERT(resets == 0);
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    changed.Reset = FALSE;
    test_config_equal(&actual, &changed);
    changed.Reset = TRUE;
    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_GET_CONFIG, 0) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(moca_SetIfConfig(0, &changed) == STATUS_SUCCESS);
    memset(&actual, 0xa5, sizeof(actual));
    CU_ASSERT(moca_GetIfConfig(0, &actual) == STATUS_FAILURE);
    test_bytes_are(&actual, sizeof(actual), 0xa5); /* Reset preserved other injections. */
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
    test_text(actual.Alias, sizeof(actual.Alias), "moca0");
    CU_ASSERT(actual.Reset == FALSE && actual.bEnabled == TRUE);
    CU_ASSERT_FATAL(moca_GetIfConfig(1, &actual) == STATUS_SUCCESS);
    test_config_equal(&actual, &other);
    CU_ASSERT_FATAL(moca_GetResetCount(&resets) == STATUS_SUCCESS);
    CU_ASSERT(resets == 1);

    /* Repeat coherent reads with freshly poisoned, maximum-capacity buffers.
     * No query may change the membership, configuration, or reset count. */
    CU_ASSERT_FATAL(moca_GetAssociatedDevices(0, &device_pointer) == STATUS_SUCCESS);
    CU_ASSERT_FATAL(device_pointer == devices);
    before = changed;
    CU_ASSERT_FATAL(moca_GetIfConfig(0, &before) == STATUS_SUCCESS);
    for (read = 0; read < 3; ++read)
    {
        l2_check_tables(0, devices, 2);
        CU_ASSERT_FATAL(moca_GetIfConfig(0, &actual) == STATUS_SUCCESS);
        test_config_equal(&actual, &before);
        CU_ASSERT_FATAL(moca_GetResetCount(&resets) == STATUS_SUCCESS);
        CU_ASSERT(resets == 1);
    }

    resets = ULONG_MAX;
    CU_ASSERT_FATAL(moca_test_fail_next(MOCA_TEST_GET_RESET_COUNT, 0) == STATUS_SUCCESS);
    CU_ASSERT(moca_GetResetCount(NULL) == STATUS_FAILURE); /* Invalid call cannot consume it. */
    CU_ASSERT(moca_GetResetCount(&resets) == STATUS_FAILURE);
    CU_ASSERT(resets == ULONG_MAX);
    CU_ASSERT_FATAL(moca_GetResetCount(&resets) == STATUS_SUCCESS);
    CU_ASSERT(resets == 1);
}
#endif

/* PUBLIC_INTERFACE */
/**
 * Register the eight Linux-reference scenarios as the official L2 group.
 * A vendor build registers no synthetic model cases and requires its own
 * hardware-specific L2 fixture; no passing placeholder suite is substituted.
 */
int test_l2_moca_hal_register(void)
{
#ifdef MOCA_LINUX_REFERENCE
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L2 moca_hal]", NULL, test_model_cleanup, UT_TESTS_L2);
    if (suite == NULL)
    {
        return -1;
    }
#define ADD(function) \
    do { if (UT_add_test(suite, #function, function) == NULL) return -1; } while (0)
    ADD(test_l2_config_round_trip);
    ADD(test_l2_interface_isolation);
    ADD(test_l2_enable_disable_reset_lifecycle);
    ADD(test_l2_aca_configure_only);
    ADD(test_l2_aca_start_overlap_cancel);
    ADD(test_l2_aca_completion_scmod);
    ADD(test_l2_membership_callbacks_tables);
    ADD(test_l2_isolation_failure_invariants);
#undef ADD
#endif
    return 0;
}
