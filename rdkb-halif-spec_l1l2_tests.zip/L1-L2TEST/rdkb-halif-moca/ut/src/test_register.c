/*
* If not stated otherwise in this file or this component's LICENSE file the
* following copyright and licenses apply:*
* Copyright 2023 RDK Management
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/* L1 Testing Functions */
extern int test_moca_hal_register(void);

#ifdef MOCA_HAS_L2_TESTS
extern int test_l2_moca_hal_register(void);
#endif

/* PUBLIC_INTERFACE */
/** Register available MoCA L1/L2 suites, returning nonzero on the first error. */
int register_hal_tests( void )
{
    if (test_moca_hal_register() != 0)
    {
        return -1;
    }
#ifdef MOCA_HAS_L2_TESTS
    if (test_l2_moca_hal_register() != 0)
    {
        return -1;
    }
#endif
    return 0;
}
