#!/usr/bin/env bash

# *
# * If not stated otherwise in this file or this component's LICENSE file the
# * following copyright and licenses apply:
# *
# * Copyright 2023 RDK Management
# *
# * Licensed under the Apache License, Version 2.0 (the "License");
# * you may not use this file except in compliance with the License.
# * You may obtain a copy of the License at
# *
# * http://www.apache.org/licenses/LICENSE-2.0
# *
# * Unless required by applicable law or agreed to in writing, software
# * distributed under the License is distributed on an "AS IS" BASIS,
# * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# * See the License for the specific language governing permissions and
# * limitations under the License.
# *

set -euo pipefail

cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ ! -d ./ut-core ]]; then
    git clone -- https://github.com/rdkcentral/ut-core.git ut-core
    # Keep the existing major-version policy; never switch an existing checkout.
    VERSION="${UT_CORE_PROJECT_VERSION:-}"
    if [[ -z "$VERSION" ]]; then
        VERSION="$(git -C ut-core tag --list '3.*' | sort -V | tail -n 1)"
    fi
    if [[ -z "$VERSION" ]]; then
        printf 'build.sh: no compatible ut-core 3.x version found\n' >&2
        exit 1
    fi
    git -C ut-core checkout "$VERSION"
fi

exec make -C . -f Makefile "$@"
