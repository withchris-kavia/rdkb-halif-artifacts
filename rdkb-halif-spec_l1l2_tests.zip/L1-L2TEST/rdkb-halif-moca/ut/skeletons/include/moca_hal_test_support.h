/*
 * Copyright 2026 RDK Management
 * Licensed under the Apache License, Version 2.0.
 */
#ifndef MOCA_HAL_TEST_SUPPORT_H
#define MOCA_HAL_TEST_SUPPORT_H

/*
 * Linux reference model ONLY. These are not vendor HAL guarantees or additions
 * to moca_hal.h. Link only the Linux skeleton, never a vendor library, to use
 * these helpers. Public HAL signatures remain unchanged.
 *
 * Policies corresponding to docs/pages/MoCAHalSpec.md's clarification checklist:
 *
 * G01: Only the ordinary, non-MOCA_VAR header profile is supported. The broken
 *      alternate header profile is not repaired or silently given new types.
 * G02: Allocate the capacities below, even for an empty table. Counts are OUT,
 *      not input capacities. Only returned entries are written; tails remain
 *      untouched. NULL storage/counts (including NULL *array) always fail.
 *      Associated devices are returned in ascending node order; use their count
 *      getter. Local node 0 plus peers 1..15 form directed, non-self mesh pairs.
 *      One synthetic CPE and one local-to-peer flow represent each active peer.
 *      SCMOD has one record per ReportNodes bit, including a self report if set.
 * G03: All storage belongs to the caller. No allocation, retention, replacement
 *      or freeing of array pointers; config/stimulus inputs are copied.
 * G04: Preserve the public numeric aliases. Overlap returns STATUS_INPROGRESS
 *      (-1); other rejected requests return STATUS_FAILURE (-1).
 * G05: ACA stat uses the header's positive states: 0 success, 3 idle/cancelled,
 *      4 running. Idle/configure-only/cancelled have no profile or SCMOD.
 *      Start clears old results. The first MOCA_TEST_ACA_POLLS successful status
 *      reads return running; the next completes. Other getters do not progress
 *      ACA. Advancing model time by that many ticks also completes it. Failed
 *      reads do not advance. No sleeps, threads or wall-clock dependency.
 * G06: MACAddress/MacAddress store six binary octets followed by zero padding.
 *      CPE MACs are six binary octets. Named CHAR MAC fields are terminated text.
 * G07: Alias, KeyPassphrase and supplied HighestVersion require a NUL within
 *      their arrays (max 63/17/63 characters); boolean fields must be 0 or 1.
 * G08: FreqMaskToValue reads exactly 16 ASCII hexadecimal digits (no terminator
 *      required), most-significant digit first. Zero/invalid/NULL fails. The
 *      least-significant set bit n selects 1150 + 25*n MHz. Additional bytes
 *      are not read. FreqCurrentMaskSetting uses this 16-byte prefix in its
 *      128-byte storage; its remainder and taboo/scan masks are retained opaque.
 *      Eight-byte observation masks encode the same 64 bits least-byte first.
 * G09: Use native header ABI, not packed/fixed-width substitutes. Config ULONG
 *      fields documented as 32-bit must be <= 0xffffffff; TxPowerLimit accepts
 *      the full native INT range (not the legacy test's undocumented -31..7).
 *      SCMOD bytes are actual UCHARs, initialized throughout all 512 elements.
 * G10: Interface indices 0..256 are independent, including 0 and 1. Signed ACA
 *      indices are range-checked before conversion. InstanceNumber must match
 *      the selected interface. Node 0 is local on each interface.
 * G11: One global callback, replacement allowed, NULL explicitly unregisters.
 *      Registration has no initial replay. Only successful membership stimuli
 *      emit events, once per changed peer; identical updates/removing an absent
 *      peer do nothing. Delivery is synchronous after commit using a borrowed
 *      stack copy, valid only during invocation. Return values are ignored.
 *      Callback mutations of the payload cannot mutate the stored peer.
 * G12: Calls/helpers must be serialized by the caller. No thread/process-safety
 *      promise; callbacks may query state or replace/unregister the callback.
 * G13: Lazy initialization; presence defaults TRUE, no /dev access. State is
 *      process-local, not persistent. Hardware absence makes data/control calls
 *      fail (conversion and callback registration remain usable).
 * G14: SetIfConfig validates before atomic copy, never modifies its input.
 *      Reset=TRUE restores that interface's defaults, counters, peers and ACA,
 *      ignoring other valid settings, reads back FALSE and increments the GLOBAL
 *      reset count once. Other interfaces/callback/presence are retained.
 *      Disable hides (does not erase) peers/flows/mesh/CPEs, cancels ACA, and
 *      reports Down; enable restores the stored membership. No implicit events
 *      from config/reset/presence changes. Membership stimuli require enabled
 *      hardware. Failures leave outputs, config, counts and pointers unchanged.
 * G15: Counters are deterministic seeded snapshots, no clear-on-read; reset
 *      restores seeds. Logical time starts at MOCA_TEST_EPOCH. LastChange is
 *      the last admin/link-state transition time; LinkUpTime advances only via
 *      the time helper. Time and reset counts saturate instead of wrapping.
 * G16: Model rates are Mbps except BW/flow peak rates in bits/s, powers dBm,
 *      duration ticks seconds. ACA supports channels 0/1 and both public probes.
 *      NodeID and ReportNodes must select present nodes (local 0 always exists
 *      on an enabled interface); ReportNodes is a nonzero low-16-bit mask.
 *      Configure-only may run while disabled; start requires enabled hardware.
 *      All ACA setters, including configure-only, reject while running. A
 *      membership change invalidates results/cancels an in-flight assessment.
 * G17: No invented public PNC getter or PQoS setter. The test-only PNC observer
 *      below covers the otherwise unreferenced structure. Its version encoding
 *      is 10/11/20 for 1.0/1.1/2.0 and 0 for an unknown version.
 * G18: No errno channel or universal -2 return. One-shot injection returns
 *      STATUS_FAILURE (FALSE for presence), before any observable mutation.
 *      It is scoped by API and interface, consumed only by a valid request.
 *      Frequency/presence/reset-count injections use interface 0. Helpers do
 *      not consume injections. moca_test_reset clears every injection.
 *
 * Defaults: enabled, preferred local NC, privacy off, "2.0", frequency bit 0,
 * two peers (1,2), idle ACA, no ready SCMOD, reset count 0. Synthetic identities
 * and statistics below exist solely to make Linux tests reproducible; they
 * represent neither a discovered device nor real traffic/hardware acceptance.
 */

#include "moca_hal.h"

#define MOCA_TEST_MAX_INTERFACES 257U
#define MOCA_TEST_ASSOC_CAPACITY kMoca_MaxMocaNodes
#define MOCA_TEST_CPE_CAPACITY kMoca_MaxCpeList
#define MOCA_TEST_MESH_CAPACITY (kMoca_MaxMocaNodes * kMoca_MaxMocaNodes)
#define MOCA_TEST_FLOW_CAPACITY kMoca_MaxMocaNodes
#define MOCA_TEST_SCMOD_CAPACITY kMoca_MaxMocaNodes
#define MOCA_TEST_ACA_POLLS 2U
#define MOCA_TEST_EPOCH 1700000000UL
#define MOCA_TEST_ACA_SUCCESS 0
#define MOCA_TEST_ACA_IDLE 3
#define MOCA_TEST_ACA_RUNNING 4

typedef enum
{
    MOCA_TEST_GET_CONFIG,
    MOCA_TEST_SET_CONFIG,
    MOCA_TEST_GET_DYNAMIC,
    MOCA_TEST_GET_STATIC,
    MOCA_TEST_GET_STATS,
    MOCA_TEST_GET_NUM_DEVICES,
    MOCA_TEST_GET_MAC_COUNTERS,
    MOCA_TEST_GET_AGGR_COUNTERS,
    MOCA_TEST_GET_CPES,
    MOCA_TEST_GET_DEVICES,
    MOCA_TEST_FREQ_VALUE,
    MOCA_TEST_HARDWARE,
    MOCA_TEST_GET_MESH,
    MOCA_TEST_GET_FLOWS,
    MOCA_TEST_GET_RESET_COUNT,
    MOCA_TEST_SET_ACA,
    MOCA_TEST_GET_ACA_CONFIG,
    MOCA_TEST_CANCEL_ACA,
    MOCA_TEST_GET_ACA_STATUS,
    MOCA_TEST_GET_SCMOD,
    MOCA_TEST_API_COUNT
} moca_test_api_t;

/* PUBLIC_INTERFACE */
/** Restore all model defaults and clear callbacks, time, failures and resets. */
void moca_test_reset(void);

/* PUBLIC_INTERFACE */
/** Set model hardware availability (nonzero means TRUE); preserve stored state. */
void moca_test_set_hardware_equipped(BOOL equipped);

/* PUBLIC_INTERFACE */
/**
 * Copy/replace an active peer, or remove it when Active=FALSE.
 * Validate index, pointer, peer node 1..15, booleans and HighestVersion first.
 * Return STATUS_SUCCESS after commit/delivery, STATUS_FAILURE without mutation.
 */
INT moca_test_set_device(ULONG ifIndex, const moca_associated_device_t *device);

/* PUBLIC_INTERFACE */
/**
 * Advance one interface's logical seconds and in-flight ACA by ticks.
 * Return STATUS_FAILURE for an invalid index; otherwise STATUS_SUCCESS, even
 * when hardware is absent. No membership callbacks are generated.
 */
INT moca_test_advance_time(ULONG ifIndex, ULONG ticks);

/* PUBLIC_INTERFACE */
/**
 * Arm one failure for api/ifIndex; repeated arming does not queue failures.
 * Return STATUS_FAILURE for invalid identifiers or a nonzero global-API index.
 */
INT moca_test_fail_next(moca_test_api_t api, ULONG ifIndex);

/* PUBLIC_INTERFACE */
/**
 * Observe local/active-peer PNC fields in caller storage without a new HAL ABI.
 * Return STATUS_FAILURE on invalid arguments, absent hardware or unknown node.
 */
INT moca_test_get_pnc(ULONG ifIndex, ULONG nodeID, moca_assoc_pnc_info_t *info);

#endif
