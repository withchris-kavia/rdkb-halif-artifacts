/*
 * If not stated otherwise in this file or this component's LICENSE file the
 * following copyright and licenses apply:
 *
 * Copyright 2023 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "moca_hal_test_support.h"

#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

/* The complete model policy and caller capacities live in the support header. */
typedef struct
{
    BOOL initialized;
    BOOL fail_next[MOCA_TEST_API_COUNT];
    moca_cfg_t config;
    moca_associated_device_t peers[MOCA_TEST_ASSOC_CAPACITY];
    moca_aca_stat_t aca;
    UINT polls_left;
    ULONG now;
    ULONG last_change;
    ULONG link_since;
    ULONG last_frequency;
} model_interface_t;

static model_interface_t interfaces[MOCA_TEST_MAX_INTERFACES];
static BOOL hardware_equipped = TRUE;
static ULONG reset_count;
static moca_associatedDevice_callback associated_callback;

static int valid_index(ULONG index)
{
    return index < MOCA_TEST_MAX_INTERFACES;
}

static int valid_signed_index(int index)
{
    return index >= 0 && (unsigned int)index < MOCA_TEST_MAX_INTERFACES;
}

static ULONG saturated_add(ULONG value, ULONG increment)
{
    return increment > ULONG_MAX - value ? ULONG_MAX : value + increment;
}

static int boolean(BOOL value)
{
    return value == FALSE || value == TRUE;
}

/* Read exactly the documented sixteen-byte model encoding, never strlen(). */
static int decode_mask(const UCHAR *mask, uint64_t *bits)
{
    uint64_t result = 0;
    unsigned int i;

    if (mask == NULL)
    {
        return 0;
    }
    for (i = 0; i < 16; ++i)
    {
        unsigned int digit;
        if (mask[i] >= '0' && mask[i] <= '9')
        {
            digit = mask[i] - '0';
        }
        else if (mask[i] >= 'a' && mask[i] <= 'f')
        {
            digit = mask[i] - 'a' + 10U;
        }
        else if (mask[i] >= 'A' && mask[i] <= 'F')
        {
            digit = mask[i] - 'A' + 10U;
        }
        else
        {
            return 0;
        }
        result = (result << 4) | digit;
    }
    *bits = result;
    return 1;
}

static ULONG mask_frequency(uint64_t bits)
{
    ULONG frequency = 1150;
    while ((bits & UINT64_C(1)) == 0)
    {
        bits >>= 1;
        frequency += 25;
    }
    return frequency;
}

static void make_mac(ULONG index, ULONG node, UCHAR *mac)
{
    memset(mac, 0, 6 + MAC_PADDING);
    mac[0] = 0x02; /* Locally administered synthetic identity. */
    mac[3] = (UCHAR)(index >> 8);
    mac[4] = (UCHAR)index;
    mac[5] = (UCHAR)node;
}

static void format_mac(const UCHAR *mac, char *text, size_t capacity)
{
    (void)snprintf(text, capacity, "%02x:%02x:%02x:%02x:%02x:%02x",
                   (unsigned int)mac[0], (unsigned int)mac[1],
                   (unsigned int)mac[2], (unsigned int)mac[3],
                   (unsigned int)mac[4], (unsigned int)mac[5]);
}

static void seed_peer(ULONG index, ULONG node, moca_associated_device_t *peer)
{
    memset(peer, 0, sizeof(*peer));
    make_mac(index, node, peer->MACAddress);
    peer->NodeID = node;
    peer->PreferredNC = FALSE;
    memcpy(peer->HighestVersion, "2.0", 4);
    peer->PHYTxRate = 1000;
    peer->PHYRxRate = 900;
    peer->TxPowerControlReduction = 3;
    peer->RxPowerLevel = -40;
    peer->TxBcastRate = 500;
    peer->RxBcastPowerLevel = -42;
    peer->TxPackets = 100 + node;
    peer->RxPackets = 200 + node;
    peer->RxErroredAndMissedPackets = 1;
    peer->QAM256Capable = TRUE;
    peer->PacketAggregationCapability = TRUE;
    peer->RxSNR = 35;
    peer->Active = TRUE;
    peer->RxBcastRate = 450;
    peer->NumberOfClients = 1;
}

static void clear_aca(model_interface_t *state)
{
    moca_aca_cfg_t config = state->aca.acaCfg;
    memset(&state->aca, 0, sizeof(state->aca));
    config.ACAStart = FALSE;
    state->aca.acaCfg = config;
    state->aca.stat = MOCA_TEST_ACA_IDLE;
    state->polls_left = 0;
}

static void initialize(ULONG index, model_interface_t *state, ULONG now)
{
    memset(state, 0, sizeof(*state));
    state->initialized = TRUE;
    state->now = now;
    state->last_change = now;
    state->link_since = now;
    state->last_frequency = 1150;
    state->config.InstanceNumber = index;
    (void)snprintf(state->config.Alias, sizeof(state->config.Alias),
                   "moca%lu", index);
    state->config.bEnabled = TRUE;
    state->config.bPreferredNC = TRUE;
    memcpy(state->config.FreqCurrentMaskSetting, "0000000000000001", 16);
    memcpy(state->config.NodeTabooMask, "0000000000000000", 16);
    memcpy(state->config.ChannelScanMask, "0000000000000003", 16);
    memcpy(state->config.KeyPassphrase, "reference-key", 14);
    state->config.TxPowerLimit = 0;
    state->config.AutoPowerControlPhyRate = 1000;
    state->config.BeaconPowerLimit = 3;
    state->config.MaxIngressBWThreshold = 1000000000UL;
    state->config.MaxEgressBWThreshold = 1000000000UL;
    state->config.MixedMode = TRUE;
    state->config.ChannelScanning = TRUE;
    state->config.AutoPowerControlEnable = TRUE;
    state->config.EnableTabooBit = TRUE;
    seed_peer(index, 1, &state->peers[1]);
    seed_peer(index, 2, &state->peers[2]);
    state->aca.acaCfg.NodeID = 0;
    state->aca.acaCfg.Type = PROBE_QUITE;
    state->aca.acaCfg.Channel = 0;
    state->aca.acaCfg.ReportNodes = 3;
    state->aca.stat = MOCA_TEST_ACA_IDLE;
}

static model_interface_t *get_state(ULONG index)
{
    model_interface_t *state;
    if (!valid_index(index))
    {
        return NULL;
    }
    state = &interfaces[index];
    if (!state->initialized)
    {
        initialize(index, state, MOCA_TEST_EPOCH);
    }
    return state;
}

/* Called only after all arguments are validated, so bad calls cannot consume
 * injections. One-shot flags are the only state changed by an injected error. */
static int no_failure(model_interface_t *state, moca_test_api_t api)
{
    if (state->fail_next[api])
    {
        state->fail_next[api] = FALSE;
        return 0;
    }
    return 1;
}

static int available(model_interface_t *state, moca_test_api_t api)
{
    return hardware_equipped && no_failure(state, api);
}

static ULONG peer_count(const model_interface_t *state)
{
    ULONG node;
    ULONG count = 0;
    if (state->config.bEnabled)
    {
        for (node = 1; node < MOCA_TEST_ASSOC_CAPACITY; ++node)
        {
            count += state->peers[node].Active ? 1UL : 0UL;
        }
    }
    return count;
}

static moca_if_status_t link_status(const model_interface_t *state)
{
    if (!state->config.bEnabled)
    {
        return IF_STATUS_Down;
    }
    return peer_count(state) ? IF_STATUS_Up : IF_STATUS_Dormant;
}

static int present_node(const model_interface_t *state, ULONG node)
{
    return node < kMoca_MaxMocaNodes &&
           (node == 0 || state->peers[node].Active);
}

static void complete_aca(model_interface_t *state)
{
    unsigned int i;
    state->aca.stat = MOCA_TEST_ACA_SUCCESS;
    state->aca.RxPower = -40;
    state->aca.ACATrapCompleted = TRUE;
    for (i = 0; i < 512; ++i)
    {
        state->aca.ACAPowProfile[i] = -60 + (INT)(i % 20);
    }
    state->polls_left = 0;
}

static int valid_config(ULONG index, const moca_cfg_t *config)
{
    uint64_t bits;
    return config != NULL && config->InstanceNumber == index &&
           memchr(config->Alias, '\0', sizeof(config->Alias)) != NULL &&
           memchr(config->KeyPassphrase, '\0', sizeof(config->KeyPassphrase)) != NULL &&
           boolean(config->bEnabled) && boolean(config->bPreferredNC) &&
           boolean(config->PrivacyEnabledSetting) && boolean(config->Reset) &&
           boolean(config->MixedMode) && boolean(config->ChannelScanning) &&
           boolean(config->AutoPowerControlEnable) && boolean(config->EnableTabooBit) &&
           config->AutoPowerControlPhyRate <= UINT32_MAX &&
           config->BeaconPowerLimit <= UINT32_MAX &&
           config->MaxIngressBWThreshold <= UINT32_MAX &&
           config->MaxEgressBWThreshold <= UINT32_MAX &&
           decode_mask(config->FreqCurrentMaskSetting, &bits) && bits != 0;
}

/* PUBLIC_INTERFACE */
/** Restore the entire test model, including callback and failure state. */
void moca_test_reset(void)
{
    memset(interfaces, 0, sizeof(interfaces));
    hardware_equipped = TRUE;
    associated_callback = NULL;
    reset_count = 0;
}

/* PUBLIC_INTERFACE */
/** Set deterministic presence without accessing any physical device. */
void moca_test_set_hardware_equipped(BOOL equipped)
{
    hardware_equipped = equipped ? TRUE : FALSE;
}

/* PUBLIC_INTERFACE */
/** Arm one API/interface failure; return failure for invalid helper arguments. */
INT moca_test_fail_next(moca_test_api_t api, ULONG ifIndex)
{
    model_interface_t *state;
    if (api < 0 || api >= MOCA_TEST_API_COUNT || !valid_index(ifIndex) ||
        ((api == MOCA_TEST_FREQ_VALUE || api == MOCA_TEST_HARDWARE ||
          api == MOCA_TEST_GET_RESET_COUNT) && ifIndex != 0))
    {
        return STATUS_FAILURE;
    }
    state = get_state(ifIndex);
    state->fail_next[api] = TRUE;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Advance one interface's clock and complete an ACA when its ticks expire. */
INT moca_test_advance_time(ULONG ifIndex, ULONG ticks)
{
    model_interface_t *state = get_state(ifIndex);
    if (state == NULL)
    {
        return STATUS_FAILURE;
    }
    state->now = saturated_add(state->now, ticks);
    if (ticks != 0 && state->aca.stat == MOCA_TEST_ACA_RUNNING)
    {
        if (ticks >= state->polls_left)
        {
            complete_aca(state);
        }
        else
        {
            state->polls_left -= (UINT)ticks;
        }
    }
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Commit a validated peer stimulus and synchronously notify with a safe copy. */
INT moca_test_set_device(ULONG ifIndex, const moca_associated_device_t *device)
{
    model_interface_t *state = get_state(ifIndex);
    moca_associated_device_t event;
    moca_associated_device_t *stored;
    moca_if_status_t before;
    moca_associatedDevice_callback callback;
    if (state == NULL || device == NULL || !hardware_equipped ||
        !state->config.bEnabled || device->NodeID == 0 ||
        device->NodeID >= MOCA_TEST_ASSOC_CAPACITY || !boolean(device->Active) ||
        !boolean(device->PreferredNC) || !boolean(device->QAM256Capable) ||
        !boolean(device->PacketAggregationCapability) ||
        memchr(device->HighestVersion, '\0', sizeof(device->HighestVersion)) == NULL)
    {
        return STATUS_FAILURE;
    }
    stored = &state->peers[device->NodeID];
    /* Normalize padding before comparing so uninitialized struct padding is
     * never interpreted as a membership change. */
    memset(&event, 0, sizeof(event));
    memcpy(event.MACAddress, device->MACAddress, 6);
    event.NodeID = device->NodeID;
    event.PreferredNC = device->PreferredNC;
    memcpy(event.HighestVersion, device->HighestVersion,
           sizeof(event.HighestVersion));
    event.PHYTxRate = device->PHYTxRate;
    event.PHYRxRate = device->PHYRxRate;
    event.TxPowerControlReduction = device->TxPowerControlReduction;
    event.RxPowerLevel = device->RxPowerLevel;
    event.TxBcastRate = device->TxBcastRate;
    event.RxBcastPowerLevel = device->RxBcastPowerLevel;
    event.TxPackets = device->TxPackets;
    event.RxPackets = device->RxPackets;
    event.RxErroredAndMissedPackets = device->RxErroredAndMissedPackets;
    event.QAM256Capable = device->QAM256Capable;
    event.PacketAggregationCapability = device->PacketAggregationCapability;
    event.RxSNR = device->RxSNR;
    event.Active = device->Active;
    event.RxBcastRate = device->RxBcastRate;
    event.NumberOfClients = device->NumberOfClients;
    if ((!event.Active && !stored->Active) ||
        memcmp(stored, &event, sizeof(event)) == 0)
    {
        return STATUS_SUCCESS;
    }
    before = link_status(state);
    if (event.Active)
    {
        *stored = event;
    }
    else
    {
        /* Deactivation reports the retained identity, not arbitrary caller
         * fields accompanying a removal request. */
        event = *stored;
        event.Active = FALSE;
        memset(stored, 0, sizeof(*stored));
    }
    clear_aca(state);
    if (before != link_status(state))
    {
        state->last_change = state->now;
        state->link_since = state->now;
    }
    callback = associated_callback;
    if (callback != NULL)
    {
        (void)callback(ifIndex, &event);
    }
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return the test-only PNC view of a local or active peer node. */
INT moca_test_get_pnc(ULONG ifIndex, ULONG nodeID, moca_assoc_pnc_info_t *info)
{
    model_interface_t *state = get_state(ifIndex);
    moca_assoc_pnc_info_t result = {0};
    const char *version;
    if (state == NULL || info == NULL || !hardware_equipped ||
        !state->config.bEnabled || !present_node(state, nodeID))
    {
        return STATUS_FAILURE;
    }
    result.mocaNodeIndex = nodeID;
    result.mocaNodePreferredNC = nodeID == 0 ? state->config.bPreferredNC
                                           : state->peers[nodeID].PreferredNC;
    version = nodeID == 0 ? "2.0" : state->peers[nodeID].HighestVersion;
    result.mocaNodeMocaversion = strcmp(version, "2.0") == 0 ? 20 :
                                strcmp(version, "1.1") == 0 ? 11 :
                                strcmp(version, "1.0") == 0 ? 10 : 0;
    *info = result;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Retain/replace the process callback; NULL explicitly unregisters in Linux. */
void moca_associatedDevice_callback_register(moca_associatedDevice_callback callback_proc)
{
    associated_callback = callback_proc;
}

/* PUBLIC_INTERFACE */
/** Copy the selected interface's configuration into caller storage, or fail. */
INT moca_GetIfConfig(ULONG ifIndex, moca_cfg_t *pmoca_config)
{
    model_interface_t *state = get_state(ifIndex);
    if (state == NULL || pmoca_config == NULL ||
        !available(state, MOCA_TEST_GET_CONFIG))
    {
        return STATUS_FAILURE;
    }
    *pmoca_config = state->config;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Atomically copy valid config, or restore interface defaults on Reset=TRUE. */
INT moca_SetIfConfig(ULONG ifIndex, moca_cfg_t *pmoca_config)
{
    model_interface_t *state = get_state(ifIndex);
    moca_if_status_t before;
    uint64_t old_bits;
    uint64_t new_bits;
    if (state == NULL || !valid_config(ifIndex, pmoca_config) ||
        !available(state, MOCA_TEST_SET_CONFIG))
    {
        return STATUS_FAILURE;
    }
    if (pmoca_config->Reset)
    {
        /* Reset must not discard failures armed for other operations. */
        BOOL failures[MOCA_TEST_API_COUNT];
        memcpy(failures, state->fail_next, sizeof(failures));
        initialize(ifIndex, state, state->now);
        memcpy(state->fail_next, failures, sizeof(failures));
        reset_count = saturated_add(reset_count, 1);
        return STATUS_SUCCESS;
    }
    before = link_status(state);
    (void)decode_mask(state->config.FreqCurrentMaskSetting, &old_bits);
    (void)decode_mask(pmoca_config->FreqCurrentMaskSetting, &new_bits);
    if (new_bits != old_bits)
    {
        state->last_frequency = mask_frequency(old_bits);
    }
    state->config = *pmoca_config;
    if (!state->config.bEnabled)
    {
        clear_aca(state);
    }
    if (before != link_status(state))
    {
        state->last_change = state->now;
        state->link_since = state->now;
    }
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Populate a coherent logical-time link snapshot; never use the wall clock. */
INT moca_IfGetDynamicInfo(ULONG ifIndex, moca_dynamic_info_t *pmoca_dynamic_info)
{
    model_interface_t *state = get_state(ifIndex);
    moca_dynamic_info_t result = {0};
    uint64_t bits;
    UCHAR mac[6 + MAC_PADDING];
    unsigned int i;
    if (state == NULL || pmoca_dynamic_info == NULL ||
        !available(state, MOCA_TEST_GET_DYNAMIC))
    {
        return STATUS_FAILURE;
    }
    result.Status = link_status(state);
    result.LastChange = state->last_change;
    result.MaxIngressBW = state->config.bEnabled ? 900000000UL : 0;
    result.MaxEgressBW = state->config.bEnabled ? 800000000UL : 0;
    memcpy(result.CurrentVersion, "2.0", 4);
    result.NetworkCoordinator = 0;
    result.NodeID = 0;
    for (i = 1; i < MOCA_TEST_ASSOC_CAPACITY; ++i)
    {
        if (state->config.bEnabled && state->peers[i].Active)
        {
            result.BackupNC = i;
            break;
        }
    }
    result.PrivacyEnabled = state->config.bEnabled &&
                            state->config.PrivacyEnabledSetting;
    (void)decode_mask(state->config.FreqCurrentMaskSetting, &bits);
    for (i = 0; i < sizeof(result.FreqCurrentMask); ++i)
    {
        result.FreqCurrentMask[i] = state->config.bEnabled ?
                                   (UCHAR)(bits >> (8U * i)) : 0;
    }
    result.CurrentOperFreq = state->config.bEnabled ? mask_frequency(bits) : 0;
    result.LastOperFreq = state->last_frequency;
    result.TxBcastRate = state->config.bEnabled ? 500 : 0;
    result.MaxIngressBWThresholdReached = state->config.bEnabled &&
        result.MaxIngressBW >= state->config.MaxIngressBWThreshold;
    result.MaxEgressBWThresholdReached = state->config.bEnabled &&
        result.MaxEgressBW >= state->config.MaxEgressBWThreshold;
    result.NumberOfConnectedClients = peer_count(state);
    make_mac(ifIndex, 0, mac);
    format_mac(mac, result.NetworkCoordinatorMACAddress,
               sizeof(result.NetworkCoordinatorMACAddress));
    result.LinkUpTime = result.Status == IF_STATUS_Up ?
                        state->now - state->link_since : 0;
    *pmoca_dynamic_info = result;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Populate synthetic interface identity/capabilities in caller storage. */
INT moca_IfGetStaticInfo(ULONG ifIndex, moca_static_info_t *pmoca_static_info)
{
    model_interface_t *state = get_state(ifIndex);
    moca_static_info_t result = {0};
    if (state == NULL || pmoca_static_info == NULL ||
        !available(state, MOCA_TEST_GET_STATIC))
    {
        return STATUS_FAILURE;
    }
    (void)snprintf(result.Name, sizeof(result.Name), "moca%lu", ifIndex);
    make_mac(ifIndex, 0, result.MacAddress);
    memcpy(result.FirmwareVersion, "linux-reference-1.0", 20);
    result.MaxBitRate = 1000;
    memcpy(result.HighestVersion, "2.0", 4);
    memset(result.FreqCapabilityMask, 0xff, sizeof(result.FreqCapabilityMask));
    memcpy(result.NetworkTabooMask, state->config.NodeTabooMask,
           sizeof(result.NetworkTabooMask));
    result.TxBcastPowerReduction = 3;
    result.QAM256Capable = TRUE;
    result.PacketAggregationCapability = TRUE;
    *pmoca_static_info = result;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Populate every field of the deterministic seeded traffic-counter snapshot. */
INT moca_IfGetStats(ULONG ifIndex, moca_stats_t *pmoca_stats)
{
    model_interface_t *state = get_state(ifIndex);
    const moca_stats_t result = {
        .BytesSent = 100000, .BytesReceived = 200000,
        .PacketsSent = 100, .PacketsReceived = 200,
        .ErrorsSent = 1, .ErrorsReceived = 2,
        .UnicastPacketsSent = 70, .UnicastPacketsReceived = 140,
        .DiscardPacketsSent = 3, .DiscardPacketsReceived = 4,
        .MulticastPacketsSent = 20, .MulticastPacketsReceived = 40,
        .BroadcastPacketsSent = 10, .BroadcastPacketsReceived = 20,
        .UnknownProtoPacketsReceived = 5, .ExtAggrAverageTx = 4,
        .ExtAggrAverageRx = 5
    };
    if (state == NULL || pmoca_stats == NULL ||
        !available(state, MOCA_TEST_GET_STATS))
    {
        return STATUS_FAILURE;
    }
    *pmoca_stats = result;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return the number of visible active peers, excluding local node zero. */
INT moca_GetNumAssociatedDevices(ULONG ifIndex, ULONG *pulCount)
{
    model_interface_t *state = get_state(ifIndex);
    if (state == NULL || pulCount == NULL ||
        !available(state, MOCA_TEST_GET_NUM_DEVICES))
    {
        return STATUS_FAILURE;
    }
    *pulCount = peer_count(state);
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Populate all six deterministic MAC-layer counters without clear-on-read. */
INT moca_IfGetExtCounter(ULONG ifIndex, moca_mac_counters_t *pmoca_mac_counters)
{
    model_interface_t *state = get_state(ifIndex);
    const moca_mac_counters_t result = {
        .Map = 10, .Rsrv = 20, .Lc = 30, .Adm = 40, .Probe = 50, .Async = 60
    };
    if (state == NULL || pmoca_mac_counters == NULL ||
        !available(state, MOCA_TEST_GET_MAC_COUNTERS))
    {
        return STATUS_FAILURE;
    }
    *pmoca_mac_counters = result;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Populate the deterministic Tx/Rx PDU counter snapshot in caller storage. */
INT moca_IfGetExtAggrCounter(ULONG ifIndex, moca_aggregate_counters_t *pmoca_aggregate_counts)
{
    model_interface_t *state = get_state(ifIndex);
    const moca_aggregate_counters_t result = {.Tx = 100, .Rx = 200};
    if (state == NULL || pmoca_aggregate_counts == NULL ||
        !available(state, MOCA_TEST_GET_AGGR_COUNTERS))
    {
        return STATUS_FAILURE;
    }
    *pmoca_aggregate_counts = result;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Write active peer MACs to a caller-owned 256-entry CPE array and OUT count. */
INT moca_GetMocaCPEs(ULONG ifIndex, moca_cpe_t *cpes, INT *pnum_cpes)
{
    model_interface_t *state = get_state(ifIndex);
    ULONG node;
    INT count = 0;
    if (state == NULL || cpes == NULL || pnum_cpes == NULL ||
        !available(state, MOCA_TEST_GET_CPES))
    {
        return STATUS_FAILURE;
    }
    for (node = 1; state->config.bEnabled && node < MOCA_TEST_ASSOC_CAPACITY; ++node)
    {
        if (state->peers[node].Active)
        {
            memcpy(cpes[count++].mac_addr, state->peers[node].MACAddress, 6);
        }
    }
    *pnum_cpes = count;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy peers into caller backing storage; never replace or retain *array. */
INT moca_GetAssociatedDevices(ULONG ifIndex, moca_associated_device_t **ppdevice_array)
{
    model_interface_t *state = get_state(ifIndex);
    ULONG node;
    ULONG count = 0;
    if (state == NULL || ppdevice_array == NULL || *ppdevice_array == NULL ||
        !available(state, MOCA_TEST_GET_DEVICES))
    {
        return STATUS_FAILURE;
    }
    for (node = 1; state->config.bEnabled && node < MOCA_TEST_ASSOC_CAPACITY; ++node)
    {
        if (state->peers[node].Active)
        {
            (*ppdevice_array)[count++] = state->peers[node];
        }
    }
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Convert a sixteen-byte ASCII hex mask to the lowest selected MHz, or -1. */
INT moca_FreqMaskToValue(UCHAR *mask)
{
    uint64_t bits;
    if (!decode_mask(mask, &bits) || bits == 0 ||
        !no_failure(get_state(0), MOCA_TEST_FREQ_VALUE))
    {
        return STATUS_FAILURE;
    }
    return (INT)mask_frequency(bits);
}

/* PUBLIC_INTERFACE */
/** Return deterministic presence, with optional one-shot FALSE injection. */
BOOL moca_HardwareEquipped(void)
{
    return available(get_state(0), MOCA_TEST_HARDWARE) ? TRUE : FALSE;
}

/* PUBLIC_INTERFACE */
/** Write all directed, non-self active node pairs to caller-owned mesh storage. */
INT moca_GetFullMeshRates(ULONG ifIndex, moca_mesh_table_t *pDeviceArray, ULONG *pulCount)
{
    model_interface_t *state = get_state(ifIndex);
    ULONG tx;
    ULONG rx;
    ULONG count = 0;
    if (state == NULL || pDeviceArray == NULL || pulCount == NULL ||
        !available(state, MOCA_TEST_GET_MESH))
    {
        return STATUS_FAILURE;
    }
    for (tx = 0; state->config.bEnabled && tx < kMoca_MaxMocaNodes; ++tx)
    {
        for (rx = 0; rx < kMoca_MaxMocaNodes; ++rx)
        {
            if (tx != rx && present_node(state, tx) && present_node(state, rx))
            {
                moca_mesh_table_t entry = {0};
                entry.RxNodeID = rx;
                entry.TxNodeID = tx;
                entry.TxRate = tx == 0 ? state->peers[rx].PHYTxRate :
                                        state->peers[tx].PHYRxRate;
                entry.TxRateNper = entry.TxRate;
                entry.TxRateVlper = (entry.TxRate / 10) * 9 +
                                    (entry.TxRate % 10) * 9 / 10;
                pDeviceArray[count++] = entry;
            }
        }
    }
    *pulCount = count;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Write one synthetic local-to-peer flow per active peer, with an OUT count. */
INT moca_GetFlowStatistics(ULONG ifIndex, moca_flow_table_t *pDeviceArray, ULONG *pulCount)
{
    model_interface_t *state = get_state(ifIndex);
    ULONG node;
    ULONG count = 0;
    if (state == NULL || pDeviceArray == NULL || pulCount == NULL ||
        !available(state, MOCA_TEST_GET_FLOWS))
    {
        return STATUS_FAILURE;
    }
    for (node = 1; state->config.bEnabled && node < MOCA_TEST_ASSOC_CAPACITY; ++node)
    {
        if (state->peers[node].Active)
        {
            moca_flow_table_t entry = {0};
            entry.FlowID = node;
            entry.IngressNodeID = 0;
            entry.EgressNodeID = node;
            entry.FlowTimeLeft = 300;
            format_mac(state->peers[node].MACAddress, entry.DestinationMACAddress,
                       sizeof(entry.DestinationMACAddress));
            entry.PacketSize = 4;
            entry.PeakDataRate = 100000000UL;
            entry.BurstSize = 4096;
            entry.FlowTag = node;
            entry.LeaseTime = 300;
            pDeviceArray[count++] = entry;
        }
    }
    *pulCount = count;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy the global reset count; all errors preserve the caller's value. */
INT moca_GetResetCount(ULONG *resetcnt)
{
    if (resetcnt == NULL || !available(get_state(0), MOCA_TEST_GET_RESET_COUNT))
    {
        return STATUS_FAILURE;
    }
    *resetcnt = reset_count;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Validate/copy ACA config by value; start if requested, reject any overlap. */
int moca_setIfAcaConfig(int interfaceIndex, moca_aca_cfg_t acaCfg)
{
    model_interface_t *state;
    unsigned int node;
    if (!valid_signed_index(interfaceIndex))
    {
        return STATUS_FAILURE;
    }
    state = get_state((ULONG)interfaceIndex);
    if (!boolean(acaCfg.ACAStart) ||
        (acaCfg.Type != PROBE_QUITE && acaCfg.Type != PROBE_EVM) ||
        acaCfg.Channel > 1 || !present_node(state, acaCfg.NodeID) ||
        acaCfg.ReportNodes == 0 || (acaCfg.ReportNodes & ~0xffffU) != 0 ||
        (acaCfg.ACAStart && !state->config.bEnabled))
    {
        return STATUS_FAILURE;
    }
    for (node = 0; node < kMoca_MaxMocaNodes; ++node)
    {
        if ((acaCfg.ReportNodes & (1U << node)) && !present_node(state, node))
        {
            return STATUS_FAILURE;
        }
    }
    if (state->aca.stat == MOCA_TEST_ACA_RUNNING)
    {
        return STATUS_INPROGRESS;
    }
    if (!available(state, MOCA_TEST_SET_ACA))
    {
        return STATUS_FAILURE;
    }
    clear_aca(state);
    state->aca.acaCfg = acaCfg;
    if (acaCfg.ACAStart)
    {
        state->aca.stat = MOCA_TEST_ACA_RUNNING;
        state->polls_left = MOCA_TEST_ACA_POLLS;
    }
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy the retained ACA configuration to caller storage, or fail unchanged. */
int moca_getIfAcaConfig(int interfaceIndex, moca_aca_cfg_t *acaCfg)
{
    model_interface_t *state;
    if (!valid_signed_index(interfaceIndex) || acaCfg == NULL)
    {
        return STATUS_FAILURE;
    }
    state = get_state((ULONG)interfaceIndex);
    if (!available(state, MOCA_TEST_GET_ACA_CONFIG))
    {
        return STATUS_FAILURE;
    }
    *acaCfg = state->aca.acaCfg;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Cancel ACA and clear old results; succeed idempotently when already idle. */
int moca_cancelIfAca(int interfaceIndex)
{
    model_interface_t *state;
    if (!valid_signed_index(interfaceIndex))
    {
        return STATUS_FAILURE;
    }
    state = get_state((ULONG)interfaceIndex);
    if (!available(state, MOCA_TEST_CANCEL_ACA))
    {
        return STATUS_FAILURE;
    }
    clear_aca(state);
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return ACA state/results; only successful reads advance deterministic polls. */
int moca_getIfAcaStatus(int interfaceIndex, moca_aca_stat_t *pacaStat)
{
    model_interface_t *state;
    if (!valid_signed_index(interfaceIndex) || pacaStat == NULL)
    {
        return STATUS_FAILURE;
    }
    state = get_state((ULONG)interfaceIndex);
    if (!available(state, MOCA_TEST_GET_ACA_STATUS))
    {
        return STATUS_FAILURE;
    }
    if (state->aca.stat == MOCA_TEST_ACA_RUNNING)
    {
        if (state->polls_left == 0)
        {
            complete_aca(state);
        }
        else
        {
            --state->polls_left;
        }
    }
    *pacaStat = state->aca;
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Write completed per-report-node SCMOD into caller storage, preserving pointers. */
int moca_getIfScmod(int interfaceIndex, int *pnumOfEntries, moca_scmod_stat_t **ppscmodStat)
{
    model_interface_t *state;
    unsigned int node;
    unsigned int carrier;
    int count = 0;
    if (!valid_signed_index(interfaceIndex) || pnumOfEntries == NULL ||
        ppscmodStat == NULL || *ppscmodStat == NULL)
    {
        return STATUS_FAILURE;
    }
    state = get_state((ULONG)interfaceIndex);
    if (!state->aca.ACATrapCompleted || !available(state, MOCA_TEST_GET_SCMOD))
    {
        return STATUS_FAILURE;
    }
    for (node = 0; node < kMoca_MaxMocaNodes; ++node)
    {
        if (state->aca.acaCfg.ReportNodes & (1U << node))
        {
            moca_scmod_stat_t entry = {0};
            entry.TxNode = (INT)state->aca.acaCfg.NodeID;
            entry.RxNode = (INT)node;
            entry.Channel = (INT)state->aca.acaCfg.Channel;
            for (carrier = 0; carrier < 512; ++carrier)
            {
                entry.Mod[carrier] = (UCHAR)(carrier % 9);
                entry.Nper[carrier] = (UCHAR)(carrier % 7);
                entry.Vlper[carrier] = (UCHAR)(carrier % 5);
            }
            (*ppscmodStat)[count++] = entry;
        }
    }
    *pnumOfEntries = count;
    return STATUS_SUCCESS;
}
