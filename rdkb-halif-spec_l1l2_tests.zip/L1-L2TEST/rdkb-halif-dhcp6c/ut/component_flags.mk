# Read by recursive make through MAKEFILES; never changes framework recipes.
# TOP_DIR and BUILD_DIR are exported by the component's Makefile.
# Pattern-specific overrides append after caller flags, even with CFLAGS set.
$(BUILD_DIR)/src/%.o $(BUILD_DIR)/skeletons/src/%.o: override XCFLAGS += -Wall -Wextra -Werror

# Existing objects must not bypass a new/updated strict-warning policy.
dhcp6c_component_sources := $(wildcard $(TOP_DIR)/src/*.c $(TOP_DIR)/skeletons/src/*.c)
dhcp6c_component_objects := $(patsubst $(TOP_DIR)/%.c,$(BUILD_DIR)/%.o,$(dhcp6c_component_sources))
$(dhcp6c_component_objects): $(TOP_DIR)/Makefile $(TOP_DIR)/component_flags.mk

# ut-core locates itself via firstword(MAKEFILE_LIST). This early-loaded policy
# is not its entry makefile; remove only our own bookkeeping entry.
MAKEFILE_LIST := $(filter-out $(TOP_DIR)/component_flags.mk,$(MAKEFILE_LIST))
