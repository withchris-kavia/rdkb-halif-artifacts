#!/usr/bin/env bash

# *
# * If not stated otherwise in this file or this component's LICENSE file the
# * following copyright and licenses apply:
# *
# * Copyright 2023 RDK Management
# *
# * Licensed under the Apache License, Version 2.0 (the "License");
# * you may not use this file except in compliance with the License.
# * You may obtain a copy of the License at
# *
# * http://www.apache.org/licenses/LICENSE-2.0
# *
# * Unless required by applicable law or agreed to in writing, software
# * distributed under the License is distributed on an "AS IS" BASIS,
# * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# * See the License for the specific language governing permissions and
# * limitations under the License.
# *

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || exit 1
cd -- "$SCRIPT_DIR" || exit 1

# Stay within the compatible major version unless the caller pins a revision.
UT_PROJECT_MAJOR_VERSION="3."
TEST_REPO=git@github.com:rdkcentral/ut-core.git

# PUBLIC_INTERFACE
# Select a compatible local tag when UT_CORE_PROJECT_VERSION is empty.
# Return nonzero if tag discovery fails or no compatible revision is available.
check_next_revision()
{
    local revisions latest
    if [[ -z "${UT_CORE_PROJECT_VERSION:-}" ]]; then
        revisions=$(git -C ./ut-core tag --list "${UT_PROJECT_MAJOR_VERSION}*" --sort=-v:refname) || return $?
        UT_CORE_PROJECT_VERSION=${revisions%%$'\n'*}
        if [[ -z "$UT_CORE_PROJECT_VERSION" ]]; then
            echo "build.sh: no compatible ut-core tag; set UT_CORE_PROJECT_VERSION" >&2
            return 1
        fi
        revisions=$(git -C ./ut-core tag --list --sort=-v:refname) || return $?
        latest=${revisions%%$'\n'*}
        if [[ "$latest" != "$UT_CORE_PROJECT_VERSION" ]]; then
            printf 'New ut-core revision [%s] available; using compatible [%s]\n' \
                "$latest" "$UT_CORE_PROJECT_VERSION"
        fi
    fi
    printf 'ut-core version selected: [%s]\n' "$UT_CORE_PROJECT_VERSION"
}

if [[ ! -d ./ut-core ]]; then
    echo "Cloning unit test core system"
    git clone -- "$TEST_REPO" ut-core || exit $?
    check_next_revision || exit $?
    git -C ./ut-core checkout "$UT_CORE_PROJECT_VERSION" || exit $?
    (
        cd -- ./ut-core || exit 1
        bash ./build.sh "$@"
    ) || exit $?
fi

# Existing checkouts are never switched implicitly.
exec make -C "$SCRIPT_DIR" -f Makefile "$@"
