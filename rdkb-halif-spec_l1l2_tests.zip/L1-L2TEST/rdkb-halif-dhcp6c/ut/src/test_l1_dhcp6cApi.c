/*
 * If not stated otherwise in this file or this component's LICENSE file the
 * following copyright and licenses apply:
 * Copyright 2023 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file test_l1_dhcp6cApi.c
 * @brief Native L1 getter, NULL-argument and public-capacity checks.
 *
 * Expected interface names come from the required KVP profile. Linux builds
 * reset the reference fixture around every case; vendor builds do not import
 * model controls. Exact frozen snapshot contents are exercised in L2.
 */
#include <stddef.h>
#include <string.h>
#include <ut.h>
#include <ut_log.h>
#include <ut_kvp_profile.h>
#include "dhcp6cApi.h"

#ifdef BUILD_LINUX
#include "dhcp6c_test_model.h"
#endif

#define STATUS_SUCCESS 0
#define STATUS_FAILURE (-1)

typedef int (*dhcp6c_getter_t)(dhcp6cInfo_t *information);

/* A binary IPv6 address has no string syntax to validate. Every unsigned-char
 * value is legal, including 00 and FF; validate only the pointer and width. */
static int ValdtIpV6(const unsigned char *Ipv6, size_t elmnt)
{
    return Ipv6 != NULL && elmnt == IPV6_ADDR_SIZE;
}

/* Call only after separately proving that a fixed-width name is terminated. */
static int null_check(const char *string_data)
{
    return string_data != NULL && string_data[0] != '\0';
}

static int valid_dns_count(int count)
{
    return count >= 0 && count <= MAX_IPV6_ADDR_LIST_SIZE;
}

#ifdef BUILD_LINUX
static int reset_model_suite(void)
{
    dhcp6c_test_model_reset();
    return 0;
}
#endif

static void check_successful_getter(dhcp6c_getter_t getter, const char *profile_key)
{
    dhcp6cInfo_t information;
    char expected_name[sizeof(information.ifname)] = {0};
    ut_kvp_status_t profile_status;
    int status;
    int index;

    memset(&information, 0xa5, sizeof(information));
    status = getter(&information);
    /* A failing getter need not have populated any part of the output. */
    UT_ASSERT_EQUAL_FATAL(status, STATUS_SUCCESS);

    UT_ASSERT_FATAL(memchr(information.ifname, '\0',
                           sizeof(information.ifname)) != NULL);
    UT_ASSERT_FATAL(null_check(information.ifname));

    profile_status = ut_kvp_getStringField(ut_kvp_profile_getInstance(),
                                           profile_key, expected_name,
                                           sizeof(expected_name));
    UT_ASSERT_EQUAL_FATAL(profile_status, UT_KVP_STATUS_SUCCESS);
    /* The framework reader can return success after strncpy truncation. Do not
     * add a terminator here: that would silently accept an overlong profile. */
    UT_ASSERT_MSG_FATAL(memchr(expected_name, '\0', sizeof(expected_name)) != NULL,
                        "Profile interface name exceeds the HAL capacity");
    UT_ASSERT_FATAL(null_check(expected_name));
    UT_ASSERT_STRING_EQUAL(information.ifname, expected_name);

    UT_ASSERT(information.smState >= 0);
    UT_ASSERT(information.configAttemps >= 0);
    UT_ASSERT(ValdtIpV6(information.ipAddr, sizeof(information.ipAddr)));
    UT_ASSERT(ValdtIpV6(information.prefix, sizeof(information.prefix)));
    UT_ASSERT(ValdtIpV6(information.gw, sizeof(information.gw)));
    UT_ASSERT(ValdtIpV6(information.dhcpServer, sizeof(information.dhcpServer)));

    /* Reject both negative and excessive counts before using a count as a
     * bound. Unused DNS slots have no generic vendor-side validity policy. */
    UT_ASSERT_FATAL(valid_dns_count(information.numOfDns));
    for (index = 0; index < information.numOfDns; ++index)
    {
        UT_ASSERT(ValdtIpV6(information.dnsAddrList[index],
                           sizeof(information.dnsAddrList[index])));
    }
}

/* PUBLIC_INTERFACE */
/** Verify successful E-Router retrieval against the configured interface name. */
void test_l1_dhcp6cApi_positive1_ert_dhcp6c_get_info(void)
{
    check_successful_getter(ert_dhcp6c_get_info,
                           "dhcp6c/config/ERouter_DHCPv6/ifName");
}

/* PUBLIC_INTERFACE */
/** Verify that E-Router retrieval rejects a NULL output pointer. */
void test_l1_dhcp6cApi_negative1_ert_dhcp6c_get_info(void)
{
    int status = ert_dhcp6c_get_info(NULL);

    UT_ASSERT_EQUAL(status, STATUS_FAILURE);
}

/* PUBLIC_INTERFACE */
/** Verify successful ECM retrieval against the configured interface name. */
void test_l1_dhcp6cApi_positive_1_ecm_dhcp6c_get_info(void)
{
    check_successful_getter(ecm_dhcp6c_get_info,
                           "dhcp6c/config/ecm_DHCPv6/ifName");
}

/* PUBLIC_INTERFACE */
/** Verify that ECM retrieval rejects a NULL output pointer. */
void test_l1_dhcp6cApi_negative_1_ecm_dhcp6c_get_info(void)
{
    int status = ecm_dhcp6c_get_info(NULL);

    UT_ASSERT_EQUAL(status, STATUS_FAILURE);
}

/** Exercise short-circuit safety and both sides of every helper bound. */
static void test_l1_validation_helper_boundaries(void)
{
    unsigned char address[IPV6_ADDR_SIZE] = {0};

    UT_ASSERT(!ValdtIpV6(NULL, IPV6_ADDR_SIZE));
    UT_ASSERT(!ValdtIpV6(NULL, 0));
    UT_ASSERT(!ValdtIpV6(address, 0));
    UT_ASSERT(!ValdtIpV6(address, IPV6_ADDR_SIZE - 1));
    UT_ASSERT(!ValdtIpV6(address, IPV6_ADDR_SIZE + 1));
    UT_ASSERT(ValdtIpV6(address, sizeof(address)));
    memset(address, 0xff, sizeof(address));
    UT_ASSERT(ValdtIpV6(address, sizeof(address)));

    UT_ASSERT(!null_check(NULL));
    UT_ASSERT(!null_check(""));
    UT_ASSERT(null_check("interface"));
    UT_ASSERT(!valid_dns_count(-1));
    UT_ASSERT(valid_dns_count(0));
    UT_ASSERT(valid_dns_count(1));
    UT_ASSERT(valid_dns_count(2));
    UT_ASSERT(valid_dns_count(3));
    UT_ASSERT(!valid_dns_count(MAX_IPV6_ADDR_LIST_SIZE + 1));
}

/** Pin the public address width and list capacity, not platform struct padding. */
static void test_l1_public_capacity_constants(void)
{
    dhcp6cInfo_t information;

    UT_ASSERT_EQUAL(IPV6_ADDR_SIZE, 16);
    UT_ASSERT_EQUAL(MAX_IPV6_ADDR_LIST_SIZE, 3);
    UT_ASSERT_EQUAL(sizeof(information.ifname), 32U);
    UT_ASSERT_EQUAL(sizeof(information.ipAddr), 16U);
    UT_ASSERT_EQUAL(sizeof(information.prefix), 16U);
    UT_ASSERT_EQUAL(sizeof(information.gw), 16U);
    UT_ASSERT_EQUAL(sizeof(information.dhcpServer), 16U);
    UT_ASSERT_EQUAL(sizeof(information.dnsAddrList[0]), 16U);
    UT_ASSERT_EQUAL(sizeof(information.dnsAddrList) /
                    sizeof(information.dnsAddrList[0]), 3U);
    UT_ASSERT_EQUAL(sizeof(information.dnsAddrList), 48U);
}

/* PUBLIC_INTERFACE */
/** Register all native L1 cases in UT_TESTS_L1; return 0 or -1 on failure. */
int register_hal_tests(void)
{
    UT_test_suite_t *suite;

#ifdef BUILD_LINUX
    suite = UT_add_suite_withGroupID("[L1 dhcp6cApi]", reset_model_suite,
                                     reset_model_suite, UT_TESTS_L1);
#else
    suite = UT_add_suite_withGroupID("[L1 dhcp6cApi]", NULL, NULL, UT_TESTS_L1);
#endif
    if (suite == NULL)
    {
        return -1;
    }

#ifdef BUILD_LINUX
    /* UT's grouping API exposes only suite callbacks. Use CUnit's public
     * per-test hooks on the returned suite, without modifying the framework.
     * TearDown still runs when a fatal assertion terminates a test. */
    ((CU_pSuite)suite)->pSetUpFunc = dhcp6c_test_model_reset;
    ((CU_pSuite)suite)->pTearDownFunc = dhcp6c_test_model_reset;
#endif

    if (UT_add_test(suite, "l1_dhcp6cApi_positive1_ert_dhcp6c_get_info",
                    test_l1_dhcp6cApi_positive1_ert_dhcp6c_get_info) == NULL ||
        UT_add_test(suite, "l1_dhcp6cApi_negative1_ert_dhcp6c_get_info",
                    test_l1_dhcp6cApi_negative1_ert_dhcp6c_get_info) == NULL ||
        UT_add_test(suite, "l1_dhcp6cApi_positive_1_ecm_dhcp6c_get_info",
                    test_l1_dhcp6cApi_positive_1_ecm_dhcp6c_get_info) == NULL ||
        UT_add_test(suite, "l1_dhcp6cApi_negative_1_ecm_dhcp6c_get_info",
                    test_l1_dhcp6cApi_negative_1_ecm_dhcp6c_get_info) == NULL ||
        UT_add_test(suite, "l1_validation_helper_boundaries",
                    test_l1_validation_helper_boundaries) == NULL ||
        UT_add_test(suite, "l1_public_capacity_constants",
                    test_l1_public_capacity_constants) == NULL)
    {
        return -1;
    }
    return 0;
}
