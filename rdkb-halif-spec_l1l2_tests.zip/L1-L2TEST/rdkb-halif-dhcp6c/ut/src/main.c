/*
* If not stated otherwise in this file or this component's LICENSE file the
* following copyright and licenses apply:*
* Copyright 2023 RDK Management
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include <ut.h>
#include <ut_kvp_profile.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

extern int register_hal_l1_tests(void);
/* Scope 4 supplies this registrar; do not invent an empty passing L2 suite. */
extern int register_hal_l2_tests(void) __attribute__((weak));
extern void __real_CU_cleanup_registry(void);
extern UT_test_suite_t *__real_UT_add_suite(
    const char *title, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup);
extern UT_test_suite_t *__real_UT_add_suite_withGroupID(
    const char *title, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup,
    UT_groupID_t group);

static bool registration_failed;
static bool capturing_results;
static bool results_captured;
static bool execution_failed;
static unsigned int tests_run;
static ut_kvp_instance_t *profile;
static bool profile_failed;

/* PUBLIC_INTERFACE */
/**
 * Open filename as the single required DHCP6C YAML/JSON profile.
 * Return a KVP status instead of triggering ut-core's profile-load assertions.
 */
ut_kvp_status_t __wrap_ut_kvp_profile_open(char *filename)
{
    static const char *keys[] = {
        "dhcp6c/config/ERouter_DHCPv6/ifName",
        "dhcp6c/config/ecm_DHCPv6/ifName"
    };
    ut_kvp_status_t status;
    size_t index;

    if (profile != NULL || profile_failed)
    {
        profile_failed = true;
        return UT_KVP_STATUS_INVALID_PARAM;
    }
    profile = ut_kvp_createInstance();
    if (profile == NULL)
    {
        profile_failed = true;
        return UT_KVP_STATUS_INVALID_INSTANCE;
    }
    status = ut_kvp_open(profile, filename);
    if (status == UT_KVP_STATUS_SUCCESS)
    {
        for (index = 0; index < sizeof(keys) / sizeof(keys[0]); ++index)
        {
            /* The HAL's interface name includes its terminator in 32 bytes. */
            char name[32] = {0};

            status = ut_kvp_getStringField(profile, keys[index], name, sizeof(name));
            if (status != UT_KVP_STATUS_SUCCESS || name[0] == '\0' ||
                memchr(name, '\0', sizeof(name)) == NULL)
            {
                status = UT_KVP_STATUS_INVALID_PARAM;
                break;
            }
        }
    }
    if (status != UT_KVP_STATUS_SUCCESS)
    {
        profile_failed = true;
        fprintf(stderr, "dhcp6c_hal_test: invalid profile [%s] (status %d)\n",
                filename != NULL ? filename : "(null)", (int)status);
    }
    return status;
}

/* PUBLIC_INTERFACE */
/** Return the component-owned profile handle used by the registered tests. */
ut_kvp_instance_t *__wrap_ut_kvp_profile_getInstance(void)
{
    return profile;
}

/* PUBLIC_INTERFACE */
/** Release the component-owned profile, allowing repeated framework cleanup. */
void __wrap_ut_kvp_profile_close(void)
{
    if (profile != NULL)
    {
        ut_kvp_destroyInstance(profile);
        profile = NULL;
    }
}

/* PUBLIC_INTERFACE */
/**
 * Forward title and lifecycle callbacks to UT_add_suite, returning its handle.
 * Preserve a registration failure even if a later CUnit call clears the error.
 */
UT_test_suite_t *__wrap_UT_add_suite(
    const char *title, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup)
{
    UT_test_suite_t *suite = __real_UT_add_suite(title, init, cleanup);

    if (suite == NULL || CU_get_error() != CUE_SUCCESS)
    {
        registration_failed = true;
    }
    return suite;
}

/* PUBLIC_INTERFACE */
/**
 * Forward title, lifecycle callbacks and group to UT_add_suite_withGroupID.
 * Return the suite handle and retain any registration failure for main.
 */
UT_test_suite_t *__wrap_UT_add_suite_withGroupID(
    const char *title, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup,
    UT_groupID_t group)
{
    UT_test_suite_t *suite =
        __real_UT_add_suite_withGroupID(title, init, cleanup, group);

    if (suite == NULL || CU_get_error() != CUE_SUCCESS)
    {
        registration_failed = true;
    }
    return suite;
}

/* PUBLIC_INTERFACE */
/**
 * Register function under title in suite, returning its handle or NULL.
 * Avoid ut-core's assert on registration failure so main can report an error.
 */
UT_test_t *__wrap_UT_add_test(UT_test_suite_t *suite, const char *title,
                            UT_TestFunction_t function)
{
    CU_pTest test = CU_add_test((CU_pSuite)suite, title, function);

    if (test == NULL || CU_get_error() != CUE_SUCCESS)
    {
        registration_failed = true;
    }
    return (UT_test_t *)test;
}

/* PUBLIC_INTERFACE */
/**
 * Capture CUnit results before registry cleanup resets them, then delegate.
 * This linker hook takes no parameters and returns no value.
 */
void __wrap_CU_cleanup_registry(void)
{
    if (capturing_results)
    {
        const CU_RunSummary *summary = CU_get_run_summary();
        CU_ErrorCode error = CU_get_error();

        results_captured = true;
        execution_failed = execution_failed || error != CUE_SUCCESS;
        if (summary == NULL)
        {
            execution_failed = true;
        }
        else
        {
            tests_run += summary->nTestsRun;
            execution_failed = execution_failed || summary->nTestsFailed != 0U ||
                summary->nAssertsFailed != 0U || summary->nSuitesFailed != 0U ||
                summary->nFailureRecords != 0U;
            fprintf(stderr,
                    "DHCP6C_RESULT tests=%u failed_tests=%u failed_assertions=%u "
                    "failed_suites=%u failure_records=%u error=%u\n",
                    summary->nTestsRun, summary->nTestsFailed,
                    summary->nAssertsFailed, summary->nSuitesFailed,
                    summary->nFailureRecords, (unsigned int)error);
        }
    }
    __real_CU_cleanup_registry();
}

/* PUBLIC_INTERFACE */
/**
 * Initialize, register and execute DHCP6C tests using ut-core's argc/argv.
 * Return EXIT_SUCCESS only for a nonempty run without initialization,
 * registration, framework, assertion, suite setup or suite cleanup failures.
 */
int main(int argc, char **argv)
{
    UT_status_t status;

    status = UT_init(argc, argv);
    if (status != UT_STATUS_OK || profile_failed || profile == NULL)
    {
        fputs("dhcp6c_hal_test: framework initialization failed; "
              "a valid -p profile is required\n", stderr);
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }

    /* Filtering out a suite is intentional, not an execution failure. */
    CU_set_fail_on_inactive(CU_FALSE);
    if (register_hal_l1_tests() != 0 ||
        (register_hal_l2_tests != NULL && register_hal_l2_tests() != 0) ||
        registration_failed ||
        CU_get_error() != CUE_SUCCESS || CU_get_registry() == NULL ||
        CU_get_registry()->uiNumberOfTests == 0U)
    {
        fputs("dhcp6c_hal_test: test registration failed or empty\n", stderr);
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }

    capturing_results = true;
    status = UT_run_tests();
    capturing_results = false;
    /* Also release a profile on framework error paths; UT_exit is idempotent. */
    UT_exit();

    if (status != UT_STATUS_OK || !results_captured || execution_failed ||
        tests_run == 0U)
    {
        fprintf(stderr, "dhcp6c_hal_test: run failed (tests executed: %u)\n",
                tests_run);
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
