/*
 * Copyright 2026 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file test_l2_dhcp6c_hal.c
 * @brief Ten stateful scenarios for the deterministic Linux reference model.
 *
 * Oracles are the internal dhcp6c_test_model.h policy and explicitly supplied
 * fixtures. These are not DHCP protocol, real-time timer or vendor conformance
 * claims. Tests use no daemon, network, sleeps, profile or environment settings.
 * Fixture tags and interface names below are synthetic data, not configuration.
 */
#include <ut.h>

#ifdef BUILD_LINUX
#include <limits.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <ut_log.h>
#include "dhcp6c_test_model.h"

typedef struct
{
    dhcp6c_test_role_t role;
    const char *name;
    int (*get_info)(dhcp6cInfo_t *information);
} role_case_t;

static const role_case_t roles[] = {
    {DHCP6C_TEST_ROLE_EROUTER, "E-Router", ert_dhcp6c_get_info},
    {DHCP6C_TEST_ROLE_ECM, "ECM", ecm_dhcp6c_get_info}
};

#define ROLE_COUNT (sizeof(roles) / sizeof(roles[0]))

/* Explicit reset oracles for the built-in example fixtures. They are not read
 * back from a getter and do not depend on which earlier test was selected. */
static const dhcp6cInfo_t reset_expected[] = {
    {
        .ifname = "erouter0", .smState = 1, .configAttemps = 1,
        .ipAddr = {0x20, 1, 0x0d, 0xb8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2},
        .prefix = {0x20, 1, 0x0d, 0xb8, 0, 1},
        .gw = {0x20, 1, 0x0d, 0xb8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
        .dhcpServer = {0x20, 1, 0x0d, 0xb8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3},
        .t1 = 1800, .t2 = 2880, .leaseTime = 3600, .leaseGotTime = 1000,
        .remainLeaseTime = 3500, .remainRenewTime = 1700,
        .remainRebindTime = 2780, .numOfDns = 2,
        .dnsAddrList = {
            {0x20, 1, 0x0d, 0xb8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x53},
            {0x20, 1, 0x0d, 0xb8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x54}
        }
    },
    {
        .ifname = "wan0", .smState = 2, .configAttemps = 2,
        .ipAddr = {0x20, 1, 0x0d, 0xb8, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2},
        .prefix = {0x20, 1, 0x0d, 0xb8, 0, 2},
        .gw = {0x20, 1, 0x0d, 0xb8, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
        .dhcpServer = {0x20, 1, 0x0d, 0xb8, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3},
        .t1 = 900, .t2 = 1440, .leaseTime = 1800, .leaseGotTime = 2000,
        .remainLeaseTime = 1700, .remainRenewTime = 800,
        .remainRebindTime = 1340, .numOfDns = 1,
        .dnsAddrList = {
            {0x20, 1, 0x0d, 0xb8, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x53}
        }
    }
};

static int reset_suite(void)
{
    dhcp6c_test_model_reset();
    return 0;
}

static void fill_address(unsigned char address[IPV6_ADDR_SIZE], unsigned int tag)
{
    size_t index;

    for (index = 0; index < IPV6_ADDR_SIZE; ++index)
    {
        address[index] = (unsigned char)(tag + 13U * index);
    }
}

/* Every field and every active DNS slot differs across fixture tags, so a
 * getter that swaps fields, returns an old snapshot, or mixes roles will fail. */
static dhcp6cInfo_t make_snapshot(unsigned int tag, int dns_count)
{
    dhcp6cInfo_t snapshot;
    int index;

    memset(&snapshot, 0, sizeof(snapshot));
    (void)snprintf(snapshot.ifname, sizeof(snapshot.ifname), "fixture-%u", tag);
    snapshot.smState = (int)tag;
    snapshot.configAttemps = (int)tag + 1;
    fill_address(snapshot.ipAddr, tag + 1);
    fill_address(snapshot.prefix, tag + 2);
    fill_address(snapshot.gw, tag + 3);
    fill_address(snapshot.dhcpServer, tag + 4);
    snapshot.t1 = tag * 100U + 11U;
    snapshot.t2 = tag * 100U + 22U;
    snapshot.leaseTime = tag * 100U + 33U;
    snapshot.leaseGotTime = tag * 100U + 44U;
    snapshot.remainLeaseTime = tag * 100U + 55U;
    snapshot.remainRenewTime = tag * 100U + 66U;
    snapshot.remainRebindTime = tag * 100U + 77U;
    snapshot.numOfDns = dns_count;
    /* Deliberately dirty even inactive slots; retrieval must clear them. */
    for (index = 0; index < MAX_IPV6_ADDR_LIST_SIZE; ++index)
    {
        fill_address(snapshot.dnsAddrList[index], tag + 10U + (unsigned int)index);
    }
    return snapshot;
}

static void assert_snapshot(const dhcp6cInfo_t *actual,
                            const dhcp6cInfo_t *expected)
{
    static const unsigned char zero_address[IPV6_ADDR_SIZE] = {0};
    int index;

    UT_ASSERT_EQUAL(memcmp(actual->ifname, expected->ifname,
                           sizeof(actual->ifname)), 0);
    UT_ASSERT_EQUAL(actual->smState, expected->smState);
    UT_ASSERT_EQUAL(actual->configAttemps, expected->configAttemps);
    UT_ASSERT_EQUAL(memcmp(actual->ipAddr, expected->ipAddr, IPV6_ADDR_SIZE), 0);
    UT_ASSERT_EQUAL(memcmp(actual->prefix, expected->prefix, IPV6_ADDR_SIZE), 0);
    UT_ASSERT_EQUAL(memcmp(actual->gw, expected->gw, IPV6_ADDR_SIZE), 0);
    UT_ASSERT_EQUAL(memcmp(actual->dhcpServer, expected->dhcpServer,
                           IPV6_ADDR_SIZE), 0);
    UT_ASSERT_EQUAL(actual->t1, expected->t1);
    UT_ASSERT_EQUAL(actual->t2, expected->t2);
    UT_ASSERT_EQUAL(actual->leaseTime, expected->leaseTime);
    UT_ASSERT_EQUAL(actual->leaseGotTime, expected->leaseGotTime);
    UT_ASSERT_EQUAL(actual->remainLeaseTime, expected->remainLeaseTime);
    UT_ASSERT_EQUAL(actual->remainRenewTime, expected->remainRenewTime);
    UT_ASSERT_EQUAL(actual->remainRebindTime, expected->remainRebindTime);
    UT_ASSERT_EQUAL(actual->numOfDns, expected->numOfDns);
    UT_ASSERT_FATAL(actual->numOfDns >= 0 &&
                    actual->numOfDns <= MAX_IPV6_ADDR_LIST_SIZE);
    UT_ASSERT_FATAL(expected->numOfDns >= 0 &&
                    expected->numOfDns <= MAX_IPV6_ADDR_LIST_SIZE);
    for (index = 0; index < MAX_IPV6_ADDR_LIST_SIZE; ++index)
    {
        const unsigned char *expected_address =
            index < expected->numOfDns ? expected->dnsAddrList[index] : zero_address;

        UT_ASSERT_EQUAL(memcmp(actual->dnsAddrList[index], expected_address,
                               IPV6_ADDR_SIZE), 0);
    }
}

static void read_and_assert(const role_case_t *role,
                            const dhcp6cInfo_t *expected)
{
    dhcp6cInfo_t actual;
    int status;

    UT_LOG_DEBUG("Checking %s snapshot", role->name);
    memset(&actual, 0xa5, sizeof(actual));
    status = role->get_info(&actual);
    UT_ASSERT_EQUAL_FATAL(status, 0);
    assert_snapshot(&actual, expected);
}

/** 1: Both getters return all supplied scalar, name and binary fields. */
static void test_l2_complete_snapshot(void)
{
    size_t index;

    for (index = 0; index < ROLE_COUNT; ++index)
    {
        dhcp6cInfo_t expected = make_snapshot(10U + (unsigned int)index,
                                             MAX_IPV6_ADDR_LIST_SIZE);
        dhcp6cInfo_t saved;

        memcpy(&saved, &expected, sizeof(saved));
        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role, &expected), 0);
        UT_ASSERT_EQUAL(memcmp(&expected, &saved, sizeof(saved)), 0);
        read_and_assert(&roles[index], &expected);
    }
}

/** 2: Repeated interleaved reads cannot advance timers, state or attempts. */
static void test_l2_frozen_state_repeatability(void)
{
    dhcp6cInfo_t expected[ROLE_COUNT];
    size_t index;
    int repetition;

    for (index = 0; index < ROLE_COUNT; ++index)
    {
        expected[index] = make_snapshot(20U + (unsigned int)index, 2);
        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role,
                                                    &expected[index]), 0);
    }
    for (repetition = 0; repetition < 12; ++repetition)
    {
        for (index = 0; index < ROLE_COUNT; ++index)
        {
            read_and_assert(&roles[index], &expected[index]);
        }
    }
}

/** 3: Neither seed inputs nor separate caller outputs are retained aliases. */
static void test_l2_caller_ownership_independence(void)
{
    size_t index;

    for (index = 0; index < ROLE_COUNT; ++index)
    {
        dhcp6cInfo_t expected = make_snapshot(30U + (unsigned int)index, 3);
        dhcp6cInfo_t input = expected;
        dhcp6cInfo_t first;
        dhcp6cInfo_t second;
        dhcp6cInfo_t saved_first;
        int status;

        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role, &input), 0);
        memset(&input, 0xcc, sizeof(input));
        status = roles[index].get_info(&first);
        UT_ASSERT_EQUAL_FATAL(status, 0);
        assert_snapshot(&first, &expected);
        memcpy(&saved_first, &first, sizeof(saved_first));

        status = roles[index].get_info(&second);
        UT_ASSERT_EQUAL_FATAL(status, 0);
        assert_snapshot(&second, &expected);
        UT_ASSERT_EQUAL(memcmp(&first, &saved_first, sizeof(first)), 0);

        memset(&first, 0x5a, sizeof(first));
        read_and_assert(&roles[index], &expected);
        assert_snapshot(&second, &expected);
        memset(&second, 0xa5, sizeof(second));
        read_and_assert(&roles[index], &expected);
        /* A later getter must not write into a previously supplied output. */
        memset(&saved_first, 0x5a, sizeof(saved_first));
        UT_ASSERT_EQUAL(memcmp(&first, &saved_first, sizeof(first)), 0);
    }
}

/** 4: Getter order and replacing one role cannot contaminate the other role. */
static void test_l2_role_isolation_order_independence(void)
{
    static const size_t order[] = {0, 1, 1, 0, 1, 0, 0, 1};
    dhcp6cInfo_t expected[ROLE_COUNT];
    size_t index;

    for (index = 0; index < ROLE_COUNT; ++index)
    {
        expected[index] = make_snapshot(40U + (unsigned int)index, (int)index + 1);
        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role,
                                                    &expected[index]), 0);
    }
    for (index = 0; index < sizeof(order) / sizeof(order[0]); ++index)
    {
        size_t selected = order[index];

        read_and_assert(&roles[selected], &expected[selected]);
    }
    for (index = 0; index < ROLE_COUNT; ++index)
    {
        size_t peer = 1U - index;

        expected[index] = make_snapshot(50U + (unsigned int)index, 3);
        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role,
                                                    &expected[index]), 0);
        read_and_assert(&roles[peer], &expected[peer]);
        read_and_assert(&roles[index], &expected[index]);
        read_and_assert(&roles[peer], &expected[peer]);
    }
}

/** 5: Replacement is complete, including a maximum-length terminated name. */
static void test_l2_state_replacement_a_to_b(void)
{
    size_t index;

    for (index = 0; index < ROLE_COUNT; ++index)
    {
        dhcp6cInfo_t state_a = make_snapshot(60U + (unsigned int)index, 3);
        dhcp6cInfo_t state_b = make_snapshot(70U + (unsigned int)index, 1);
        dhcp6cInfo_t previous;
        int status;

        memset(state_b.ifname, 'B', sizeof(state_b.ifname) - 1);
        state_b.ifname[sizeof(state_b.ifname) - 1] = '\0';
        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role, &state_a), 0);
        status = roles[index].get_info(&previous);
        UT_ASSERT_EQUAL_FATAL(status, 0);
        assert_snapshot(&previous, &state_a);

        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role, &state_b), 0);
        read_and_assert(&roles[index], &state_b);
        assert_snapshot(&previous, &state_a);
        read_and_assert(&roles[index], &state_b);
    }
}

/** 6: Cover every count and clear stale DNS data through 3 -> 1 -> 0. */
static void test_l2_dns_boundaries_and_shrink(void)
{
    static const int counts[] = {0, 1, 2, 3, 1, 0};
    static const int invalid_counts[] = {-1, MAX_IPV6_ADDR_LIST_SIZE + 1};
    size_t role_index;

    for (role_index = 0; role_index < ROLE_COUNT; ++role_index)
    {
        dhcp6cInfo_t expected = make_snapshot(80U + (unsigned int)role_index, 0);
        dhcp6cInfo_t actual;
        size_t index;
        int status;

        memset(&actual, 0xa5, sizeof(actual));
        for (index = 0; index < sizeof(counts) / sizeof(counts[0]); ++index)
        {
            expected.numOfDns = counts[index];
            UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[role_index].role,
                                                        &expected), 0);
            /* Reuse the same output to expose stale slots after shrinking. */
            status = roles[role_index].get_info(&actual);
            UT_ASSERT_EQUAL_FATAL(status, 0);
            assert_snapshot(&actual, &expected);
        }
        for (index = 0; index < sizeof(invalid_counts) / sizeof(invalid_counts[0]); ++index)
        {
            dhcp6cInfo_t invalid = expected;

            invalid.numOfDns = invalid_counts[index];
            UT_ASSERT_EQUAL(dhcp6c_test_model_seed(roles[role_index].role, &invalid), -1);
            read_and_assert(&roles[role_index], &expected);
        }
    }
}

/** 7: Full-width copies preserve zero, FF and mixed binary addresses. */
static void test_l2_binary_fidelity_zero_and_ff(void)
{
    static const unsigned char mixed[IPV6_ADDR_SIZE] = {
        0x00, 0xff, 0x10, 0x00, 0x80, 0xff, 0x01, 0x00,
        0x7f, 0x00, 0xfe, 0xff, 0x55, 0xaa, 0x00, 0xff
    };
    size_t role_index;
    int pattern;

    for (role_index = 0; role_index < ROLE_COUNT; ++role_index)
    {
        for (pattern = 0; pattern < 3; ++pattern)
        {
            dhcp6cInfo_t expected = make_snapshot(90U + (unsigned int)role_index, 3);
            int dns_index;
            size_t byte;

            expected.smState = INT_MIN;
            expected.configAttemps = INT_MAX;
            expected.t1 = UINT_MAX;
            expected.t2 = UINT_MAX - 1U;
            expected.leaseTime = 0;
            expected.leaseGotTime = UINT_MAX - 2U;
            expected.remainLeaseTime = UINT_MAX - 3U;
            expected.remainRenewTime = UINT_MAX - 4U;
            expected.remainRebindTime = UINT_MAX - 5U;
            for (byte = 0; byte < IPV6_ADDR_SIZE; ++byte)
            {
                unsigned char value = pattern == 0 ? 0x00 : 0xff;

                expected.ipAddr[byte] = pattern == 2 ? mixed[byte] : value;
                expected.prefix[byte] =
                    pattern == 2 ? mixed[IPV6_ADDR_SIZE - 1U - byte] : value;
                expected.gw[byte] =
                    pattern == 2 ? mixed[(byte + 3U) % IPV6_ADDR_SIZE] : value;
                expected.dhcpServer[byte] =
                    pattern == 2 ? mixed[(byte + 7U) % IPV6_ADDR_SIZE] : value;
                for (dns_index = 0; dns_index < MAX_IPV6_ADDR_LIST_SIZE; ++dns_index)
                {
                    expected.dnsAddrList[dns_index][byte] = pattern == 2 ?
                        mixed[(byte + (size_t)dns_index) % IPV6_ADDR_SIZE] : value;
                }
            }
            UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[role_index].role,
                                                        &expected), 0);
            read_and_assert(&roles[role_index], &expected);
        }
    }
}

/** 8: Failure persists across reads and seeds, is role-local, and recovers. */
static void test_l2_retrieval_failure_and_recovery(void)
{
    dhcp6cInfo_t expected[ROLE_COUNT];
    size_t index;

    for (index = 0; index < ROLE_COUNT; ++index)
    {
        expected[index] = make_snapshot(100U + (unsigned int)index, 2);
        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role,
                                                    &expected[index]), 0);
    }
    for (index = 0; index < ROLE_COUNT; ++index)
    {
        size_t peer = 1U - index;
        dhcp6cInfo_t output;
        dhcp6cInfo_t sentinel;
        int repetition;
        int status;

        memset(&sentinel, 0xa5, sizeof(sentinel));
        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_set_failure(roles[index].role, -7), 0);
        for (repetition = 0; repetition < 3; ++repetition)
        {
            memcpy(&output, &sentinel, sizeof(output));
            status = roles[index].get_info(&output);
            UT_ASSERT_EQUAL(status, -1);
            /* Raw equality is intentional here: failure must not write even
             * one byte, including padding, into caller storage. */
            UT_ASSERT_EQUAL(memcmp(&output, &sentinel, sizeof(output)), 0);
            read_and_assert(&roles[peer], &expected[peer]);
        }
        UT_ASSERT_EQUAL(roles[index].get_info(NULL), -1);
        expected[index] = make_snapshot(110U + (unsigned int)index, 1);
        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role,
                                                    &expected[index]), 0);
        /* Do not reapply the flag: the seed itself must preserve failure. */
        memcpy(&output, &sentinel, sizeof(output));
        status = roles[index].get_info(&output);
        UT_ASSERT_EQUAL(status, -1);
        UT_ASSERT_EQUAL(memcmp(&output, &sentinel, sizeof(output)), 0);
        read_and_assert(&roles[peer], &expected[peer]);

        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_set_failure(roles[index].role, 0), 0);
        read_and_assert(&roles[index], &expected[index]);
        UT_ASSERT_EQUAL(roles[index].get_info(NULL), -1);
        read_and_assert(&roles[index], &expected[index]);
        read_and_assert(&roles[peer], &expected[peer]);
    }
}

typedef struct
{
    unsigned char before[16];
    dhcp6cInfo_t information;
    unsigned char after[16];
} guarded_snapshot_t;

/* Ensure an off-by-one write cannot land in alignment padding before a guard. */
_Static_assert(offsetof(guarded_snapshot_t, information) == 16,
               "The leading canary must touch the output structure");
_Static_assert(offsetof(guarded_snapshot_t, after) ==
               offsetof(guarded_snapshot_t, information) + sizeof(dhcp6cInfo_t),
               "The trailing canary must touch the output structure");

static void assert_canaries(const guarded_snapshot_t *guarded,
                            unsigned char expected)
{
    size_t index;

    for (index = 0; index < sizeof(guarded->before); ++index)
    {
        UT_ASSERT_EQUAL(guarded->before[index], expected);
        UT_ASSERT_EQUAL(guarded->after[index], expected);
    }
}

/** 9: Success/failure/recovery writes stay inside the exact caller structure. */
static void test_l2_struct_boundary_canaries(void)
{
    size_t index;

    for (index = 0; index < ROLE_COUNT; ++index)
    {
        dhcp6cInfo_t input = make_snapshot(120U + (unsigned int)index, 3);
        dhcp6cInfo_t expected;
        guarded_snapshot_t guarded;
        guarded_snapshot_t sentinel;
        int status;

        memset(input.ifname, 'N', sizeof(input.ifname));
        expected = input;
        expected.ifname[sizeof(expected.ifname) - 1] = '\0';
        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role, &input), 0);
        UT_ASSERT(memchr(input.ifname, '\0', sizeof(input.ifname)) == NULL);
        memset(&guarded, 0xa5, sizeof(guarded));
        status = roles[index].get_info(&guarded.information);
        UT_ASSERT_EQUAL_FATAL(status, 0);
        assert_canaries(&guarded, 0xa5);
        assert_snapshot(&guarded.information, &expected);

        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_set_failure(roles[index].role, 1), 0);
        memset(&guarded, 0x3c, sizeof(guarded));
        memcpy(&sentinel, &guarded, sizeof(sentinel));
        status = roles[index].get_info(&guarded.information);
        UT_ASSERT_EQUAL(status, -1);
        UT_ASSERT_EQUAL(memcmp(&guarded, &sentinel, sizeof(guarded)), 0);
        assert_canaries(&guarded, 0x3c);

        UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_set_failure(roles[index].role, 0), 0);
        status = roles[index].get_info(&guarded.information);
        UT_ASSERT_EQUAL_FATAL(status, 0);
        assert_canaries(&guarded, 0x3c);
        assert_snapshot(&guarded.information, &expected);
    }
}

/** 10: Reset restores both built-in snapshots and clears both failure flags. */
static void test_l2_fixture_reset_isolation(void)
{
    size_t index;
    int cycle;

    for (index = 0; index < ROLE_COUNT; ++index)
    {
        read_and_assert(&roles[index], &reset_expected[index]);
    }
    for (cycle = 0; cycle < 2; ++cycle)
    {
        for (index = 0; index < ROLE_COUNT; ++index)
        {
            dhcp6cInfo_t dirty = make_snapshot(130U + (unsigned int)index, 3);
            dhcp6cInfo_t output;
            dhcp6cInfo_t sentinel;
            int status;

            UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_seed(roles[index].role, &dirty), 0);
            UT_ASSERT_EQUAL_FATAL(dhcp6c_test_model_set_failure(roles[index].role, 1), 0);
            memset(&sentinel, 0x69, sizeof(sentinel));
            memcpy(&output, &sentinel, sizeof(output));
            status = roles[index].get_info(&output);
            UT_ASSERT_EQUAL(status, -1);
            UT_ASSERT_EQUAL(memcmp(&output, &sentinel, sizeof(output)), 0);
        }
        dhcp6c_test_model_reset();
        for (index = 0; index < ROLE_COUNT; ++index)
        {
            read_and_assert(&roles[index], &reset_expected[index]);
        }
        /* Reset is idempotent, and rejected NULL reads cannot poison state. */
        dhcp6c_test_model_reset();
        for (index = 0; index < ROLE_COUNT; ++index)
        {
            UT_ASSERT_EQUAL(roles[index].get_info(NULL), -1);
            read_and_assert(&roles[index], &reset_expected[index]);
        }
    }
}
#endif /* BUILD_LINUX */

/* PUBLIC_INTERFACE */
/**
 * Register the ten Linux-model cases under UT_TESTS_L2; return 0 or -1.
 * Vendor builds return 0 without registering simulated cases or model symbols.
 */
int register_hal_l2_tests(void)
{
#ifdef BUILD_LINUX
    static const struct
    {
        const char *name;
        UT_TestFunction_t function;
    } cases[] = {
        {"l2_complete_snapshot", test_l2_complete_snapshot},
        {"l2_frozen_state_repeatability", test_l2_frozen_state_repeatability},
        {"l2_caller_ownership_independence", test_l2_caller_ownership_independence},
        {"l2_role_isolation_order_independence", test_l2_role_isolation_order_independence},
        {"l2_state_replacement_a_to_b", test_l2_state_replacement_a_to_b},
        {"l2_dns_boundaries_and_shrink", test_l2_dns_boundaries_and_shrink},
        {"l2_binary_fidelity_zero_and_ff", test_l2_binary_fidelity_zero_and_ff},
        {"l2_retrieval_failure_and_recovery", test_l2_retrieval_failure_and_recovery},
        {"l2_struct_boundary_canaries", test_l2_struct_boundary_canaries},
        {"l2_fixture_reset_isolation", test_l2_fixture_reset_isolation}
    };
    UT_test_suite_t *suite =
        UT_add_suite_withGroupID("[L2 dhcp6c Linux model]", reset_suite,
                                  reset_suite, UT_TESTS_L2);
    size_t index;

    if (suite == NULL)
    {
        return -1;
    }
    /* Use the public per-test hooks because UT's group API exposes only suite
     * init/cleanup. CUnit invokes TearDown even after a fatal test assertion. */
    ((CU_pSuite)suite)->pSetUpFunc = dhcp6c_test_model_reset;
    ((CU_pSuite)suite)->pTearDownFunc = dhcp6c_test_model_reset;
    for (index = 0; index < sizeof(cases) / sizeof(cases[0]); ++index)
    {
        if (UT_add_test(suite, cases[index].name, cases[index].function) == NULL)
        {
            return -1;
        }
    }
#endif
    return 0;
}
