/*
 * Copyright 2026 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef DHCP6C_TEST_MODEL_H
#define DHCP6C_TEST_MODEL_H

#ifdef BUILD_LINUX

#include "dhcp6cApi.h"

/**
 * Internal Linux fixture interface, not part of the vendor HAL ABI.
 *
 * The model is process-local and intended for serialized tests. No clock,
 * network, daemon, profile or environment is consulted. Getters start with the
 * same built-in example snapshots as reset, and never advance timers or state.
 *
 * Linux-model policy ONLY (the public HAL header leaves these details open):
 * - Getters return 0 on success, -1 on NULL output or injected role failure.
 * - A failed getter leaves caller storage unchanged.
 * - Successful getters copy values into caller-owned storage, never aliases.
 * - Interface names contain at most 31 bytes plus a NUL in the 32-byte array.
 * - IPv6 fields and active DNS slots are binary, copied at their full width.
 * - Unused DNS slots and struct padding are zeroed in each returned snapshot.
 */
typedef enum
{
    DHCP6C_TEST_ROLE_EROUTER = 0,
    DHCP6C_TEST_ROLE_ECM = 1
} dhcp6c_test_role_t;

/* PUBLIC_INTERFACE */
/**
 * Restore both built-in role snapshots and clear both failure flags.
 * Takes no arguments and returns no value. Safe to call before any getter.
 */
void dhcp6c_test_model_reset(void);

/* PUBLIC_INTERFACE */
/**
 * Replace one role's snapshot with an owned, bounded copy of snapshot.
 *
 * Return 0 on success, -1 for an unknown role, NULL snapshot, or numOfDns
 * outside [0, MAX_IPV6_ADDR_LIST_SIZE]. Rejection changes no model state.
 * The input is not modified or retained. Nonterminated ifname is truncated to
 * 31 bytes; inactive DNS slots are cleared. Other fields are copied verbatim.
 * Seeding does not alter either role's failure flag or the other snapshot.
 */
int dhcp6c_test_model_seed(dhcp6c_test_role_t role,
                          const dhcp6cInfo_t *snapshot);

/* PUBLIC_INTERFACE */
/**
 * Set a persistent getter failure for role when enabled is nonzero.
 * Zero clears the flag; reset also clears it. Return 0 on success or -1 for
 * an unknown role, without changing either stored snapshot or the other flag.
 */
int dhcp6c_test_model_set_failure(dhcp6c_test_role_t role, int enabled);

#endif /* BUILD_LINUX */
#endif /* DHCP6C_TEST_MODEL_H */
