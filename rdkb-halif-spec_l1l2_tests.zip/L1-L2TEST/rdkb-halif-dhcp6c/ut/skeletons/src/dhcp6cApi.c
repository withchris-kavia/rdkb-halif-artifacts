/*
* If not stated otherwise in this file or this component's LICENSE file the
* following copyright and licenses apply:*
* Copyright 2023 RDK Management
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#ifdef BUILD_LINUX

#include <stdbool.h>
#include <stddef.h>
#include <string.h>

/* Keep standalone source probes independent of framework include paths. */
#include "../include/dhcp6c_test_model.h"

/* These are frozen example fixtures, not device/network configuration. */
static const dhcp6cInfo_t default_snapshots[] = {
    [DHCP6C_TEST_ROLE_EROUTER] = {
        .ifname = "erouter0",
        .smState = 1,
        .configAttemps = 1,
        .ipAddr = {0x20, 0x01, 0x0d, 0xb8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2},
        .prefix = {0x20, 0x01, 0x0d, 0xb8, 0, 1},
        .gw = {0x20, 0x01, 0x0d, 0xb8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
        .dhcpServer = {0x20, 0x01, 0x0d, 0xb8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3},
        .t1 = 1800,
        .t2 = 2880,
        .leaseTime = 3600,
        .leaseGotTime = 1000,
        .remainLeaseTime = 3500,
        .remainRenewTime = 1700,
        .remainRebindTime = 2780,
        .numOfDns = 2,
        .dnsAddrList = {
            {0x20, 0x01, 0x0d, 0xb8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x53},
            {0x20, 0x01, 0x0d, 0xb8, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x54}
        }
    },
    [DHCP6C_TEST_ROLE_ECM] = {
        .ifname = "wan0",
        .smState = 2,
        .configAttemps = 2,
        .ipAddr = {0x20, 0x01, 0x0d, 0xb8, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2},
        .prefix = {0x20, 0x01, 0x0d, 0xb8, 0, 2},
        .gw = {0x20, 0x01, 0x0d, 0xb8, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
        .dhcpServer = {0x20, 0x01, 0x0d, 0xb8, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3},
        .t1 = 900,
        .t2 = 1440,
        .leaseTime = 1800,
        .leaseGotTime = 2000,
        .remainLeaseTime = 1700,
        .remainRenewTime = 800,
        .remainRebindTime = 1340,
        .numOfDns = 1,
        .dnsAddrList = {
            {0x20, 0x01, 0x0d, 0xb8, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x53}
        }
    }
};

static dhcp6cInfo_t snapshots[sizeof(default_snapshots) / sizeof(default_snapshots[0])];
static bool failures[sizeof(default_snapshots) / sizeof(default_snapshots[0])];
static bool initialized;

static bool valid_role(dhcp6c_test_role_t role)
{
    return role == DHCP6C_TEST_ROLE_EROUTER || role == DHCP6C_TEST_ROLE_ECM;
}

/* Source DNS counts are validated before storage; defaults also satisfy bounds.
 * Copy fields, not input padding, so every returned byte is deterministic. */
static void copy_snapshot(dhcp6cInfo_t *destination, const dhcp6cInfo_t *source)
{
    size_t index;

    memset(destination, 0, sizeof(*destination));
    for (index = 0; index < sizeof(destination->ifname) - 1; ++index)
    {
        if (source->ifname[index] == '\0')
        {
            break;
        }
        destination->ifname[index] = source->ifname[index];
    }

    destination->smState = source->smState;
    destination->configAttemps = source->configAttemps;
    memcpy(destination->ipAddr, source->ipAddr, sizeof(destination->ipAddr));
    memcpy(destination->prefix, source->prefix, sizeof(destination->prefix));
    memcpy(destination->gw, source->gw, sizeof(destination->gw));
    memcpy(destination->dhcpServer, source->dhcpServer, sizeof(destination->dhcpServer));
    destination->t1 = source->t1;
    destination->t2 = source->t2;
    destination->leaseTime = source->leaseTime;
    destination->leaseGotTime = source->leaseGotTime;
    destination->remainLeaseTime = source->remainLeaseTime;
    destination->remainRenewTime = source->remainRenewTime;
    destination->remainRebindTime = source->remainRebindTime;
    destination->numOfDns = source->numOfDns;
    memcpy(destination->dnsAddrList, source->dnsAddrList,
           (size_t)source->numOfDns * sizeof(source->dnsAddrList[0]));
}

/* PUBLIC_INTERFACE */
/** Restore both deterministic snapshots and clear all injected failures. */
void dhcp6c_test_model_reset(void)
{
    size_t index;

    for (index = 0; index < sizeof(snapshots) / sizeof(snapshots[0]); ++index)
    {
        copy_snapshot(&snapshots[index], &default_snapshots[index]);
        failures[index] = false;
    }
    initialized = true;
}

static void initialize_if_needed(void)
{
    if (!initialized)
    {
        dhcp6c_test_model_reset();
    }
}

/* PUBLIC_INTERFACE */
/** Copy snapshot into role; return 0, or -1 without mutation for invalid input. */
int dhcp6c_test_model_seed(dhcp6c_test_role_t role,
                          const dhcp6cInfo_t *snapshot)
{
    if (!valid_role(role) || snapshot == NULL ||
        snapshot->numOfDns < 0 || snapshot->numOfDns > MAX_IPV6_ADDR_LIST_SIZE)
    {
        return -1;
    }

    initialize_if_needed();
    copy_snapshot(&snapshots[role], snapshot);
    return 0;
}

/* PUBLIC_INTERFACE */
/** Toggle role's persistent retrieval failure; return -1 only for an invalid role. */
int dhcp6c_test_model_set_failure(dhcp6c_test_role_t role, int enabled)
{
    if (!valid_role(role))
    {
        return -1;
    }

    initialize_if_needed();
    failures[role] = enabled != 0;
    return 0;
}

static int get_snapshot(dhcp6c_test_role_t role, dhcp6cInfo_t *information)
{
    if (information == NULL)
    {
        return -1;
    }

    initialize_if_needed();
    if (failures[role])
    {
        return -1;
    }

    copy_snapshot(information, &snapshots[role]);
    return 0;
}

/* PUBLIC_INTERFACE */
/**
 * Copy the frozen E-Router snapshot into caller-owned pInfo.
 * Return 0 on success, -1 on NULL or injected failure, with no failure writes.
 */
int ert_dhcp6c_get_info(dhcp6cInfo_t *pInfo)
{
    return get_snapshot(DHCP6C_TEST_ROLE_EROUTER, pInfo);
}

/* PUBLIC_INTERFACE */
/**
 * Copy the frozen ECM snapshot into caller-owned pInfo.
 * Return 0 on success, -1 on NULL or injected failure, with no failure writes.
 */
int ecm_dhcp6c_get_info(dhcp6cInfo_t *pInfo)
{
    return get_snapshot(DHCP6C_TEST_ROLE_ECM, pInfo);
}

#endif /* BUILD_LINUX */
