#!/usr/bin/env bash

# *
# * If not stated otherwise in this file or this component's LICENSE file the
# * following copyright and licenses apply:
# *
# * Copyright 2023 RDK Management
# *
# * Licensed under the Apache License, Version 2.0 (the "License");
# * you may not use this file except in compliance with the License.
# * You may obtain a copy of the License at
# *
# * http://www.apache.org/licenses/LICENSE-2.0
# *
# * Unless required by applicable law or agreed to in writing, software
# * distributed under the License is distributed on an "AS IS" BASIS,
# * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# * See the License for the specific language governing permissions and
# * limitations under the License.
# *

# Relative checkout paths, including --dir, are rooted at this script.
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || exit 1
cd -- "$SCRIPT_DIR" || exit 1
UT_DIR="$SCRIPT_DIR/ut"
UT_PROJECT_VERSION=${UT_PROJECT_VERSION:-master}
BUILD_ARGS=()

while (( $# )); do
    case "$1" in
        -h|--help)
            printf '%s\n' \
                "Usage: build_ut.sh [--dir DIRECTORY] [make arguments...]" \
                "Relative DIRECTORY paths are relative to the script." \
                "Default target: linux; use TARGET=arm for a vendor build."
            exit 0
            ;;
        --dir)
            if (( $# < 2 )) || [[ -z "$2" || "$2" == -* ]]; then
                echo "build_ut.sh: --dir requires a directory" >&2
                exit 2
            fi
            UT_DIR=$2
            shift 2
            ;;
        --dir=*)
            UT_DIR=${1#--dir=}
            if [[ -z "$UT_DIR" ]]; then
                echo "build_ut.sh: --dir requires a directory" >&2
                exit 2
            fi
            shift
            ;;
        --)
            shift
            BUILD_ARGS+=("$@")
            break
            ;;
        *)
            BUILD_ARGS+=("$1")
            shift
            ;;
    esac
done

if [[ ! -d "$UT_DIR" ]]; then
    # Derive the matching test repository only when a checkout is needed.
    TEST_REPO=$(git -C "$SCRIPT_DIR" remote get-url origin) || exit $?
    TEST_REPO=${TEST_REPO//halif/halif-test}
    echo "Cloning unit test suite for this module"
    git clone -- "$TEST_REPO" "$UT_DIR" || exit $?
    git -C "$UT_DIR" checkout "$UT_PROJECT_VERSION" || exit $?
fi

cd -- "$UT_DIR" || exit 1
exec bash ./build.sh "${BUILD_ARGS[@]}"
