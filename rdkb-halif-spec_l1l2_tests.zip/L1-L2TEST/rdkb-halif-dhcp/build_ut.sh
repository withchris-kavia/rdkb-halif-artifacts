#!/usr/bin/env bash

# *
# * If not stated otherwise in this file or this component's LICENSE file the
# * following copyright and licenses apply:
# *
# * Copyright 2023 RDK Management
# *
# * Licensed under the Apache License, Version 2.0 (the "License");
# * you may not use this file except in compliance with the License.
# * You may obtain a copy of the License at
# *
# * http://www.apache.org/licenses/LICENSE-2.0
# *
# * Unless required by applicable law or agreed to in writing, software
# * distributed under the License is distributed on an "AS IS" BASIS,
# * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# * See the License for the specific language governing permissions and
# * limitations under the License.
# *

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd) || exit 1
DIR=$SCRIPT_DIR
UT_PROJECT_VERSION=${UT_PROJECT_VERSION:-main}

case "${1:-}" in
    -h|--help)
        printf '%s\n' \
            'Usage: build_ut.sh [--dir DIRECTORY] [make arguments...]' \
            'Default: build Linux tests in the ut directory next to this script.' \
            'Examples: build_ut.sh clean; build_ut.sh TARGET=arm HAL=dhcp4cApi'
        exit 0
        ;;
    --dir)
        if [[ $# -lt 2 || -z $2 ]]; then
            printf '%s\n' 'build_ut.sh: --dir requires a directory' >&2
            exit 2
        fi
        DIR=$2
        shift 2
        ;;
esac

if [[ ! -d "$DIR/ut" ]]; then
    # Derive the official companion repository from this component, not cwd.
    REMOTE=$(git -C "$SCRIPT_DIR" remote get-url origin) || exit $?
    TEST_REPO=${REMOTE/halif/halif-test}
    TEST_REPO=${TEST_REPO/hal-/haltest-}
    if [[ -z $REMOTE || $TEST_REPO == "$REMOTE" ]]; then
        printf '%s\n' 'build_ut.sh: cannot derive the companion test repository' >&2
        exit 1
    fi
    mkdir -p -- "$DIR" || exit $?
    git clone -- "$TEST_REPO" "$DIR/ut" || exit $?
    git -C "$DIR/ut" checkout "$UT_PROJECT_VERSION" || exit $?
fi

cd -- "$DIR/ut" || exit $?
exec ./build.sh "$@"
