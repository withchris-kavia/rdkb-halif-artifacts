/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file test_l1_dhcpv4c_api.c
 * Newer DHCP client L1 tests. Exact Linux fixture assertions are distinct from
 * portable status, NULL and bounded-output checks used on a vendor HAL.
 * References: include/dhcpv4c_api.h; docs/pages/DHCPv4ChalSpec.md.
 * No undefined ECM state range or address byte order is imposed.
 */
#include "dhcpv4c_api.h"

#define TEST_L1_FAMILY DHCP_TEST_FAMILY_NEWER
#define TEST_L1_DNS_TYPE dhcpv4c_ip_list_t
#define TEST_L1_DNS_ADDRS addrs
#define TEST_L1_DNS_CAPACITY DHCPV4_MAX_IPV4_ADDRS
#include "test_dhcp_l1.h"

#define NEWER_UINT_CASES(X) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_lease_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_lease_time, \
      dhcpv4c_get_ert_lease_time, DHCP_TEST_ROLE_ERT, lease_time) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_remain_lease_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_remain_lease_time, \
      dhcpv4c_get_ert_remain_lease_time, DHCP_TEST_ROLE_ERT, remain_lease_time) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_remain_renew_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_remain_renew_time, \
      dhcpv4c_get_ert_remain_renew_time, DHCP_TEST_ROLE_ERT, remain_renew_time) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_remain_rebind_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_remain_rebind_time, \
      dhcpv4c_get_ert_remain_rebind_time, DHCP_TEST_ROLE_ERT, remain_rebind_time) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_ip_addr, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_ip_addr, \
      dhcpv4c_get_ert_ip_addr, DHCP_TEST_ROLE_ERT, ip_addr) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_mask, \
      l1_dhcpv4c_api_negative1_dhcpv4c_dhcpv4c_get_ert_mask, \
      dhcpv4c_get_ert_mask, DHCP_TEST_ROLE_ERT, mask) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_gw, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_gw, \
      dhcpv4c_get_ert_gw, DHCP_TEST_ROLE_ERT, gw) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_dhcp_svr, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_dhcp_svr, \
      dhcpv4c_get_ert_dhcp_svr, DHCP_TEST_ROLE_ERT, dhcp_svr) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_lease_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_lease_time, \
      dhcpv4c_get_ecm_lease_time, DHCP_TEST_ROLE_ECM, lease_time) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_remain_lease_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_remain_lease_time, \
      dhcpv4c_get_ecm_remain_lease_time, DHCP_TEST_ROLE_ECM, remain_lease_time) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_remain_renew_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_remain_renew_time, \
      dhcpv4c_get_ecm_remain_renew_time, DHCP_TEST_ROLE_ECM, remain_renew_time) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_ecm_remain_rebind_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_remain_rebind_time, \
      dhcpv4c_get_ecm_remain_rebind_time, DHCP_TEST_ROLE_ECM, remain_rebind_time) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_ip_addr, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_ip_addr, \
      dhcpv4c_get_ecm_ip_addr, DHCP_TEST_ROLE_ECM, ip_addr) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_mask, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_mask, \
      dhcpv4c_get_ecm_mask, DHCP_TEST_ROLE_ECM, mask) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_gw, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_gw, \
      dhcpv4c_get_ecm_gw, DHCP_TEST_ROLE_ECM, gw) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_dhcp_svr, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_dhcp_svr, \
      dhcpv4c_get_ecm_dhcp_svr, DHCP_TEST_ROLE_ECM, dhcp_svr)

#define NEWER_INT_CASES(X) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_config_attempts, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_config_attempts, \
      dhcpv4c_get_ert_config_attempts, DHCP_TEST_ROLE_ERT, config_attempts, TEST_L1_NO_RANGE) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_fsm_state, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_fsm_state, \
      dhcpv4c_get_ert_fsm_state, DHCP_TEST_ROLE_ERT, fsm_state, TEST_L1_NO_RANGE) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_config_attempts, \
      l1_dhcpv4c_api_negative1_dhcpv4c_ecm_config_attempts, \
      dhcpv4c_get_ecm_config_attempts, DHCP_TEST_ROLE_ECM, config_attempts, TEST_L1_NO_RANGE) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_fsm_state, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_fsm_state, \
      dhcpv4c_get_ecm_fsm_state, DHCP_TEST_ROLE_ECM, fsm_state, TEST_L1_NO_RANGE)

#define NEWER_NAME_CASES(X) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_ifname, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_ifname, \
      dhcpv4c_get_ert_ifname, DHCP_TEST_ROLE_ERT) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_ifname, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_ifname, \
      dhcpv4c_get_ecm_ifname, DHCP_TEST_ROLE_ECM)

#define NEWER_DNS_CASES(X) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ert_dns_svrs, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ert_dns_svrs, \
      dhcpv4c_get_ert_dns_svrs, DHCP_TEST_ROLE_ERT) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_ecm_dns_svrs, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_ecm_dns_svrs, \
      dhcpv4c_get_ecm_dns_svrs, DHCP_TEST_ROLE_ECM)

NEWER_UINT_CASES(TEST_L1_UINT_PAIR)
NEWER_INT_CASES(TEST_L1_INT_PAIR)
NEWER_NAME_CASES(TEST_L1_NAME_PAIR)
NEWER_DNS_CASES(TEST_L1_DNS_PAIR)

#ifndef NO_MTA_FEATURE_SUPPORT
#define NEWER_EMTA_CASES(X) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_emta_remain_lease_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_emta_remain_lease_time, \
      dhcpv4c_get_emta_remain_lease_time, DHCP_TEST_ROLE_EMTA, remain_lease_time) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_emta_remain_renew_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_emta_remain_renew_time, \
      dhcpv4c_get_emta_remain_renew_time, DHCP_TEST_ROLE_EMTA, remain_renew_time) \
    X(l1_dhcpv4c_api_positive1_dhcpv4c_get_emta_remain_rebind_time, \
      l1_dhcpv4c_api_negative1_dhcpv4c_get_emta_remain_rebind_time, \
      dhcpv4c_get_emta_remain_rebind_time, DHCP_TEST_ROLE_EMTA, remain_rebind_time)
NEWER_EMTA_CASES(TEST_L1_UINT_PAIR)
#endif

/** Check macro types as well as values; sizeof alone misses signedness. */
static void test_l1_dhcpv4c_contract_constants(void)
{
    dhcpv4c_ip_list_t list = {0};

    UT_ASSERT_EQUAL(DHCPV4_MAX_IPV4_ADDRS, 4);
    UT_ASSERT_EQUAL(sizeof(list.addrs) / sizeof(list.addrs[0]), 4U);
    UT_ASSERT_EQUAL(STATUS_SUCCESS, 0);
    UT_ASSERT_EQUAL(STATUS_FAILURE, -1);
    UT_ASSERT_EQUAL(TRUE, 1);
    UT_ASSERT_EQUAL(FALSE, 0);
    UT_ASSERT_EQUAL(ENABLE, 1);
    UT_ASSERT_TRUE(_Generic((ULONG)0, unsigned long: 1, default: 0));
    UT_ASSERT_TRUE(_Generic((BOOL)0, unsigned char: 1, default: 0));
    UT_ASSERT_TRUE(_Generic((CHAR)0, char: 1, default: 0));
    UT_ASSERT_TRUE(_Generic((UCHAR)0, unsigned char: 1, default: 0));
    UT_ASSERT_TRUE(_Generic((INT)0, int: 1, default: 0));
    UT_ASSERT_TRUE(_Generic((UINT)0, unsigned int: 1, default: 0));
    UT_ASSERT_TRUE(_Generic(list.number, int: 1, default: 0));
    UT_ASSERT_TRUE(_Generic(list.addrs[0], unsigned int: 1, default: 0));
}

/* PUBLIC_INTERFACE */
/** Register newer L1 tests; return 0, or -1 on any registration failure. */
int test_dhcpv4c_api_hal_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite("[L1 dhcpv4c_api]", NULL, TEST_L1_CLEANUP);

    if (suite == NULL) return -1;
    NEWER_UINT_CASES(TEST_L1_REGISTER_PAIR)
    NEWER_INT_CASES(TEST_L1_REGISTER_PAIR)
    NEWER_NAME_CASES(TEST_L1_REGISTER_PAIR)
    NEWER_DNS_CASES(TEST_L1_REGISTER_PAIR)
#ifndef NO_MTA_FEATURE_SUPPORT
    NEWER_EMTA_CASES(TEST_L1_REGISTER_PAIR)
#endif
    if (UT_add_test(suite, "l1_dhcpv4c_contract_constants",
                    test_l1_dhcpv4c_contract_constants) == NULL) return -1;
    return 0;
}
