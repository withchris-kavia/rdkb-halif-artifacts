/*
* If not stated otherwise in this file or this component's LICENSE file the
* following copyright and licenses apply:*
* Copyright 2023 RDK Management
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/*
 * The existing build explicitly enumerates sources and already compiles this
 * registrar. Embed private Linux L2 callbacks to keep build/vendor code intact.
 */
#ifdef BUILD_LINUX
#define DHCP_L2_EMBEDDED
#include "test_l2_dhcp_hal.c"
#undef DHCP_L2_EMBEDDED
#endif

#ifdef DHCP4CAPI
extern int test_dhcp4cApi_hal_l1_register(void);
#endif
#ifdef DHCPV4C_API
extern int test_dhcpv4c_api_hal_l1_register(void);
#endif

/* PUBLIC_INTERFACE */
/**
 * Register selected L1 suites and Linux-model L2 scenarios.
 * Retain the historical function name for compatibility with main.c.
 * @return 0 on success, or -1 on the first suite/case registration failure.
 */
int register_hal_l1_tests(void)
{
#ifdef DHCP4CAPI
    if (test_dhcp4cApi_hal_l1_register() != 0) return -1;
#endif
#ifdef DHCPV4C_API
    if (test_dhcpv4c_api_hal_l1_register() != 0) return -1;
#endif
#ifdef BUILD_LINUX
    if (test_dhcp_hal_l2_register() != 0) return -1;
#endif
    return 0;
}
