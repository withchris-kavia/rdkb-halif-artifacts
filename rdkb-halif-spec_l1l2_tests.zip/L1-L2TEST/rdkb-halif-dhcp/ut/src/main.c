/*
* If not stated otherwise in this file or this component's LICENSE file the
* following copyright and licenses apply:*
* Copyright 2023 RDK Management
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <ut.h>

extern int register_hal_l1_tests(void);
extern void __real_CU_cleanup_registry(void);
extern UT_test_suite_t *__real_UT_add_suite(
    const char *title, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup);

static bool registration_failed;
static bool capturing_results;
static bool results_captured;
static bool execution_failed;
static unsigned int tests_run;

/* PUBLIC_INTERFACE */
/**
 * Forward title/init/cleanup to UT_add_suite and return its suite handle.
 * Keep registration failure sticky even if a later API clears CUnit's error.
 */
UT_test_suite_t *__wrap_UT_add_suite(
    const char *title, UT_InitialiseFunction_t init, UT_CleanupFunction_t cleanup)
{
    UT_test_suite_t *suite = __real_UT_add_suite(title, init, cleanup);

    if (suite == NULL || CU_get_error() != CUE_SUCCESS)
    {
        registration_failed = true;
    }
    return suite;
}

/* PUBLIC_INTERFACE */
/**
 * Register function under title in suite and return its test handle or NULL.
 * Bypass ut-core's assertion on registration failure so main can report it.
 */
UT_test_t *__wrap_UT_add_test(UT_test_suite_t *suite, const char *title,
                            UT_TestFunction_t function)
{
    CU_pTest test = CU_add_test((CU_pSuite)suite, title, function);

    if (test == NULL || CU_get_error() != CUE_SUCCESS)
    {
        registration_failed = true;
    }
    return (UT_test_t *)test;
}

/* PUBLIC_INTERFACE */
/**
 * Retain run results before CUnit resets them, then destroy its registry.
 * This linker wrapper accepts no parameters and returns no value.
 */
void __wrap_CU_cleanup_registry(void)
{
    if (capturing_results)
    {
        const CU_RunSummary *summary = CU_get_run_summary();

        results_captured = true;
        execution_failed = execution_failed || CU_get_error() != CUE_SUCCESS;
        if (summary == NULL)
        {
            execution_failed = true;
        }
        else
        {
            tests_run += summary->nTestsRun;
            execution_failed = execution_failed || summary->nTestsFailed != 0U ||
                summary->nAssertsFailed != 0U || summary->nSuitesFailed != 0U ||
                summary->nFailureRecords != 0U;
            fprintf(stderr,
                    "DHCP_RESULT tests=%u failed_tests=%u failed_assertions=%u "
                    "failed_suites=%u failure_records=%u\n",
                    summary->nTestsRun, summary->nTestsFailed,
                    summary->nAssertsFailed, summary->nSuitesFailed,
                    summary->nFailureRecords);
        }
    }
    __real_CU_cleanup_registry();
}

/* PUBLIC_INTERFACE */
/**
 * Initialize, register and run the official DHCP tests.
 * @param argc Number of command-line arguments forwarded to ut-core.
 * @param argv ut-core options (-b basic, -a automated, -c console, -p profile).
 * @return EXIT_SUCCESS only for a nonempty successful run; EXIT_FAILURE on
 * initialization, registration, framework, suite or assertion failure.
 * ut-core retains its existing help handling.
 */
int main(int argc, char **argv)
{
    UT_status_t status;

    if (UT_init(argc, argv) != UT_STATUS_OK)
    {
        fputs("dhcp4_hal_test: framework initialization failed\n", stderr);
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }

    /* An intentionally inactive suite is a selection, not a test failure. */
    CU_set_fail_on_inactive(CU_FALSE);
    if (register_hal_l1_tests() != 0 || registration_failed ||
        CU_get_error() != CUE_SUCCESS || CU_get_registry() == NULL ||
        CU_get_registry()->uiNumberOfTests == 0U)
    {
        fputs("dhcp4_hal_test: test registration failed or empty\n", stderr);
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }

    capturing_results = true;
    status = UT_run_tests();
    capturing_results = false;
    /* Also release profiles on framework error paths; UT_exit is idempotent. */
    UT_exit();

    if (status != UT_STATUS_OK || !results_captured || execution_failed ||
        tests_run == 0U)
    {
        fprintf(stderr, "dhcp4_hal_test: run failed (tests executed: %u)\n",
                tests_run);
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
