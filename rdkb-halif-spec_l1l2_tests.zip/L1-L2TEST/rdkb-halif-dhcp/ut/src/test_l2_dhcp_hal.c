/* SPDX-License-Identifier: Apache-2.0 */
/*
 * Copyright 2023 RDK Management
 *
 * Linux model sequences, not hardware or DHCP-daemon conformance tests.
 * The public contract defines no lifecycle controls, cross-family aliasing,
 * cross-getter atomicity, general FSM graph, or address byte order.
 * Reset/load/fail-next, failed-output preservation and unused-slot clearing
 * below are PRIVATE MODEL policies. ERT 1..6 are observations, not transitions.
 *
 * test_register.c embeds these private callbacks because the existing build
 * explicitly enumerates source files. Standalone compilation emits no code,
 * avoiding duplicate registration if a downstream build discovers this file.
 */
#if defined(BUILD_LINUX) && defined(DHCP_L2_EMBEDDED)

#include <limits.h>
#include <stddef.h>
#include <string.h>
#include <ut.h>
#include <ut_log.h>
#include "dhcp4cApi.h"
#include "dhcpv4c_api.h"
#include "test_dhcp_fixture.h"

typedef struct {
    const char *label;
    dhcp_test_family_t family;
    dhcp_test_role_t role;
    int (*uint_get[DHCP_TEST_FIELD_COUNT])(unsigned int *);
    int (*int_get[DHCP_TEST_FIELD_COUNT])(int *);
    int (*name_get)(char *);
    int (*legacy_dns_get)(ipv4AddrList_t *);
    int (*newer_dns_get)(dhcpv4c_ip_list_t *);
} test_l2_api_t;

/* Typed pointers let the compiler reject mismatches; no public-structure casts. */
#define L2_FULL_API(prefix, title, family_key, role_key, role_name, legacy, newer) \
    { \
        .label = title, .family = family_key, .role = role_key, \
        .uint_get = { \
            [DHCP_TEST_LEASE_TIME] = prefix##_get_##role_name##_lease_time, \
            [DHCP_TEST_REMAIN_LEASE_TIME] = prefix##_get_##role_name##_remain_lease_time, \
            [DHCP_TEST_REMAIN_RENEW_TIME] = prefix##_get_##role_name##_remain_renew_time, \
            [DHCP_TEST_REMAIN_REBIND_TIME] = prefix##_get_##role_name##_remain_rebind_time, \
            [DHCP_TEST_IP_ADDR] = prefix##_get_##role_name##_ip_addr, \
            [DHCP_TEST_MASK] = prefix##_get_##role_name##_mask, \
            [DHCP_TEST_GW] = prefix##_get_##role_name##_gw, \
            [DHCP_TEST_DHCP_SVR] = prefix##_get_##role_name##_dhcp_svr \
        }, \
        .int_get = { \
            [DHCP_TEST_CONFIG_ATTEMPTS] = prefix##_get_##role_name##_config_attempts, \
            [DHCP_TEST_FSM_STATE] = prefix##_get_##role_name##_fsm_state \
        }, \
        .name_get = prefix##_get_##role_name##_ifname, \
        .legacy_dns_get = legacy, .newer_dns_get = newer \
    }

#ifndef NO_MTA_FEATURE_SUPPORT
#define L2_EMTA_API(prefix, title, family_key) \
    { \
        .label = title, .family = family_key, .role = DHCP_TEST_ROLE_EMTA, \
        .uint_get = { \
            [DHCP_TEST_REMAIN_LEASE_TIME] = prefix##_get_emta_remain_lease_time, \
            [DHCP_TEST_REMAIN_RENEW_TIME] = prefix##_get_emta_remain_renew_time, \
            [DHCP_TEST_REMAIN_REBIND_TIME] = prefix##_get_emta_remain_rebind_time \
        } \
    }
#endif

static const test_l2_api_t test_l2_apis[] = {
#ifdef DHCP4CAPI
    L2_FULL_API(dhcp4c, "legacy/ERT", DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                ert, dhcp4c_get_ert_dns_svrs, NULL),
    L2_FULL_API(dhcp4c, "legacy/ECM", DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                ecm, dhcp4c_get_ecm_dns_svrs, NULL),
#ifndef NO_MTA_FEATURE_SUPPORT
    L2_EMTA_API(dhcp4c, "legacy/eMTA", DHCP_TEST_FAMILY_LEGACY),
#endif
#endif
#ifdef DHCPV4C_API
    L2_FULL_API(dhcpv4c, "newer/ERT", DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                ert, NULL, dhcpv4c_get_ert_dns_svrs),
    L2_FULL_API(dhcpv4c, "newer/ECM", DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                ecm, NULL, dhcpv4c_get_ecm_dns_svrs),
#ifndef NO_MTA_FEATURE_SUPPORT
    L2_EMTA_API(dhcpv4c, "newer/eMTA", DHCP_TEST_FAMILY_NEWER),
#endif
#endif
};
#define L2_API_COUNT (sizeof(test_l2_apis) / sizeof(test_l2_apis[0]))

/** Limit traversal to fields actually exposed for the selected role. */
static int test_l2_supported(const test_l2_api_t *api, dhcp_test_field_t field)
{
    if (field == DHCP_TEST_IFNAME) return api->name_get != NULL;
    if (field == DHCP_TEST_DNS_SVRS)
    {
        return api->legacy_dns_get != NULL || api->newer_dns_get != NULL;
    }
    return api->uint_get[field] != NULL || api->int_get[field] != NULL;
}

/** Verify canaries or an unchanged failed name output byte by byte. */
static void test_l2_guard(const unsigned char *bytes, size_t length)
{
    size_t index;

    for (index = 0; index < length; ++index)
    {
        UT_ASSERT_EQUAL(bytes[index], 0xa5U);
    }
}

/** Select an independent expected member, never a provider readback. */
static unsigned int test_l2_expected_uint(const dhcp_test_snapshot_t *expected,
                                          dhcp_test_field_t field)
{
    switch (field)
    {
        case DHCP_TEST_LEASE_TIME: return expected->lease_time;
        case DHCP_TEST_REMAIN_LEASE_TIME: return expected->remain_lease_time;
        case DHCP_TEST_REMAIN_RENEW_TIME: return expected->remain_renew_time;
        case DHCP_TEST_REMAIN_REBIND_TIME: return expected->remain_rebind_time;
        case DHCP_TEST_IP_ADDR: return expected->ip_addr;
        case DHCP_TEST_MASK: return expected->mask;
        case DHCP_TEST_GW: return expected->gw;
        case DHCP_TEST_DHCP_SVR: return expected->dhcp_svr;
        default:
            UT_ASSERT_TRUE(0);
            return 0U;
    }
}

/*
 * Generate separately typed DNS checks. Validate count BEFORE indexing returned
 * entries; compare members, not padding. Inactive zeros are model-only policy.
 */
#define L2_DNS_CHECK(function, list_type, member) \
    /** Check typed DNS status, canaries and failure preservation. */ \
    static void function(int (*getter)(list_type *), \
                          const dhcp_test_snapshot_t *expected, int fail) \
    { \
        struct \
        { \
            unsigned char before[8]; \
            list_type list; \
            unsigned char after[8]; \
        } output; \
        int index; \
        int status; \
        memset(&output, 0xa5, sizeof(output)); \
        output.list.number = -73; \
        for (index = 0; index < DHCP_TEST_DNS_CAPACITY; ++index) \
        { \
            output.list.member[index] = UINT_MAX; \
        } \
        status = getter(&output.list); \
        UT_ASSERT_EQUAL(status, fail ? -1 : 0); \
        test_l2_guard(output.before, sizeof(output.before)); \
        test_l2_guard(output.after, sizeof(output.after)); \
        if (status != (fail ? -1 : 0)) return; \
        if (fail) \
        { \
            UT_ASSERT_EQUAL(output.list.number, -73); \
            for (index = 0; index < DHCP_TEST_DNS_CAPACITY; ++index) \
            { \
                UT_ASSERT_EQUAL(output.list.member[index], UINT_MAX); \
            } \
            return; \
        } \
        UT_ASSERT_TRUE(output.list.number >= 0 && \
                       output.list.number <= DHCP_TEST_DNS_CAPACITY); \
        if (output.list.number < 0 || \
            output.list.number > DHCP_TEST_DNS_CAPACITY) return; \
        UT_ASSERT_EQUAL(output.list.number, expected->dns.number); \
        for (index = 0; index < DHCP_TEST_DNS_CAPACITY; ++index) \
        { \
            unsigned int value = index < expected->dns.number ? \
                                 expected->dns.addrs[index] : 0U; \
            UT_ASSERT_EQUAL(output.list.member[index], value); \
        } \
    }

L2_DNS_CHECK(test_l2_legacy_dns, ipv4AddrList_t, addrList)
L2_DNS_CHECK(test_l2_newer_dns, dhcpv4c_ip_list_t, addrs)

/** Call a typed public getter and compare its output with the loaded fixture. */
static void test_l2_expect_field(const test_l2_api_t *api,
                                 dhcp_test_field_t field,
                                 const dhcp_test_snapshot_t *expected, int fail)
{
    int status;
    int wanted_status = fail ? -1 : 0;

    UT_LOG_DEBUG("Linux model: %s field=%d failure=%d",
                  api->label, (int)field, fail);
    if (api->uint_get[field] != NULL)
    {
        unsigned int wanted = test_l2_expected_uint(expected, field);
        unsigned int initial = wanted ^ UINT_MAX;
        unsigned int actual = initial;

        status = api->uint_get[field](&actual);
        UT_ASSERT_EQUAL(status, wanted_status);
        if (status == wanted_status)
        {
            UT_ASSERT_EQUAL(actual, fail ? initial : wanted);
        }
    }
    else if (api->int_get[field] != NULL)
    {
        int actual = INT_MIN;
        int wanted = field == DHCP_TEST_CONFIG_ATTEMPTS ?
                     expected->config_attempts : expected->fsm_state;

        status = api->int_get[field](&actual);
        UT_ASSERT_EQUAL(status, wanted_status);
        if (status == wanted_status)
        {
            UT_ASSERT_EQUAL(actual, fail ? INT_MIN : wanted);
        }
    }
    else if (field == DHCP_TEST_IFNAME && api->name_get != NULL)
    {
        struct {
            unsigned char before[8];
            char name[DHCP_TEST_IFNAME_SIZE];
            unsigned char after[8];
        } output;

        memset(&output, 0xa5, sizeof(output));
        status = api->name_get(output.name);
        UT_ASSERT_EQUAL(status, wanted_status);
        test_l2_guard(output.before, sizeof(output.before));
        test_l2_guard(output.after, sizeof(output.after));
        if (status != wanted_status) return;
        if (fail)
        {
            test_l2_guard((const unsigned char *)output.name, sizeof(output.name));
        }
        else
        {
            UT_ASSERT_TRUE(memchr(output.name, '\0', sizeof(output.name)) != NULL);
            UT_ASSERT_EQUAL(memcmp(output.name, expected->ifname,
                                    sizeof(output.name)), 0);
        }
    }
    else if (field == DHCP_TEST_DNS_SVRS && api->legacy_dns_get != NULL)
    {
        test_l2_legacy_dns(api->legacy_dns_get, expected, fail);
    }
    else if (field == DHCP_TEST_DNS_SVRS && api->newer_dns_get != NULL)
    {
        test_l2_newer_dns(api->newer_dns_get, expected, fail);
    }
    else
    {
        UT_ASSERT_TRUE(0);
    }
}

/** Traverse all supported fields in either getter order. */
static void test_l2_expect_snapshot(const test_l2_api_t *api,
                                    const dhcp_test_snapshot_t *expected,
                                    int reverse)
{
    int offset;

    for (offset = 0; offset < DHCP_TEST_FIELD_COUNT; ++offset)
    {
        dhcp_test_field_t field = (dhcp_test_field_t)(
            reverse ? DHCP_TEST_FIELD_COUNT - 1 - offset : offset);

        if (test_l2_supported(api, field))
        {
            test_l2_expect_field(api, field, expected, 0);
        }
    }
}

/** Load independent initial observations for every enabled family and role. */
static int test_l2_load_all(dhcp_test_snapshot_t expected[L2_API_COUNT],
                            unsigned int seed)
{
    size_t index;

    for (index = 0; index < L2_API_COUNT; ++index)
    {
        const test_l2_api_t *api = &test_l2_apis[index];

        expected[index] = test_dhcp_fixture(api->family, api->role, seed);
        if (test_dhcp_load(api->family, api->role, &expected[index]) != 0) return -1;
    }
    return 0;
}

/** Verify NULL does not consume the failure pending for this exact getter. */
static void test_l2_null_read(const test_l2_api_t *api, dhcp_test_field_t field)
{
    if (api->uint_get[field] != NULL)
    {
        UT_ASSERT_EQUAL(api->uint_get[field](NULL), -1);
    }
    else if (api->int_get[field] != NULL)
    {
        UT_ASSERT_EQUAL(api->int_get[field](NULL), -1);
    }
    else if (field == DHCP_TEST_IFNAME)
    {
        UT_ASSERT_EQUAL(api->name_get(NULL), -1);
    }
    else if (api->legacy_dns_get != NULL)
    {
        UT_ASSERT_EQUAL(api->legacy_dns_get(NULL), -1);
    }
    else
    {
        UT_ASSERT_EQUAL(api->newer_dns_get(NULL), -1);
    }
}

/** Reset, copy caller storage, reload, then clear all data and pending failures. */
static void test_l2_model_lifecycle(void)
{
    dhcp_test_snapshot_t expected[L2_API_COUNT];
    const dhcp_test_snapshot_t empty = {0};
    size_t index;
    int field;

    dhcp_test_model_reset();
    for (index = 0; index < L2_API_COUNT; ++index)
    {
        test_l2_expect_snapshot(&test_l2_apis[index], &empty, 0);
    }
    if (test_l2_load_all(expected, 3U) != 0) return;
    for (index = 0; index < L2_API_COUNT; ++index)
    {
        const test_l2_api_t *api = &test_l2_apis[index];
        dhcp_test_snapshot_t caller = expected[index];

        if (test_dhcp_load(api->family, api->role, &caller) != 0) return;
        memset(&caller, 0, sizeof(caller));
        test_l2_expect_snapshot(api, &expected[index], 1);
        expected[index] = test_dhcp_fixture(api->family, api->role, 29U);
        if (test_dhcp_load(api->family, api->role, &expected[index]) != 0) return;
        test_l2_expect_snapshot(api, &expected[index], 0);
        for (field = 0; field < DHCP_TEST_FIELD_COUNT; ++field)
        {
            if (test_l2_supported(api, (dhcp_test_field_t)field))
            {
                UT_ASSERT_EQUAL(dhcp_test_model_fail_next(api->family, api->role,
                                  (dhcp_test_field_t)field), 0);
            }
        }
    }
    dhcp_test_model_reset();
    for (index = 0; index < L2_API_COUNT; ++index)
    {
        /* Zero FSM here is reset policy, not a valid vendor ERT-state claim. */
        test_l2_expect_snapshot(&test_l2_apis[index], &empty, 1);
    }
    dhcp_test_model_reset();
}

/** Repeated/permuted reads must not mutate fields or advance model timers. */
static void test_l2_getter_ordering(void)
{
    dhcp_test_snapshot_t expected[L2_API_COUNT];
    size_t offset;
    int pass;

    dhcp_test_model_reset();
    if (test_l2_load_all(expected, 11U) != 0) return;
    for (pass = 0; pass < 4; ++pass)
    {
        for (offset = 0; offset < L2_API_COUNT; ++offset)
        {
            size_t index = pass % 2 ? L2_API_COUNT - 1U - offset : offset;

            test_l2_expect_snapshot(&test_l2_apis[index], &expected[index], pass % 2);
        }
    }
    dhcp_test_model_reset();
}

/** Update each role/family independently while checking every other fixture. */
static void test_l2_role_family_isolation(void)
{
    dhcp_test_snapshot_t expected[L2_API_COUNT];
    size_t target;
    size_t observer;

    dhcp_test_model_reset();
    if (test_l2_load_all(expected, 13U) != 0) return;
    for (target = 0; target < L2_API_COUNT; ++target)
    {
        const test_l2_api_t *api = &test_l2_apis[target];

        expected[target] = test_dhcp_fixture(api->family, api->role,
                                             31U + (unsigned int)target);
        if (test_dhcp_load(api->family, api->role, &expected[target]) != 0) return;
        for (observer = 0; observer < L2_API_COUNT; ++observer)
        {
            test_l2_expect_snapshot(&test_l2_apis[observer], &expected[observer], 1);
        }
    }
    dhcp_test_model_reset();
}

/**
 * Check finite loaded observations, including zero timers and the documented
 * legacy ERT lease maximum. Deliberately permuted ERT 1..6 values are NOT a
 * transition graph: model loads do not represent public lifecycle operations.
 */
static void test_l2_finite_timers_and_ert_fsm_observations(void)
{
    const struct {
        unsigned int lease;
        unsigned int remaining;
        unsigned int renew;
        unsigned int rebind;
        int ert_state;
    } observations[] = {
        {604800U, 604799U, 302400U, 529200U, 5},
        {7200U, 0U, 0U, 0U, 1},
        {7200U, 3600U, 0U, 1800U, 6},
        {120U, 120U, 60U, 100U, 3},
        {7200U, 900U, 0U, 0U, 4},
        {60U, 59U, 30U, 50U, 2}
    };
    size_t index;
    size_t step;

    dhcp_test_model_reset();
    for (index = 0; index < L2_API_COUNT; ++index)
    {
        const test_l2_api_t *api = &test_l2_apis[index];

        for (step = 0; step < sizeof(observations) / sizeof(observations[0]); ++step)
        {
            dhcp_test_snapshot_t expected = test_dhcp_fixture(api->family, api->role, 17U);

            expected.lease_time = observations[step].lease;
            expected.remain_lease_time = observations[step].remaining;
            expected.remain_renew_time = observations[step].renew;
            expected.remain_rebind_time = observations[step].rebind;
            if (api->role == DHCP_TEST_ROLE_ERT)
            {
                expected.fsm_state = observations[step].ert_state;
            }
            if (test_dhcp_load(api->family, api->role, &expected) != 0) return;
            test_l2_expect_snapshot(api, &expected, (int)(step % 2U));
        }
    }
    dhcp_test_model_reset();
}

/** Check changing DNS sizes, stale-slot clearing and atomic invalid-load rejection. */
static void test_l2_dns_list_changes(void)
{
    const int counts[] = {4, 1, 0, 4, 0, 1};
    size_t index;
    size_t step;

    dhcp_test_model_reset();
    for (index = 0; index < L2_API_COUNT; ++index)
    {
        const test_l2_api_t *api = &test_l2_apis[index];

        if (!test_l2_supported(api, DHCP_TEST_DNS_SVRS)) continue;
        for (step = 0; step < sizeof(counts) / sizeof(counts[0]); ++step)
        {
            dhcp_test_snapshot_t expected = test_dhcp_fixture(api->family, api->role,
                                                               19U + (unsigned int)step);
            dhcp_test_snapshot_t invalid;

            expected.dns.number = counts[step];
            if (test_dhcp_load(api->family, api->role, &expected) != 0) return;
            test_l2_expect_snapshot(api, &expected, 0);
            invalid = expected;
            invalid.dns.number = -1;
            UT_ASSERT_EQUAL(dhcp_test_model_load(api->family, api->role, &invalid), -1);
            test_l2_expect_snapshot(api, &expected, 1);
            invalid.dns.number = DHCP_TEST_DNS_CAPACITY + 1;
            UT_ASSERT_EQUAL(dhcp_test_model_load(api->family, api->role, &invalid), -1);
            test_l2_expect_snapshot(api, &expected, 0);
        }
    }
    dhcp_test_model_reset();
}

/** Check 63 characters plus NUL, long-to-short/empty names and caller ownership. */
static void test_l2_interface_name_boundaries(void)
{
    const size_t lengths[] = {63U, 1U, 0U, 62U, 3U};
    size_t index;
    size_t step;

    dhcp_test_model_reset();
    for (index = 0; index < L2_API_COUNT; ++index)
    {
        const test_l2_api_t *api = &test_l2_apis[index];

        if (api->name_get == NULL) continue;
        for (step = 0; step < sizeof(lengths) / sizeof(lengths[0]); ++step)
        {
            dhcp_test_snapshot_t expected = test_dhcp_fixture(api->family, api->role, 23U);
            dhcp_test_snapshot_t caller;

            /* Caller bytes after NUL must not become part of the model name. */
            memset(expected.ifname, 'x', sizeof(expected.ifname));
            expected.ifname[lengths[step]] = '\0';
            caller = expected;
            if (test_dhcp_load(api->family, api->role, &caller) != 0) return;
            memset(expected.ifname + lengths[step], 0,
                    sizeof(expected.ifname) - lengths[step]);
            memset(caller.ifname, 'y', sizeof(caller.ifname));
            test_l2_expect_snapshot(api, &expected, 0);
            /* Exactly 64 non-NUL bytes must be rejected without changing state. */
            UT_ASSERT_EQUAL(dhcp_test_model_load(api->family, api->role, &caller), -1);
            test_l2_expect_snapshot(api, &expected, 1);
        }
    }
    dhcp_test_model_reset();
}

/**
 * For every enabled getter: arm failure, load replacement, read other fields
 * and roles/families, try NULL, fail once with unchanged output, then recover.
 */
static void test_l2_retrieval_failure_and_recovery(void)
{
    dhcp_test_snapshot_t expected[L2_API_COUNT];
    size_t target;
    size_t observer;
    int field_number;

    dhcp_test_model_reset();
    if (test_l2_load_all(expected, 37U) != 0) return;
    for (target = 0; target < L2_API_COUNT; ++target)
    {
        const test_l2_api_t *api = &test_l2_apis[target];

        for (field_number = 0; field_number < DHCP_TEST_FIELD_COUNT; ++field_number)
        {
            dhcp_test_field_t field = (dhcp_test_field_t)field_number;
            int other;

            if (!test_l2_supported(api, field)) continue;
            UT_ASSERT_EQUAL(dhcp_test_model_fail_next(api->family, api->role, field), 0);
            expected[target] = test_dhcp_fixture(api->family, api->role,
                                                 50U + (unsigned int)field_number);
            if (test_dhcp_load(api->family, api->role, &expected[target]) != 0) return;
            for (other = 0; other < DHCP_TEST_FIELD_COUNT; ++other)
            {
                if (other != field_number &&
                    test_l2_supported(api, (dhcp_test_field_t)other))
                {
                    test_l2_expect_field(api, (dhcp_test_field_t)other,
                                          &expected[target], 0);
                }
            }
            for (observer = 0; observer < L2_API_COUNT; ++observer)
            {
                if (observer != target)
                {
                    test_l2_expect_snapshot(&test_l2_apis[observer], &expected[observer], 1);
                }
            }
            test_l2_null_read(api, field);
            test_l2_expect_field(api, field, &expected[target], 1);
            test_l2_expect_field(api, field, &expected[target], 0);
            test_l2_expect_snapshot(api, &expected[target], 1);
        }
    }
    dhcp_test_model_reset();
}

/** Register all Linux scenarios and propagate any failed suite/case addition. */
static int test_dhcp_hal_l2_register(void)
{
    const struct {
        const char *name;
        UT_TestFunction_t function;
    } cases[] = {
        {"l2_model_lifecycle", test_l2_model_lifecycle},
        {"l2_getter_ordering", test_l2_getter_ordering},
        {"l2_role_family_isolation", test_l2_role_family_isolation},
        {"l2_finite_timers_and_ert_fsm_observations",
          test_l2_finite_timers_and_ert_fsm_observations},
        {"l2_dns_list_changes", test_l2_dns_list_changes},
        {"l2_interface_name_boundaries", test_l2_interface_name_boundaries},
        {"l2_retrieval_failure_and_recovery", test_l2_retrieval_failure_and_recovery}
    };
    UT_test_suite_t *suite = UT_add_suite("[L2 DHCP Linux model]", NULL, test_dhcp_cleanup);
    size_t index;

    if (suite == NULL) return -1;
    for (index = 0; index < sizeof(cases) / sizeof(cases[0]); ++index)
    {
        if (UT_add_test(suite, cases[index].name, cases[index].function) == NULL)
        {
            return -1;
        }
    }
    return 0;
}
#endif
