/* SPDX-License-Identifier: Apache-2.0 */
/*
 * Copyright 2023 RDK Management
 * Test-only Linux observations. No vendor lifecycle, address byte order,
 * sentinel, or cross-getter atomicity is implied by these fixtures.
 */
#ifndef TEST_DHCP_FIXTURE_H
#define TEST_DHCP_FIXTURE_H

#include <stdio.h>
#include <string.h>
#include <ut.h>
#include "dhcp_test_model.h"

/** Construct distinct, finite observations without consulting a getter. */
static inline dhcp_test_snapshot_t test_dhcp_fixture(
    dhcp_test_family_t family, dhcp_test_role_t role, unsigned int seed)
{
    dhcp_test_snapshot_t snapshot = {0};
    unsigned int tag = 100U * (unsigned int)family +
                       10U * (unsigned int)role + seed;
    int index;

    snapshot.lease_time = 10000U + tag;
    snapshot.remain_lease_time = 8000U + tag;
    snapshot.remain_renew_time = 3000U + tag;
    snapshot.remain_rebind_time = 6000U + tag;
    snapshot.config_attempts = 7 + (int)tag;
    (void)snprintf(snapshot.ifname, sizeof(snapshot.ifname), "test-%u-%u-%u",
                   (unsigned int)family, (unsigned int)role, seed);
    snapshot.fsm_state = role == DHCP_TEST_ROLE_ERT ? 5 : 42 + (int)tag;
    /* Opaque, distinct words: do not convert or prescribe host/network order. */
    snapshot.ip_addr = 0x12345600U + tag;
    snapshot.mask = 0xfefdfc00U + tag;
    snapshot.gw = 0x23456700U + tag;
    snapshot.dhcp_svr = 0x34567800U + tag;
    snapshot.dns.number = DHCP_TEST_DNS_CAPACITY;
    for (index = 0; index < DHCP_TEST_DNS_CAPACITY; ++index)
    {
        snapshot.dns.addrs[index] = 0x45678900U + tag + (unsigned int)index;
    }
    return snapshot;
}

/** Assert fixture setup independently of the public getter under test. */
static inline int test_dhcp_load(dhcp_test_family_t family,
                                 dhcp_test_role_t role,
                                 const dhcp_test_snapshot_t *snapshot)
{
    int status = dhcp_test_model_load(family, role, snapshot);

    UT_ASSERT_EQUAL(status, DHCP_TEST_SUCCESS);
    return status;
}

/** Suite cleanup also runs after an assertion aborts a test. */
static inline int test_dhcp_cleanup(void)
{
    dhcp_test_model_reset();
    return 0;
}
#endif
