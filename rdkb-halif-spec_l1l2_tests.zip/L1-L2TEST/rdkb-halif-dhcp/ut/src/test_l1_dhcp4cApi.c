/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file test_l1_dhcp4cApi.c
 * Legacy L1 tests: exact Linux fixtures, or portable vendor status/NULL/bounds.
 * References: include/dhcp4cApi.h; docs/pages/DHCPv4ChalSpec.md.
 * No address scratch globals or byte-order assumptions are needed.
 */
#include "dhcp4cApi.h"

#define TEST_L1_FAMILY DHCP_TEST_FAMILY_LEGACY
#define TEST_L1_DNS_TYPE ipv4AddrList_t
#define TEST_L1_DNS_ADDRS addrList
#define TEST_L1_DNS_CAPACITY MAX_IPV4_ADDR_LIST_NUMBER
#include "test_dhcp_l1.h"

/* Retain historical names so existing case selections continue to work. */
#define LEGACY_UINT_CASES(X) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ert_lease_time, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ert_lease_time, \
      dhcp4c_get_ert_lease_time, DHCP_TEST_ROLE_ERT, lease_time) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ert_remain_lease_time, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ert_remain_lease_time, \
      dhcp4c_get_ert_remain_lease_time, DHCP_TEST_ROLE_ERT, remain_lease_time) \
    X(l1_dhcp4cApi_hal_positive1_get_ert_remain_renew_time, \
      l1_dhcp4cApi_hal_negative1_get_ert_remain_renew_time, \
      dhcp4c_get_ert_remain_renew_time, DHCP_TEST_ROLE_ERT, remain_renew_time) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ert_remain_rebind_time, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ert_remain_rebind_time, \
      dhcp4c_get_ert_remain_rebind_time, DHCP_TEST_ROLE_ERT, remain_rebind_time) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ert_ip_addr, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ert_ip_addr, \
      dhcp4c_get_ert_ip_addr, DHCP_TEST_ROLE_ERT, ip_addr) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ert_mask, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ert_mask, \
      dhcp4c_get_ert_mask, DHCP_TEST_ROLE_ERT, mask) \
    X(l1_dhcp4cApi_hal_positive1_get_ert_gw, \
      l1_dhcp4cApi_hal_negative1_get_ert_gw, \
      dhcp4c_get_ert_gw, DHCP_TEST_ROLE_ERT, gw) \
    X(l1_dhcp4cApi_hal_positive1_get_ert_dhcp_svr, \
      l1_dhcp4cApi_hal_negative1_get_ert_dhcp_svr, \
      dhcp4c_get_ert_dhcp_svr, DHCP_TEST_ROLE_ERT, dhcp_svr) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ecm_lease_time, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ecm_lease_time, \
      dhcp4c_get_ecm_lease_time, DHCP_TEST_ROLE_ECM, lease_time) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ecm_remain_lease_time, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ecm_remain_lease_time, \
      dhcp4c_get_ecm_remain_lease_time, DHCP_TEST_ROLE_ECM, remain_lease_time) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ecm_remain_renew_time, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ecm_remain_renew_time, \
      dhcp4c_get_ecm_remain_renew_time, DHCP_TEST_ROLE_ECM, remain_renew_time) \
    X(l1_dhcp4c_get_ecm_remain_rebind_time_positive1, \
      l1_dhcp4c_get_ecm_remain_rebind_time_negative1, \
      dhcp4c_get_ecm_remain_rebind_time, DHCP_TEST_ROLE_ECM, remain_rebind_time) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ecm_ip_addr, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ecm_ip_addr, \
      dhcp4c_get_ecm_ip_addr, DHCP_TEST_ROLE_ECM, ip_addr) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ecm_mask, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ecm_mask, \
      dhcp4c_get_ecm_mask, DHCP_TEST_ROLE_ECM, mask) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ecm_gw, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ecm_gw, \
      dhcp4c_get_ecm_gw, DHCP_TEST_ROLE_ECM, gw) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ecm_dhcp_svr, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ecm_dhcp_svr, \
      dhcp4c_get_ecm_dhcp_svr, DHCP_TEST_ROLE_ECM, dhcp_svr)

#define LEGACY_INT_CASES(X) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ert_config_attempts, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ert_config_attempts, \
      dhcp4c_get_ert_config_attempts, DHCP_TEST_ROLE_ERT, config_attempts, TEST_L1_NO_RANGE) \
    X(l1_dhcp4cApi_hal_positive1_GetErtFsmState, \
      l1_dhcp4cApi_hal_negative1_GetErtFsmState_NullPointer, \
      dhcp4c_get_ert_fsm_state, DHCP_TEST_ROLE_ERT, fsm_state, TEST_L1_ERT_RANGE) \
    X(l1_dhcp4cApi_hal_positive1_get_ecm_config_attempts, \
      l1_dhcp4cApi_hal_negative1_get_ecm_config_attempts, \
      dhcp4c_get_ecm_config_attempts, DHCP_TEST_ROLE_ECM, config_attempts, TEST_L1_NO_RANGE) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ecm_fsm_state, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ecm_fsm_state, \
      dhcp4c_get_ecm_fsm_state, DHCP_TEST_ROLE_ECM, fsm_state, TEST_L1_NO_RANGE)

#define LEGACY_NAME_CASES(X) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ert_ifname, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ert_ifname, \
      dhcp4c_get_ert_ifname, DHCP_TEST_ROLE_ERT) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_ecm_ifname, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ecm_ifname, \
      dhcp4c_get_ecm_ifname, DHCP_TEST_ROLE_ECM)

#define LEGACY_DNS_CASES(X) \
    X(l1_dhcp4cApi_hal_positive1_get_ert_dns_svrs, \
      l1_dhcp4cApi_hal_negative1_get_ert_dns_svrs, \
      dhcp4c_get_ert_dns_svrs, DHCP_TEST_ROLE_ERT) \
    X(l1_dhcp4cApi_hal_positive2_dhcp4c_get_ecm_dns_svrs, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_ecm_dns_svrs, \
      dhcp4c_get_ecm_dns_svrs, DHCP_TEST_ROLE_ECM)

LEGACY_UINT_CASES(TEST_L1_UINT_PAIR)
LEGACY_INT_CASES(TEST_L1_INT_PAIR)
LEGACY_NAME_CASES(TEST_L1_NAME_PAIR)
LEGACY_DNS_CASES(TEST_L1_DNS_PAIR)

#ifndef NO_MTA_FEATURE_SUPPORT
#define LEGACY_EMTA_CASES(X) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_emta_remain_lease_time, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_emta_remain_lease_time, \
      dhcp4c_get_emta_remain_lease_time, DHCP_TEST_ROLE_EMTA, remain_lease_time) \
    X(l1_dhcp4cApi_hal_positive1_get_emta_remain_renew_time, \
      l1_dhcp4cApi_hal_negative1_get_emta_remain_renew_time, \
      dhcp4c_get_emta_remain_renew_time, DHCP_TEST_ROLE_EMTA, remain_renew_time) \
    X(l1_dhcp4cApi_hal_positive1_dhcp4c_get_emta_remain_rebind_time, \
      l1_dhcp4cApi_hal_negative1_dhcp4c_get_emta_remain_rebind_time, \
      dhcp4c_get_emta_remain_rebind_time, DHCP_TEST_ROLE_EMTA, remain_rebind_time)
LEGACY_EMTA_CASES(TEST_L1_UINT_PAIR)
#endif

/** Verify literal public enum values, independently of the private model. */
static void test_l1_dhcp4c_contract_constants(void)
{
    const enum DHCPC_CMD commands[] = {
        DHCPC_CMD_LEASE_TIME, DHCPC_CMD_LEASE_TIME_REMAIN,
        DHCPC_CMD_RENEW_TIME_REMAIN, DHCPC_CMD_REBIND_TIME_REMAIN,
        DHCPC_CMD_CONFIG_ATTEMPTS, DHCPC_CMD_GET_IFNAME, DHCPC_CMD_FSM_STATE,
        DHCPC_CMD_IP_ADDR, DHCPC_CMD_IP_MASK, DHCPC_CMD_ROUTERS,
        DHCPC_CMD_DNS_SVRS, DHCPC_CMD_DHCP_SVR
    };
    size_t index;
    ipv4AddrList_t list = {0};

    UT_ASSERT_EQUAL(sizeof(commands) / sizeof(commands[0]), 12U);
    for (index = 0; index < sizeof(commands) / sizeof(commands[0]); ++index)
    {
        UT_ASSERT_EQUAL(commands[index], (enum DHCPC_CMD)index);
    }
    UT_ASSERT_EQUAL(DHCPC_CMD_MAX, 12);
    UT_ASSERT_EQUAL(DHCPC_ECM, 0);
    UT_ASSERT_EQUAL(DHCPC_EROUTER, 1);
#ifndef NO_MTA_FEATURE_SUPPORT
    UT_ASSERT_EQUAL(DHCPC_EMTA, 2);
#endif
    UT_ASSERT_EQUAL(MAX_IPV4_ADDR_LIST_NUMBER, 4);
    UT_ASSERT_EQUAL(sizeof(list.addrList) / sizeof(list.addrList[0]), 4U);
    UT_ASSERT_TRUE(_Generic(list.number, int: 1, default: 0));
    UT_ASSERT_TRUE(_Generic(list.addrList[0], unsigned int: 1, default: 0));
}

/* PUBLIC_INTERFACE */
/** Register legacy L1 tests; return 0, or -1 on any registration failure. */
int test_dhcp4cApi_hal_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite("[L1 dhcp4cApi]", NULL, TEST_L1_CLEANUP);

    if (suite == NULL) return -1;
    LEGACY_UINT_CASES(TEST_L1_REGISTER_PAIR)
    LEGACY_INT_CASES(TEST_L1_REGISTER_PAIR)
    LEGACY_NAME_CASES(TEST_L1_REGISTER_PAIR)
    LEGACY_DNS_CASES(TEST_L1_REGISTER_PAIR)
#ifndef NO_MTA_FEATURE_SUPPORT
    LEGACY_EMTA_CASES(TEST_L1_REGISTER_PAIR)
#endif
    if (UT_add_test(suite, "l1_dhcp4c_contract_constants",
                    test_l1_dhcp4c_contract_constants) == NULL) return -1;
    return 0;
}
