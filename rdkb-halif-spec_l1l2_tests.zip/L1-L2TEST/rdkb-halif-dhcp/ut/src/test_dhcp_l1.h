/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright 2023 RDK Management. Private typed native L1 test helpers. */
#ifndef TEST_DHCP_L1_H
#define TEST_DHCP_L1_H

#include <limits.h>
#include <stddef.h>
#include <string.h>
#include <ut.h>

#ifdef BUILD_LINUX
#include "test_dhcp_fixture.h"
#define TEST_L1_PREPARE(role) \
    dhcp_test_snapshot_t expected = test_dhcp_fixture(TEST_L1_FAMILY, role, 7U); \
    dhcp_test_model_reset(); \
    if (test_dhcp_load(TEST_L1_FAMILY, role, &expected) != 0) return
#define TEST_L1_UINT_INITIAL(member) (expected.member ^ UINT_MAX)
#define TEST_L1_EXPECT(member) UT_ASSERT_EQUAL(actual, expected.member)
#define TEST_L1_RESET() dhcp_test_model_reset()
#define TEST_L1_CLEANUP test_dhcp_cleanup
#else
/* Vendor builds must not depend on or assert private model fixture policies. */
#define TEST_L1_PREPARE(role) ((void)0)
#define TEST_L1_UINT_INITIAL(member) UINT_MAX
#define TEST_L1_EXPECT(member) ((void)0)
#define TEST_L1_RESET() ((void)0)
#define TEST_L1_CLEANUP NULL
#endif

#define TEST_L1_NO_RANGE(value) ((void)(value))
#define TEST_L1_ERT_RANGE(value) \
    do { UT_ASSERT_TRUE((value) >= 1 && (value) <= 6); } while (0)

/** Compare canaries without interpreting untrusted output as a string. */
static inline void test_l1_guard(const unsigned char *bytes, size_t length)
{
    size_t index;

    for (index = 0; index < length; ++index)
    {
        UT_ASSERT_EQUAL(bytes[index], 0xa5U);
    }
}

/* Each private callback initializes its output and resets independently. */
#define TEST_L1_UINT_PAIR(positive, negative, getter, role, member) \
    /** Check status and the loaded unsigned observation. */ \
    static void test_##positive(void) \
    { \
        TEST_L1_PREPARE(role); \
        unsigned int actual = TEST_L1_UINT_INITIAL(member); \
        int status = getter(&actual); \
        UT_ASSERT_EQUAL(status, 0); \
        if (status == 0) { TEST_L1_EXPECT(member); } \
        TEST_L1_RESET(); \
    } \
    /** Check NULL without relying on a preceding positive case. */ \
    static void test_##negative(void) \
    { \
        TEST_L1_RESET(); \
        UT_ASSERT_EQUAL(getter(NULL), -1); \
        TEST_L1_RESET(); \
    }

#define TEST_L1_INT_PAIR(positive, negative, getter, role, member, range_check) \
    /** Check status, signed observation and any documented range. */ \
    static void test_##positive(void) \
    { \
        TEST_L1_PREPARE(role); \
        int actual = INT_MIN; \
        int status = getter(&actual); \
        UT_ASSERT_EQUAL(status, 0); \
        if (status == 0) { TEST_L1_EXPECT(member); range_check(actual); } \
        TEST_L1_RESET(); \
    } \
    /** Check NULL rejection. */ \
    static void test_##negative(void) \
    { \
        TEST_L1_RESET(); \
        UT_ASSERT_EQUAL(getter(NULL), -1); \
        TEST_L1_RESET(); \
    }

#ifdef BUILD_LINUX
#define TEST_L1_EXPECT_NAME() \
    UT_ASSERT_EQUAL(strcmp(output.name, expected.ifname), 0)
#define TEST_L1_EXPECT_DNS() \
    do \
    { \
        UT_ASSERT_EQUAL(output.list.number, expected.dns.number); \
        for (index = 0; index < output.list.number; ++index) \
        { \
            UT_ASSERT_EQUAL(output.list.TEST_L1_DNS_ADDRS[index], \
                            expected.dns.addrs[index]); \
        } \
    } while (0)
#else
#define TEST_L1_EXPECT_NAME() ((void)0)
#define TEST_L1_EXPECT_DNS() ((void)0)
#endif

#define TEST_L1_NAME_PAIR(positive, negative, getter, role) \
    /** Check a full 64-byte output buffer and adjacent canaries. */ \
    static void test_##positive(void) \
    { \
        TEST_L1_PREPARE(role); \
        struct \
        { \
            unsigned char before[8]; \
            char name[64]; \
            unsigned char after[8]; \
        } output; \
        int status; \
        memset(&output, 0xa5, sizeof(output)); \
        status = getter(output.name); \
        UT_ASSERT_EQUAL(status, 0); \
        test_l1_guard(output.before, sizeof(output.before)); \
        test_l1_guard(output.after, sizeof(output.after)); \
        if (status == 0) \
        { \
            const char *end = memchr(output.name, '\0', sizeof(output.name)); \
            UT_ASSERT_TRUE(end != NULL); \
            if (end != NULL) { TEST_L1_EXPECT_NAME(); } \
        } \
        TEST_L1_RESET(); \
    } \
    /** Check name NULL rejection. */ \
    static void test_##negative(void) \
    { \
        TEST_L1_RESET(); \
        UT_ASSERT_EQUAL(getter(NULL), -1); \
        TEST_L1_RESET(); \
    }

#define TEST_L1_DNS_PAIR(positive, negative, getter, role) \
    /** Check a typed DNS result; validate count before indexing output. */ \
    static void test_##positive(void) \
    { \
        TEST_L1_PREPARE(role); \
        struct \
        { \
            unsigned char before[8]; \
            TEST_L1_DNS_TYPE list; \
            unsigned char after[8]; \
        } output; \
        int index; \
        int status; \
        memset(&output, 0xa5, sizeof(output)); \
        output.list.number = -1; \
        for (index = 0; index < TEST_L1_DNS_CAPACITY; ++index) \
        { \
            output.list.TEST_L1_DNS_ADDRS[index] = UINT_MAX; \
        } \
        status = getter(&output.list); \
        UT_ASSERT_EQUAL(status, 0); \
        test_l1_guard(output.before, sizeof(output.before)); \
        test_l1_guard(output.after, sizeof(output.after)); \
        if (status == 0) \
        { \
            UT_ASSERT_TRUE(output.list.number >= 0 && \
                           output.list.number <= TEST_L1_DNS_CAPACITY); \
            if (output.list.number >= 0 && \
                output.list.number <= TEST_L1_DNS_CAPACITY) \
            { \
                TEST_L1_EXPECT_DNS(); \
            } \
        } \
        TEST_L1_RESET(); \
    } \
    /** Check typed DNS NULL rejection. */ \
    static void test_##negative(void) \
    { \
        TEST_L1_RESET(); \
        UT_ASSERT_EQUAL(getter(NULL), -1); \
        TEST_L1_RESET(); \
    }

/* Propagate the first failed registration, including additions within pairs. */
#define TEST_L1_REGISTER_PAIR(positive, negative, ...) \
    do \
    { \
        if (UT_add_test(suite, #positive, test_##positive) == NULL) return -1; \
        if (UT_add_test(suite, #negative, test_##negative) == NULL) return -1; \
    } while (0);

#endif
