#!/usr/bin/env bash

# *
# * If not stated otherwise in this file or this component's LICENSE file the
# * following copyright and licenses apply:
# *
# * Copyright 2023 RDK Management
# *
# * Licensed under the Apache License, Version 2.0 (the "License");
# * you may not use this file except in compliance with the License.
# * You may obtain a copy of the License at
# *
# * http://www.apache.org/licenses/LICENSE-2.0
# *
# * Unless required by applicable law or agreed to in writing, software
# * distributed under the License is distributed on an "AS IS" BASIS,
# * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# * See the License for the specific language governing permissions and
# * limitations under the License.
# *

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd) || exit 1
cd -- "$SCRIPT_DIR" || exit $?

# Preserve the supported framework pin; never switch an existing checkout.
UT_CORE_PROJECT_VERSION=${UT_CORE_PROJECT_VERSION:-3.1.1}
if [[ ! -d ut-core ]]; then
    git clone -- git@github.com:rdkcentral/ut-core.git ut-core || exit $?
    git -C ut-core checkout "$UT_CORE_PROJECT_VERSION" || exit $?
fi

# Normal builds use existing dependencies read-only. Bootstrap missing official
# dependencies without patching their sources or invoking a destructive clean.
TARGET_VALUE=linux
for argument in "$@"; do
    case "$argument" in
        TARGET=*) TARGET_VALUE=${argument#TARGET=} ;;
    esac
done
TARGET_VALUE=${TARGET_VALUE:-linux}
CONTROL_DIR="$SCRIPT_DIR/ut-core/framework/ut-control"
if [[ ! -r ut-core/framework/CUnit-2.1-3/CUnit/Headers/CUnit.h ||
      ! -r "$CONTROL_DIR/lib/libut_control.so" ||
      ! -r "$CONTROL_DIR/framework/libwebsockets-4.3.3/build/lib/libwebsockets.so" ]]; then
    (cd -- ut-core && bash -e ./build.sh "TARGET=$TARGET_VALUE") || exit $?
    make -C "$CONTROL_DIR" "TARGET=$TARGET_VALUE" || exit $?
fi

exec make -C "$SCRIPT_DIR" -f Makefile "$@"
