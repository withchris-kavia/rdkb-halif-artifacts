#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Focused provider regression; not the independent full-suite build matrix.
set -euo pipefail

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
SCRATCH=$(mktemp -d "${TMPDIR:-/tmp}/dhcp-model.XXXXXXXX")
trap 'rm -rf -- "$SCRATCH"' EXIT

for mta in enabled disabled; do
    flags=()
    if [[ $mta == disabled ]]; then
        flags+=(-DNO_MTA_FEATURE_SUPPORT)
    fi
    "${CC:-cc}" -std=c11 -DBUILD_LINUX "${flags[@]}" \
        -Wall -Wextra -Werror -fno-common \
        -I"$ROOT_DIR/../include" -I"$ROOT_DIR/skeletons/include" \
        "$ROOT_DIR/skeletons/src/dhcp_test_model.c" \
        "$ROOT_DIR/skeletons/src/dhcp4cApi.c" \
        "$ROOT_DIR/skeletons/src/dhcpv4c_api.c" \
        "$ROOT_DIR/verification/test_model.c" -o "$SCRATCH/model-$mta"
    "$SCRATCH/model-$mta"
    nm -g --defined-only "$SCRATCH/model-$mta" >"$SCRATCH/symbols"
    count=$(awk '$3 ~ /^dhcp(4c|v4c)_get_emta_/ { n++ } END { print n+0 }' \
        "$SCRATCH/symbols")
    expected=6
    if [[ $mta == disabled ]]; then
        expected=0
    fi
    if [[ $count -ne $expected ]]; then
        printf 'FAIL: eMTA %s exports %s getters, expected %s\n' \
            "$mta" "$count" "$expected" >&2
        exit 1
    fi
done
printf '%s\n' 'Provider checks passed; official suite binary unchanged.'
