/* SPDX-License-Identifier: Apache-2.0 */
/* Verification-only probes: never linked into the official DHCP suite. */
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <ut.h>

extern UT_status_t __real_UT_init(int argc, char **argv);
extern UT_status_t __real_UT_run_tests(void);
extern void __real_CU_cleanup_registry(void);

static bool selected(const char *name)
{
    const char *probe = getenv("DHCP_HARNESS_CASE");

    return probe != NULL && strcmp(probe, name) == 0;
}

static void passing_test(void)
{
    CU_ASSERT_TRUE(CU_TRUE);
}

static void failing_test(void)
{
    CU_ASSERT_TRUE(CU_FALSE);
}

static void fatal_test(void)
{
    CU_ASSERT_TRUE_FATAL(CU_FALSE);
}

static int suite_init(void)
{
    return selected("suite-init") ? 1 : 0;
}

static int suite_cleanup(void)
{
    return selected("suite-cleanup") ? 1 : 0;
}

/* PUBLIC_INTERFACE */
/** Forward argc/argv to UT_init, or return a requested initialization failure. */
UT_status_t __wrap_UT_init(int argc, char **argv)
{
    return selected("init") ? UT_STATUS_FAILURE : __real_UT_init(argc, argv);
}

/* PUBLIC_INTERFACE */
/** Run the framework, optionally injecting a missing result or error status. */
UT_status_t __wrap_UT_run_tests(void)
{
    UT_status_t status;

    if (selected("no-results"))
    {
        /* Deliberately bypass the result hook to prove main fails closed. */
        __real_CU_cleanup_registry();
        return UT_STATUS_OK;
    }
    status = __real_UT_run_tests();
    return selected("run-error") ? UT_STATUS_FAILURE : status;
}

/* PUBLIC_INTERFACE */
/**
 * Register one controlled fixture selected by DHCP_HARNESS_CASE.
 * Return nonzero only for the explicit registrar-return failure probe.
 */
int register_hal_l1_tests(void)
{
    UT_test_suite_t *suite;
    UT_test_t *test;

    if (selected("registrar-return"))
    {
        return 1;
    }
    if (selected("empty"))
    {
        return 0;
    }
    if (selected("suite-registration"))
    {
        /* A later successful registration must not erase this failure. */
        (void)UT_add_suite(NULL, NULL, NULL);
    }

    suite = UT_add_suite("harness-active", suite_init, suite_cleanup);
    if (suite == NULL)
    {
        return 1;
    }
    if (selected("test-registration"))
    {
        /* The component hook must return NULL, not abort inside ut-core. */
        (void)UT_add_test(suite, NULL, passing_test);
    }
    test = UT_add_test(suite, "controlled-result",
                       selected("assertion") ? failing_test :
                       selected("fatal-assertion") ? fatal_test : passing_test);
    if (test == NULL)
    {
        return 1;
    }

    if (selected("inactive"))
    {
        (void)CU_set_suite_active((CU_pSuite)suite, CU_FALSE);
    }
    if (selected("filtered"))
    {
        UT_test_suite_t *inactive = UT_add_suite("harness-inactive", NULL, NULL);

        if (inactive == NULL ||
            UT_add_test(inactive, "must-not-run", failing_test) == NULL)
        {
            return 1;
        }
        (void)CU_set_suite_active((CU_pSuite)inactive, CU_FALSE);
    }
    if (selected("inactive-test"))
    {
        UT_test_t *inactive = UT_add_test(suite, "must-not-run", failing_test);

        if (inactive == NULL)
        {
            return 1;
        }
        (void)CU_set_test_active((CU_pTest)inactive, CU_FALSE);
    }
    return 0;
}
