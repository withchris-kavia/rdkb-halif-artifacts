/* SPDX-License-Identifier: Apache-2.0 */
/* Provider regression only: these model policies are not vendor conformance. */
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dhcp4cApi.h"
#include "dhcpv4c_api.h"
#include "dhcp_test_model.h"

static unsigned int checks;
#define CHECK(expression) do { \
    ++checks; \
    if (!(expression)) { \
        fprintf(stderr, "%s:%d: %s\n", __FILE__, __LINE__, #expression); \
        exit(EXIT_FAILURE); \
    } \
} while (0)
#define COUNT(array) (sizeof(array) / sizeof((array)[0]))

typedef struct {
    int (*get)(unsigned int *);
    dhcp_test_family_t family;
    dhcp_test_role_t role;
    dhcp_test_field_t field;
    size_t offset;
} uint_case_t;

typedef struct {
    int (*get)(int *);
    dhcp_test_family_t family;
    dhcp_test_role_t role;
    dhcp_test_field_t field;
    size_t offset;
} int_case_t;

#define SCALAR(prefix, family, role, key, member, field) \
    {prefix##_get_##role##_##member, family, key, field, \
     offsetof(dhcp_test_snapshot_t, member)}
#define UINT_ROLE(prefix, family, role, key) \
    SCALAR(prefix, family, role, key, lease_time, DHCP_TEST_LEASE_TIME), \
    SCALAR(prefix, family, role, key, remain_lease_time, DHCP_TEST_REMAIN_LEASE_TIME), \
    SCALAR(prefix, family, role, key, remain_renew_time, DHCP_TEST_REMAIN_RENEW_TIME), \
    SCALAR(prefix, family, role, key, remain_rebind_time, DHCP_TEST_REMAIN_REBIND_TIME), \
    SCALAR(prefix, family, role, key, ip_addr, DHCP_TEST_IP_ADDR), \
    SCALAR(prefix, family, role, key, mask, DHCP_TEST_MASK), \
    SCALAR(prefix, family, role, key, gw, DHCP_TEST_GW), \
    SCALAR(prefix, family, role, key, dhcp_svr, DHCP_TEST_DHCP_SVR)
#define INT_ROLE(prefix, family, role, key) \
    SCALAR(prefix, family, role, key, config_attempts, DHCP_TEST_CONFIG_ATTEMPTS), \
    SCALAR(prefix, family, role, key, fsm_state, DHCP_TEST_FSM_STATE)
#define EMTA(prefix, family) \
    SCALAR(prefix, family, emta, DHCP_TEST_ROLE_EMTA, remain_lease_time, DHCP_TEST_REMAIN_LEASE_TIME), \
    SCALAR(prefix, family, emta, DHCP_TEST_ROLE_EMTA, remain_renew_time, DHCP_TEST_REMAIN_RENEW_TIME), \
    SCALAR(prefix, family, emta, DHCP_TEST_ROLE_EMTA, remain_rebind_time, DHCP_TEST_REMAIN_REBIND_TIME)

static const uint_case_t uint_cases[] = {
    UINT_ROLE(dhcp4c, DHCP_TEST_FAMILY_LEGACY, ert, DHCP_TEST_ROLE_ERT),
    UINT_ROLE(dhcp4c, DHCP_TEST_FAMILY_LEGACY, ecm, DHCP_TEST_ROLE_ECM),
    UINT_ROLE(dhcpv4c, DHCP_TEST_FAMILY_NEWER, ert, DHCP_TEST_ROLE_ERT),
    UINT_ROLE(dhcpv4c, DHCP_TEST_FAMILY_NEWER, ecm, DHCP_TEST_ROLE_ECM),
#ifndef NO_MTA_FEATURE_SUPPORT
    EMTA(dhcp4c, DHCP_TEST_FAMILY_LEGACY),
    EMTA(dhcpv4c, DHCP_TEST_FAMILY_NEWER),
#endif
};

static const int_case_t int_cases[] = {
    INT_ROLE(dhcp4c, DHCP_TEST_FAMILY_LEGACY, ert, DHCP_TEST_ROLE_ERT),
    INT_ROLE(dhcp4c, DHCP_TEST_FAMILY_LEGACY, ecm, DHCP_TEST_ROLE_ECM),
    INT_ROLE(dhcpv4c, DHCP_TEST_FAMILY_NEWER, ert, DHCP_TEST_ROLE_ERT),
    INT_ROLE(dhcpv4c, DHCP_TEST_FAMILY_NEWER, ecm, DHCP_TEST_ROLE_ECM),
};

static dhcp_test_snapshot_t fixtures[DHCP_TEST_FAMILY_COUNT][DHCP_TEST_ROLE_COUNT];

static void load_fixtures(void)
{
    int family, role;

    for (family = 0; family < DHCP_TEST_FAMILY_COUNT; ++family)
    {
        for (role = 0; role < DHCP_TEST_ROLE_COUNT; ++role)
        {
            dhcp_test_snapshot_t *s = &fixtures[family][role];
            unsigned int base = 1000U * (unsigned int)(family + 1) +
                                100U * (unsigned int)(role + 1);
            int index;

            memset(s, 0, sizeof(*s));
            s->lease_time = base + 1U;
            s->remain_lease_time = base + 2U;
            s->remain_renew_time = base + 3U;
            s->remain_rebind_time = base + 4U;
            s->config_attempts = -(int)base - 5;
            s->fsm_state = (int)base + 6;
            s->ip_addr = base + 7U;
            s->mask = base + 8U;
            s->gw = base + 9U;
            s->dhcp_svr = base + 10U;
            CHECK(snprintf(s->ifname, sizeof(s->ifname), "family-%d-role-%d",
                           family, role) > 0);
            s->dns.number = DHCP_TEST_DNS_CAPACITY;
            for (index = 0; index < DHCP_TEST_DNS_CAPACITY; ++index)
            {
                s->dns.addrs[index] = base + 11U + (unsigned int)index;
            }
            CHECK(dhcp_test_model_load((dhcp_test_family_t)family,
                                       (dhcp_test_role_t)role, s) == 0);
        }
    }
}

static void check_scalars(void)
{
    size_t index;

    for (index = 0; index < COUNT(uint_cases); ++index)
    {
        const uint_case_t *c = &uint_cases[index];
        unsigned int expected, value = 0xA5A5U;
        int wrong_type = 77;

        memcpy(&expected, (const char *)&fixtures[c->family][c->role] +
                          c->offset, sizeof(expected));
        CHECK(c->get(&value) == 0 && value == expected);
        CHECK(dhcp_test_model_fail_next(c->family, c->role, c->field) == 0);
        CHECK(dhcp_test_model_fail_next(c->family, c->role, c->field) == 0);
        CHECK(c->get(NULL) == -1);
        CHECK(dhcp_test_model_get_int(c->family, c->role, c->field,
                                     &wrong_type) == -1 && wrong_type == 77);
        value = 0xA5A5U;
        CHECK(c->get(&value) == -1 && value == 0xA5A5U);
        CHECK(c->get(&value) == 0 && value == expected);
        CHECK(c->get(&value) == 0 && value == expected);
    }
    for (index = 0; index < COUNT(int_cases); ++index)
    {
        const int_case_t *c = &int_cases[index];
        int expected, value = -77;
        unsigned int wrong_type = 77U;

        memcpy(&expected, (const char *)&fixtures[c->family][c->role] +
                          c->offset, sizeof(expected));
        CHECK(c->get(&value) == 0 && value == expected);
        CHECK(dhcp_test_model_fail_next(c->family, c->role, c->field) == 0);
        CHECK(c->get(NULL) == -1);
        CHECK(dhcp_test_model_get_uint(c->family, c->role, c->field,
                                      &wrong_type) == -1 && wrong_type == 77U);
        value = -77;
        CHECK(c->get(&value) == -1 && value == -77);
        CHECK(c->get(&value) == 0 && value == expected);
    }
}

static void check_names(void)
{
    static const struct {
        int (*get)(char *);
        dhcp_test_family_t family;
        dhcp_test_role_t role;
    } cases[] = {
        {dhcp4c_get_ert_ifname, DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT},
        {dhcp4c_get_ecm_ifname, DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM},
        {dhcpv4c_get_ert_ifname, DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT},
        {dhcpv4c_get_ecm_ifname, DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM},
    };
    size_t index;

    for (index = 0; index < COUNT(cases); ++index)
    {
        struct {
            unsigned char before[8];
            char name[DHCP_TEST_IFNAME_SIZE];
            unsigned char after[8];
        } guarded, saved;
        dhcp_test_snapshot_t fixture = fixtures[cases[index].family][cases[index].role];
        size_t byte;

        memset(&guarded, 0xA5, sizeof(guarded));
        saved = guarded;
        CHECK(dhcp_test_model_fail_next(cases[index].family, cases[index].role,
                                        DHCP_TEST_IFNAME) == 0);
        CHECK(cases[index].get(NULL) == -1);
        CHECK(cases[index].get(guarded.name) == -1);
        CHECK(memcmp(&guarded, &saved, sizeof(guarded)) == 0);
        CHECK(cases[index].get(guarded.name) == 0);
        CHECK(memcmp(guarded.name, fixture.ifname, sizeof(guarded.name)) == 0);
        CHECK(memcmp(guarded.before, saved.before, sizeof(guarded.before)) == 0);
        CHECK(memcmp(guarded.after, saved.after, sizeof(guarded.after)) == 0);

        /* A maximum-length name fits exactly, with a NUL in byte 63. */
        memset(fixture.ifname, 'x', sizeof(fixture.ifname));
        fixture.ifname[DHCP_TEST_IFNAME_SIZE - 1] = '\0';
        CHECK(dhcp_test_model_load(cases[index].family, cases[index].role, &fixture) == 0);
        CHECK(cases[index].get(guarded.name) == 0);
        CHECK(memcmp(guarded.name, fixture.ifname, sizeof(guarded.name)) == 0);
        CHECK(memcmp(guarded.after, saved.after, sizeof(guarded.after)) == 0);

        /* Shorter names replace, rather than expose, stale fixture storage. */
        fixture.ifname[0] = '\0';
        CHECK(dhcp_test_model_load(cases[index].family, cases[index].role, &fixture) == 0);
        CHECK(cases[index].get(guarded.name) == 0);
        for (byte = 0; byte < sizeof(guarded.name); ++byte)
        {
            CHECK(guarded.name[byte] == '\0');
        }
        CHECK(dhcp_test_model_load(cases[index].family, cases[index].role,
                                   &fixtures[cases[index].family][cases[index].role]) == 0);
    }
}

/* Each instantiation retains the real public DNS pointer type and member name. */
#define DEFINE_DNS_CHECK(function, type, member, prefix, family_key) \
static void function(void) \
{ \
    int (*const getters[])(type *) = {prefix##_get_ert_dns_svrs, prefix##_get_ecm_dns_svrs}; \
    const dhcp_test_role_t roles[] = {DHCP_TEST_ROLE_ERT, DHCP_TEST_ROLE_ECM}; \
    const int counts[] = {0, 1, 4}; \
    size_t role, count; \
    for (role = 0; role < COUNT(getters); ++role) \
    { \
        struct { unsigned int before; type list; unsigned int after; } guarded, saved; \
        dhcp_test_snapshot_t fixture = fixtures[family_key][roles[role]]; \
        memset(&guarded, 0xA5, sizeof(guarded)); \
        memcpy(&saved, &guarded, sizeof(saved)); \
        CHECK(dhcp_test_model_fail_next(family_key, roles[role], DHCP_TEST_DNS_SVRS) == 0); \
        CHECK(getters[role](NULL) == -1); \
        CHECK(getters[role](&guarded.list) == -1); \
        CHECK(memcmp(&guarded, &saved, sizeof(guarded)) == 0); \
        for (count = 0; count < COUNT(counts); ++count) \
        { \
            int slot; \
            fixture.dns.number = counts[count]; \
            CHECK(dhcp_test_model_load(family_key, roles[role], &fixture) == 0); \
            CHECK(getters[role](&guarded.list) == 0); \
            CHECK(guarded.list.number == counts[count]); \
            for (slot = 0; slot < DHCP_TEST_DNS_CAPACITY; ++slot) \
            { \
                CHECK(guarded.list.member[slot] == \
                      (slot < counts[count] ? fixture.dns.addrs[slot] : 0U)); \
            } \
            CHECK(guarded.before == saved.before && guarded.after == saved.after); \
        } \
        CHECK(dhcp_test_model_load(family_key, roles[role], \
                                   &fixtures[family_key][roles[role]]) == 0); \
    } \
}
DEFINE_DNS_CHECK(check_legacy_dns, ipv4AddrList_t, addrList, dhcp4c,
                 DHCP_TEST_FAMILY_LEGACY)
DEFINE_DNS_CHECK(check_newer_dns, dhcpv4c_ip_list_t, addrs, dhcpv4c,
                 DHCP_TEST_FAMILY_NEWER)

static void check_controls(void)
{
    dhcp_test_snapshot_t copy = fixtures[DHCP_TEST_FAMILY_LEGACY][DHCP_TEST_ROLE_ERT];
    unsigned int value = 77U;
    int signed_value = 77;

    CHECK(dhcp_test_model_load(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT, NULL) == -1);
    CHECK(dhcp_test_model_load((dhcp_test_family_t)-1, DHCP_TEST_ROLE_ERT, &copy) == -1);
    CHECK(dhcp_test_model_load(DHCP_TEST_FAMILY_COUNT, DHCP_TEST_ROLE_ERT, &copy) == -1);
    CHECK(dhcp_test_model_load(DHCP_TEST_FAMILY_LEGACY, (dhcp_test_role_t)-1, &copy) == -1);
    CHECK(dhcp_test_model_load(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_COUNT, &copy) == -1);
    CHECK(dhcp_test_model_fail_next(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    (dhcp_test_field_t)-1) == -1);
    CHECK(dhcp_test_model_fail_next(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_FIELD_COUNT) == -1);
    CHECK(dhcp_test_model_get_uint((dhcp_test_family_t)-1, DHCP_TEST_ROLE_ERT,
                                   DHCP_TEST_LEASE_TIME, &value) == -1 && value == 77U);
    CHECK(dhcp_test_model_get_int(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_COUNT,
                                  DHCP_TEST_FSM_STATE, &signed_value) == -1 &&
          signed_value == 77);

    /* Invalid loads cannot partially change otherwise valid scalar fields. */
    copy.lease_time = 999U;
    copy.dns.number = -1;
    CHECK(dhcp_test_model_load(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT, &copy) == -1);
    copy.dns.number = 5;
    CHECK(dhcp_test_model_load(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT, &copy) == -1);
    copy.dns.number = 4;
    memset(copy.ifname, 'x', sizeof(copy.ifname));
    CHECK(dhcp_test_model_load(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT, &copy) == -1);
    CHECK(dhcp4c_get_ert_lease_time(&value) == 0 &&
          value == fixtures[DHCP_TEST_FAMILY_LEGACY][DHCP_TEST_ROLE_ERT].lease_time);

    /* Valid loads copy input and preserve pending targeted failures. */
    copy = fixtures[DHCP_TEST_FAMILY_LEGACY][DHCP_TEST_ROLE_ERT];
    CHECK(dhcp_test_model_fail_next(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_LEASE_TIME) == 0);
    CHECK(dhcp_test_model_load(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT, &copy) == 0);
    copy.lease_time = 999U;
    copy.ifname[0] = '!';
    copy.dns.addrs[0] = 999U;
    CHECK(dhcpv4c_get_ert_lease_time(&value) == 0 &&
          value == fixtures[DHCP_TEST_FAMILY_NEWER][DHCP_TEST_ROLE_ERT].lease_time);
    CHECK(dhcp4c_get_ecm_lease_time(&value) == 0 &&
          value == fixtures[DHCP_TEST_FAMILY_LEGACY][DHCP_TEST_ROLE_ECM].lease_time);
    CHECK(dhcp4c_get_ert_remain_lease_time(&value) == 0 &&
          value == fixtures[DHCP_TEST_FAMILY_LEGACY][DHCP_TEST_ROLE_ERT].remain_lease_time);
    value = 77U;
    CHECK(dhcp4c_get_ert_lease_time(&value) == -1 && value == 77U);
    CHECK(dhcp4c_get_ert_lease_time(&value) == 0 &&
          value == fixtures[DHCP_TEST_FAMILY_LEGACY][DHCP_TEST_ROLE_ERT].lease_time);
#ifndef NO_MTA_FEATURE_SUPPORT
    CHECK(dhcp_test_model_fail_next(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_EMTA,
                                    DHCP_TEST_LEASE_TIME) == -1);
    value = 77U;
    CHECK(dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_EMTA,
                                   DHCP_TEST_LEASE_TIME, &value) == -1 && value == 77U);
#endif
}

static void check_reset(void)
{
    size_t index;
    char name[DHCP_TEST_IFNAME_SIZE];
    ipv4AddrList_t legacy;
    dhcpv4c_ip_list_t newer;

    CHECK(dhcp_test_model_fail_next(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_LEASE_TIME) == 0);
    CHECK(dhcp_test_model_fail_next(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_DNS_SVRS) == 0);
    dhcp_test_model_reset();
    dhcp_test_model_reset();
    for (index = 0; index < COUNT(uint_cases); ++index)
    {
        unsigned int value = 77U;
        CHECK(uint_cases[index].get(&value) == 0 && value == 0U);
    }
    for (index = 0; index < COUNT(int_cases); ++index)
    {
        int value = 77;
        CHECK(int_cases[index].get(&value) == 0 && value == 0);
    }
    memset(name, 'x', sizeof(name));
    CHECK(dhcp4c_get_ert_ifname(name) == 0);
    for (index = 0; index < sizeof(name); ++index)
    {
        CHECK(name[index] == '\0');
    }
    CHECK(dhcp4c_get_ecm_dns_svrs(&legacy) == 0 && legacy.number == 0);
    CHECK(dhcpv4c_get_ecm_dns_svrs(&newer) == 0 && newer.number == 0);
    for (index = 0; index < DHCP_TEST_DNS_CAPACITY; ++index)
    {
        CHECK(legacy.addrList[index] == 0U && newer.addrs[index] == 0U);
    }
}

/* PUBLIC_INTERFACE */
/** Run standalone Linux provider regressions; return nonzero on first failure. */
int main(void)
{
    unsigned int initial = 77U;

    CHECK(dhcp4c_get_ert_lease_time(&initial) == 0 && initial == 0U);
    dhcp_test_model_reset();
    load_fixtures();
    check_controls();
    check_scalars();
    check_names();
    check_legacy_dns();
    check_newer_dns();
    check_reset();
    printf("Provider regression passed: %u checks, %zu typed getter mappings\n",
           checks, COUNT(uint_cases) + COUNT(int_cases) + 8U);
    return EXIT_SUCCESS;
}
