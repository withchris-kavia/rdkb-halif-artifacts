#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
set -euo pipefail

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
SCRATCH=$(mktemp -d "${TMPDIR:-/tmp}/dhcp-harness.XXXXXXXX")
trap 'rm -rf -- "$SCRATCH"' EXIT

if ! make -C "$ROOT_DIR" TARGET=linux HAL=both HARNESS_VERIFY=1 BIN_DIR="$SCRATCH" -j2 \
        >"$SCRATCH/build.log" 2>&1; then
    cat "$SCRATCH/build.log"
    exit 1
fi
cp "$ROOT_DIR/bin/run.sh" "$SCRATCH/run.sh"

# PUBLIC_INTERFACE
# Run a named probe in the requested mode and check its exact process status.
check_probe()
{
    local probe=$1 expected=$2 mode=$3 entrypoint=$4 status=0
    DHCP_HARNESS_CASE="$probe" "$SCRATCH/$entrypoint" "$mode" -l "$SCRATCH/" \
        >"$SCRATCH/probe.log" 2>&1 || status=$?
    if [[ $status -ne $expected ]]; then
        printf 'FAIL: %s %s %s returned %s, expected %s\n' \
            "$entrypoint" "$mode" "$probe" "$status" "$expected" >&2
        cat "$SCRATCH/probe.log"
        exit 1
    fi
    if [[ $expected -eq 0 ]] &&
            ! grep -q 'DHCP_RESULT tests=1 failed_tests=0 failed_assertions=0' \
                "$SCRATCH/probe.log"; then
        printf 'FAIL: missing successful result for %s\n' "$probe" >&2
        cat "$SCRATCH/probe.log"
        exit 1
    fi
    if [[ $probe == inactive ]] &&
            ! grep -q 'DHCP_RESULT tests=0 ' "$SCRATCH/probe.log"; then
        printf '%s\n' 'FAIL: inactive selection did not reach zero-run capture' >&2
        cat "$SCRATCH/probe.log"
        exit 1
    fi
    printf 'PASS: %s %s %s -> %s\n' "$entrypoint" "$mode" "$probe" "$status"
}

for mode in -b -a; do
    for probe in pass filtered inactive-test; do
        check_probe "$probe" 0 "$mode" dhcp4_hal_test
    done
    for probe in init registrar-return suite-registration test-registration \
            empty inactive assertion fatal-assertion suite-init suite-cleanup \
            run-error no-results; do
        check_probe "$probe" 1 "$mode" dhcp4_hal_test
    done
done
check_probe pass 0 -b run.sh
check_probe assertion 1 -b run.sh
python3 "$ROOT_DIR/verification/test_wrappers.py"
printf '%s\n' 'Harness verification passed; official suite binary unchanged.'
