#!/usr/bin/env python3
"""Black-box regression tests for component-owned shell wrappers."""
# SPDX-License-Identifier: Apache-2.0

import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

UT_ROOT = Path(__file__).resolve().parents[1]

RECORDER = """#!/usr/bin/env python3
import json
import os
from pathlib import Path
import sys
Path(os.environ["WRAPPER_RECORD"]).write_text(json.dumps({
    "cwd": os.getcwd(),
    "args": sys.argv[1:],
    "library_path": os.environ.get("LD_LIBRARY_PATH"),
}))
sys.exit(int(os.environ.get("CHILD_STATUS", "37")))
"""

GIT_DOUBLE = """#!/usr/bin/env python3
import os
from pathlib import Path
import shutil
import sys
args = sys.argv[1:]
stage = "remote" if "remote" in args else "checkout" if "checkout" in args else "clone"
if stage == os.environ.get("FAIL_GIT_STAGE"):
    sys.exit(int(os.environ.get("GIT_STATUS", "41")))
if stage == "remote":
    print("https://example.invalid/rdkb-halif-dhcp.git")
elif stage == "clone":
    target = Path(args[-1])
    target.mkdir(parents=True)
    shutil.copy2(os.environ["BUILD_DOUBLE"], target / "build.sh")
"""


# PUBLIC_INTERFACE
class WrapperTests(unittest.TestCase):
    """Exercise copied wrappers in temporary directories, without network use."""

    # PUBLIC_INTERFACE
    def setUp(self):
        """Create an isolated component, caller directory and command doubles."""
        self.scratch = tempfile.TemporaryDirectory(prefix="dhcp wrapper ")
        self.addCleanup(self.scratch.cleanup)
        self.base = Path(self.scratch.name)
        self.component = self.base / "component root"
        self.caller = self.base / "unrelated caller"
        self.commands = self.base / "commands"
        for directory in (self.component, self.caller, self.commands):
            directory.mkdir()
        self.record = self.base / "record.json"
        self.double = self.commands / "build-double"
        self._write_executable(self.double, RECORDER)
        self._write_executable(self.commands / "git", GIT_DOUBLE)
        self._write_executable(self.commands / "make", RECORDER)
        shutil.copy2(UT_ROOT.parent / "build_ut.sh", self.component / "build_ut.sh")
        self.env = os.environ.copy()
        self.env.update(
            PATH=str(self.commands) + os.pathsep + self.env["PATH"],
            WRAPPER_RECORD=str(self.record),
            BUILD_DOUBLE=str(self.double),
            CHILD_STATUS="37",
            LD_LIBRARY_PATH="/existing library:/another",
        )
        # Do not inherit a parent make invocation's jobserver or test options.
        for name in ("MAKEFLAGS", "MFLAGS", "MAKELEVEL", "FAIL_GIT_STAGE"):
            self.env.pop(name, None)

    def _write_executable(self, path, content):
        path.write_text(content)
        path.chmod(0o755)

    def _run(self, script, *args):
        return subprocess.run(
            [str(script), *args],
            cwd=self.caller,
            env=self.env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=15,
            check=False,
        )

    def _install_child(self, parent):
        child = parent / "ut"
        child.mkdir(parents=True)
        shutil.copy2(self.double, child / "build.sh")
        return child

    def _recorded(self):
        return json.loads(self.record.read_text())

    # PUBLIC_INTERFACE
    def test_default_directory_arguments_and_failure(self):
        """Default to the script's component and preserve exact argv/status."""
        child = self._install_child(self.component)
        args = ["VALUE=two words", "empty=", ""]
        result = self._run(self.component / "build_ut.sh", *args)
        self.assertEqual(result.returncode, 37, result.stderr)
        self.assertEqual(self._recorded()["cwd"], str(child))
        self.assertEqual(self._recorded()["args"], args)

    # PUBLIC_INTERFACE
    def test_relative_directory_override(self):
        """Resolve an explicit relative --dir from the caller, including spaces."""
        destination = self.caller / "alternate root"
        child = self._install_child(destination)
        result = self._run(
            self.component / "build_ut.sh", "--dir", "alternate root", "A=b c"
        )
        self.assertEqual(result.returncode, 37, result.stderr)
        self.assertEqual(self._recorded()["cwd"], str(child))
        self.assertEqual(self._recorded()["args"], ["A=b c"])

    # PUBLIC_INTERFACE
    def test_missing_directory_argument(self):
        """Reject --dir with no operand before invoking a child."""
        result = self._run(self.component / "build_ut.sh", "--dir")
        self.assertEqual(result.returncode, 2)
        self.assertFalse(self.record.exists())

    # PUBLIC_INTERFACE
    def test_clone_checkout_and_remote_errors(self):
        """Retain each failed git operation's status and never invoke a child."""
        for stage in ("remote", "clone", "checkout"):
            with self.subTest(stage=stage):
                destination = self.caller / stage
                self.env["FAIL_GIT_STAGE"] = stage
                result = self._run(
                    self.component / "build_ut.sh", "--dir", str(destination)
                )
                self.assertEqual(result.returncode, 41, result.stderr)
                self.assertFalse(self.record.exists())

    # PUBLIC_INTERFACE
    def test_successful_clone_does_not_recurse(self):
        """A new companion checkout runs its child exactly once."""
        destination = self.caller / "fresh checkout"
        result = self._run(
            self.component / "build_ut.sh",
            "--dir", str(destination), "TARGET=linux", "A=b c"
        )
        self.assertEqual(result.returncode, 37, result.stderr)
        self.assertEqual(self._recorded()["cwd"], str(destination / "ut"))
        self.assertEqual(self._recorded()["args"], ["TARGET=linux", "A=b c"])

    def _install_ut_build(self):
        script = self.component / "build.sh"
        shutil.copy2(UT_ROOT / "build.sh", script)
        return script

    # PUBLIC_INTERFACE
    def test_ut_build_directory_arguments_and_failure(self):
        """Use an existing dependency tree read-only and exec make verbatim."""
        script = self._install_ut_build()
        core = self.component / "ut-core"
        markers = (
            "framework/CUnit-2.1-3/CUnit/Headers/CUnit.h",
            "framework/ut-control/lib/libut_control.so",
            "framework/ut-control/framework/libwebsockets-4.3.3/build/lib/libwebsockets.so",
        )
        for marker in markers:
            path = core / marker
            path.parent.mkdir(parents=True, exist_ok=True)
            path.touch()
        result = self._run(script, "TARGET=linux", "VALUE=two words", "")
        self.assertEqual(result.returncode, 37, result.stderr)
        self.assertEqual(self._recorded()["cwd"], str(self.component))
        self.assertEqual(
            self._recorded()["args"],
            ["-C", str(self.component), "-f", "Makefile",
             "TARGET=linux", "VALUE=two words", ""],
        )

    # PUBLIC_INTERFACE
    def test_ut_clone_and_checkout_errors(self):
        """Do not hide core bootstrap failures with a later make invocation."""
        script = self._install_ut_build()
        for stage in ("clone", "checkout"):
            with self.subTest(stage=stage):
                self.env["FAIL_GIT_STAGE"] = stage
                result = self._run(script)
                self.assertEqual(result.returncode, 41, result.stderr)
                self.assertFalse(self.record.exists())

    # PUBLIC_INTERFACE
    def test_ut_dependency_bootstrap_failure(self):
        """Stop immediately if an official dependency bootstrap fails."""
        script = self._install_ut_build()
        core = self.component / "ut-core"
        core.mkdir()
        self._write_executable(core / "build.sh", "#!/bin/bash\nexit 43\n")
        result = self._run(script)
        self.assertEqual(result.returncode, 43, result.stderr)
        self.assertFalse(self.record.exists())

    # PUBLIC_INTERFACE
    def test_runner_preserves_library_path_arguments_and_status(self):
        """The runner prepends its directory without dropping existing paths."""
        runner = self.component / "run.sh"
        shutil.copy2(UT_ROOT / "bin/run.sh", runner)
        shutil.copy2(self.double, self.component / "dhcp4_hal_test")
        result = self._run(runner, "-p", "profile with spaces.yaml", "")
        self.assertEqual(result.returncode, 37, result.stderr)
        self.assertEqual(self._recorded()["cwd"], str(self.component))
        self.assertEqual(
            self._recorded()["args"], ["-p", "profile with spaces.yaml", ""]
        )
        self.assertEqual(
            self._recorded()["library_path"],
            str(self.component) + ":/existing library:/another",
        )

    # PUBLIC_INTERFACE
    def test_runner_unset_library_path(self):
        """An unset search path produces no empty, cwd-searching path entry."""
        self.env.pop("LD_LIBRARY_PATH")
        runner = self.component / "run.sh"
        shutil.copy2(UT_ROOT / "bin/run.sh", runner)
        shutil.copy2(self.double, self.component / "dhcp4_hal_test")
        result = self._run(runner, "-b")
        self.assertEqual(result.returncode, 37, result.stderr)
        self.assertEqual(self._recorded()["library_path"], str(self.component))

    # PUBLIC_INTERFACE
    def test_requested_executable_modes(self):
        """All three user entrypoints must be executable in the worktree."""
        for script in (UT_ROOT.parent / "build_ut.sh",
                       UT_ROOT / "build.sh", UT_ROOT / "bin/run.sh"):
            with self.subTest(script=script):
                self.assertTrue(os.access(script, os.X_OK))


if __name__ == "__main__":
    unittest.main(verbosity=2)
