/* SPDX-License-Identifier: Apache-2.0 */
#include <stdbool.h>
#include <stddef.h>
#include <string.h>

#include "dhcp_test_model.h"

/* Static initialization and explicit reset intentionally have identical policy. */
static dhcp_test_snapshot_t snapshots[DHCP_TEST_FAMILY_COUNT][DHCP_TEST_ROLE_COUNT];
static bool failures[DHCP_TEST_FAMILY_COUNT][DHCP_TEST_ROLE_COUNT][DHCP_TEST_FIELD_COUNT];

static bool valid_key(dhcp_test_family_t family, dhcp_test_role_t role)
{
    return (unsigned int)family < DHCP_TEST_FAMILY_COUNT &&
           (unsigned int)role < DHCP_TEST_ROLE_COUNT;
}

static bool valid_field(dhcp_test_family_t family, dhcp_test_role_t role,
                        dhcp_test_field_t field)
{
    if (!valid_key(family, role) ||
        (unsigned int)field >= DHCP_TEST_FIELD_COUNT)
    {
        return false;
    }
#ifndef NO_MTA_FEATURE_SUPPORT
    if (role == DHCP_TEST_ROLE_EMTA)
    {
        return field == DHCP_TEST_REMAIN_LEASE_TIME ||
               field == DHCP_TEST_REMAIN_RENEW_TIME ||
               field == DHCP_TEST_REMAIN_REBIND_TIME;
    }
#endif
    return true;
}

/* Call only after validating keys, output pointers and the requested type. */
static bool consume_failure(dhcp_test_family_t family, dhcp_test_role_t role,
                            dhcp_test_field_t field)
{
    bool pending = failures[family][role][field];

    failures[family][role][field] = false;
    return pending;
}

/* PUBLIC_INTERFACE */
/** Restore the zero/empty model policy and cancel every pending failure. */
void dhcp_test_model_reset(void)
{
    memset(snapshots, 0, sizeof(snapshots));
    memset(failures, 0, sizeof(failures));
}

/* PUBLIC_INTERFACE */
/** Validate and copy one bounded snapshot atomically; see private header. */
int dhcp_test_model_load(dhcp_test_family_t family, dhcp_test_role_t role,
                         const dhcp_test_snapshot_t *snapshot)
{
    dhcp_test_snapshot_t copy;
    const char *terminator;
    size_t length;
    int index;

    if (!valid_key(family, role) || snapshot == NULL ||
        snapshot->dns.number < 0 ||
        snapshot->dns.number > DHCP_TEST_DNS_CAPACITY)
    {
        return DHCP_TEST_FAILURE;
    }
    terminator = memchr(snapshot->ifname, '\0', sizeof(snapshot->ifname));
    if (terminator == NULL)
    {
        return DHCP_TEST_FAILURE;
    }

    copy = *snapshot;
    length = (size_t)(terminator - snapshot->ifname);
    memset(copy.ifname + length, 0, sizeof(copy.ifname) - length);
    for (index = copy.dns.number; index < DHCP_TEST_DNS_CAPACITY; ++index)
    {
        copy.dns.addrs[index] = 0U;
    }
    snapshots[family][role] = copy;
    return DHCP_TEST_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Arm a single exact getter failure without changing any snapshot. */
int dhcp_test_model_fail_next(dhcp_test_family_t family, dhcp_test_role_t role,
                              dhcp_test_field_t field)
{
    if (!valid_field(family, role, field))
    {
        return DHCP_TEST_FAILURE;
    }
    failures[family][role][field] = true;
    return DHCP_TEST_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return only unsigned fields, preserving value on every failure. */
int dhcp_test_model_get_uint(dhcp_test_family_t family, dhcp_test_role_t role,
                             dhcp_test_field_t field, unsigned int *value)
{
    const dhcp_test_snapshot_t *snapshot;
    unsigned int result;

    if (value == NULL || !valid_field(family, role, field))
    {
        return DHCP_TEST_FAILURE;
    }
    snapshot = &snapshots[family][role];
    switch (field)
    {
        case DHCP_TEST_LEASE_TIME:
            result = snapshot->lease_time;
            break;
        case DHCP_TEST_REMAIN_LEASE_TIME:
            result = snapshot->remain_lease_time;
            break;
        case DHCP_TEST_REMAIN_RENEW_TIME:
            result = snapshot->remain_renew_time;
            break;
        case DHCP_TEST_REMAIN_REBIND_TIME:
            result = snapshot->remain_rebind_time;
            break;
        case DHCP_TEST_IP_ADDR:
            result = snapshot->ip_addr;
            break;
        case DHCP_TEST_MASK:
            result = snapshot->mask;
            break;
        case DHCP_TEST_GW:
            result = snapshot->gw;
            break;
        case DHCP_TEST_DHCP_SVR:
            result = snapshot->dhcp_svr;
            break;
        default:
            return DHCP_TEST_FAILURE;
    }
    if (consume_failure(family, role, field))
    {
        return DHCP_TEST_FAILURE;
    }
    *value = result;
    return DHCP_TEST_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Return a signed field without aliasing an unsigned field or output. */
int dhcp_test_model_get_int(dhcp_test_family_t family, dhcp_test_role_t role,
                            dhcp_test_field_t field, int *value)
{
    int result;

    if (value == NULL || !valid_field(family, role, field))
    {
        return DHCP_TEST_FAILURE;
    }
    switch (field)
    {
        case DHCP_TEST_CONFIG_ATTEMPTS:
            result = snapshots[family][role].config_attempts;
            break;
        case DHCP_TEST_FSM_STATE:
            result = snapshots[family][role].fsm_state;
            break;
        default:
            return DHCP_TEST_FAILURE;
    }
    if (consume_failure(family, role, field))
    {
        return DHCP_TEST_FAILURE;
    }
    *value = result;
    return DHCP_TEST_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy the bounded, normalized interface name only after a successful read. */
int dhcp_test_model_get_ifname(dhcp_test_family_t family, dhcp_test_role_t role,
                               char *name)
{
    if (name == NULL || !valid_field(family, role, DHCP_TEST_IFNAME) ||
        consume_failure(family, role, DHCP_TEST_IFNAME))
    {
        return DHCP_TEST_FAILURE;
    }
    memcpy(name, snapshots[family][role].ifname, DHCP_TEST_IFNAME_SIZE);
    return DHCP_TEST_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy all four initialized DNS slots only after a successful read. */
int dhcp_test_model_get_dns(dhcp_test_family_t family, dhcp_test_role_t role,
                            dhcp_test_dns_t *list)
{
    if (list == NULL || !valid_field(family, role, DHCP_TEST_DNS_SVRS) ||
        consume_failure(family, role, DHCP_TEST_DNS_SVRS))
    {
        return DHCP_TEST_FAILURE;
    }
    *list = snapshots[family][role].dns;
    return DHCP_TEST_SUCCESS;
}
