/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include <stddef.h>

#include "dhcp4cApi.h"
#include "dhcp_test_model.h"

_Static_assert(MAX_IPV4_ADDR_LIST_NUMBER == DHCP_TEST_DNS_CAPACITY,
               "Legacy DNS capacity must match the bounded model");

/* No structure casts: the two public list types are distinct C types. */
static int get_dns(dhcp_test_role_t role, ipv4AddrList_t *list)
{
    dhcp_test_dns_t dns;
    int index;

    if (list == NULL ||
        dhcp_test_model_get_dns(DHCP_TEST_FAMILY_LEGACY, role, &dns) !=
            DHCP_TEST_SUCCESS)
    {
        return DHCP_TEST_FAILURE;
    }
    list->number = dns.number;
    for (index = 0; index < MAX_IPV4_ADDR_LIST_NUMBER; ++index)
    {
        list->addrList[index] = dns.addrs[index];
    }
    return DHCP_TEST_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT offered lease to pValue; return 0 or -1, preserving failures. */
int dhcp4c_get_ert_lease_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_LEASE_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT remaining lease to pValue; return 0 or -1. */
int dhcp4c_get_ert_remain_lease_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_REMAIN_LEASE_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT remaining renewal timer to pValue; return 0 or -1. */
int dhcp4c_get_ert_remain_renew_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_REMAIN_RENEW_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT remaining rebind timer to pValue; return 0 or -1. */
int dhcp4c_get_ert_remain_rebind_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_REMAIN_REBIND_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT attempt count to pValue; return 0 or -1. */
int dhcp4c_get_ert_config_attempts(int *pValue)
{
    return dhcp_test_model_get_int(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                   DHCP_TEST_CONFIG_ATTEMPTS, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT name to a 64-byte pName buffer; return 0 or -1. */
int dhcp4c_get_ert_ifname(char *pName)
{
    return dhcp_test_model_get_ifname(DHCP_TEST_FAMILY_LEGACY,
                                      DHCP_TEST_ROLE_ERT, pName);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT observed FSM value to pValue; return 0 or -1. */
int dhcp4c_get_ert_fsm_state(int *pValue)
{
    return dhcp_test_model_get_int(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                   DHCP_TEST_FSM_STATE, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT opaque IPv4 word to pValue; return 0 or -1. */
int dhcp4c_get_ert_ip_addr(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_IP_ADDR, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT mask to pValue; return 0 or -1. */
int dhcp4c_get_ert_mask(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_MASK, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT gateway to pValue; return 0 or -1. */
int dhcp4c_get_ert_gw(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_GW, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT DNS count and four slots to pList; return 0 or -1. */
int dhcp4c_get_ert_dns_svrs(ipv4AddrList_t *pList)
{
    return get_dns(DHCP_TEST_ROLE_ERT, pList);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ERT DHCP server to pValue; return 0 or -1. */
int dhcp4c_get_ert_dhcp_svr(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_DHCP_SVR, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM offered lease to pValue; return 0 or -1. */
int dhcp4c_get_ecm_lease_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_LEASE_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM remaining lease to pValue; return 0 or -1. */
int dhcp4c_get_ecm_remain_lease_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_REMAIN_LEASE_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM remaining renewal timer to pValue; return 0 or -1. */
int dhcp4c_get_ecm_remain_renew_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_REMAIN_RENEW_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM remaining rebind timer to pValue; return 0 or -1. */
int dhcp4c_get_ecm_remain_rebind_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_REMAIN_REBIND_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM attempt count to pValue; return 0 or -1. */
int dhcp4c_get_ecm_config_attempts(int *pValue)
{
    return dhcp_test_model_get_int(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                                   DHCP_TEST_CONFIG_ATTEMPTS, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM name to a 64-byte pName buffer; return 0 or -1. */
int dhcp4c_get_ecm_ifname(char *pName)
{
    return dhcp_test_model_get_ifname(DHCP_TEST_FAMILY_LEGACY,
                                      DHCP_TEST_ROLE_ECM, pName);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM observed FSM value to pValue; return 0 or -1. */
int dhcp4c_get_ecm_fsm_state(int *pValue)
{
    return dhcp_test_model_get_int(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                                   DHCP_TEST_FSM_STATE, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM opaque IPv4 word to pValue; return 0 or -1. */
int dhcp4c_get_ecm_ip_addr(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_IP_ADDR, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM mask to pValue; return 0 or -1. */
int dhcp4c_get_ecm_mask(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_MASK, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM gateway to pValue; return 0 or -1. */
int dhcp4c_get_ecm_gw(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_GW, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM DNS count and four slots to pList; return 0 or -1. */
int dhcp4c_get_ecm_dns_svrs(ipv4AddrList_t *pList)
{
    return get_dns(DHCP_TEST_ROLE_ECM, pList);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy ECM DHCP server to pValue; return 0 or -1. */
int dhcp4c_get_ecm_dhcp_svr(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_DHCP_SVR, pValue);
}

#ifndef NO_MTA_FEATURE_SUPPORT
/* PUBLIC_INTERFACE */
/** Copy the legacy eMTA remaining lease to pValue; return 0 or -1. */
int dhcp4c_get_emta_remain_lease_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_EMTA,
                                    DHCP_TEST_REMAIN_LEASE_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy eMTA remaining renewal timer to pValue; return 0 or -1. */
int dhcp4c_get_emta_remain_renew_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_EMTA,
                                    DHCP_TEST_REMAIN_RENEW_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the legacy eMTA remaining rebind timer to pValue; return 0 or -1. */
int dhcp4c_get_emta_remain_rebind_time(unsigned int *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_LEGACY, DHCP_TEST_ROLE_EMTA,
                                    DHCP_TEST_REMAIN_REBIND_TIME, pValue);
}
#endif
