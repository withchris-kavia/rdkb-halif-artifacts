/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include <stddef.h>

#include "dhcpv4c_api.h"
#include "dhcp_test_model.h"

_Static_assert(DHCPV4_MAX_IPV4_ADDRS == DHCP_TEST_DNS_CAPACITY,
               "Newer DNS capacity must match the bounded model");

static INT get_dns(dhcp_test_role_t role, dhcpv4c_ip_list_t *list)
{
    dhcp_test_dns_t dns;
    int index;

    if (list == NULL ||
        dhcp_test_model_get_dns(DHCP_TEST_FAMILY_NEWER, role, &dns) !=
            DHCP_TEST_SUCCESS)
    {
        return STATUS_FAILURE;
    }
    list->number = dns.number;
    for (index = 0; index < DHCPV4_MAX_IPV4_ADDRS; ++index)
    {
        list->addrs[index] = dns.addrs[index];
    }
    return STATUS_SUCCESS;
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT offered lease to pValue; return 0 or -1, preserving failures. */
INT dhcpv4c_get_ert_lease_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_LEASE_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT remaining lease to pValue; return 0 or -1. */
INT dhcpv4c_get_ert_remain_lease_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_REMAIN_LEASE_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT remaining renewal timer to pValue; return 0 or -1. */
INT dhcpv4c_get_ert_remain_renew_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_REMAIN_RENEW_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT remaining rebind timer to pValue; return 0 or -1. */
INT dhcpv4c_get_ert_remain_rebind_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_REMAIN_REBIND_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT attempt count to pValue; return 0 or -1. */
INT dhcpv4c_get_ert_config_attempts(INT *pValue)
{
    return dhcp_test_model_get_int(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                                   DHCP_TEST_CONFIG_ATTEMPTS, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT name to a 64-byte pName buffer; return 0 or -1. */
INT dhcpv4c_get_ert_ifname(CHAR *pName)
{
    return dhcp_test_model_get_ifname(DHCP_TEST_FAMILY_NEWER,
                                      DHCP_TEST_ROLE_ERT, pName);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT observed FSM value to pValue; return 0 or -1. */
INT dhcpv4c_get_ert_fsm_state(INT *pValue)
{
    return dhcp_test_model_get_int(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                                   DHCP_TEST_FSM_STATE, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT opaque IPv4 word to pValue; return 0 or -1. */
INT dhcpv4c_get_ert_ip_addr(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_IP_ADDR, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT mask to pValue; return 0 or -1. */
INT dhcpv4c_get_ert_mask(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_MASK, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT gateway to pValue; return 0 or -1. */
INT dhcpv4c_get_ert_gw(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_GW, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT DNS count and four slots to pList; return 0 or -1. */
INT dhcpv4c_get_ert_dns_svrs(dhcpv4c_ip_list_t *pList)
{
    return get_dns(DHCP_TEST_ROLE_ERT, pList);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ERT DHCP server to pValue; return 0 or -1. */
INT dhcpv4c_get_ert_dhcp_svr(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ERT,
                                    DHCP_TEST_DHCP_SVR, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM offered lease to pValue; return 0 or -1. */
INT dhcpv4c_get_ecm_lease_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_LEASE_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM remaining lease to pValue; return 0 or -1. */
INT dhcpv4c_get_ecm_remain_lease_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_REMAIN_LEASE_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM remaining renewal timer to pValue; return 0 or -1. */
INT dhcpv4c_get_ecm_remain_renew_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_REMAIN_RENEW_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM remaining rebind timer to pValue; return 0 or -1. */
INT dhcpv4c_get_ecm_remain_rebind_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_REMAIN_REBIND_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM attempt count to pValue; return 0 or -1. */
INT dhcpv4c_get_ecm_config_attempts(INT *pValue)
{
    return dhcp_test_model_get_int(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                   DHCP_TEST_CONFIG_ATTEMPTS, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM name to a 64-byte pName buffer; return 0 or -1. */
INT dhcpv4c_get_ecm_ifname(CHAR *pName)
{
    return dhcp_test_model_get_ifname(DHCP_TEST_FAMILY_NEWER,
                                      DHCP_TEST_ROLE_ECM, pName);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM observed FSM value to pValue; return 0 or -1. */
INT dhcpv4c_get_ecm_fsm_state(INT *pValue)
{
    return dhcp_test_model_get_int(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                   DHCP_TEST_FSM_STATE, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM opaque IPv4 word to pValue; return 0 or -1. */
INT dhcpv4c_get_ecm_ip_addr(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_IP_ADDR, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM mask to pValue; return 0 or -1. */
INT dhcpv4c_get_ecm_mask(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_MASK, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM gateway to pValue; return 0 or -1. */
INT dhcpv4c_get_ecm_gw(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_GW, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM DNS count and four slots to pList; return 0 or -1. */
INT dhcpv4c_get_ecm_dns_svrs(dhcpv4c_ip_list_t *pList)
{
    return get_dns(DHCP_TEST_ROLE_ECM, pList);
}

/* PUBLIC_INTERFACE */
/** Copy the newer ECM DHCP server to pValue; return 0 or -1. */
INT dhcpv4c_get_ecm_dhcp_svr(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_ECM,
                                    DHCP_TEST_DHCP_SVR, pValue);
}

#ifndef NO_MTA_FEATURE_SUPPORT
/* PUBLIC_INTERFACE */
/** Copy the newer eMTA remaining lease to pValue; return 0 or -1. */
INT dhcpv4c_get_emta_remain_lease_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_EMTA,
                                    DHCP_TEST_REMAIN_LEASE_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer eMTA remaining renewal timer to pValue; return 0 or -1. */
INT dhcpv4c_get_emta_remain_renew_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_EMTA,
                                    DHCP_TEST_REMAIN_RENEW_TIME, pValue);
}

/* PUBLIC_INTERFACE */
/** Copy the newer eMTA remaining rebind timer to pValue; return 0 or -1. */
INT dhcpv4c_get_emta_remain_rebind_time(UINT *pValue)
{
    return dhcp_test_model_get_uint(DHCP_TEST_FAMILY_NEWER, DHCP_TEST_ROLE_EMTA,
                                    DHCP_TEST_REMAIN_REBIND_TIME, pValue);
}
#endif
