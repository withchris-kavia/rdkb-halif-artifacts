/* SPDX-License-Identifier: Apache-2.0 */
/**
 * @file dhcp_test_model.h
 * Private, single-threaded Linux test provider; never a vendor HAL interface.
 *
 * Fixtures are copied by value. Reads do not advance timers or simulate a DHCP
 * daemon. IPv4 words are opaque and returned without byte-order conversion.
 * Reset (also the initial state) supplies zero scalars, empty names/DNS lists,
 * and no pending failures. These defaults, zeroed unused DNS/name storage, and
 * output preservation on failure are model policies, not vendor requirements.
 */
#ifndef DHCP_TEST_MODEL_H
#define DHCP_TEST_MODEL_H

#ifndef BUILD_LINUX
#error "dhcp_test_model is private to the Linux test build"
#endif

#define DHCP_TEST_IFNAME_SIZE 64
#define DHCP_TEST_DNS_CAPACITY 4
#define DHCP_TEST_SUCCESS 0
#define DHCP_TEST_FAILURE (-1)

/** Independent API namespaces, not IP protocol versions. */
typedef enum {
    DHCP_TEST_FAMILY_LEGACY,
    DHCP_TEST_FAMILY_NEWER,
    DHCP_TEST_FAMILY_COUNT
} dhcp_test_family_t;

/** Roles with public getters; eMTA exposes only three remaining timers. */
typedef enum {
    DHCP_TEST_ROLE_ERT,
    DHCP_TEST_ROLE_ECM,
#ifndef NO_MTA_FEATURE_SUPPORT
    DHCP_TEST_ROLE_EMTA,
#endif
    DHCP_TEST_ROLE_COUNT
} dhcp_test_role_t;

/** Private getter identifiers, deliberately independent of DHCPC_CMD. */
typedef enum {
    DHCP_TEST_LEASE_TIME,
    DHCP_TEST_REMAIN_LEASE_TIME,
    DHCP_TEST_REMAIN_RENEW_TIME,
    DHCP_TEST_REMAIN_REBIND_TIME,
    DHCP_TEST_CONFIG_ATTEMPTS,
    DHCP_TEST_IFNAME,
    DHCP_TEST_FSM_STATE,
    DHCP_TEST_IP_ADDR,
    DHCP_TEST_MASK,
    DHCP_TEST_GW,
    DHCP_TEST_DNS_SVRS,
    DHCP_TEST_DHCP_SVR,
    DHCP_TEST_FIELD_COUNT
} dhcp_test_field_t;

/** Bounded private list, translated member-by-member by each typed adapter. */
typedef struct {
    int number;
    unsigned int addrs[DHCP_TEST_DNS_CAPACITY];
} dhcp_test_dns_t;

/** One family/role observation, with no implicit timer or FSM transitions. */
typedef struct {
    unsigned int lease_time;
    unsigned int remain_lease_time;
    unsigned int remain_renew_time;
    unsigned int remain_rebind_time;
    int config_attempts;
    char ifname[DHCP_TEST_IFNAME_SIZE];
    int fsm_state;
    unsigned int ip_addr;
    unsigned int mask;
    unsigned int gw;
    dhcp_test_dns_t dns;
    unsigned int dhcp_svr;
} dhcp_test_snapshot_t;

/* PUBLIC_INTERFACE */
/** Reset every family/role snapshot and all pending failures to initial zeros. */
void dhcp_test_model_reset(void);

/* PUBLIC_INTERFACE */
/**
 * Copy snapshot into family/role, returning 0 or -1 for invalid keys/input.
 * A NUL must occur within the 64-byte name; DNS number must be in [0, 4].
 * Invalid loads are atomic no-ops. Valid loads clear unused name/DNS storage
 * but preserve pending failures. Numeric values are observations, not validated
 * vendor state-machine rules; only the exposed eMTA timer fields are readable.
 */
int dhcp_test_model_load(dhcp_test_family_t family, dhcp_test_role_t role,
                         const dhcp_test_snapshot_t *snapshot);

/* PUBLIC_INTERFACE */
/**
 * Arm one failure for the selected family/role/field; return 0 or -1.
 * Only the next valid, correctly typed read of that exact getter consumes it.
 * NULL/invalid reads and unrelated getters leave it pending. Re-arming an
 * already armed target is idempotent; distinct targets may be armed together.
 */
int dhcp_test_model_fail_next(dhcp_test_family_t family, dhcp_test_role_t role,
                              dhcp_test_field_t field);

/* PUBLIC_INTERFACE */
/**
 * Copy an unsigned scalar field to value, returning 0 or -1.
 * Reject NULL, invalid keys, unsupported role fields, or a signed/name/DNS
 * field. All errors preserve output; only an injected failure is consumed.
 */
int dhcp_test_model_get_uint(dhcp_test_family_t family, dhcp_test_role_t role,
                             dhcp_test_field_t field, unsigned int *value);

/* PUBLIC_INTERFACE */
/**
 * Copy CONFIG_ATTEMPTS or FSM_STATE to value, returning 0 or -1.
 * NULL, wrong-type/invalid keys and injected failures leave output untouched.
 */
int dhcp_test_model_get_int(dhcp_test_family_t family, dhcp_test_role_t role,
                            dhcp_test_field_t field, int *value);

/* PUBLIC_INTERFACE */
/**
 * Copy exactly 64 initialized bytes (including NUL) to name; return 0 or -1.
 * Caller must supply at least 64 writable bytes, as in the public HAL contract.
 * NULL, unsupported role/keys or injected failure leaves the buffer untouched.
 */
int dhcp_test_model_get_ifname(dhcp_test_family_t family, dhcp_test_role_t role,
                               char *name);

/* PUBLIC_INTERFACE */
/**
 * Copy number and all four DNS slots to list, returning 0 or -1.
 * Unused slots are zero. NULL, invalid/unsupported keys and injected failure
 * leave the complete output untouched.
 */
int dhcp_test_model_get_dns(dhcp_test_family_t family, dhcp_test_role_t role,
                            dhcp_test_dns_t *list);

#endif
