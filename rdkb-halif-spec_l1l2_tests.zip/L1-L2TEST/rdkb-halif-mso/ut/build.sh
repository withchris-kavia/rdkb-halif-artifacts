#!/usr/bin/env bash
# Copyright 2026 RDK Management. Licensed under the Apache License, Version 2.0.
set -euo pipefail
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# The dependency tree is intentionally read-only. Bootstrap separately if absent.
[[ -f $SCRIPT_DIR/ut-core/Makefile ]] || {
    echo 'Missing bootstrapped ut-core dependency; install it before building MSO tests.' >&2
    exit 1
}
[[ -f $SCRIPT_DIR/ut-core/framework/CUnit-2.1-3/config.h &&
   -f $SCRIPT_DIR/ut-core/framework/libfyaml-master/include/libfyaml.h ]] || {
    echo 'Missing bootstrapped CUnit/libfyaml dependency headers.' >&2
    exit 1
}
exec make -C "$SCRIPT_DIR" "$@"
