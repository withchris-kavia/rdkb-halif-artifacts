/* Copyright 2026 RDK Management. Licensed under the Apache License, Version 2.0. */
#include "mso_test_helpers.h"

/* PUBLIC_INTERFACE */
/** Register the L1 suite and propagate registration failure. */
int register_hal_l1_tests(void)
{
    return test_mso_hal_l1_register();
}

/* PUBLIC_INTERFACE */
/** Register the L2 suite and propagate registration failure. */
int register_hal_l2_tests(void)
{
    return test_mso_hal_l2_register();
}
