/* Copyright 2026 RDK Management. Licensed under the Apache License, Version 2.0. */
#include <string.h>
#include "mso_test_helpers.h"

static void scalar_contract(void)
{
    CU_ASSERT(SEC_PER_YEAR == 31536000);
    CU_ASSERT(SIZE_arrisCmDevHttpClientSeed == 8L);
    CU_ASSERT(RETURN_OK == 0 && RETURN_ERR == -1 && ERROR == -1);
    CU_ASSERT(TRUE == 1 && FALSE == 0 && ENABLE == 1);
    CU_ASSERT(sizeof(CHAR) == sizeof(char));
    CU_ASSERT(sizeof(UCHAR) == sizeof(unsigned char));
    CU_ASSERT(sizeof(BOOLEAN) == sizeof(unsigned char));
    CU_ASSERT(sizeof(INT) == sizeof(int));
    CU_ASSERT(sizeof(UINT) == sizeof(unsigned int));
    CU_ASSERT(sizeof(ULONG) == sizeof(unsigned long));
    CU_ASSERT(sizeof(uint16) == sizeof(unsigned short));
    CU_ASSERT(sizeof(uint32) == sizeof(unsigned long));
    CU_ASSERT(sizeof(boolean) == sizeof(int));
}

static void enum_contract(void)
{
    CU_ASSERT(Invalid_PWD == 0 && Good_PWD == 1 && Unique_PWD == 2);
    CU_ASSERT(Expired_PWD == 3 && TimeError == 4);
}

#ifdef BUILD_LINUX
static int begin(mso_vectors *vectors)
{
    int status = mso_case_begin(vectors);
    CU_ASSERT(status == 0);
    if (status != 0) {
        mso_case_end(vectors);
    }
    return status == 0;
}

static void seed_roundtrip(void)
{
    mso_vectors v;
    char retrieved[64];
    int status;
    if (!begin(&v)) {
        return;
    }
    memset(retrieved, 0xa5, sizeof retrieved);
    status = mso_get_pod_seed(retrieved);
    CU_ASSERT(status == RETURN_OK);
    CU_ASSERT(memchr(retrieved, '\0', sizeof retrieved) != NULL);
    CU_ASSERT(memcmp(retrieved, v.seed_a, sizeof retrieved) == 0);
    mso_secure_erase(retrieved, sizeof retrieved);
    CU_ASSERT(mso_is_erased(retrieved, sizeof retrieved));
    CU_ASSERT(mso_set_pod_seed(v.seed_b) == RETURN_OK);
    CU_ASSERT(mso_seed_matches(v.seed_b));
    mso_case_end(&v);
    CU_ASSERT(mso_is_erased(&v, sizeof v));
}

static void output_canaries(void)
{
    struct {
        unsigned char before[16];
        char seed[64];
        unsigned char after[16];
    } output;
    unsigned char guard[16];
    mso_vectors v;
    if (!begin(&v)) {
        return;
    }
    memset(&output, 0xa5, sizeof output);
    memset(guard, 0xa5, sizeof guard);
    CU_ASSERT(mso_get_pod_seed(output.seed) == RETURN_OK);
    CU_ASSERT(memcmp(output.before, guard, sizeof guard) == 0);
    CU_ASSERT(memcmp(output.after, guard, sizeof guard) == 0);
    CU_ASSERT(memchr(output.seed, '\0', sizeof output.seed) != NULL);
    mso_secure_erase(output.seed, sizeof output.seed);
    CU_ASSERT(mso_is_erased(output.seed, sizeof output.seed));
    mso_test_provider(1, 0);
    memset(output.seed, 0xa5, sizeof output.seed);
    CU_ASSERT(mso_get_pod_seed(output.seed) == RETURN_ERR);
    CU_ASSERT(memcmp(output.before, guard, sizeof guard) == 0);
    CU_ASSERT(memcmp(output.after, guard, sizeof guard) == 0);
    mso_secure_erase(&output, sizeof output);
    mso_case_end(&v);
}

static void invalid_inputs(void)
{
    mso_vectors v;
    char empty[64] = {0}, unterminated[64];
    if (!begin(&v)) {
        return;
    }
    memset(unterminated, 'x', sizeof unterminated);
    CU_ASSERT(mso_validatepwd(NULL) == Invalid_PWD);
    CU_ASSERT(mso_validatepwd(v.invalid) == Invalid_PWD);
    CU_ASSERT(mso_set_pod_seed(NULL) == RETURN_ERR);
    CU_ASSERT(mso_set_pod_seed(empty) == RETURN_ERR);
    CU_ASSERT(mso_set_pod_seed(unterminated) == RETURN_ERR);
    CU_ASSERT(mso_get_pod_seed(NULL) == RETURN_ERR);
    CU_ASSERT(mso_seed_matches(v.seed_a));
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    mso_secure_erase(unterminated, sizeof unterminated);
    mso_secure_erase(empty, sizeof empty);
    mso_case_end(&v);
}

static void expired_vector(void)
{
    mso_vectors v;
    if (!begin(&v)) {
        return;
    }
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    mso_test_clock(MSO_MODEL_DAY + 1, 1);
    CU_ASSERT(mso_validatepwd(v.good_a) == Expired_PWD);
    CU_ASSERT(mso_validatepwd(v.next_a) == Good_PWD);
    mso_case_end(&v);
}

static void clock_error(void)
{
    mso_vectors v;
    if (!begin(&v)) {
        return;
    }
    mso_test_clock(MSO_MODEL_DAY, 0);
    CU_ASSERT(mso_validatepwd(v.good_a) == TimeError);
    mso_test_clock(MSO_MODEL_DAY - 1, 1);
    CU_ASSERT(mso_validatepwd(v.good_a) == TimeError);
    mso_test_clock(MSO_MODEL_DAY, 1);
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    mso_case_end(&v);
}

static void unique_model_token(void)
{
    mso_vectors v;
    if (!begin(&v)) {
        return;
    }
    /* Fixture policy only: validation is non-consuming, including Unique. */
    CU_ASSERT(mso_validatepwd(v.unique) == Unique_PWD);
    CU_ASSERT(mso_validatepwd(v.unique) == Unique_PWD);
    CU_ASSERT(mso_seed_matches(v.seed_a));
    mso_case_end(&v);
}
#endif

/* PUBLIC_INTERFACE */
/** Register individually reported L1 tests; any failed addition fails registration. */
int test_mso_hal_l1_register(void)
{
    UT_test_suite_t *suite = UT_add_suite(UT_TESTS_L1, NULL, NULL);
    if (!suite) {
        return -1;
    }
#define ADD(name) do { if (!UT_add_test(suite, #name, name)) return -1; } while (0)
    ADD(scalar_contract);
    ADD(enum_contract);
#ifdef BUILD_LINUX
    ADD(seed_roundtrip);
    ADD(output_canaries);
    ADD(invalid_inputs);
    ADD(expired_vector);
    ADD(clock_error);
    ADD(unique_model_token);
#endif
#undef ADD
    return 0;
}
