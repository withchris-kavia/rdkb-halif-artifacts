/* Copyright 2026 RDK Management. Licensed under the Apache License, Version 2.0. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <unistd.h>
#include <limits.h>
#include <sys/stat.h>
#include "mso_test_helpers.h"
#include "TestDB.h"
#include "TestRun.h"

static unsigned int tests_run, tests_failed, assertions_failed, suites_failed;
static CU_ErrorCode run_error;
static int running, captured, registration_failed;

extern void __real_CU_cleanup_registry(void);

/* PUBLIC_INTERFACE */
/** Capture run counters before old ut-core destroys and resets its registry. */
void __wrap_CU_cleanup_registry(void)
{
    if (running && !captured) {
        tests_run = CU_get_number_of_tests_run();
        tests_failed = CU_get_number_of_tests_failed();
        assertions_failed = CU_get_number_of_failures();
        suites_failed = CU_get_number_of_suites_failed();
        run_error = CU_get_error();
        captured = 1;
    }
    __real_CU_cleanup_registry();
}

/* PUBLIC_INTERFACE */
/** Register without upstream assertions; keep failure sticky until process exit. */
UT_test_suite_t *__wrap_UT_add_suite(const char *name,
                                   UT_InitialiseFunction_t init,
                                   UT_CleanupFunction_t cleanup)
{
    CU_pSuite suite = CU_add_suite(name, init, cleanup);
    if (!suite) {
        registration_failed = 1;
    }
    return (UT_test_suite_t *)suite;
}

/* PUBLIC_INTERFACE */
/** Report test-registration failures without aborting in the protected framework. */
UT_test_t *__wrap_UT_add_test(UT_test_suite_t *suite, const char *name,
                            UT_TestFunction_t function)
{
    CU_pTest test = CU_add_test((CU_pSuite)suite, name, function);
    if (!test) {
        registration_failed = 1;
    }
    return (UT_test_t *)test;
}

static int group_number(const char *group)
{
    if (!strcmp(group, "all")) {
        return 0;
    }
    if (!strcmp(group, UT_TESTS_L1) || !strcmp(group, "L1") || !strcmp(group, "1")) {
        return 1;
    }
    if (!strcmp(group, UT_TESTS_L2) || !strcmp(group, "L2") || !strcmp(group, "2")) {
        return 2;
    }
    return -1;
}

static void usage(void)
{
    puts("Usage: hal_test [-b|-a|-c] [-p synthetic-profile] "
         "[-d all|UT_TESTS_L1|UT_TESTS_L2] [-e group] [-l log-directory] [-t]");
}

static int default_profile(char *path, size_t size)
{
    char executable[PATH_MAX];
    char *slash;
    ssize_t length = readlink("/proc/self/exe", executable, sizeof executable - 1);
    int count;
    if (length < 0 || (size_t)length >= sizeof executable - 1) {
        return -1;
    }
    executable[length] = '\0';
    slash = strrchr(executable, '/');
    if (!slash) {
        return -1;
    }
    *slash = '\0';
    count = snprintf(path, size, "%s/../profiles/mso_linux.yaml", executable);
    return count >= 0 && (size_t)count < size ? 0 : -1;
}

/* PUBLIC_INTERFACE */
/**
 * Parse CLI/profile inputs, register both levels, run tests and return 0 only for
 * a nonempty run with no assertion, suite, registration, or framework failures.
 * Arguments mirror supported ut-core modes plus ordered L1/L2 group filtering.
 */
int main(int argc, char **argv)
{
    char profile_path[PATH_MAX];
    char *framework_argv[5] = {0};
    char *mode = "-c";
    char *log_directory = NULL;
    const char *profile = NULL;
    int framework_argc = 1, option, result = EXIT_FAILURE;
    int enabled[3] = {1, 1, 1};
    int help = 0;
    struct stat info;
    CU_pSuite suite;
    UT_status_t run_status;

    framework_argv[0] = argv[0];
    opterr = 0;
    while ((option = getopt(argc, argv, "+:abcthp:l:d:e:")) != -1) {
        if (option == 'p') {
            if (!*optarg || profile) {
                goto invalid;
            }
            profile = optarg;
        } else if (option == 'd' || option == 'e') {
            int group = group_number(optarg);
            if (group < 0) {
                goto invalid;
            }
            if (group == 0) {
                enabled[1] = enabled[2] = option == 'e';
            } else {
                enabled[group] = option == 'e';
            }
        } else if (option == 'l') {
            if (!*optarg || strlen(optarg) > 200 ||
                stat(optarg, &info) != 0 || !S_ISDIR(info.st_mode) ||
                access(optarg, W_OK) != 0) {
                goto invalid;
            }
            log_directory = optarg;
        } else if (option == 'h') {
            help = 1;
        } else if (option == 'a' || option == 'b' ||
                   option == 'c' || option == 't') {
            mode = option == 'a' ? "-a" : option == 'b' ? "-b" :
                   option == 't' ? "-t" : "-c";
        } else {
            goto invalid;
        }
    }
    if (optind != argc) {
        goto invalid;
    }
    if (help) {
        usage();
        result = EXIT_SUCCESS;
        goto done;
    }
    /* getopt accepts clustered flags and attached values. Forward a bounded,
     * canonical argument list rather than expanding each original option. */
    framework_argv[framework_argc++] = mode;
    if (log_directory) {
        framework_argv[framework_argc++] = "-l";
        framework_argv[framework_argc++] = log_directory;
    }
#ifdef BUILD_LINUX
    if (!profile) {
        if (default_profile(profile_path, sizeof profile_path) != 0) {
            goto invalid_profile;
        }
        profile = profile_path;
    }
    if (stat(profile, &info) != 0 || !S_ISREG(info.st_mode) ||
        mso_profile_load(profile) != 0) {
        goto invalid_profile;
    }
#else
    /* Model vectors are never used against a vendor HAL. */
    (void)profile_path;
    (void)default_profile;
    if (profile) {
        goto invalid_profile;
    }
#endif
    /* Reset getopt for the old framework, excluding component-only arguments. */
    optind = 0;
    if (UT_init(framework_argc, framework_argv) != UT_STATUS_OK) {
        fputs("MSO initialization failed\n", stderr);
        goto cleanup;
    }
    CU_set_fail_on_inactive(CU_FALSE);
    if (register_hal_l1_tests() != 0 || register_hal_l2_tests() != 0 ||
        registration_failed || CU_get_error() != CUE_SUCCESS) {
        fputs("MSO registration failed\n", stderr);
        goto cleanup;
    }
    for (suite = CU_get_registry()->pSuite; suite; suite = suite->pNext) {
        int group = group_number(suite->pName);
        if (group > 0 &&
            CU_set_suite_active(suite, enabled[group] ? CU_TRUE : CU_FALSE) != CUE_SUCCESS) {
            fputs("MSO selection failed\n", stderr);
            goto cleanup;
        }
    }
    running = 1;
    run_status = UT_run_tests();
    running = 0;
    printf("MSO_RESULT tests=%u failed=%u assertions=%u suites=%u error=%d captured=%d\n",
           tests_run, tests_failed, assertions_failed, suites_failed,
           (int)run_error, captured);
    if (run_status == UT_STATUS_OK && captured && tests_run > 0 &&
        tests_failed == 0 && assertions_failed == 0 && suites_failed == 0 &&
        run_error == CUE_SUCCESS) {
        result = EXIT_SUCCESS;
    }
cleanup:
    if (CU_get_registry()) {
        __real_CU_cleanup_registry();
    }
    UT_exit();
    goto done;
invalid_profile:
    fputs("Invalid MSO synthetic profile\n", stderr);
    goto done;
invalid:
    fputs("Invalid MSO arguments\n", stderr);
    usage();
done:
#ifdef BUILD_LINUX
    mso_test_reset();
#endif
    mso_profile_clear();
    return result;
}
