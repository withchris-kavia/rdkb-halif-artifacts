#ifndef MSO_TEST_HELPERS_H
#define MSO_TEST_HELPERS_H
#include <stddef.h>
#include "ut.h"
#include "mso_mgmt_hal.h"
#ifdef BUILD_LINUX
#include "mso_test_control.h"
typedef mso_model_vectors mso_vectors;
#else
/* Sizes are caller capacities, not the unrelated public 8L constant. */
typedef struct {
    char seed_a[64], seed_b[64], good_a[64], good_b[64];
    char next_a[64], unique[64], invalid[64];
} mso_vectors;
#endif
#define UT_TESTS_L1 "UT_TESTS_L1"
#define UT_TESTS_L2 "UT_TESTS_L2"
/* PUBLIC_INTERFACE */
/** Load and validate a Linux-only synthetic profile; return 0 or -1. */
int mso_profile_load(const char *path);
/* PUBLIC_INTERFACE */
/** Erase component-owned profile vectors. */
void mso_profile_clear(void);
/* PUBLIC_INTERFACE */
/** Overwrite memory using volatile stores that cannot be optimized away. */
void mso_secure_erase(void *memory, size_t size);
/* PUBLIC_INTERFACE */
/** Return whether every byte in a buffer is zero. */
int mso_is_erased(const void *memory, size_t size);
/* PUBLIC_INTERFACE */
/** Start an isolated Linux model case with a private vector copy and seed A. */
int mso_case_begin(mso_vectors *vectors);
/* PUBLIC_INTERFACE */
/** Erase case vectors and model state; safe after partial initialization. */
void mso_case_end(mso_vectors *vectors);
/* PUBLIC_INTERFACE */
/** Read, compare without logging values, and erase a caller-owned seed buffer. */
int mso_seed_matches(const char *expected);
/* PUBLIC_INTERFACE */
/** Register all L1 suites, returning nonzero on any failure. */
int register_hal_l1_tests(void);
/* PUBLIC_INTERFACE */
/** Register all L2 suites, returning nonzero on any failure. */
int register_hal_l2_tests(void);
/* PUBLIC_INTERFACE */
/** Register the MSO L1 suite. */
int test_mso_hal_l1_register(void);
/* PUBLIC_INTERFACE */
/** Register the MSO L2 suite. */
int test_mso_hal_l2_register(void);
#endif
