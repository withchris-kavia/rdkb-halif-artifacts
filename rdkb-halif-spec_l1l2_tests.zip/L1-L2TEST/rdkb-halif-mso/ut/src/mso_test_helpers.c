/* Copyright 2026 RDK Management. Licensed under the Apache License, Version 2.0. */
#include <string.h>
#include <libfyaml.h>
#include "ut_kvp.h"
#include "mso_test_helpers.h"

static mso_vectors profile;
static int loaded;

/* PUBLIC_INTERFACE */
/** Securely overwrite a caller-owned buffer. */
void mso_secure_erase(void *memory, size_t size)
{
    volatile unsigned char *p = memory;
    while (size--) {
        *p++ = 0;
    }
}

/* PUBLIC_INTERFACE */
/** Inspect erased memory without emitting any buffer contents. */
int mso_is_erased(const void *memory, size_t size)
{
    const unsigned char *p = memory;
    unsigned char bits = 0;
    while (size--) {
        bits |= *p++;
    }
    return bits == 0;
}

/* PUBLIC_INTERFACE */
/** Erase the component's cached synthetic profile. */
void mso_profile_clear(void)
{
    mso_secure_erase(&profile, sizeof profile);
    loaded = 0;
}

#ifdef BUILD_LINUX
/* Parser errors may echo credential source lines; never forward those bytes. */
static void discard_profile_diagnostic(struct fy_diag *diag, void *user,
                                       const char *buffer, size_t size)
{
    (void)diag;
    (void)user;
    (void)buffer;
    (void)size;
}

static int scalar_fits(struct fy_document *doc, const char *key, size_t capacity)
{
    struct fy_node *node = fy_node_by_path(fy_document_root(doc), key, -1,
                                         FYNWF_DONT_FOLLOW);
    const char *value;
    size_t length = 0;
    if (!node || !fy_node_is_scalar(node)) {
        return 0;
    }
    value = fy_node_get_scalar(node, &length);
    return value && length > 0 && length < capacity &&
           !memchr(value, '\0', length);
}
#endif

/* PUBLIC_INTERFACE */
/** Load only Linux synthetic profiles; reject malformed fields before old KVP calls. */
int mso_profile_load(const char *path)
{
    mso_profile_clear();
#ifdef BUILD_LINUX
    struct fy_parse_cfg config = { .flags = FYPCF_QUIET };
    struct fy_diag_cfg diagnostics;
    struct fy_document *doc;
    ut_kvp_instance_t *instance;
    char target[32];
    const char *keys[] = { "/target", "/seed_a", "/seed_b", "/good_a",
                          "/good_b", "/next_a", "/unique", "/invalid" };
    size_t i;
    int result = -1;
    if (!path || !*path) {
        return -1;
    }
    /* FYPCF_QUIET only suppresses informational messages, not syntax errors. */
    fy_diag_cfg_default(&diagnostics);
    diagnostics.fp = NULL;
    diagnostics.output_fn = discard_profile_diagnostic;
    config.diag = fy_diag_create(&diagnostics);
    if (!config.diag) {
        return -1;
    }
    doc = fy_document_build_from_file(&config, path);
    if (!doc || fy_diag_got_error(config.diag)) {
        fy_document_destroy(doc);
        fy_diag_destroy(config.diag);
        return -1;
    }
    for (i = 0; i < sizeof keys / sizeof keys[0]; ++i) {
        if (!scalar_fits(doc, keys[i], i == 0 ? sizeof target : sizeof profile.seed_a)) {
            fy_document_destroy(doc);
            fy_diag_destroy(config.diag);
            return -1;
        }
    }
    fy_document_destroy(doc);
    fy_diag_destroy(config.diag);
    instance = ut_kvp_createInstance();
    if (!instance) {
        return -1;
    }
    if (ut_kvp_open(instance, (char *)path) != UT_KVP_STATUS_SUCCESS) {
        goto done;
    }
    memset(target, 0xa5, sizeof target);
    if (ut_kvp_getStringField(instance, "target", target, sizeof target) !=
        UT_KVP_STATUS_SUCCESS || !memchr(target, '\0', sizeof target) ||
        strcmp(target, "mso-linux-synthetic-v1") != 0) {
        goto done;
    }
    /* sizeof applies to each real array, never a pointer or the public 8L constant. */
#define READ_VECTOR(field) \
    do { \
        memset(profile.field, 0xa5, sizeof profile.field); \
        if (ut_kvp_getStringField(instance, #field, profile.field, \
                                 sizeof profile.field) != UT_KVP_STATUS_SUCCESS || \
            !memchr(profile.field, '\0', sizeof profile.field) || !profile.field[0]) { \
            goto done; \
        } \
    } while (0)
    READ_VECTOR(seed_a);
    READ_VECTOR(seed_b);
    READ_VECTOR(good_a);
    READ_VECTOR(good_b);
    READ_VECTOR(next_a);
    READ_VECTOR(unique);
    READ_VECTOR(invalid);
#undef READ_VECTOR
    if (mso_test_configure(&profile) == 0) {
        mso_test_reset();
        loaded = 1;
        result = 0;
    }
done:
    mso_secure_erase(target, sizeof target);
    ut_kvp_destroyInstance(instance);
    if (result != 0) {
        mso_profile_clear();
    }
    return result;
#else
    (void)path;
    return -1; /* Synthetic profiles must never drive vendor hardware. */
#endif
}

/* PUBLIC_INTERFACE */
/** Copy vectors and reset model state before each stateful scenario. */
int mso_case_begin(mso_vectors *vectors)
{
    memset(vectors, 0, sizeof *vectors);
#ifdef BUILD_LINUX
    if (!loaded) {
        return -1;
    }
    *vectors = profile;
    if (mso_test_configure(vectors) != 0) {
        return -1;
    }
    return mso_set_pod_seed(vectors->seed_a);
#else
    return -1;
#endif
}

/* PUBLIC_INTERFACE */
/** Erase local vectors and every model-owned seed after a scenario. */
void mso_case_end(mso_vectors *vectors)
{
#ifdef BUILD_LINUX
    mso_test_reset();
#endif
    mso_secure_erase(vectors, sizeof *vectors);
}

/* PUBLIC_INTERFACE */
/** Compare readback using only a boolean result; always erase the retrieved seed. */
int mso_seed_matches(const char *expected)
{
    char retrieved[64] = {0};
    int result = mso_get_pod_seed(retrieved) == RETURN_OK &&
                 memchr(retrieved, '\0', sizeof retrieved) &&
                 strcmp(retrieved, expected) == 0;
    mso_secure_erase(retrieved, sizeof retrieved);
    return result && mso_is_erased(retrieved, sizeof retrieved);
}
