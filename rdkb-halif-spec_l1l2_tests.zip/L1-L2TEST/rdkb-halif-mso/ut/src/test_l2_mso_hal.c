/* Copyright 2026 RDK Management. Licensed under the Apache License, Version 2.0. */
#include <string.h>
#include "mso_test_helpers.h"

#ifdef BUILD_LINUX
static int begin(mso_vectors *v)
{
    int status = mso_case_begin(v);
    CU_ASSERT(status == 0);
    if (status != 0) {
        mso_case_end(v);
    }
    return status == 0;
}

static void seed_a_lifecycle(void)
{
    mso_vectors v;
    if (!begin(&v)) {
        return;
    }
    CU_ASSERT(mso_seed_matches(v.seed_a));
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    CU_ASSERT(mso_validatepwd(v.good_b) == Invalid_PWD);
    CU_ASSERT(mso_validatepwd(v.invalid) == Invalid_PWD);
    mso_case_end(&v);
    CU_ASSERT(mso_is_erased(&v, sizeof v));
}

static void stable_repeated_reads(void)
{
    mso_vectors v;
    unsigned int i;
    if (!begin(&v)) {
        return;
    }
    for (i = 0; i < 5; ++i) {
        CU_ASSERT(mso_seed_matches(v.seed_a));
        CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    }
    mso_case_end(&v);
}

static void seed_b_replacement(void)
{
    mso_vectors v;
    if (!begin(&v)) {
        return;
    }
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    CU_ASSERT(mso_set_pod_seed(v.seed_b) == RETURN_OK);
    CU_ASSERT(mso_seed_matches(v.seed_b));
    CU_ASSERT(mso_validatepwd(v.good_a) == Invalid_PWD);
    CU_ASSERT(mso_validatepwd(v.good_b) == Good_PWD);
    CU_ASSERT(mso_set_pod_seed(v.seed_a) == RETURN_OK);
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    mso_case_end(&v);
}

static void nonmutating_validation(void)
{
    mso_vectors v, original;
    if (!begin(&v)) {
        return;
    }
    original = v;
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    CU_ASSERT(mso_validatepwd(v.invalid) == Invalid_PWD);
    CU_ASSERT(mso_validatepwd(v.unique) == Unique_PWD);
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    CU_ASSERT(memcmp(&v, &original, sizeof v) == 0);
    CU_ASSERT(mso_seed_matches(v.seed_a));
    mso_secure_erase(&original, sizeof original);
    CU_ASSERT(mso_is_erased(&original, sizeof original));
    mso_case_end(&v);
}

static void failed_update_atomicity(void)
{
    mso_vectors v;
    char invalid_seed[64] = "synthetic-unrecognized-seed";
    if (!begin(&v)) {
        mso_secure_erase(invalid_seed, sizeof invalid_seed);
        return;
    }
    mso_test_provider(0, 1);
    CU_ASSERT(mso_set_pod_seed(v.seed_b) == RETURN_ERR);
    CU_ASSERT(mso_seed_matches(v.seed_a));
    mso_test_provider(0, 0);
    CU_ASSERT(mso_set_pod_seed(invalid_seed) == RETURN_ERR);
    CU_ASSERT(mso_seed_matches(v.seed_a));
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    CU_ASSERT(mso_set_pod_seed(v.seed_b) == RETURN_OK);
    CU_ASSERT(mso_seed_matches(v.seed_b));
    mso_secure_erase(invalid_seed, sizeof invalid_seed);
    mso_case_end(&v);
}

static void virtual_clock_rollover(void)
{
    mso_vectors v;
    if (!begin(&v)) {
        return;
    }
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    mso_test_clock(MSO_MODEL_DAY + 1, 1);
    CU_ASSERT(mso_validatepwd(v.good_a) == Expired_PWD);
    CU_ASSERT(mso_validatepwd(v.next_a) == Good_PWD);
    mso_test_clock(MSO_MODEL_DAY + 2, 1);
    CU_ASSERT(mso_validatepwd(v.next_a) == Expired_PWD);
    mso_test_clock(MSO_MODEL_DAY + 2, 0);
    CU_ASSERT(mso_validatepwd(v.next_a) == TimeError);
    CU_ASSERT(mso_seed_matches(v.seed_a));
    mso_test_clock(MSO_MODEL_DAY, 1);
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    mso_case_end(&v);
}

static void provider_failure_recovery(void)
{
    mso_vectors v;
    char retrieved[64], untouched[64];
    if (!begin(&v)) {
        return;
    }
    memset(retrieved, 0xa5, sizeof retrieved);
    memset(untouched, 0xa5, sizeof untouched);
    mso_test_provider(1, 1);
    CU_ASSERT(mso_get_pod_seed(retrieved) == RETURN_ERR);
    CU_ASSERT(memcmp(retrieved, untouched, sizeof retrieved) == 0);
    CU_ASSERT(mso_validatepwd(v.good_a) == Invalid_PWD);
    CU_ASSERT(mso_set_pod_seed(v.seed_b) == RETURN_ERR);
    mso_test_provider(0, 0);
    CU_ASSERT(mso_seed_matches(v.seed_a));
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    CU_ASSERT(mso_set_pod_seed(v.seed_b) == RETURN_OK);
    CU_ASSERT(mso_validatepwd(v.good_b) == Good_PWD);
    mso_secure_erase(retrieved, sizeof retrieved);
    mso_secure_erase(untouched, sizeof untouched);
    CU_ASSERT(mso_is_erased(retrieved, sizeof retrieved));
    mso_case_end(&v);
}

static void isolation_restoration_erasure(void)
{
    mso_vectors v;
    char retrieved[64] = {0};
    if (!begin(&v)) {
        return;
    }
    CU_ASSERT(mso_seed_matches(v.seed_a));
    CU_ASSERT(mso_set_pod_seed(v.seed_b) == RETURN_OK);
    CU_ASSERT(mso_get_pod_seed(retrieved) == RETURN_OK);
    mso_secure_erase(retrieved, sizeof retrieved);
    CU_ASSERT(mso_is_erased(retrieved, sizeof retrieved));
    mso_test_provider(1, 1);
    mso_test_clock(MSO_MODEL_DAY + 5, 0);
    mso_test_reset();
    CU_ASSERT(mso_get_pod_seed(retrieved) == RETURN_ERR);
    CU_ASSERT(mso_validatepwd(v.good_a) == Invalid_PWD);
    CU_ASSERT(mso_test_configure(&v) == 0);
    CU_ASSERT(mso_set_pod_seed(v.seed_a) == RETURN_OK);
    CU_ASSERT(mso_seed_matches(v.seed_a));
    CU_ASSERT(mso_validatepwd(v.good_a) == Good_PWD);
    mso_case_end(&v);
    CU_ASSERT(mso_is_erased(&v, sizeof v));
    mso_secure_erase(retrieved, sizeof retrieved);
}
#endif

/* PUBLIC_INTERFACE */
/** Register eight Linux model state sequences; vendor builds omit model controls. */
int test_mso_hal_l2_register(void)
{
#ifdef BUILD_LINUX
    UT_test_suite_t *suite = UT_add_suite(UT_TESTS_L2, NULL, NULL);
    if (!suite) {
        return -1;
    }
#define ADD(name) do { if (!UT_add_test(suite, #name, name)) return -1; } while (0)
    ADD(seed_a_lifecycle);
    ADD(stable_repeated_reads);
    ADD(seed_b_replacement);
    ADD(nonmutating_validation);
    ADD(failed_update_atomicity);
    ADD(virtual_clock_rollover);
    ADD(provider_failure_recovery);
    ADD(isolation_restoration_erasure);
#undef ADD
#endif
    return 0;
}
