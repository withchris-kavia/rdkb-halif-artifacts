/* Copyright 2026 RDK Management. Licensed under the Apache License, Version 2.0. */
#include <string.h>
#include "mso_mgmt_hal.h"
#include "mso_test_control.h"

static mso_model_vectors model;
static char stored[MSO_SEED_CAPACITY];
static long today = MSO_MODEL_DAY;
static int clock_valid = 1;
static int read_failed, write_failed, configured;

static void erase(void *memory, size_t size)
{
    volatile unsigned char *p = memory;
    while (size--) {
        *p++ = 0;
    }
}

/* PUBLIC_INTERFACE */
/** Erase all synthetic state and restore the initial virtual clock. */
void mso_test_reset(void)
{
    erase(&model, sizeof model);
    erase(stored, sizeof stored);
    today = MSO_MODEL_DAY;
    clock_valid = 1;
    read_failed = write_failed = configured = 0;
}

/* PUBLIC_INTERFACE */
/** Install distinct bounded synthetic vectors; invalid input is nonmutating. */
int mso_test_configure(const mso_model_vectors *vectors)
{
    const char *fields[7];
    size_t i, j;
    if (!vectors) {
        return -1;
    }
    fields[0] = vectors->seed_a; fields[1] = vectors->seed_b;
    fields[2] = vectors->good_a; fields[3] = vectors->good_b;
    fields[4] = vectors->next_a; fields[5] = vectors->unique;
    fields[6] = vectors->invalid;
    for (i = 0; i < 7; ++i) {
        if (!fields[i][0] || !memchr(fields[i], '\0', MSO_VECTOR_CAPACITY)) {
            return -1;
        }
        for (j = 0; j < i; ++j) {
            if (strcmp(fields[i], fields[j]) == 0) {
                return -1;
            }
        }
    }
    mso_test_reset();
    model = *vectors;
    configured = 1;
    return 0;
}

/* PUBLIC_INTERFACE */
/** Set the synthetic day and clock availability without changing the host clock. */
void mso_test_clock(long day, int valid)
{
    today = day;
    clock_valid = valid != 0;
}

/* PUBLIC_INTERFACE */
/** Inject persistent provider errors until explicitly cleared. */
void mso_test_provider(int read_error, int write_error)
{
    read_failed = read_error != 0;
    write_failed = write_error != 0;
}

/* PUBLIC_INTERFACE */
/** Atomically store a recognized fixture seed; no real decryption is performed. */
INT mso_set_pod_seed(char *seed)
{
    if (!configured || !seed || write_failed ||
        !memchr(seed, '\0', MSO_SEED_CAPACITY) ||
        (strcmp(seed, model.seed_a) != 0 && strcmp(seed, model.seed_b) != 0)) {
        return RETURN_ERR;
    }
    erase(stored, sizeof stored);
    memcpy(stored, seed, strlen(seed) + 1);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy 64 bytes on success; failures leave the caller's buffer untouched. */
INT mso_get_pod_seed(char *seed)
{
    if (!configured || !seed || read_failed || !stored[0]) {
        return RETURN_ERR;
    }
    memcpy(seed, stored, sizeof stored);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/**
 * Return a synthetic validation status without mutating state.
 * Unique is a reserved fixture token, not a production uniqueness guarantee.
 * Read failure maps to Invalid; an unavailable/backward clock maps to TimeError.
 * Only seed A defines a next-day token. This is NOT vendor PoD cryptography.
 */
mso_pwd_ret_status mso_validatepwd(char *pwd)
{
    int seed_a;
    if (!pwd || !configured || !stored[0] || read_failed) {
        return Invalid_PWD;
    }
    if (!clock_valid || today < MSO_MODEL_DAY) {
        return TimeError;
    }
    seed_a = strcmp(stored, model.seed_a) == 0;
    if (strcmp(pwd, model.unique) == 0) {
        return Unique_PWD;
    }
    if (today == MSO_MODEL_DAY &&
        strcmp(pwd, seed_a ? model.good_a : model.good_b) == 0) {
        return Good_PWD;
    }
    if (seed_a && today == MSO_MODEL_DAY + 1 && strcmp(pwd, model.next_a) == 0) {
        return Good_PWD;
    }
    if ((today > MSO_MODEL_DAY &&
         strcmp(pwd, seed_a ? model.good_a : model.good_b) == 0) ||
        (seed_a && today > MSO_MODEL_DAY + 1 && strcmp(pwd, model.next_a) == 0)) {
        return Expired_PWD;
    }
    return Invalid_PWD;
}
