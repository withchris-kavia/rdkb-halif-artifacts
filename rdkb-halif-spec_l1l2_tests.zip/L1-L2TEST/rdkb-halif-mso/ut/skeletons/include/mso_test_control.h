#ifndef MSO_TEST_CONTROL_H
#define MSO_TEST_CONTROL_H
#ifndef BUILD_LINUX
#error "MSO model controls are Linux-only"
#endif
#include <stddef.h>
#define MSO_SEED_CAPACITY 64
#define MSO_VECTOR_CAPACITY 64
#define MSO_MODEL_DAY 100L
/* Synthetic vectors only: no PoD encryption, decryption or vendor algorithm. */
typedef struct {
    char seed_a[MSO_SEED_CAPACITY];
    char seed_b[MSO_SEED_CAPACITY];
    char good_a[MSO_VECTOR_CAPACITY];
    char good_b[MSO_VECTOR_CAPACITY];
    char next_a[MSO_VECTOR_CAPACITY];
    char unique[MSO_VECTOR_CAPACITY];
    char invalid[MSO_VECTOR_CAPACITY];
} mso_model_vectors;
/* PUBLIC_INTERFACE */
/** Reset and erase model state, including vectors and injected failures. */
void mso_test_reset(void);
/* PUBLIC_INTERFACE */
/** Install bounded synthetic vectors, returning 0 on success or -1 on error. */
int mso_test_configure(const mso_model_vectors *vectors);
/* PUBLIC_INTERFACE */
/** Set a virtual day and clock validity without touching the host clock. */
void mso_test_clock(long day, int valid);
/* PUBLIC_INTERFACE */
/** Set persistent provider read/write failures until explicitly cleared. */
void mso_test_provider(int read_error, int write_error);
#endif
