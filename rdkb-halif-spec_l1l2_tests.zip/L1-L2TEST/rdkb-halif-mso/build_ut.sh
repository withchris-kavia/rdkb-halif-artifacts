#!/usr/bin/env bash
# Copyright 2026 RDK Management. Licensed under the Apache License, Version 2.0.
set -euo pipefail
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
DIR=$SCRIPT_DIR
if [[ ${1:-} == -h || ${1:-} == --help ]]; then
    printf '%s\n' 'Usage: build_ut.sh [--dir DIRECTORY] [make arguments ...]'
    exit 0
fi
if [[ ${1:-} == --dir ]]; then
    [[ $# -ge 2 && -n $2 ]] || { echo 'Missing --dir directory' >&2; exit 2; }
    DIR=$2
    shift 2
fi
UT_DIR=$DIR/ut
if [[ ! -d $UT_DIR ]]; then
    # Discover the component remote, not the caller's working directory.
    REMOTE=$(git -C "$SCRIPT_DIR" remote get-url origin)
    [[ -n $REMOTE ]] || { echo 'Missing component origin remote' >&2; exit 1; }
    TEST_REPO=${REMOTE//halif/halif-test}
    TEST_REPO=${TEST_REPO//hal-/haltest-}
    git clone -- "$TEST_REPO" "$UT_DIR"
    git -C "$UT_DIR" checkout "${UT_PROJECT_VERSION:-main}"
fi
[[ -f $UT_DIR/build.sh ]] || { echo 'Missing unit-test build script' >&2; exit 1; }
exec bash "$UT_DIR/build.sh" "$@"
