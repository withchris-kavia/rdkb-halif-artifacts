/*
 * If not stated otherwise in this file or this component's LICENSE file the
 * following copyright and licenses apply:
 *
 * Copyright 2023 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <arpa/inet.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include "cm_hal_test_control.h"

/* All mutable model state lives here. No retained heap objects or host I/O. */
static struct {
    BOOLEAN ready;
    cm_hal_test_channels_t channels;
    cm_hal_test_observations_t observations;
    cm_hal_test_activity_t activity;
    CMMGMT_CM_EventLogEntry_t logs[CM_HAL_TEST_MAX_LOGS];
    size_t log_count;
    char mdd_mode[64];
    UINT8 us_channel_id;
    ULONG start_frequency;
    ULONG reinit_threshold;
    char http_url[CM_HAL_TEST_HTTP_CAPACITY];
    char http_filename[CM_HAL_TEST_HTTP_CAPACITY];
    unsigned int http_interface;
    INT download_status;
    cm_hal_DiplexerVariationCallback callback;
    BOOLEAN dispatching;
    char fail_api[80];
    BOOLEAN fail_allocation;
} model;

/* Only apply to actual fixed arrays, never a pointer supplied by a caller. */
#define TERMINATE(object, field) \
    ((object)->field[sizeof((object)->field) - 1] = '\0')

static size_t bounded_length(const char *text, size_t capacity)
{
    size_t i = 0;
    if (text == NULL)
        return capacity;
    while (i < capacity && text[i] != '\0')
        ++i;
    return i;
}

static void copy_string(char *destination, size_t capacity, const char *source)
{
    size_t length = bounded_length(source, capacity - 1);
    memcpy(destination, source, length);
    destination[length] = '\0';
}

static void terminate_observations(cm_hal_test_observations_t *o)
{
    TERMINATE(o, cm_status);
    TERMINATE(o, provision_type);
    TERMINATE(o, certificate_path);
    TERMINATE(o, market);
    TERMINATE(&o->docsis, DOCSISVersion);
    TERMINATE(&o->docsis, DOCSISDownstreamScanning);
    TERMINATE(&o->docsis, DOCSISDownstreamRanging);
    TERMINATE(&o->docsis, DOCSISUpstreamScanning);
    TERMINATE(&o->docsis, DOCSISUpstreamRanging);
    TERMINATE(&o->docsis, DOCSISTftpStatus);
    TERMINATE(&o->docsis, DOCSISDataRegComplete);
    TERMINATE(&o->docsis, DOCSISConfigFileName);
    TERMINATE(&o->docsis, ToDStatus);
    TERMINATE(&o->docsis, UpstreamServiceFlowParams);
    TERMINATE(&o->docsis, DownstreamServiceFlowParams);
    TERMINATE(&o->docsis, DOCSISDownstreamDataRate);
    TERMINATE(&o->docsis, DOCSISUpstreamDataRate);
    TERMINATE(&o->docsis, CoreVersion);
    TERMINATE(&o->dhcp, BootFileName);
    TERMINATE(&o->dhcp, TimeServer);
    TERMINATE(&o->dhcp, RebindTimeRemaining);
    TERMINATE(&o->dhcp, RenewTimeRemaining);
    TERMINATE(&o->dhcp, MACAddress);
    TERMINATE(&o->dhcp, DOCSISDHCPStatus);
    TERMINATE(&o->dhcpv6, IPv6Address);
    TERMINATE(&o->dhcpv6, IPv6BootFileName);
    TERMINATE(&o->dhcpv6, IPv6Prefix);
    TERMINATE(&o->dhcpv6, IPv6Router);
    TERMINATE(&o->dhcpv6, IPv6TFTPServer);
    TERMINATE(&o->dhcpv6, IPv6TimeServer);
    TERMINATE(&o->cpe, IPAddress);
    TERMINATE(&o->cpe, MACAddress);
}

static void reset_preferences(void)
{
    copy_string(model.mdd_mode, sizeof(model.mdd_mode), "honorMdd");
    model.us_channel_id = 1;
    model.start_frequency = 600000000UL;
    model.reinit_threshold = 0;
    model.http_url[0] = '\0';
    model.http_filename[0] = '\0';
    model.http_interface = 0;
    model.activity.led_flash = FALSE;
}

/* PUBLIC_INTERFACE */
/** Restore model fixtures and controls; see the internal control header. */
void cm_hal_test_reset(void)
{
    size_t i;
    memset(&model, 0, sizeof(model));
    model.ready = TRUE;
    reset_preferences();
    model.channels.ds_count = 2;
    model.channels.us_count = 2;
    model.channels.ofdm_count = 1;
    model.channels.ofdma_count = 1;
    model.channels.status_count = 1;
    for (i = 0; i < 2; ++i) {
        CMMGMT_CM_DS_CHANNEL *ds = &model.channels.ds[i];
        CMMGMT_CM_US_CHANNEL *us = &model.channels.us[i];
        ds->ChannelID = (ULONG)i + 1;
        copy_string(ds->Frequency, sizeof(ds->Frequency),
                    i == 0 ? "600000000" : "606000000");
        copy_string(ds->PowerLevel, sizeof(ds->PowerLevel), "-1.5");
        copy_string(ds->SNRLevel, sizeof(ds->SNRLevel), "38");
        copy_string(ds->Modulation, sizeof(ds->Modulation), "256-QAM");
        copy_string(ds->LockStatus, sizeof(ds->LockStatus), "Locked");
        ds->Octets = 1000;
        us->ChannelID = (ULONG)i + 1;
        copy_string(us->Frequency, sizeof(us->Frequency),
                    i == 0 ? "30000000" : "36000000");
        copy_string(us->PowerLevel, sizeof(us->PowerLevel), "45");
        copy_string(us->ChannelType, sizeof(us->ChannelType), "ATDMA");
        copy_string(us->SymbolRate, sizeof(us->SymbolRate), "5120000");
        copy_string(us->Modulation, sizeof(us->Modulation), "64-QAM");
        copy_string(us->LockStatus, sizeof(us->LockStatus), "Locked");
    }
    model.channels.ofdm[0] = (DOCSIF31_CM_DS_OFDM_CHAN) {
        .ChannelId = 33, .ChanIndicator = 2, .SubcarrierZeroFreq = 700000000,
        .FirstActiveSubcarrierNum = 148, .LastActiveSubcarrierNum = 2047,
        .NumActiveSubcarriers = 1900, .SubcarrierSpacing = 50000,
        .CyclicPrefix = 192, .RollOffPeriod = 128, .PlcFreq = 710000000,
        .NumPilots = 16, .TimeInterleaverDepth = 16,
        .averageSNR = "38", .PowerLevel = "-15",
        .PlcTotalCodewords = 10000, .NcpTotalFields = 10000
    };
    model.channels.ofdma[0] = (DOCSIF31_CM_US_OFDMA_CHAN) {
        .ChannelId = 3, .ConfigChangeCt = 1, .SubcarrierZeroFreq = 5000000,
        .FirstActiveSubcarrierNum = 74, .LastActiveSubcarrierNum = 1000,
        .NumActiveSubcarriers = 927, .SubcarrierSpacing = 50000,
        .CyclicPrefix = 192, .RollOffPeriod = 128, .NumSymbolsPerFrame = 16,
        .TxPower = 180, .PreEqEnabled = TRUE
    };
    model.channels.status[0] = (DOCSIF31_CMSTATUSOFDMA_US) {
        .ChannelId = 3, .RangingStatus = 4
    };
    model.observations = (cm_hal_test_observations_t) {
        .docsis = {
            .DOCSISVersion = "3.1",
            .DOCSISDownstreamScanning = "Complete",
            .DOCSISDownstreamRanging = "Complete",
            .DOCSISUpstreamScanning = "Complete",
            .DOCSISUpstreamRanging = "Complete",
            .DOCSISTftpStatus = "DownloadComplete",
            .DOCSISDataRegComplete = "RegistrationComplete",
            .DOCSISDHCPAttempts = 1, .DOCSISConfigFileName = "reference.cm",
            .DOCSISTftpAttempts = 1, .ToDStatus = "Complete",
            .BPIState = TRUE, .NetworkAccess = TRUE,
            .UpgradeServerIP = { .Dot = {192, 0, 2, 10} },
            .MaxCpeAllowed = 1, .UpstreamServiceFlowParams = "Reference upstream",
            .DownstreamServiceFlowParams = "Reference downstream",
            .DOCSISDownstreamDataRate = "1000000000",
            .DOCSISUpstreamDataRate = "100000000", .CoreVersion = "reference-1"
        },
        .codewords = { .UnerroredCodewords = 1000 },
        .dhcp = {
            .IPAddress = { .Dot = {192, 0, 2, 2} },
            .BootFileName = "reference.cm",
            .SubnetMask = { .Dot = {255, 255, 255, 0} },
            .Gateway = { .Dot = {192, 0, 2, 1} },
            .TFTPServer = { .Dot = {192, 0, 2, 10} },
            .TimeServer = "192.0.2.11", .LeaseTimeRemaining = 3600,
            .RebindTimeRemaining = "3150", .RenewTimeRemaining = "1800",
            .MACAddress = "02:00:00:00:00:01", .DOCSISDHCPStatus = "Complete"
        },
        .dhcpv6 = {
            .IPv6Address = "2001:db8::2", .IPv6BootFileName = "reference.cm",
            .IPv6Prefix = "2001:db8::/64", .IPv6Router = "2001:db8::1",
            .IPv6TFTPServer = "2001:db8::10", .IPv6TimeServer = "2001:db8::11",
            .IPv6LeaseTimeRemaining = 3600, .IPv6RebindTimeRemaining = 3150,
            .IPv6RenewTimeRemaining = 1800
        },
        .cpe = { .IPAddress = "192.0.2.20", .MACAddress = "02:00:00:00:00:20" },
        .cm_status = "OPERATIONAL", .provision_type = "DHCP",
        .certificate_path = "/nvram/cmcert.bin", .market = "US",
        .certificate_enabled = ENABLE, .energy_detected = TRUE,
        .lld_enabled = DISABLE,
        .diplexer = { .usDiplexerSetting = 85, .dsDiplexerSetting = 1002 }
    };
    model.log_count = 1;
    model.logs[0] = (CMMGMT_CM_EventLogEntry_t) {
        .docsDevEvIndex = 1, .docsDevEvFirstTime = { .tv_sec = 1700000000 },
        .docsDevEvLastTime = { .tv_sec = 1700000000 }, .docsDevEvCounts = 1,
        .docsDevEvLevel = 6, .docsDevEvId = 1,
        .docsDevEvText = "Reference modem initialized"
    };
}

static void ensure_model(void)
{
    if (!model.ready)
        cm_hal_test_reset();
}

static BOOLEAN should_fail(const char *name)
{
    ensure_model();
    if (strcmp(model.fail_api, name) != 0)
        return FALSE;
    model.fail_api[0] = '\0';
    return TRUE;
}

static void *snapshot(const void *source, size_t count, size_t item_size)
{
    void *result;
    if (count == 0)
        return NULL;
    if (model.fail_allocation) {
        model.fail_allocation = FALSE;
        return NULL;
    }
    /* Counts are bounded by CM_HAL_TEST_MAX_CHANNELS before reaching here. */
    result = malloc(count * item_size);
    if (result != NULL)
        memcpy(result, source, count * item_size);
    return result;
}

static INT read_string(char *out, size_t capacity, const char *value,
                       const char *api)
{
    BOOLEAN fail = should_fail(api);
    if (out == NULL)
        return RETURN_ERR;
    out[0] = '\0';
    if (fail)
        return RETURN_ERR;
    copy_string(out, capacity, value);
    return RETURN_OK;
}

static INT read_ulong(ULONG *out, ULONG value, const char *api)
{
    BOOLEAN fail = should_fail(api);
    if (out == NULL)
        return RETURN_ERR;
    *out = 0;
    if (fail)
        return RETURN_ERR;
    *out = value;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy bounded channel fixtures atomically; no caller pointers are retained. */
INT cm_hal_test_seed_channels(const cm_hal_test_channels_t *channels)
{
    size_t i;
    ensure_model();
    if (channels == NULL || channels->ds_count > CM_HAL_TEST_MAX_CHANNELS ||
        channels->us_count > CM_HAL_TEST_MAX_CHANNELS ||
        channels->ofdm_count > CM_HAL_TEST_MAX_CHANNELS ||
        channels->ofdma_count > CM_HAL_TEST_MAX_CHANNELS ||
        channels->status_count != channels->ofdma_count)
        return RETURN_ERR;
    for (i = 0; i < channels->ofdma_count; ++i)
        if (channels->ofdma[i].ChannelId != channels->status[i].ChannelId)
            return RETURN_ERR;
    model.channels = *channels;
    for (i = 0; i < model.channels.ds_count; ++i) {
        CMMGMT_CM_DS_CHANNEL *ds = &model.channels.ds[i];
        TERMINATE(ds, Frequency);
        TERMINATE(ds, PowerLevel);
        TERMINATE(ds, SNRLevel);
        TERMINATE(ds, Modulation);
        TERMINATE(ds, LockStatus);
    }
    for (i = 0; i < model.channels.us_count; ++i) {
        CMMGMT_CM_US_CHANNEL *us = &model.channels.us[i];
        TERMINATE(us, Frequency);
        TERMINATE(us, PowerLevel);
        TERMINATE(us, ChannelType);
        TERMINATE(us, SymbolRate);
        TERMINATE(us, Modulation);
        TERMINATE(us, LockStatus);
    }
    for (i = 0; i < model.channels.ofdm_count; ++i) {
        TERMINATE(&model.channels.ofdm[i], averageSNR);
        TERMINATE(&model.channels.ofdm[i], PowerLevel);
    }
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Replace copied event fixtures unless a clear is pending. */
INT cm_hal_test_seed_logs(const CMMGMT_CM_EventLogEntry_t *entries, size_t count)
{
    size_t i;
    ensure_model();
    if (count > CM_HAL_TEST_MAX_LOGS || (count != 0 && entries == NULL) ||
        model.activity.log_clear_pending)
        return RETURN_ERR;
    memset(model.logs, 0, sizeof(model.logs));
    if (count != 0)
        memcpy(model.logs, entries, count * sizeof(*entries));
    model.log_count = count;
    for (i = 0; i < count; ++i)
        TERMINATE(&model.logs[i], docsDevEvText);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy observation fixtures without advancing state or consuming faults. */
INT cm_hal_test_get_observations(cm_hal_test_observations_t *out)
{
    ensure_model();
    if (out == NULL)
        return RETURN_ERR;
    *out = model.observations;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Validate and copy observation fixtures, terminating fixed string fields. */
INT cm_hal_test_seed_observations(const cm_hal_test_observations_t *observations)
{
    ensure_model();
    if (observations == NULL || observations->certificate_enabled > ENABLE ||
        observations->energy_detected > TRUE ||
        observations->docsis.BPIState > TRUE ||
        observations->docsis.NetworkAccess > TRUE ||
        (observations->lld_enabled != ENABLE && observations->lld_enabled != DISABLE))
        return RETURN_ERR;
    model.observations = *observations;
    terminate_observations(&model.observations);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Return model-only activity without progressing it. */
INT cm_hal_test_get_activity(cm_hal_test_activity_t *out)
{
    ensure_model();
    if (out == NULL)
        return RETURN_ERR;
    *out = model.activity;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Arm a one-shot error for an explicitly supported fallible HAL entrypoint. */
INT cm_hal_test_fail_next(const char *api_name)
{
    static const char *const names[] = {
        "cm_hal_InitDB", "docsis_InitDS", "docsis_InitUS", "docsis_getCMStatus",
        "docsis_GetDSChannel", "docsis_GetUsStatus", "docsis_GetUSChannel",
        "docsis_GetDOCSISInfo", "docsis_GetNumOfActiveTxChannels",
        "docsis_GetNumOfActiveRxChannels", "docsis_GetErrorCodewords",
        "docsis_GetMddIpModeOverride", "docsis_SetMddIpModeOverride",
        "docsis_GetDocsisEventLogItems", "docsis_ClearDocsisEventLog",
        "cm_hal_GetDHCPInfo", "cm_hal_GetIPv6DHCPInfo", "cm_hal_GetCPEList",
        "cm_hal_GetMarket", "cm_hal_Set_HTTP_Download_Url",
        "cm_hal_Get_HTTP_Download_Url", "cm_hal_Set_HTTP_Download_Interface",
        "cm_hal_Get_HTTP_Download_Interface", "cm_hal_HTTP_Download",
        "cm_hal_Get_HTTP_Download_Status", "cm_hal_Reboot_Ready",
        "cm_hal_HTTP_Download_Reboot_Now", "cm_hal_FWupdateAndFactoryReset",
        "cm_hal_ReinitMac", "docsis_GetProvIpType", "docsis_GetCert",
        "docsis_GetCertStatus", "cm_hal_Get_CableModemResetCount",
        "cm_hal_Get_LocalResetCount", "cm_hal_Get_DocsisResetCount",
        "cm_hal_Get_ErouterResetCount", "cm_hal_HTTP_LED_Flash",
        "docsis_GetDsOfdmChanTable", "docsis_GetUsOfdmaChanTable",
        "docsis_GetStatusOfdmaUsTable", "docsis_LLDgetEnableStatus",
        "cm_hal_snmpv3_kickstart_initialize", "docsis_IsEnergyDetected",
        "cm_hal_set_ReinitMacThreshold", "cm_hal_get_ReinitMacThreshold",
        "cm_hal_get_DiplexerSettings", "cm_hal_Register_DiplexerVariationCallback"
    };
    size_t i;
    ensure_model();
    if (bounded_length(api_name, sizeof(model.fail_api)) == sizeof(model.fail_api))
        return RETURN_ERR;
    for (i = 0; i < sizeof(names) / sizeof(names[0]); ++i) {
        if (strcmp(api_name, names[i]) == 0) {
            copy_string(model.fail_api, sizeof(model.fail_api), api_name);
            return RETURN_OK;
        }
    }
    return RETURN_ERR;
}

/* PUBLIC_INTERFACE */
/** Make the next nonempty snapshot allocation fail exactly once. */
void cm_hal_test_fail_next_allocation(void)
{
    ensure_model();
    model.fail_allocation = TRUE;
}

static BOOLEAN download_busy(void)
{
    return model.activity.download_active || model.download_status == 100 ||
           model.activity.reboot_pending || model.activity.factory_reset_pending;
}

/* Parse only syntax: inet_pton does not resolve names or open connections. */
static BOOLEAN valid_http_authority(const char *host, size_t length)
{
    size_t i = 0, label_length = 0;
    unsigned int port = 0;
    if (length == 0)
        return FALSE;
    if (host[0] == '[') {
        char address[CM_HAL_TEST_HTTP_CAPACITY];
        struct in6_addr parsed;
        size_t end = 1;
        while (end < length && host[end] != ']')
            ++end;
        if (end == length || end == 1)
            return FALSE;
        memcpy(address, host + 1, end - 1);
        address[end - 1] = '\0';
        if (inet_pton(AF_INET6, address, &parsed) != 1)
            return FALSE;
        i = end + 1;
    } else {
        for (; i < length && host[i] != ':'; ++i) {
            unsigned char c = (unsigned char)host[i];
            if (c == '.') {
                if (label_length == 0 || host[i - 1] == '-')
                    return FALSE;
                label_length = 0;
            } else {
                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                      (c >= '0' && c <= '9') || (c == '-' && label_length != 0)))
                    return FALSE;
                if (++label_length > 63)
                    return FALSE;
            }
        }
        /* A final dot is permitted for an absolute DNS name. */
        if (i == 0 || host[i - 1] == '-')
            return FALSE;
    }
    if (i == length)
        return TRUE;
    if (host[i++] != ':' || i == length)
        return FALSE;
    for (; i < length; ++i) {
        if (host[i] < '0' || host[i] > '9')
            return FALSE;
        port = port * 10 + (unsigned int)(host[i] - '0');
        if (port > 65535)
            return FALSE;
    }
    return port != 0;
}

static BOOLEAN valid_download(const char *url, const char *filename)
{
    size_t i, host, host_end;
    size_t url_length = bounded_length(url, CM_HAL_TEST_HTTP_CAPACITY);
    size_t name_length = bounded_length(filename, CM_HAL_TEST_HTTP_CAPACITY);
    if (url_length == 0 || url_length == CM_HAL_TEST_HTTP_CAPACITY ||
        name_length == 0 || name_length == CM_HAL_TEST_HTTP_CAPACITY)
        return FALSE;
    if (strncmp(url, "https://", 8) == 0)
        host = 8;
    else if (strncmp(url, "http://", 7) == 0)
        host = 7;
    else
        return FALSE;
    host_end = host;
    while (host_end < url_length && url[host_end] != '/' &&
           url[host_end] != '?' && url[host_end] != '#')
        ++host_end;
    if (!valid_http_authority(url + host, host_end - host))
        return FALSE;
    /* Deliberately small accepted grammar; never passed to a shell/network. */
    for (i = host_end; i < url_length; ++i)
        if ((unsigned char)url[i] <= 32 || (unsigned char)url[i] >= 127 ||
            url[i] == '\\' || url[i] == '"' || url[i] == '\'')
            return FALSE;
    if (strcmp(filename, ".") == 0 || strcmp(filename, "..") == 0)
        return FALSE;
    for (i = 0; i < name_length; ++i) {
        unsigned char c = (unsigned char)filename[i];
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '_'))
            return FALSE;
    }
    return TRUE;
}

/* PUBLIC_INTERFACE */
/** Advance only an active simulated transfer, never wall-clock time. */
INT cm_hal_test_advance_download(INT status)
{
    ensure_model();
    if (!model.activity.download_active ||
        !((status >= model.download_status && status <= 100) ||
          (status >= 400 && status <= 407) || status == 500))
        return RETURN_ERR;
    model.download_status = status;
    if (status >= 100)
        model.activity.download_active = FALSE;
    if (status > 100)
        model.activity.factory_reset_pending = FALSE;
    return RETURN_OK;
}

static void increment_counter(ULONG *counter)
{
    if (*counter != ULONG_MAX)
        ++*counter;
}

/* PUBLIC_INTERFACE */
/** Finish eligible queued requests entirely in memory, with no host effects. */
void cm_hal_test_advance_async(void)
{
    ensure_model();
    if (model.activity.log_clear_pending) {
        memset(model.logs, 0, sizeof(model.logs));
        model.log_count = 0;
        model.activity.log_clear_pending = FALSE;
    }
    if (model.activity.reboot_pending ||
        (model.activity.factory_reset_pending && model.download_status == 100)) {
        increment_counter(&model.observations.cable_modem_resets);
        increment_counter(&model.observations.local_resets);
        if (model.activity.factory_reset_pending) {
            reset_preferences();
            memset(model.logs, 0, sizeof(model.logs));
            model.log_count = 0;
        }
        model.activity.reboot_pending = FALSE;
        model.activity.factory_reset_pending = FALSE;
        model.activity.download_active = FALSE;
        model.download_status = 0;
    }
}

/* PUBLIC_INTERFACE */
/** Publish a physical fixture change before dispatching its by-value callback. */
INT cm_hal_test_dispatch_diplexer(CM_DIPLEXER_SETTINGS settings)
{
    INT result = RETURN_OK;
    cm_hal_DiplexerVariationCallback callback;
    ensure_model();
    if (model.dispatching)
        return RETURN_ERR;
    if (settings.usDiplexerSetting == model.observations.diplexer.usDiplexerSetting &&
        settings.dsDiplexerSetting == model.observations.diplexer.dsDiplexerSetting)
        return RETURN_OK;
    model.observations.diplexer = settings;
    callback = model.callback;
    if (callback != NULL) {
        model.dispatching = TRUE;
        result = callback(settings);
        model.dispatching = FALSE;
    }
    return result;
}

/* PUBLIC_INTERFACE */
/** Record idempotent database startup; preserve pre-seeded observations. */
INT cm_hal_InitDB(void)
{
    if (should_fail(__func__))
        return RETURN_ERR;
    model.activity.db_initialized = TRUE;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Record idempotent DS startup without replacing channels. */
INT docsis_InitDS(void)
{
    if (should_fail(__func__))
        return RETURN_ERR;
    model.activity.ds_initialized = TRUE;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Record idempotent US startup without replacing channels. */
INT docsis_InitUS(void)
{
    if (should_fail(__func__))
        return RETURN_ERR;
    model.activity.us_initialized = TRUE;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy the observed DOCSIS status into a caller buffer of at least 40 bytes. */
INT docsis_getCMStatus(CHAR *cm_status)
{
    ensure_model();
    return read_string(cm_status, 40, model.observations.cm_status, __func__);
}

/* PUBLIC_INTERFACE */
/** Allocate a DS array snapshot; caller frees it, including across model reset. */
INT docsis_GetDSChannel(PCMMGMT_CM_DS_CHANNEL *ppinfo)
{
    BOOLEAN fail = should_fail(__func__);
    if (ppinfo == NULL)
        return RETURN_ERR;
    *ppinfo = NULL;
    if (fail)
        return RETURN_ERR;
    *ppinfo = snapshot(model.channels.ds, model.channels.ds_count, sizeof(**ppinfo));
    return model.channels.ds_count != 0 && *ppinfo == NULL ? RETURN_ERR : RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy a zero-based US row into caller-owned storage, or zero it on failure. */
INT docsis_GetUsStatus(USHORT i, PCMMGMT_CM_US_CHANNEL pinfo)
{
    BOOLEAN fail = should_fail(__func__);
    if (pinfo == NULL)
        return RETURN_ERR;
    memset(pinfo, 0, sizeof(*pinfo));
    if (fail || (size_t)i >= model.channels.us_count)
        return RETURN_ERR;
    *pinfo = model.channels.us[i];
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Allocate an independent US array snapshot; caller must free the result. */
INT docsis_GetUSChannel(PCMMGMT_CM_US_CHANNEL *ppinfo)
{
    BOOLEAN fail = should_fail(__func__);
    if (ppinfo == NULL)
        return RETURN_ERR;
    *ppinfo = NULL;
    if (fail)
        return RETURN_ERR;
    *ppinfo = snapshot(model.channels.us, model.channels.us_count, sizeof(**ppinfo));
    return model.channels.us_count != 0 && *ppinfo == NULL ? RETURN_ERR : RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Fill caller-owned registration details; initialize the struct on error. */
INT docsis_GetDOCSISInfo(PCMMGMT_CM_DOCSIS_INFO pinfo)
{
    BOOLEAN fail = should_fail(__func__);
    if (pinfo == NULL)
        return RETURN_ERR;
    memset(pinfo, 0, sizeof(*pinfo));
    if (fail)
        return RETURN_ERR;
    *pinfo = model.observations.docsis;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Return the legacy US array count without changing it. */
INT docsis_GetNumOfActiveTxChannels(ULONG *cnt)
{
    ensure_model();
    return read_ulong(cnt, (ULONG)model.channels.us_count, __func__);
}

/* PUBLIC_INTERFACE */
/** Return the legacy DS array count without changing it. */
INT docsis_GetNumOfActiveRxChannels(ULONG *cnt)
{
    ensure_model();
    return read_ulong(cnt, (ULONG)model.channels.ds_count, __func__);
}

/* PUBLIC_INTERFACE */
/** Fill the caller's existing codewords struct; never allocate or replace it. */
INT docsis_GetErrorCodewords(PCMMGMT_CM_ERROR_CODEWORDS *ppinfo)
{
    BOOLEAN fail = should_fail(__func__);
    if (ppinfo == NULL || *ppinfo == NULL)
        return RETURN_ERR;
    memset(*ppinfo, 0, sizeof(**ppinfo));
    if (fail)
        return RETURN_ERR;
    **ppinfo = model.observations.codewords;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy MDD override to a caller buffer of at least 64 bytes. */
INT docsis_GetMddIpModeOverride(CHAR *pValue)
{
    ensure_model();
    return read_string(pValue, 64, model.mdd_mode, __func__);
}

/* PUBLIC_INTERFACE */
/** Set a supported MDD override, with empty input clearing it to honorMdd. */
INT docsis_SetMddIpModeOverride(CHAR *pValue)
{
    BOOLEAN fail = should_fail(__func__);
    if (bounded_length(pValue, sizeof(model.mdd_mode)) == sizeof(model.mdd_mode) ||
        fail)
        return RETURN_ERR;
    if (pValue[0] != '\0' && strcmp(pValue, "ipv4Only") != 0 &&
        strcmp(pValue, "ipv6Only") != 0 && strcmp(pValue, "honorMdd") != 0)
        return RETURN_ERR;
    copy_string(model.mdd_mode, sizeof(model.mdd_mode),
                pValue[0] == '\0' ? "honorMdd" : pValue);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Return the stored upstream preference, not a mutable fixture row. */
UINT8 docsis_GetUSChannelId(void)
{
    ensure_model();
    return model.us_channel_id;
}

/* PUBLIC_INTERFACE */
/** Store a 0..255 channel preference; silently preserve it for invalid input. */
void docsis_SetUSChannelId(INT index)
{
    ensure_model();
    if (index >= 0 && index <= 255)
        model.us_channel_id = (UINT8)index;
}

/* PUBLIC_INTERFACE */
/** Return the stored downstream start-frequency preference in Hz. */
ULONG docsis_GetDownFreq(void)
{
    ensure_model();
    return model.start_frequency;
}

/* PUBLIC_INTERFACE */
/** Store a start-frequency preference without modifying observed channels. */
void docsis_SetStartFreq(ULONG value)
{
    ensure_model();
    model.start_frequency = value;
}

/* PUBLIC_INTERFACE */
/** Copy up to len events; return count, or ERR for invalid arguments/fault. */
INT docsis_GetDocsisEventLogItems(CMMGMT_CM_EventLogEntry_t *entryArray, INT len)
{
    size_t count;
    BOOLEAN fail = should_fail(__func__);
    if (entryArray == NULL || len < 0)
        return RETURN_ERR;
    /*
     * Only returned rows are meaningful. Initialize one available row on error
     * or empty results without trusting an unbounded len for a huge memset.
     */
    if (len > 0)
        memset(entryArray, 0, sizeof(*entryArray));
    if (fail)
        return RETURN_ERR;
    count = (size_t)len < model.log_count ? (size_t)len : model.log_count;
    if (count != 0)
        memcpy(entryArray, model.logs, count * sizeof(*entryArray));
    return (INT)count;
}

/* PUBLIC_INTERFACE */
/** Queue a nonblocking log clear; only the internal async control completes it. */
INT docsis_ClearDocsisEventLog(void)
{
    if (should_fail(__func__))
        return RETURN_ERR;
    model.activity.log_clear_pending = TRUE;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Fill caller-owned IPv4 DHCP observations without ticking lease times. */
INT cm_hal_GetDHCPInfo(PCMMGMT_CM_DHCP_INFO pInfo)
{
    BOOLEAN fail = should_fail(__func__);
    if (pInfo == NULL)
        return RETURN_ERR;
    memset(pInfo, 0, sizeof(*pInfo));
    if (fail)
        return RETURN_ERR;
    *pInfo = model.observations.dhcp;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Fill caller-owned IPv6 DHCP observations without ticking lease times. */
INT cm_hal_GetIPv6DHCPInfo(PCMMGMT_CM_IPV6DHCP_INFO pInfo)
{
    BOOLEAN fail = should_fail(__func__);
    if (pInfo == NULL)
        return RETURN_ERR;
    memset(pInfo, 0, sizeof(*pInfo));
    if (fail)
        return RETURN_ERR;
    *pInfo = model.observations.dhcpv6;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Fill one preallocated CPE record and count; see internal capacity convention. */
INT cm_hal_GetCPEList(PCMMGMT_DML_CPE_LIST *ppCPEList, ULONG *InstanceNum, CHAR *LanMode)
{
    BOOLEAN fail = should_fail(__func__);
    if (InstanceNum != NULL)
        *InstanceNum = 0;
    /* Validate other inputs before reading a potentially absent inner pointer. */
    if (InstanceNum == NULL || ppCPEList == NULL ||
        bounded_length(LanMode, 100) == 100)
        return RETURN_ERR;
    if (strcmp(LanMode, "router") != 0 && strcmp(LanMode, "bridge") != 0)
        return RETURN_ERR;
    if (*ppCPEList == NULL)
        return RETURN_ERR;
    memset(*ppCPEList, 0, sizeof(**ppCPEList));
    if (fail)
        return RETURN_ERR;
    **ppCPEList = model.observations.cpe;
    *InstanceNum = 1;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy market to a caller buffer of at least 100 bytes. */
INT cm_hal_GetMarket(CHAR *market)
{
    ensure_model();
    return read_string(market, 100, model.observations.market, __func__);
}

/* PUBLIC_INTERFACE */
/** Atomically set validated HTTP configuration unless an update is pending. */
INT cm_hal_Set_HTTP_Download_Url(char *pHttpUrl, char *pfilename)
{
    BOOLEAN fail = should_fail(__func__);
    if (fail || download_busy() || !valid_download(pHttpUrl, pfilename))
        return RETURN_ERR;
    copy_string(model.http_url, sizeof(model.http_url), pHttpUrl);
    copy_string(model.http_filename, sizeof(model.http_filename), pfilename);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy HTTP configuration to two >=200-byte buffers; empty config is ERR. */
INT cm_hal_Get_HTTP_Download_Url(char *pHttpUrl, char *pfilename)
{
    BOOLEAN fail = should_fail(__func__);
    if (pHttpUrl != NULL)
        pHttpUrl[0] = '\0';
    if (pfilename != NULL)
        pfilename[0] = '\0';
    if (fail || pHttpUrl == NULL || pfilename == NULL || model.http_url[0] == '\0')
        return RETURN_ERR;
    copy_string(pHttpUrl, CM_HAL_TEST_HTTP_CAPACITY, model.http_url);
    copy_string(pfilename, CM_HAL_TEST_HTTP_CAPACITY, model.http_filename);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Select wan0 (0) or erouter0 (1), preserving active-transfer configuration. */
INT cm_hal_Set_HTTP_Download_Interface(unsigned int interface)
{
    BOOLEAN fail = should_fail(__func__);
    if (fail || interface > 1 || download_busy())
        return RETURN_ERR;
    model.http_interface = interface;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy HTTP interface to caller storage, initialized to zero on failure. */
INT cm_hal_Get_HTTP_Download_Interface(unsigned int *pinterface)
{
    BOOLEAN fail = should_fail(__func__);
    if (pinterface == NULL)
        return RETURN_ERR;
    *pinterface = 0;
    if (fail)
        return RETURN_ERR;
    *pinterface = model.http_interface;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Start only a configured idle simulated download; never open a connection. */
INT cm_hal_HTTP_Download(void)
{
    if (should_fail(__func__) || download_busy() || model.http_url[0] == '\0')
        return RETURN_ERR;
    model.download_status = 0;
    model.activity.download_active = TRUE;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Observe progress without advancing it; injected retrieval failure is 500. */
INT cm_hal_Get_HTTP_Download_Status(void)
{
    if (should_fail(__func__))
        return 500;
    return model.download_status;
}

/* PUBLIC_INTERFACE */
/** Return 1 only for a completed update not already queued for reboot, else 2. */
INT cm_hal_Reboot_Ready(ULONG *pValue)
{
    ensure_model();
    return read_ulong(pValue,
                      model.download_status == 100 && !model.activity.reboot_pending
                          ? 1UL : 2UL,
                      __func__);
}

/* PUBLIC_INTERFACE */
/** Queue a simulated reboot of a completed update; no host reboot occurs. */
INT cm_hal_HTTP_Download_Reboot_Now(void)
{
    if (should_fail(__func__) || model.download_status != 100 ||
        model.activity.reboot_pending || model.activity.factory_reset_pending)
        return RETURN_ERR;
    model.activity.reboot_pending = TRUE;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Queue a validated simulated firmware update followed by factory reset. */
INT cm_hal_FWupdateAndFactoryReset(char *pUrl, char *pImagename)
{
    BOOLEAN fail = should_fail(__func__);
    if (fail || download_busy() || !valid_download(pUrl, pImagename))
        return RETURN_ERR;
    copy_string(model.http_url, sizeof(model.http_url), pUrl);
    copy_string(model.http_filename, sizeof(model.http_filename), pImagename);
    model.download_status = 0;
    model.activity.download_active = TRUE;
    model.activity.factory_reset_pending = TRUE;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Record a MAC reinitialization without changing channels or reset counters. */
INT cm_hal_ReinitMac(void)
{
    if (should_fail(__func__))
        return RETURN_ERR;
    increment_counter(&model.activity.reinit_mac_calls);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy DHCP/STATIC provision type; reserve CM_HAL_TEST_PROV_CAPACITY bytes. */
INT docsis_GetProvIpType(CHAR *pValue)
{
    ensure_model();
    return read_string(pValue, CM_HAL_TEST_PROV_CAPACITY,
                       model.observations.provision_type, __func__);
}

/* PUBLIC_INTERFACE */
/** Copy certificate path; reserve CM_HAL_TEST_CERT_CAPACITY bytes. */
INT docsis_GetCert(CHAR *pCert)
{
    ensure_model();
    return read_string(pCert, CM_HAL_TEST_CERT_CAPACITY,
                       model.observations.certificate_path, __func__);
}

/* PUBLIC_INTERFACE */
/** Copy observed certificate enablement without accessing host files. */
INT docsis_GetCertStatus(ULONG *pVal)
{
    ensure_model();
    return read_ulong(pVal, model.observations.certificate_enabled, __func__);
}

/* PUBLIC_INTERFACE */
/** Copy the independent cable modem reset counter. */
INT cm_hal_Get_CableModemResetCount(ULONG *resetcnt)
{
    ensure_model();
    return read_ulong(resetcnt, model.observations.cable_modem_resets, __func__);
}

/* PUBLIC_INTERFACE */
/** Copy the independent locally initiated reset counter. */
INT cm_hal_Get_LocalResetCount(ULONG *resetcnt)
{
    ensure_model();
    return read_ulong(resetcnt, model.observations.local_resets, __func__);
}

/* PUBLIC_INTERFACE */
/** Copy the independent DOCSIS reset counter. */
INT cm_hal_Get_DocsisResetCount(ULONG *resetcnt)
{
    ensure_model();
    return read_ulong(resetcnt, model.observations.docsis_resets, __func__);
}

/* PUBLIC_INTERFACE */
/** Copy the independent eRouter reset counter. */
INT cm_hal_Get_ErouterResetCount(ULONG *resetcnt)
{
    ensure_model();
    return read_ulong(resetcnt, model.observations.erouter_resets, __func__);
}

/* PUBLIC_INTERFACE */
/** Set simulated LED flashing only for a valid BOOLEAN. */
INT cm_hal_HTTP_LED_Flash(BOOLEAN LedFlash)
{
    if (should_fail(__func__) || LedFlash > TRUE)
        return RETURN_ERR;
    model.activity.led_flash = LedFlash;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Allocate an independent OFDM table; initialize pointer/count on all failures. */
INT docsis_GetDsOfdmChanTable(PDOCSIF31_CM_DS_OFDM_CHAN *ppinfo,
                             int *output_NumberOfEntries)
{
    BOOLEAN fail = should_fail(__func__);
    if (ppinfo != NULL)
        *ppinfo = NULL;
    if (output_NumberOfEntries != NULL)
        *output_NumberOfEntries = 0;
    if (fail || ppinfo == NULL || output_NumberOfEntries == NULL)
        return RETURN_ERR;
    *ppinfo = snapshot(model.channels.ofdm, model.channels.ofdm_count, sizeof(**ppinfo));
    if (model.channels.ofdm_count != 0 && *ppinfo == NULL)
        return RETURN_ERR;
    *output_NumberOfEntries = (int)model.channels.ofdm_count;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Allocate an independent OFDMA table; caller frees any nonempty result. */
INT docsis_GetUsOfdmaChanTable(PDOCSIF31_CM_US_OFDMA_CHAN *ppinfo,
                              int *output_NumberOfEntries)
{
    BOOLEAN fail = should_fail(__func__);
    if (ppinfo != NULL)
        *ppinfo = NULL;
    if (output_NumberOfEntries != NULL)
        *output_NumberOfEntries = 0;
    if (fail || ppinfo == NULL || output_NumberOfEntries == NULL)
        return RETURN_ERR;
    *ppinfo = snapshot(model.channels.ofdma, model.channels.ofdma_count, sizeof(**ppinfo));
    if (model.channels.ofdma_count != 0 && *ppinfo == NULL)
        return RETURN_ERR;
    *output_NumberOfEntries = (int)model.channels.ofdma_count;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Allocate independent OFDMA status rows matching seeded OFDMA row IDs. */
INT docsis_GetStatusOfdmaUsTable(PDOCSIF31_CMSTATUSOFDMA_US *ppinfo,
                                int *output_NumberOfEntries)
{
    BOOLEAN fail = should_fail(__func__);
    if (ppinfo != NULL)
        *ppinfo = NULL;
    if (output_NumberOfEntries != NULL)
        *output_NumberOfEntries = 0;
    if (fail || ppinfo == NULL || output_NumberOfEntries == NULL)
        return RETURN_ERR;
    *ppinfo = snapshot(model.channels.status, model.channels.status_count, sizeof(**ppinfo));
    if (model.channels.status_count != 0 && *ppinfo == NULL)
        return RETURN_ERR;
    *output_NumberOfEntries = (int)model.channels.status_count;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Return seeded ENABLE/DISABLE or ERR, without conflating ENABLE with errors. */
INT docsis_LLDgetEnableStatus(void)
{
    if (should_fail(__func__))
        return RETURN_ERR;
    return model.observations.lld_enabled;
}

/* PUBLIC_INTERFACE */
/** Validate nested kickstart rows synchronously; retain/log no secret buffers. */
INT cm_hal_snmpv3_kickstart_initialize(snmpv3_kickstart_table_t *pKickstart_Table)
{
    size_t i;
    BOOLEAN fail = should_fail(__func__);
    if (fail || pKickstart_Table == NULL || pKickstart_Table->n_rows > MAX_KICKSTART_ROWS)
        return RETURN_ERR;
    for (i = 0; i < pKickstart_Table->n_rows; ++i) {
        const snmp_kickstart_row_t *row = pKickstart_Table->kickstart_values[i];
        if (row == NULL ||
            (row->security_name.length != 0 && row->security_name.buffer == NULL) ||
            (row->security_number.length != 0 && row->security_number.buffer == NULL))
            return RETURN_ERR;
    }
    /* Raw byte buffers need not be strings. Do not inspect beyond their length.
     * Like any C pointer+length API, actual backing capacity is the caller's duty.
     */
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy the seeded energy-detection observation, zeroing it on error. */
INT docsis_IsEnergyDetected(BOOLEAN *pEnergyDetected)
{
    BOOLEAN fail = should_fail(__func__);
    if (pEnergyDetected == NULL)
        return RETURN_ERR;
    *pEnergyDetected = FALSE;
    if (fail)
        return RETURN_ERR;
    *pEnergyDetected = model.observations.energy_detected;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Store an unsigned MAC reinitialization threshold without changing fixtures. */
INT cm_hal_set_ReinitMacThreshold(ULONG value)
{
    if (should_fail(__func__))
        return RETURN_ERR;
    model.reinit_threshold = value;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Copy the MAC reinitialization threshold to initialized caller storage. */
INT cm_hal_get_ReinitMacThreshold(ULONG *pValue)
{
    ensure_model();
    return read_ulong(pValue, model.reinit_threshold, __func__);
}

/* PUBLIC_INTERFACE */
/** Copy current diplexer settings into initialized caller storage. */
INT cm_hal_get_DiplexerSettings(CM_DIPLEXER_SETTINGS *pValue)
{
    BOOLEAN fail = should_fail(__func__);
    if (pValue == NULL)
        return RETURN_ERR;
    memset(pValue, 0, sizeof(*pValue));
    if (fail)
        return RETURN_ERR;
    *pValue = model.observations.diplexer;
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Register a non-removable callback; same-pointer registration is idempotent. */
INT cm_hal_Register_DiplexerVariationCallback(cm_hal_DiplexerVariationCallback callback_proc)
{
    BOOLEAN fail = should_fail(__func__);
    if (fail || callback_proc == NULL ||
        (model.callback != NULL && model.callback != callback_proc))
        return RETURN_ERR;
    model.callback = callback_proc;
    return RETURN_OK;
}
