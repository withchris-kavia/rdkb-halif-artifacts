/*
 * Copyright 2023 RDK Management
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef CM_HAL_TEST_CONTROL_H
#define CM_HAL_TEST_CONTROL_H

#ifndef BUILD_LINUX
#error "CM model controls are only available to BUILD_LINUX reference tests"
#endif

#include <stddef.h>
#include "cm_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Internal reference-model conventions, NOT additions to the vendor HAL ABI:
 * - Single-threaded; callers must serialize access, including callbacks.
 * - Getters work before initialization, never advance time, and return copies.
 * - DS/US and OFDM/OFDMA getters allocate independent snapshots. free() each
 *   successful non-NULL result. Start with an empty output pointer; the model
 *   never frees a caller's old allocation. Empty tables return OK, NULL, zero.
 * - Codewords and CPE getters instead fill caller-owned storage, as specified
 *   in cm_hal.h. CPE has no capacity argument, so this model returns ONE entry
 *   in either router or bridge mode. Both the outer and inner pointers are
 *   required. It does not allocate or replace that inner pointer.
 * - All lengthless string getters require the public header's stated capacity.
 *   Where it states none, reserve CM_HAL_TEST_PROV_CAPACITY for provision type
 *   and CM_HAL_TEST_CERT_CAPACITY for certificate path. Sizes include the NUL.
 * - HTTP configuration accepts nonempty http(s) URLs with a DNS/IPv4 host or
 *   bracketed IPv6 address, optional port 1..65535, and safe single-component
 *   filenames, each shorter than CM_HAL_TEST_HTTP_CAPACITY. Hosts are never
 *   resolved. No filename extension is required by the HAL contract.
 * - Seed functions copy inputs, retain no pointers, and truncate unterminated
 *   fixed string fields by placing a NUL in their final byte.
 * - Repeated initialization is idempotent and preserves seeded fixtures.
 * - A completed download (100) blocks a new configuration or download until
 *   simulated reboot. Errors allow retry. No HAL call performs host I/O.
 */
#define CM_HAL_TEST_MAX_CHANNELS 32
#define CM_HAL_TEST_MAX_LOGS 64
#define CM_HAL_TEST_HTTP_CAPACITY 200
#define CM_HAL_TEST_PROV_CAPACITY 8
#define CM_HAL_TEST_CERT_CAPACITY 128

/** Fixed-capacity channel fixtures; counts apply to their corresponding arrays.
 * OFDMA status rows must match OFDMA channel count and ChannelId in row order.
 * Legacy DS/US counts describe those arrays, not the separate 3.1 tables.
 */
typedef struct {
    size_t ds_count;
    size_t us_count;
    size_t ofdm_count;
    size_t ofdma_count;
    size_t status_count;
    CMMGMT_CM_DS_CHANNEL ds[CM_HAL_TEST_MAX_CHANNELS];
    CMMGMT_CM_US_CHANNEL us[CM_HAL_TEST_MAX_CHANNELS];
    DOCSIF31_CM_DS_OFDM_CHAN ofdm[CM_HAL_TEST_MAX_CHANNELS];
    DOCSIF31_CM_US_OFDMA_CHAN ofdma[CM_HAL_TEST_MAX_CHANNELS];
    DOCSIF31_CMSTATUSOFDMA_US status[CM_HAL_TEST_MAX_CHANNELS];
} cm_hal_test_channels_t;

/** Independently seedable, read-only HAL observations; reads never change them. */
typedef struct {
    CMMGMT_CM_DOCSIS_INFO docsis;
    CMMGMT_CM_ERROR_CODEWORDS codewords;
    CMMGMT_CM_DHCP_INFO dhcp;
    CMMGMT_CM_IPV6DHCP_INFO dhcpv6;
    CMMGMT_DML_CPE_LIST cpe;
    char cm_status[40];
    char provision_type[CM_HAL_TEST_PROV_CAPACITY];
    char certificate_path[CM_HAL_TEST_CERT_CAPACITY];
    char market[100];
    ULONG certificate_enabled;
    ULONG cable_modem_resets;
    ULONG local_resets;
    ULONG docsis_resets;
    ULONG erouter_resets;
    BOOLEAN energy_detected;
    INT lld_enabled;
    CM_DIPLEXER_SETTINGS diplexer;
} cm_hal_test_observations_t;

/** Model-only activity, separate from physical observations and preferences. */
typedef struct {
    BOOLEAN db_initialized;
    BOOLEAN ds_initialized;
    BOOLEAN us_initialized;
    BOOLEAN download_active;
    BOOLEAN log_clear_pending;
    BOOLEAN reboot_pending;
    BOOLEAN factory_reset_pending;
    BOOLEAN led_flash;
    ULONG reinit_mac_calls;
} cm_hal_test_activity_t;

/* PUBLIC_INTERFACE */
/** Restore deterministic defaults, clearing pending work, callbacks and faults.
 * Outstanding output snapshots remain caller-owned and valid.
 */
void cm_hal_test_reset(void);

/* PUBLIC_INTERFACE */
/** Atomically copy channel fixtures; return ERR for NULL, excessive counts or
 * mismatched OFDMA/status rows. No allocation is retained by the model.
 */
INT cm_hal_test_seed_channels(const cm_hal_test_channels_t *channels);

/* PUBLIC_INTERFACE */
/** Replace logs with count copied entries (NULL is allowed only at count zero).
 * Return ERR for excessive count or a pending clear; invalid seeds change nothing.
 */
INT cm_hal_test_seed_logs(const CMMGMT_CM_EventLogEntry_t *entries, size_t count);

/* PUBLIC_INTERFACE */
/** Copy current observations to out; return ERR for NULL. No faults are consumed. */
INT cm_hal_test_get_observations(cm_hal_test_observations_t *out);

/* PUBLIC_INTERFACE */
/** Atomically copy observations; return ERR for NULL or invalid boolean/LLD
 * values. This fixture operation does not dispatch the diplexer callback.
 */
INT cm_hal_test_seed_observations(const cm_hal_test_observations_t *observations);

/* PUBLIC_INTERFACE */
/** Copy activity to out; return ERR for NULL. Does not advance pending work. */
INT cm_hal_test_get_activity(cm_hal_test_activity_t *out);

/* PUBLIC_INTERFACE */
/** Arm one failure for a named fallible HAL API, replacing a previous fault.
 * Unknown names and value/void APIs without error returns are rejected.
 * The next invocation of that API consumes the fault, even with invalid input.
 * Ordinary APIs return ERR; download-status returns its documented failure 500.
 * Valid output arguments are initialized before returning a failure.
 */
INT cm_hal_test_fail_next(const char *api_name);

/* PUBLIC_INTERFACE */
/** Fail the next nonempty output-snapshot allocation once. Other calls and empty
 * tables do not consume it. No real allocation or pointer is leaked on failure.
 */
void cm_hal_test_fail_next_allocation(void);

/* PUBLIC_INTERFACE */
/** Advance an active download to a monotonic percentage 0..100, 400..407 or 500.
 * Invalid transitions return ERR without mutation. At 100, explicit reboot is
 * needed except for a queued firmware/factory-reset request.
 */
INT cm_hal_test_advance_download(INT status);

/* PUBLIC_INTERFACE */
/** Complete queued log clear and eligible simulated reboot/factory reset.
 * Factory reset waits for download 100; ordinary reboot must first be requested.
 * Reboot increments ONLY CM/local reset counters (saturating at ULONG_MAX).
 * Factory reset additionally restores MDD/preference/threshold/HTTP/LED defaults
 * and empties logs. Physical fixtures, callbacks and init flags are preserved.
 * This policy is a test convention, not a vendor persistence requirement.
 */
void cm_hal_test_advance_async(void);

/* PUBLIC_INTERFACE */
/** Publish a diplexer change, then synchronously call the registered callback
 * with a by-value payload. Getter reads already see the new value in callback.
 * Return its status (or OK when unregistered/unchanged); reject nested dispatch.
 * A callback error does not roll back the observed hardware change.
 */
INT cm_hal_test_dispatch_diplexer(CM_DIPLEXER_SETTINGS settings);

#ifdef __cplusplus
}
#endif

#endif
