/*
 * Copyright 2024 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file test_l2_cm_hal.c
 * @brief Stateful CM reference-model sequences, CM-UT-COMPLETION-01 STEP-04.
 *
 * Contract references below name declarations in include/cm_hal.h and the
 * corresponding families in docs/pages/CMhalSpec.md. Deterministic fixtures,
 * validation rollback, zero-based US indexing, reset scope, synchronous callback
 * dispatch and explicit async ticks are Linux conventions documented separately
 * in cm_hal_test_control.h, NOT additional vendor/hardware requirements.
 *
 * No test invokes a real network download, reboot, factory reset or DUT.
 * There is no public deinit/unregister: reset surrounds EVERY scenario, including
 * an early prerequisite return. Only nonfatal assertions are used, so snapshot
 * cleanup and the outer reset always run. Snapshots remain caller-owned.
 */
#include <ut.h>

#ifdef BUILD_LINUX
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ut_kvp_profile.h>

#include "cm_hal.h"
#include "cm_hal_test_control.h"

#define ARRAY_COUNT(array) (sizeof(array) / sizeof((array)[0]))

/* For void scenarios/helpers with no outstanding allocations. */
#define REQUIRE_OK(call) do { \
    int result_ = (call); \
    UT_ASSERT_EQUAL(result_, RETURN_OK); \
    if (result_ != RETURN_OK) { return; } \
} while (0)

/* Compare named fields, never struct padding, endian-dependent unions or ABI sizes. */
#define NUMBER(member) UT_ASSERT_TRUE(actual->member == expected->member)
#define TEXT(member) check_text(actual->member, expected->member, sizeof(actual->member))

typedef struct {
    PCMMGMT_CM_DS_CHANNEL ds;
    PCMMGMT_CM_US_CHANNEL us;
    PDOCSIF31_CM_DS_OFDM_CHAN ofdm;
    PDOCSIF31_CM_US_OFDMA_CHAN ofdma;
    PDOCSIF31_CMSTATUSOFDMA_US status;
    ULONG ds_count;
    ULONG us_count;
    int ofdm_count;
    int ofdma_count;
    int status_count;
} channel_snapshot_t;

static unsigned int callback_calls;
static CM_DIPLEXER_SETTINGS callback_payload;
static CM_DIPLEXER_SETTINGS callback_getter;
static int callback_getter_status;

/** Compare terminated text without an unbounded read on a defective output. */
static void check_text(const char *actual, const char *expected, size_t capacity)
{
    UT_ASSERT_TRUE(memchr(actual, '\0', capacity) != NULL);
    UT_ASSERT_EQUAL(strncmp(actual, expected, capacity), 0);
}

/** Retrieve size-aware, terminated profile fixtures; never log their contents. */
static int load_http(char url[CM_HAL_TEST_HTTP_CAPACITY],
                     char filename[CM_HAL_TEST_HTTP_CAPACITY])
{
    ut_kvp_status_t url_status = ut_kvp_getStringField(
        ut_kvp_profile_getInstance(), "cm.config.HttpUrl",
        url, CM_HAL_TEST_HTTP_CAPACITY);
    ut_kvp_status_t file_status = ut_kvp_getStringField(
        ut_kvp_profile_getInstance(), "cm.config.filename",
        filename, CM_HAL_TEST_HTTP_CAPACITY);
    url[CM_HAL_TEST_HTTP_CAPACITY - 1] = '\0';
    filename[CM_HAL_TEST_HTTP_CAPACITY - 1] = '\0';
    UT_ASSERT_EQUAL(url_status, UT_KVP_STATUS_SUCCESS);
    UT_ASSERT_EQUAL(file_status, UT_KVP_STATUS_SUCCESS);
    UT_ASSERT_TRUE(url[0] != '\0');
    UT_ASSERT_TRUE(filename[0] != '\0');
    return url_status == UT_KVP_STATUS_SUCCESS &&
           file_status == UT_KVP_STATUS_SUCCESS &&
           url[0] != '\0' && filename[0] != '\0' ? RETURN_OK : RETURN_ERR;
}

/** Check both HTTP fields and the independently configured interface. */
static void check_http(const char *expected_url, const char *expected_filename,
                       unsigned int expected_interface)
{
    char url[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    char filename[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    unsigned int interface = UINT_MAX;
    REQUIRE_OK(cm_hal_Get_HTTP_Download_Url(url, filename));
    check_text(url, expected_url, sizeof(url));
    check_text(filename, expected_filename, sizeof(filename));
    REQUIRE_OK(cm_hal_Get_HTTP_Download_Interface(&interface));
    UT_ASSERT_EQUAL(interface, expected_interface);
}

/** Free partial/full pairs exactly once, even if an allocation-alias check fails. */
static void release_channels(channel_snapshot_t *first, channel_snapshot_t *second)
{
    void *allocations[] = {
        first->ds, first->us, first->ofdm, first->ofdma, first->status,
        second != NULL ? second->ds : NULL,
        second != NULL ? second->us : NULL,
        second != NULL ? second->ofdm : NULL,
        second != NULL ? second->ofdma : NULL,
        second != NULL ? second->status : NULL
    };
    for (size_t i = 0; i < ARRAY_COUNT(allocations); ++i)
    {
        /* Discard duplicates before freeing; do not inspect freed pointers. */
        for (size_t j = i + 1; j < ARRAY_COUNT(allocations); ++j)
        {
            if (allocations[j] == allocations[i])
            {
                allocations[j] = NULL;
            }
        }
        free(allocations[i]);
    }
    memset(first, 0, sizeof(*first));
    if (second != NULL)
    {
        memset(second, 0, sizeof(*second));
    }
}

/** Read one coherent seeded snapshot; the caller frees partial results on error. */
static int read_channels(channel_snapshot_t *snapshot)
{
#define READ(call) do { \
    int result_ = (call); \
    UT_ASSERT_EQUAL(result_, RETURN_OK); \
    if (result_ != RETURN_OK) { return RETURN_ERR; } \
} while (0)
    READ(docsis_GetNumOfActiveRxChannels(&snapshot->ds_count));
    READ(docsis_GetNumOfActiveTxChannels(&snapshot->us_count));
    READ(docsis_GetDSChannel(&snapshot->ds));
    READ(docsis_GetUSChannel(&snapshot->us));
    READ(docsis_GetDsOfdmChanTable(&snapshot->ofdm, &snapshot->ofdm_count));
    READ(docsis_GetUsOfdmaChanTable(&snapshot->ofdma, &snapshot->ofdma_count));
    READ(docsis_GetStatusOfdmaUsTable(&snapshot->status, &snapshot->status_count));
#undef READ
    int valid = snapshot->ds_count <= CM_HAL_TEST_MAX_CHANNELS &&
                snapshot->us_count <= CM_HAL_TEST_MAX_CHANNELS &&
                snapshot->ofdm_count >= 0 &&
                snapshot->ofdm_count <= CM_HAL_TEST_MAX_CHANNELS &&
                snapshot->ofdma_count >= 0 &&
                snapshot->ofdma_count <= CM_HAL_TEST_MAX_CHANNELS &&
                snapshot->status_count >= 0 &&
                snapshot->status_count <= CM_HAL_TEST_MAX_CHANNELS &&
                ((snapshot->ds_count == 0) == (snapshot->ds == NULL)) &&
                ((snapshot->us_count == 0) == (snapshot->us == NULL)) &&
                ((snapshot->ofdm_count == 0) == (snapshot->ofdm == NULL)) &&
                ((snapshot->ofdma_count == 0) == (snapshot->ofdma == NULL)) &&
                ((snapshot->status_count == 0) == (snapshot->status == NULL));
    UT_ASSERT_TRUE(valid);
    return valid ? RETURN_OK : RETURN_ERR;
}

/** Construct distinct counts/IDs and fully initialized representative PHY rows. */
static void make_channels(cm_hal_test_channels_t *fixture)
{
    memset(fixture, 0, sizeof(*fixture));
    fixture->ds_count = 3;
    fixture->us_count = 2;
    fixture->ofdm_count = 2;
    fixture->ofdma_count = 1;
    fixture->status_count = 1;
    for (size_t i = 0; i < fixture->ds_count; ++i)
    {
        CMMGMT_CM_DS_CHANNEL row = {
            .ChannelID = 11 + i * 6,
            .Frequency = "606000000", .PowerLevel = "-2.5", .SNRLevel = "37",
            .Modulation = "256-QAM", .LockStatus = "Locked",
            .Octets = 1001 + i, .Correcteds = 13 + i, .Uncorrectables = 3 + i
        };
        fixture->ds[i] = row;
    }
    for (size_t i = 0; i < fixture->us_count; ++i)
    {
        CMMGMT_CM_US_CHANNEL row = {
            .ChannelID = 31 + i * 6,
            .Frequency = "36000000", .PowerLevel = "46",
            .ChannelType = "ATDMA", .SymbolRate = "5120000",
            .Modulation = "64-QAM", .LockStatus = "Locked"
        };
        fixture->us[i] = row;
    }
    for (size_t i = 0; i < fixture->ofdm_count; ++i)
    {
        DOCSIF31_CM_DS_OFDM_CHAN row = {
            .ChannelId = 51 + (unsigned int)i * 6, .ChanIndicator = 2,
            .SubcarrierZeroFreq = 500000000, .FirstActiveSubcarrierNum = 148,
            .LastActiveSubcarrierNum = 2047, .NumActiveSubcarriers = 1800,
            .SubcarrierSpacing = 50000, .CyclicPrefix = 192,
            .RollOffPeriod = 128, .PlcFreq = 522000000, .NumPilots = 16,
            .TimeInterleaverDepth = 32, .averageSNR = "39", .PowerLevel = "-15",
            .PlcTotalCodewords = 9001 + i, .PlcUnreliableCodewords = 2 + i,
            .NcpTotalFields = 8001 + i, .NcpFieldCrcFailures = 3 + i
        };
        fixture->ofdm[i] = row;
    }
    DOCSIF31_CM_US_OFDMA_CHAN ofdma = {
        .ChannelId = 71, .ConfigChangeCt = 9, .SubcarrierZeroFreq = 5000000,
        .FirstActiveSubcarrierNum = 74, .LastActiveSubcarrierNum = 1573,
        .NumActiveSubcarriers = 1500, .SubcarrierSpacing = 50000,
        .CyclicPrefix = 192, .RollOffPeriod = 128, .NumSymbolsPerFrame = 8,
        .TxPower = 184, .PreEqEnabled = TRUE
    };
    DOCSIF31_CMSTATUSOFDMA_US status = {
        .ChannelId = 71, .T3Timeouts = 3, .T4Timeouts = 4,
        .RangingAborteds = 5, .T3Exceededs = 6, .IsMuted = FALSE,
        .RangingStatus = 4
    };
    fixture->ofdma[0] = ofdma;
    fixture->status[0] = status;
}

/** Borrow fixture rows for comparisons only; never release this view. */
static channel_snapshot_t channel_view(cm_hal_test_channels_t *fixture)
{
    channel_snapshot_t view = {
        .ds = fixture->ds, .us = fixture->us, .ofdm = fixture->ofdm,
        .ofdma = fixture->ofdma, .status = fixture->status,
        .ds_count = fixture->ds_count, .us_count = fixture->us_count,
        .ofdm_count = (int)fixture->ofdm_count,
        .ofdma_count = (int)fixture->ofdma_count,
        .status_count = (int)fixture->status_count
    };
    return view;
}

/** Compare every named downstream field, without imposing string units. */
static void check_ds(const CMMGMT_CM_DS_CHANNEL *actual,
                     const CMMGMT_CM_DS_CHANNEL *expected)
{
    NUMBER(ChannelID); NUMBER(Octets); NUMBER(Correcteds); NUMBER(Uncorrectables);
    TEXT(Frequency); TEXT(PowerLevel); TEXT(SNRLevel); TEXT(Modulation); TEXT(LockStatus);
}

/** Compare both full-snapshot and indexed upstream outputs. */
static void check_us(const CMMGMT_CM_US_CHANNEL *actual,
                     const CMMGMT_CM_US_CHANNEL *expected)
{
    NUMBER(ChannelID);
    TEXT(Frequency); TEXT(PowerLevel); TEXT(ChannelType); TEXT(SymbolRate);
    TEXT(Modulation); TEXT(LockStatus);
}

/** Compare all OFDM fields as supplied, not an inferred physical-unit encoding. */
static void check_ofdm(const DOCSIF31_CM_DS_OFDM_CHAN *actual,
                       const DOCSIF31_CM_DS_OFDM_CHAN *expected)
{
    NUMBER(ChannelId); NUMBER(ChanIndicator); NUMBER(SubcarrierZeroFreq);
    NUMBER(FirstActiveSubcarrierNum); NUMBER(LastActiveSubcarrierNum);
    NUMBER(NumActiveSubcarriers); NUMBER(SubcarrierSpacing); NUMBER(CyclicPrefix);
    NUMBER(RollOffPeriod); NUMBER(PlcFreq); NUMBER(NumPilots); NUMBER(TimeInterleaverDepth);
    TEXT(averageSNR); TEXT(PowerLevel);
    NUMBER(PlcTotalCodewords); NUMBER(PlcUnreliableCodewords);
    NUMBER(NcpTotalFields); NUMBER(NcpFieldCrcFailures);
}

/** Compare all OFDMA configuration fields. */
static void check_ofdma(const DOCSIF31_CM_US_OFDMA_CHAN *actual,
                        const DOCSIF31_CM_US_OFDMA_CHAN *expected)
{
    NUMBER(ChannelId); NUMBER(ConfigChangeCt); NUMBER(SubcarrierZeroFreq);
    NUMBER(FirstActiveSubcarrierNum); NUMBER(LastActiveSubcarrierNum);
    NUMBER(NumActiveSubcarriers); NUMBER(SubcarrierSpacing); NUMBER(CyclicPrefix);
    NUMBER(RollOffPeriod); NUMBER(NumSymbolsPerFrame); NUMBER(TxPower); NUMBER(PreEqEnabled);
}

/** Compare all OFDMA status fields. */
static void check_ofdma_status(const DOCSIF31_CMSTATUSOFDMA_US *actual,
                               const DOCSIF31_CMSTATUSOFDMA_US *expected)
{
    NUMBER(ChannelId); NUMBER(T3Timeouts); NUMBER(T4Timeouts);
    NUMBER(RangingAborteds); NUMBER(T3Exceededs); NUMBER(IsMuted); NUMBER(RangingStatus);
}

/** Check counts before indexing; the immutable Linux fixture supplies capacities. */
static void check_channels(const channel_snapshot_t *actual,
                           const channel_snapshot_t *expected)
{
    NUMBER(ds_count); NUMBER(us_count); NUMBER(ofdm_count);
    NUMBER(ofdma_count); NUMBER(status_count);
    if (actual->ds_count == expected->ds_count && actual->ds != NULL)
    {
        for (ULONG i = 0; i < expected->ds_count; ++i)
        {
            check_ds(&actual->ds[i], &expected->ds[i]);
        }
    }
    if (actual->us_count == expected->us_count && actual->us != NULL)
    {
        for (ULONG i = 0; i < expected->us_count; ++i)
        {
            CMMGMT_CM_US_CHANNEL indexed = {0};
            check_us(&actual->us[i], &expected->us[i]);
            int result = docsis_GetUsStatus((USHORT)i, &indexed);
            UT_ASSERT_EQUAL(result, RETURN_OK);
            if (result == RETURN_OK)
            {
                check_us(&indexed, &expected->us[i]);
            }
        }
    }
    if (actual->ofdm_count == expected->ofdm_count && actual->ofdm != NULL)
    {
        for (int i = 0; i < expected->ofdm_count; ++i)
        {
            check_ofdm(&actual->ofdm[i], &expected->ofdm[i]);
        }
    }
    if (actual->ofdma_count == expected->ofdma_count && actual->ofdma != NULL)
    {
        for (int i = 0; i < expected->ofdma_count; ++i)
        {
            check_ofdma(&actual->ofdma[i], &expected->ofdma[i]);
        }
    }
    if (actual->status_count == expected->status_count && actual->status != NULL)
    {
        for (int i = 0; i < expected->status_count; ++i)
        {
            check_ofdma_status(&actual->status[i], &expected->status[i]);
            if (actual->ofdma_count == actual->status_count && actual->ofdma != NULL)
            {
                UT_ASSERT_EQUAL(actual->status[i].ChannelId, actual->ofdma[i].ChannelId);
            }
        }
    }
}

/** L2-01
 * Purpose: configure/read/clear MDD and reject changes without losing the last mode.
 * Contract Requirement: docsis_{Set,Get}MddIpModeOverride; CMhalSpec MDD override.
 * Preconditions: independent Linux model. Inputs: legal modes, empty, invalid/NULL.
 * Expected Result: exact readback; clear -> honorMdd; rejected writes preserve it
 * (the clear representation and rollback are explicit reference conventions).
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: outer case reset; no public vendor persistence assumption.
 */
static void mdd_readback(void)
{
    char modes[][64] = {"ipv4Only", "ipv6Only", "honorMdd", ""};
    const char *expected[] = {"ipv4Only", "ipv6Only", "honorMdd", "honorMdd"};
    char mode[64] = {0};
    char too_long[64];
    for (size_t i = 0; i < ARRAY_COUNT(modes); ++i)
    {
        REQUIRE_OK(docsis_SetMddIpModeOverride(modes[i]));
        REQUIRE_OK(docsis_GetMddIpModeOverride(mode));
        check_text(mode, expected[i], sizeof(mode));
    }
    REQUIRE_OK(docsis_SetMddIpModeOverride("ipv6Only"));
    char *invalid[] = {"APM", "DualStack", "unknown", NULL, too_long};
    memset(too_long, 'x', sizeof(too_long));
    for (size_t i = 0; i < ARRAY_COUNT(invalid); ++i)
    {
        UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride(invalid[i]), RETURN_ERR);
        REQUIRE_OK(docsis_GetMddIpModeOverride(mode));
        check_text(mode, "ipv6Only", sizeof(mode));
    }
}

/** L2-02
 * Purpose: round-trip HTTP fields and both interfaces without cross-corruption.
 * Contract Requirement: cm_hal_{Set,Get}_HTTP_Download_{Url,Interface}.
 * Preconditions: idle Linux model and valid profile. Inputs: profile URL/file, 0/1.
 * Expected Result: field replacements/interface changes preserve unrelated fields;
 * rejected input preserves prior configuration (reference rollback convention).
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: outer reset; no HTTP request is initiated.
 */
static void http_readback(void)
{
    char url[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    char filename[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    char replacement[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    char replacement_url[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    REQUIRE_OK(load_http(url, filename));
    int length = snprintf(replacement, sizeof(replacement), "l2-%s", filename);
    UT_ASSERT_TRUE(length > 0 && (size_t)length < sizeof(replacement));
    if (length <= 0 || (size_t)length >= sizeof(replacement))
    {
        return;
    }
    length = snprintf(replacement_url, sizeof(replacement_url), "%s/l2", url);
    UT_ASSERT_TRUE(length > 0 && (size_t)length < sizeof(replacement_url));
    if (length <= 0 || (size_t)length >= sizeof(replacement_url))
    {
        return;
    }
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Url(url, filename));
    for (unsigned int interface = 0; interface <= 1; ++interface)
    {
        REQUIRE_OK(cm_hal_Set_HTTP_Download_Interface(interface));
        check_http(url, filename, interface);
    }
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Url(url, replacement));
    check_http(url, replacement, 1);
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Url(replacement_url, replacement));
    check_http(replacement_url, replacement, 1);
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Interface(0));
    check_http(replacement_url, replacement, 0);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Interface(2), RETURN_ERR);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Url("", filename), RETURN_ERR);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Url(url, "../image.bin"), RETURN_ERR);
    check_http(replacement_url, replacement, 0);
}

/** L2-03
 * Purpose: observe independent US ID/start-frequency preferences across changes.
 * Contract Requirement: docsis_{Set,Get}USChannelId, SetStartFreq/GetDownFreq (Hz).
 * Preconditions: independent Linux model. Inputs: IDs 0/42/255; Hz preferences.
 * Expected Result: readback; invalid ID preservation is a reference-only policy,
 * not an error return from the void setter or proof of a hardware retune.
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: outer reset.
 */
static void channel_preferences(void)
{
    const int ids[] = {0, 42, 255};
    const ULONG frequencies[] = {0, 606000000UL, 618000000UL};
    for (size_t i = 0; i < ARRAY_COUNT(ids); ++i)
    {
        ULONG previous_frequency = docsis_GetDownFreq();
        docsis_SetUSChannelId(ids[i]);
        UT_ASSERT_EQUAL(docsis_GetUSChannelId(), ids[i]);
        UT_ASSERT_TRUE(docsis_GetDownFreq() == previous_frequency);
        docsis_SetStartFreq(frequencies[i]);
        UT_ASSERT_TRUE(docsis_GetDownFreq() == frequencies[i]);
        UT_ASSERT_EQUAL(docsis_GetUSChannelId(), ids[i]);
    }
    docsis_SetUSChannelId(-1);
    docsis_SetUSChannelId(256);
    UT_ASSERT_EQUAL(docsis_GetUSChannelId(), 255);
    UT_ASSERT_TRUE(docsis_GetDownFreq() == frequencies[2]);
}

/** L2-04
 * Purpose: round-trip successive MAC-reinitialization threshold preferences.
 * Contract Requirement: cm_hal_{set,get}_ReinitMacThreshold; units/range unspecified.
 * Preconditions: independent model. Inputs: 0/19/ULONG_MAX (model-supported range).
 * Expected Result: readback; a one-shot failed write preserves the last threshold.
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: outer reset; no inferred automatic MAC recovery is asserted.
 */
static void threshold_readback(void)
{
    const ULONG inputs[] = {0, 19, ULONG_MAX};
    ULONG threshold = 0;
    for (size_t i = 0; i < ARRAY_COUNT(inputs); ++i)
    {
        REQUIRE_OK(cm_hal_set_ReinitMacThreshold(inputs[i]));
        REQUIRE_OK(cm_hal_get_ReinitMacThreshold(&threshold));
        UT_ASSERT_TRUE(threshold == inputs[i]);
    }
    REQUIRE_OK(cm_hal_test_fail_next("cm_hal_set_ReinitMacThreshold"));
    UT_ASSERT_EQUAL(cm_hal_set_ReinitMacThreshold(7), RETURN_ERR);
    REQUIRE_OK(cm_hal_get_ReinitMacThreshold(&threshold));
    UT_ASSERT_TRUE(threshold == ULONG_MAX);
    REQUIRE_OK(cm_hal_set_ReinitMacThreshold(7));
    REQUIRE_OK(cm_hal_get_ReinitMacThreshold(&threshold));
    UT_ASSERT_EQUAL(threshold, 7);
}

/** L2-05
 * Purpose: reconcile seeded counts/rows/indexed US status and snapshot ownership.
 * Contract Requirement: GetDSChannel/GetUSChannel/GetUsStatus/active TX/RX counts,
 * GetDsOfdmChanTable/GetUsOfdmaChanTable/GetStatusOfdmaUsTable; caller frees arrays.
 * Preconditions: serialized Linux fixtures. Inputs: unequal table counts/IDs.
 * Expected Result: exact named fields and OFDMA/status pairing; simultaneous
 * allocations and subsequent reads are independent, including caller mutations.
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: all partial/full outputs freed; outer reset.
 */
static void channel_consistency(void)
{
    cm_hal_test_channels_t fixture;
    channel_snapshot_t first = {0}, second = {0};
    make_channels(&fixture);
    channel_snapshot_t expected = channel_view(&fixture);
    REQUIRE_OK(cm_hal_test_seed_channels(&fixture));
    if (read_channels(&first) != RETURN_OK || read_channels(&second) != RETURN_OK)
    {
        release_channels(&first, &second);
        return;
    }
    check_channels(&first, &expected);
    check_channels(&second, &expected);
    UT_ASSERT_PTR_NOT_EQUAL(first.ds, second.ds);
    UT_ASSERT_PTR_NOT_EQUAL(first.us, second.us);
    UT_ASSERT_PTR_NOT_EQUAL(first.ofdm, second.ofdm);
    UT_ASSERT_PTR_NOT_EQUAL(first.ofdma, second.ofdma);
    UT_ASSERT_PTR_NOT_EQUAL(first.status, second.status);
    /* read_channels already checked pointer presence, but count mismatches must
     * not turn a failing assertion into an out-of-bounds write. */
    if (first.ds_count > 0) { first.ds[0].ChannelID = 201; }
    if (first.us_count > 0) { first.us[0].ChannelID = 202; }
    if (first.ofdm_count > 0) { first.ofdm[0].ChannelId = 203; }
    if (first.ofdma_count > 0) { first.ofdma[0].ChannelId = 204; }
    if (first.status_count > 0) { first.status[0].ChannelId = 205; }
    check_channels(&second, &expected);
    release_channels(&first, &second);
    if (read_channels(&first) == RETURN_OK)
    {
        check_channels(&first, &expected);
    }
    release_channels(&first, NULL);
}

/** Compare all log fields, including timeval components, rather than padding. */
static void check_event(const CMMGMT_CM_EventLogEntry_t *actual,
                        const CMMGMT_CM_EventLogEntry_t *expected)
{
    NUMBER(docsDevEvIndex); NUMBER(docsDevEvCounts); NUMBER(docsDevEvLevel);
    NUMBER(docsDevEvId); NUMBER(docsDevEvFirstTime.tv_sec);
    NUMBER(docsDevEvFirstTime.tv_usec); NUMBER(docsDevEvLastTime.tv_sec);
    NUMBER(docsDevEvLastTime.tv_usec); TEXT(docsDevEvText);
}

/** L2-06
 * Purpose: read seeded logs within capacity, request async clear, observe empty.
 * Contract Requirement: docsis_GetDocsisEventLogItems / ClearDocsisEventLog.
 * Preconditions: Linux model; no clock advancement from reads.
 * Inputs: three distinct logs; capacities 0/1/2/4; explicit async tick.
 * Expected Result: bounded ordered subsets, no completion merely from scheduling
 * or reading; zero rows after explicit completion and subsequent reads.
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: caller arrays on stack; outer reset restores logs/pending state.
 */
static void event_log_lifecycle(void)
{
    CMMGMT_CM_EventLogEntry_t fixture[3] = {{0}};
    CMMGMT_CM_EventLogEntry_t output[4] = {{0}};
    cm_hal_test_activity_t activity = {0};
    for (size_t i = 0; i < ARRAY_COUNT(fixture); ++i)
    {
        fixture[i].docsDevEvIndex = 11 + (UINT)i;
        fixture[i].docsDevEvCounts = 2 + (UINT)i;
        fixture[i].docsDevEvLevel = 3 + (UINT)i;
        fixture[i].docsDevEvId = 101 + (UINT)i;
        fixture[i].docsDevEvFirstTime.tv_sec = 1000 + (long)i;
        fixture[i].docsDevEvFirstTime.tv_usec = 10 + (long)i;
        fixture[i].docsDevEvLastTime.tv_sec = 2000 + (long)i;
        fixture[i].docsDevEvLastTime.tv_usec = 20 + (long)i;
        (void)snprintf(fixture[i].docsDevEvText, sizeof(fixture[i].docsDevEvText),
                       "L2 fixture %zu", i);
    }
    REQUIRE_OK(cm_hal_test_seed_logs(fixture, ARRAY_COUNT(fixture)));
    int count = docsis_GetDocsisEventLogItems(output, 4);
    UT_ASSERT_EQUAL(count, 3);
    if (count == 3)
    {
        for (int i = 0; i < count; ++i) { check_event(&output[i], &fixture[i]); }
    }
    for (int capacity = 0; capacity <= 2; ++capacity)
    {
        /* A complete untouched next row detects writes beyond the supplied len. */
        output[capacity] = fixture[2];
        count = docsis_GetDocsisEventLogItems(output, capacity);
        UT_ASSERT_EQUAL(count, capacity);
        check_event(&output[capacity], &fixture[2]);
        if (count == capacity)
        {
            for (int i = 0; i < count; ++i) { check_event(&output[i], &fixture[i]); }
        }
    }
    REQUIRE_OK(docsis_ClearDocsisEventLog());
    REQUIRE_OK(cm_hal_test_get_activity(&activity));
    UT_ASSERT_TRUE(activity.log_clear_pending);
    for (int read = 0; read < 2; ++read)
    {
        UT_ASSERT_EQUAL(docsis_GetDocsisEventLogItems(output, 4), 3);
    }
    cm_hal_test_advance_async();
    REQUIRE_OK(cm_hal_test_get_activity(&activity));
    UT_ASSERT_FALSE(activity.log_clear_pending);
    UT_ASSERT_EQUAL(docsis_GetDocsisEventLogItems(output, 4), 0);
    cm_hal_test_advance_async();
    UT_ASSERT_EQUAL(docsis_GetDocsisEventLogItems(output, 4), 0);
}

/** Compare every model activity field, without reading struct padding. */
static void check_activity(const cm_hal_test_activity_t *actual,
                           const cm_hal_test_activity_t *expected)
{
    NUMBER(db_initialized); NUMBER(ds_initialized); NUMBER(us_initialized);
    NUMBER(download_active); NUMBER(log_clear_pending); NUMBER(reboot_pending);
    NUMBER(factory_reset_pending); NUMBER(led_flash); NUMBER(reinit_mac_calls);
}

/** Compare all public observation fields, including individual IPv4 octets. */
static void check_observations(const cm_hal_test_observations_t *actual,
                               const cm_hal_test_observations_t *expected)
{
    TEXT(cm_status); TEXT(provision_type); TEXT(certificate_path); TEXT(market);
    NUMBER(certificate_enabled); NUMBER(cable_modem_resets); NUMBER(local_resets);
    NUMBER(docsis_resets); NUMBER(erouter_resets); NUMBER(energy_detected);
    NUMBER(lld_enabled);
    NUMBER(diplexer.usDiplexerSetting); NUMBER(diplexer.dsDiplexerSetting);
    TEXT(docsis.DOCSISVersion); TEXT(docsis.DOCSISDownstreamScanning);
    TEXT(docsis.DOCSISDownstreamRanging); TEXT(docsis.DOCSISUpstreamScanning);
    TEXT(docsis.DOCSISUpstreamRanging); TEXT(docsis.DOCSISTftpStatus);
    TEXT(docsis.DOCSISDataRegComplete); TEXT(docsis.DOCSISConfigFileName);
    TEXT(docsis.ToDStatus); TEXT(docsis.UpstreamServiceFlowParams);
    TEXT(docsis.DownstreamServiceFlowParams); TEXT(docsis.DOCSISDownstreamDataRate);
    TEXT(docsis.DOCSISUpstreamDataRate); TEXT(docsis.CoreVersion);
    NUMBER(docsis.DOCSISDHCPAttempts); NUMBER(docsis.DOCSISTftpAttempts);
    NUMBER(docsis.BPIState); NUMBER(docsis.NetworkAccess); NUMBER(docsis.MaxCpeAllowed);
    NUMBER(codewords.UnerroredCodewords); NUMBER(codewords.CorrectableCodewords);
    NUMBER(codewords.UncorrectableCodewords);
    TEXT(dhcp.BootFileName); TEXT(dhcp.TimeServer); TEXT(dhcp.RebindTimeRemaining);
    TEXT(dhcp.RenewTimeRemaining); TEXT(dhcp.MACAddress); TEXT(dhcp.DOCSISDHCPStatus);
    NUMBER(dhcp.TimeOffset); NUMBER(dhcp.LeaseTimeRemaining);
    TEXT(dhcpv6.IPv6Address); TEXT(dhcpv6.IPv6BootFileName); TEXT(dhcpv6.IPv6Prefix);
    TEXT(dhcpv6.IPv6Router); TEXT(dhcpv6.IPv6TFTPServer); TEXT(dhcpv6.IPv6TimeServer);
    NUMBER(dhcpv6.IPv6LeaseTimeRemaining); NUMBER(dhcpv6.IPv6RebindTimeRemaining);
    NUMBER(dhcpv6.IPv6RenewTimeRemaining);
    TEXT(cpe.IPAddress); TEXT(cpe.MACAddress);
    for (size_t i = 0; i < IPV4_ADDRESS_SIZE; ++i)
    {
        NUMBER(docsis.UpgradeServerIP.Dot[i]); NUMBER(dhcp.IPAddress.Dot[i]);
        NUMBER(dhcp.SubnetMask.Dot[i]); NUMBER(dhcp.Gateway.Dot[i]);
        NUMBER(dhcp.TFTPServer.Dot[i]);
    }
}

/** Read observations through public HAL calls only; outputs are caller storage. */
static int read_observations(cm_hal_test_observations_t *out)
{
#define READ(call) do { \
    int result_ = (call); \
    UT_ASSERT_EQUAL(result_, RETURN_OK); \
    if (result_ != RETURN_OK) { return RETURN_ERR; } \
} while (0)
    PCMMGMT_CM_ERROR_CODEWORDS codewords = &out->codewords;
    PCMMGMT_DML_CPE_LIST cpe = &out->cpe;
    ULONG cpe_count = 0;
    memset(out, 0, sizeof(*out));
    READ(docsis_getCMStatus(out->cm_status));
    READ(docsis_GetDOCSISInfo(&out->docsis));
    READ(docsis_GetErrorCodewords(&codewords));
    UT_ASSERT_PTR_EQUAL(codewords, &out->codewords);
    READ(cm_hal_GetDHCPInfo(&out->dhcp));
    READ(cm_hal_GetIPv6DHCPInfo(&out->dhcpv6));
    READ(cm_hal_GetCPEList(&cpe, &cpe_count, "router"));
    UT_ASSERT_PTR_EQUAL(cpe, &out->cpe);
    UT_ASSERT_TRUE(cpe_count == 1UL);
    READ(cm_hal_GetMarket(out->market));
    READ(docsis_GetProvIpType(out->provision_type));
    READ(docsis_GetCert(out->certificate_path));
    READ(docsis_GetCertStatus(&out->certificate_enabled));
    READ(cm_hal_Get_CableModemResetCount(&out->cable_modem_resets));
    READ(cm_hal_Get_LocalResetCount(&out->local_resets));
    READ(cm_hal_Get_DocsisResetCount(&out->docsis_resets));
    READ(cm_hal_Get_ErouterResetCount(&out->erouter_resets));
    READ(docsis_IsEnergyDetected(&out->energy_detected));
    out->lld_enabled = docsis_LLDgetEnableStatus();
    UT_ASSERT_TRUE(out->lld_enabled == ENABLE || out->lld_enabled == DISABLE);
    READ(cm_hal_get_DiplexerSettings(&out->diplexer));
#undef READ
    return RETURN_OK;
}

/** Check both public outputs and stored state against an independent fixture. */
static void check_public_observations(const cm_hal_test_observations_t *expected)
{
    cm_hal_test_observations_t actual = {0}, stored = {0};
    if (read_observations(&actual) == RETURN_OK)
    {
        check_observations(&actual, expected);
    }
    REQUIRE_OK(cm_hal_test_get_observations(&stored));
    check_observations(&stored, expected);
}

/** Distinct model-only observations; no file, network or secret is accessed. */
static cm_hal_test_observations_t make_observations(void)
{
    cm_hal_test_observations_t fixture = {
        .docsis = {
            .DOCSISVersion = "3.1", .DOCSISDownstreamScanning = "Complete",
            .DOCSISDownstreamRanging = "Complete", .DOCSISUpstreamScanning = "Complete",
            .DOCSISUpstreamRanging = "Complete", .DOCSISTftpStatus = "DownloadComplete",
            .DOCSISDataRegComplete = "RegistrationComplete", .DOCSISDHCPAttempts = 5,
            .DOCSISConfigFileName = "l2.cm", .DOCSISTftpAttempts = 7,
            .ToDStatus = "Complete", .BPIState = FALSE, .NetworkAccess = TRUE,
            .UpgradeServerIP = { .Dot = {198, 51, 100, 9} }, .MaxCpeAllowed = 3,
            .UpstreamServiceFlowParams = "L2 upstream",
            .DownstreamServiceFlowParams = "L2 downstream",
            .DOCSISDownstreamDataRate = "800000000", .DOCSISUpstreamDataRate = "80000000",
            .CoreVersion = "l2-reference"
        },
        .codewords = { .UnerroredCodewords = ULONG_MAX - 2,
                       .CorrectableCodewords = 61, .UncorrectableCodewords = 7 },
        .dhcp = {
            .IPAddress = { .Dot = {198, 51, 100, 21} }, .BootFileName = "l2-v4.cm",
            .SubnetMask = { .Dot = {255, 255, 255, 128} },
            .Gateway = { .Dot = {198, 51, 100, 1} },
            .TFTPServer = { .Dot = {198, 51, 100, 10} },
            .TimeServer = "198.51.100.11", .TimeOffset = -3600,
            .LeaseTimeRemaining = 7201, .RebindTimeRemaining = "6301",
            .RenewTimeRemaining = "3601", .MACAddress = "02:00:00:00:01:21",
            .DOCSISDHCPStatus = "Complete"
        },
        .dhcpv6 = {
            .IPv6Address = "2001:db8:1::21", .IPv6BootFileName = "l2-v6.cm",
            .IPv6Prefix = "2001:db8:1::/64", .IPv6Router = "2001:db8:1::1",
            .IPv6TFTPServer = "2001:db8:1::10", .IPv6TimeServer = "2001:db8:1::11",
            .IPv6LeaseTimeRemaining = 8201, .IPv6RebindTimeRemaining = 7301,
            .IPv6RenewTimeRemaining = 4101
        },
        .cpe = { .IPAddress = "198.51.100.22", .MACAddress = "02:00:00:00:01:22" },
        .cm_status = "OPERATIONAL", .provision_type = "STATIC",
        .certificate_path = "/reference/l2-cert.bin", .market = "EURO",
        .certificate_enabled = DISABLE, .cable_modem_resets = 17,
        .local_resets = 23, .docsis_resets = 31, .erouter_resets = 47,
        .energy_detected = FALSE, .lld_enabled = ENABLE,
        .diplexer = { .usDiplexerSetting = 204, .dsDiplexerSetting = 1218 }
    };
    return fixture;
}

/** Read/free all PHY snapshots inside the helper, including partial failures. */
static void check_channel_fixture(cm_hal_test_channels_t *fixture)
{
    channel_snapshot_t actual = {0};
    channel_snapshot_t expected = channel_view(fixture);
    if (read_channels(&actual) == RETURN_OK)
    {
        check_channels(&actual, &expected);
    }
    release_channels(&actual, NULL);
}

/** Check preferences independently of actual observed channel frequencies. */
static void check_preferences(const char *mode, UINT8 id, ULONG frequency,
                              ULONG expected_threshold)
{
    char actual_mode[64] = {0};
    ULONG threshold = 0;
    REQUIRE_OK(docsis_GetMddIpModeOverride(actual_mode));
    check_text(actual_mode, mode, sizeof(actual_mode));
    UT_ASSERT_TRUE(docsis_GetUSChannelId() == id);
    UT_ASSERT_TRUE(docsis_GetDownFreq() == frequency);
    REQUIRE_OK(cm_hal_get_ReinitMacThreshold(&threshold));
    UT_ASSERT_TRUE(threshold == expected_threshold);
}

/** Assert reference default empty HTTP state, including initialized outputs. */
static void check_empty_http(void)
{
    char url[CM_HAL_TEST_HTTP_CAPACITY] = "sentinel";
    char filename[CM_HAL_TEST_HTTP_CAPACITY] = "sentinel";
    unsigned int interface = UINT_MAX;
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Url(url, filename), RETURN_ERR);
    check_text(url, "", sizeof(url));
    check_text(filename, "", sizeof(filename));
    REQUIRE_OK(cm_hal_Get_HTTP_Download_Interface(&interface));
    UT_ASSERT_TRUE(interface == 0);
}

/** Attempt valid operations while busy; all rejections must preserve progress. */
static void check_busy_http(char *url, char *filename, int progress)
{
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Url(url, filename), RETURN_ERR);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Interface(0), RETURN_ERR);
    UT_ASSERT_EQUAL(cm_hal_HTTP_Download(), RETURN_ERR);
    UT_ASSERT_EQUAL(cm_hal_FWupdateAndFactoryReset(url, filename), RETURN_ERR);
    check_http(url, filename, 1);
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Status(), progress);
}

/** L2-07
 * Purpose: follow configured HTTP download through progress and reboot readiness.
 * Contract Requirement: HTTP configuration/Download/GetStatus/Reboot_Ready; status
 * 100 means complete pending reboot. Busy configuration is rejected.
 * Preconditions: idle Linux model. Inputs: profile settings, progress 0/1/43/99/100.
 * Expected Result: exact status/readiness; reads do not advance; pending-update
 * rejection preserves settings and progress (explicit reference busy policy).
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: outer reset cancels transfer/completed-update state.
 */
static void download_lifecycle(void)
{
    char url[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    char filename[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    const int progress[] = {0, 1, 43, 99, 100};
    ULONG ready = 0;
    cm_hal_test_activity_t activity = {0};
    REQUIRE_OK(load_http(url, filename));
    UT_ASSERT_EQUAL(cm_hal_HTTP_Download(), RETURN_ERR);
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Url(url, filename));
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Interface(1));
    REQUIRE_OK(cm_hal_Reboot_Ready(&ready));
    UT_ASSERT_TRUE(ready == 2);
    REQUIRE_OK(cm_hal_HTTP_Download());
    for (size_t i = 0; i < ARRAY_COUNT(progress); ++i)
    {
        if (i != 0)
        {
            REQUIRE_OK(cm_hal_test_advance_download(progress[i]));
        }
        for (int read = 0; read < 2; ++read)
        {
            UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Status(), progress[i]);
            REQUIRE_OK(cm_hal_Reboot_Ready(&ready));
            UT_ASSERT_TRUE(ready == (progress[i] == 100 ? 1UL : 2UL));
        }
        REQUIRE_OK(cm_hal_test_get_activity(&activity));
        UT_ASSERT_TRUE(activity.download_active == (progress[i] < 100));
        UT_ASSERT_FALSE(activity.reboot_pending);
        UT_ASSERT_FALSE(activity.factory_reset_pending);
        check_busy_http(url, filename, progress[i]);
        if (progress[i] < 100)
        {
            UT_ASSERT_EQUAL(cm_hal_HTTP_Download_Reboot_Now(), RETURN_ERR);
        }
    }
    /* An ordinary completed download must not reboot merely because time ticks. */
    cm_hal_test_advance_async();
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Status(), 100);
    REQUIRE_OK(cm_hal_Reboot_Ready(&ready));
    UT_ASSERT_TRUE(ready == 1);
}

/** L2-08
 * Purpose: safely queue and complete ordinary reboot and firmware/factory reset.
 * Contract Requirement: HTTP_Download_Reboot_Now / FWupdateAndFactoryReset.
 * Preconditions: BUILD_LINUX reference only, seeded observations/PHY/preferences.
 * Inputs: completed ordinary download, then firmware request and explicit ticks.
 * Expected Result: no completion before eligible tick; CM/local counters advance
 * once, DOCSIS/eRouter counters and PHY remain; ordinary preferences persist,
 * factory preferences/logs reset. These scopes are model policy, not vendor ABI.
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: all outputs freed by helpers; outer reset, no actual host action.
 */
static void simulated_destructive_requests(void)
{
    char url[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    char filename[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    cm_hal_test_channels_t channels;
    cm_hal_test_observations_t expected = make_observations();
    cm_hal_test_activity_t activity = {0};
    CMMGMT_CM_EventLogEntry_t log = {
        .docsDevEvIndex = 41, .docsDevEvCounts = 9, .docsDevEvId = 71,
        .docsDevEvText = "L2 reset scope"
    };
    CMMGMT_CM_EventLogEntry_t output = {0};
    ULONG ready = 0;
    REQUIRE_OK(load_http(url, filename));
    make_channels(&channels);
    REQUIRE_OK(cm_hal_test_seed_channels(&channels));
    REQUIRE_OK(cm_hal_test_seed_observations(&expected));
    REQUIRE_OK(cm_hal_test_seed_logs(&log, 1));
    REQUIRE_OK(cm_hal_InitDB());
    REQUIRE_OK(docsis_InitDS());
    REQUIRE_OK(docsis_InitUS());
    REQUIRE_OK(docsis_SetMddIpModeOverride("ipv6Only"));
    docsis_SetUSChannelId(42);
    docsis_SetStartFreq(618000000UL);
    REQUIRE_OK(cm_hal_set_ReinitMacThreshold(13));
    REQUIRE_OK(cm_hal_HTTP_LED_Flash(TRUE));
    UT_ASSERT_EQUAL(cm_hal_HTTP_Download_Reboot_Now(), RETURN_ERR);
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Url(url, filename));
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Interface(1));
    REQUIRE_OK(cm_hal_HTTP_Download());
    REQUIRE_OK(cm_hal_test_advance_download(100));
    REQUIRE_OK(cm_hal_HTTP_Download_Reboot_Now());
    REQUIRE_OK(cm_hal_test_get_activity(&activity));
    UT_ASSERT_TRUE(activity.reboot_pending);
    UT_ASSERT_FALSE(activity.factory_reset_pending);
    check_public_observations(&expected);
    REQUIRE_OK(cm_hal_Reboot_Ready(&ready));
    UT_ASSERT_TRUE(ready == 2);
    UT_ASSERT_EQUAL(cm_hal_HTTP_Download_Reboot_Now(), RETURN_ERR);
    check_busy_http(url, filename, 100);
    cm_hal_test_advance_async();
    ++expected.cable_modem_resets;
    ++expected.local_resets;
    check_public_observations(&expected);
    check_channel_fixture(&channels);
    check_preferences("ipv6Only", 42, 618000000UL, 13);
    check_http(url, filename, 1);
    int count = docsis_GetDocsisEventLogItems(&output, 1);
    UT_ASSERT_EQUAL(count, 1);
    if (count == 1) { check_event(&output, &log); }
    REQUIRE_OK(cm_hal_test_get_activity(&activity));
    cm_hal_test_activity_t initialized = {
        .db_initialized = TRUE, .ds_initialized = TRUE,
        .us_initialized = TRUE, .led_flash = TRUE
    };
    check_activity(&activity, &initialized);
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Status(), 0);
    cm_hal_test_advance_async();
    check_public_observations(&expected);

    REQUIRE_OK(cm_hal_FWupdateAndFactoryReset(url, filename));
    for (int stage = 0; stage < 2; ++stage)
    {
        if (stage != 0) { REQUIRE_OK(cm_hal_test_advance_download(61)); }
        check_busy_http(url, filename, stage == 0 ? 0 : 61);
        cm_hal_test_advance_async();
        REQUIRE_OK(cm_hal_test_get_activity(&activity));
        UT_ASSERT_TRUE(activity.factory_reset_pending);
        UT_ASSERT_TRUE(activity.download_active);
        UT_ASSERT_FALSE(activity.reboot_pending);
        check_public_observations(&expected);
        check_preferences("ipv6Only", 42, 618000000UL, 13);
    }
    REQUIRE_OK(cm_hal_test_advance_download(100));
    UT_ASSERT_EQUAL(cm_hal_HTTP_Download_Reboot_Now(), RETURN_ERR);
    check_public_observations(&expected);
    cm_hal_test_advance_async();
    ++expected.cable_modem_resets;
    ++expected.local_resets;
    check_public_observations(&expected);
    check_channel_fixture(&channels);
    check_preferences("honorMdd", 1, 600000000UL, 0);
    check_empty_http();
    UT_ASSERT_EQUAL(docsis_GetDocsisEventLogItems(&output, 1), 0);
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Status(), 0);
    REQUIRE_OK(cm_hal_Reboot_Ready(&ready));
    UT_ASSERT_TRUE(ready == 2);
    REQUIRE_OK(cm_hal_test_get_activity(&activity));
    initialized.led_flash = FALSE;
    check_activity(&activity, &initialized);
    cm_hal_test_advance_async();
    check_public_observations(&expected);
}

/** L2-09
 * Purpose: reinitialize MAC while maintaining all channel observations.
 * Contract Requirement: cm_hal_ReinitMac explicitly preserves DS/US channels.
 * Preconditions: distinct seeded PHY and independent nondefault preferences.
 * Inputs: ReinitMac twice, with independently owned before/after snapshots.
 * Expected Result: every PHY field/count/indexed US row preserved; model activity
 * counts two calls without changing physical counters or preferences.
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: free both complete/partial snapshots, then outer reset.
 */
static void reinit_channel_preservation(void)
{
    cm_hal_test_channels_t fixture;
    cm_hal_test_observations_t observations = make_observations();
    cm_hal_test_activity_t activity = {0};
    channel_snapshot_t before = {0}, after = {0};
    make_channels(&fixture);
    REQUIRE_OK(cm_hal_test_seed_channels(&fixture));
    REQUIRE_OK(cm_hal_test_seed_observations(&observations));
    REQUIRE_OK(docsis_SetMddIpModeOverride("ipv4Only"));
    docsis_SetUSChannelId(57);
    docsis_SetStartFreq(630000000UL);
    REQUIRE_OK(cm_hal_set_ReinitMacThreshold(21));
    if (read_channels(&before) != RETURN_OK)
    {
        release_channels(&before, NULL);
        return;
    }
    int first = cm_hal_ReinitMac();
    int second = cm_hal_ReinitMac();
    UT_ASSERT_EQUAL(first, RETURN_OK);
    UT_ASSERT_EQUAL(second, RETURN_OK);
    if (read_channels(&after) == RETURN_OK)
    {
        channel_snapshot_t expected = channel_view(&fixture);
        check_channels(&before, &expected);
        check_channels(&after, &before);
        UT_ASSERT_PTR_NOT_EQUAL(before.ds, after.ds);
        UT_ASSERT_PTR_NOT_EQUAL(before.us, after.us);
    }
    release_channels(&before, &after);
    check_public_observations(&observations);
    check_preferences("ipv4Only", 57, 630000000UL, 21);
    REQUIRE_OK(cm_hal_test_get_activity(&activity));
    cm_hal_test_activity_t expected_activity = { .reinit_mac_calls = 2 };
    check_activity(&activity, &expected_activity);
}

/** Capture the by-value argument, mutate the local copy, and query during dispatch. */
static INT capture_diplexer(CM_DIPLEXER_SETTINGS settings)
{
    ++callback_calls;
    callback_payload = settings;
    settings.usDiplexerSetting = 0;
    settings.dsDiplexerSetting = 0;
    callback_getter_status = cm_hal_get_DiplexerSettings(&callback_getter);
    /* Local writes cannot change the published fixture or caller's input. */
    return settings.usDiplexerSetting == 0 && settings.dsDiplexerSetting == 0
               ? RETURN_OK : RETURN_ERR;
}

/** A distinct callback must not replace an already registered model callback. */
static INT other_diplexer(CM_DIPLEXER_SETTINGS settings)
{
    (void)settings;
    UT_FAIL("A rejected replacement callback was invoked");
    return RETURN_ERR;
}

/** Compare the complete by-value payload using its documented MHz fields. */
static void check_diplexer(const CM_DIPLEXER_SETTINGS *actual,
                           const CM_DIPLEXER_SETTINGS *expected)
{
    NUMBER(usDiplexerSetting); NUMBER(dsDiplexerSetting);
}

/** L2-10
 * Purpose: register diplexer callback, inject changes and reconcile getter/payload.
 * Contract Requirement: Register_DiplexerVariationCallback takes a by-value
 * CM_DIPLEXER_SETTINGS callback that cannot be publicly removed.
 * Preconditions: Linux model reset/quiescent callback state. Inputs: two settings.
 * Expected Result: one invocation per injected change, getter already matches
 * inside callback, local payload mutation has no effect. Duplicate-registration,
 * unchanged-dispatch and synchronous reset behavior are explicit model policies.
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: synchronous model reset removes subscription; no vendor unregister.
 */
static void diplexer_callback_lifecycle(void)
{
    CM_DIPLEXER_SETTINGS changes[] = {
        { .usDiplexerSetting = 204, .dsDiplexerSetting = 1218 },
        { .usDiplexerSetting = 42, .dsDiplexerSetting = 1002 }
    };
    UT_ASSERT_EQUAL(cm_hal_Register_DiplexerVariationCallback(NULL), RETURN_ERR);
    REQUIRE_OK(cm_hal_Register_DiplexerVariationCallback(capture_diplexer));
    REQUIRE_OK(cm_hal_Register_DiplexerVariationCallback(capture_diplexer));
    UT_ASSERT_EQUAL(cm_hal_Register_DiplexerVariationCallback(other_diplexer), RETURN_ERR);
    UT_ASSERT_TRUE(callback_calls == 0);
    for (size_t i = 0; i < ARRAY_COUNT(changes); ++i)
    {
        CM_DIPLEXER_SETTINGS input = changes[i], getter = {0};
        REQUIRE_OK(cm_hal_test_dispatch_diplexer(input));
        UT_ASSERT_TRUE(callback_calls == i + 1);
        UT_ASSERT_EQUAL(callback_getter_status, RETURN_OK);
        check_diplexer(&callback_payload, &changes[i]);
        check_diplexer(&callback_getter, &changes[i]);
        check_diplexer(&input, &changes[i]);
        REQUIRE_OK(cm_hal_get_DiplexerSettings(&getter));
        check_diplexer(&getter, &changes[i]);
        REQUIRE_OK(cm_hal_test_dispatch_diplexer(input));
        UT_ASSERT_TRUE(callback_calls == i + 1);
    }
    cm_hal_test_reset();
    REQUIRE_OK(cm_hal_test_dispatch_diplexer(changes[0]));
    UT_ASSERT_TRUE(callback_calls == ARRAY_COUNT(changes));
}

/** L2-11
 * Purpose: reconcile independent read-only observations with no state mutation.
 * Contract Requirement: four reset-count getters; DHCP/v6, certificate/status,
 * energy, LLD, diplexer, DOCSIS/codewords/CPE/market/provision getters.
 * Preconditions: independent seeded fields; download and log clear pending.
 * Inputs: distinct counters; one-counter-at-a-time reseeds; both boolean values.
 * Expected Result: exact named fields and stable activity/preferences/progress/
 * logs; reads neither alias other observations nor complete queued work.
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: stack-owned outputs, outer reset cancels pending model work.
 */
static void independent_observations(void)
{
    cm_hal_test_observations_t fixture = make_observations();
    cm_hal_test_activity_t before = {0}, after = {0};
    char url[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    char filename[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    CMMGMT_CM_EventLogEntry_t log = {0}, current_log = {0};
    REQUIRE_OK(load_http(url, filename));
    REQUIRE_OK(cm_hal_test_seed_observations(&fixture));
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Url(url, filename));
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Interface(1));
    REQUIRE_OK(cm_hal_HTTP_Download());
    REQUIRE_OK(cm_hal_test_advance_download(37));
    UT_ASSERT_EQUAL(docsis_GetDocsisEventLogItems(&log, 1), 1);
    REQUIRE_OK(docsis_ClearDocsisEventLog());
    REQUIRE_OK(cm_hal_HTTP_LED_Flash(TRUE));
    REQUIRE_OK(cm_hal_test_get_activity(&before));
    for (int read = 0; read < 3; ++read)
    {
        check_public_observations(&fixture);
    }
    ULONG *counters[] = {
        &fixture.cable_modem_resets, &fixture.local_resets,
        &fixture.docsis_resets, &fixture.erouter_resets
    };
    for (size_t i = 0; i < ARRAY_COUNT(counters); ++i)
    {
        *counters[i] = ULONG_MAX - (ULONG)i;
        REQUIRE_OK(cm_hal_test_seed_observations(&fixture));
        check_public_observations(&fixture);
    }
    fixture.certificate_enabled = ENABLE;
    fixture.energy_detected = TRUE;
    fixture.lld_enabled = DISABLE;
    fixture.diplexer.usDiplexerSetting = 85;
    fixture.diplexer.dsDiplexerSetting = 1002;
    REQUIRE_OK(cm_hal_test_seed_observations(&fixture));
    check_public_observations(&fixture);
    REQUIRE_OK(cm_hal_test_get_activity(&after));
    check_activity(&after, &before);
    check_preferences("honorMdd", 1, 600000000UL, 0);
    check_http(url, filename, 1);
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Status(), 37);
    int count = docsis_GetDocsisEventLogItems(&current_log, 1);
    UT_ASSERT_EQUAL(count, 1);
    if (count == 1) { check_event(&current_log, &log); }
    UT_ASSERT_TRUE(callback_calls == 0);
}

/** Seed nondefaults, observe startup stages, then leave work/faults to reset.
 * This helper owns no returned allocations; early returns cannot leak snapshots
 * retained by the outer isolation scenario.
 */
static void startup_and_contaminate(void)
{
    cm_hal_test_channels_t channels;
    cm_hal_test_observations_t observations = make_observations();
    cm_hal_test_activity_t actual = {0}, expected = {0};
    CMMGMT_CM_EventLogEntry_t log = {
        .docsDevEvIndex = 91, .docsDevEvId = 97, .docsDevEvText = "L2 isolated fixture"
    };
    CMMGMT_CM_EventLogEntry_t output = {0};
    char url[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    char filename[CM_HAL_TEST_HTTP_CAPACITY] = {0};
    make_channels(&channels);
    REQUIRE_OK(load_http(url, filename));
    REQUIRE_OK(cm_hal_test_seed_channels(&channels));
    REQUIRE_OK(cm_hal_test_seed_observations(&observations));
    REQUIRE_OK(cm_hal_test_seed_logs(&log, 1));
    REQUIRE_OK(docsis_SetMddIpModeOverride("ipv6Only"));
    docsis_SetUSChannelId(89);
    docsis_SetStartFreq(642000000UL);
    REQUIRE_OK(cm_hal_set_ReinitMacThreshold(29));
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Url(url, filename));
    REQUIRE_OK(cm_hal_Set_HTTP_Download_Interface(1));
    REQUIRE_OK(cm_hal_HTTP_LED_Flash(TRUE));
    expected.led_flash = TRUE;
    for (int stage = 0; stage < 4; ++stage)
    {
        if (stage == 0)
        {
            REQUIRE_OK(cm_hal_InitDB());
            expected.db_initialized = TRUE;
        }
        else if (stage == 1)
        {
            REQUIRE_OK(docsis_InitDS());
            expected.ds_initialized = TRUE;
        }
        else if (stage == 2)
        {
            REQUIRE_OK(docsis_InitUS());
            expected.us_initialized = TRUE;
        }
        else
        {
            REQUIRE_OK(cm_hal_InitDB());
            REQUIRE_OK(docsis_InitDS());
            REQUIRE_OK(docsis_InitUS());
        }
        REQUIRE_OK(cm_hal_test_get_activity(&actual));
        check_activity(&actual, &expected);
        check_public_observations(&observations);
        check_channel_fixture(&channels);
        check_preferences("ipv6Only", 89, 642000000UL, 29);
        check_http(url, filename, 1);
        int count = docsis_GetDocsisEventLogItems(&output, 1);
        UT_ASSERT_EQUAL(count, 1);
        if (count == 1) { check_event(&output, &log); }
    }
    REQUIRE_OK(cm_hal_HTTP_Download());
    REQUIRE_OK(cm_hal_test_advance_download(53));
    REQUIRE_OK(docsis_ClearDocsisEventLog());
    REQUIRE_OK(cm_hal_Register_DiplexerVariationCallback(capture_diplexer));
    REQUIRE_OK(cm_hal_test_fail_next("cm_hal_GetDHCPInfo"));
    cm_hal_test_fail_next_allocation();
}

/** L2-12
 * Purpose: initialize DB/DS/US in order, preserve fixtures, prove case isolation.
 * Contract Requirement: cm_hal_InitDB/docsis_InitDS/docsis_InitUS initialization;
 * idempotence, pre-init reads and reset/fault scope are Linux model conventions.
 * Preconditions: reset independent model. Inputs: distinct fixtures, all startup
 * stages, repeated startup, pending transfer/clear/callback and one-shot faults.
 * Expected Result: flags progress independently, startup preserves fixtures;
 * reset restores initial defaults and clears pending work/faults/subscription;
 * caller-owned snapshots retained over reset remain valid.
 * Level: L2. Hardware Requirements: none. Destructive Classification: simulation.
 * Restoration: free every partial/full snapshot pair and outer model reset.
 */
static void startup_fixture_isolation(void)
{
    cm_hal_test_observations_t baseline = {0};
    cm_hal_test_activity_t activity = {0}, idle = {0};
    channel_snapshot_t before = {0}, after = {0};
    CMMGMT_CM_EventLogEntry_t original[CM_HAL_TEST_MAX_LOGS] = {{0}};
    CMMGMT_CM_EventLogEntry_t restored[CM_HAL_TEST_MAX_LOGS] = {{0}};
    REQUIRE_OK(cm_hal_test_get_observations(&baseline));
    REQUIRE_OK(cm_hal_test_get_activity(&activity));
    check_activity(&activity, &idle);
    int original_count = docsis_GetDocsisEventLogItems(original, CM_HAL_TEST_MAX_LOGS);
    UT_ASSERT_TRUE(original_count >= 0 && original_count <= CM_HAL_TEST_MAX_LOGS);
    if (read_channels(&before) != RETURN_OK)
    {
        release_channels(&before, NULL);
        return;
    }
    startup_and_contaminate();
    cm_hal_test_reset();
    check_public_observations(&baseline); /* Also proves the DHCP fault is cleared. */
    if (read_channels(&after) == RETURN_OK) /* Proves allocation fault is cleared. */
    {
        check_channels(&after, &before);
        UT_ASSERT_PTR_NOT_EQUAL(before.ds, after.ds);
        UT_ASSERT_PTR_NOT_EQUAL(before.us, after.us);
    }
    release_channels(&before, &after);
    int restored_count = docsis_GetDocsisEventLogItems(restored, CM_HAL_TEST_MAX_LOGS);
    UT_ASSERT_EQUAL(restored_count, original_count);
    if (original_count >= 0 && original_count <= CM_HAL_TEST_MAX_LOGS &&
        restored_count == original_count)
    {
        for (int i = 0; i < original_count; ++i)
        {
            check_event(&restored[i], &original[i]);
        }
    }
    REQUIRE_OK(cm_hal_test_get_activity(&activity));
    check_activity(&activity, &idle);
    check_preferences("honorMdd", 1, 600000000UL, 0);
    check_empty_http();
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Status(), 0);
    cm_hal_test_advance_async();
    check_public_observations(&baseline);
    CM_DIPLEXER_SETTINGS changed = { .usDiplexerSetting = 204, .dsDiplexerSetting = 1218 };
    REQUIRE_OK(cm_hal_test_dispatch_diplexer(changed));
    UT_ASSERT_TRUE(callback_calls == 0);
}

/**
 * Reset wrappers deliberately surround a normal scenario call rather than use
 * fatal assertions or the framework's declared-but-unimplemented per-test hook.
 * An early scenario return still reaches teardown. Static callback state is
 * reset as well, after model reset has synchronously removed the subscription.
 */
#define L2_CASE(id, scenario) \
    static void test_l2_##id(void) \
    { \
        cm_hal_test_reset(); \
        callback_calls = 0; \
        memset(&callback_payload, 0, sizeof(callback_payload)); \
        memset(&callback_getter, 0, sizeof(callback_getter)); \
        callback_getter_status = RETURN_ERR; \
        UT_LOG_INFO("L2-" #id " cm_hal: " #scenario " [Linux simulation]"); \
        scenario(); \
        cm_hal_test_reset(); \
    }

L2_CASE(01, mdd_readback)
L2_CASE(02, http_readback)
L2_CASE(03, channel_preferences)
L2_CASE(04, threshold_readback)
L2_CASE(05, channel_consistency)
L2_CASE(06, event_log_lifecycle)
L2_CASE(07, download_lifecycle)
L2_CASE(08, simulated_destructive_requests)
L2_CASE(09, reinit_channel_preservation)
L2_CASE(10, diplexer_callback_lifecycle)
L2_CASE(11, independent_observations)
L2_CASE(12, startup_fixture_isolation)
#undef L2_CASE

/** Ensure no pending simulated work or callback escapes suite shutdown. */
static int finish_l2_suite(void)
{
    cm_hal_test_reset();
    return 0;
}
#endif /* BUILD_LINUX */

/* PUBLIC_INTERFACE */
/**
 * Register CM L2 stateful cases in UT_TESTS_L2; no parameters.
 * Return 0 on success, -1 on suite/test registration failure. Non-Linux builds
 * register no model-only cases and never reference private simulation controls.
 */
int test_cm_hal_l2_register(void)
{
#ifdef BUILD_LINUX
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L2 cm_hal Linux simulation]", NULL, finish_l2_suite, UT_TESTS_L2);
    if (suite == NULL)
    {
        return -1;
    }
#define ADD_CASE(id, title) do { \
    if (UT_add_test(suite, "L2-" #id ": " title, test_l2_##id) == NULL) \
    { return -1; } \
} while (0)
    ADD_CASE(01, "MDD configuration readback and preservation");
    ADD_CASE(02, "HTTP settings and interface independence");
    ADD_CASE(03, "Channel ID and start-frequency preferences");
    ADD_CASE(04, "ReinitMacThreshold round-trip");
    ADD_CASE(05, "Seeded channel consistency and independent snapshots");
    ADD_CASE(06, "Seeded event logs and asynchronous clear");
    ADD_CASE(07, "HTTP lifecycle and pending-update rejection");
    ADD_CASE(08, "Safe simulated reboot and firmware factory reset");
    ADD_CASE(09, "ReinitMac preserves channel observations");
    ADD_CASE(10, "Diplexer callback payload and getter agreement");
    ADD_CASE(11, "Independent observations without state mutation");
    ADD_CASE(12, "Startup stages and fixture isolation");
#undef ADD_CASE
#endif
    return 0;
}
