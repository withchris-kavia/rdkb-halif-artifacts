/*
* If not stated otherwise in this file or this component's LICENSE file the
* following copyright and licenses apply:*
* Copyright 2023 RDK Management
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include <ut.h>
#include <ut_log.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "cm_hal.h"

extern int register_hal_l1_tests(void);
extern void __real_CU_cleanup_registry(void);

static bool registration_failed;
static bool capture_results;
static bool results_captured;
static bool execution_failed;
static unsigned int tests_run;

/* PUBLIC_INTERFACE */
/**
 * Add a test without ut-core's assert-on-allocation-failure behavior.
 * Parameters and return value match UT_add_test; failures remain sticky even
 * when an upstream registrar ignores the returned pointer.
 */
UT_test_t *__wrap_UT_add_test(UT_test_suite_t *suite, const char *title,
                            UT_TestFunction_t function)
{
    CU_pTest test = CU_add_test((CU_pSuite)suite, title, function);

    if (test == NULL)
    {
        registration_failed = true;
    }
    return (UT_test_t *)test;
}

/* PUBLIC_INTERFACE */
/**
 * Capture run statistics and errors immediately before CUnit discards them.
 * This linker hook has no parameters or return value and always delegates
 * registry destruction to the unmodified CUnit implementation.
 */
void __wrap_CU_cleanup_registry(void)
{
    if (capture_results)
    {
        const CU_RunSummary *summary = CU_get_run_summary();

        results_captured = true;
        execution_failed = execution_failed || CU_get_error() != CUE_SUCCESS;
        if (summary == NULL)
        {
            execution_failed = true;
        }
        else
        {
            tests_run += summary->nTestsRun;
            execution_failed = execution_failed || summary->nTestsFailed != 0 ||
                summary->nAssertsFailed != 0 || summary->nSuitesFailed != 0 ||
                summary->nFailureRecords != 0;
        }
    }
    __real_CU_cleanup_registry();
}

/* PUBLIC_INTERFACE */
/** Initialize the HAL database for suite setup; return 0 on success, -1 on error. */
int init_cm_hal_init(void)
{
    if (cm_hal_InitDB() != RETURN_OK)
    {
        UT_LOG_ERROR("cm_hal_InitDB initialization failed");
        return -1;
    }
    return 0;
}

/* PUBLIC_INTERFACE */
/**
 * Initialize, register and execute component tests using ut-core CLI arguments.
 * argc/argv are forwarded unchanged. Return EXIT_FAILURE on initialization,
 * registration, execution, suite setup/cleanup, assertion or empty-run failure;
 * otherwise return EXIT_SUCCESS.
 */
int main(int argc, char **argv)
{
    UT_status_t status;

    if (UT_init(argc, argv) != UT_STATUS_OK)
    {
        fprintf(stderr, "cm_hal_test: framework initialization failed\n");
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }

    /* Disabling a group is a selection, not a failed suite. */
    CU_set_fail_on_inactive(CU_FALSE);

    if (register_hal_l1_tests() != 0 || registration_failed ||
        CU_get_error() != CUE_SUCCESS)
    {
        fprintf(stderr, "cm_hal_test: test registration failed\n");
        CU_cleanup_registry();
        UT_exit();
        return EXIT_FAILURE;
    }

    capture_results = true;
    status = UT_run_tests();
    capture_results = false;
    /* UT_exit is idempotent; also close the profile on runner error paths. */
    UT_exit();

    if (status != UT_STATUS_OK || !results_captured || execution_failed ||
        tests_run == 0)
    {
        fprintf(stderr, "cm_hal_test: run failed (tests executed: %u)\n", tests_run);
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
