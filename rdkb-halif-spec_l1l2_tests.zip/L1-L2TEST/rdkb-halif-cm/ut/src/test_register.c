/*
* If not stated otherwise in this file or this component's LICENSE file the
* following copyright and licenses apply:*
* Copyright 2023 RDK Management
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include <ut.h>

/* Component suite registrars; retain the legacy entrypoint name used by main. */
extern int test_cm_hal_register(void);
extern int test_cm_hal_l2_register(void);

/* PUBLIC_INTERFACE */
/** Register component L1/L2 tests; return 0 only for a nonempty, valid registry. */
int register_hal_l1_tests(void)
{
    if (test_cm_hal_register() != 0 || CU_get_error() != CUE_SUCCESS)
    {
        return -1;
    }

    if (test_cm_hal_l2_register() != 0 || CU_get_error() != CUE_SUCCESS)
    {
        return -1;
    }

    if (CU_get_registry() == NULL || CU_get_registry()->uiNumberOfTests == 0)
    {
        return -1;
    }
    return 0;
}
