/*
 * Copyright 2024 RDK Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file test_l1_cm_hal.c
 * @brief CM HAL L1 function-contract tests.
 *
 * Contract: include/cm_hal.h and docs/pages/CMhalSpec.md.
 * The upstream case names and IDs 001..122 are retained. Each Linux case
 * starts with independent reference fixtures; stateful sequences belong to L2.
 * Snapshot getters allocate memory that these tests free. Codeword and CPE
 * getters instead receive caller-owned storage. No ABI padding/word-size or
 * ambiguous legacy frequency-string unit assumptions are made.
 *
 * Successful download/reboot/update requests are registered only for the Linux
 * simulation: running conformance tests must not download/reboot a real DUT.
 */
#include <ut.h>
#include <ut_log.h>
#include <ut_kvp_profile.h>

#include <limits.h>
#include <stdlib.h>
#include <string.h>

#include "cm_hal.h"
#ifdef BUILD_LINUX
#include "cm_hal_test_control.h"
#endif

#define MAX_STRING_LENGTH 250
#define ARRAY_COUNT(a) (sizeof(a) / sizeof((a)[0]))

/*
 * Only array destinations are passed to this macro. The framework convenience
 * getter always supplies 256, which overflows MAX_STRING_LENGTH-sized arrays.
 * Record missing/oversized profile values and return from the current void
 * test/helper before using them; always terminate even on a failed retrieval.
 */
#define READ_PROFILE(key, destination) do { \
    ut_kvp_status_t profile_status = ut_kvp_getStringField( \
        ut_kvp_profile_getInstance(), (key), (destination), sizeof(destination)); \
    (destination)[sizeof(destination) - 1] = '\0'; \
    UT_ASSERT_EQUAL(profile_status, UT_KVP_STATUS_SUCCESS); \
    if (profile_status != UT_KVP_STATUS_SUCCESS) { return; } \
} while (0)

#define CHECK_TEXT(array) \
    UT_ASSERT_TRUE(memchr((array), '\0', sizeof(array)) != NULL)

/** Start an independent L1 case, without changing vendor HAL initialization. */
static void begin_case(unsigned int id)
{
#ifdef BUILD_LINUX
    cm_hal_test_reset();
#endif
    UT_LOG_INFO("L1 cm_hal [01%03u]", id);
}

/** Reset reference-only pending work and callbacks when the suite finishes. */
static int finish_suite(void)
{
#ifdef BUILD_LINUX
    cm_hal_test_reset();
#endif
    return 0;
}

/** Configure valid profile inputs; propagate prerequisite failure to the test. */
static int configure_http(void)
{
    char url[MAX_STRING_LENGTH] = {0};
    char filename[MAX_STRING_LENGTH] = {0};
    ut_kvp_status_t url_status = ut_kvp_getStringField(
        ut_kvp_profile_getInstance(), "cm.config.HttpUrl", url, sizeof(url));
    ut_kvp_status_t file_status = ut_kvp_getStringField(
        ut_kvp_profile_getInstance(), "cm.config.filename", filename, sizeof(filename));
    url[sizeof(url) - 1] = '\0';
    filename[sizeof(filename) - 1] = '\0';
    UT_ASSERT_EQUAL(url_status, UT_KVP_STATUS_SUCCESS);
    UT_ASSERT_EQUAL(file_status, UT_KVP_STATUS_SUCCESS);
    if (url_status != UT_KVP_STATUS_SUCCESS ||
        file_status != UT_KVP_STATUS_SUCCESS)
    {
        return RETURN_ERR;
    }
    int status = cm_hal_Set_HTTP_Download_Url(url, filename);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    return status;
}

/** Validate fixed US string fields without assuming MHz versus Hz encoding. */
static void check_us(const CMMGMT_CM_US_CHANNEL *info)
{
    CHECK_TEXT(info->Frequency);
    CHECK_TEXT(info->PowerLevel);
    CHECK_TEXT(info->ChannelType);
    CHECK_TEXT(info->SymbolRate);
    CHECK_TEXT(info->Modulation);
    CHECK_TEXT(info->LockStatus);
}

/* PUBLIC_INTERFACE */
/** Case 001: database initialization succeeds. */
void test_l1_cm_hal_positive1_cm_hal_InitDB(void)
{
    begin_case(1);
    UT_ASSERT_EQUAL(cm_hal_InitDB(), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 002: downstream initialization succeeds. */
void test_l1_cm_hal_positive1_docsis_InitDS(void)
{
    begin_case(2);
    UT_ASSERT_EQUAL(docsis_InitDS(), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 003: upstream initialization succeeds. */
void test_l1_cm_hal_positive1_docsis_InitUS(void)
{
    begin_case(3);
    UT_ASSERT_EQUAL(docsis_InitUS(), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 004: status fits the documented 40-byte caller buffer. */
void test_l1_cm_hal_positive1_docsis_getCMStatus(void)
{
    char status[40] = {0};
    begin_case(4);
    UT_ASSERT_EQUAL(docsis_getCMStatus(status), RETURN_OK);
    CHECK_TEXT(status);
}

/* PUBLIC_INTERFACE */
/** Case 005: reject a NULL status buffer. */
void test_l1_cm_hal_negative1_docsis_getCMStatus(void)
{
    begin_case(5);
    UT_ASSERT_EQUAL(docsis_getCMStatus(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 006: retrieve and free a downstream snapshot, validating text fields. */
void test_l1_cm_hal_positive1_docsis_GetDSChannel(void)
{
    PCMMGMT_CM_DS_CHANNEL info = NULL;
    begin_case(6);
    int status = docsis_GetDSChannel(&info);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    /* A modem with no channels may legitimately have an empty snapshot. */
    if (status == RETURN_OK && info != NULL)
    {
        CHECK_TEXT(info->Frequency);
        CHECK_TEXT(info->PowerLevel);
        CHECK_TEXT(info->SNRLevel);
        CHECK_TEXT(info->Modulation);
        CHECK_TEXT(info->LockStatus);
    }
    free(info);
}

/* PUBLIC_INTERFACE */
/** Case 007: reject a NULL downstream output pointer. */
void test_l1_cm_hal_negative1_docsis_GetDSChannel(void)
{
    begin_case(7);
    UT_ASSERT_EQUAL(docsis_GetDSChannel(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 008: fill initialized caller-owned US storage at zero-based index 0. */
void test_l1_cm_hal_positive1_docsis_GetUsStatus(void)
{
    CMMGMT_CM_US_CHANNEL storage = {0};
    PCMMGMT_CM_US_CHANNEL info = &storage;
    begin_case(8);
    int status = docsis_GetUsStatus(0, info);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    if (status == RETURN_OK)
    {
        check_us(info);
    }
}

/* PUBLIC_INTERFACE */
/** Case 009: reject a NULL caller-owned US status output. */
void test_l1_cm_hal_negative1_docsis_GetUsStatus(void)
{
    begin_case(9);
    UT_ASSERT_EQUAL(docsis_GetUsStatus(0, NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 010: retrieve and free an upstream snapshot. */
void test_l1_cm_hal_positive1_docsis_GetUSChannel(void)
{
    PCMMGMT_CM_US_CHANNEL info = NULL;
    begin_case(10);
    int status = docsis_GetUSChannel(&info);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    if (status == RETURN_OK && info != NULL)
    {
        check_us(info);
    }
    free(info);
}

/* PUBLIC_INTERFACE */
/** Case 011: reject a NULL upstream output pointer. */
void test_l1_cm_hal_negative1_docsis_GetUSChannel(void)
{
    begin_case(11);
    UT_ASSERT_EQUAL(docsis_GetUSChannel(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 012: fill caller-owned DOCSIS information and validate its strings/flags. */
void test_l1_cm_hal_positive1_docsis_GetDOCSISInfo(void)
{
    CMMGMT_CM_DOCSIS_INFO storage = {0};
    PCMMGMT_CM_DOCSIS_INFO info = &storage;
    begin_case(12);
    int status = docsis_GetDOCSISInfo(info);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    if (status != RETURN_OK)
    {
        return;
    }
    CHECK_TEXT(info->DOCSISVersion);
    CHECK_TEXT(info->DOCSISDownstreamScanning);
    CHECK_TEXT(info->DOCSISDownstreamRanging);
    CHECK_TEXT(info->DOCSISUpstreamScanning);
    CHECK_TEXT(info->DOCSISUpstreamRanging);
    CHECK_TEXT(info->DOCSISTftpStatus);
    CHECK_TEXT(info->DOCSISDataRegComplete);
    CHECK_TEXT(info->DOCSISConfigFileName);
    CHECK_TEXT(info->ToDStatus);
    CHECK_TEXT(info->UpstreamServiceFlowParams);
    CHECK_TEXT(info->DownstreamServiceFlowParams);
    CHECK_TEXT(info->DOCSISDownstreamDataRate);
    CHECK_TEXT(info->DOCSISUpstreamDataRate);
    CHECK_TEXT(info->CoreVersion);
    UT_ASSERT_TRUE(info->BPIState == TRUE || info->BPIState == FALSE);
    UT_ASSERT_TRUE(info->NetworkAccess == TRUE || info->NetworkAccess == FALSE);
    UT_LOG_DEBUG("DHCP attempts=%lu, TFTP attempts=%lu, max CPE=%lu",
                 info->DOCSISDHCPAttempts, info->DOCSISTftpAttempts, info->MaxCpeAllowed);
}

/* PUBLIC_INTERFACE */
/** Case 013: reject a NULL DOCSIS information output. */
void test_l1_cm_hal_negative1_docsis_GetDOCSISInfo(void)
{
    begin_case(13);
    UT_ASSERT_EQUAL(docsis_GetDOCSISInfo(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 014: retrieve an unsigned active upstream count (zero is legal). */
void test_l1_cm_hal_positive1_docsis_GetNumOfActiveTxChannels(void)
{
    ULONG count = 0;
    begin_case(14);
    UT_ASSERT_EQUAL(docsis_GetNumOfActiveTxChannels(&count), RETURN_OK);
    UT_LOG_DEBUG("Active upstream channels: %lu", count);
}

/* PUBLIC_INTERFACE */
/** Case 015: reject a NULL upstream count. */
void test_l1_cm_hal_negative1_docsis_GetNumOfActiveTxChannels(void)
{
    begin_case(15);
    UT_ASSERT_EQUAL(docsis_GetNumOfActiveTxChannels(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 016: retrieve an unsigned active downstream count (zero is legal). */
void test_l1_cm_hal_positive1_docsis_GetNumOfActiveRxChannels(void)
{
    ULONG count = 0;
    begin_case(16);
    UT_ASSERT_EQUAL(docsis_GetNumOfActiveRxChannels(&count), RETURN_OK);
    UT_LOG_DEBUG("Active downstream channels: %lu", count);
}

/* PUBLIC_INTERFACE */
/** Case 017: reject a NULL downstream count. */
void test_l1_cm_hal_negative1_docsis_GetNumOfActiveRxChannels(void)
{
    begin_case(17);
    UT_ASSERT_EQUAL(docsis_GetNumOfActiveRxChannels(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 018: codeword output uses, and does not replace, caller-owned storage. */
void test_l1_cm_hal_positive1_docsis_GetErrorCodewords(void)
{
    CMMGMT_CM_ERROR_CODEWORDS storage = {0};
    PCMMGMT_CM_ERROR_CODEWORDS info = &storage;
    begin_case(18);
    UT_ASSERT_EQUAL(docsis_GetErrorCodewords(&info), RETURN_OK);
    UT_ASSERT_PTR_EQUAL(info, &storage);
    UT_LOG_DEBUG("Codewords: %lu/%lu/%lu", storage.UnerroredCodewords,
                 storage.CorrectableCodewords, storage.UncorrectableCodewords);
}

/* PUBLIC_INTERFACE */
/** Case 019: reject NULL outer and inner codeword pointers. */
void test_l1_cm_hal_negative1_docsis_GetErrorCodewords(void)
{
    PCMMGMT_CM_ERROR_CODEWORDS info = NULL;
    begin_case(19);
    UT_ASSERT_EQUAL(docsis_GetErrorCodewords(NULL), RETURN_ERR);
    UT_ASSERT_EQUAL(docsis_GetErrorCodewords(&info), RETURN_ERR);
}

/** Check a bounded provisioning-mode result without imposing a configured value. */
static void check_mdd(char *value, size_t capacity)
{
    int status = docsis_GetMddIpModeOverride(value);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    UT_ASSERT_TRUE(memchr(value, '\0', capacity) != NULL);
    if (status == RETURN_OK && memchr(value, '\0', capacity) != NULL)
    {
        UT_ASSERT_TRUE(strcmp(value, "ipv4Only") == 0 ||
                       strcmp(value, "ipv6Only") == 0 ||
                       strcmp(value, "honorMdd") == 0);
    }
}

/* PUBLIC_INTERFACE */
/** Case 020: retrieve MDD mode into the documented 64-byte buffer. */
void test_l1_cm_hal_positive1_docsis_GetMddIpModeOverride(void)
{
    char value[64] = {0};
    begin_case(20);
    check_mdd(value, sizeof(value));
}

/* PUBLIC_INTERFACE */
/** Case 021: reject a NULL MDD buffer. */
void test_l1_cm_hal_negative1_docsis_GetMddIpModeOverride(void)
{
    begin_case(21);
    UT_ASSERT_EQUAL(docsis_GetMddIpModeOverride(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 022: retrieving MDD mode also works with a larger buffer. */
void test_l1_cm_hal_positive2_docsis_GetMddIpModeOverride(void)
{
    char value[128] = {0};
    begin_case(22);
    check_mdd(value, sizeof(value));
}

/* PUBLIC_INTERFACE */
/** Case 023: accept ipv4Only. */
void test_l1_cm_hal_positive1_docsis_SetMddIpModeOverride(void)
{
    begin_case(23);
    UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride("ipv4Only"), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 024: accept ipv6Only. */
void test_l1_cm_hal_positive2_docsis_SetMddIpModeOverride(void)
{
    begin_case(24);
    UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride("ipv6Only"), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 025: accept honorMdd. */
void test_l1_cm_hal_positive3_docsis_SetMddIpModeOverride(void)
{
    begin_case(25);
    UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride("honorMdd"), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 026: accept an empty override to clear it. */
void test_l1_cm_hal_positive4_docsis_SetMddIpModeOverride(void)
{
    begin_case(26);
    UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride(""), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 027: APM is not a valid setter value. */
void test_l1_cm_hal_negative1_docsis_SetMddIpModeOverride(void)
{
    begin_case(27);
    UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride("APM"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 028: DualStack is not a valid setter value. */
void test_l1_cm_hal_negative2_docsis_SetMddIpModeOverride(void)
{
    begin_case(28);
    UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride("DualStack"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 029: reject a NULL override. */
void test_l1_cm_hal_negative3_docsis_SetMddIpModeOverride(void)
{
    begin_case(29);
    UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 030: reject an unknown override. */
void test_l1_cm_hal_negative4_docsis_SetMddIpModeOverride(void)
{
    begin_case(30);
    UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride("invalid"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 031: reject special characters in an override. */
void test_l1_cm_hal_negative5_docsis_SetMddIpModeOverride(void)
{
    begin_case(31);
    UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride("@#%"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 032: reject a numeric override. */
void test_l1_cm_hal_negative6_docsis_SetMddIpModeOverride(void)
{
    begin_case(32);
    UT_ASSERT_EQUAL(docsis_SetMddIpModeOverride("1234"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 033: exercise the value-returning channel getter; UINT8 defines its range. */
void test_l1_cm_hal_positive1_docsis_GetUSChannelId(void)
{
    begin_case(33);
    UINT8 value = docsis_GetUSChannelId();
    UT_LOG_DEBUG("Upstream channel ID: %u", (unsigned int)value);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(value, 1);
#endif
}

/* PUBLIC_INTERFACE */
/** Case 034: exercise invalid input to the void setter, with model preservation. */
void test_l1_cm_hal_negative1_docsis_SetUSChannelId(void)
{
    begin_case(34);
#ifdef BUILD_LINUX
    UINT8 previous = docsis_GetUSChannelId();
#endif
    docsis_SetUSChannelId(-1);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(docsis_GetUSChannelId(), previous);
#endif
}

/* PUBLIC_INTERFACE */
/** Case 035: exercise a valid upstream ID preference. */
void test_l1_cm_hal_positive1_docsis_SetUSChannelId(void)
{
    begin_case(35);
    docsis_SetUSChannelId(10);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(docsis_GetUSChannelId(), 10);
#endif
}

/* PUBLIC_INTERFACE */
/** Case 036: exercise the Hz-valued frequency getter without unsigned tautologies. */
void test_l1_cm_hal_positive1_docsis_GetDownFreq(void)
{
    begin_case(36);
    ULONG value = docsis_GetDownFreq();
    UT_LOG_DEBUG("Downstream frequency (Hz): %lu", value);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(value, 600000000UL);
#endif
}

/* PUBLIC_INTERFACE */
/** Case 037: exercise a downstream frequency preference in Hz. */
void test_l1_cm_hal_positive1_docsis_SetStartFreq(void)
{
    begin_case(37);
    docsis_SetStartFreq(606000000UL);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(docsis_GetDownFreq(), 606000000UL);
#endif
}

/* PUBLIC_INTERFACE */
/** Case 038: exercise zero as a cleared start-frequency preference. */
void test_l1_cm_hal_positive2_docsis_SetStartFreq(void)
{
    begin_case(38);
    docsis_SetStartFreq(0);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(docsis_GetDownFreq(), 0);
#endif
}

/** Validate only rows actually returned, and never index beyond caller capacity. */
static void check_events(int capacity)
{
    CMMGMT_CM_EventLogEntry_t entries[10] = {0};
    int count = docsis_GetDocsisEventLogItems(entries, capacity);
    UT_ASSERT_TRUE(count >= 0 && count <= capacity);
    if (count < 0 || count > capacity)
    {
        return;
    }
    for (int i = 0; i < count; ++i)
    {
        UT_ASSERT_TRUE(entries[i].docsDevEvLevel <= 255);
        CHECK_TEXT(entries[i].docsDevEvText);
        UT_LOG_DEBUG("Event %u level %u: %.*s", entries[i].docsDevEvId,
                     entries[i].docsDevEvLevel, EVM_MAX_EVENT_TEXT,
                     entries[i].docsDevEvText);
    }
}

/* PUBLIC_INTERFACE */
/** Case 039: retrieve a bounded ten-entry event array. */
void test_l1_cm_hal_positive1_docsis_GetDocsisEventLogItems(void)
{
    begin_case(39);
    check_events(10);
}

/* PUBLIC_INTERFACE */
/** Case 040: retrieve a bounded one-entry event subset. */
void test_l1_cm_hal_positive2_docsis_GetDocsisEventLogItems(void)
{
    begin_case(40);
    check_events(1);
}

/* PUBLIC_INTERFACE */
/** Case 041: reject a NULL event output. */
void test_l1_cm_hal_negative1_docsis_GetDocsisEventLogItems(void)
{
    begin_case(41);
    UT_ASSERT_EQUAL(docsis_GetDocsisEventLogItems(NULL, 10), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 042: reject a negative event capacity. */
void test_l1_cm_hal_negative2_docsis_GetDocsisEventLogItems(void)
{
    CMMGMT_CM_EventLogEntry_t entries[1] = {0};
    begin_case(42);
    UT_ASSERT_EQUAL(docsis_GetDocsisEventLogItems(entries, -10), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 043: accept asynchronous log-clear scheduling without expecting completion. */
void test_l1_cm_hal_positive1_docsis_ClearDocsisEventLog(void)
{
    begin_case(43);
    UT_ASSERT_EQUAL(docsis_ClearDocsisEventLog(), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 044: fill initialized caller-owned IPv4 DHCP storage. */
void test_l1_cm_hal_positive1_GetDHCPInfo(void)
{
    CMMGMT_CM_DHCP_INFO storage = {0};
    PCMMGMT_CM_DHCP_INFO info = &storage;
    begin_case(44);
    int status = cm_hal_GetDHCPInfo(info);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    if (status != RETURN_OK)
    {
        return;
    }
    CHECK_TEXT(info->BootFileName);
    CHECK_TEXT(info->TimeServer);
    CHECK_TEXT(info->RebindTimeRemaining);
    CHECK_TEXT(info->RenewTimeRemaining);
    CHECK_TEXT(info->MACAddress);
    CHECK_TEXT(info->DOCSISDHCPStatus);
}

/* PUBLIC_INTERFACE */
/** Case 045: reject a NULL DHCP output. */
void test_l1_cm_hal_negative1_GetDHCPInfo(void)
{
    begin_case(45);
    UT_ASSERT_EQUAL(cm_hal_GetDHCPInfo(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 046: fill initialized caller-owned IPv6 DHCP storage. */
void test_l1_cm_hal_positive1_GetIPv6DHCPInfo(void)
{
    CMMGMT_CM_IPV6DHCP_INFO storage = {0};
    PCMMGMT_CM_IPV6DHCP_INFO info = &storage;
    begin_case(46);
    int status = cm_hal_GetIPv6DHCPInfo(info);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    if (status != RETURN_OK)
    {
        return;
    }
    CHECK_TEXT(info->IPv6Address);
    CHECK_TEXT(info->IPv6BootFileName);
    CHECK_TEXT(info->IPv6Prefix);
    CHECK_TEXT(info->IPv6Router);
    CHECK_TEXT(info->IPv6TFTPServer);
    CHECK_TEXT(info->IPv6TimeServer);
}

/* PUBLIC_INTERFACE */
/** Case 047: reject a NULL IPv6 DHCP output. */
void test_l1_cm_hal_negative1_GetIPv6DHCPInfo(void)
{
    begin_case(47);
    UT_ASSERT_EQUAL(cm_hal_GetIPv6DHCPInfo(NULL), RETURN_ERR);
}

/**
 * Supply real inner storage as required by cm_hal.h. The API has no capacity
 * parameter; reserve its documented typical maximum CPE count (255), rather
 * than allocating only an uninitialized outer pointer as the upstream did.
 */
static void check_cpe(char *mode)
{
    CMMGMT_DML_CPE_LIST storage[255] = {0};
    PCMMGMT_DML_CPE_LIST info = storage;
    ULONG count = 0;
    int status = cm_hal_GetCPEList(&info, &count, mode);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    UT_ASSERT_PTR_EQUAL(info, storage);
    UT_ASSERT_TRUE(count <= ARRAY_COUNT(storage));
    if (status != RETURN_OK || info != storage || count > ARRAY_COUNT(storage))
    {
        return;
    }
    for (ULONG i = 0; i < count; ++i)
    {
        CHECK_TEXT(storage[i].IPAddress);
        CHECK_TEXT(storage[i].MACAddress);
    }
}

/* PUBLIC_INTERFACE */
/** Case 048: retrieve router-mode CPEs into caller-owned storage. */
void test_l1_cm_hal_positive1_GetCPEList(void)
{
    begin_case(48);
    check_cpe("router");
}

/* PUBLIC_INTERFACE */
/** Case 049: retrieve bridge-mode CPEs into caller-owned storage. */
void test_l1_cm_hal_positive2_GetCPEList(void)
{
    begin_case(49);
    check_cpe("bridge");
}

/* PUBLIC_INTERFACE */
/** Case 050: reject NULL outer and inner CPE outputs. */
void test_l1_cm_hal_negative1_GetCPEList(void)
{
    ULONG count = 0;
    PCMMGMT_DML_CPE_LIST info = NULL;
    begin_case(50);
    UT_ASSERT_EQUAL(cm_hal_GetCPEList(NULL, &count, "router"), RETURN_ERR);
    UT_ASSERT_EQUAL(cm_hal_GetCPEList(&info, &count, "router"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 051: reject a NULL CPE count with valid inner storage. */
void test_l1_cm_hal_negative2_GetCPEList(void)
{
    CMMGMT_DML_CPE_LIST storage = {0};
    PCMMGMT_DML_CPE_LIST info = &storage;
    begin_case(51);
    UT_ASSERT_EQUAL(cm_hal_GetCPEList(&info, NULL, "router"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 052: reject a NULL CPE LAN mode with valid inner storage. */
void test_l1_cm_hal_negative3_GetCPEList(void)
{
    CMMGMT_DML_CPE_LIST storage = {0};
    PCMMGMT_DML_CPE_LIST info = &storage;
    ULONG count = 0;
    begin_case(52);
    UT_ASSERT_EQUAL(cm_hal_GetCPEList(&info, &count, NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 053: reject an empty CPE LAN mode. */
void test_l1_cm_hal_negative4_GetCPEList(void)
{
    CMMGMT_DML_CPE_LIST storage = {0};
    PCMMGMT_DML_CPE_LIST info = &storage;
    ULONG count = 0;
    begin_case(53);
    UT_ASSERT_EQUAL(cm_hal_GetCPEList(&info, &count, ""), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 054: reject an unknown CPE LAN mode. */
void test_l1_cm_hal_negative5_GetCPEList(void)
{
    CMMGMT_DML_CPE_LIST storage = {0};
    PCMMGMT_DML_CPE_LIST info = &storage;
    ULONG count = 0;
    begin_case(54);
    UT_ASSERT_EQUAL(cm_hal_GetCPEList(&info, &count, "invalid"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 055: retrieve market into the documented 100-byte buffer. */
void test_l1_cm_hal_positive1_GetMarket(void)
{
    char market[100] = {0};
    begin_case(55);
    UT_ASSERT_EQUAL(cm_hal_GetMarket(market), RETURN_OK);
    CHECK_TEXT(market);
}

/* PUBLIC_INTERFACE */
/** Case 056: reject a NULL market buffer. */
void test_l1_cm_hal_negative1_GetMarket(void)
{
    begin_case(56);
    UT_ASSERT_EQUAL(cm_hal_GetMarket(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 057: retrieve market into a larger caller buffer. */
void test_l1_cm_hal_positive2_GetMarket(void)
{
    char market[200] = {0};
    begin_case(57);
    UT_ASSERT_EQUAL(cm_hal_GetMarket(market), RETURN_OK);
    CHECK_TEXT(market);
}

/* PUBLIC_INTERFACE */
/** Case 058: configure nonempty, bounded HTTP fixtures from the profile. */
void test_l1_cm_hal_positive1_Set_HTTP_Download_Url(void)
{
    begin_case(58);
    UT_ASSERT_EQUAL(configure_http(), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 059: reject a NULL download filename with an otherwise valid URL. */
void test_l1_cm_hal_negative1_Set_HTTP_Download_Url(void)
{
    char url[MAX_STRING_LENGTH] = {0};
    begin_case(59);
    READ_PROFILE("cm.config.HttpUrl", url);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Url(url, NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 060: reject a NULL download URL with an otherwise valid filename. */
void test_l1_cm_hal_negative2_Set_HTTP_Download_Url(void)
{
    char filename[MAX_STRING_LENGTH] = {0};
    begin_case(60);
    READ_PROFILE("cm.config.filename", filename);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Url(NULL, filename), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 061: reject an empty download URL. */
void test_l1_cm_hal_negative3_Set_HTTP_Download_Url(void)
{
    char filename[MAX_STRING_LENGTH] = {0};
    begin_case(61);
    READ_PROFILE("cm.config.filename", filename);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Url("", filename), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 062: reject an empty download filename. */
void test_l1_cm_hal_negative4_Set_HTTP_Download_Url(void)
{
    char url[MAX_STRING_LENGTH] = {0};
    begin_case(62);
    READ_PROFILE("cm.config.HttpUrl", url);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Url(url, ""), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 063: reject a download filename containing unsafe special characters. */
void test_l1_cm_hal_negative5_Set_HTTP_Download_Url(void)
{
    char url[MAX_STRING_LENGTH] = {0};
    begin_case(63);
    READ_PROFILE("cm.config.HttpUrl", url);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Url(url, "Invalid Image@#"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 064: reject an invalid download URL. */
void test_l1_cm_hal_negative6_Set_HTTP_Download_Url(void)
{
    char filename[MAX_STRING_LENGTH] = {0};
    begin_case(64);
    READ_PROFILE("cm.config.filename", filename);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Url("Invalid URL@#", filename), RETURN_ERR);
}

/** Configure this case's prerequisites and check bounded nonempty getter output. */
static void check_http(char *url, size_t url_capacity, char *filename, size_t file_capacity)
{
    if (configure_http() != RETURN_OK)
    {
        return;
    }
    int status = cm_hal_Get_HTTP_Download_Url(url, filename);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    if (status != RETURN_OK)
    {
        return;
    }
    UT_ASSERT_TRUE(memchr(url, '\0', url_capacity) != NULL);
    UT_ASSERT_TRUE(memchr(filename, '\0', file_capacity) != NULL);
    UT_ASSERT_TRUE(url[0] != '\0');
    UT_ASSERT_TRUE(filename[0] != '\0');
}

/* PUBLIC_INTERFACE */
/** Case 065: retrieve download settings using documented 200-byte buffers. */
void test_l1_cm_hal_positive1_Get_HTTP_Download_Url(void)
{
    char url[200] = {0};
    char filename[200] = {0};
    begin_case(65);
    check_http(url, sizeof(url), filename, sizeof(filename));
}

/* PUBLIC_INTERFACE */
/** Case 066: reject a NULL download URL output. */
void test_l1_cm_hal_negative1_Get_HTTP_Download_Url(void)
{
    char filename[200] = {0};
    begin_case(66);
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Url(NULL, filename), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 067: reject a NULL download filename output. */
void test_l1_cm_hal_negative2_Get_HTTP_Download_Url(void)
{
    char url[200] = {0};
    begin_case(67);
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Url(url, NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 068: retrieve download settings using larger buffers. */
void test_l1_cm_hal_positive2_Get_HTTP_Download_Url(void)
{
    char url[300] = {0};
    char filename[300] = {0};
    begin_case(68);
    check_http(url, sizeof(url), filename, sizeof(filename));
}

/* PUBLIC_INTERFACE */
/** Case 069: accept wan0 interface selection. */
void test_l1_cm_hal_positive1_Set_HTTP_Download_Interface(void)
{
    begin_case(69);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Interface(0), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 070: accept erouter0 interface selection. */
void test_l1_cm_hal_positive2_Set_HTTP_Download_Interface(void)
{
    begin_case(70);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Interface(1), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 071: reject an unknown interface selection. */
void test_l1_cm_hal_negative1_Set_HTTP_Download_Interface(void)
{
    begin_case(71);
    UT_ASSERT_EQUAL(cm_hal_Set_HTTP_Download_Interface(2), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 072: retrieve a documented interface value. */
void test_l1_cm_hal_positive1_Get_HTTP_Download_Interface(void)
{
    unsigned int value = UINT_MAX;
    begin_case(72);
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Interface(&value), RETURN_OK);
    UT_ASSERT_TRUE(value == 0 || value == 1);
}

/* PUBLIC_INTERFACE */
/** Case 073: reject a NULL interface output. */
void test_l1_cm_hal_negative1_Get_HTTP_Download_Interface(void)
{
    begin_case(73);
    UT_ASSERT_EQUAL(cm_hal_Get_HTTP_Download_Interface(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 074: download status belongs to its documented progress/error domain. */
void test_l1_cm_hal_positive1_Get_HTTP_Download_Status(void)
{
    begin_case(74);
    int status = cm_hal_Get_HTTP_Download_Status();
    UT_ASSERT_TRUE((status >= 0 && status <= 100) ||
                   (status >= 400 && status <= 407) || status == 500);
#ifdef BUILD_LINUX
    UT_ASSERT_EQUAL(status, 0);
#endif
}

/* PUBLIC_INTERFACE */
/** Case 075: retrieve one of the two documented reboot-readiness states. */
void test_l1_cm_hal_positive1_Reboot_Ready(void)
{
    ULONG value = 0;
    begin_case(75);
    UT_ASSERT_EQUAL(cm_hal_Reboot_Ready(&value), RETURN_OK);
    UT_ASSERT_TRUE(value == 1 || value == 2);
}

/* PUBLIC_INTERFACE */
/** Case 076: reject a NULL readiness output. */
void test_l1_cm_hal_negative1_Reboot_Ready(void)
{
    begin_case(76);
    UT_ASSERT_EQUAL(cm_hal_Reboot_Ready(NULL), RETURN_ERR);
}

#ifdef BUILD_LINUX
/* PUBLIC_INTERFACE */
/** Case 077: accept a simulated reboot only after preparing a completed download. */
void test_l1_cm_hal_positive1_HTTP_Download_Reboot_Now(void)
{
    begin_case(77);
    if (configure_http() != RETURN_OK)
    {
        return;
    }
    int status = cm_hal_HTTP_Download();
    UT_ASSERT_EQUAL(status, RETURN_OK);
    if (status != RETURN_OK)
    {
        return;
    }
    status = cm_hal_test_advance_download(100);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    if (status == RETURN_OK)
    {
        UT_ASSERT_EQUAL(cm_hal_HTTP_Download_Reboot_Now(), RETURN_OK);
    }
}
#endif

/* PUBLIC_INTERFACE */
/** Case 078: reject a special-character firmware image filename. */
void test_l1_cm_hal_negative1_FWupdateAndFactoryReset(void)
{
    char url[MAX_STRING_LENGTH] = {0};
    begin_case(78);
    READ_PROFILE("cm.config.HttpUrl", url);
    UT_ASSERT_EQUAL(cm_hal_FWupdateAndFactoryReset(url, "Invalid#Image@Name"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 079: reject a NULL firmware URL. */
void test_l1_cm_hal_negative2_FWupdateAndFactoryReset(void)
{
    char filename[MAX_STRING_LENGTH] = {0};
    begin_case(79);
    READ_PROFILE("cm.config.filename", filename);
    UT_ASSERT_EQUAL(cm_hal_FWupdateAndFactoryReset(NULL, filename), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 080: reject a NULL firmware filename. */
void test_l1_cm_hal_negative3_FWupdateAndFactoryReset(void)
{
    char url[MAX_STRING_LENGTH] = {0};
    begin_case(80);
    READ_PROFILE("cm.config.HttpUrl", url);
    UT_ASSERT_EQUAL(cm_hal_FWupdateAndFactoryReset(url, NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 081: reject an empty firmware URL. */
void test_l1_cm_hal_negative4_FWupdateAndFactoryReset(void)
{
    char filename[MAX_STRING_LENGTH] = {0};
    begin_case(81);
    READ_PROFILE("cm.config.filename", filename);
    UT_ASSERT_EQUAL(cm_hal_FWupdateAndFactoryReset("", filename), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 082: reject an empty firmware filename. */
void test_l1_cm_hal_negative5_FWupdateAndFactoryReset(void)
{
    char url[MAX_STRING_LENGTH] = {0};
    begin_case(82);
    READ_PROFILE("cm.config.HttpUrl", url);
    UT_ASSERT_EQUAL(cm_hal_FWupdateAndFactoryReset(url, ""), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 083: reject a malformed firmware URL. */
void test_l1_cm_hal_negative6_FWupdateAndFactoryReset(void)
{
    char filename[MAX_STRING_LENGTH] = {0};
    begin_case(83);
    READ_PROFILE("cm.config.filename", filename);
    UT_ASSERT_EQUAL(cm_hal_FWupdateAndFactoryReset("invalid_url", filename), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/**
 * Case 084: reject a path-traversing image name. The upstream "InvalidImageName"
 * was a valid filename: the HAL does not require a particular file extension.
 */
void test_l1_cm_hal_negative7_FWupdateAndFactoryReset(void)
{
    char url[MAX_STRING_LENGTH] = {0};
    begin_case(84);
    READ_PROFILE("cm.config.HttpUrl", url);
    UT_ASSERT_EQUAL(cm_hal_FWupdateAndFactoryReset(url, "../InvalidImageName"), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 085: accept MAC reinitialization. */
void test_l1_cm_hal_positive1_ReinitMac(void)
{
    begin_case(85);
    UT_ASSERT_EQUAL(cm_hal_ReinitMac(), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 086: retrieve bounded provisioning type text. */
void test_l1_cm_hal_positive1_docsis_GetProvIpType(void)
{
    char value[32] = {0};
    begin_case(86);
    UT_ASSERT_EQUAL(docsis_GetProvIpType(value), RETURN_OK);
    CHECK_TEXT(value);
}

/* PUBLIC_INTERFACE */
/** Case 087: reject a NULL provisioning type output. */
void test_l1_cm_hal_negative1_docsis_GetProvIpType(void)
{
    begin_case(87);
    UT_ASSERT_EQUAL(docsis_GetProvIpType(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 088: retrieve a bounded certificate path. */
void test_l1_cm_hal_positive1_docsis_GetCert(void)
{
    char path[256] = {0};
    begin_case(88);
    UT_ASSERT_EQUAL(docsis_GetCert(path), RETURN_OK);
    CHECK_TEXT(path);
}

/* PUBLIC_INTERFACE */
/** Case 089: reject a NULL certificate output. */
void test_l1_cm_hal_negative1_docsis_GetCert(void)
{
    begin_case(89);
    UT_ASSERT_EQUAL(docsis_GetCert(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 090: certificate status is enabled or disabled. */
void test_l1_cm_hal_positive1_docsis_GetCertStatus(void)
{
    ULONG value = ULONG_MAX;
    begin_case(90);
    UT_ASSERT_EQUAL(docsis_GetCertStatus(&value), RETURN_OK);
    UT_ASSERT_TRUE(value == ENABLE || value == DISABLE);
}

/* PUBLIC_INTERFACE */
/** Case 091: reject a NULL certificate status output. */
void test_l1_cm_hal_negative1_docsis_GetCertStatus(void)
{
    begin_case(91);
    UT_ASSERT_EQUAL(docsis_GetCertStatus(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 092: retrieve the cable-modem reset count. */
void test_l1_cm_hal_positive1_Get_CableModemResetCount(void)
{
    ULONG value = 0;
    begin_case(92);
    UT_ASSERT_EQUAL(cm_hal_Get_CableModemResetCount(&value), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 093: reject a NULL cable-modem reset count. */
void test_l1_cm_hal_negative1_Get_CableModemResetCount(void)
{
    begin_case(93);
    UT_ASSERT_EQUAL(cm_hal_Get_CableModemResetCount(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 094: retrieve the local reset count. */
void test_l1_cm_hal_positive1_Get_LocalResetCount(void)
{
    ULONG value = 0;
    begin_case(94);
    UT_ASSERT_EQUAL(cm_hal_Get_LocalResetCount(&value), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 095: reject a NULL local reset count. */
void test_l1_cm_hal_negative1_Get_LocalResetCount(void)
{
    begin_case(95);
    UT_ASSERT_EQUAL(cm_hal_Get_LocalResetCount(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 096: retrieve the DOCSIS reset count. */
void test_l1_cm_hal_positive1_Get_DocsisResetCount(void)
{
    ULONG value = 0;
    begin_case(96);
    UT_ASSERT_EQUAL(cm_hal_Get_DocsisResetCount(&value), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 097: reject a NULL DOCSIS reset count. */
void test_l1_cm_hal_negative1_Get_DocsisResetCount(void)
{
    begin_case(97);
    UT_ASSERT_EQUAL(cm_hal_Get_DocsisResetCount(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 098: retrieve the eRouter reset count. */
void test_l1_cm_hal_positive1_Get_ErouterResetCount(void)
{
    ULONG value = 0;
    begin_case(98);
    UT_ASSERT_EQUAL(cm_hal_Get_ErouterResetCount(&value), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 099: reject a NULL eRouter reset count. */
void test_l1_cm_hal_negative1_Get_ErouterResetCount(void)
{
    begin_case(99);
    UT_ASSERT_EQUAL(cm_hal_Get_ErouterResetCount(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 100: enable the HTTP LED flash. */
void test_l1_cm_hal_positive1_HTTP_LED_Flash(void)
{
    begin_case(100);
    UT_ASSERT_EQUAL(cm_hal_HTTP_LED_Flash(TRUE), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 101: disable the HTTP LED flash. */
void test_l1_cm_hal_positive2_HTTP_LED_Flash(void)
{
    begin_case(101);
    UT_ASSERT_EQUAL(cm_hal_HTTP_LED_Flash(FALSE), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 102: reject a non-boolean HTTP LED value. */
void test_l1_cm_hal_negative1_HTTP_LED_Flash(void)
{
    begin_case(102);
    UT_ASSERT_EQUAL(cm_hal_HTTP_LED_Flash(2), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 103: retrieve all DS OFDM rows without leaking an overwritten allocation. */
void test_l1_cm_hal_positive1_docsis_GetDsOfdmChanTable(void)
{
    PDOCSIF31_CM_DS_OFDM_CHAN info = NULL;
    int count = 0;
    begin_case(103);
    int status = docsis_GetDsOfdmChanTable(&info, &count);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    UT_ASSERT_TRUE(count >= 0);
    UT_ASSERT_TRUE(count == 0 || info != NULL);
    if (status == RETURN_OK && info != NULL)
    {
        for (int i = 0; i < count; ++i)
        {
            UT_ASSERT_TRUE(info[i].ChanIndicator >= 2 && info[i].ChanIndicator <= 4);
            UT_ASSERT_TRUE(info[i].FirstActiveSubcarrierNum >= 148 &&
                           info[i].FirstActiveSubcarrierNum <= 7895);
            UT_ASSERT_TRUE(info[i].LastActiveSubcarrierNum >= 148 &&
                           info[i].LastActiveSubcarrierNum <= 7895);
            /* Physical spacing is documented in kHz, not its integer encoding. */
            UT_ASSERT_TRUE(info[i].SubcarrierSpacing == 25 ||
                           info[i].SubcarrierSpacing == 50 ||
                           info[i].SubcarrierSpacing == 25000 ||
                           info[i].SubcarrierSpacing == 50000);
            /*
             * Fractional microseconds cannot be recovered from this integer
             * without a defined scale. Do not invent a divisibility rule.
             * The Linux fixture explicitly uses a PHY sample count.
             */
#ifdef BUILD_LINUX
            UT_ASSERT_EQUAL(info[i].CyclicPrefix, 192);
#endif
            CHECK_TEXT(info[i].averageSNR);
            CHECK_TEXT(info[i].PowerLevel);
        }
    }
    free(info);
}

/* PUBLIC_INTERFACE */
/** Case 104: reject a NULL DS OFDM outer output. */
void test_l1_cm_hal_negative1_docsis_GetDsOfdmChanTable(void)
{
    int count = 0;
    begin_case(104);
    UT_ASSERT_EQUAL(docsis_GetDsOfdmChanTable(NULL, &count), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 105: reject a NULL DS OFDM count with an initialized output pointer. */
void test_l1_cm_hal_negative2_docsis_GetDsOfdmChanTable(void)
{
    PDOCSIF31_CM_DS_OFDM_CHAN info = NULL;
    begin_case(105);
    UT_ASSERT_EQUAL(docsis_GetDsOfdmChanTable(&info, NULL), RETURN_ERR);
    free(info);
}

/* PUBLIC_INTERFACE */
/** Case 106: retrieve all US OFDMA rows and free only the returned snapshot. */
void test_l1_cm_hal_positive1_docsis_GetUsOfdmaChanTable(void)
{
    PDOCSIF31_CM_US_OFDMA_CHAN info = NULL;
    int count = 0;
    begin_case(106);
    int status = docsis_GetUsOfdmaChanTable(&info, &count);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    UT_ASSERT_TRUE(count >= 0);
    UT_ASSERT_TRUE(count == 0 || info != NULL);
    if (status == RETURN_OK && info != NULL)
    {
        for (int i = 0; i < count; ++i)
        {
            UT_ASSERT_TRUE(info[i].FirstActiveSubcarrierNum >= 74 &&
                           info[i].FirstActiveSubcarrierNum <= 3947);
            UT_ASSERT_TRUE(info[i].LastActiveSubcarrierNum >= 74 &&
                           info[i].LastActiveSubcarrierNum <= 3947);
            UT_ASSERT_TRUE(info[i].NumActiveSubcarriers >= 1 &&
                           info[i].NumActiveSubcarriers <= 3800);
            /* Accept the documented physical spacing in either kHz or Hz. */
            UT_ASSERT_TRUE(info[i].SubcarrierSpacing == 25 ||
                           info[i].SubcarrierSpacing == 50 ||
                           info[i].SubcarrierSpacing == 25000 ||
                           info[i].SubcarrierSpacing == 50000);
        }
    }
    free(info);
}

/* PUBLIC_INTERFACE */
/** Case 107: reject a NULL US OFDMA outer output. */
void test_l1_cm_hal_negative1_docsis_GetUsOfdmaChanTable(void)
{
    int count = 0;
    begin_case(107);
    UT_ASSERT_EQUAL(docsis_GetUsOfdmaChanTable(NULL, &count), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 108: reject a NULL US OFDMA count with an initialized output pointer. */
void test_l1_cm_hal_negative2_docsis_GetUsOfdmaChanTable(void)
{
    PDOCSIF31_CM_US_OFDMA_CHAN info = NULL;
    begin_case(108);
    UT_ASSERT_EQUAL(docsis_GetUsOfdmaChanTable(&info, NULL), RETURN_ERR);
    free(info);
}

/* PUBLIC_INTERFACE */
/** Case 109: check the OFDMA status snapshot after, not before, allocation. */
void test_l1_cm_hal_positive1_docsis_GetStatusOfdmaUsTable(void)
{
    PDOCSIF31_CMSTATUSOFDMA_US info = NULL;
    int count = 0;
    begin_case(109);
    int status = docsis_GetStatusOfdmaUsTable(&info, &count);
    UT_ASSERT_EQUAL(status, RETURN_OK);
    UT_ASSERT_TRUE(count >= 0);
    UT_ASSERT_TRUE(count == 0 || info != NULL);
    if (status == RETURN_OK && info != NULL)
    {
        for (int i = 0; i < count; ++i)
        {
            UT_ASSERT_TRUE(info[i].RangingStatus >= 1 && info[i].RangingStatus <= 6);
            UT_ASSERT_TRUE(info[i].IsMuted == TRUE || info[i].IsMuted == FALSE);
            UT_LOG_DEBUG("OFDMA channel %u muted: %u", info[i].ChannelId,
                         (unsigned int)info[i].IsMuted);
        }
    }
    free(info);
}

/* PUBLIC_INTERFACE */
/** Case 110: reject a NULL OFDMA status outer output. */
void test_l1_cm_hal_negative1_docsis_GetStatusOfdmaUsTable(void)
{
    int count = 0;
    begin_case(110);
    UT_ASSERT_EQUAL(docsis_GetStatusOfdmaUsTable(NULL, &count), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 111: reject a NULL OFDMA status count with initialized output storage. */
void test_l1_cm_hal_negative2_docsis_GetStatusOfdmaUsTable(void)
{
    PDOCSIF31_CMSTATUSOFDMA_US info = NULL;
    begin_case(111);
    UT_ASSERT_EQUAL(docsis_GetStatusOfdmaUsTable(&info, NULL), RETURN_ERR);
    free(info);
}

/* PUBLIC_INTERFACE */
/** Case 112: LLD success means ENABLE or DISABLE; an error is never ENABLE. */
void test_l1_cm_hal_positive1_docsis_LLDgetEnableStatus(void)
{
    begin_case(112);
    int status = docsis_LLDgetEnableStatus();
    UT_ASSERT_NOT_EQUAL(status, RETURN_ERR);
    UT_ASSERT_TRUE(status == ENABLE || status == DISABLE);
}

/* PUBLIC_INTERFACE */
/** Case 113: SNMP byte lengths exactly match live, caller-owned buffers. */
void test_l1_cm_hal_positive1_cm_hal_snmpv3_kickstart_initialize(void)
{
    unsigned char name[] = "Name1";
    unsigned char number[] = "0ABCDEFG";
    fixed_length_buffer_t name_buffer = {sizeof(name) - 1, name};
    fixed_length_buffer_t number_buffer = {sizeof(number) - 1, number};
    snmp_kickstart_row_t row = {name_buffer, number_buffer};
    snmpv3_kickstart_table_t table = {0};
    begin_case(113);
    table.n_rows = 1;
    table.kickstart_values[0] = &row;
    UT_ASSERT_EQUAL(cm_hal_snmpv3_kickstart_initialize(&table), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 114: reject a NULL SNMP table. */
void test_l1_cm_hal_negative1_cm_hal_snmpv3_kickstart_initialize(void)
{
    begin_case(114);
    UT_ASSERT_EQUAL(cm_hal_snmpv3_kickstart_initialize(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 115: reject a NULL SNMP row in an otherwise initialized table. */
void test_l1_cm_hal_negative2_cm_hal_snmpv3_kickstart_initialize(void)
{
    snmpv3_kickstart_table_t table = {0};
    begin_case(115);
    table.n_rows = 1;
    UT_ASSERT_EQUAL(cm_hal_snmpv3_kickstart_initialize(&table), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 116: energy detection returns a boolean. */
void test_l1_cm_hal_positive1_docsis_IsEnergyDetected(void)
{
    BOOLEAN detected = 2;
    begin_case(116);
    UT_ASSERT_EQUAL(docsis_IsEnergyDetected(&detected), RETURN_OK);
    UT_ASSERT_TRUE(detected == TRUE || detected == FALSE);
}

/* PUBLIC_INTERFACE */
/** Case 117: reject a NULL energy output. */
void test_l1_cm_hal_negative1_docsis_IsEnergyDetected(void)
{
    begin_case(117);
    UT_ASSERT_EQUAL(docsis_IsEnergyDetected(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 118: accept a MAC reinitialization threshold. */
void test_l1_cm_hal_positive1_set_ReinitMacThreshold(void)
{
    begin_case(118);
    UT_ASSERT_EQUAL(cm_hal_set_ReinitMacThreshold(10), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 119: retrieve a MAC reinitialization threshold. */
void test_l1_cm_hal_positive1_get_ReinitMacThreshold(void)
{
    ULONG value = 0;
    begin_case(119);
    UT_ASSERT_EQUAL(cm_hal_get_ReinitMacThreshold(&value), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 120: reject a NULL threshold output. */
void test_l1_cm_hal_negative1_get_ReinitMacThreshold(void)
{
    begin_case(120);
    UT_ASSERT_EQUAL(cm_hal_get_ReinitMacThreshold(NULL), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 121: retrieve diplexer settings into initialized caller-owned storage. */
void test_l1_cm_hal_positive1_cm_hal_get_DiplexerSettings(void)
{
    CM_DIPLEXER_SETTINGS settings = {0};
    begin_case(121);
    UT_ASSERT_EQUAL(cm_hal_get_DiplexerSettings(&settings), RETURN_OK);
    UT_LOG_DEBUG("Diplexer US=%u DS=%u", settings.usDiplexerSetting, settings.dsDiplexerSetting);
}

/* PUBLIC_INTERFACE */
/** Case 122: reject a NULL diplexer output. */
void test_l1_cm_hal_negative1_cm_hal_get_DiplexerSettings(void)
{
    begin_case(122);
    UT_ASSERT_EQUAL(cm_hal_get_DiplexerSettings(NULL), RETURN_ERR);
}

#ifdef BUILD_LINUX
/* PUBLIC_INTERFACE */
/** Case 123: a configured simulated HTTP download starts successfully. */
void test_l1_cm_hal_positive1_HTTP_Download(void)
{
    begin_case(123);
    if (configure_http() == RETURN_OK)
    {
        UT_ASSERT_EQUAL(cm_hal_HTTP_Download(), RETURN_OK);
    }
}

/* PUBLIC_INTERFACE */
/** Case 124: an unconfigured reference download is rejected without host I/O. */
void test_l1_cm_hal_negative1_HTTP_Download(void)
{
    begin_case(124);
    UT_ASSERT_EQUAL(cm_hal_HTTP_Download(), RETURN_ERR);
}

/* PUBLIC_INTERFACE */
/** Case 125: accept a safe simulated firmware/factory-reset request. */
void test_l1_cm_hal_positive1_FWupdateAndFactoryReset(void)
{
    char url[MAX_STRING_LENGTH] = {0};
    char filename[MAX_STRING_LENGTH] = {0};
    begin_case(125);
    READ_PROFILE("cm.config.HttpUrl", url);
    READ_PROFILE("cm.config.filename", filename);
    UT_ASSERT_EQUAL(cm_hal_FWupdateAndFactoryReset(url, filename), RETURN_OK);
}
#endif

/**
 * The registered callback deliberately takes its payload BY VALUE, as required
 * by the public typedef. It has static lifetime because it cannot be removed.
 * State-transition dispatch and getter matching are exercised in L2.
 */
static INT diplexer_callback(CM_DIPLEXER_SETTINGS settings)
{
    UT_LOG_DEBUG("Diplexer callback US=%u DS=%u",
                 settings.usDiplexerSetting, settings.dsDiplexerSetting);
    return RETURN_OK;
}

/* PUBLIC_INTERFACE */
/** Case 126: register an exactly typed, by-value diplexer callback. */
void test_l1_cm_hal_positive1_Register_DiplexerVariationCallback(void)
{
    cm_hal_DiplexerVariationCallback callback = diplexer_callback;
    begin_case(126);
    UT_ASSERT_EQUAL(cm_hal_Register_DiplexerVariationCallback(callback), RETURN_OK);
}

/* PUBLIC_INTERFACE */
/** Case 127: reject a NULL diplexer callback. */
void test_l1_cm_hal_negative1_Register_DiplexerVariationCallback(void)
{
    begin_case(127);
    UT_ASSERT_EQUAL(cm_hal_Register_DiplexerVariationCallback(NULL), RETURN_ERR);
}

/*
 * Exercise each of the 12 public pointer aliases by mutating a named member
 * through it and observing the corresponding struct. Do not compare padding
 * or assume the size of ULONG on a particular target.
 */
#define CHECK_ALIAS(type, alias, member, value) do { \
    type object = {0}; \
    alias pointer = &object; \
    pointer->member = (value); \
    UT_ASSERT_EQUAL(object.member, (value)); \
    UT_ASSERT_PTR_EQUAL(pointer, &object); \
} while (0)

/* PUBLIC_INTERFACE */
/** Case 128: cover all 17 struct typedefs, all 12 pointer aliases and constants. */
void test_l1_cm_hal_public_types_and_constants(void)
{
    begin_case(128);
    CHECK_ALIAS(CMMGMT_CM_DS_CHANNEL, PCMMGMT_CM_DS_CHANNEL, ChannelID, 7);
    CHECK_ALIAS(CMMGMT_CM_US_CHANNEL, PCMMGMT_CM_US_CHANNEL, ChannelID, 8);
    CHECK_ALIAS(CMMGMT_CM_DOCSIS_INFO, PCMMGMT_CM_DOCSIS_INFO, DOCSISDHCPAttempts, 9);
    CHECK_ALIAS(CMMGMT_CM_ERROR_CODEWORDS, PCMMGMT_CM_ERROR_CODEWORDS, CorrectableCodewords, 10);
    CHECK_ALIAS(CMMGMT_DML_CM_LOG, PCMMGMT_DML_CM_LOG, EnableLog, TRUE);
    CHECK_ALIAS(CMMGMT_DML_DOCSISLOG_FULL, PCMMGMT_DML_DOCSISLOG_FULL, EventID, 11);
    CHECK_ALIAS(CMMGMT_CM_DHCP_INFO, PCMMGMT_CM_DHCP_INFO, LeaseTimeRemaining, 12);
    CHECK_ALIAS(CMMGMT_CM_IPV6DHCP_INFO, PCMMGMT_CM_IPV6DHCP_INFO, IPv6LeaseTimeRemaining, 13);
    CHECK_ALIAS(CMMGMT_DML_CPE_LIST, PCMMGMT_DML_CPE_LIST, IPAddress[0], '1');
    CHECK_ALIAS(DOCSIF31_CM_DS_OFDM_CHAN, PDOCSIF31_CM_DS_OFDM_CHAN, ChannelId, 14);
    CHECK_ALIAS(DOCSIF31_CM_US_OFDMA_CHAN, PDOCSIF31_CM_US_OFDMA_CHAN, ChannelId, 15);
    CHECK_ALIAS(DOCSIF31_CMSTATUSOFDMA_US, PDOCSIF31_CMSTATUSOFDMA_US, IsMuted, TRUE);

    CMMGMT_DML_CM_LOG log_config = {TRUE, FALSE};
    CMMGMT_DML_DOCSISLOG_FULL full_log = {0};
    CMMGMT_CM_EventLogEntry_t event = {0};
    DOCSIF31_CM_DS_OFDM_CHAN ofdm = {0};
    unsigned char bytes[] = {0x00, 0x7f, 0xff};
    fixed_length_buffer_t buffer = {sizeof(bytes), bytes};
    snmp_kickstart_row_t row = {buffer, buffer};
    snmpv3_kickstart_table_t table = {0};
    CM_DIPLEXER_SETTINGS settings = {85, 1002};
    ANSC_IPV4_ADDRESS address = {.Dot = {192, 0, 2, 1}};
    unsigned char address_bytes[IPV4_ADDRESS_SIZE] = {0};

    UT_ASSERT_EQUAL(OFDM_PARAM_STR_MAX_LEN, 64);
    UT_ASSERT_EQUAL(EVM_MAX_EVENT_TEXT, 255);
    UT_ASSERT_EQUAL(MAX_KICKSTART_ROWS, 5);
    UT_ASSERT_EQUAL(IPV4_ADDRESS_SIZE, 4);
    UT_ASSERT_EQUAL(sizeof(ofdm.averageSNR), OFDM_PARAM_STR_MAX_LEN);
    UT_ASSERT_EQUAL(sizeof(ofdm.PowerLevel), OFDM_PARAM_STR_MAX_LEN);
    UT_ASSERT_EQUAL(sizeof(event.docsDevEvText), EVM_MAX_EVENT_TEXT);
    UT_ASSERT_EQUAL(ARRAY_COUNT(table.kickstart_values), MAX_KICKSTART_ROWS);
    UT_ASSERT_EQUAL(sizeof(address.Dot), IPV4_ADDRESS_SIZE);
    UT_ASSERT_EQUAL(sizeof(address.Value), sizeof(uint32_t));

    /* Byte-wise union roundtrip is portable across target endianness. */
    memcpy(address_bytes, &address.Value, sizeof(address_bytes));
    UT_ASSERT_EQUAL(memcmp(address.Dot, address_bytes, sizeof(address_bytes)), 0);
    UT_ASSERT_EQUAL(address.Dot[IPV4_ADDRESS_SIZE - 1], 1);
    event.docsDevEvText[EVM_MAX_EVENT_TEXT - 1] = '\0';
    ofdm.averageSNR[OFDM_PARAM_STR_MAX_LEN - 1] = '\0';
    full_log.Index = 1;
    full_log.EventLevel = 3;
    full_log.Time[sizeof(full_log.Time) - 1] = '\0';
    full_log.Description[sizeof(full_log.Description) - 1] = '\0';
    table.n_rows = MAX_KICKSTART_ROWS;
    table.kickstart_values[MAX_KICKSTART_ROWS - 1] = &row;
    UT_ASSERT_TRUE(log_config.EnableLog == TRUE && log_config.ClearDocsisLog == FALSE);
    UT_ASSERT_EQUAL(full_log.Index, 1);
    UT_ASSERT_EQUAL(full_log.EventLevel, 3);
    CHECK_TEXT(full_log.Time);
    CHECK_TEXT(full_log.Description);
    CHECK_TEXT(event.docsDevEvText);
    CHECK_TEXT(ofdm.averageSNR);
    UT_ASSERT_EQUAL(table.n_rows, MAX_KICKSTART_ROWS);
    UT_ASSERT_PTR_EQUAL(table.kickstart_values[MAX_KICKSTART_ROWS - 1], &row);
    UT_ASSERT_EQUAL(row.security_name.length, sizeof(bytes));
    UT_ASSERT_EQUAL(row.security_number.buffer[2], 0xff);
    UT_ASSERT_EQUAL(settings.usDiplexerSetting, 85);
    UT_ASSERT_EQUAL(settings.dsDiplexerSetting, 1002);
}

#ifdef BUILD_LINUX
/* PUBLIC_INTERFACE */
/** Case 129: injected LLD retrieval failure is distinguishable from ENABLE. */
void test_l1_cm_hal_negative1_docsis_LLDgetEnableStatus(void)
{
    begin_case(129);
    UT_ASSERT_EQUAL(cm_hal_test_fail_next("docsis_LLDgetEnableStatus"), RETURN_OK);
    int status = docsis_LLDgetEnableStatus();
    UT_ASSERT_EQUAL(status, RETURN_ERR);
    UT_ASSERT_NOT_EQUAL(status, ENABLE);
}

/* PUBLIC_INTERFACE */
/** Case 130: reject invalid nested SNMP buffers and excessive row counts safely. */
void test_l1_cm_hal_negative3_cm_hal_snmpv3_kickstart_initialize(void)
{
    unsigned char byte = 0;
    snmp_kickstart_row_t row = {{1, &byte}, {1, &byte}};
    snmpv3_kickstart_table_t table = {0};
    begin_case(130);
    table.n_rows = MAX_KICKSTART_ROWS + 1;
    UT_ASSERT_EQUAL(cm_hal_snmpv3_kickstart_initialize(&table), RETURN_ERR);
    table.n_rows = 1;
    table.kickstart_values[0] = &row;
    row.security_name.buffer = NULL;
    UT_ASSERT_EQUAL(cm_hal_snmpv3_kickstart_initialize(&table), RETURN_ERR);
    row.security_name.buffer = &byte;
    row.security_number.buffer = NULL;
    UT_ASSERT_EQUAL(cm_hal_snmpv3_kickstart_initialize(&table), RETURN_ERR);
}
#endif

/* PUBLIC_INTERFACE */
/**
 * Register all L1 cases using UT_TESTS_L1; no parameters.
 * Return 0 on success or -1 if suite/test registration fails.
 */
int test_cm_hal_register(void)
{
    UT_test_suite_t *suite = UT_add_suite_withGroupID(
        "[L1 cm_hal]", NULL, finish_suite, UT_TESTS_L1);
    if (suite == NULL)
    {
        return -1;
    }

    /* Stringification preserves every original externally visible test name. */
#define ADD_CASE(suffix) do { \
    if (UT_add_test(suite, "l1_cm_hal_" #suffix, test_l1_cm_hal_##suffix) == NULL) \
    { return -1; } \
} while (0)

    ADD_CASE(positive1_cm_hal_InitDB);
    ADD_CASE(positive1_docsis_InitDS);
    ADD_CASE(positive1_docsis_InitUS);
    ADD_CASE(positive1_docsis_getCMStatus);
    ADD_CASE(negative1_docsis_getCMStatus);
    ADD_CASE(positive1_docsis_GetDSChannel);
    ADD_CASE(negative1_docsis_GetDSChannel);
    ADD_CASE(positive1_docsis_GetUsStatus);
    ADD_CASE(negative1_docsis_GetUsStatus);
    ADD_CASE(positive1_docsis_GetUSChannel);
    ADD_CASE(negative1_docsis_GetUSChannel);
    ADD_CASE(positive1_docsis_GetDOCSISInfo);
    ADD_CASE(negative1_docsis_GetDOCSISInfo);
    ADD_CASE(positive1_docsis_GetNumOfActiveTxChannels);
    ADD_CASE(negative1_docsis_GetNumOfActiveTxChannels);
    ADD_CASE(positive1_docsis_GetNumOfActiveRxChannels);
    ADD_CASE(negative1_docsis_GetNumOfActiveRxChannels);
    ADD_CASE(positive1_docsis_GetErrorCodewords);
    ADD_CASE(negative1_docsis_GetErrorCodewords);
    ADD_CASE(positive1_docsis_GetMddIpModeOverride);
    ADD_CASE(negative1_docsis_GetMddIpModeOverride);
    ADD_CASE(positive2_docsis_GetMddIpModeOverride);
    ADD_CASE(positive1_docsis_SetMddIpModeOverride);
    ADD_CASE(positive2_docsis_SetMddIpModeOverride);
    ADD_CASE(positive3_docsis_SetMddIpModeOverride);
    ADD_CASE(positive4_docsis_SetMddIpModeOverride);
    ADD_CASE(negative1_docsis_SetMddIpModeOverride);
    ADD_CASE(negative2_docsis_SetMddIpModeOverride);
    ADD_CASE(negative3_docsis_SetMddIpModeOverride);
    ADD_CASE(negative4_docsis_SetMddIpModeOverride);
    ADD_CASE(negative5_docsis_SetMddIpModeOverride);
    ADD_CASE(negative6_docsis_SetMddIpModeOverride);
    ADD_CASE(positive1_docsis_GetUSChannelId);
    ADD_CASE(negative1_docsis_SetUSChannelId);
    ADD_CASE(positive1_docsis_SetUSChannelId);
    ADD_CASE(positive1_docsis_GetDownFreq);
    ADD_CASE(positive1_docsis_SetStartFreq);
    ADD_CASE(positive2_docsis_SetStartFreq);
    ADD_CASE(positive1_docsis_GetDocsisEventLogItems);
    ADD_CASE(positive2_docsis_GetDocsisEventLogItems);
    ADD_CASE(negative1_docsis_GetDocsisEventLogItems);
    ADD_CASE(negative2_docsis_GetDocsisEventLogItems);
    ADD_CASE(positive1_docsis_ClearDocsisEventLog);
    ADD_CASE(positive1_GetDHCPInfo);
    ADD_CASE(negative1_GetDHCPInfo);
    ADD_CASE(positive1_GetIPv6DHCPInfo);
    ADD_CASE(negative1_GetIPv6DHCPInfo);
    ADD_CASE(positive1_GetCPEList);
    ADD_CASE(positive2_GetCPEList);
    ADD_CASE(negative1_GetCPEList);
    ADD_CASE(negative2_GetCPEList);
    ADD_CASE(negative3_GetCPEList);
    ADD_CASE(negative4_GetCPEList);
    ADD_CASE(negative5_GetCPEList);
    ADD_CASE(positive1_GetMarket);
    ADD_CASE(negative1_GetMarket);
    ADD_CASE(positive2_GetMarket);
    ADD_CASE(positive1_Set_HTTP_Download_Url);
    ADD_CASE(negative1_Set_HTTP_Download_Url);
    ADD_CASE(negative2_Set_HTTP_Download_Url);
    ADD_CASE(negative3_Set_HTTP_Download_Url);
    ADD_CASE(negative4_Set_HTTP_Download_Url);
    ADD_CASE(negative5_Set_HTTP_Download_Url);
    ADD_CASE(negative6_Set_HTTP_Download_Url);
    ADD_CASE(positive1_Get_HTTP_Download_Url);
    ADD_CASE(negative1_Get_HTTP_Download_Url);
    ADD_CASE(negative2_Get_HTTP_Download_Url);
    ADD_CASE(positive2_Get_HTTP_Download_Url);
    ADD_CASE(positive1_Set_HTTP_Download_Interface);
    ADD_CASE(positive2_Set_HTTP_Download_Interface);
    ADD_CASE(negative1_Set_HTTP_Download_Interface);
    ADD_CASE(positive1_Get_HTTP_Download_Interface);
    ADD_CASE(negative1_Get_HTTP_Download_Interface);
    ADD_CASE(positive1_Get_HTTP_Download_Status);
    ADD_CASE(positive1_Reboot_Ready);
    ADD_CASE(negative1_Reboot_Ready);
#ifdef BUILD_LINUX
    ADD_CASE(positive1_HTTP_Download_Reboot_Now);
#endif
    ADD_CASE(negative1_FWupdateAndFactoryReset);
    ADD_CASE(negative2_FWupdateAndFactoryReset);
    ADD_CASE(negative3_FWupdateAndFactoryReset);
    ADD_CASE(negative4_FWupdateAndFactoryReset);
    ADD_CASE(negative5_FWupdateAndFactoryReset);
    ADD_CASE(negative6_FWupdateAndFactoryReset);
    ADD_CASE(negative7_FWupdateAndFactoryReset);
    ADD_CASE(positive1_ReinitMac);
    ADD_CASE(positive1_docsis_GetProvIpType);
    ADD_CASE(negative1_docsis_GetProvIpType);
    ADD_CASE(positive1_docsis_GetCert);
    ADD_CASE(negative1_docsis_GetCert);
    ADD_CASE(positive1_docsis_GetCertStatus);
    ADD_CASE(negative1_docsis_GetCertStatus);
    ADD_CASE(positive1_Get_CableModemResetCount);
    ADD_CASE(negative1_Get_CableModemResetCount);
    ADD_CASE(positive1_Get_LocalResetCount);
    ADD_CASE(negative1_Get_LocalResetCount);
    ADD_CASE(positive1_Get_DocsisResetCount);
    ADD_CASE(negative1_Get_DocsisResetCount);
    ADD_CASE(positive1_Get_ErouterResetCount);
    ADD_CASE(negative1_Get_ErouterResetCount);
    ADD_CASE(positive1_HTTP_LED_Flash);
    ADD_CASE(positive2_HTTP_LED_Flash);
    ADD_CASE(negative1_HTTP_LED_Flash);
    ADD_CASE(positive1_docsis_GetDsOfdmChanTable);
    ADD_CASE(negative1_docsis_GetDsOfdmChanTable);
    ADD_CASE(negative2_docsis_GetDsOfdmChanTable);
    ADD_CASE(positive1_docsis_GetUsOfdmaChanTable);
    ADD_CASE(negative1_docsis_GetUsOfdmaChanTable);
    ADD_CASE(negative2_docsis_GetUsOfdmaChanTable);
    ADD_CASE(positive1_docsis_GetStatusOfdmaUsTable);
    ADD_CASE(negative1_docsis_GetStatusOfdmaUsTable);
    ADD_CASE(negative2_docsis_GetStatusOfdmaUsTable);
    ADD_CASE(positive1_docsis_LLDgetEnableStatus);
    ADD_CASE(positive1_cm_hal_snmpv3_kickstart_initialize);
    ADD_CASE(negative1_cm_hal_snmpv3_kickstart_initialize);
    ADD_CASE(negative2_cm_hal_snmpv3_kickstart_initialize);
    ADD_CASE(positive1_docsis_IsEnergyDetected);
    ADD_CASE(negative1_docsis_IsEnergyDetected);
    ADD_CASE(positive1_set_ReinitMacThreshold);
    ADD_CASE(positive1_get_ReinitMacThreshold);
    ADD_CASE(negative1_get_ReinitMacThreshold);
    ADD_CASE(positive1_cm_hal_get_DiplexerSettings);
    ADD_CASE(negative1_cm_hal_get_DiplexerSettings);
#ifdef BUILD_LINUX
    ADD_CASE(positive1_HTTP_Download);
    ADD_CASE(negative1_HTTP_Download);
    ADD_CASE(positive1_FWupdateAndFactoryReset);
#endif
    ADD_CASE(positive1_Register_DiplexerVariationCallback);
    ADD_CASE(negative1_Register_DiplexerVariationCallback);
    ADD_CASE(public_types_and_constants);
#ifdef BUILD_LINUX
    ADD_CASE(negative1_docsis_LLDgetEnableStatus);
    ADD_CASE(negative3_cm_hal_snmpv3_kickstart_initialize);
#endif
#undef ADD_CASE
    return 0;
}
