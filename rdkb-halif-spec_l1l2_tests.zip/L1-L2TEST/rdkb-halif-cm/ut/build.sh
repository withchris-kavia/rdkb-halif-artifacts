#!/usr/bin/env bash

# *
# * If not stated otherwise in this file or this component's LICENSE file the
# * following copyright and licenses apply:
# *
# * Copyright 2023 RDK Management
# *
# * Licensed under the Apache License, Version 2.0 (the "License");
# * you may not use this file except in compliance with the License.
# * You may obtain a copy of the License at
# *
# * http://www.apache.org/licenses/LICENSE-2.0
# *
# * Unless required by applicable law or agreed to in writing, software
# * distributed under the License is distributed on an "AS IS" BASIS,
# * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# * See the License for the specific language governing permissions and
# * limitations under the License.
# *

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd) || exit 1
cd -- "$SCRIPT_DIR" || exit $?

UT_PROJECT_MAJOR_VERSION=4
TEST_REPO=git@github.com:rdkcentral/ut-core.git

if [[ ! -d ut-core ]]; then
    echo "Cloning Unit Test Core System"
    git clone -- "$TEST_REPO" ut-core || exit $?
    # An unset/empty override chooses the newest ABI-compatible release.
    if [[ -z ${UT_CORE_PROJECT_VERSION:-} ]]; then
        TAGS=$(git -C ut-core tag --list "${UT_PROJECT_MAJOR_VERSION}.*" \
            --sort=-version:refname) || exit $?
        UT_CORE_PROJECT_VERSION=${TAGS%%$'\n'*}
        if [[ -z $UT_CORE_PROJECT_VERSION ]]; then
            echo "No compatible ut-core ${UT_PROJECT_MAJOR_VERSION}.x tag found" >&2
            exit 1
        fi
    fi
    git -C ut-core checkout "$UT_CORE_PROJECT_VERSION" || exit $?
    # Bootstrap only a newly cloned dependency, never an existing checkout.
    BOOTSTRAP_ARGS=("TARGET=${TARGET:-linux}")
    for ARG in "$@"; do
        case "$ARG" in
            TARGET=*|CC=*|CXX=*) BOOTSTRAP_ARGS+=("$ARG") ;;
        esac
    done
    (cd -- ut-core && bash ./build.sh "${BOOTSTRAP_ARGS[@]}") || exit $?
    make -C ut-core/framework/ut-control "${BOOTSTRAP_ARGS[@]}" || exit $?
elif [[ -n ${UT_CORE_PROJECT_VERSION:-} ]]; then
    CURRENT=$(git -C ut-core rev-parse HEAD) || exit $?
    REQUESTED=$(git -C ut-core rev-parse --verify "${UT_CORE_PROJECT_VERSION}^{commit}") || exit $?
    if [[ $CURRENT != "$REQUESTED" ]]; then
        echo "Existing ut-core differs from UT_CORE_PROJECT_VERSION=$UT_CORE_PROJECT_VERSION; checkout left unchanged" >&2
        exit 1
    fi
fi

exec make -C "$SCRIPT_DIR" -f Makefile "$@"
