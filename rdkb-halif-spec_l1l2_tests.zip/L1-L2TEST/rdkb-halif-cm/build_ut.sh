#!/usr/bin/env bash

# *
# * If not stated otherwise in this file or this component's LICENSE file the
# * following copyright and licenses apply:
# *
# * Copyright 2023 RDK Management
# *
# * Licensed under the Apache License, Version 2.0 (the "License");
# * you may not use this file except in compliance with the License.
# * You may obtain a copy of the License at
# *
# * http://www.apache.org/licenses/LICENSE-2.0
# *
# * Unless required by applicable law or agreed to in writing, software
# * distributed under the License is distributed on an "AS IS" BASIS,
# * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# * See the License for the specific language governing permissions and
# * limitations under the License.
# *

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd) || exit 1
DIR=$SCRIPT_DIR

if [[ ${1:-} == -h || ${1:-} == --help ]]; then
    echo "Script to build the unit testing suite"
    echo " bash build_ut.sh <clean> - clean the testing"
    echo " bash build_ut.sh TARGET=xxx - build the xxx version of the tests, linux/arm etc."
    echo " bash build_ut.sh --dir xxx - Build Directory (must be first)"
    echo " bash build_ut.sh <noswitch> - build the linux version of tests using skeleton & stubs"
    exit 0
fi

if [[ ${1:-} == --dir ]]; then
    if [[ $# -lt 2 || -z $2 || $2 == -* ]]; then
        echo "build_ut.sh: --dir requires a directory" >&2
        exit 2
    fi
    DIR=$2
    shift 2
fi

UT_DIR="${DIR}/ut"
if [[ ! -d $UT_DIR ]]; then
    mkdir -p -- "$DIR" || exit $?

    # Discover a remote only when cloning is required. Capture Git's status
    # before transforming the URL so a pipeline cannot hide a failure.
    REMOTES=$(git -C "$SCRIPT_DIR" remote -v) || exit $?
    TEST_REPO=$(printf '%s\n' "$REMOTES" | awk 'NR == 1 {print $2}' |
        sed 's/halif/halif-test/g; s/hal-/haltest-/g')
    if [[ -z $TEST_REPO ]]; then
        echo "build_ut.sh: no remote available to locate the unit test suite" >&2
        exit 1
    fi

    echo "Cloning unit Test Suite for this module [${DIR}]"
    git clone -- "$TEST_REPO" "$UT_DIR" || exit $?
    git -C "$UT_DIR" checkout "${UT_PROJECT_VERSION:-main}" || exit $?
fi

# Replace this wrapper instead of losing the child status to popd or recursion.
# Explicit Bash invocation also supports checkouts without executable mode bits.
cd -- "$UT_DIR" || exit $?
exec bash ./build.sh "$@"
